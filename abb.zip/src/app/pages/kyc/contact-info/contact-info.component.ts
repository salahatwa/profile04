import { Component, OnInit } from '@angular/core';
import { Translations } from '@inma/helpers/translations';
import { kycTranslations } from '../kyctranslation';
import { Kyc } from '@inma/models/kyc';
import { SharedDataService } from 'src/app/providers/shared-data.service';
import { NavController } from '@ionic/angular';
import { Dialogs } from '@inma/helpers/dialogs';
import { resetCache } from '@inma/helpers/cached';
import { AppComponent } from 'src/app/app.component';

@Component({
  selector: 'tadawul-contact-info',
  templateUrl: './contact-info.component.html',
  styleUrls: ['./contact-info.component.scss'],
})
export class ContactInfoComponent implements OnInit {

  @Translations()
  t = kycTranslations;

  public kycDetail: any;
  public nationalAddress: any ="";
  public userContact: any;
  public citiesList = [];
  public countriesList = [];
  public responce: any;
  public selectedTab = "1";
  public addressType = "1"
  Number = Number;
  public saveClicked = false;
  public showLoader = false;
  constructor(public sharedData: SharedDataService, public navCtrl: NavController) { }


  ngOnInit() {
    Kyc.detailsCountries.subscribe((countries) => {
      this.countriesList = countries;
    });

    this.kycDetail = this.sharedData.getSharedData("kycDetail", false);
    this.citiesList = this.sharedData.getSharedData("citites", false);
    this.selectedTab = this.sharedData.getSharedData("tab");
    if(!this.selectedTab){
      this.selectedTab="1"
    }
    this.userContact = this.kycDetail?.contact;
    this.nationalAddress = this.kycDetail?.nationalAddress;
    this.addressType = 'WASEL';
  }


  saveChanges() {
    this.saveClicked = true;
    
    if(this.kycDetail.nationalAddress.city==""||this.kycDetail.nationalAddress.postalCode==null
      ||this.kycDetail.nationalAddress.street==""||this.kycDetail.nationalAddress.district==""||this.kycDetail.nationalAddress.basicNo==null
      ||this.kycDetail.nationalAddress.unitNumber==null||this.kycDetail.nationalAddress.additionalNo==null){
       // alert("Please fill Required Fields");
        Dialogs.alert(this.t.REQUIREDFIELDS as any).subscribe(ok => {
        });   
        return false;
    }
    this.showLoader = true;
    this.nationalAddress.country = { code: "SA"};
    const kycObj = Object.assign({}, this.kycDetail);
    kycObj.contact = null;
    Kyc.updateDetails(kycObj).subscribe(() => {
      resetCache(Kyc, 'details');
      AppComponent.ExpiredUserID = false;
      this.navCtrl.navigateRoot('/kyc/home', { animated: true });
      this.showLoader = false;
    },
    err => {
      console.log('HTTP Error', err);
      this.showLoader = false;
    });
  }

  openSettings() {
    this.navCtrl.navigateRoot('/settings', { animated: true });
  }


  changeTab(tab) {
    this.selectedTab = tab;
  }

  selectAddress(address) {
    this.addressType = address;
    this.nationalAddress.type.code = address;
  }
}
