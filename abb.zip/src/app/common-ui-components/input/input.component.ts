import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
// import { AppTranslations } from 'src/app/app.translations'
import {InputTranslations} from '../input/input.translations';
import { Translations } from '@inma/helpers/translations';

@Component({
  selector: 'app-input',
  templateUrl: './input.component.html',
  styleUrls: ['./input.component.scss'],
})
export class InputComponent implements OnInit {
  @Input() form:any;
  @Input() label:any;
  @Input() formControl:any;
  @Input() name:any;
  @Input() type:any;
  @Input() model:any;
  @Output() modelChange = new EventEmitter();
  @Input() layout:any;
  @Input() disabled:any = false;

  @Translations()
  t = InputTranslations;


  constructor() { }

  ngOnInit() {}

  onChange() {
    this.modelChange.emit(this.model);
  }
  // keyup(event: any){
  //   let newValue = event.target.value;
  //   console.log(event);
  //   if (event.code=="Space") {
  //     event.target.value = newValue.slice(0, -1);
  //   }
  // }
  preventPaste(){
    return false
  }

}
