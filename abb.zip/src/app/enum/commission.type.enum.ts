export enum CommissionType {
    SUBMIT_ORDER = 1,
    CONFIRM_ORDER = 2
}