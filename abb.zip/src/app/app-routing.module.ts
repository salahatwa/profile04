import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { DisconnectionPagePageModule } from './disconnection-page/disconnection-page.module';

const routes: Routes = [
  // {
  //   path: '',
  //   redirectTo: 'splash-screen',
  //   pathMatch: 'full'
  // },
  // {
  //   path: 'login',
  //   loadChildren: () => import('./pages/login/login.module').then(m => m.LoginPageModule)
  // },
  {
    path: '',
    loadChildren: () => import('./pages/login/login.module').then(m => m.LoginPageModule)
  },
  {
    path: 'splash-screen',
    loadChildren: () => import('./pages/splash-screen/splash-screen.module').then( m => m.SplashScreenPageModule)
  },
  {
    path: 'ui-samples',
    loadChildren: () => import('./ui-samples/ui-samples.module').then(m => m.UiSamplesPageModule)
  },
  {
    path: 'main',
    loadChildren: () => import('./tadawul-home/tadawul-home.module').then(m => m.TadawulHomePageModule)
  },
  {
    path: 'market',
    loadChildren: () => import('./pages/market/market.module').then(m => m.MarketPageModule)
  },

  //#region Create module region
  {
    path: 'watchlists/add',
    loadChildren: () => import('./pages/watchlists/edit/watchlist-edit.module').then(m => m.WatchlistEditPageModule)
  },
  {
    path: 'watchlists/edit/:id',
    loadChildren: () => import('./pages/watchlists/edit/watchlist-edit.module').then(m => m.WatchlistEditPageModule)
  },
  {
    path: 'watchlists/show/:id',
    loadChildren: () => import('./pages/watchlists/show/watchlist-show.module').then(m => m.WatchlistShowPageModule)
  },
  {
    path: 'watchlists',
    loadChildren: () => import('./pages/watchlists/index/watchlists-index.module').then(m => m.WatchlistsIndexPageModule)
  },
  ////
  {
    path: 'sectors/add',
    loadChildren: () => import('./pages/watchlists/edit/watchlist-edit.module').then(m => m.WatchlistEditPageModule)
  },
  {
    path: 'sectors/edit/:id',
    loadChildren: () => import('./pages/watchlists/edit/watchlist-edit.module').then(m => m.WatchlistEditPageModule)
  },
  {
    path: 'sectors/show/:id',
    loadChildren: () => import('./pages/watchlists/show/watchlist-show.module').then(m => m.WatchlistShowPageModule)
  },
  {
    path: 'sectors',
    loadChildren: () => import('./pages/watchlists/index/watchlists-index.module').then(m => m.WatchlistsIndexPageModule)
  },
  //#endregion
  {
    path: 'search',
    loadChildren: () => import('./common-ui-components/search/search.module').then(m => m.SearchPageModule)
  },
  {
    path: 'order/summary',
    loadChildren: () => import('./pages/order/summary/order-summary.module').then(m => m.OrderSummaryPageModule)
  },
  {
    path: 'settings',
    loadChildren: () => import('./pages/settings/settings.module').then(m => m.SettingsPageModule)
  },
  {
    path: 'order/confirm',
    loadChildren: () => import('./pages/order/confirm/order-confirm.module').then(m => m.OrderConfirmPageModule)
  },

  // {
  //   path: 'transfer',
  //   loadChildren: () => import('./pages/transfer/transfer.module').then(m => m.TransferPageModule)
  // },

  {
    path: 'markets',
    loadChildren: () => import('./pages/tradestation/markets-index/markets-index.module').then(m => m.MarketsIndexPageModule)
  },

  {
    path: 'token-authentication',
    loadChildren: () => import('./token-authentication/token-authentication.module').then(m => m.TokenAuthenticationPageModule)
  },
  // {
  //   path: 'contact-us',
  //   loadChildren: () => import('./pages/contact-us/contact-us.module').then( m => m.ContactUsPageModule)
  // }
  // {
  //   path: 'products',
  //   loadChildren: () => import('./pages/products/products/products.module').then(m => m.ProductsPageModule)
  // },
  // {
  //   path: 'product-details',
  //   loadChildren: () => import('./pages/products/product-details/product-details.module').then(m => m.ProductDetailsPageModule)
  // },
  // {
  //   path: 'product-subscribe',
  //   loadChildren: () => import('./pages/products/product-subscribe/product-subscribe.module').then(m => m.ProductSubscribePageModule)
  // },
  // {
  //   path: 'product-subscribe-summary',
  //   loadChildren: () => import('./pages/products/product-subscribe-summary/product-subscribe-summary.module').then(m => m.ProductSubscribeSummaryPageModule)
  // },
  {
    path: 'dynamic-authentication',
    loadChildren: () => import('./dynamic-authentication/dynamic-authentication.module').then(m => m.DynamicAuthenticationPageModule)
  },
  {
    path: 'biometric-authentication',
    loadChildren: () => import('./dynamic-authentication/biometric-authentication/biometric-authentication.module').then(m => m.BiometricAuthenticationPageModule)
  },
  {
    path: 'forget-username-password',
    loadChildren: () => import('./pages/forget-username-password/forget-username-password.module').then(m => m.ForgetUsernamePasswordPageModule)
  },
  {
    path: 'disconnection-page',
    loadChildren: () => import('./disconnection-page/disconnection-page.module').then(m => m.DisconnectionPagePageModule)
  },
  {
    path: 'session-expired',
    loadChildren: () => import('./pages/session-expired/session-expired.module').then(m => m.SessionExpiredPageModule)
  },
  {
    path: 'loading',
    loadChildren: () => import('./loading/loading.module').then(m => m.LoadingPageModule)
  },
  {
    path: 'id-expired',
    loadChildren: () => import('./pages/id-expired/id-expired.module').then( m => m.IdExpiredPageModule)
  },
  {
    path: 'nav-modal',
    loadChildren: () => import('./pages/nav-modal/nav-modal.module').then( m => m.NavModalPageModule)
  },
  {
    path: 'portfolio-actions',
    loadChildren: () => import('./pages/portfolio-actions/portfolio-actions.module').then( m => m.PortfolioActionsPageModule)
  },
  {
    path: 'mutual-fund-actions',
    loadChildren: () => import('./pages/mutual-funds/mutual-fund-actions/mutual-fund-actions.module').then( m => m.MutualFundActionsPageModule)
  },
  {
    path: 'notifications',
    loadChildren: () => import('./pages/notifications/notifications.module').then( m => m.NotificationsPageModule)
  },
  {
    path: 'open-account',
    loadChildren: () => import('./pages/open-account/open-account-stepper/open-account-stepper.module').then( m => m.OpenAccountStepperPageModule)
  },
  {
    path: 'open-account-lovs',
    loadChildren: () => import('./pages/open-account/open-account-lovs/open-account-lovs.module').then( m => m.OpenAccountLovsPageModule)
  },  {
    path: 'add-country-fatca',
    loadChildren: () => import('./pages/open-account/add-country-fatca/add-country-fatca.module').then( m => m.AddCountryFatcaPageModule)
  },
  {
    path: 'open-account-summary',
    loadChildren: () => import('./pages/open-account/open-account-summary/open-account-summary.module').then( m => m.OpenAccountSummaryPageModule)
  },





 





  // {
  //   path: 'contact-us',
  //   loadChildren: () => import('./pages/contact-us/contact-us.module').then( m => m.ContactUsPageModule)
  // }

  // {
  //   path: 'contact-us',
  //   loadChildren: () => import('./pages/contact-us/contact-us.module').then( m => m.ContactUsPageModule)
  // }

  //#endregion
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
