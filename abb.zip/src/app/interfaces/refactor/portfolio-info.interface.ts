import { LocalizedString } from './../../helpers/localized-string';
import { MFDetails } from './mutual-fund-details.interface';

    export interface Symbol {
        code: string;
    }

    export interface AvgCostPrice {
        currencyCode?: any;
        currencyRate?: any;
        amount: string;
        formatedAmount?: any;
        localAmount?: any;
    }

    export interface MrktPrice {
        currencyCode?: any;
        currencyRate?: any;
        amount: string;
        formatedAmount?: any;
        localAmount?: any;
    }

    export interface TotalCost {
        currencyCode?: any;
        currencyRate?: any;
        amount: string;
        formatedAmount?: any;
        localAmount?: any;
    }

    export interface TotalMrktValue {
        currencyCode?: any;
        currencyRate?: any;
        amount: string;
        formatedAmount?: any;
        localAmount?: any;
    }

    export interface UnrealizedProfitLoss {
        currencyCode?: any;
        currencyRate?: any;
        amount: string;
        formatedAmount?: any;
        localAmount?: any;
    }

    export interface RealizedProfitLoss {
        currencyCode?: any;
        currencyRate?: any;
        amount: string;
        formatedAmount?: any;
        localAmount?: any;
    }

    export interface TradeSecurtyInfo {
        portfolioNumber: string;
        symbol: Symbol;
        ownedQuantity: string;
        outstandSellQuantity: string;
        outstandBuyQuantity: string;
        pledgedQuantity: string;
        availQuantity: string;
        avgCostPrice: AvgCostPrice;
        mrktPrice: MrktPrice;
        totalCost: TotalCost;
        totalMrktValue: TotalMrktValue;
        unrealizedProfitLoss: UnrealizedProfitLoss;
        realizedProfitLoss: RealizedProfitLoss;
        unrealizedProfitLossPercen: string;
        realizedProfitLossPercen: string;
        portfolioPer: number;
        additionDisplayData?: any;
        productType?: any;
        productQuantity: number;
        securityType: string;
        couponDays?: any;
        couponAmount?: any;
        secArName: string;
        secEnName: string;
        _secName?: LocalizedString;
    }

    export interface PortfolioDetailsInfo {
        totalCost: string;
        totalMrktValue: string;
        totalProfitLoss: string;
        actualBalance: string;
        buyingPwrAmt: string;
        availableBalance: string;
        margin: string;
        coverageRatio: string;
        blockedAmt: string;
        accountNumber: string;
        accountType: string;
        samaAccountNumber: string;
        portfolioPostionAmt: string;
        tradeSecurties: TradeSecurtyInfo[];
        _MFDetails?: MFDetails[];
        _portfolioNumber?: string;
        _cashPercentage?: number;
        _unitPercentage?: number;
        _cashValue?: number;
        _unitValue?: number;
        _portfolioValue?: number;
        _buyingPower?: string;
        _totalLoss?: number;
        _type?: string;
        _isDefault?: boolean; 

        

    }




