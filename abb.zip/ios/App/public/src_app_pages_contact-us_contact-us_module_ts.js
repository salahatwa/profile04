"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_contact-us_contact-us_module_ts"],{

/***/ 45861:
/*!**************************************************************************!*\
  !*** ./src/app/pages/contact-us/contact-success/contact-success.page.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ContactSuccessPage": () => (/* binding */ ContactSuccessPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _contact_success_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./contact-success.page.html?ngResource */ 85134);
/* harmony import */ var _contact_success_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./contact-success.page.scss?ngResource */ 89255);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 93819);





let ContactSuccessPage = class ContactSuccessPage {
    constructor(modalControl) {
        this.modalControl = modalControl;
    }
    ngOnInit() {
    }
    closeModal() {
        this.modalControl.dismiss();
    }
};
ContactSuccessPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.ModalController }
];
ContactSuccessPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'tadawul-contact-success',
        template: _contact_success_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_contact_success_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__metadata)("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__.ModalController])
], ContactSuccessPage);



/***/ }),

/***/ 8576:
/*!***************************************************************!*\
  !*** ./src/app/pages/contact-us/contact-us-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ContactUsPageRoutingModule": () => (/* binding */ ContactUsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _contact_us_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./contact-us.page */ 94506);




const routes = [
    {
        path: '',
        component: _contact_us_page__WEBPACK_IMPORTED_MODULE_0__.ContactUsPage
    },
    {
        path: 'contact-success',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_contact-us_contact-success_contact-success_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./contact-success/contact-success.module */ 52696)).then(m => m.ContactSuccessPageModule)
    }
];
let ContactUsPageRoutingModule = class ContactUsPageRoutingModule {
};
ContactUsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ContactUsPageRoutingModule);



/***/ }),

/***/ 5344:
/*!*******************************************************!*\
  !*** ./src/app/pages/contact-us/contact-us.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ContactUsPageModule": () => (/* binding */ ContactUsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _contact_us_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./contact-us-routing.module */ 8576);
/* harmony import */ var _contact_us_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./contact-us.page */ 94506);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);









let ContactUsPageModule = class ContactUsPageModule {
};
ContactUsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _contact_us_routing_module__WEBPACK_IMPORTED_MODULE_0__.ContactUsPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateModule.forChild()
        ],
        declarations: [_contact_us_page__WEBPACK_IMPORTED_MODULE_1__.ContactUsPage]
    })
], ContactUsPageModule);



/***/ }),

/***/ 94506:
/*!*****************************************************!*\
  !*** ./src/app/pages/contact-us/contact-us.page.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ContactUsPage": () => (/* binding */ ContactUsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _contact_us_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./contact-us.page.html?ngResource */ 70290);
/* harmony import */ var _contact_us_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./contact-us.page.scss?ngResource */ 62450);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _contact_success_contact_success_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./contact-success/contact-success.page */ 45861);
/* harmony import */ var _inma_models_contact_us_contact_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/models/contact-us/contact.model */ 2855);








let ContactUsPage = class ContactUsPage {
    constructor(formBuilder, modalController) {
        this.formBuilder = formBuilder;
        this.modalController = modalController;
        this.subjects = [];
        this.buildForm();
        this.getsubjects();
    }
    ngOnInit() {
    }
    buildForm() {
        this.form = this.formBuilder.group({
            subject: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required
                ])],
            title: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required
                ])],
            content: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required
                ])],
            email: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.email
                ])]
        });
    }
    getsubjects() {
        _inma_models_contact_us_contact_model__WEBPACK_IMPORTED_MODULE_3__.Contact.getsubjects().subscribe(result => {
            result.forEach(s => {
                this.subjects.push(s.value);
            });
        });
    }
    presentSuccessModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _contact_success_contact_success_page__WEBPACK_IMPORTED_MODULE_2__.ContactSuccessPage,
                cssClass: ''
            });
            return yield modal.present();
        });
    }
    sendMessage(form) {
        console.log(this.form);
        this.submitted = true;
        if (!this.form.valid) {
            return;
        }
        _inma_models_contact_us_contact_model__WEBPACK_IMPORTED_MODULE_3__.Contact.send(this.form.value.title, this.form.value.content, this.form.value.subject, this.form.value.email).subscribe(result => {
            console.log(result);
            this.form.reset();
            this.submitted = false;
            this.presentSuccessModal();
        });
    }
};
ContactUsPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController }
];
ContactUsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'tadawul-contact-us',
        template: _contact_us_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_contact_us_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController])
], ContactUsPage);



/***/ }),

/***/ 2855:
/*!******************************************************!*\
  !*** ./src/app/🌱models/contact-us/contact.model.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Contact": () => (/* binding */ Contact),
/* harmony export */   "ContactModel": () => (/* binding */ ContactModel)
/* harmony export */ });
/* harmony import */ var _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/helpers/http */ 36802);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ 86942);


class ContactModel {
    //? how to know the request failed?
    send(title, content, subject, email) {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request("/customerSupport/CustomerSupport/contactAlinmaInvestment", { title: title, content: content, subject: subject, email: email }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.map)(result => {
            return result;
        }));
    }
    getsubjects() {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request('/customerSupport/CustomerSupport/loadAICContactSubjects')
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.map)(result => {
            return this.subjects = result;
        }));
    }
}
const Contact = new ContactModel();


/***/ }),

/***/ 89255:
/*!***************************************************************************************!*\
  !*** ./src/app/pages/contact-us/contact-success/contact-success.page.scss?ngResource ***!
  \***************************************************************************************/
/***/ ((module) => {

module.exports = "ion-content {\n  --background: #005157;\n  --background: var(--ion-color-primary-bg);\n}\n\ndiv.content {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-20%);\n}\n\np {\n  color: #ffffff;\n}\n\nion-button {\n  --border-radius: 0;\n  background-color: #ffffff;\n  position: absolute;\n  left: 0;\n  right: 0;\n  bottom: 5%;\n  transform: translateY(40%);\n  --border-color: #ffffff;\n  margin: 16px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbnRhY3Qtc3VjY2Vzcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxxQkFBQTtFQUNBLHlDQUFBO0FBQ0o7O0FBRUE7RUFDSSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxRQUFBO0VBQ0EsMkJBQUE7QUFDSjs7QUFFQTtFQUNJLGNBQUE7QUFDSjs7QUFFQTtFQUNJLGtCQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsVUFBQTtFQUNBLDBCQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0FBQ0oiLCJmaWxlIjoiY29udGFjdC1zdWNjZXNzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50IHtcbiAgICAtLWJhY2tncm91bmQ6ICMwMDUxNTc7XG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1iZyk7XG59XG5cbmRpdi5jb250ZW50e1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgbGVmdDogMDtcbiAgICByaWdodDogMDtcbiAgICB0b3A6IDUwJTtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTIwJSk7XG59XG5cbnB7XG4gICAgY29sb3I6ICNmZmZmZmY7XG59XG5cbmlvbi1idXR0b257XG4gICAgLS1ib3JkZXItcmFkaXVzOiAwO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmZmZmY7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGxlZnQ6IDA7XG4gICAgcmlnaHQ6IDA7XG4gICAgYm90dG9tOiA1JTtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoNDAlKTtcbiAgICAtLWJvcmRlci1jb2xvcjogI2ZmZmZmZjtcbiAgICBtYXJnaW46IDE2cHg7XG59Il19 */";

/***/ }),

/***/ 62450:
/*!******************************************************************!*\
  !*** ./src/app/pages/contact-us/contact-us.page.scss?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = "ion-item {\n  --border-color: transparent;\n  color: var(--ion-color-primary-txt);\n}\n\nion-toolbar {\n  --background: #005157;\n  --color: white;\n}\n\nion-back-button {\n  color: #ffffff;\n}\n\nion-label {\n  font-weight: bold;\n}\n\nion-input.title {\n  border: solid 1px #99b9bc;\n  --padding-start: 8px;\n}\n\nion-textarea.textarea {\n  border: solid 1px #99b9bc;\n  --padding-start: 8px;\n}\n\nion-segment.form-segment {\n  --background: var(--ion-color-tertiary);\n  --border-radius: 0;\n  border-radius: 0;\n}\n\nion-segment.form-segment ion-segment-button {\n  --border-radius: 0px;\n  --indicator-color: var(--ion-color-primary-bg);\n}\n\nion-segment.form-segment ion-segment-button.segment-button-checked {\n  color: white;\n}\n\n.validator-error {\n  color: #f5455a;\n  font-size: 14px;\n}\n\n.form-header {\n  text-align: center;\n  position: relative;\n  -webkit-margin-end: 16px;\n          margin-inline-end: 16px;\n  -webkit-margin-start: 16px;\n          margin-inline-start: 16px;\n  color: #005157;\n  font-size: 14px;\n  font-weight: bold;\n}\n\n.form-header span {\n  background-color: #ffffff;\n  padding: 16px;\n  z-index: 2;\n  position: relative;\n}\n\n.form-header::after {\n  content: \"\";\n  display: block;\n  width: 100%;\n  height: 1px;\n  background: #cddcdd;\n  top: 50%;\n  position: absolute;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbnRhY3QtdXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksMkJBQUE7RUFFQSxtQ0FBQTtBQUFKOztBQUdBO0VBQ0kscUJBQUE7RUFDQSxjQUFBO0FBQUo7O0FBR0E7RUFDSSxjQUFBO0FBQUo7O0FBR0E7RUFDSSxpQkFBQTtBQUFKOztBQUdBO0VBQ0kseUJBQUE7RUFDQSxvQkFBQTtBQUFKOztBQUdBO0VBQ0kseUJBQUE7RUFDQSxvQkFBQTtBQUFKOztBQUdBO0VBRUksdUNBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FBREo7O0FBRUk7RUFDSSxvQkFBQTtFQUVBLDhDQUFBO0FBRFI7O0FBRVE7RUFDSSxZQUFBO0FBQVo7O0FBT0E7RUFDSSxjQUFBO0VBQ0EsZUFBQTtBQUpKOztBQU9BO0VBQ0ksa0JBQUE7RUFDQSxrQkFBQTtFQUNBLHdCQUFBO1VBQUEsdUJBQUE7RUFDQSwwQkFBQTtVQUFBLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQUpKOztBQUtJO0VBQ0kseUJBQUE7RUFDQSxhQUFBO0VBQ0EsVUFBQTtFQUNBLGtCQUFBO0FBSFI7O0FBTUE7RUFDSSxXQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSxRQUFBO0VBQ0Esa0JBQUE7QUFKSiIsImZpbGUiOiJjb250YWN0LXVzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1pdGVtIHtcbiAgICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gICAgLy8gY29sb3I6ICMwMDU0NTc7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXR4dClcbn1cblxuaW9uLXRvb2xiYXIge1xuICAgIC0tYmFja2dyb3VuZDogIzAwNTE1NztcbiAgICAtLWNvbG9yOiB3aGl0ZTtcbn1cblxuaW9uLWJhY2stYnV0dG9ue1xuICAgIGNvbG9yOiAjZmZmZmZmO1xufVxuXG5pb24tbGFiZWwge1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuXG5pb24taW5wdXQudGl0bGUge1xuICAgIGJvcmRlcjogc29saWQgMXB4ICM5OWI5YmM7XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiA4cHg7XG59XG5cbmlvbi10ZXh0YXJlYS50ZXh0YXJlYSB7XG4gICAgYm9yZGVyOiBzb2xpZCAxcHggIzk5YjliYztcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDhweDtcbn1cblxuaW9uLXNlZ21lbnQuZm9ybS1zZWdtZW50IHtcbiAgICAvLyAtLWJhY2tncm91bmQ6ICNlNmVmZjA7XG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItdGVydGlhcnkpO1xuICAgIC0tYm9yZGVyLXJhZGl1czogMDtcbiAgICBib3JkZXItcmFkaXVzOiAwO1xuICAgIGlvbi1zZWdtZW50LWJ1dHRvbiB7XG4gICAgICAgIC0tYm9yZGVyLXJhZGl1czogMHB4O1xuICAgICAgICAvLyAtLWluZGljYXRvci1jb2xvcjogIzMzNzQ3OTtcbiAgICAgICAgLS1pbmRpY2F0b3ItY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LWJnKTtcbiAgICAgICAgJi5zZWdtZW50LWJ1dHRvbi1jaGVja2VkIHtcbiAgICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuXG5cbi52YWxpZGF0b3ItZXJyb3Ige1xuICAgIGNvbG9yOiAjZjU0NTVhO1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbn1cblxuLmZvcm0taGVhZGVye1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgbWFyZ2luLWlubGluZS1lbmQ6IDE2cHg7XG4gICAgbWFyZ2luLWlubGluZS1zdGFydDogMTZweDtcbiAgICBjb2xvcjogIzAwNTE1NztcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgc3BhbntcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcbiAgICAgICAgcGFkZGluZzogMTZweDtcbiAgICAgICAgei1pbmRleDogMjtcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIH1cbiAgICBcbiY6OmFmdGVye1xuICAgIGNvbnRlbnQ6IFwiXCI7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxcHg7XG4gICAgYmFja2dyb3VuZDogI2NkZGNkZDtcbiAgICB0b3A6IDUwJTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG59XG59Il19 */";

/***/ }),

/***/ 85134:
/*!***************************************************************************************!*\
  !*** ./src/app/pages/contact-us/contact-success/contact-success.page.html?ngResource ***!
  \***************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <!-- <ion-toolbar>\n    <ion-title>contact-success</ion-title>\n  </ion-toolbar> -->\n</ion-header>\n\n<ion-content>\n  <div class=\"content\">\n    <img src=\"assets/icon/success.svg\">\n    <ion-text class=\"ion-text-center\">\n    <p class=\"ion-text-center\">\n    {{'contactUs.THANK_YOU' | translate}}\n    </p>\n    <p class=\"ion-text-center\">\n      {{'contactUs.SEND_SUCCESS' | translate}}\n    </p>\n\n    </ion-text>\n  </div>\n\n    <ion-button\n    (click)=\"closeModal()\"\n    fill=\"outline\"\n    color=\"primary\"\n    strong=true\n    routerLink=\"tadawul-home/home\"\n    >{{'contactUs.BACK_TO_HOME' | translate}}</ion-button>\n\n\n</ion-content>\n";

/***/ }),

/***/ 70290:
/*!******************************************************************!*\
  !*** ./src/app/pages/contact-us/contact-us.page.html?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = "<ion-header translucent>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button [text]=\"''\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{'contactUs.CONTACT_US' | translate}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-grid class=\"ion-padding\">\n    <app-button\n    expand=\"block\"\n    type=\"submit\"\n    color = \"success\"\n    href = \"https://wa.me/+966920000343?\"\n    target = \"_blank\"\n    >\n    <ion-icon slot=\"end\" name=\"logo-whatsapp\"></ion-icon>\n    {{'contactUs.contactOnWatsapp' | translate}}\n  </app-button>\n  </ion-grid>\n<h4 class=\"form-header\"><span>{{'contactUs.orSendMessage' | translate}}</span></h4>\n\n  <form [formGroup]=\"form\" (ngSubmit)=\"sendMessage(form)\">\n    <ion-list>\n      <ion-item>\n        <ion-grid>\n          <ion-row>\n            <ion-label position=\"stacked\">{{'contactUs.SUBJECT' | translate}}</ion-label>\n          </ion-row>\n          <ion-row>\n            <ion-segment class='form-segment' scrollable=\"true\" [(ngModel)]=\"subject\" formControlName=\"subject\">\n            <ion-segment-button *ngFor=\"let type of subjects\" [value]=\"type\">\n              <ion-label>{{ type }}</ion-label>\n            </ion-segment-button>\n          </ion-segment>\n          <div *ngIf=\"submitted && !form.controls.subject.valid\" class=\"validator-error\">\n            {{'contactUs.INVALID_SUBJECT' | translate}}\n          </div>\n          </ion-row>\n        </ion-grid>\n      </ion-item>\n\n      <ion-item>\n        <ion-label position=\"stacked\">{{'contactUs.email' | translate}}</ion-label>\n\n        <ion-input\n        name=\"email\" \n        formControlName=\"email\"\n        [(ngModel)]=\"email\"\n        placeholder=\"{{ 'contactUs.emailPlaceholder' | translate }}\" \n        class=\"title\"\n        ></ion-input>\n        <div *ngIf=\"!form.controls.email.valid && (submitted || form.controls.email.touched)\" class=\"validator-error\">\n        {{'contactUs.invalidEmail' | translate}}\n        </div>\n      </ion-item>\n      <ion-item>\n        <ion-label position=\"stacked\">{{'contactUs.TITLE' | translate}}</ion-label>\n\n        <ion-input\n        name=\"title\" \n        formControlName=\"title\"\n        [(ngModel)]=\"title\"\n        placeholder=\"{{ 'contactUs.TITLE_PLACEHOLDER' | translate }}\" \n        class=\"title\"\n        ></ion-input>\n        <div *ngIf=\"!form.controls.title.valid && (submitted || form.controls.title.touched)\" class=\"validator-error\">\n        {{'contactUs.INVALID_TITLE' | translate}}\n        </div>\n      </ion-item>\n\n      <ion-item>\n        <ion-label position=\"stacked\">{{'contactUs.CONTENT' | translate}}</ion-label>\n\n        <ion-textarea\n        class=\"textarea\"\n        name=\"content\" \n        formControlName=\"content\"\n        [(ngModel)]=\"content\"\n        ></ion-textarea>\n        <div *ngIf=\"!form.controls.content.valid && (submitted || form.controls.content.touched)\" class=\"validator-error\">\n          {{'contactUs.INVALID_CONTENT' | translate}}\n        </div>\n\n      </ion-item>\n    </ion-list>\n    <ion-grid class=\"ion-padding\">\n      <app-button\n      expand=\"block\"\n      type=\"submit\"\n      >\n      {{'contactUs.SEND' | translate}}\n    </app-button>\n    </ion-grid>\n  </form>\n</ion-content>\n\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_contact-us_contact-us_module_ts.js.map