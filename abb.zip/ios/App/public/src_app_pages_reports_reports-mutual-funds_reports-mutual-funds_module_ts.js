"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_reports_reports-mutual-funds_reports-mutual-funds_module_ts"],{

/***/ 99855:
/*!*******************************************************************************************!*\
  !*** ./src/app/pages/reports/reports-mutual-funds/reports-mutual-funds-routing.module.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReportsMutualFundsPageRoutingModule": () => (/* binding */ ReportsMutualFundsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _reports_mutual_funds_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reports-mutual-funds.page */ 38476);




const routes = [
    {
        path: '',
        component: _reports_mutual_funds_page__WEBPACK_IMPORTED_MODULE_0__.ReportsMutualFundsPage
    }
];
let ReportsMutualFundsPageRoutingModule = class ReportsMutualFundsPageRoutingModule {
};
ReportsMutualFundsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ReportsMutualFundsPageRoutingModule);



/***/ }),

/***/ 45487:
/*!***********************************************************************************!*\
  !*** ./src/app/pages/reports/reports-mutual-funds/reports-mutual-funds.module.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReportsMutualFundsPageModule": () => (/* binding */ ReportsMutualFundsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _reports_mutual_funds_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reports-mutual-funds-routing.module */ 99855);
/* harmony import */ var _reports_mutual_funds_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./reports-mutual-funds.page */ 38476);








let ReportsMutualFundsPageModule = class ReportsMutualFundsPageModule {
};
ReportsMutualFundsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _reports_mutual_funds_routing_module__WEBPACK_IMPORTED_MODULE_0__.ReportsMutualFundsPageRoutingModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__.TranslateModule.forChild()
        ],
        declarations: [_reports_mutual_funds_page__WEBPACK_IMPORTED_MODULE_1__.ReportsMutualFundsPage]
    })
], ReportsMutualFundsPageModule);



/***/ }),

/***/ 38476:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/reports/reports-mutual-funds/reports-mutual-funds.page.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReportsMutualFundsPage": () => (/* binding */ ReportsMutualFundsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _reports_mutual_funds_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reports-mutual-funds.page.html?ngResource */ 8706);
/* harmony import */ var _reports_mutual_funds_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./reports-mutual-funds.page.scss?ngResource */ 44705);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_models_mutual_funds__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/models/mutual-funds */ 14645);





let ReportsMutualFundsPage = class ReportsMutualFundsPage {
    constructor() {
        this.MutualFunds = _inma_models_mutual_funds__WEBPACK_IMPORTED_MODULE_2__.MutualFunds;
    }
    ngOnInit() {
    }
};
ReportsMutualFundsPage.ctorParameters = () => [];
ReportsMutualFundsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'tadawul-reports-mutual-funds',
        template: _reports_mutual_funds_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_reports_mutual_funds_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__metadata)("design:paramtypes", [])
], ReportsMutualFundsPage);



/***/ }),

/***/ 44705:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/reports/reports-mutual-funds/reports-mutual-funds.page.scss?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

module.exports = ":host ion-toolbar {\n  --color: white;\n  --background: #005157;\n}\n:host ion-label {\n  color: var(--ion-color-primary-txt);\n}\n:host ion-item {\n  --inner-border-width: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlcG9ydHMtbXV0dWFsLWZ1bmRzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDSTtFQUNJLGNBQUE7RUFDQSxxQkFBQTtBQUFSO0FBR0k7RUFDSSxtQ0FBQTtBQURSO0FBSUk7RUFDSSx1QkFBQTtBQUZSIiwiZmlsZSI6InJlcG9ydHMtbXV0dWFsLWZ1bmRzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcbiAgICBpb24tdG9vbGJhciB7XG4gICAgICAgIC0tY29sb3IgICAgIDogd2hpdGU7XG4gICAgICAgIC0tYmFja2dyb3VuZDogIzAwNTE1NztcbiAgICB9XG5cbiAgICBpb24tbGFiZWwge1xuICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktdHh0KTtcbiAgICB9XG5cbiAgICBpb24taXRlbSB7XG4gICAgICAgIC0taW5uZXItYm9yZGVyLXdpZHRoOiAwO1xuICAgIH1cbn0iXX0= */";

/***/ }),

/***/ 8706:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/reports/reports-mutual-funds/reports-mutual-funds.page.html?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>{{ 'report.PAGE_TITLE' | translate }}</ion-title>\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\"></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n \n</ion-header>\n\n\n\n<ion-content>\n  <ion-item\n    button\n    *ngFor=\"let mf of MutualFunds.all | async\"\n    [routerLink]=\"['/main/reports', mf?.id]\"\n    routerDirection=\"forward\"\n  >\n    <ion-label> {{mf.name}} </ion-label>\n  </ion-item>\n\n  <!-- TODO: Empty and loading states -->\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_reports_reports-mutual-funds_reports-mutual-funds_module_ts.js.map