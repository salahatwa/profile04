"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_tradestation_tradestation_module_ts"],{

/***/ 33844:
/*!*******************************************************************!*\
  !*** ./src/app/pages/tradestation/tradestation-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TradestationPageRoutingModule": () => (/* binding */ TradestationPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _tradestation_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tradestation.page */ 3722);




const routes = [
    {
        path: '',
        component: _tradestation_page__WEBPACK_IMPORTED_MODULE_0__.TradestationPage
    }
];
let TradestationPageRoutingModule = class TradestationPageRoutingModule {
};
TradestationPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], TradestationPageRoutingModule);



/***/ }),

/***/ 20142:
/*!***********************************************************!*\
  !*** ./src/app/pages/tradestation/tradestation.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TradestationPageModule": () => (/* binding */ TradestationPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ion-bottom-drawer */ 74272);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _tradestation_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tradestation-routing.module */ 33844);
/* harmony import */ var _tradestation_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tradestation.page */ 3722);
/* harmony import */ var src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/pipes/pipes.module */ 41041);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);
/* harmony import */ var _symbol_swiper_symbol_swiper_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./symbol-swiper/symbol-swiper.module */ 69554);












let TradestationPageModule = class TradestationPageModule {
};
TradestationPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            _tradestation_routing_module__WEBPACK_IMPORTED_MODULE_0__.TradestationPageRoutingModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_3__.TadawulCommonUiModule,
            src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_2__.PipesModule,
            _symbol_swiper_symbol_swiper_module__WEBPACK_IMPORTED_MODULE_4__.SymbolSwiperModule,
            ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_10__.IonBottomDrawerModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__.TranslateModule.forChild()
        ],
        declarations: [
            _tradestation_page__WEBPACK_IMPORTED_MODULE_1__.TradestationPage
        ]
    })
], TradestationPageModule);



/***/ }),

/***/ 3722:
/*!*********************************************************!*\
  !*** ./src/app/pages/tradestation/tradestation.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TradestationPage": () => (/* binding */ TradestationPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _tradestation_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tradestation.page.html?ngResource */ 63285);
/* harmony import */ var _tradestation_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tradestation.page.scss?ngResource */ 93539);
/* harmony import */ var src_app_enum_skeleton_type_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/enum/skeleton-type.enum */ 88617);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _events_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../events.service */ 31782);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_models_symbol__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/models/symbol */ 61202);
/* harmony import */ var _inma_models_market__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @inma/models/market */ 1874);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _inma_helpers_refreshable__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @inma/helpers/refreshable */ 2281);
/* harmony import */ var _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @inma/helpers/streaming */ 9199);
/* harmony import */ var src_app_common_ui_components_sectors_dragable_modal_sectors_dragable_modal_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/common-ui-components/sectors-dragable-modal/sectors-dragable-modal.component */ 64377);
/* harmony import */ var _inma_models_watchlist__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @inma/models/watchlist */ 12059);
/* harmony import */ var src_app_common_ui_components_markets_names_dragable_modal_markets_names_dragable_modal_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/common-ui-components/markets-names-dragable-modal/markets-names-dragable-modal.component */ 48450);
/* harmony import */ var src_app_app_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/app.component */ 20721);
/* harmony import */ var src_app_common_ui_components_symbols_search_dragable_modal_symbols_search_dragable_modal_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/common-ui-components/symbols-search-dragable-modal/symbols-search-dragable-modal.component */ 75846);
/* harmony import */ var src_app_common_ui_components_watchlist_dragable_modal_watchlist_dragable_modal_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/common-ui-components/watchlist-dragable-modal/watchlist-dragable-modal.component */ 17198);
/* harmony import */ var src_app_common_ui_components_view_edit_watclist_dragable_modal_view_edit_watclist_dragable_modal_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/common-ui-components/view-edit-watclist-dragable-modal/view-edit-watclist-dragable-modal.component */ 19023);
/* harmony import */ var _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @inma/helpers/cached */ 569);






















let TradestationPage = class TradestationPage {
    constructor(route, sharedData, navCtrl, platform, modalController, routerOutlet, translate, event) {
        this.route = route;
        this.sharedData = sharedData;
        this.navCtrl = navCtrl;
        this.platform = platform;
        this.modalController = modalController;
        this.routerOutlet = routerOutlet;
        this.translate = translate;
        this.event = event;
        this.market = new _inma_models_market__WEBPACK_IMPORTED_MODULE_5__.MarketModel(_inma_models_market__WEBPACK_IMPORTED_MODULE_5__.MarketsNames.TASI);
        this.Symbols = _inma_models_symbol__WEBPACK_IMPORTED_MODULE_4__.Symbols;
        this.marketName = 'TASI';
        this.filterType = 'All';
        this.symbolSearch = false;
        this.symbolDetailsOpened = ' ';
        this.searchModalOpened = false;
        this.showLoader = true;
        this.modalBreakpoints = [];
        this.SkeletonType = src_app_enum_skeleton_type_enum__WEBPACK_IMPORTED_MODULE_2__.SkeletonType;
        this.keyboardVisible = false;
    }
    get buyClass() {
        return !!this.symbol;
    }
    ionViewWillEnter() {
        this.watchlistData = null;
        this.sectorData = null;
        _inma_models_symbol__WEBPACK_IMPORTED_MODULE_4__.Symbols.connectToStream();
        (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_16__.resetCache)(_inma_models_market__WEBPACK_IMPORTED_MODULE_5__.Market, 'info');
        this.market.changeMarkets("TASI");
        this.sharedData.marketName.next("TASI");
        this.onSymbolsLoad('TASI');
        if (src_app_app_component__WEBPACK_IMPORTED_MODULE_12__.App.platformType == 'android') {
            this.headerClass = 'android-header';
        }
        else {
            this.headerClass = '';
        }
        this.filterType = 'All';
    }
    ionViewDidLeave() {
        _inma_models_symbol__WEBPACK_IMPORTED_MODULE_4__.Symbols.disconnectToStream();
        _inma_models_watchlist__WEBPACK_IMPORTED_MODULE_10__.Watchlists.disconnectToStream();
    }
    ngOnInit() {
        let sab = getComputedStyle(document.documentElement).getPropertyValue("--sab");
        sab = sab.substring(0, sab.indexOf('px'));
        let _bottomSfeArea = Number(sab);
        let screenHeight = window.innerHeight;
        let modalContent = 250 + _bottomSfeArea;
        let modalPercent = Number((modalContent / screenHeight).toFixed(2));
        this.modalInitBreakpoint = modalPercent;
        this.modalBreakpoints = [this.modalInitBreakpoint];
        //  $('.symbol-details-opened').height(screenHeight - modalContent);
        this.platform.pause.subscribe(() => (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
            this.symbol = null;
            this.symbolDetailsOpened = " ";
            this.modalSymbolSelected = false;
        }));
        this.getDefaultWL();
        this.route.params.subscribe((params) => {
            this.onSymbolsLoad(params === null || params === void 0 ? void 0 : params.market_id);
        });
    }
    onSymbolsLoad(marketName) {
        _inma_models_symbol__WEBPACK_IMPORTED_MODULE_4__.Symbols.preload();
        this.showLoader = true;
        this.symbols = null;
        const marketID = marketName;
        if (marketID)
            this.market = new _inma_models_market__WEBPACK_IMPORTED_MODULE_5__.MarketModel(_inma_models_market__WEBPACK_IMPORTED_MODULE_5__.MarketsNames[marketID]);
        // this.market.loadMarketSymbols().subscribe();
        this.market.symbols.subscribe(data => {
            this.fullSymbols = data;
            this.symbols = data;
            setTimeout(() => {
                this.showLoader = false;
            }, 500);
        });
        //  window.dispatchEvent(new Event("resize"));
        // if (Capacitor.isPluginAvailable("Keyboard")) {
        //   Keyboard.addListener("keyboardWillShow", (info: KeyboardInfo) => {
        //     this.keyboardVisible = true;
        //     this.symbol = null;
        //   });
        //   Keyboard.addListener("keyboardWillHide", () => {
        //     this.keyboardVisible = false;
        //     setTimeout(() => {
        //       window.dispatchEvent(new Event("resize"));
        //     }, 250);
        //   });
        // }
    }
    onSymbolChange(s) {
        this.symbol = s;
        this.symbolDetailsOpened = "symbol-details-opened";
        this.modalSymbolSelected = true;
    }
    symbolDetailsDismissed() {
        this.modalSymbolSelected = false;
        this.symbol = null;
    }
    symbolDetailsWillDismissed() {
        this.symbolDetailsOpened = " ";
    }
    onClose() {
        // debugger
        this.modalSymbolSelected = false;
        if (this.symbol)
            _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_8__.Streaming.unsubscribe(`/alinma/marketDepth/${this.symbol.id}`);
        if (this.symbolSearch == false) {
            this.symbol = null;
            this.symbolDetailsOpened = " ";
        }
        else {
            this.symbolSearch = false;
        }
    }
    openSymbol() {
        this.sharedData.setSharedData(this.symbol, "sharedSymbol");
        this.navCtrl.navigateForward("symbol", { animated: true });
        // OrderPage.initialize();
    }
    /**************************************New Design Functions *****************************/
    presentSectorsModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
            this.onClose();
            const modal = yield this.modalController.create({
                component: src_app_common_ui_components_sectors_dragable_modal_sectors_dragable_modal_component__WEBPACK_IMPORTED_MODULE_9__.SectorsDragableModalComponent,
                cssClass: 'auto-height-modal ipad-full-width-modal',
                componentProps: {
                    sectorData: this.sectorData
                },
                swipeToClose: true
                // initialBreakpoint: 0.96,
                // breakpoints: [0, 0.96],
                // presentingElement:this.routerOutlet.nativeEl
            });
            modal.onDidDismiss()
                .then((data) => {
                var _a, _b;
                if (data.data != null) {
                    this.sectorData = data.data;
                    if ((_a = this.sectorData) === null || _a === void 0 ? void 0 : _a.id) {
                        this.watchlistData = null;
                        _inma_models_watchlist__WEBPACK_IMPORTED_MODULE_10__.Watchlists.allSectors.subscribe(Sectors => {
                            this.sectorData = Sectors[this.sectorData.i];
                        });
                        (_inma_models_watchlist__WEBPACK_IMPORTED_MODULE_10__.Watchlists.findSectorByID((_b = this.sectorData) === null || _b === void 0 ? void 0 : _b.id)).subscribe(watchlist => {
                            var _a;
                            this.watchlist = watchlist;
                            (_a = this.watchlist) === null || _a === void 0 ? void 0 : _a.symbols.subscribe((symbols) => {
                                this.symbols = symbols;
                            });
                        });
                    }
                }
            });
            return yield modal.present();
        });
    }
    onSectorClose() {
        this.sectorData = null;
        this.onClose();
        this.symbols = this.fullSymbols;
    }
    presentMarketsModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
            this.onClose();
            const modal = yield this.modalController.create({
                component: src_app_common_ui_components_markets_names_dragable_modal_markets_names_dragable_modal_component__WEBPACK_IMPORTED_MODULE_11__.MarketsNamesDragableModalComponent,
                cssClass: 'auto-height-modal ipad-full-width-modal',
                componentProps: {
                    marketName: this.marketName
                },
                swipeToClose: true
                //presentingElement:this.routerOutlet.nativeEl
            });
            modal.onDidDismiss()
                .then((data) => {
                if (this.marketName != data.data && data.data != null) {
                    this.marketName = data.data;
                    this.filterType = 'All';
                    this.onSymbolsLoad(data.data);
                }
            });
            return yield modal.present();
        });
    }
    presentSymbolsSearchModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
            if (this.searchModalOpened == true) {
                return false;
            }
            this.searchModalOpened = true;
            this.onClose();
            const modal = yield this.modalController.create({
                component: src_app_common_ui_components_symbols_search_dragable_modal_symbols_search_dragable_modal_component__WEBPACK_IMPORTED_MODULE_13__.SymbolsSearchDragableModalComponent,
                cssClass: 'auto-height-modal ipad-full-width-modal',
                componentProps: {
                    title: this.translate.instant('tradestion.symabolsSearch'),
                    symbols: this.fullSymbols,
                    prevPage: "tradestation"
                },
                swipeToClose: true
            });
            modal.onDidDismiss()
                .then((data) => {
                this.symbol = data.data;
                if (this.symbol) {
                    this.modalSymbolSelected = true;
                    if (this.filterType != 'All') {
                        this.symbolSearch = true;
                        this.filterType = 'All';
                    }
                    this.symbols = this.fullSymbols;
                    setTimeout(() => {
                        this.sharedData.symbolSearchId.next(this.symbol.id);
                        this.symbolDetailsOpened = "symbol-details-opened";
                        this.modalSymbolSelected = true;
                    }, 100);
                }
                this.searchModalOpened = false;
            });
            return yield modal.present();
        });
    }
    filterSymbols(event) {
        this.filterType = event === null || event === void 0 ? void 0 : event.detail.value;
        this.showLoader = true;
        this.onClose();
        this.sectorData = null;
        this.sharedData.symbolsFilterType.next(this.filterType);
        if (this.filterType == 'All' || this.filterType == 'DOWN_TEN' || this.filterType == 'TOP_TEN') {
            this.symbols = this.fullSymbols;
            this.showLoader = false;
        }
        else {
            this.market.filterdSymbols(this.filterType).subscribe(data => {
                this.symbols = data;
                this.showLoader = false;
            });
        }
    }
    presentWatchListsModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
            this.onClose();
            const modal = yield this.modalController.create({
                component: src_app_common_ui_components_watchlist_dragable_modal_watchlist_dragable_modal_component__WEBPACK_IMPORTED_MODULE_14__.WatchlistDragableModalComponent,
                cssClass: 'auto-height-modal ipad-full-width-modal',
                swipeToClose: true,
                // initialBreakpoint: 0.96,
                // breakpoints: [0, 0.96],
            });
            modal.onDidDismiss()
                .then((data) => {
                var _a, _b;
                this.getDefaultWL();
                if (data.data != null) {
                    this.watchlistData = data.data;
                    if ((_a = this.watchlistData) === null || _a === void 0 ? void 0 : _a.id) {
                        this.sectorData = null;
                        (_inma_models_watchlist__WEBPACK_IMPORTED_MODULE_10__.Watchlists.findByID((_b = this.watchlistData) === null || _b === void 0 ? void 0 : _b.id)).subscribe(watchlist => {
                            var _a;
                            this.watchlist = watchlist;
                            (_a = this.watchlist) === null || _a === void 0 ? void 0 : _a.symbols.subscribe((symbols) => {
                                this.symbols = symbols;
                            });
                        });
                    }
                }
            });
            return yield modal.present();
        });
    }
    onWatchListClose() {
        this.watchlistData = null;
        this.onClose();
        this.symbols = this.fullSymbols;
    }
    editWatchList() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: src_app_common_ui_components_view_edit_watclist_dragable_modal_view_edit_watclist_dragable_modal_component__WEBPACK_IMPORTED_MODULE_15__.ViewEditWatclistDragableModalComponent,
                cssClass: 'auto-height-modal ipad-full-width-modal',
                componentProps: {
                    watchlistData: this.watchlist
                },
                swipeToClose: true
                // initialBreakpoint: 0.96,
                // breakpoints: [0,0.96],
            });
            modal.onDidDismiss()
                .then((data) => {
                var _a, _b;
                this.getDefaultWL();
                if (data.data != null) {
                    this.watchlistData = data.data;
                    if ((_a = this.watchlistData) === null || _a === void 0 ? void 0 : _a.id) {
                        this.sectorData = null;
                        (_inma_models_watchlist__WEBPACK_IMPORTED_MODULE_10__.Watchlists.findByID((_b = this.watchlistData) === null || _b === void 0 ? void 0 : _b.id)).subscribe(watchlist => {
                            var _a;
                            this.watchlist = watchlist;
                            (_a = this.watchlist) === null || _a === void 0 ? void 0 : _a.symbols.subscribe((symbols) => {
                                this.symbols = symbols;
                            });
                        });
                    }
                }
            });
            return yield modal.present();
        });
    }
    openSymbolWatchlists(symbol) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
            //this.onClose();
            const modal = yield this.modalController.create({
                component: src_app_common_ui_components_watchlist_dragable_modal_watchlist_dragable_modal_component__WEBPACK_IMPORTED_MODULE_14__.WatchlistDragableModalComponent,
                cssClass: 'auto-height-modal ipad-full-width-modal',
                componentProps: {
                    action: 'addRemove',
                    watchListsIds: symbol.watchListsIds,
                    symbolData: this.symbol
                },
                swipeToClose: true
                // initialBreakpoint: 0.96,
                // breakpoints: [0, 0.96],
            });
            modal.onDidDismiss()
                .then((data) => {
                if (data.data != null) {
                    this.symbol.includedIntoWatchList = data.data.included;
                    this.symbol.watchListsIds = data.data.listIdsArr;
                }
            });
            return yield modal.present();
        });
    }
    getDefaultWL() {
        this.market.getDefaultWatchlist.subscribe((result) => {
            this.defaultWL = result;
        });
    }
};
TradestationPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_18__.ActivatedRoute },
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_6__.SharedDataService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.Platform },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonRouterOutlet },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_20__.TranslateService },
    { type: _events_service__WEBPACK_IMPORTED_MODULE_3__.EventsService }
];
TradestationPage.propDecorators = {
    buyClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_21__.HostBinding, args: ["class.buy",] }]
};
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([
    _inma_helpers_refreshable__WEBPACK_IMPORTED_MODULE_7__.onRefresh,
    (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Function),
    (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:paramtypes", []),
    (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:returntype", void 0)
], TradestationPage.prototype, "ionViewWillEnter", null);
TradestationPage = (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_21__.Component)({
        selector: "tadawul-tradestation",
        template: _tradestation_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_tradestation_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_18__.ActivatedRoute,
        src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_6__.SharedDataService,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.NavController,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.Platform,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.ModalController,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonRouterOutlet,
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_20__.TranslateService,
        _events_service__WEBPACK_IMPORTED_MODULE_3__.EventsService])
], TradestationPage);



/***/ }),

/***/ 93539:
/*!**********************************************************************!*\
  !*** ./src/app/pages/tradestation/tradestation.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = ":host ion-button {\n  white-space: pre-line;\n  font-size: 100%;\n  --background: var(--ion-color-tertiary);\n  --background-activated: var(--ion-color-tertiary-shade);\n  --color: var(--ion-color-primary-txt);\n  font-weight: normal;\n  width: 100%;\n  --border-radius: 0;\n  font-size: 80%;\n}\n:host ion-button ion-icon {\n  -webkit-margin-end: 4px;\n          margin-inline-end: 4px;\n  margin-top: -2px;\n}\n:host tadawul-loader {\n  position: relative;\n  z-index: 9;\n}\n:host tadawul-symbol-swiper {\n  transition: 0.25s;\n  bottom: calc(-100% - 500px);\n  opacity: 1;\n}\n:host tadawul-symbol-swiper.show {\n  bottom: calc(-64px - env(safe-area-inset-bottom));\n}\n.down {\n  color: #f5455a !important;\n  line-height: 16px;\n}\n.down ion-icon {\n  transform: scaleY(-1);\n}\n.up {\n  color: #2ebd85 !important;\n  line-height: 16px;\n}\n.up ion-icon {\n  transform: scaleY(1);\n}\nbody.dark :host .sub-header-dark {\n  background: #1e1e1e;\n}\n/***** Market Filter Header *****/\n.market-filters {\n  background: #e6eff0;\n  --ion-grid-padding: 0;\n  height: 45px;\n}\n.market-filters-segments {\n  flex-grow: 1 !important;\n  flex-basis: 0;\n  width: calc(100% - 45px);\n  -webkit-padding-start: 0;\n          padding-inline-start: 0;\n  -webkit-padding-end: 0;\n          padding-inline-end: 0;\n}\n.market-filters ion-segment {\n  background: transparent;\n  justify-content: space-between;\n  border-radius: 0;\n}\n.market-filters ion-segment::-webkit-scrollbar {\n  width: 0;\n  height: 0;\n  display: none;\n}\n.market-filters ion-segment ion-segment-button {\n  font-size: 11px;\n  border: 1px solid #99B9BC;\n  --border-radius: 15px;\n  color: #005157;\n  background: #cddcdd;\n  padding-right: 0;\n  padding-left: 0;\n  -webkit-margin-end: 8px;\n          margin-inline-end: 8px;\n  --indicator-color: transparent;\n  --indicator-box-shadow: none;\n  min-width: auto;\n}\n.market-filters ion-segment ion-segment-button.segment-button-checked {\n  color: white;\n  background: #65979a;\n  border-color: #65979a;\n}\n.market-filters ion-segment ion-segment-button:first-child {\n  -webkit-margin-start: 10px;\n          margin-inline-start: 10px;\n}\n.market-filters ion-segment ion-segment-button:last-child {\n  -webkit-margin-end: 10px;\n          margin-inline-end: 10px;\n}\n.market-filters ion-segment ion-segment-button::before {\n  opacity: 0;\n}\n.market-filters ion-segment ion-col {\n  padding: 0;\n}\n.market-filters .action-links {\n  --ion-grid-column-padding: 0;\n}\n.market-filters .search-link {\n  width: 45px;\n  height: 45px;\n  display: grid;\n  background: #e6eff0;\n  text-align: center;\n  padding: 12px;\n  color: #005157;\n  place-content: center;\n}\n.market-filters .search-link ion-icon {\n  height: 20px;\n  width: 20px;\n  color: #005157;\n}\n.market-filters .search-link {\n  -webkit-border-start: 1px solid #cddcdd;\n          border-inline-start: 1px solid #cddcdd;\n}\n.sector-watchlist-list {\n  --ion-grid-padding: 0;\n  background-color: #e6eff0;\n  height: 45px;\n  -webkit-padding-start: 13px;\n          padding-inline-start: 13px;\n  position: absolute;\n  width: 100%;\n  bottom: 0;\n  color: #005157;\n}\n.sector-watchlist-list ion-col {\n  padding: 0;\n}\n.sector-watchlist-list .close-link {\n  width: 45px;\n  height: 45px;\n  display: inline-block;\n  background: #e6eff0;\n  text-align: center;\n  padding: 12px;\n  color: currentColor;\n}\n.sector-watchlist-list .close-link ion-icon {\n  height: 20px;\n  width: 20px;\n  color: #005157;\n}\n.live-symbol-details-modal {\n  pointer-events: none !important;\n  --border-radius: 0 !important;\n  --background: #337479;\n}\n.live-symbol-details-modal::part(backdrop) {\n  pointer-events: none !important;\n  background: transparent;\n}\n.market-filters-segments {\n  display: flex !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRyYWRlc3RhdGlvbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBcUJFO0VBQ0UscUJBQUE7RUFDQSxlQUFBO0VBRUEsdUNBQUE7RUFDQSx1REFBQTtFQUVBLHFDQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FBdEJKO0FBd0JJO0VBQ0UsdUJBQUE7VUFBQSxzQkFBQTtFQUNBLGdCQUFBO0FBdEJOO0FBMEJFO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0FBeEJKO0FBMkJFO0VBQ0UsaUJBQUE7RUFDQSwyQkFBQTtFQUNBLFVBQUE7QUF6Qko7QUE0Qkk7RUFFRSxpREFBQTtBQTNCTjtBQWdDQTtFQUlFLHlCQUFBO0VBQ0EsaUJBQUE7QUFoQ0Y7QUE0QkU7RUFDRSxxQkFBQTtBQTFCSjtBQStCQTtFQUlFLHlCQUFBO0VBQ0EsaUJBQUE7QUEvQkY7QUEyQkU7RUFDRSxvQkFBQTtBQXpCSjtBQStCQTtFQUNFLG1CQUFBO0FBNUJGO0FBb0NBLGlDQUFBO0FBQ0E7RUFDRSxtQkFBQTtFQUNBLHFCQUFBO0VBQ0EsWUFBQTtBQWpDRjtBQW9DRTtFQUNFLHVCQUFBO0VBQ0EsYUFBQTtFQUNBLHdCQUFBO0VBQ0Esd0JBQUE7VUFBQSx1QkFBQTtFQUNBLHNCQUFBO1VBQUEscUJBQUE7QUFsQ0o7QUFxQ0U7RUFDRSx1QkFBQTtFQUNBLDhCQUFBO0VBRUEsZ0JBQUE7QUFwQ0o7QUFzQ0k7RUFDSSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGFBQUE7QUFwQ1I7QUF1Q0k7RUFDSSxlQUFBO0VBQ0EseUJBQUE7RUFDQSxxQkFBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLHVCQUFBO1VBQUEsc0JBQUE7RUFDQSw4QkFBQTtFQUNBLDRCQUFBO0VBQ0EsZUFBQTtBQXJDUjtBQTRDUTtFQUNFLFlBQUE7RUFDQSxtQkFBQTtFQUNBLHFCQUFBO0FBMUNWO0FBNkNRO0VBQ0UsMEJBQUE7VUFBQSx5QkFBQTtBQTNDVjtBQTZDUTtFQUNFLHdCQUFBO1VBQUEsdUJBQUE7QUEzQ1Y7QUE4Q1E7RUFDRSxVQUFBO0FBNUNWO0FBZ0RJO0VBQ0UsVUFBQTtBQTlDTjtBQW9ERTtFQUNFLDRCQUFBO0FBbERKO0FBcURFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxjQUFBO0VBQ0EscUJBQUE7QUFuREo7QUFvREk7RUFDRSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7QUFsRE47QUFzREU7RUFDRSx1Q0FBQTtVQUFBLHNDQUFBO0FBcERKO0FBZ0VBO0VBQ0UscUJBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSwyQkFBQTtVQUFBLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLGNBQUE7QUE3REY7QUE4REU7RUFDRSxVQUFBO0FBNURKO0FBK0RFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUE3REo7QUE4REk7RUFDRSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7QUE1RE47QUFpRUE7RUFDRSwrQkFBQTtFQUNBLDZCQUFBO0VBRUEscUJBQUE7QUEvREY7QUFpRUU7RUFDRSwrQkFBQTtFQUNBLHVCQUFBO0FBL0RKO0FBbUVBO0VBQ0Usd0JBQUE7QUFoRUYiLCJmaWxlIjoidHJhZGVzdGF0aW9uLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcbiAgLy8gaW9uLWhlYWRlciB7XG4gIC8vICAgcGFkZGluZy10b3A6IGVudihzYWZlLWFyZWEtaW5zZXQtdG9wKTtcbiAgLy8gICBiYWNrZ3JvdW5kOiAjMDA1MTU3O1xuXG4gIC8vICAgJi5hbmRyb2lkLWhlYWRlciB7XG4gIC8vICAgICBwYWRkaW5nLXRvcDogMjVweDtcbiAgLy8gICB9XG4gIC8vIH1cbiAgLy8gaW9uLXRvb2xiYXIge1xuICAgIFxuICAvLyAgIC0tY29sb3I6IHdoaXRlO1xuICAvLyAgIC0tYm9yZGVyLXdpZHRoOiAwO1xuICAvLyAgIC8vIGhlaWdodDogMzJweDtcbiAgLy8gICAtLW1pbi1oZWlnaHQ6IDI0cHg7XG5cbiAgLy8gICBpb24tdGl0bGUge1xuICAvLyAgICAgZm9udC1zaXplOiAxMnB4O1xuICAvLyAgIH1cbiAgLy8gfVxuICBcbiAgaW9uLWJ1dHRvbiB7XG4gICAgd2hpdGUtc3BhY2U6IHByZS1saW5lO1xuICAgIGZvbnQtc2l6ZTogMTAwJTtcbiAgICAvLyAtLWJhY2tncm91bmQ6ICNlNmVmZjA7XG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItdGVydGlhcnkpO1xuICAgIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6IHZhcigtLWlvbi1jb2xvci10ZXJ0aWFyeS1zaGFkZSk7XG4gICAgLy8gLS1jb2xvcjogIzAwNTE1NztcbiAgICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS10eHQpO1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgLS1ib3JkZXItcmFkaXVzOiAwO1xuICAgIGZvbnQtc2l6ZTogODAlO1xuXG4gICAgaW9uLWljb24ge1xuICAgICAgbWFyZ2luLWlubGluZS1lbmQ6IDRweDtcbiAgICAgIG1hcmdpbi10b3A6IC0ycHg7XG4gICAgfVxuICB9XG5cbiAgdGFkYXd1bC1sb2FkZXIge1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICB6LWluZGV4OiA5O1xuICB9XG5cbiAgdGFkYXd1bC1zeW1ib2wtc3dpcGVyIHtcbiAgICB0cmFuc2l0aW9uOiAwLjI1cztcbiAgICBib3R0b206ICBjYWxjKC0xMDAlIC0gNTAwcHgpO1xuICAgIG9wYWNpdHk6IDE7XG4gICAgLy9kaXNwbGF5OiBub25lO1xuXG4gICAgJi5zaG93IHtcbiAgICAgLy8gZGlzcGxheTogYmxvY2s7XG4gICAgICBib3R0b206IGNhbGMoLTY0cHggLSBlbnYoc2FmZS1hcmVhLWluc2V0LWJvdHRvbSkpO1xuICAgIH1cbiAgfVxufVxuXG4uZG93biB7XG4gIGlvbi1pY29uIHtcbiAgICB0cmFuc2Zvcm06IHNjYWxlWSgtMSk7XG4gIH1cbiAgY29sb3I6ICNmNTQ1NWEgIWltcG9ydGFudDtcbiAgbGluZS1oZWlnaHQ6IDE2cHg7XG59XG4udXAge1xuICBpb24taWNvbiB7XG4gICAgdHJhbnNmb3JtOiBzY2FsZVkoMSk7XG4gIH1cbiAgY29sb3I6ICMyZWJkODUgIWltcG9ydGFudDtcbiAgbGluZS1oZWlnaHQ6IDE2cHg7XG59XG5cbmJvZHkuZGFyayA6aG9zdCAuc3ViLWhlYWRlci1kYXJre1xuICBiYWNrZ3JvdW5kOiAjMWUxZTFlO1xufVxuXG5cblxuXG5cblxuLyoqKioqIE1hcmtldCBGaWx0ZXIgSGVhZGVyICoqKioqL1xuLm1hcmtldC1maWx0ZXJzIHtcbiAgYmFja2dyb3VuZDogI2U2ZWZmMDtcbiAgLS1pb24tZ3JpZC1wYWRkaW5nOiAwO1xuICBoZWlnaHQ6IDQ1cHg7XG4gLy8gb3ZlcmZsb3c6IGF1dG87XG5cbiAgJi1zZWdtZW50cyB7XG4gICAgZmxleC1ncm93OiAxIWltcG9ydGFudDtcbiAgICBmbGV4LWJhc2lzOiAwO1xuICAgIHdpZHRoOiBjYWxjKDEwMCUgLSA0NXB4KTtcbiAgICBwYWRkaW5nLWlubGluZS1zdGFydDogMDtcbiAgICBwYWRkaW5nLWlubGluZS1lbmQ6IDA7XG4gIH1cblxuICBpb24tc2VnbWVudCB7XG4gICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgIC8vb3ZlcmZsb3c6IGF1dG87XG4gICAgYm9yZGVyLXJhZGl1czogMDtcblxuICAgICY6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcbiAgICAgICAgd2lkdGg6IDA7XG4gICAgICAgIGhlaWdodDogMDtcbiAgICAgICAgZGlzcGxheTogbm9uZTtcbiAgICB9XG5cbiAgICBpb24tc2VnbWVudC1idXR0b24ge1xuICAgICAgICBmb250LXNpemU6IDExcHg7XG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICM5OUI5QkM7XG4gICAgICAgIC0tYm9yZGVyLXJhZGl1czogMTVweDtcbiAgICAgICAgY29sb3I6ICMwMDUxNTc7XG4gICAgICAgIGJhY2tncm91bmQ6ICNjZGRjZGQ7XG4gICAgICAgIHBhZGRpbmctcmlnaHQ6IDA7XG4gICAgICAgIHBhZGRpbmctbGVmdDogMDtcbiAgICAgICAgbWFyZ2luLWlubGluZS1lbmQ6IDhweDtcbiAgICAgICAgLS1pbmRpY2F0b3ItY29sb3I6IHRyYW5zcGFyZW50O1xuICAgICAgICAtLWluZGljYXRvci1ib3gtc2hhZG93OiBub25lO1xuICAgICAgICBtaW4td2lkdGg6IGF1dG87XG5cbiAgICAgICAgLy8gJi5kZWZhdWx0LXdhdGNobGlzdCB7XG4gICAgICAgIC8vICAgYmFja2dyb3VuZC1jb2xvcjogI0ZGQ0MwMDtcbiAgICAgICAgLy8gICBjb2xvcjogIzFlMWUxZTtcbiAgICAgICAgLy8gfVxuXG4gICAgICAgICYuc2VnbWVudC1idXR0b24tY2hlY2tlZCB7XG4gICAgICAgICAgY29sb3I6IHdoaXRlO1xuICAgICAgICAgIGJhY2tncm91bmQ6ICM2NTk3OWE7XG4gICAgICAgICAgYm9yZGVyLWNvbG9yOiAjNjU5NzlhO1xuICAgICAgICB9XG5cbiAgICAgICAgJjpmaXJzdC1jaGlsZCB7XG4gICAgICAgICAgbWFyZ2luLWlubGluZS1zdGFydDogMTBweDtcbiAgICAgICAgfVxuICAgICAgICAmOmxhc3QtY2hpbGQge1xuICAgICAgICAgIG1hcmdpbi1pbmxpbmUtZW5kOiAxMHB4O1xuICAgICAgICB9XG5cbiAgICAgICAgJjo6YmVmb3JlIHtcbiAgICAgICAgICBvcGFjaXR5OiAwO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgaW9uLWNvbCB7XG4gICAgICBwYWRkaW5nOiAwO1xuICAgIH1cbiAgfVxuXG4gIFxuXG4gIC5hY3Rpb24tbGlua3Mge1xuICAgIC0taW9uLWdyaWQtY29sdW1uLXBhZGRpbmc6IDA7XG4gIH1cblxuICAuc2VhcmNoLWxpbmsge1xuICAgIHdpZHRoOiA0NXB4O1xuICAgIGhlaWdodDogNDVweDtcbiAgICBkaXNwbGF5OiBncmlkO1xuICAgIGJhY2tncm91bmQ6ICNlNmVmZjA7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIHBhZGRpbmc6IDEycHg7XG4gICAgY29sb3I6ICMwMDUxNTc7XG4gICAgcGxhY2UtY29udGVudDogY2VudGVyO1xuICAgIGlvbi1pY29uIHtcbiAgICAgIGhlaWdodDogMjBweDtcbiAgICAgIHdpZHRoOiAyMHB4O1xuICAgICAgY29sb3I6ICMwMDUxNTc7XG4gICAgfVxuICB9XG5cbiAgLnNlYXJjaC1saW5rIHtcbiAgICBib3JkZXItaW5saW5lLXN0YXJ0OiAxcHggc29saWQgI2NkZGNkZDtcbiAgfVxufVxuXG4vLyAuc2VjdG9yLWRhdGF7XG4vLyAgIGJhY2tncm91bmQtY29sb3I6ICNlNmVmZjA7XG4vLyAgIGhlaWdodDogNDVweDtcbi8vICAgcG9zaXRpb246IGFic29sdXRlO1xuLy8gICB3aWR0aDogMTAwJTtcbi8vICAgYm90dG9tOiAwO1xuLy8gfVxuXG4uc2VjdG9yLXdhdGNobGlzdC1saXN0IHtcbiAgLS1pb24tZ3JpZC1wYWRkaW5nOiAwO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTZlZmYwO1xuICBoZWlnaHQ6IDQ1cHg7XG4gIHBhZGRpbmctaW5saW5lLXN0YXJ0OiAxM3B4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHdpZHRoOiAxMDAlO1xuICBib3R0b206IDA7XG4gIGNvbG9yOiAjMDA1MTU3O1xuICBpb24tY29sIHtcbiAgICBwYWRkaW5nOiAwO1xuICB9XG5cbiAgLmNsb3NlLWxpbmsge1xuICAgIHdpZHRoOiA0NXB4O1xuICAgIGhlaWdodDogNDVweDtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgYmFja2dyb3VuZDogI2U2ZWZmMDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgcGFkZGluZzogMTJweDtcbiAgICBjb2xvcjogY3VycmVudENvbG9yO1xuICAgIGlvbi1pY29uIHtcbiAgICAgIGhlaWdodDogMjBweDtcbiAgICAgIHdpZHRoOiAyMHB4O1xuICAgICAgY29sb3I6ICMwMDUxNTc7XG4gICAgfVxuICB9XG59XG5cbi5saXZlLXN5bWJvbC1kZXRhaWxzLW1vZGFsIHtcbiAgcG9pbnRlci1ldmVudHM6IG5vbmUgIWltcG9ydGFudDtcbiAgLS1ib3JkZXItcmFkaXVzOiAwICFpbXBvcnRhbnQ7XG4gIC8vIHBhZGRpbmctYm90dG9tOiBlbnYoc2FmZS1hcmVhLWluc2V0LWJvdHRvbSk7XG4gIC0tYmFja2dyb3VuZDogIzMzNzQ3OTtcblxuICAmOjpwYXJ0KGJhY2tkcm9wKSB7XG4gICAgcG9pbnRlci1ldmVudHM6IG5vbmUgIWltcG9ydGFudDtcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgfVxufVxuXG4ubWFya2V0LWZpbHRlcnMtc2VnbWVudHN7XG4gIGRpc3BsYXk6IGZsZXggIWltcG9ydGFudDtcbn0iXX0= */";

/***/ }),

/***/ 63285:
/*!**********************************************************************!*\
  !*** ./src/app/pages/tradestation/tradestation.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<ion-header [ngClass]=\"headerClass\">\n  <tadawul-market-sub-header class=\"sub-header-dark\" page='tradestation' [market]='market' [marketName]='marketName'\n    (marketsClick)=\"presentMarketsModal()\" (sectorClick)=\"presentSectorsModal()\"\n    (watchlistClick)=\"presentWatchListsModal()\"></tadawul-market-sub-header>\n\n  <ion-grid class=\"market-filters\">\n    <ion-row>\n      <!-- <tadawul-loader *ngIf=\"showLoader\"></tadawul-loader> -->\n      <ion-col class=\"market-filters-segments\">\n        <ion-segment scrollable=\"true\" [value]=\"filterType\" (ionChange)=\"filterSymbols($event)\">\n          <ion-segment-button value=\"All\">\n            <ion-label>{{'tradestion.All' | translate}}</ion-label>\n          </ion-segment-button>\n          <ion-segment-button value=\"USER_SHARES\">\n            <ion-label>{{'tradestion.myShares' | translate}}</ion-label>\n          </ion-segment-button>\n          <ion-segment-button *ngIf=\"defaultWL\" value=\"DEFAULT_WL\">\n            <ion-label>{{defaultWL}}</ion-label>\n          </ion-segment-button>\n          <ion-segment-button value=\"TOP_TEN\">\n            <ion-label>{{'tradestion.topTen' | translate}}</ion-label>\n          </ion-segment-button>\n          <ion-segment-button value=\"DOWN_TEN\">\n            <ion-label>{{'tradestion.downTen' | translate}}</ion-label>\n          </ion-segment-button>\n        </ion-segment>\n      </ion-col>\n\n      <ion-col size=\"auto\" class=\"action-links\" (click)=\"presentSymbolsSearchModal()\">\n        <div class=\"search-link\">\n          <span class=\"icon icon-search\"></span>\n        </div>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <ion-grid *ngIf=\"sectorData || watchlistData\" class=\"sector-watchlist-list\">\n    <ion-row *ngIf=\"sectorData\" class=\"sector-data ion-align-items-center\">\n      <ion-col>\n        <div style=\"color:#005157;font-weight:bold;font-size:11px;\">{{sectorData?.name}}</div>\n        <div [ngClass]=\"sectorData?.changePercent < 0 ? 'down' : 'up' \"><span>\n            <ion-icon style=\"vertical-align: middle;\" name=\"caret-up-outline\"></ion-icon>\n          </span><span style=\"padding-inline-start: 3px;font-size: 12px;font-weight: bold;\">{{sectorData?.index}}</span>\n          <span style=\"font-size: 10px;\">&nbsp;({{sector?.changePercent | commafy:'number':2}} %)\n            {{sectorData?.change}}</span></div>\n      </ion-col>\n\n      <ion-col size=\"auto\" class=\"action-links\" (click)=\"onSectorClose()\">\n        <div class=\"close-link\">\n          <span class=\"icon icon-close\"></span>\n        </div>\n      </ion-col>\n    </ion-row>\n\n    <ion-row *ngIf=\"watchlistData\" class=\"sector-data ion-align-items-center\">\n      <ion-col>\n        <div style=\"color:#005157;font-weight:bold;font-size:15px;\">{{watchlistData?.name}}</div>\n      </ion-col>\n\n      <ion-col size=\"auto\" class=\"action-links\">\n        <div class=\"close-link\" (click)=\"editWatchList()\">\n          <span class=\"icon icon-edit\" style=\"font-size: 16px!important;\"></span>\n        </div>\n        <div class=\"close-link\" (click)=\"onWatchListClose()\">\n          <span class=\"icon icon-close\"></span>\n        </div>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\n</ion-header>\n\n<tadawul-skeleton-loader [hidden]=\"!showLoader\" *ngFor=\"let item of [].constructor(10)\"\n[type]=\"SkeletonType.SYMBOL_CARD\">\n</tadawul-skeleton-loader>\n  <tadawul-symbols *ngIf=\"symbols && !showLoader\"  [allSymbols]=\"(symbols)\" [filterType]=\"filterType\" [symbolListClass]=\"symbolDetailsOpened\"\n    (onSymbolChange)=\"onSymbolChange($event)\" [selectedSymbol]=\"symbol\" style=\"width: 100%;\">\n  </tadawul-symbols>\n\n  <ion-modal (ionModalDidDismiss)=\"symbolDetailsDismissed()\" \n  (ionModalWillDismiss)=\"symbolDetailsWillDismissed()\"\n             [isOpen]=\"modalSymbolSelected\" [showBackdrop]=\"false\"\n             [handle]=\"false\"\n             class=\"live-symbol-details-modal auto-height-modal ipad-full-width-modal\">\n    <ng-template>\n      <tadawul-symbol-swiper class=\"market-names-dragable-modal\" [symbol]=\"symbol\" [ngClass]=\"{show: !!symbol}\"\n      (close)=\"onClose()\" (openSymbolWatchlists)=\"openSymbolWatchlists(symbol)\"></tadawul-symbol-swiper>\n    </ng-template>\n  </ion-modal>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_tradestation_tradestation_module_ts.js.map