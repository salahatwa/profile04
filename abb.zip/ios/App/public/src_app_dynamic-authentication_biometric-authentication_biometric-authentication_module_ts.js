"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_dynamic-authentication_biometric-authentication_biometric-authentication_module_ts"],{

/***/ 9108:
/*!************************************************************************************************************!*\
  !*** ./src/app/dynamic-authentication/biometric-authentication/biometric-authentication-routing.module.ts ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BiometricAuthenticationPageRoutingModule": () => (/* binding */ BiometricAuthenticationPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _biometric_authentication_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./biometric-authentication.page */ 13054);




const routes = [
    {
        path: '',
        component: _biometric_authentication_page__WEBPACK_IMPORTED_MODULE_0__.BiometricAuthenticationPage
    }
];
let BiometricAuthenticationPageRoutingModule = class BiometricAuthenticationPageRoutingModule {
};
BiometricAuthenticationPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], BiometricAuthenticationPageRoutingModule);



/***/ }),

/***/ 96393:
/*!****************************************************************************************************!*\
  !*** ./src/app/dynamic-authentication/biometric-authentication/biometric-authentication.module.ts ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BiometricAuthenticationPageModule": () => (/* binding */ BiometricAuthenticationPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _biometric_authentication_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./biometric-authentication-routing.module */ 9108);
/* harmony import */ var _biometric_authentication_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./biometric-authentication.page */ 13054);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ 87514);








let BiometricAuthenticationPageModule = class BiometricAuthenticationPageModule {
};
BiometricAuthenticationPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _biometric_authentication_routing_module__WEBPACK_IMPORTED_MODULE_0__.BiometricAuthenticationPageRoutingModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__.TranslateModule.forChild()
        ],
        declarations: [_biometric_authentication_page__WEBPACK_IMPORTED_MODULE_1__.BiometricAuthenticationPage]
    })
], BiometricAuthenticationPageModule);



/***/ }),

/***/ 13054:
/*!**************************************************************************************************!*\
  !*** ./src/app/dynamic-authentication/biometric-authentication/biometric-authentication.page.ts ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BiometricAuthenticationPage": () => (/* binding */ BiometricAuthenticationPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _biometric_authentication_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./biometric-authentication.page.html?ngResource */ 7953);
/* harmony import */ var _biometric_authentication_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./biometric-authentication.page.scss?ngResource */ 42726);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/helpers/biometric */ 16406);
/* harmony import */ var _inma_models_authentication_authentication_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/models/authentication/authentication.model */ 83443);
/* harmony import */ var _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/models/users/authentication */ 93143);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _dynamic_authentication_translations__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../dynamic-authentication.translations */ 34229);
/* harmony import */ var _inma_helpers_translations__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @inma/helpers/translations */ 69353);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 86942);
var BiometricAuthenticationPage_1;











let BiometricAuthenticationPage = BiometricAuthenticationPage_1 = class BiometricAuthenticationPage {
    constructor(navCtrl, navParams, modalCtrl) {
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.modalCtrl = modalCtrl;
        this.t = _dynamic_authentication_translations__WEBPACK_IMPORTED_MODULE_5__.DynamicAuthenticationTranslations;
        // this.action = navParams.get('action')
        // this.authenticationGroup = navParams.get('group');
        // this.translate.get("authentication." + Biometric.type + this.action).subscribe(value => {
        // });
    }
    get biometricAction() {
        return _inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_2__.Biometric.type + this.action;
    }
    static isStored() {
        return _inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_2__.Biometric.isStored().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)(result => {
            return !!result;
        }));
    }
    ngOnInit() {
        this.opened = true;
        if (!_inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_2__.Biometric.type)
            this.closeBiometricAuthentication();
        _inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_2__.Biometric.verify("Verify" + (this.action == "Authenticate" ? this.action : "Other")).subscribe(result => {
            if (result) {
                if (result == "NOT_STORED" || result == "NOT_VERIFIED" || result == "CANCELLED" || (result === null || result === void 0 ? void 0 : result.startsWith('Error'))) {
                    this.closeBiometricAuthentication(false);
                }
                else {
                    var storedUsername = result.split('#:#')[0];
                    var storedKey = result.split('#:#')[1];
                    this.authenticateBiometric(storedUsername, storedKey);
                }
            }
            else {
                if (this.opened) {
                    _inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_2__.Biometric["delete"]().subscribe();
                    this.closeBiometricAuthentication(false);
                }
            }
        });
    }
    get action() {
        return BiometricAuthenticationPage_1.action;
    }
    get authenticationGroup() {
        return BiometricAuthenticationPage_1.authenticationGroup;
    }
    authenticateBiometric(storedUsername, storedKey) {
        console.log("Login key " + storedKey);
        _inma_models_authentication_authentication_model__WEBPACK_IMPORTED_MODULE_3__.Authentication.encrypt(storedKey).subscribe(encryptedKey => {
            this.authenticationGroup.methods[0].value = encryptedKey;
            console.log("Login Key encrypted" + encryptedKey);
            _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_4__.Authentication2.authenticateSourceAction(this.authenticationGroup.groupName, this.authenticationGroup.methods)
                .subscribe(response => {
                if (response) {
                    _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_4__.Authentication2.dynamicAuthenticationSubject.next(response);
                }
                else {
                    _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_4__.Authentication2.dynamicAuthenticationSubject.error(response);
                }
                _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_4__.Authentication2.dynamicAuthenticationSubject.complete();
                this.closeBiometricAuthentication(true);
            });
        });
    }
    closeBiometricAuthentication(isSuccess = null) {
        setTimeout(() => {
            this.opened = false;
            this.modalCtrl.dismiss(isSuccess, null, 'biometric-authentication-page');
        }, 500);
    }
};
BiometricAuthenticationPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavParams },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController }
];
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_inma_helpers_translations__WEBPACK_IMPORTED_MODULE_6__.Translations)(),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", Object)
], BiometricAuthenticationPage.prototype, "t", void 0);
BiometricAuthenticationPage = BiometricAuthenticationPage_1 = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'tadawul-biometric-authentication',
        template: _biometric_authentication_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_biometric_authentication_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavParams, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController])
], BiometricAuthenticationPage);



/***/ }),

/***/ 42726:
/*!***************************************************************************************************************!*\
  !*** ./src/app/dynamic-authentication/biometric-authentication/biometric-authentication.page.scss?ngResource ***!
  \***************************************************************************************************************/
/***/ ((module) => {

module.exports = ".fingerprintIcon {\n  font-size: 2rem;\n  position: absolute;\n  top: -360px;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  margin: auto;\n  /* width: 90px; */\n  height: 200px;\n  color: #005157;\n  text-align: center;\n}\n.fingerprintIcon img {\n  width: 90px;\n  height: 90px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJpb21ldHJpYy1hdXRoZW50aWNhdGlvbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsYUFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQUNKO0FBQ0k7RUFDSSxXQUFBO0VBQ0EsWUFBQTtBQUNSIiwiZmlsZSI6ImJpb21ldHJpYy1hdXRoZW50aWNhdGlvbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZmluZ2VycHJpbnRJY29uIHtcbiAgICBmb250LXNpemU6IDJyZW07XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHRvcDogLTM2MHB4O1xuICAgIGJvdHRvbTogMDtcbiAgICBsZWZ0OiAwO1xuICAgIHJpZ2h0OiAwO1xuICAgIG1hcmdpbjogYXV0bztcbiAgICAvKiB3aWR0aDogOTBweDsgKi9cbiAgICBoZWlnaHQ6IDIwMHB4O1xuICAgIGNvbG9yOiAjMDA1MTU3O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcblxuICAgIGltZyB7XG4gICAgICAgIHdpZHRoOiA5MHB4O1xuICAgICAgICBoZWlnaHQ6IDkwcHg7XG4gICAgfVxuXG59Il19 */";

/***/ }),

/***/ 7953:
/*!***************************************************************************************************************!*\
  !*** ./src/app/dynamic-authentication/biometric-authentication/biometric-authentication.page.html?ngResource ***!
  \***************************************************************************************************************/
/***/ ((module) => {

module.exports = "<!-- <ion-header>\n  <ion-toolbar>\n    <ion-title>BiometricAuthentication</ion-title>\n  </ion-toolbar>\n</ion-header> -->\n\n<ion-content>\n\n  <div class=\"fingerprintIcon\">\n\n    <img src=\"assets/icon/fingerprint.svg\" class=\"biometricIcon\">\n    <div> {{ translate.instant('dynamicAuthenticate.'+biometricAction) }}</div>\n  </div>\n\n\n  <ion-footer style=\"padding-top: calc(var(--ion-safe-area-top, 0))\">\n    <button ion-button (click)=\"closeBiometricAuthentication()\" style=\"padding-inline-start: 16px;\">\n     {{'app.CANCEL' | translate}}\n    </button>\n  </ion-footer>\n\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_dynamic-authentication_biometric-authentication_biometric-authentication_module_ts.js.map