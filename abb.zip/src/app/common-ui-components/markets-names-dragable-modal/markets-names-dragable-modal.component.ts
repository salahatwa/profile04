import { EventsService } from './../../events.service';
import { TranslateService } from '@ngx-translate/core';
import { Component, Input, OnInit } from '@angular/core';
import { resetCache } from '@inma/helpers/cached';
import { Translations } from '@inma/helpers/translations';
import { Market, MarketNamesTranslations, MarketsNames } from '@inma/models/market';
import { ModalController } from '@ionic/angular';
import { SharedDataService } from 'src/app/providers/shared-data.service';

@Component({
  selector: 'tadawul-markets-names-dragable-modal',
  templateUrl: './markets-names-dragable-modal.component.html',
  styleUrls: ['./markets-names-dragable-modal.component.scss'],
})
export class MarketsNamesDragableModalComponent implements OnInit {

  MarketsNames = MarketsNames;
  @Input() marketName: any;

  constructor(private modalControl: ModalController,public translate: TranslateService,public sharedData: SharedDataService, private event: EventsService) { }

  ngOnInit() { }

  closeModal(market?: any) {
   if(market){
    this.event.publish('MARKET_CHANGED', market);
    resetCache(Market, 'info');
    Market.changeMarkets(market);
    this.sharedData.marketName.next(market);
   }
    const data = market;
    this.modalControl.dismiss(data);
   
  }

}
