export enum MutualFundType {
    SUBSCRIPTION = 1,
    REDEMPTION = 2
}