import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NavController } from '@ionic/angular';
import { kycTranslations } from '../../../kyc/kyctranslation';
import { Translations } from '@inma/helpers/translations';
import { Kyc } from '@inma/models/kyc/';
import { resetCache } from '@inma/helpers/cached';

@Component({
  selector: 'tadawul-investment-info-form',
  templateUrl: './investment-info-form.component.html',
  styleUrls: ['./investment-info-form.component.scss'],
})
export class InvestmentInfoFormComponent implements OnInit {
  form: FormGroup;
  t = kycTranslations;
  public showLoader = false;
  formData = {};
  details = {
    investmentInfo: {
      commodities: "",
      contractDiffAndOpt: "",
      deposits: "",
      foreignExchange: "",
      investmentFunds: "",
      realEstate: "",
      sharesAmount: "",
      debtInstruments: "",
      // total: "",
      tradeFinance: "",
    }
  };
  total;

  constructor(private formBuilder: FormBuilder, private navCtrl: NavController) { 
    this.buildForm();
  }

  ngOnInit() {
    Kyc.details.subscribe( details => {
      console.log(details);
      this.form.controls['shares'].setValue(details.investmentInfo.sharesAmount);
      this.form.controls['sukuk'].setValue(details.investmentInfo.debtInstruments);
      this.form.controls['foreignCurrency'].setValue(details.investmentInfo.foreignExchange);
      this.form.controls['deposite'].setValue(details.investmentInfo.deposits);
      this.form.controls['tradeFinance'].setValue(details.investmentInfo.tradeFinance);
      this.form.controls['investmentFunds'].setValue(details.investmentInfo.investmentFunds);
      this.form.controls['commodities'].setValue(details.investmentInfo.commodities);
      this.form.controls['realEstates'].setValue(details.investmentInfo.realEstate);
      this.form.controls['contractsOptions'].setValue(details.investmentInfo.contractDiffAndOpt);
      // this.form.controls['total'].setValue(details.investmentInfo.total);

      // this.form.controls['shares'].patchValue(details.investmentInfo.sharesAmount);
      // this.form.controls['sukuk'].patchValue(details.investmentInfo.debtInstruments);
      // this.form.controls['foreignCurrency'].patchValue(details.investmentInfo.foreignExchange);
      // this.form.controls['deposite'].patchValue(details.investmentInfo.deposits);
      // this.form.controls['tradeFinance'].patchValue(details.investmentInfo.tradeFinance);
      // this.form.controls['investmentFunds'].patchValue(details.investmentInfo.investmentFunds);
      // this.form.controls['commodities'].patchValue(details.investmentInfo.commodities);
      // this.form.controls['realEstates'].patchValue(details.investmentInfo.realEstate);
      // this.form.controls['contractsOptions'].patchValue(details.investmentInfo.contractDiffAndOpt);
      // this.form.controls['total'].patchValue(details.investmentInfo.total);

      this.details = details;
      this.details['contact'] = null;
      this.calcTotal();
    });
  }

  buildForm() {
    this.form = this.formBuilder.group({
      shares: [
        '', Validators.compose([
          Validators.required
        ])
      ],
      sukuk: [
        '', Validators.compose([
          Validators.required
        ])
      ],
      foreignCurrency: [
        '', Validators.compose([
          Validators.required
        ])
      ],
      deposite: [
        '', Validators.compose([
          Validators.required
        ])
      ],
      tradeFinance: [
        '', Validators.compose([
          Validators.required
        ])
      ],
      investmentFunds: [
        '', Validators.compose([
          Validators.required
        ])
      ],
      commodities: [
        '', Validators.compose([
          Validators.required
        ])
      ],
      realEstates: [
        '', Validators.compose([
          Validators.required
        ])
      ],
      contractsOptions: [
        '', Validators.compose([
          Validators.required
        ])
      ],
      total: [''],
    });
  }

  calcTotal() {
    let sharesVal = parseInt(this.form.controls['shares'].value) ? parseInt(this.form.controls['shares'].value) : 0;
    let sukukVal = parseInt(this.form.controls['sukuk'].value) ? parseInt(this.form.controls['sukuk'].value) : 0;
    let foreignCurrencyVal = parseInt(this.form.controls['foreignCurrency'].value) ? parseInt(this.form.controls['foreignCurrency'].value) : 0;
    let depositeVal = parseInt(this.form.controls['deposite'].value) ? parseInt(this.form.controls['deposite'].value) : 0;
    let tradeFinanceVal = parseInt(this.form.controls['tradeFinance'].value) ? parseInt(this.form.controls['tradeFinance'].value) : 0;
    let investmentFundsVal = parseInt(this.form.controls['investmentFunds'].value) ? parseInt(this.form.controls['investmentFunds'].value) : 0;
    let commoditiesVal = parseInt(this.form.controls['commodities'].value) ? parseInt(this.form.controls['commodities'].value) : 0;
    let realEstatesVal = parseInt(this.form.controls['realEstates'].value) ? parseInt(this.form.controls['realEstates'].value) : 0;
    let contractsOptionsVal = parseInt(this.form.controls['contractsOptions'].value) ? parseInt(this.form.controls['contractsOptions'].value) : 0;

    this.form.controls['total'].setValue(String(sharesVal+ sukukVal + foreignCurrencyVal + depositeVal + tradeFinanceVal + investmentFundsVal + commoditiesVal + realEstatesVal + contractsOptionsVal));
    this.total = String(sharesVal+ sukukVal + foreignCurrencyVal + depositeVal + tradeFinanceVal + investmentFundsVal + commoditiesVal + realEstatesVal + contractsOptionsVal);
  }

  saveSettings(form) {
    console.log(form.valid);
    console.log(this.details);
    if (form.invalid) {
      return;
    }
    //Kyc.updateDetails(this.details);
    this.showLoader = true;
    Kyc.updateDetails(this.details).subscribe(() => {
      resetCache(Kyc, 'details');
      this.showLoader = false;
      this.navCtrl.navigateRoot('/kyc/home', { animated: true });
    },
    err => {
      console.log('HTTP Error', err);
      this.showLoader = false;
    });
  }

}
