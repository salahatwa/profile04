import { PortfoliosMockedWebService } from 'src/environments/mocks/portfolios.mocks';

export class AppTranslations {
    SELECT = ['اختر', 'Select'];
    OK = ["اختيار", "Ok"];
    CANCEL = ["إلغاء", "Cancel"];
    CONFIRM = ["تأكيد", "Confirm"];
    DONE = ["تم", "Done"];
    SLASH = ["\\", "/"];
    PLEASE_CHOOSE = ["الرجاء اختيار", "Please choose a valid"];
    PLEASE_ENTER = ["الرجاء إدخال", "Please enter a"];  
    CORRECT_PATTERN = ["بالنمط الصحيح", "in correct pattern"];
    alertOK = ["موافق","Ok"];
    alertHeader = ["تنبيه","Alert"];
    REQUIREDFIELDS = ["الرجاء ادخال الحقول المطلوبة","Please fill Required Fields"];


    SHOULD_BE_LESS = ["يجب أن يكون أقل من أو يساوي", "should be less than or equal"];
    SHOULD_BE_GREATER = ["يجب أن يكون أكبر من أو يساوي", "should be greater than or equal"];
    SHOULD_BE_EQUALS = ["يجب أن يساوي", "should equals"];
    CURRENCY= ["ر.س", "SAR"];
    SAR= ["ر.س", "SAR"];
    units= ["وحدات", "units"];
    B= ["شراء", "Buy"];
    S= ["بيع", "Sell"];

    BUYING_POWER_VALIDATION = ["قيمة أمر الشراء أكبر من القدرة الشرائية", "Order value is more than buying power"];
    OWNED_QUANTITY_VALIDATION = ["الكمية المباعة أكبر من الكمية المتاحة", "Order quantity is more than owned quanity"];
   
    //modal translation
    SECTORS_INDEX_PAGE_TITLE = ['مؤشر القطاعات', 'Sectors']
}

