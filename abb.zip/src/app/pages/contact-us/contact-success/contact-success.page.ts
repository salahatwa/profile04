import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { Translations } from '@inma/helpers/translations';
import { ContactSuccessTranslations } from './contact-success.translations';

@Component({
  selector: 'tadawul-contact-success',
  templateUrl: './contact-success.page.html',
  styleUrls: ['./contact-success.page.scss'],
})
export class ContactSuccessPage implements OnInit {

  constructor(private modalControl: ModalController) { }

  ngOnInit() {
  }

  closeModal() {
    this.modalControl.dismiss();
  }

}
