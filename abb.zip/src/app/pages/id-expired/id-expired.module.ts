import { TranslateModule } from '@ngx-translate/core';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { IdExpiredPageRoutingModule } from './id-expired-routing.module';

import { IdExpiredPage } from './id-expired.page';
import { TadawulCommonUiModule } from 'src/app/common-ui-components/tadawul-common-ui.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    IdExpiredPageRoutingModule,
    TadawulCommonUiModule,
    TranslateModule.forChild()
  ],
  declarations: [IdExpiredPage]
})
export class IdExpiredPageModule { }
