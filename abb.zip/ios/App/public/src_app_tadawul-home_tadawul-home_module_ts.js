"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tadawul-home_tadawul-home_module_ts"],{

/***/ 20231:
/*!*************************************************************!*\
  !*** ./src/app/tadawul-home/tadawul-home-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TadawulHomePageRoutingModule": () => (/* binding */ TadawulHomePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _tadawul_home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tadawul-home.page */ 62432);




const routes = [
    {
        path: '',
        component: _tadawul_home_page__WEBPACK_IMPORTED_MODULE_0__.TadawulHomePage
    }
];
let TadawulHomePageRoutingModule = class TadawulHomePageRoutingModule {
};
TadawulHomePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], TadawulHomePageRoutingModule);



/***/ }),

/***/ 61805:
/*!*****************************************************!*\
  !*** ./src/app/tadawul-home/tadawul-home.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TadawulHomePageModule": () => (/* binding */ TadawulHomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _tadawul_home_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tadawul-home-routing.module */ 20231);
/* harmony import */ var _tadawul_home_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tadawul-home.page */ 62432);
/* harmony import */ var _common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../common-ui-components/tadawul-common-ui.module */ 50773);
/* harmony import */ var _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../pipes/pipes.module */ 41041);










const routes = [
    {
        path: '',
        component: _tadawul_home_page__WEBPACK_IMPORTED_MODULE_1__.TadawulHomePage,
        children: [
            // {
            //   path: 'home',
            //   component: HomeComponent
            // }, 
            {
                path: 'tabs',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_pages_order_confirm_order-confirm_page_ts-src_app_pages_order_order_page_ts"), __webpack_require__.e("default-src_app_pages_tradestation_symbol-swiper_symbol-swiper_module_ts"), __webpack_require__.e("common"), __webpack_require__.e("src_app_pages_tabs_tabs_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./../pages/tabs/tabs.module */ 4987)).then(m => m.TabsPageModule)
            },
            {
                path: 'user-profile',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_user-profile_user-profile_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./../pages/user-profile/user-profile.module */ 44032)).then(m => m.UserProfilePageModule)
            },
            {
                path: 'notifications',
                loadChildren: () => __webpack_require__.e(/*! import() */ "common").then(__webpack_require__.bind(__webpack_require__, /*! ./../pages/notifications/notifications.module */ 38617)).then(m => m.NotificationsPageModule)
            },
            {
                path: 'symbol',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_pages_order_confirm_order-confirm_page_ts-src_app_pages_order_order_page_ts"), __webpack_require__.e("src_app_pages_symbol_symbol_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./../pages/symbol/symbol.module */ 85730)).then(m => m.SymbolPageModule)
            },
            {
                path: 'portfolios',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_pages_order_confirm_order-confirm_page_ts-src_app_pages_order_order_page_ts"), __webpack_require__.e("src_app_pages_portfolios_portfolios_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./../pages/portfolios/portfolios.module */ 1661)).then(m => m.PortfoliosPageModule)
            },
            {
                path: 'products',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_products_products_products_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./../pages/products/products/products.module */ 8518)).then(m => m.ProductsPageModule)
            },
            {
                path: 'product-details',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_products_product-details_product-details_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./../pages/products/product-details/product-details.module */ 68454)).then(m => m.ProductDetailsPageModule)
            },
            {
                path: 'product-subscribe',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_products_product-subscribe_product-subscribe_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./../pages/products/product-subscribe/product-subscribe.module */ 89685)).then(m => m.ProductSubscribePageModule)
            },
            {
                path: 'product-subscribe-summary',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_products_product-subscribe-summary_product-subscribe-summary_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./../pages/products/product-subscribe-summary/product-subscribe-summary.module */ 31667)).then(m => m.ProductSubscribeSummaryPageModule)
            },
            {
                path: 'transfer',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_transfer_transfer_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./../pages/transfer/transfer.module */ 73254)).then(m => m.TransferPageModule)
            },
            {
                path: 'standing-orders',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_pages_order_confirm_order-confirm_page_ts-src_app_pages_order_order_page_ts"), __webpack_require__.e("default-src_app_pages_standing-orders_standing-orders_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./../pages/standing-orders/standing-orders.module */ 47425)).then(m => m.StandingOrdersPageModule)
            },
            {
                path: 'mutual-funds-details',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_mutual-funds_mutual-funds-details_mutual-funds-details_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./../pages/mutual-funds/mutual-funds-details/mutual-funds-details.module */ 96742)).then(m => m.MutualFundsDetailsPageModule)
            },
            {
                path: 'mutual-funds-subscribe',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_mutual-funds_mutual-funds-subscribe_mutual-funds-subscribe_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./../pages/mutual-funds/mutual-funds-subscribe/mutual-funds-subscribe.module */ 79006)).then(m => m.MutualFundsSubscribePageModule)
            },
            {
                path: 'mutual-funds-subscribe-confirm',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_mutual-funds_mutual-funds-subscribe-confirm_mutual-funds-subscribe-confirm_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./../pages/mutual-funds/mutual-funds-subscribe-confirm/mutual-funds-subscribe-confirm.module */ 15540)).then(m => m.MutualFundsSubscribeConfirmPageModule)
            },
            {
                path: 'mutual-funds-subscribe-summary',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_mutual-funds_mutual-funds-subscribe-summary_mutual-funds-subscribe-summary_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./../pages/mutual-funds/mutual-funds-subscribe-summary/mutual-funds-subscribe-summary.module */ 296)).then(m => m.MutualFundsSubscribeSummaryPageModule)
            },
            {
                path: 'mutual-funds-redemption',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_mutual-funds_mutual-funds-redemption_mutual-funds-redemption_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./../pages/mutual-funds/mutual-funds-redemption/mutual-funds-redemption.module */ 29292)).then(m => m.MutualFundsRedemptionPageModule)
            },
            {
                path: 'mutual-funds-redemption-confirm',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_mutual-funds_mutual-funds-redemption-confirm_mutual-funds-redemption-confirm_mo-ee38fb").then(__webpack_require__.bind(__webpack_require__, /*! ./../pages/mutual-funds/mutual-funds-redemption-confirm/mutual-funds-redemption-confirm.module */ 7824)).then(m => m.MutualFundsRedemptionConfirmPageModule)
            },
            {
                path: 'mutual-funds-redemption-summary',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_mutual-funds_mutual-funds-redemption-summary_mutual-funds-redemption-summary_mo-7d7dfe").then(__webpack_require__.bind(__webpack_require__, /*! ./../pages/mutual-funds/mutual-funds-redemption-summary/mutual-funds-redemption-summary.module */ 8558)).then(m => m.MutualFundsRedemptionSummaryPageModule)
            },
            {
                path: 'reports-mutual-funds',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_reports_reports-mutual-funds_reports-mutual-funds_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./../pages/reports/reports-mutual-funds/reports-mutual-funds.module */ 45487)).then(m => m.ReportsMutualFundsPageModule)
            },
            {
                path: 'reports/:id',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_reports_reports_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./../pages/reports/reports.module */ 75843)).then(m => m.ReportsPageModule)
            },
            // {
            //   path: 'kyc',
            //   loadChildren: () => import('./../pages/kyc/kyc.module').then(m => m.KycPageModule)
            // },
            {
                path: 'mutual-funds',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_mutual-funds_mutual-funds_mutual-funds_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./../pages/mutual-funds/mutual-funds/mutual-funds.module */ 32067)).then(m => m.MutualFundsPageModule)
            },
            {
                path: 'contact-us',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_contact-us_contact-us_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./../pages/contact-us/contact-us.module */ 5344)).then(m => m.ContactUsPageModule)
            },
        ]
    },
];
let TadawulHomePageModule = class TadawulHomePageModule {
};
TadawulHomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.ReactiveFormsModule,
            _tadawul_home_routing_module__WEBPACK_IMPORTED_MODULE_0__.TadawulHomePageRoutingModule,
            _angular_router__WEBPACK_IMPORTED_MODULE_9__.RouterModule.forChild(routes),
            _common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_3__.PipesModule
        ],
        declarations: [
            _tadawul_home_page__WEBPACK_IMPORTED_MODULE_1__.TadawulHomePage
        ]
    })
], TadawulHomePageModule);



/***/ }),

/***/ 62432:
/*!***************************************************!*\
  !*** ./src/app/tadawul-home/tadawul-home.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TadawulHomePage": () => (/* binding */ TadawulHomePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _tadawul_home_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tadawul-home.page.html?ngResource */ 46510);
/* harmony import */ var _tadawul_home_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tadawul-home.page.scss?ngResource */ 11689);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _events_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../events.service */ 31782);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);







let TadawulHomePage = class TadawulHomePage {
    constructor(translate, event, navCtrl) {
        this.translate = translate;
        this.event = event;
        this.navCtrl = navCtrl;
        this.routerDirection = 'rtl';
        this.routerDirection = this.translate.currentLang == 'ar' ? 'rtl' : 'ltr';
        console.log("🚀 ~ file: tadawul-home.page.ts ~ line 13 ~ TadawulHomePage ~ constructor ~ this.routerDirection", this.routerDirection);
        this.translate.onLangChange.subscribe((event) => {
            console.log("🚀 ~ file: tadawul-home.page.ts ~ line 15 ~ TadawulHomePage ~ this.translate.onLangChange.subscribe ~ event", event);
            if (event.lang == 'ar') {
                this.routerDirection = 'rtl';
            }
            else {
                this.routerDirection = 'ltr';
            }
        });
        this.event.subscribe('CHANGE_APP_LANG', (val) => {
            if (val) {
                console.log("🚀 ~ file: app.component.ts ~ line 125 ~ AppComponent ~ this.event.subscribe ~ this.routerDirection", this.routerDirection);
                this.navCtrl.navigateRoot('main/tabs');
            }
        });
    }
    ngOnInit() {
    }
};
TadawulHomePage.ctorParameters = () => [
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslateService },
    { type: _events_service__WEBPACK_IMPORTED_MODULE_2__.EventsService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController }
];
TadawulHomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'tadawul-tadawul-home',
        template: _tadawul_home_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_tadawul_home_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:paramtypes", [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslateService,
        _events_service__WEBPACK_IMPORTED_MODULE_2__.EventsService,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController])
], TadawulHomePage);



/***/ }),

/***/ 11689:
/*!****************************************************************!*\
  !*** ./src/app/tadawul-home/tadawul-home.page.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0YWRhd3VsLWhvbWUucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 46510:
/*!****************************************************************!*\
  !*** ./src/app/tadawul-home/tadawul-home.page.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<!-- <ion-content > -->\n  <!-- <ion-router-outlet></ion-router-outlet> -->\n<!-- </ion-content> -->\n\n  <ng-container *ngIf=\"routerDirection == 'rtl'\" >\n    <ion-router-outlet  dir=\"rtl\"></ion-router-outlet>\n  </ng-container>\n  <ng-container *ngIf=\"routerDirection == 'ltr'\" >\n    <ion-router-outlet  dir=\"ltr\"></ion-router-outlet>\n  </ng-container>";

/***/ })

}]);
//# sourceMappingURL=src_app_tadawul-home_tadawul-home_module_ts.js.map