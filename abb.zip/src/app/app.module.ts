import { HttpRequestService } from '@inma/helpers/http/http-request';
import { TadawulCommonUiModule } from 'src/app/common-ui-components/tadawul-common-ui.module';
import { ChartHelper } from './../helpers/chart.helper';
import { Files } from '@inma/helpers/file';
import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { RouteReuseStrategy } from "@angular/router";

import { IonicModule, IonicRouteStrategy } from "@ionic/angular";
import { SplashScreen } from "@ionic-native/splash-screen/ngx";
import { StatusBar } from "@ionic-native/status-bar/ngx";
import { NgxNavigationWithDataComponent } from "ngx-navigation-with-data";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { Injector } from "@inma/helpers/injector";
import { HttpClientModule, HttpClient } from "@angular/common/http";
import { TabbarComponent } from "./pages/tabbar/tabbar.component";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { Globalization } from "@ionic-native/globalization/ngx";
import { HTTP } from '@ionic-native/http/ngx';
import { DevelopmentComponent } from './common-ui-components/development/development.component';
import { KeychainTouchId } from '@ionic-native/keychain-touch-id/ngx';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { ChartComponent } from './chart/chart.component';
import { CommafyPipe } from './pipes/commafy';
import { ChartComponentModule } from './chart/chart.component.module';
import { SmsRetriever } from '@ionic-native/sms-retriever/ngx';
import { MobileAccessibility } from '@ionic-native/mobile-accessibility/ngx';
import { DisconnectionPagePageModule } from "./disconnection-page/disconnection-page.module";
import { Network } from '@ionic-native/network/ngx';
import { Vibration } from '@ionic-native/vibration/ngx';
import { NativePageTransitions } from '@ionic-native/native-page-transitions/ngx';

import { TranslateModule, TranslateLoader, TranslateService } from '@ngx-translate/core'
import { TranslateHttpLoader } from '@ngx-translate/http-loader'
import { IonBottomDrawerModule } from 'ion-bottom-drawer';
import { LocalizedString } from './helpers/localized-string';
import { AppHelper } from './helpers/helper';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';

import { OpenNativeSettings } from '@ionic-native/open-native-settings/ngx';
import { Diagnostic } from '@ionic-native/diagnostic/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { File } from '@ionic-native/file/ngx'

export function createTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json')
}

@NgModule({
  declarations: [AppComponent, DevelopmentComponent],
  entryComponents: [],
  imports: [
    BrowserModule,
    IonicModule.forRoot({
      mode: "ios",
      animated: true,
      rippleEffect: true,
      swipeBackEnabled: true,
      scrollPadding: false,
      scrollAssist: true,
      // platforms: {
      // ios: {
      //   scrollAssist: false,
      //   autoFocusAssist: false,
      //   scrollPadding: false,
      // },
      // android: {
      //   scrollAssist: false,
      //   autoFocusAssist: false,
      //   scrollPadding: true,
      // },
      // },
    }),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (createTranslateLoader),
        deps: [HttpClient]
      }
    }),
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    DisconnectionPagePageModule,
    IonBottomDrawerModule
    // TadawulCommonUiModule
  ],
  providers: [
    StatusBar,
    SplashScreen,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
    Injector,
    Globalization,
    HTTP,
    NgxNavigationWithDataComponent,
    KeychainTouchId,
    LocalizedString,
    AppHelper,
   //  HttpRequestService,
    SocialSharing,
    SmsRetriever,
    MobileAccessibility,
    Network,
    // ChartHelper,
    Vibration,
    NativePageTransitions,
    InAppBrowser,
    OpenNativeSettings,
    Diagnostic,
    InAppBrowser,
    NativePageTransitions,
    FileOpener,
    File,
    Files
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(private injector: Injector) { }
}
