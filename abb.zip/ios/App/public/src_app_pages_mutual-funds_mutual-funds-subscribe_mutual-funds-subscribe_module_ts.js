"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_mutual-funds_mutual-funds-subscribe_mutual-funds-subscribe_module_ts"],{

/***/ 29132:
/*!*************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-details.translations.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsTranslations": () => (/* binding */ MutualFundsTranslations)
/* harmony export */ });
/* harmony import */ var src_app_app_translations__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/app.translations */ 32801);

class Translations extends src_app_app_translations__WEBPACK_IMPORTED_MODULE_0__.AppTranslations {
    constructor() {
        super(...arguments);
        this.MUTUAL_FUND_DETAILS = ["تفاصيل الصندوق", "Details"];
        this.MUTUAL_FUND_FEES = ["رسوم الصندوق", "Fees"];
        this.SUBSCRIPTION_FEES = ["رسوم الاشتراك", "Subscription Fees"];
        this.MINIMUM_SUBSCRIPTION = ["الحد الأدنى للاشتراك", "Minimum Subscription"];
        this.MINIMUM_INITIAL_SUBSCRIPTION = ["الحد الأدنى لأول اشتراك", "Minimum Initial Subscription"];
        this.MIN_ADDITIONAL_SUBSCRIPTION = ["الحد الأدنى للاشتراك الإضافي", "Min Additional Subscription"];
        this.CUSTODY_FEES = ["رسوم الحفظ", "Custody Fees"];
        this.REDEMPTION_FEES = ["رسوم الاسترداد", "Redemption Fees"];
        this.EARLY_REDEMPTION_FEES = ["رسوم استرداد مبكر", "Early Redemption Fees"];
        this.EARLY_REDEMPTION_FEES_POLICY = ["سياسة رسوم الاسترداد المبكر", "Early Redemption Fees Policy"];
        this.OTHER_FEES = ["رسوم أخرى", "Other Fees"];
        this.INVESTMENT_STRATEGY = ["استراتيجية الاستثمار", "Investment Strategy"];
        this.OBJECTIVE = ["هدف الصندوق", "Objective"];
        this.CURRENCY = ["العملة الأساسية", "Currency"];
        this.EVALUATION_DAYS = ["أيام التقييم", "Evaluation Days"];
        this.AT_TIME = ["الساعة", "at"];
        this.INCEPTION_DATE = ["تاريخ بداية التأسيس", "Inception Date"];
        this.INCEPTION_PRICE = ["سعر الوحدة عند التأسيس", "Inception Price"];
        this.INVESTING_MARKETS = ["الاسواق المستثمر فيها", "Investing Markets"];
        this.LAST_PRICE = ["آخر سعر", "Last Price"];
        this.LAST_PRICE_AT = ["بتاريخ", "at"];
        this.YEAR_TO_DAY_CHANGE_PERCENTAGE = ["نسبة تغيير السعر عن بداية العام", "Year To Day Change"];
        // MINIMUM_INITIAL_SUBSCRIPTION =["الحد الأدنى لأول اشتراك", "Minimum Initial Subscription"];
        // MIN_ADDITIONAL_SUBSCRIPTION =["الحد الأدنى للاشتراك الإضافي", "Min Additional Subscription"];
        this.MINIMUM_REDEMPTION = ["الحد الأدنى للاسترداد", "Minimum Redemption"];
        this.unit = ["وحدة", "unit"];
        this.units = ["وحدات", "units"];
        this.NO_REDEMPTION = ["لا يوجد استرداد", "No Redemption"];
        this.ADD_UNITS = ["إضافة وحدات", "Add Units"];
        this.REDEEM_UNITS = ["استرداد وحدات", "Redeem Units"];
        this.YOU_ARE_SUBSCRIBED_TO_THIS_FUND = ["أنت مشترك في هذا الصندوق", "You are subscribed to this fund"];
        this.SUBSCRIBE = ["اشتراك", "Subscribe"];
        // SUBSCRIPTION PAGE
        this.SUBSCRIPTION_HEADER = ["الاشتراك في الصندوق", "Mutual Fund Subscription"];
        this.ADD_UNIT_HEADER = ["إضافة وحدات فى الصندوق", "Mutual Fund Subscription"];
        this.PORTFOLIO = ["المحفظة", "Portfolio"];
        this.BALANCE = ["الرصيد", "Balance"];
        this.MUTUAL_FUND = ["صندوق الاستثمار", "Mutual Fund"];
        this.UNIT_PRICE = ["سعر الوحدة", "Unit Price"];
        this.VALUATION_DATE = ["تاريخ أيام التقييم", "Valuation Date"];
        this.LAST_DATE_FOR_RECEIPT_THE_ORDERS = ["آخر موعد للطلبات", "Last Date For Orders"];
        this.SUBSCRIPTION_AMOUNT = ["قيمة الاشتراك", "Subscription Amount"];
        this.MUTUAL_FUND_REQUEST_NOTICE_MESSAGE = ["سيتم تنفيذ الطلب بعد يوم التقييم القادم،  حيث قد يطرأ تعديل على سعر الوحدة،  لذلك يرجى ملاحظة أن القيمة هي قيمة تقريبية تعتمد على سعر الوحدة الحالي.", "The order will be executed after the next evaluation day, as there may be an adjustment to the unit price, so please note that the value is an approximate value that depends on the current unit price."];
        this.COMMISSION_DETAILS = ["تفاصيل العمولة", "Commission Details"];
        this.TOTAL_COMMISSION = ["إجمالى العمولة", "Total Commision"];
        this.VAT_WITH_PERCENTAGE = ["ضريبة القيمة المضافة (١٥٪)", "Vat 15%"];
        this.TOTAL_AMOUNT = ["إجمالى قيمة الأمر", "Total Amount"];
        this.TERMS_CONDITIONS_CONFIRMATION = ["لقد قرأت وفهمت و وافقت على ", "I have read and agreed on"];
        this.TERMS_CONDITIONS = ["الشروط والأحكام", "terms and conditions"];
        this.PLEASE_AGREE_ON_TERMS_AND_CONDITIONS = ["برجاء الموافقة على الشروط والأحكام", "Please Agree on terms and conditions"];
        this.SEND_SUBSCRIPTION_ORDER = ["إرسال طلب الاشتراك", "Send Subscription Order"];
        this.EDIT_ORDER = ["تعديل الطلب", "Edit"];
        this.CANCEL_ORDER = ["إلغاء", "Cancel"];
        this.SUBSCRIPTION_REQUEST_SUCCESS_MESSAGE = ["تم إرسال طلب الاشتراك بنجاح", "Subscription request has been sent successfully"];
        this.ADDUNITS_REQUEST_SUCCESS_MESSAGE = ["تم إرسال طلب إضافة وحدات بنجاح", "Adding Units request has been sent successfully"];
        this.ORDER_DETAILS = ["تفاصيل الطلب", "Subscription Details"];
        this.ADD_NEW_SUBSCRIPTION = ["إضافة أمر جديد", "Add new subscription"];
        this.SHARE = ["مشاركة", "Share"];
        this.BACK_TO_HOME = ["العودة إلى الرئيسية", "Back To Home"];
        // REDEMPTION PAGE
        this.REDEMPTION = ["استرداد", "Redemption"];
        this.SEND_REDEMPTION_ORDER = ["إرسال طلب الاسترداد", "Send Redemption Order"];
        this.REDEMPTION_REQUEST_SUCCESS_MESSAGE = ["تم إرسال طلب الاسترداد بنجاح", "Redemption request has been sent successfully"];
        this.REDEMPTION_UNITS_AMOUNT = ["عدد الوحدات", "Units number"];
        this.ALLUNITS = ['جميع الوحدات', 'All units'];
        this.NUMBEROFUNITS = ['عدد من الوحدات', 'Part'];
        this.AMOUNT = ['قيمة محددة', 'Amount'];
        this.REDEMPTION_AMOUNT = ['قيمة الاسترداد', 'Redemption Amount'];
        this.ALL_UNITS_WARNING = ["باختيار جميع الوحدات سوف تقوم باسترداد جميع الوحدات المملوكة لك في المحفظة", "By selecting All Units you will redeem all owned units you have in your portfolio"];
        this.UNITS_NUMBER = ['عدد الوحدات', 'Units number'];
        this.PLEASE_ENTER_A_VALID = ["الرجاء إدخال", "Please enter a valid"];
        this.VALUE_SHOULD_BE_GREATER_THAN = ["يجب أن تكون القيمة أكبر من", "Value should be greater than"];
        //MUTUAL_FUNDS PAGE
        this.INVESTMENT_FUNDS = ["صناديق الاستثمار", "Investment Funds"];
        this.CHARITY_FUNDS = ["الصناديق الوقفية", "Endowment Funds"];
        this.MUTUAL_FUNDS = ['الصناديق الاستثمارية', 'Mutual Funds'];
        this.MUTUAL_FUND_TYPE = ['نوع الصندوق', 'Mutual Fund Type'];
        this.MUTUAL_FUND_NAME = ['اسم الصندوق', 'Name'];
        this.YEAR_TO_DAY_CHANGE = ["التغير عن بداية العام", "Year To Day Change"];
        this.SUBSCRIPTION_PRICE = ["سعر الاشتراك", "Subscription price"];
        this.INVESTMENT_FUND_TYPE = ["استثماري", "’Mutual Fund"];
        this.CLOSED_FUND_TYPE = ["مغلق", "Closed"];
        this.CHARITY_FUND_TYPE = ["خيرى", "Charity"];
        this.FUND_PERFORMANCE = ["أداء الصندوق", "Performance"];
        this.ANNUAL_STATEMENT = ["البيان السنوي", "Statement"];
        this.DETAILS = ["التفاصيل", "Details"];
        this.SAR = ["ر.س", "SAR"];
        this.ownedUnits = ["الوحدات المملوكة", "Owned Units"];
        this.ownedAmount = ["القيمة المملوكة", "Owned Amount"];
        this.REPORT_REVIEW = ["عرض تقرير الملاءمة", "View Suitability Report"];
        this.SUB_MSG = [" , ولكن لا يزال بإمكانك الاشتراك أو", " , but you still can subscribe or "];
        this.NOT_SUITABLE_AGREEMENT = ["أقــر باطلاعــي عــلى تقريــر ملاءمــة الصفقــة المعــد مــن شركــة الإنمــاء للاســتثمار والمتضمــن أن هــذه الصفقــة غــير ملائمــة لي، وأقــر بعلمــي بجميــع تفاصيــل هــذه الصفقــة، وبفهمــي لجميــع المخاطــر المحتملــة نتيجــة دخــولي لهــذه الصفقــة، كــما أقــر بفهمــي أن تنفيــذ هــذه الصفقــة لا يتوافــق مــع تقريــر الملاءمــة المعــد مــن شركــة الإنمــاء للاســتثمار", "I acknowledge reviewing the suitability report prepared by Alinma Investment, which stated that this transaction is non-suitable for me.I also acknowledge that I am fully aware of all transaction details, and the potential risks entering into this transaction.\r\nI also acknowledge by executing this transaction that I am fully aware that it is not consistent with the suitability report provided by Alinma Investment"];
        this.PLEASE_AGREE_ON_NOT_SUITABLE_AGREEMENT = ["برجاء الموافقة على الإقرار بمراجعة تقرير الملاءمة", "Please Agree on acknowledge reviewing the suitability report"];
    }
}
const MutualFundsTranslations = new Translations();


/***/ }),

/***/ 89366:
/*!****************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-subscribe/mutual-funds-subscribe-routing.module.ts ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsSubscribePageRoutingModule": () => (/* binding */ MutualFundsSubscribePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _mutual_funds_subscribe_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-funds-subscribe.page */ 20707);




const routes = [
    {
        path: '',
        component: _mutual_funds_subscribe_page__WEBPACK_IMPORTED_MODULE_0__.MutualFundsSubscribePage
    }
];
let MutualFundsSubscribePageRoutingModule = class MutualFundsSubscribePageRoutingModule {
};
MutualFundsSubscribePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MutualFundsSubscribePageRoutingModule);



/***/ }),

/***/ 79006:
/*!********************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-subscribe/mutual-funds-subscribe.module.ts ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsSubscribePageModule": () => (/* binding */ MutualFundsSubscribePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _providers_order_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../providers/order.service */ 1098);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _mutual_funds_subscribe_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mutual-funds-subscribe-routing.module */ 89366);
/* harmony import */ var _mutual_funds_subscribe_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./mutual-funds-subscribe.page */ 20707);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);
/* harmony import */ var src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/pipes/pipes.module */ 41041);











let MutualFundsSubscribePageModule = class MutualFundsSubscribePageModule {
};
MutualFundsSubscribePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            _mutual_funds_subscribe_routing_module__WEBPACK_IMPORTED_MODULE_1__.MutualFundsSubscribePageRoutingModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_3__.TadawulCommonUiModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__.TranslateModule.forChild(),
            src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_4__.PipesModule
        ],
        declarations: [
            _mutual_funds_subscribe_page__WEBPACK_IMPORTED_MODULE_2__.MutualFundsSubscribePage,
            // CommafyPipe,
            // SARPipe
        ],
        providers: [_providers_order_service__WEBPACK_IMPORTED_MODULE_0__.OrderService]
    })
], MutualFundsSubscribePageModule);



/***/ }),

/***/ 20707:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-subscribe/mutual-funds-subscribe.page.ts ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsSubscribePage": () => (/* binding */ MutualFundsSubscribePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _mutual_funds_subscribe_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-funds-subscribe.page.html?ngResource */ 78507);
/* harmony import */ var _mutual_funds_subscribe_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mutual-funds-subscribe.page.scss?ngResource */ 67934);
/* harmony import */ var _providers_order_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../providers/order.service */ 1098);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @capacitor/core */ 26549);
/* harmony import */ var _inma_helpers_toast__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/helpers/toast */ 51139);
/* harmony import */ var _inma_helpers_translations__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @inma/helpers/translations */ 69353);
/* harmony import */ var _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @inma/models/portfolio */ 65082);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../providers/mutual-funds.service */ 1835);
/* harmony import */ var _mutual_funds_mutual_funds_details_translations__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../mutual-funds/mutual-funds-details.translations */ 29132);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 19193);
/* harmony import */ var _inma_helpers_file__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @inma/helpers/file */ 96245);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs/operators */ 44661);












// import { ActivatedRoute } from '@angular/router';

const { Browser } = _capacitor_core__WEBPACK_IMPORTED_MODULE_3__.Plugins;



let MutualFundsSubscribePage = class MutualFundsSubscribePage {
    constructor(mutualFundsService, formBuilder, orderService, navCtrl, file) {
        this.mutualFundsService = mutualFundsService;
        this.formBuilder = formBuilder;
        this.orderService = orderService;
        this.navCtrl = navCtrl;
        this.file = file;
        this.t = _mutual_funds_mutual_funds_details_translations__WEBPACK_IMPORTED_MODULE_8__.MutualFundsTranslations;
        this.terms = false;
        this.notSuitable = false;
        this.submitted = false;
        this.loading = false;
        this.suitability = {};
        this.buildForm();
    }
    ngOnInit() {
        this.mutualFund = this.mutualFundsService.getMutualFund();
        console.log(this.mutualFund);
        this.mutualFund.suitability.subscribe((res) => {
            this.suitability = res;
            console.log("🚀 ~ file: mutual-funds-subscribe.page.ts ~ line 55 ~ MutualFundsSubscribePage ~ this.mutualFund.suitability.subscribe ~ this.suitability", this.suitability);
        });
    }
    ionViewWillEnter() {
        // this.form.controls.amount.setValue('');
        // this.form.controls.terms.setValue(false);
        // this.submitted = true;
        // this.form.reset();
        _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_6__.Portfolios.allMutualFundPortfolios.subscribe((portfolios) => {
            var _a, _b;
            this.portfolios = portfolios;
            if (this.mutualFund.portfolio) {
                this.findPortfolioById(this.mutualFund.portfolio.id).then((res) => {
                    this.portfolio = res;
                });
            }
            else if (!this.mutualFund.portfolio &&
                portfolios &&
                portfolios.length) {
                this.mutualFund.portfolio = portfolios[0];
                this.portfolio = portfolios[0];
            }
            if (this.portfolio) {
                this.orderService.getLiveBuyingPower((_a = this.portfolio) === null || _a === void 0 ? void 0 : _a.id, (_b = this.portfolio) === null || _b === void 0 ? void 0 : _b.type)
                    .subscribe((bP) => {
                    this.mutualFundBuyingPower = bP;
                });
            }
        });
        this.mutualFund.details.subscribe((details) => {
            this.mfDetails = details;
            console.log(this.mfDetails);
            this.updateValidators();
        });
    }
    findPortfolioById(id) {
        return new Promise((resolve, reject) => {
            this.portfolios.forEach((p) => {
                if (p.id === id) {
                    resolve(p);
                }
            });
        });
    }
    buildForm() {
        this.form = this.formBuilder.group({
            portfolio: ["", _angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.required])],
            amount: ["", _angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.required])],
            terms: [],
            notSuitable: [],
        });
    }
    updateValidators() {
        var _a;
        // if (this.initialized) {
        // Undo
        console.log(this.mfDetails);
        console.log(this.mfDetails.minimumInitialSubscription);
        console.log(this.mfDetails.minAdditionalSubscription);
        var value = ((_a = this.mutualFund) === null || _a === void 0 ? void 0 : _a.ownedUnits)
            ? this.mfDetails.minAdditionalSubscription
            : this.mfDetails.minimumInitialSubscription;
        // this.mfDetails.subscribe(det=>{
        this.form.controls["amount"].setValidators([
            _angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.required,
            _angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.min(value),
        ]);
        this.form.controls["amount"].updateValueAndValidity();
        // });
        // EndUndo
        // }
    }
    subscribe(form) {
        var _a, _b, _c, _d;
        console.log(form);
        console.log(this.terms);
        this.submitted = true;
        if (form.invalid || !this.terms || (((_b = (_a = this.mutualFund) === null || _a === void 0 ? void 0 : _a.mfSuitability) === null || _b === void 0 ? void 0 : _b.eligiblityCheckApplicable) && !((_d = (_c = this.mutualFund) === null || _c === void 0 ? void 0 : _c.mfSuitability) === null || _d === void 0 ? void 0 : _d.isSuitabile) && this.notSuitable == false)) {
            return;
        }
        this.mutualFund["formData"] = {
            amount: this.amount,
            portfolio: this.mutualFund.portfolio,
        };
        this.mutualFundsService.setMutualFund(this.mutualFund);
        this.navCtrl.navigateForward('main/mutual-funds-subscribe-confirm');
    }
    portfolioChanged(val) {
        console.log(val);
        if (this.mutualFund) {
            this.mutualFund["portfolio"] = val;
        }
        // this.portfolio = val;
    }
    openTermsAndConditions() {
        this.loading = true;
        (0,rxjs__WEBPACK_IMPORTED_MODULE_11__.combineLatest)([this.mutualFund.termsAndConditions]).subscribe((data) => {
            this.loading = false;
            this.file.openBase64File(data);
        });
    }
    openReport() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__awaiter)(this, void 0, void 0, function* () {
            (0,rxjs__WEBPACK_IMPORTED_MODULE_11__.combineLatest)([this.mutualFund.suitability]).subscribe((data) => {
                var _a;
                // On iOS, for example, open the URL in SFSafariViewController (the in-app browser)
                let report = (_a = data[0]) === null || _a === void 0 ? void 0 : _a.report;
                if (report) {
                    this.file.openBase64File(report);
                    // var dataBlob = Encryption.Base64.toBlob(report, "application/pdf");
                    // var downloadURL = (window.webkitURL || window.URL).createObjectURL(dataBlob);
                    // Browser.open({
                    //   url: downloadURL
                    // });
                }
                else {
                    _inma_helpers_toast__WEBPACK_IMPORTED_MODULE_4__.Toast.present("Service Data Issue", {
                        class: "server-error-toast",
                        timer: { period: 10, callback: null },
                    });
                }
            });
        });
    }
    refuseSubscription() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__awaiter)(this, void 0, void 0, function* () {
            this.mutualFund.refuseSubscription().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.finalize)(() => {
                this.navCtrl.navigateRoot('main/tabs');
            })).subscribe((data) => {
                console.log(data);
            });
        });
    }
    back() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__awaiter)(this, void 0, void 0, function* () {
            this.navCtrl.navigateBack("/tadawul-home/home");
        });
    }
};
MutualFundsSubscribePage.ctorParameters = () => [
    { type: _providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_7__.MutualFundsService },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormBuilder },
    { type: _providers_order_service__WEBPACK_IMPORTED_MODULE_2__.OrderService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.NavController },
    { type: _inma_helpers_file__WEBPACK_IMPORTED_MODULE_9__.Files }
];
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([
    (0,_inma_helpers_translations__WEBPACK_IMPORTED_MODULE_5__.Translations)(),
    (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Object)
], MutualFundsSubscribePage.prototype, "t", void 0);
MutualFundsSubscribePage = (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_15__.Component)({
        selector: "tadawul-mutual-funds-subscribe",
        template: _mutual_funds_subscribe_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_mutual_funds_subscribe_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:paramtypes", [_providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_7__.MutualFundsService,
        _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormBuilder,
        _providers_order_service__WEBPACK_IMPORTED_MODULE_2__.OrderService,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.NavController,
        _inma_helpers_file__WEBPACK_IMPORTED_MODULE_9__.Files])
], MutualFundsSubscribePage);



/***/ }),

/***/ 1835:
/*!***************************************************!*\
  !*** ./src/app/providers/mutual-funds.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsService": () => (/* binding */ MutualFundsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let MutualFundsService = class MutualFundsService {
    constructor() { }
    setMutualFund(mutualFund) {
        this.mutualFund = mutualFund;
    }
    getMutualFund() {
        return this.mutualFund;
    }
};
MutualFundsService.ctorParameters = () => [];
MutualFundsService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Injectable)({
        providedIn: 'root'
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__metadata)("design:paramtypes", [])
], MutualFundsService);



/***/ }),

/***/ 1098:
/*!********************************************!*\
  !*** ./src/app/providers/order.service.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderService": () => (/* binding */ OrderService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/helpers/http */ 36802);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ 86942);




let OrderService = class OrderService {
    constructor() { }
    getLiveBuyingPower(id, type) {
        const url = "/Portfolio/MyPortfolios/loadCustBuyingPwr";
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request(url, { portfolioId: id, portfolioType: type }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.map)((result) => {
            var _a, _b;
            return (_b = (_a = result === null || result === void 0 ? void 0 : result.buyingPwr) === null || _a === void 0 ? void 0 : _a.buyingPwrAmt) === null || _b === void 0 ? void 0 : _b.amount;
        }));
    }
};
OrderService.ctorParameters = () => [];
OrderService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: "root",
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:paramtypes", [])
], OrderService);



/***/ }),

/***/ 67934:
/*!*******************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-subscribe/mutual-funds-subscribe.page.scss?ngResource ***!
  \*******************************************************************************************************/
/***/ ((module) => {

module.exports = "ion-button {\n  --border-radius: 0;\n  height: 40px;\n}\n\n.inner-box-label {\n  display: block;\n  color: var(--ion-color-primary-tint);\n}\n\n.terms-agree {\n  display: flex;\n  align-items: start;\n}\n\n.terms-agree ion-label {\n  -webkit-padding-start: 10px;\n          padding-inline-start: 10px;\n}\n\n.terms-agree ion-checkbox {\n  width: 25px;\n  height: 25px;\n  display: block;\n  flex-shrink: 0;\n}\n\n.suitability-box {\n  display: flex;\n  align-items: flex-start;\n}\n\n.suitability-box ion-label {\n  padding: 0 15px;\n}\n\nion-item {\n  color: #005457;\n  --padding-start: 0;\n  --padding-end: 0;\n  --inner-padding-start: 0;\n  --inner-padding-end: 0;\n}\n\nbody.dark :host ion-item {\n  color: white;\n}\n\nion-item ion-select {\n  background: var(--ion-color-tertiary);\n  padding: 10px;\n}\n\nion-item {\n  --border-color: transparent;\n}\n\n.validator-error {\n  color: var(--ion-color-danger) !important;\n}\n\n.box-with-bg-tangerine {\n  background: #fdf9f2;\n  border: 1px solid var(--ion-color-warning);\n}\n\n.box-info {\n  background: #e4eef8;\n  border: 1px solid #7aabde;\n  color: #7aaade;\n}\n\n.box-warn {\n  background: #fdf9f2;\n  border: 1px solid var(--ion-color-warning);\n  color: #f5a623 !important;\n}\n\n.box-warn #bold-text {\n  color: #efa222 !important;\n  font-weight: bold;\n  text-decoration: underline;\n}\n\n.box-error {\n  background: #f8d7da;\n  border: 1px solid #dba0a6;\n  color: #842029 !important;\n}\n\n.box-error #bold-text {\n  font-weight: bold;\n  text-decoration: underline;\n}\n\nbody.dark :host .text-color-info {\n  color: #7aaade;\n}\n\nbody.dark :host .box-with-bg-tangerine {\n  background: transparent;\n}\n\nbody.dark :host .text-color-tangerine {\n  color: #f5a623;\n}\n\n.text-color-tangerine {\n  color: var(--ion-color-warning);\n}\n\n.amount-input ion-label {\n  color: var(--ion-color-primary);\n}\n\nbody.dark :host .amount-input ion-label {\n  color: white;\n}\n\n.amount-input ion-input {\n  border: 1px solid #99b9bc;\n  color: var(--ion-color-primary);\n  --padding-start: 10px;\n}\n\nbody.dark :host .amount-input ion-input {\n  color: white;\n}\n\nion-checkbox {\n  --border-radius: 0px;\n}\n\n#link-to-terms-and-conditions {\n  text-decoration: underline;\n  color: #f93f03;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm11dHVhbC1mdW5kcy1zdWJzY3JpYmUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7RUFDQSxZQUFBO0FBQ0o7O0FBRUE7RUFDSSxjQUFBO0VBQ0Esb0NBQUE7QUFDSjs7QUFFQTtFQUNJLGFBQUE7RUFDQSxrQkFBQTtBQUNKOztBQUNJO0VBQ0ksMkJBQUE7VUFBQSwwQkFBQTtBQUNSOztBQUVJO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtBQUFSOztBQUlBO0VBQ0ksYUFBQTtFQUNBLHVCQUFBO0FBREo7O0FBR0k7RUFDSSxlQUFBO0FBRFI7O0FBS0E7RUFDSSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLHdCQUFBO0VBQ0Esc0JBQUE7QUFGSjs7QUFHSTtFQUNJLFlBQUE7QUFEUjs7QUFHSTtFQUNJLHFDQUFBO0VBRUEsYUFBQTtBQUZSOztBQU1BO0VBQ0ksMkJBQUE7QUFISjs7QUFNQTtFQUNJLHlDQUFBO0FBSEo7O0FBTUE7RUFDSSxtQkFBQTtFQUNBLDBDQUFBO0FBSEo7O0FBTUE7RUFDSSxtQkFBQTtFQUNBLHlCQUFBO0VBQ0EsY0FBQTtBQUhKOztBQU1BO0VBQ0ksbUJBQUE7RUFDQSwwQ0FBQTtFQUNBLHlCQUFBO0FBSEo7O0FBSUk7RUFDSSx5QkFBQTtFQUNBLGlCQUFBO0VBQ0EsMEJBQUE7QUFGUjs7QUFPQTtFQUNJLG1CQUFBO0VBQ0EseUJBQUE7RUFDQSx5QkFBQTtBQUpKOztBQUtJO0VBQ0ksaUJBQUE7RUFDQSwwQkFBQTtBQUhSOztBQVNBO0VBQ0ksY0FBQTtBQU5KOztBQVNBO0VBQ0ksdUJBQUE7QUFOSjs7QUFTQTtFQUNJLGNBQUE7QUFOSjs7QUFTQTtFQUNJLCtCQUFBO0FBTko7O0FBVUk7RUFDSSwrQkFBQTtBQVBSOztBQVFRO0VBQ0ksWUFBQTtBQU5aOztBQVNJO0VBQ0kseUJBQUE7RUFDQSwrQkFBQTtFQUNBLHFCQUFBO0FBUFI7O0FBUVE7RUFDSSxZQUFBO0FBTlo7O0FBV0E7RUFDSSxvQkFBQTtBQVJKOztBQVdBO0VBQ0ksMEJBQUE7RUFDQSxjQUFBO0FBUkoiLCJmaWxlIjoibXV0dWFsLWZ1bmRzLXN1YnNjcmliZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tYnV0dG9uIHtcbiAgICAtLWJvcmRlci1yYWRpdXM6IDA7XG4gICAgaGVpZ2h0OiA0MHB4O1xufVxuXG4uaW5uZXItYm94LWxhYmVsIHtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktdGludCk7XG59XG5cbi50ZXJtcy1hZ3JlZSB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogc3RhcnQ7XG5cbiAgICBpb24tbGFiZWwge1xuICAgICAgICBwYWRkaW5nLWlubGluZS1zdGFydDogMTBweDtcbiAgICB9XG5cbiAgICBpb24tY2hlY2tib3gge1xuICAgICAgICB3aWR0aDogMjVweDtcbiAgICAgICAgaGVpZ2h0OiAyNXB4O1xuICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICAgICAgZmxleC1zaHJpbms6IDA7XG4gICAgfVxufVxuXG4uc3VpdGFiaWxpdHktYm94IHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xuXG4gICAgaW9uLWxhYmVsIHtcbiAgICAgICAgcGFkZGluZzogMCAxNXB4O1xuICAgIH1cbn1cblxuaW9uLWl0ZW0ge1xuICAgIGNvbG9yOiAjMDA1NDU3O1xuICAgIC0tcGFkZGluZy1zdGFydDogMDtcbiAgICAtLXBhZGRpbmctZW5kOiAwO1xuICAgIC0taW5uZXItcGFkZGluZy1zdGFydDogMDtcbiAgICAtLWlubmVyLXBhZGRpbmctZW5kOiAwO1xuICAgIGJvZHkuZGFyayA6aG9zdCAmIHtcbiAgICAgICAgY29sb3I6IHdoaXRlO1xuICAgIH1cbiAgICBpb24tc2VsZWN0IHtcbiAgICAgICAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5KTtcbiAgICAgICAgLy8gYm9yZGVyOiAxcHggc29saWQgIzk5YjliYztcbiAgICAgICAgcGFkZGluZzogMTBweDtcbiAgICB9XG59XG5cbmlvbi1pdGVtIHtcbiAgICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG59XG5cbi52YWxpZGF0b3ItZXJyb3Ige1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFuZ2VyKSAhaW1wb3J0YW50O1xufVxuXG4uYm94LXdpdGgtYmctdGFuZ2VyaW5lIHtcbiAgICBiYWNrZ3JvdW5kOiAjZmRmOWYyO1xuICAgIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci13YXJuaW5nKTtcbn1cblxuLmJveC1pbmZvIHtcbiAgICBiYWNrZ3JvdW5kOiAjZTRlZWY4O1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICM3YWFiZGU7XG4gICAgY29sb3I6ICM3YWFhZGU7XG59XG5cbi5ib3gtd2FybiB7XG4gICAgYmFja2dyb3VuZDogI2ZkZjlmMjtcbiAgICBib3JkZXI6IDFweCBzb2xpZCB2YXIoLS1pb24tY29sb3Itd2FybmluZyk7XG4gICAgY29sb3I6ICNmNWE2MjMgIWltcG9ydGFudDtcbiAgICAjYm9sZC10ZXh0IHtcbiAgICAgICAgY29sb3I6ICNlZmEyMjIgIWltcG9ydGFudDtcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICAgIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xuICAgIH1cbn1cblxuXG4uYm94LWVycm9yIHtcbiAgICBiYWNrZ3JvdW5kOiAjZjhkN2RhO1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICNkYmEwYTY7XG4gICAgY29sb3I6ICM4NDIwMjkgIWltcG9ydGFudDtcbiAgICAjYm9sZC10ZXh0IHtcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICAgIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xuICAgIH1cbn1cblxuXG5cbmJvZHkuZGFyayA6aG9zdCAudGV4dC1jb2xvci1pbmZvIHtcbiAgICBjb2xvcjogIzdhYWFkZTtcbn1cblxuYm9keS5kYXJrIDpob3N0IC5ib3gtd2l0aC1iZy10YW5nZXJpbmUge1xuICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xufVxuXG5ib2R5LmRhcmsgOmhvc3QgLnRleHQtY29sb3ItdGFuZ2VyaW5lIHtcbiAgICBjb2xvcjogI2Y1YTYyMztcbn1cblxuLnRleHQtY29sb3ItdGFuZ2VyaW5lIHtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXdhcm5pbmcpO1xufVxuXG4uYW1vdW50LWlucHV0IHtcbiAgICBpb24tbGFiZWwge1xuICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICBib2R5LmRhcmsgOmhvc3QgJiB7XG4gICAgICAgICAgICBjb2xvcjogd2hpdGU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgaW9uLWlucHV0IHtcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgIzk5YjliYztcbiAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAxMHB4O1xuICAgICAgICBib2R5LmRhcmsgOmhvc3QgJiB7XG4gICAgICAgICAgICBjb2xvcjogd2hpdGU7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbmlvbi1jaGVja2JveCB7XG4gICAgLS1ib3JkZXItcmFkaXVzOiAwcHg7XG59XG5cbiNsaW5rLXRvLXRlcm1zLWFuZC1jb25kaXRpb25zIHtcbiAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgICBjb2xvcjogI2Y5M2YwMztcbn1cbiJdfQ== */";

/***/ }),

/***/ 78507:
/*!*******************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-subscribe/mutual-funds-subscribe.page.html?ngResource ***!
  \*******************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"success\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\"></ion-back-button>\n    </ion-buttons>\n    <ion-title slot=\"start\">{{ ((mutualFund?.ownedUnits)?'mutualFund.ADD_UNIT_HEADER':'mutualFund.SUBSCRIPTION_HEADER') | translate }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<tadawul-loader *ngIf=\"loading\"></tadawul-loader>\n<ion-content class=\"ion-padding\">\n\n  <div></div>\n  <div *ngIf=\"mutualFund?.mfSuitability?.eligiblityCheckApplicable&&mutualFund?.mfSuitability\" class=\"ion-padding\"\n    [ngClass]=\"mutualFund?.mfSuitability?.isSuitabile ? 'box-info' : 'box-warn'\">\n    <div class=\"suitability-box\">\n      <ion-icon [name]=\"mutualFund?.mfSuitability?.isSuitabile ? 'alert-circle-outline':'warning-outline' \"\n        style=\"font-size: 30px;\"></ion-icon>\n      <ion-label>\n        {{suitability?.msg}}\n        <span *ngIf=\"!suitability?.isSuitabile\">{{ 'mutualFund.SUB_MSG' | translate }}</span>\n        <span *ngIf=\"!suitability?.isSuitabile\" (click)=\"refuseSubscription()\" id='bold-text'>\n          {{'mutualFund.BACK_TO_HOME' | translate}}\n        </span>\n\n        <br />\n\n        <ion-button fill=\"solid\" type=\"button\" size=\"small\" (click)=\"openReport()\">\n          <ion-icon slot=\"start\" src=\"assets/icon/pdf.svg\" style=\"font-size: 16px;\"></ion-icon>\n          <span style=\"padding: 0px 5px 0px 5px;font-size: 14px;\">\n            {{'mutualFund.REPORT_REVIEW' | translate}}\n          </span>\n        </ion-button>\n      </ion-label>\n    </div>\n  </div>\n\n\n\n  <div *ngIf=\"mutualFund?.error\" class=\"ion-padding\" [ngClass]=\"mutualFund?.error ? 'box-error':'box-info' \">\n    <div class=\"suitability-box\">\n      <ion-icon [name]=\"'warning-outline'\" style=\"font-size: 30px;\"></ion-icon>\n      <ion-label>\n        {{mutualFund?.error?.msg?.msgText}}\n\n        <span (click)=\"back()\" id='bold-text'>\n          {{'mutualFund.BACK_TO_HOME' | translate}}\n        </span>\n\n        <br />\n\n      </ion-label>\n    </div>\n  </div>\n\n\n\n\n\n  <form [formGroup]=\"form\" (ngSubmit)=\"subscribe(form)\" class=\"subscribe-form\">\n    <!-- <div class=\"ion-margin-bottom\">\n      <ion-text class=\"bold\">\n        {{ 'mutualFund.PORTFOLIO }}\n      </ion-text>\n      <div class=\"box-with-bg ion-padding\">\n        <ion-text>\n          {{mutualFund?.portfolio?.name}}\n        </ion-text>\n      </div>\n    </div> -->\n\n    <ion-item class=\"ion-margin-bottom\">\n      <ion-label position=\"stacked\">{{ 'mutualFund.PORTFOLIO' | translate }}</ion-label>\n      <ion-select placeholder=\"{{ 'mutualFund.SELECT' | translate }}\" formControlName=\"portfolio\" name=\"portfolio\" okText=\"{{ 'app.OK' | translate }}\"\n        interface=\"action-sheet\" mode=\"ios\" [interfaceOptions]=\"{header: 'mutualFund.PORTFOLIO' | translate, cssClass: 'app-select'}\"\n        cancelText=\"{{ 'app.CANCEL' | translate }}\" [(ngModel)]=\"portfolio\" (ngModelChange)=\"portfolioChanged($event)\">\n\n        <ion-select-option *ngFor=\"let p of portfolios\" [value]=\"p\">\n          {{p.id}}\n        </ion-select-option>\n\n      </ion-select>\n\n      <div *ngIf=\"!form.controls.portfolio.valid\n                  && form.controls.portfolio.dirty\" class=\"validator-error\">\n        {{ 'mutualFund.PLEASE_CHOOSE' | translate }} {{ 'mutualFund.PORTFOLIO' | translate }}\n      </div>\n    </ion-item>\n\n    <div class=\"ion-margin-bottom\">\n      <ion-text class=\"bold\">\n        {{ 'mutualFund.BALANCE' | translate }}\n      </ion-text>\n      <div class=\"box-with-bg ion-padding\">\n        <ion-text>\n          {{ mutualFundBuyingPower | number: '1.2-2'}}\n        </ion-text>\n      </div>\n    </div>\n    <div class=\"ion-margin-bottom\">\n      <ion-text class=\"bold\">\n        {{ 'mutualFund.MUTUAL_FUND' | translate }}\n      </ion-text>\n      <div class=\"box-with-bg ion-padding\">\n        <ion-text>\n          {{mutualFund?.localizedName.toString()}}\n        </ion-text>\n      </div>\n    </div>\n    <div class=\"ion-margin-bottom\">\n      <div class=\"box-with-bg ion-padding\">\n        <ion-row>\n          <ion-col size=\"4\">\n            <ion-text class=\"inner-box-label font-size-overline\">{{ 'mutualFund.CURRENCY' | translate }}</ion-text>\n            <ion-text class=\"font-size-caption\">{{ t[mfDetails?.currency] }}</ion-text>\n          </ion-col>\n          <ion-col size=\"4\">\n            <ion-text class=\"inner-box-label font-size-overline\">{{ 'mutualFund.UNIT_PRICE' | translate }}</ion-text>\n            <ion-text class=\"font-size-caption\">{{ mutualFund?.unitPrice | number:'1.0-2' | commafy }}</ion-text>\n          </ion-col>\n          <ion-col size=\"4\">\n            <ion-text class=\"inner-box-label font-size-overline\">{{ 'mutualFund.VALUATION_DATE' | translate }}</ion-text>\n            <ion-text class=\"font-size-caption\">{{ mfDetails?.lastPriceDate }}</ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size=\"4\">\n            <ion-text class=\"inner-box-label font-size-overline\">{{ ((mutualFund?.ownedUnits)? 'mutualFund.MIN_ADDITIONAL_SUBSCRIPTION':'mutualFund.MINIMUM_INITIAL_SUBSCRIPTION' )| translate }}</ion-text>\n            <ion-text class=\"font-size-caption\" >{{ (mutualFund?.ownedUnits)?mfDetails?.minAdditionalSubscription:mfDetails?.minimumInitialSubscription | number:'1.0-2' | commafy }} {{ t[mfDetails?.minimumInitialSubscriptionType] }}</ion-text>\n          </ion-col>\n          <ion-col size=\"4\">\n            <ion-text class=\"inner-box-label font-size-overline\">{{ 'mutualFund.EVALUATION_DAYS' | translate }}</ion-text>\n            <ion-text class=\"font-size-caption\">{{ mfDetails?.evaluationDays }}</ion-text>\n          </ion-col>\n          <ion-col size=\"4\">\n            <ion-text class=\"inner-box-label font-size-overline\">{{ 'mutualFund.SUBSCRIPTION_FEES' | translate }}</ion-text>\n            <ion-text class=\"font-size-caption\">\n              {{ mfDetails?.subscriptionFees }} {{ mfDetails?.subscriptionFeesType }}\n            </ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size=\"4\">\n            <ion-text class=\"inner-box-label font-size-overline\">{{ 'mutualFund.LAST_DATE_FOR_RECEIPT_THE_ORDERS' | translate }}</ion-text>\n            <ion-text class=\"font-size-caption\">{{ mfDetails?.lastDateForReceiptTheOrders?.days }}</ion-text>\n            <ion-text class=\"font-size-caption\" *ngIf='mfDetails?.lastDateForReceiptTheOrders?.time'>\n              {{ 'mutualFund.AT_TIME' | translate }} {{ mfDetails?.lastDateForReceiptTheOrders?.time }}</ion-text>\n          </ion-col>\n        </ion-row>\n      </div>\n    </div>\n\n    <!-- <ion-row>\n      <ion-col>\n        <app-input [form]=\"form\" [label]=\"'mutualFund.SUBSCRIPTION_AMOUNT\" [formControl]=\"form.controls.amount\" name=\"amount\" type=\"number\" [min]=\"mfDetails?.minimumInitialSubscription\" [(model)]=\"amount\" layout=\"2\" ngDefaultControl></app-input>\n      </ion-col>\n    </ion-row> -->\n\n    <div class=\"ion-margin-bottom amount-input\">\n      <ion-label position=\"floating\">{{'mutualFund.SUBSCRIPTION_AMOUNT' | translate}}</ion-label>\n      <ion-input type=\"number\" name=\"amount\" autocomplete=\"on\" placeholder=\"{{'mutualFund.SUBSCRIPTION_AMOUNT' | translate}}\"\n        formControlName=\"amount\" [(ngModel)]=\"amount\"></ion-input>\n      <div *ngIf=\"form.controls.amount.errors && form.controls.amount.errors.required && form.controls.amount.dirty\"\n        class=\"validator-error\">\n        {{'mutualFund.PLEASE_ENTER_A_VALID' | translate}} {{'mutualFund.SUBSCRIPTION_AMOUNT' | translate}}\n      </div>\n      <div *ngIf=\"form.controls.amount.errors && form.controls.amount.errors.min && form.controls.amount.dirty\" class=\"validator-error\">\n        {{'mutualFund.VALUE_SHOULD_BE_GREATER_THAN' | translate}} {{(mutualFund?.ownedUnits)?mfDetails?.minAdditionalSubscription:mfDetails?.minimumInitialSubscription}}\n      </div>\n    </div>\n\n    <div class=\"ion-margin-bottom\">\n      <div class=\"box-with-bg-tangerine ion-padding\">\n        <ion-text class=\"font-size-overline text-color-tangerine\">\n          {{ 'mutualFund.MUTUAL_FUND_REQUEST_NOTICE_MESSAGE' | translate }}\n        </ion-text>\n      </div>\n    </div>\n\n    <!-- SECOND SECTION -->\n    <!-- <ion-text class=\"bold\" >{{'mutualFund.COMMISSION_DETAILS}}</ion-text>\n    <div class=\"box-with-bg bordered ion-margin-bottom\">\n      <ion-row class=\"data-row\">\n        <ion-col size=\"6\">\n          <ion-text class=\"label font-size-caption\" >{{'mutualFund.TOTAL_COMMISSION}}</ion-text>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-text class=\"value font-size-caption bold\" >\n              {{mutualFund?.totalCommission | SAR}}\n          </ion-text>\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"data-row\">\n        <ion-col size=\"6\">\n          <ion-text class=\"label font-size-caption\" >{{'mutualFund.VAT_WITH_PERCENTAGE}}</ion-text>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-text class=\"value font-size-caption bold\" >\n              {{mutualFund?.vat | SAR}}\n          </ion-text>\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"data-row\">\n        <ion-col size=\"6\">\n          <ion-text class=\"label font-size-caption\" >{{'mutualFund.TOTAL_AMOUNT}}</ion-text>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-text class=\"value font-size-caption bold\" >\n            {{mutualFund?.totalAmount | SAR}}\n          </ion-text>\n        </ion-col>\n      </ion-row>\n    </div> -->\n\n    <div class=\"ion-margin-bottom\">\n      <div class=\"terms-agree\">\n        <ion-checkbox [formControl]=\"form.controls.terms\" [(ngModel)]=\"terms\"></ion-checkbox>\n        <ion-label>{{'mutualFund.TERMS_CONDITIONS_CONFIRMATION' | translate}}\n          <span (click)=\"openTermsAndConditions()\" id='link-to-terms-and-conditions'>\n            {{'mutualFund.TERMS_CONDITIONS' | translate}}\n          </span>\n        </ion-label>\n      </div>\n\n      <ion-text *ngIf=\"submitted && terms===false\" class=\"font-size-overline\" color=\"danger\">\n         {{'mutualFund.PLEASE_AGREE_ON_TERMS_AND_CONDITIONS' | translate}}</ion-text>\n    </div>\n\n    <div class=\"ion-margin-bottom\" *ngIf=\"mutualFund?.mfSuitability?.eligiblityCheckApplicable&&!mutualFund?.mfSuitability?.isSuitabile\">\n      <div class=\"terms-agree\">\n        <ion-checkbox [formControl]=\"form.controls.notSuitable\" [(ngModel)]=\"notSuitable\"></ion-checkbox>\n        <ion-label> {{'mutualFund.NOT_SUITABLE_AGREEMENT' | translate}}</ion-label>\n      </div>\n\n      <ion-text *ngIf=\"submitted && !mutualFund?.mfSuitability?.isSuitabile && notSuitable===false\"\n        class=\"font-size-overline\" color=\"danger\">\n        {{'mutualFund.PLEASE_AGREE_ON_NOT_SUITABLE_AGREEMENT' | translate}}</ion-text>\n    </div>\n\n\n    <app-button [disabled]=\"!form.valid||suitability?.isSuitabile==undefined\" expand=\"block\" size=\"\" color=\"success\" fill=\"solid\" type=\"submit\">\n      {{'mutualFund.SEND_SUBSCRIPTION_ORDER' | translate}}\n    </app-button>\n  </form>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_mutual-funds_mutual-funds-subscribe_mutual-funds-subscribe_module_ts.js.map