## Running
1. Open Chrome canary browser by `nr canary`
2. Go to `chrome://flags` then set 'SameSite by default cookies' to `Disabled`