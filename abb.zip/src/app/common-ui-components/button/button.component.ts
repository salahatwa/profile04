import { Component, OnInit, Input, Output, EventEmitter, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss'],
  // encapsulation: ViewEncapsulation.None
})
export class ButtonComponent implements OnInit {
  @Output() public clickAction: EventEmitter<any> = new EventEmitter();

  // @Input() click:any;
  @Input() disabled:any;
  @Input() expand:any;//"block" | "full" | undefined
  @Input('icon-name') iconName:any;
  @Input('icon-slot') iconSlot: any;//"end" | "icon-only"	| "start"	 
  // @Input('button-type') buttonType: any;//"button" | "reset" | "submit"
  @Input() color: any;
  @Input() download: any;//string | undefined
  @Input() size:any;
  @Input() fill:any;//"clear" | "default" | "outline" | "solid" | undefined
  @Input() shape:any;//"round" | undefined
  @Input() strong:any;//If true, activates a button with a heavier font weight.
  @Input() target:any;//"_blank", "_self", "_parent", "_top" 
  @Input() type:any;//"button" | "reset" | "submit"
  @Input() href:any;
  @Input('ribbon-text') ribbonText:any;//"string"
  @Input('ribbon-color') ribbonColor:any;
  @Input('custom-class') customClass:any;
  
  constructor() { }

  ngOnInit() {}

  // clickOutput() {

  // }

  clicked() {
    this.clickAction.emit();
  }

}
