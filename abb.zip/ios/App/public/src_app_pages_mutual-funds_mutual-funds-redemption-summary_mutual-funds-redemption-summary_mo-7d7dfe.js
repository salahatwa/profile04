"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_mutual-funds_mutual-funds-redemption-summary_mutual-funds-redemption-summary_mo-7d7dfe"],{

/***/ 10347:
/*!**********************************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-redemption-summary/mutual-funds-redemption-summary-routing.module.ts ***!
  \**********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsRedemptionSummaryPageRoutingModule": () => (/* binding */ MutualFundsRedemptionSummaryPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _mutual_funds_redemption_summary_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-funds-redemption-summary.page */ 13521);




const routes = [
    {
        path: '',
        component: _mutual_funds_redemption_summary_page__WEBPACK_IMPORTED_MODULE_0__.MutualFundsRedemptionSummaryPage
    }
];
let MutualFundsRedemptionSummaryPageRoutingModule = class MutualFundsRedemptionSummaryPageRoutingModule {
};
MutualFundsRedemptionSummaryPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MutualFundsRedemptionSummaryPageRoutingModule);



/***/ }),

/***/ 8558:
/*!**************************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-redemption-summary/mutual-funds-redemption-summary.module.ts ***!
  \**************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsRedemptionSummaryPageModule": () => (/* binding */ MutualFundsRedemptionSummaryPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _mutual_funds_redemption_summary_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-funds-redemption-summary-routing.module */ 10347);
/* harmony import */ var _mutual_funds_redemption_summary_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mutual-funds-redemption-summary.page */ 13521);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);









let MutualFundsRedemptionSummaryPageModule = class MutualFundsRedemptionSummaryPageModule {
};
MutualFundsRedemptionSummaryPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _mutual_funds_redemption_summary_routing_module__WEBPACK_IMPORTED_MODULE_0__.MutualFundsRedemptionSummaryPageRoutingModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateModule.forChild()
        ],
        declarations: [_mutual_funds_redemption_summary_page__WEBPACK_IMPORTED_MODULE_1__.MutualFundsRedemptionSummaryPage]
    })
], MutualFundsRedemptionSummaryPageModule);



/***/ }),

/***/ 13521:
/*!************************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-redemption-summary/mutual-funds-redemption-summary.page.ts ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsRedemptionSummaryPage": () => (/* binding */ MutualFundsRedemptionSummaryPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _mutual_funds_redemption_summary_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-funds-redemption-summary.page.html?ngResource */ 43358);
/* harmony import */ var _mutual_funds_redemption_summary_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mutual-funds-redemption-summary.page.scss?ngResource */ 30682);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../providers/mutual-funds.service */ 1835);






let MutualFundsRedemptionSummaryPage = class MutualFundsRedemptionSummaryPage {
    constructor(mutualFundsService, navCtrl) {
        this.mutualFundsService = mutualFundsService;
        this.navCtrl = navCtrl;
        this.terms = false;
        this.submitted = false;
    }
    ngOnInit() {
        this.mutualFund = this.mutualFundsService.getMutualFund();
        console.log(this.mutualFund);
        this.mutualFund.details.subscribe(details => {
            this.mfDetails = details;
            console.log(this.mfDetails);
        });
    }
    addNew() {
        this.navCtrl.navigateBack('main/mutual-funds-details');
    }
    backToHome() {
        this.navCtrl.navigateRoot('main/tabs');
    }
};
MutualFundsRedemptionSummaryPage.ctorParameters = () => [
    { type: _providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_2__.MutualFundsService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController }
];
MutualFundsRedemptionSummaryPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'tadawul-mutual-funds-redemption-summary',
        template: _mutual_funds_redemption_summary_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_mutual_funds_redemption_summary_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__metadata)("design:paramtypes", [_providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_2__.MutualFundsService, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController])
], MutualFundsRedemptionSummaryPage);



/***/ }),

/***/ 1835:
/*!***************************************************!*\
  !*** ./src/app/providers/mutual-funds.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsService": () => (/* binding */ MutualFundsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let MutualFundsService = class MutualFundsService {
    constructor() { }
    setMutualFund(mutualFund) {
        this.mutualFund = mutualFund;
    }
    getMutualFund() {
        return this.mutualFund;
    }
};
MutualFundsService.ctorParameters = () => [];
MutualFundsService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Injectable)({
        providedIn: 'root'
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__metadata)("design:paramtypes", [])
], MutualFundsService);



/***/ }),

/***/ 30682:
/*!*************************************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-redemption-summary/mutual-funds-redemption-summary.page.scss?ngResource ***!
  \*************************************************************************************************************************/
/***/ ((module) => {

module.exports = ".summary-title {\n  color: #2ebd85;\n  display: flex;\n  justify-content: center;\n  flex-direction: column;\n  text-align: center;\n  padding: 32px;\n  align-items: center;\n}\n\n.success-img {\n  width: 33%;\n}\n\n.success-text {\n  font-size: 120%;\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm11dHVhbC1mdW5kcy1yZWRlbXB0aW9uLXN1bW1hcnkucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUFDSjs7QUFFQTtFQUNJLFVBQUE7QUFDSjs7QUFDQTtFQUNJLGVBQUE7RUFDQSxpQkFBQTtBQUVKIiwiZmlsZSI6Im11dHVhbC1mdW5kcy1yZWRlbXB0aW9uLXN1bW1hcnkucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnN1bW1hcnktdGl0bGUge1xuICAgIGNvbG9yOiAjMmViZDg1O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgcGFkZGluZzogMzJweDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuXG4uc3VjY2Vzcy1pbWcge1xuICAgIHdpZHRoOiAzMyU7XG59XG4uc3VjY2Vzcy10ZXh0IHtcbiAgICBmb250LXNpemU6IDEyMCU7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59Il19 */";

/***/ }),

/***/ 43358:
/*!*************************************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-redemption-summary/mutual-funds-redemption-summary.page.html?ngResource ***!
  \*************************************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n    <ion-toolbar color=\"danger\">\n      <ion-buttons slot=\"start\">\n        <ion-back-button text=\"\"></ion-back-button>\n      </ion-buttons>\n      <ion-title slot=\"start\">{{ 'mutualFund..REDEMPTION' | translate }}</ion-title>\n    </ion-toolbar>\n  </ion-header>\n  \n  <ion-content>\n    <div class=\"summary-title\">\n      <img src=\"assets/icon/success.svg\" class=\"success-img\">\n      <div class=\"success-text\">{{'mutualFund.REDEMPTION_REQUEST_SUCCESS_MESSAGE' | translate}}\n      </div>\n    </div>\n  \n    <div class=\"ion-padding\">\n      <ion-text class=\"bold\" color=\"primary\">{{'mutualFund.ORDER_DETAILS' | translate}}</ion-text>\n      <div class=\"box-with-bg bordered ion-margin-bottom\">\n        <ion-row class=\"data-row\">\n          <ion-col size=\"6\">\n            <ion-text class=\"label font-size-caption\" color=\"primary\">{{'mutualFund.PORTFOLIO' | translate}}</ion-text>\n          </ion-col>\n          <ion-col size=\"6\">\n            <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n                {{mutualFund?.portfolio?.name}}\n            </ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"data-row\">\n          <ion-col size=\"6\">\n            <ion-text class=\"label font-size-caption\" color=\"primary\">{{'mutualFund.MUTUAL_FUND' | translate}}</ion-text>\n          </ion-col>\n          <ion-col size=\"6\">\n            <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n                {{mutualFund?.name}}\n            </ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"data-row\">\n          <ion-col size=\"6\">\n            <ion-text class=\"label font-size-caption\" color=\"primary\">{{'mutualFund.REDEMPTION_FEES' | translate}}</ion-text>\n          </ion-col>\n          <ion-col size=\"6\">\n            <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n                {{ mfDetails?.redemptionFees }} {{ mfDetails?.redemptionFeesType }}\n            </ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"data-row\">\n          <ion-col size=\"6\">\n            <ion-text class=\"label font-size-caption\" color=\"primary\">{{'mutualFund.REDEMPTION_UNITS_AMOUNT' | translate}}</ion-text>\n          </ion-col>\n          <ion-col size=\"6\">\n            <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n                {{ mutualFund?.formData.amount }}\n            </ion-text>\n          </ion-col>\n        </ion-row>\n      </div>\n      <app-button\n      (clickAction)=\"addNew()\"\n      expand=\"block\" \n      size=\"\"\n      color=\"success\"\n      fill=\"solid\"\n      type=\"button\"\n      >\n        {{'mutualFund.ADD_NEW_SUBSCRIPTION' | translate}}\n      </app-button>\n      \n      <app-button\n      (clickAction)=\"backToHome()\"\n      expand=\"block\" \n      size=\"\"\n      color=\"medium\"\n      fill=\"outline\"\n      type=\"button\"\n      >\n        {{'mutualFund.BACK_TO_HOME' | translate}}\n      </app-button>\n    </div>\n  </ion-content>\n  ";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_mutual-funds_mutual-funds-redemption-summary_mutual-funds-redemption-summary_mo-7d7dfe.js.map