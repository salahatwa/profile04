import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'tadawul-market-value',
  templateUrl: './market-value.component.html',
  styleUrls: ['./market-value.component.scss'],
})
export class MarketValueComponent implements OnInit {

  @Input() headerOne: string;
  @Input() headerTwo: string;
  @Input() headerThree: string;
  @Input() headerFour: string;
  @Input() valueOne: string;
  @Input() valueTwo: string;
  @Input() valueThree: string;
  @Input() valueFour: string;
  @Input() marketHeaderClass: string;
  @Input() valOneClass: string;
  @Input() valTwoClass: string;
  @Input() marketGridClass: string;
  @Input() valThreeClass: string;
  @Input() valFourClass: string;
  @Input() valueFive: string;

  constructor() { }

  ngOnInit() {}

}
