import { TranslateService } from '@ngx-translate/core';
import { Component, Input, OnInit } from '@angular/core';
import { Translations } from '@inma/helpers/translations';
import { Watchlist, Watchlists } from '@inma/models/watchlist';
import { AlertController, ModalController } from '@ionic/angular';
import { WatchlistTranslations } from 'src/app/pages/watchlists/watchlist.translations';
import { InternetDisconnectTranslations } from '../internet-disconnected/internet-disconnect.translation';
import { ViewEditWatclistDragableModalComponent } from '../view-edit-watclist-dragable-modal/view-edit-watclist-dragable-modal.component';
import { Toast } from '@inma/helpers/toast';

@Component({
  selector: 'tadawul-watchlist-dragable-modal',
  templateUrl: './watchlist-dragable-modal.component.html',
  styleUrls: ['./watchlist-dragable-modal.component.scss'],
})
export class WatchlistDragableModalComponent implements OnInit {
  Watchlists = Watchlists;
  @Translations()
  newWatchlists =[];
  //watchlist: Watchlist;
  @Input() watchListsIds : any;
  @Input() action : string;
  @Input() symbolData :any;

  constructor(private modalControl: ModalController, public translate : TranslateService ,public alertController: AlertController) { }

  ngOnInit() {
    if(this.action == 'addRemove' && this.watchListsIds != null){
      Watchlists.resetCheckedWatchlists();
      for(let i = 0 ; i<this.watchListsIds.length; i++)
        (Watchlists.findByID(this.watchListsIds[i])).subscribe(watchlist => {
           watchlist.checked = true;
        });
    }
    
      }
      


  editWatchlist(){
    if(this.action == 'edit'){this.action = 'select'} else {this.action = 'edit'}
  }

  addSymbolToWatchlists(){
    let addedWatclists = [];
    for(let i = 0; i<this.newWatchlists.length; i++){
      if(this.newWatchlists[i].checked == true){
          addedWatclists.push(this.newWatchlists[i].name);
      };
    }
    //console.log(this.symbolData)
    Watchlists.addSymbolToExistingOrNewWatchlist(addedWatclists,this.symbolData.id,this.symbolData.marketCode).subscribe((obj) => {
      let data = obj
      Toast.present(this.translate.instant('watchlist.SAVED_SUCCESSFULLY'), { class: 'info-alert',duration: 2})
      this.modalControl.dismiss(data);
  });
  }
  
  closeModal(watchlist) {
    const data = watchlist;
    this.modalControl.dismiss(data);
  }

    async presentViewEditWatchlist(watchlist?: any) {
      const modal = await this.modalControl.create({
        component: ViewEditWatclistDragableModalComponent,
        cssClass: 'auto-height-modal ipad-full-width-modal',
        componentProps: {
          watchlistData: watchlist
        },
        swipeToClose: true
        //presentingElement:this.routerOutlet.nativeEl
      });
  
      modal.onDidDismiss()
        .then((data) => {
        
        });
  
      return await modal.present();
    }
  
    watchListClicked(watchlist){
      if(this.action == 'edit'){
        this.presentViewEditWatchlist(watchlist)
      }else if(this.action == 'select'||this.action == undefined){
        this.closeModal(watchlist)
      }else if(this.action == 'addRemove'){
        
      }
    }

  
    async presentAddNewWatchlist() {
      const alert = await this.alertController.create({
        cssClass: 'my-custom-class',
        header: String(this.translate.instant('watchlist.ADD_LIST')),
        inputs: [
          {
            name: 'name',
            type: 'text',
            placeholder: String(this.translate.instant('watchlist.NAME')),
          
          }
        ],
        buttons: [
          {
            text:String(this.translate.instant('watchlist.CANCEL')),
            role: 'cancel',
            cssClass: 'secondary',
            handler: () => {
            },
          },
          {
            text: String(this.translate.instant('watchlist.OK')),
            handler: data => {
              this.newWatchlists.push({'name':data.name, 'checked':true})
            },
          },
        ],
      });
  
      await alert.present();
    }

}
