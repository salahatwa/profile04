import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DisconnectionPagePage } from './disconnection-page.page';

const routes: Routes = [
  {
    path: '',
    component: DisconnectionPagePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DisconnectionPagePageRoutingModule {}
