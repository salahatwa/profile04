import { ChangeDetectorRef, Component, HostBinding, Input, OnInit } from '@angular/core';
import { Translations } from '@inma/helpers/translations';
import { Portfolio } from '@inma/models/portfolio';
import { CommafyPipe } from '../pipes/commafy';
import { ChartTranslations } from './chart.translation';
import fitty from 'fitty';
import * as ApexCharts from 'apexcharts';

@Component({
  selector: 'tadawul-chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.scss'],
})
export class ChartComponent implements OnInit {

  @Translations()
  t = ChartTranslations;

  @HostBinding('class.running') get loaded() {
    return this.changed;
  }
  Commafy = new CommafyPipe();
  Number = Number;
  _portfolio: Portfolio;
  get portfolio(): Portfolio {
    return this._portfolio;
  }
  @Input() set portfolio(p: Portfolio) {
    setTimeout(() => {
      this._portfolio = p;
      setTimeout(() => {        
        this.loadChart();
        this.cdr.detectChanges();
      }, 2000);

    }, 1000);
    // 
    // this.percentage = p.profitLoss / p.portfolioValue;
    // console.log(p.profitLoss / p.portfolioValue);
    // debugger
  }
  
  get cash() {
    return Number(this.portfolio?.portfolioValue - this.portfolio?.marketValue);
  }

  get units() {
    return Number(this.portfolio?.marketValue);
  }
  get percentage() {
    // Units = (por.marketValue | commafy) || 0
    // Cash = ((portfolio.portfolioValue - por.marketValue) | commafy:'number':2) || 0
    if (!(this.cash + this.units)) return '0';

    // let profitLoss = this.portfolio?.profitLoss.replaceAll(',', '');
    let percentage = 100 * (this.units / (this.cash + this.units));

    if (!percentage) return '0';
    return percentage?.toString() || '0';
  };


  get isBordersVisible() {
    let p = Math.abs(Number(this.percentage));
    return  p > 2 && p < 98;
  }

  
  Math = Math;
  _lastPortfolioCost;
  changed = false;
  ngDoCheck() {
    // if (this.portfolio) debugger;
    if (this.portfolioCost != this._lastPortfolioCost && (Number(this.portfolioCost) > 0 || this.portfolioCost == '0')) {
      setTimeout(() => {
        this.changed = true;
      }, 100);
      this._lastPortfolioCost = this.portfolioCost;
    }
  }

  get portfolioCost() {
    return this.portfolio?.portfolioCost;
  }
  constructor(private cdr: ChangeDetectorRef) { }

  ngOnInit() {
    setTimeout(() => {
      fitty('#text-container #value #value-text', {
        minSize: 8,
        maxSize: 32,
        multiLine: false
      });
    }, 0)
  }

  loadChart() {
    var options = {
      series: [Number(this.cash), Number(this.units)],
      colors: ['#cddcdd', '#fc0', '#cddcdd', '#fc0', '#cddcdd', '#fc0'],
      chart: {
        height: 100,
        type: 'donut',
      },
      dataLabels: {
        enabled: false,
      },
      fill: {
      },
      plotOptions: {
        pie: {
          donut: {
            size: '70%',
            labels: {}
          }
        }
      },
      legend: {
        show: false
      }, stroke: {
        show: false,
        width: 0
      },
    };

    var chart = new ApexCharts(document.querySelector('#chart_' + this._portfolio.id), options);
    chart.render();
  }

}

