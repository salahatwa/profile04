"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_transfer_transfer_module_ts"],{

/***/ 14299:
/*!*******************************************************!*\
  !*** ./src/app/pages/transfer/home/home.component.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeComponent": () => (/* binding */ HomeComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _home_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.component.html?ngResource */ 44095);
/* harmony import */ var _home_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.component.scss?ngResource */ 32739);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _inma_models_transfers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/models/transfers */ 39494);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _inma_helpers_dialogs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/helpers/dialogs */ 66695);










let HomeComponent = class HomeComponent {
    constructor(router, sharedData, translate, navCtrl, modalController) {
        this.router = router;
        this.sharedData = sharedData;
        this.translate = translate;
        this.navCtrl = navCtrl;
        this.modalController = modalController;
        this.selectedTab = 2;
        this.secondSelectLable = this.translate.instant('transfer.toAccount');
        this.secondSelectHeader = this.translate.instant('transfer.accounts');
        this.accountsArr = [];
        this.beneficiariesArr = [];
        this.firstSelectArr = [];
        this.secondSelectArr = [];
        // public toAccountLabel : any;
        this.fundType = "2";
        this.funds = [];
        this.firstIban = "";
        this.secondIban = "";
        this.showIban = false;
        this.showAmountHint = true;
    }
    ngOnInit() {
        //   this.getTransferTypes();
        //  // this.getBeneficiaries();
        //   this.redirectFromSummary();
    }
    ionViewWillEnter() {
        this.getTransferTypes();
        // this.getBeneficiaries();
        let edit = this.sharedData.getSharedData('editTransfer');
        if (edit) {
            this.redirectFromSummary();
        }
        else {
            this.resetInput();
        }
    }
    // buildForm() {
    //   const englishOnlyTester = /^[^\u0621-\u064A\u0660-\u0669]*$/;
    //   this.form = this.formBuilder.group({
    //     username: [
    //       '', Validators.compose([
    //         Validators.pattern(englishOnlyTester),
    //         Validators.required
    //       ])
    //     ],
    //     password: [
    //       '', Validators.compose([
    //         Validators.required
    //       ])
    //     ]
    //   });
    // }
    resetInput() {
        this.amount = null;
        this.memo = null;
        this.fromAccount = null;
        this.firstSelectedAccount = null;
        this.secondSelectedAccount = null;
        this.selectedTab = 2;
        if (this.selectedTab == 1) {
            this.secondSelectLable = this.translate.instant('transfer.toAccount');
            this.secondSelectHeader = this.translate.instant('transfer.accounts');
            this.firstSelectChange();
        }
        else {
            this.secondSelectLable = this.translate.instant('transfer.toBeneficiary');
            this.secondSelectHeader = this.translate.instant('transfer.beneficiaries');
            this.secondSelectArr = this.beneficiariesArr;
        }
        this.toAccount = null;
        //this.secondSelectChange();
    }
    redirectFromSummary() {
        this.summaryPageObj = this.sharedData.getSharedData("sharedSummaryPageObj");
        if (this.summaryPageObj) {
            this.amount = this.summaryPageObj.amount;
            this.memo = this.summaryPageObj.memo;
            this.fromAccount = this.summaryPageObj.fromAccount.accountValue;
            this.firstSelectedAccount = this.summaryPageObj.fromAccount;
            this.secondSelectedAccount = this.summaryPageObj.toAccount;
            this.selectedTab = this.summaryPageObj.selctedFund;
            if (this.selectedTab == 1) {
                this.secondSelectLable = this.translate.instant('transfer.toAccount');
                this.secondSelectHeader = this.translate.instant('transfer.accounts');
                this.firstSelectChange();
            }
            else {
                this.secondSelectLable = this.translate.instant('transfer.toBeneficiary');
                this.secondSelectHeader = this.translate.instant('transfer.beneficiaries');
                this.secondSelectArr = this.beneficiariesArr;
            }
            this.toAccount = this.summaryPageObj.toAccount.accountValue;
            //this.secondSelectChange();
        }
    }
    openSummary() {
        this.router.navigate(['main/transfer/summary']);
    }
    getTransferTypes() {
        _inma_models_transfers__WEBPACK_IMPORTED_MODULE_2__.Transfers.fundTypes.subscribe(fundTypes => {
            console.log('fundTypes>>>>>>>' + fundTypes);
            this.funds = fundTypes;
            this.getAccounts(this.funds[1].id);
            this.getBeneficiaries(this.funds[1].id);
        });
    }
    getAccounts(fundType) {
        _inma_models_transfers__WEBPACK_IMPORTED_MODULE_2__.Transfers.getAccounts(fundType).subscribe(accounts => {
            // debugger
            // this.fromAccounts = accounts;
            // this.onFromAccountSelected();
            console.log('accounts>>>>>>>' + accounts);
            for (let i = 0; i < accounts.length; i++) {
                if (accounts[i].accountValue == "") {
                    accounts.splice(i, 1);
                }
            }
            this.accountsArr = accounts;
            this.firstSelectArr = this.accountsArr;
            // this.secondSelectArr =  this.accountsArr;
        });
    }
    getBeneficiaries(fundType) {
        _inma_models_transfers__WEBPACK_IMPORTED_MODULE_2__.Transfers.getBeneficiaries(fundType).subscribe(beneficiaries => {
            // this.toAccounts = beneficiaries;
            console.log('beneficiaries>>>>>>' + beneficiaries);
            for (let i = 0; i < beneficiaries.length; i++) {
                if (beneficiaries[i].accountValue == "") {
                    beneficiaries.splice(i, 1);
                }
            }
            this.beneficiariesArr = beneficiaries;
            this.secondSelectArr = this.beneficiariesArr;
        });
    }
    changeFund(type) {
        console.log(type, "selected type");
        this.fromAccount = "";
        this.toAccount = "";
        this.amount = null;
        if (type == "1") {
            this.selectedTab = 1;
            this.secondSelectLable = this.translate.instant('transfer.toAccount');
            this.secondSelectHeader = this.translate.instant('transfer.accounts');
            console.log("MF");
            this.getAccounts(this.funds[0].id);
            console.log(this.funds[0].id, "ID getAccounts");
            this.showIban = true;
            // this.secondSelectArr = this.accountsArr;
        }
        else if (type == "2") {
            this.selectedTab = 2;
            console.log("CA");
            this.getAccounts(this.funds[1].id);
            console.log(this.funds[1].id, "ID getAccounts");
            this.getBeneficiaries(this.funds[1].id);
            this.secondSelectLable = this.translate.instant('transfer.toBeneficiary');
            this.secondSelectHeader = this.translate.instant('transfer.beneficiaries');
            this.secondSelectArr = this.beneficiariesArr;
            this.fromAccount = this.firstSelectArr[0].accountValue;
            this.toAccount = this.secondSelectArr[0].accountValue;
            this.showIban = false;
        }
    }
    firstSelectChange() {
        // this.toAccountLabel = "";
        if (this.selectedTab == 1 && this.fromAccount != "") {
            this.toAccount = "";
            this.secondSelectArr = [];
            for (let i = 0; i < this.firstSelectArr.length; i++) {
                if (this.firstSelectArr[i].accountValue != this.fromAccount) {
                    this.secondSelectArr.push(this.firstSelectArr[i]);
                }
            }
        }
        for (let i = 0; i < this.firstSelectArr.length; i++) {
            if (this.firstSelectArr[i].accountValue == this.fromAccount) {
                this.firstIban = this.firstSelectArr[i].additionDisplayData;
                this.firstSelectedAccount = this.firstSelectArr[i];
            }
        }
    }
    secondSelectChange() {
        for (let i = 0; i < this.secondSelectArr.length; i++) {
            if (this.secondSelectArr[i].accountValue == this.toAccount) {
                this.secondIban = this.secondSelectArr[i].additionDisplayData;
                this.secondSelectedAccount = this.secondSelectArr[i];
            }
        }
    }
    goToSummaryPage() {
        if (this.showAmountHint == false) {
            return false;
        }
        if (this.toAccount == "" || this.fromAccount == "" || this.memo == "" || this.amount == null) {
            // alert("الرجاء إدخال جميع البيانات");
            _inma_helpers_dialogs__WEBPACK_IMPORTED_MODULE_4__.Dialogs.alert(this.translate.instant('transfer.REQUIREDFIELDS')).subscribe(ok => {
            });
            return false;
        }
        let fundName = "";
        if (this.selectedTab == 1) {
            fundName = this.funds[0].name;
            // this.toAccount = this.secondSelectedAccount.accountValue;
        }
        else {
            fundName = this.funds[1].name;
            // this.toAccount = this.secondSelectedAccount.accountLabel;
        }
        ;
        this.summaryPageObj = { 'toAccount': this.secondSelectedAccount, 'fromAccount': this.firstSelectedAccount, 'memo': this.memo, 'amount': this.amount, 'fundName': fundName, "selctedFund": this.selectedTab };
        console.log(this.summaryPageObj["selctedFund"]);
        debugger;
        this.sharedData.setSharedData(this.summaryPageObj, 'sharedSummaryPageObj');
        // this.router.navigate(['transfer/summary']);
        // this.navCtrl.navigateRoot('transfer/summary', { animated: true });
        this.navCtrl.navigateForward('main/transfer/summary', { animated: true });
    }
    checkAmount(amount) {
        if (amount > this.firstSelectedAccount.accountBalance) {
            this.showAmountHint = false;
        }
        else {
            this.showAmountHint = true;
        }
    }
};
HomeComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_3__.SharedDataService },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController }
];
HomeComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-home',
        template: _home_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_home_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__metadata)("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router, src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_3__.SharedDataService, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateService, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController])
], HomeComponent);



/***/ }),

/***/ 95131:
/*!*************************************************************!*\
  !*** ./src/app/pages/transfer/success/success.component.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SuccessComponent": () => (/* binding */ SuccessComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _success_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./success.component.html?ngResource */ 86056);
/* harmony import */ var _success_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./success.component.scss?ngResource */ 42278);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_providers_share_screenshot_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/providers/share-screenshot.service */ 92802);









// import {domtoimage} from 'dom-to-image';
let SuccessComponent = class SuccessComponent {
    constructor(router, translate, sharedData, navCtrl, shareScreenshotService) {
        this.router = router;
        this.translate = translate;
        this.sharedData = sharedData;
        this.navCtrl = navCtrl;
        this.shareScreenshotService = shareScreenshotService;
        this.transferTo = this.translate.instant('transfer.toAccount');
    }
    ngOnInit() {
        this.summaryObj = this.sharedData.getSharedData("sharedSummaryPageObj");
        if (this.summaryObj.selctedFund == 1) {
            this.transferTo = this.translate.instant('transfer.toAccount');
        }
        else {
            this.transferTo = this.translate.instant('transfer.toBeneficiary');
        }
    }
    newTransfer() {
        //this.router.navigate(['transfer/home']);
        this.navCtrl.navigateRoot('main/transfer/transfer-home', { animated: true });
    }
    backToHome() {
        // this.router.navigate(['tadawul-home/home']);
        this.navCtrl.navigateRoot('main/tabs', { animated: true });
    }
    shareScreenshot() {
        let data = [
            { key: this.translate.instant('transfer.transferType'), value: this.summaryObj.fundName },
            { key: this.translate.instant('transfer.fromAccount'), value: this.summaryObj.fromAccount.accountLabel },
            { key: this.transferTo, value: this.summaryObj.toAccount.accountLabel },
            { key: this.translate.instant('transfer.amount'), value: this.summaryObj.amount },
            { key: this.translate.instant('transfer.referanceNumber'), value: this.summaryObj.referenceNumber },
            { key: this.translate.instant('transfer.date'), value: this.summaryObj.date }
        ];
        this.shareScreenshotService.createModal(data);
    }
};
SuccessComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslateService },
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_2__.SharedDataService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController },
    { type: src_app_providers_share_screenshot_service__WEBPACK_IMPORTED_MODULE_3__.ShareScreenshotService }
];
SuccessComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-success',
        template: _success_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_success_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__metadata)("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_4__.Router, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslateService, src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_2__.SharedDataService, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController, src_app_providers_share_screenshot_service__WEBPACK_IMPORTED_MODULE_3__.ShareScreenshotService])
], SuccessComponent);



/***/ }),

/***/ 28705:
/*!*************************************************************!*\
  !*** ./src/app/pages/transfer/summary/summary.component.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SummaryComponent": () => (/* binding */ SummaryComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _summary_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./summary.component.html?ngResource */ 4670);
/* harmony import */ var _summary_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./summary.component.scss?ngResource */ 87038);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var _inma_models_transfers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/models/transfers */ 39494);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ionic_native_vibration_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/vibration/ngx */ 59076);










let SummaryComponent = class SummaryComponent {
    constructor(router, translate, sharedData, navCtrl, vibration) {
        this.router = router;
        this.translate = translate;
        this.sharedData = sharedData;
        this.navCtrl = navCtrl;
        this.vibration = vibration;
        this.transferTo = this.translate.instant('transfer.toAccount');
        this.showLoader = false;
    }
    ngOnInit() {
        this.summaryObj = this.sharedData.getSharedData("sharedSummaryPageObj", false);
        if (this.summaryObj.selctedFund == 1) {
            this.transferTo = this.translate.instant('transfer.toAccount');
        }
        else {
            this.transferTo = this.translate.instant('transfer.toBeneficiary');
        }
    }
    transfer() {
        this.showLoader = true;
        _inma_models_transfers__WEBPACK_IMPORTED_MODULE_3__.Transfers.checkFundTransfer(this.summaryObj.selctedFund, this.summaryObj.fromAccount.accountValue, this.summaryObj.toAccount.accountValue, this.summaryObj.amount, "SAR", this.summaryObj.memo).subscribe({
            next: result => {
                let transferResult = result.status;
                // if (transferResult == "1") {
                //  let result: any = result;
                this.summaryObj.beneficiaryBank = result.beneficiaryBank;
                this.summaryObj.fees = result.fee.feeAmount.amountValue + " " + result.fee.feeAmount.curCode;
                this.summaryObj.date = result.transactionDate;
                // this.summaryObj.referenceNumber = result.transactionNumber;
                // this.showLoader = false;
                // this.vibration.vibrate(250);
                // this.router.navigate(['main/transfer/success'])
                _inma_models_transfers__WEBPACK_IMPORTED_MODULE_3__.Transfers.authenticateTransfer()
                    .subscribe({
                    next: response => {
                        this.summaryObj.referenceNumber = response;
                        this.showLoader = false;
                        this.vibration.vibrate(250);
                        this.router.navigate(['main/transfer/success']);
                    },
                    error: error => {
                        this.showLoader = false;
                    }
                });
                //  }
            },
            // error: error => {
            //   this.loadingModal.dismiss();
            // }
        });
    }
    openSuccess() {
    }
    cancel() {
        this.sharedData.getSharedData("sharedSummaryPageObj");
        this.navCtrl.navigateRoot('main/tabs', { animated: true });
    }
    modifyRequest() {
        //this.router.navigate(['transfer/home']);
        //  this.navCtrl.navigateRoot('transfer/home', { animated: true });
        this.sharedData.setSharedData(true, "editTransfer");
        this.navCtrl.navigateBack('main/transfer/transfer-home', { animated: true });
    }
    changePeriod(arg) {
    }
};
SummaryComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateService },
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_2__.SharedDataService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController },
    { type: _ionic_native_vibration_ngx__WEBPACK_IMPORTED_MODULE_4__.Vibration }
];
SummaryComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-summary',
        template: _summary_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_summary_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__metadata)("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateService, src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_2__.SharedDataService,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController, _ionic_native_vibration_ngx__WEBPACK_IMPORTED_MODULE_4__.Vibration])
], SummaryComponent);



/***/ }),

/***/ 80322:
/*!*************************************************************************!*\
  !*** ./src/app/pages/transfer/transfer-home/transfer-home.component.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TransferHomeComponent": () => (/* binding */ TransferHomeComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _transfer_home_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./transfer-home.component.html?ngResource */ 79036);
/* harmony import */ var _transfer_home_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./transfer-home.component.scss?ngResource */ 98569);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _inma_models_transfers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/models/transfers */ 39494);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _inma_helpers_dialogs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/helpers/dialogs */ 66695);










let TransferHomeComponent = class TransferHomeComponent {
    constructor(router, translate, sharedData, navCtrl, modalController) {
        this.router = router;
        this.translate = translate;
        this.sharedData = sharedData;
        this.navCtrl = navCtrl;
        this.modalController = modalController;
        this.selectedTab = 2;
        this.secondSelectLable = this.translate.instant('transfer.toAccount');
        this.secondSelectHeader = this.translate.instant('transfer.accounts');
        this.accountsArr = [];
        this.beneficiariesArr = [];
        this.firstSelectArr = [];
        this.secondSelectArr = [];
        // public toAccountLabel : any;
        this.fundType = "2";
        this.funds = [];
        this.firstIban = "";
        this.secondIban = "";
        this.showIban = false;
        this.showAmountHint = true;
        this.showLoader = false;
    }
    ngOnInit() {
        //   this.getTransferTypes();
        //  // this.getBeneficiaries();
        //   this.redirectFromSummary();
    }
    ionViewWillEnter() {
        this.getTransferTypes();
        // this.getBeneficiaries();
        let edit = this.sharedData.getSharedData('editTransfer');
        if (edit) {
            this.redirectFromSummary();
        }
        else {
            this.resetInput();
        }
    }
    // buildForm() {
    //   const englishOnlyTester = /^[^\u0621-\u064A\u0660-\u0669]*$/;
    //   this.form = this.formBuilder.group({
    //     username: [
    //       '', Validators.compose([
    //         Validators.pattern(englishOnlyTester),
    //         Validators.required
    //       ])
    //     ],
    //     password: [
    //       '', Validators.compose([
    //         Validators.required
    //       ])
    //     ]
    //   });
    // }
    resetInput() {
        this.amount = null;
        this.memo = null;
        this.fromAccount = null;
        this.firstSelectedAccount = null;
        this.secondSelectedAccount = null;
        this.selectedTab = 2;
        if (this.selectedTab == 1) {
            this.secondSelectLable = this.translate.instant('transfer.toAccount');
            this.secondSelectHeader = this.translate.instant('transfer.accounts');
            this.firstSelectChange();
        }
        else {
            this.secondSelectLable = this.translate.instant('transfer.toBeneficiary');
            this.secondSelectHeader = this.translate.instant('transfer.beneficiaries');
            this.secondSelectArr = this.beneficiariesArr;
        }
        this.toAccount = null;
        //this.secondSelectChange();
    }
    redirectFromSummary() {
        this.summaryPageObj = this.sharedData.getSharedData("sharedSummaryPageObj");
        if (this.summaryPageObj) {
            this.amount = this.summaryPageObj.amount;
            this.memo = this.summaryPageObj.memo;
            this.fromAccount = this.summaryPageObj.fromAccount.accountValue;
            this.firstSelectedAccount = this.summaryPageObj.fromAccount;
            this.secondSelectedAccount = this.summaryPageObj.toAccount;
            this.selectedTab = this.summaryPageObj.selctedFund;
            if (this.selectedTab == 1) {
                this.secondSelectLable = this.translate.instant('transfer.toAccount');
                this.secondSelectHeader = this.translate.instant('transfer.accounts');
                this.firstSelectChange();
            }
            else {
                this.secondSelectLable = this.translate.instant('transfer.toBeneficiary');
                this.secondSelectHeader = this.translate.instant('transfer.beneficiaries');
                this.secondSelectArr = this.beneficiariesArr;
            }
            this.toAccount = this.summaryPageObj.toAccount.accountValue;
            //this.secondSelectChange();
        }
    }
    openSummary() {
        this.router.navigate(['main/transfer/summary']);
    }
    getTransferTypes() {
        _inma_models_transfers__WEBPACK_IMPORTED_MODULE_2__.Transfers.fundTypes.subscribe(fundTypes => {
            console.log('fundTypes>>>>>>>' + fundTypes);
            this.funds = fundTypes;
            this.getAccounts(this.funds[1].id);
            this.getBeneficiaries(this.funds[1].id);
        });
    }
    getAccounts(fundType) {
        this.showLoader = true;
        _inma_models_transfers__WEBPACK_IMPORTED_MODULE_2__.Transfers.getAccounts(fundType).subscribe(accounts => {
            this.showLoader = false;
            // debugger
            // this.fromAccounts = accounts;
            // this.onFromAccountSelected();
            console.log('accounts>>>>>>>' + accounts);
            for (let i = 0; i < accounts.length; i++) {
                if (accounts[i].accountValue == "") {
                    accounts.splice(i, 1);
                }
            }
            this.accountsArr = accounts;
            this.firstSelectArr = this.accountsArr;
            // this.secondSelectArr =  this.accountsArr;
        });
    }
    getBeneficiaries(fundType) {
        _inma_models_transfers__WEBPACK_IMPORTED_MODULE_2__.Transfers.getBeneficiaries(fundType).subscribe(beneficiaries => {
            // this.toAccounts = beneficiaries;
            console.log('beneficiaries>>>>>>' + beneficiaries);
            for (let i = 0; i < beneficiaries.length; i++) {
                if (beneficiaries[i].accountValue == "") {
                    beneficiaries.splice(i, 1);
                }
            }
            this.beneficiariesArr = beneficiaries;
            this.secondSelectArr = this.beneficiariesArr;
        });
    }
    changeFund(type) {
        this.firstSelectArr = [];
        this.secondSelectArr = [];
        this.fromAccount = "";
        this.toAccount = "";
        this.amount = null;
        if (type == "1") {
            this.selectedTab = 1;
            this.secondSelectLable = this.translate.instant('transfer.toAccount');
            this.secondSelectHeader = this.translate.instant('transfer.accounts');
            this.getAccounts(this.funds[0].id);
            this.showIban = true;
            // this.secondSelectArr = this.accountsArr;
        }
        else if (type == "2") {
            this.selectedTab = 2;
            this.getAccounts(this.funds[1].id);
            this.getBeneficiaries(this.funds[1].id);
            this.secondSelectLable = this.translate.instant('transfer.toBeneficiary');
            this.secondSelectHeader = this.translate.instant('transfer.beneficiaries');
            this.secondSelectArr = this.beneficiariesArr;
            this.fromAccount = this.firstSelectArr[0].accountValue;
            this.toAccount = this.secondSelectArr[0].accountValue;
            this.showIban = false;
        }
    }
    firstSelectChange() {
        // this.toAccountLabel = "";
        if (this.selectedTab == 1 && this.fromAccount != "") {
            this.toAccount = "";
            this.secondSelectArr = [];
            for (let i = 0; i < this.firstSelectArr.length; i++) {
                if (this.firstSelectArr[i].accountValue != this.fromAccount) {
                    this.secondSelectArr.push(this.firstSelectArr[i]);
                }
            }
        }
        for (let i = 0; i < this.firstSelectArr.length; i++) {
            if (this.firstSelectArr[i].accountValue == this.fromAccount) {
                this.firstIban = this.firstSelectArr[i].additionDisplayData;
                this.firstSelectedAccount = this.firstSelectArr[i];
            }
        }
    }
    secondSelectChange() {
        for (let i = 0; i < this.secondSelectArr.length; i++) {
            if (this.secondSelectArr[i].accountValue == this.toAccount) {
                this.secondIban = this.secondSelectArr[i].additionDisplayData;
                this.secondSelectedAccount = this.secondSelectArr[i];
            }
        }
    }
    goToSummaryPage() {
        if (this.showAmountHint == false) {
            return false;
        }
        if (this.toAccount == "" || this.fromAccount == "" || this.memo == "" || this.amount == null) {
            //alert("الرجاء إدخال جميع البيانات");
            _inma_helpers_dialogs__WEBPACK_IMPORTED_MODULE_4__.Dialogs.alert(this.translate.instant('transfer.REQUIREDFIELDS')).subscribe(ok => {
            });
            return false;
        }
        let fundName = "";
        if (this.selectedTab == 1) {
            fundName = this.funds[0].name;
            // this.toAccount = this.secondSelectedAccount.accountValue;
        }
        else {
            fundName = this.funds[1].name;
            // this.toAccount = this.secondSelectedAccount.accountLabel;
        }
        ;
        this.summaryPageObj = { 'toAccount': this.secondSelectedAccount, 'fromAccount': this.firstSelectedAccount, 'memo': this.memo, 'amount': this.amount, 'fundName': fundName, "selctedFund": this.selectedTab };
        console.log(this.summaryPageObj["selctedFund"]);
        this.sharedData.setSharedData(this.summaryPageObj, 'sharedSummaryPageObj');
        // this.router.navigate(['transfer/summary']);
        // this.navCtrl.navigateRoot('transfer/summary', { animated: true });
        this.navCtrl.navigateForward('main/transfer/summary', { animated: true });
    }
    checkAmount(amount) {
        if (amount > this.firstSelectedAccount.accountBalance) {
            this.showAmountHint = false;
        }
        else {
            this.showAmountHint = true;
        }
    }
};
TransferHomeComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateService },
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_3__.SharedDataService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController }
];
TransferHomeComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'tadawul-transfer-home',
        template: _transfer_home_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_transfer_home_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__metadata)("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateService, src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_3__.SharedDataService, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController])
], TransferHomeComponent);



/***/ }),

/***/ 27253:
/*!***********************************************************!*\
  !*** ./src/app/pages/transfer/transfer-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TransferPageRoutingModule": () => (/* binding */ TransferPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _transfer_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./transfer.page */ 45642);
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home/home.component */ 14299);
/* harmony import */ var _summary_summary_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./summary/summary.component */ 28705);
/* harmony import */ var _success_success_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./success/success.component */ 95131);
/* harmony import */ var _transfer_home_transfer_home_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./transfer-home/transfer-home.component */ 80322);








const routes = [
    {
        path: '',
        component: _transfer_page__WEBPACK_IMPORTED_MODULE_0__.TransferPage
    },
    {
        path: 'home',
        component: _home_home_component__WEBPACK_IMPORTED_MODULE_1__.HomeComponent
    },
    {
        path: 'summary',
        component: _summary_summary_component__WEBPACK_IMPORTED_MODULE_2__.SummaryComponent
    },
    {
        path: 'success',
        component: _success_success_component__WEBPACK_IMPORTED_MODULE_3__.SuccessComponent
    },
    {
        path: 'transfer-home',
        component: _transfer_home_transfer_home_component__WEBPACK_IMPORTED_MODULE_4__.TransferHomeComponent
    }
];
let TransferPageRoutingModule = class TransferPageRoutingModule {
};
TransferPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_7__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_7__.RouterModule],
    })
], TransferPageRoutingModule);



/***/ }),

/***/ 73254:
/*!***************************************************!*\
  !*** ./src/app/pages/transfer/transfer.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TransferPageModule": () => (/* binding */ TransferPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _transfer_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./transfer-routing.module */ 27253);
/* harmony import */ var _transfer_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./transfer.page */ 45642);
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./home/home.component */ 14299);
/* harmony import */ var _summary_summary_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./summary/summary.component */ 28705);
/* harmony import */ var _success_success_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./success/success.component */ 95131);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);
/* harmony import */ var _transfer_home_transfer_home_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./transfer-home/transfer-home.component */ 80322);













let TransferPageModule = class TransferPageModule {
};
TransferPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_9__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonicModule,
            _transfer_routing_module__WEBPACK_IMPORTED_MODULE_0__.TransferPageRoutingModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__.TranslateModule.forChild(),
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_5__.TadawulCommonUiModule
        ],
        declarations: [_transfer_page__WEBPACK_IMPORTED_MODULE_1__.TransferPage, _home_home_component__WEBPACK_IMPORTED_MODULE_2__.HomeComponent, _summary_summary_component__WEBPACK_IMPORTED_MODULE_3__.SummaryComponent, _success_success_component__WEBPACK_IMPORTED_MODULE_4__.SuccessComponent, _transfer_home_transfer_home_component__WEBPACK_IMPORTED_MODULE_6__.TransferHomeComponent],
        exports: [_home_home_component__WEBPACK_IMPORTED_MODULE_2__.HomeComponent, _summary_summary_component__WEBPACK_IMPORTED_MODULE_3__.SummaryComponent, _success_success_component__WEBPACK_IMPORTED_MODULE_4__.SuccessComponent, _transfer_home_transfer_home_component__WEBPACK_IMPORTED_MODULE_6__.TransferHomeComponent]
    })
], TransferPageModule);



/***/ }),

/***/ 45642:
/*!*************************************************!*\
  !*** ./src/app/pages/transfer/transfer.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TransferPage": () => (/* binding */ TransferPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _transfer_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./transfer.page.html?ngResource */ 73462);
/* harmony import */ var _transfer_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./transfer.page.scss?ngResource */ 40307);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let TransferPage = class TransferPage {
    constructor() { }
    ngOnInit() {
    }
};
TransferPage.ctorParameters = () => [];
TransferPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-transfer',
        template: _transfer_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_transfer_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:paramtypes", [])
], TransferPage);



/***/ }),

/***/ 39494:
/*!*********************************************!*\
  !*** ./src/app/🌱models/transfers/index.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccountType": () => (/* reexport safe */ _transfers_model__WEBPACK_IMPORTED_MODULE_0__.AccountType),
/* harmony export */   "Accounts": () => (/* reexport safe */ _transfers_model__WEBPACK_IMPORTED_MODULE_0__.Accounts),
/* harmony export */   "BeneficiaryType": () => (/* reexport safe */ _transfers_model__WEBPACK_IMPORTED_MODULE_0__.BeneficiaryType),
/* harmony export */   "FundTransferSummary": () => (/* reexport safe */ _transfers_model__WEBPACK_IMPORTED_MODULE_0__.FundTransferSummary),
/* harmony export */   "FundType": () => (/* reexport safe */ _transfers_model__WEBPACK_IMPORTED_MODULE_0__.FundType),
/* harmony export */   "FundTypes": () => (/* reexport safe */ _transfers_model__WEBPACK_IMPORTED_MODULE_0__.FundTypes),
/* harmony export */   "Transfers": () => (/* reexport safe */ _transfers_model__WEBPACK_IMPORTED_MODULE_0__.Transfers),
/* harmony export */   "TransfersModel": () => (/* reexport safe */ _transfers_model__WEBPACK_IMPORTED_MODULE_0__.TransfersModel)
/* harmony export */ });
/* harmony import */ var _transfers_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./transfers.model */ 69334);



/***/ }),

/***/ 69334:
/*!*******************************************************!*\
  !*** ./src/app/🌱models/transfers/transfers.model.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccountType": () => (/* binding */ AccountType),
/* harmony export */   "Accounts": () => (/* binding */ Accounts),
/* harmony export */   "BeneficiaryType": () => (/* binding */ BeneficiaryType),
/* harmony export */   "FundTransferSummary": () => (/* binding */ FundTransferSummary),
/* harmony export */   "FundType": () => (/* binding */ FundType),
/* harmony export */   "FundTypes": () => (/* binding */ FundTypes),
/* harmony export */   "Transfers": () => (/* binding */ Transfers),
/* harmony export */   "TransfersModel": () => (/* binding */ TransfersModel)
/* harmony export */ });
/* harmony import */ var _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/helpers/http */ 36802);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 64139);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var _users_authentication__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../users/authentication */ 93143);
/* harmony import */ var _portfolio__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../portfolio */ 65082);





class FundType {
    constructor(options) {
        this.id = options.id;
        this.name = options.value;
    }
}
class BeneficiaryType {
}
class AccountType {
}
var FundTypes;
(function (FundTypes) {
    FundTypes["ToAccount"] = "1";
    FundTypes["ToBeneficiary"] = "2";
})(FundTypes || (FundTypes = {}));
class Accounts {
    constructor(options) {
        if (options instanceof AccountType) {
            this.accountLabel = options.accountLabel;
            this.accountValue = options.accountValue;
            this.accountBalance = options.accountBalance;
        }
        else if (options instanceof BeneficiaryType) {
            this.accountLabel = options.beneficiaryLabel;
            this.accountValue = options.beneficiaryValue;
        }
        this.additionDisplayData = options.additionDisplayData;
        this.currencyCode = options.currencyCode;
        this.currencyValue = options.currencyValue;
        this.type = {
            code: options.accountTypeCode,
            label: options.accountTypeLabel,
        };
    }
}
class FundTransferSummary {
    constructor(options) {
        if (options) {
            this.fundType = options.fundType;
            this.fromAccount = options.fromAccount;
            this.targetAccount = options.targetAccount;
            this.amount = options.amount;
            this.currency = options.currency;
            this.memo = options.memo;
            this.date = options.date;
            this.fees = options.fees;
            this.beneficiaryBank = options.beneficiaryBank;
            this.referenceNumber = options.referenceNumber;
        }
    }
}
class TransfersModel {
    get fundTypes() {
        // if (this.cachedFundTypes) return of(this.cachedFundTypes);
        // else
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request("/accounts/FundTransfers/loadFundTypes").pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)((result) => {
            this.cachedFundTypes = new Array();
            for (const fundType of result)
                this.cachedFundTypes.push(new FundType(fundType));
            return this.cachedFundTypes;
        }));
    }
    getAccounts(fundType) {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request("/accounts/FundTransfers/getAccounts", { fundType: fundType }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)((result) => {
            const accounts = new Array();
            for (let _account of result) {
                let a = new AccountType();
                Object.assign(a, _account);
                accounts.push(new Accounts(a));
            }
            return accounts;
        }));
    }
    getBeneficiaries(fundType) {
        if (this.beneficiaries)
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)(this.beneficiaries);
        else
            return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request("/accounts/FundTransfers/getBeneficiaries", { fundType }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)((result) => {
                this.beneficiaries = new Array();
                for (let _beneficiary of result) {
                    let b = new BeneficiaryType();
                    Object.assign(b, _beneficiary);
                    this.beneficiaries.push(new Accounts(b));
                }
                return this.beneficiaries;
            }));
    }
    checkFundTransfer(fundType, fromAccount, toAccount, amount, currency, memo) {
        let params = {
            fundType: fundType === null || fundType === void 0 ? void 0 : fundType.toString(),
            fromAccountNumber: fromAccount === null || fromAccount === void 0 ? void 0 : fromAccount.toString(),
            amount: amount === null || amount === void 0 ? void 0 : amount.toString(),
            currencyCode: currency === null || currency === void 0 ? void 0 : currency.toString(),
            memo: (memo === null || memo === void 0 ? void 0 : memo.toString()) || "",
        };
        if (fundType == FundTypes.ToAccount)
            params["targetAccountNumber"] = toAccount;
        else if (fundType == FundTypes.ToBeneficiary)
            params["toBeneficiary"] = toAccount;
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request("/accounts/FundTransfers/checkFundTransfer", params).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)((response) => {
            return response;
        }));
    }
    authenticateTransfer() {
        // let subject = new Subject<string>();
        // return subject.asObservable();
        // return of("635274764334");
        return _users_authentication__WEBPACK_IMPORTED_MODULE_1__.Authentication2.start("accounts", "FundTransfers", false).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)((result) => {
            //     // let auboolthenticationResult = <Response<string>>response;
            _portfolio__WEBPACK_IMPORTED_MODULE_2__.Portfolios.refresh();
            //     // this.portfoliosService.refreshBuyingPower();
            return result;
        }));
        // return this.authenticationService.startDynamicAuthentication("accounts", "FundTransfers", false)
        //     .map(response => {
        //         let auboolthenticationResult = <Response<string>>response;
        //         this.portfoliosService.refreshBuyingPower();
        //         return authenticationResult;
        //     });
    }
}
const Transfers = new TransfersModel();


/***/ }),

/***/ 32739:
/*!********************************************************************!*\
  !*** ./src/app/pages/transfer/home/home.component.scss?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = "ion-header ion-toolbar {\n  --background: #005157;\n  color: #fff;\n}\n\nion-content ion-grid ion-row .iban-number {\n  font-weight: bold;\n  margin: 0 6px;\n}\n\nion-content ion-grid ion-label {\n  text-transform: capitalize;\n  color: var(--ion-color-primary-txt);\n  font-weight: 500;\n}\n\nion-content ion-grid .home-btn-padding {\n  padding: 5px 0;\n}\n\nion-content ion-grid ion-col ion-button,\nion-content ion-grid ion-col ion-input,\nion-content ion-grid ion-col ion-textarea {\n  text-transform: capitalize;\n}\n\nion-content ion-grid ion-col ion-select,\nion-content ion-grid ion-col ion-input {\n  height: 50px;\n}\n\nion-content ion-grid ion-col ion-select,\nion-content ion-grid ion-col ion-input,\nion-content ion-grid ion-col ion-textarea {\n  border: 1px solid #99b9bc;\n  padding: 0 12px !important;\n  color: var(--ion-color-primary-txt);\n}\n\n.investment-btn {\n  background: var(--ion-color-tertiary);\n  color: var(--ion-color-primary-txt);\n  border-radius: 0;\n  font-size: 11px;\n  text-align: center;\n}\n\nbody.dark :host .investment-btn {\n  background-color: #4b4b4b;\n  color: #a5a5a5;\n}\n\n.secondInvestment-btn {\n  background: var(--ion-color-primary);\n  color: white;\n  border-radius: 0;\n  font-size: 11px;\n  text-align: center;\n}\n\nbody.dark :host .secondInvestment-btn {\n  background: #787878;\n  color: white;\n}\n\n.amountHint {\n  font-weight: bold;\n  margin: 0 6px;\n  color: red !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxxQkFBQTtFQUNBLFdBQUE7QUFBSjs7QUFNTTtFQUNFLGlCQUFBO0VBQ0EsYUFBQTtBQUhSOztBQU1JO0VBQ0UsMEJBQUE7RUFFQSxtQ0FBQTtFQUNBLGdCQUFBO0FBTE47O0FBT0k7RUFDRSxjQUFBO0FBTE47O0FBUU07OztFQUdFLDBCQUFBO0FBTlI7O0FBUU07O0VBRUUsWUFBQTtBQU5SOztBQVFNOzs7RUFHRSx5QkFBQTtFQUNBLDBCQUFBO0VBQ0EsbUNBQUE7QUFOUjs7QUFZQTtFQUdJLHFDQUFBO0VBQ0EsbUNBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQVhKOztBQWNBO0VBQ0UseUJBQUE7RUFDRSxjQUFBO0FBWEo7O0FBY0E7RUFFRSxvQ0FBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQVpGOztBQWVBO0VBQ0UsbUJBQUE7RUFDQSxZQUFBO0FBWkY7O0FBZUE7RUFDRSxpQkFBQTtFQUNBLGFBQUE7RUFDQSxxQkFBQTtBQVpGIiwiZmlsZSI6ImhvbWUuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcbiAgaW9uLXRvb2xiYXIge1xuICAgIC0tYmFja2dyb3VuZDogIzAwNTE1NztcbiAgICBjb2xvcjogI2ZmZjtcbiAgfVxufVxuaW9uLWNvbnRlbnQge1xuICBpb24tZ3JpZCB7XG4gICAgaW9uLXJvd3tcbiAgICAgIC5pYmFuLW51bWJlciB7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICBtYXJnaW46IDAgNnB4O1xuICAgICAgfVxuICAgIH1cbiAgICBpb24tbGFiZWwge1xuICAgICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG4gICAgICAvLyBjb2xvcjogIzAwNTE1NztcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS10eHQpO1xuICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICB9XG4gICAgLmhvbWUtYnRuLXBhZGRpbmd7XG4gICAgICBwYWRkaW5nOiA1cHggMDtcbiAgICB9XG4gICAgaW9uLWNvbCB7XG4gICAgICBpb24tYnV0dG9uLFxuICAgICAgaW9uLWlucHV0LFxuICAgICAgaW9uLXRleHRhcmVhIHtcbiAgICAgICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG4gICAgICB9XG4gICAgICBpb24tc2VsZWN0LFxuICAgICAgaW9uLWlucHV0IHtcbiAgICAgICAgaGVpZ2h0OiA1MHB4O1xuICAgICAgfVxuICAgICAgaW9uLXNlbGVjdCxcbiAgICAgIGlvbi1pbnB1dCxcbiAgICAgIGlvbi10ZXh0YXJlYSB7XG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICM5OWI5YmM7XG4gICAgICAgIHBhZGRpbmc6IDAgMTJweCAhaW1wb3J0YW50O1xuICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktdHh0KTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxuLmludmVzdG1lbnQtYnRue1xuIFxuICAgIC8vIC0tYmFja2dyb3VuZDogI2U2ZWZmMDtcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItdGVydGlhcnkpO1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS10eHQpO1xuICAgIGJvcmRlci1yYWRpdXM6IDA7XG4gICAgZm9udC1zaXplOiAxMXB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuYm9keS5kYXJrIDpob3N0IC5pbnZlc3RtZW50LWJ0bntcbiAgYmFja2dyb3VuZC1jb2xvcjogIzRiNGI0YjtcbiAgICBjb2xvcjogI2E1YTVhNTtcbn1cblxuLnNlY29uZEludmVzdG1lbnQtYnRue1xuICAvLyAtLWJhY2tncm91bmQ6ICNlNmVmZjA7XG4gIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgY29sb3I6IHdoaXRlO1xuICBib3JkZXItcmFkaXVzOiAwO1xuICBmb250LXNpemU6IDExcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuYm9keS5kYXJrIDpob3N0IC5zZWNvbmRJbnZlc3RtZW50LWJ0bntcbiAgYmFja2dyb3VuZDogIzc4Nzg3ODtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG4uYW1vdW50SGludHtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIG1hcmdpbjogMCA2cHg7XG4gIGNvbG9yOiByZWQgIWltcG9ydGFudDtcbn0iXX0= */";

/***/ }),

/***/ 42278:
/*!**************************************************************************!*\
  !*** ./src/app/pages/transfer/success/success.component.scss?ngResource ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = "ion-header ion-toolbar {\n  --background: #005157;\n  color: #fff;\n}\n\nion-content ion-grid ion-grid {\n  background: var(--ion-color-tertiary);\n}\n\nion-content ion-grid ion-grid ion-col .last-item,\nion-content ion-grid ion-grid ion-col .process-label {\n  color: var(ion-color-primary-txt);\n}\n\nion-content ion-grid ion-grid ion-col ion-label:first-child {\n  color: #000;\n}\n\nbody.dark :host ion-content ion-grid ion-grid ion-col ion-label:first-child {\n  color: white;\n}\n\nion-content ion-grid ion-grid ion-row {\n  min-height: 50px;\n  border-bottom: 1px solid #dbdbdb;\n  display: flex;\n  align-items: center;\n  font-size: 12px;\n}\n\nion-content ion-grid ion-grid ion-row:last-child {\n  border-bottom: 0;\n}\n\nion-content ion-row .process-margin {\n  margin-bottom: 6px;\n}\n\nion-content ion-row ion-label,\nion-content ion-row ion-button {\n  text-transform: capitalize;\n}\n\nion-content .btns {\n  margin-top: 18px;\n}\n\nion-content .process-label {\n  color: var(--ion-color-primary-txt) !important;\n}\n\nion-content .new-transfer {\n  --background:#2ebd85;\n  color: #fff;\n}\n\nion-content .back-to-main {\n  --background:#ff;\n  color: var(--ion-color-primary-bg);\n  border: 1px solid var(--ion-color-primary-bg);\n}\n\nion-content .success-label {\n  color: #2ebd85;\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN1Y2Nlc3MuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxxQkFBQTtFQUNBLFdBQUE7QUFBSjs7QUFLSTtFQUVFLHFDQUFBO0FBSE47O0FBS1E7O0VBR0UsaUNBQUE7QUFKVjs7QUFNUTtFQUNFLFdBQUE7QUFKVjs7QUFLVTtFQUNFLFlBQUE7QUFIWjs7QUFPTTtFQUNFLGdCQUFBO0VBQ0EsZ0NBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0FBTFI7O0FBT007RUFDRSxnQkFBQTtBQUxSOztBQVVJO0VBQ0Usa0JBQUE7QUFSTjs7QUFVSTs7RUFFRSwwQkFBQTtBQVJOOztBQVdFO0VBQ0UsZ0JBQUE7QUFUSjs7QUFZRTtFQUNFLDhDQUFBO0FBVko7O0FBWUU7RUFDRSxvQkFBQTtFQUNBLFdBQUE7QUFWSjs7QUFZRTtFQUNFLGdCQUFBO0VBR0Esa0NBQUE7RUFDQSw2Q0FBQTtBQVpKOztBQWVFO0VBQ0UsY0FBQTtFQUNBLGlCQUFBO0FBYkoiLCJmaWxlIjoic3VjY2Vzcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXIge1xuICBpb24tdG9vbGJhciB7XG4gICAgLS1iYWNrZ3JvdW5kOiAjMDA1MTU3O1xuICAgIGNvbG9yOiAjZmZmO1xuICB9XG59XG5pb24tY29udGVudCB7XG4gIGlvbi1ncmlkIHtcbiAgICBpb24tZ3JpZCB7XG4gICAgICAvLyBiYWNrZ3JvdW5kOiAjZTZlZmYwO1xuICAgICAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5KTtcbiAgICAgIGlvbi1jb2x7XG4gICAgICAgIC5sYXN0LWl0ZW0sXG4gICAgICAgIC5wcm9jZXNzLWxhYmVse1xuICAgICAgICAgIC8vIGNvbG9yOiAjMDA1MTU3ICFpbXBvcnRhbnQ7XG4gICAgICAgICAgY29sb3I6IHZhcihpb24tY29sb3ItcHJpbWFyeS10eHQpXG4gICAgICAgIH1cbiAgICAgICAgaW9uLWxhYmVsOmZpcnN0LWNoaWxke1xuICAgICAgICAgIGNvbG9yOiMwMDA7XG4gICAgICAgICAgYm9keS5kYXJrIDpob3N0ICYge1xuICAgICAgICAgICAgY29sb3I6d2hpdGU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpb24tcm93IHtcbiAgICAgICAgbWluLWhlaWdodDogNTBweDtcbiAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNkYmRiZGI7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgIH1cbiAgICAgIGlvbi1yb3c6bGFzdC1jaGlsZCB7XG4gICAgICAgIGJvcmRlci1ib3R0b206IDA7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGlvbi1yb3cge1xuICAgIC5wcm9jZXNzLW1hcmdpbiB7XG4gICAgICBtYXJnaW4tYm90dG9tOiA2cHg7XG4gICAgfVxuICAgIGlvbi1sYWJlbCxcbiAgICBpb24tYnV0dG9uIHtcbiAgICAgIHRleHQtdHJhbnNmb3JtOiBjYXBpdGFsaXplO1xuICAgIH1cbiAgfVxuICAuYnRucyB7XG4gICAgbWFyZ2luLXRvcDogMThweDtcbiAgfVxuICBcbiAgLnByb2Nlc3MtbGFiZWx7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXR4dCkgIWltcG9ydGFudDtcbiAgfVxuICAubmV3LXRyYW5zZmVye1xuICAgIC0tYmFja2dyb3VuZDojMmViZDg1O1xuICAgIGNvbG9yOiNmZmZcbiAgfVxuICAuYmFjay10by1tYWlue1xuICAgIC0tYmFja2dyb3VuZDojZmY7XG4gICAgLy8gY29sb3I6IzAwNTE1NztcbiAgICAvLyBib3JkZXI6MXB4IHNvbGlkICMwMDUxNTc7XG4gICAgY29sb3I6dmFyKC0taW9uLWNvbG9yLXByaW1hcnktYmcpO1xuICAgIGJvcmRlcjoxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLXByaW1hcnktYmcpO1xuXG4gIH1cbiAgLnN1Y2Nlc3MtbGFiZWx7XG4gICAgY29sb3I6ICMyZWJkODU7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIH1cbn1cbiJdfQ== */";

/***/ }),

/***/ 87038:
/*!**************************************************************************!*\
  !*** ./src/app/pages/transfer/summary/summary.component.scss?ngResource ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = "ion-header ion-toolbar {\n  --background: #005157;\n  color: #fff;\n}\n\nion-content ion-grid ion-label {\n  text-transform: capitalize;\n  color: var(--ion-color-primary-txt);\n  font-weight: 500;\n}\n\nion-content ion-grid ion-col .modify-btn {\n  --background:#fff;\n  color: #f5455a;\n  border: 1px solid #f5455a;\n}\n\nion-content ion-grid ion-col .cancel-btn {\n  --background:#fff;\n  color: var(--ion-color-primary-bg);\n  border: 1px solid var(--ion-color-primary-bg);\n}\n\nion-content ion-grid ion-col ion-button,\nion-content ion-grid ion-col ion-input,\nion-content ion-grid ion-col ion-textarea {\n  text-transform: capitalize;\n}\n\nion-content ion-grid ion-col .output-label {\n  display: flex;\n  align-items: center;\n}\n\nion-content ion-grid ion-col ion-input,\nion-content ion-grid ion-col .output-label {\n  height: 50px;\n}\n\nion-content ion-grid ion-col ion-input ion-label,\nion-content ion-grid ion-col .output-label ion-label {\n  text-transform: capitalize;\n  font-weight: 500;\n}\n\nion-content ion-grid ion-col ion-input,\nion-content ion-grid ion-col ion-textarea,\nion-content ion-grid ion-col .output-label {\n  background-color: var(--ion-color-tertiary);\n  padding: 0 12px !important;\n}\n\nion-content ion-grid ion-row:last-child {\n  margin-top: 2px;\n}\n\n.investment-btn ion-button {\n  opacity: 1;\n  --background: #005157;\n  color: white;\n  border-radius: 0;\n  font-size: 12px;\n}\n\nbody.dark :host .investment-btn ion-button {\n  --background: #787878;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN1bW1hcnkuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxxQkFBQTtFQUNBLFdBQUE7QUFBSjs7QUFLSTtFQUNFLDBCQUFBO0VBQ0EsbUNBQUE7RUFDQSxnQkFBQTtBQUZOOztBQUtNO0VBQ0UsaUJBQUE7RUFDQSxjQUFBO0VBQ0EseUJBQUE7QUFIUjs7QUFLTTtFQUNFLGlCQUFBO0VBQ0Esa0NBQUE7RUFDQSw2Q0FBQTtBQUhSOztBQUtNOzs7RUFHRSwwQkFBQTtBQUhSOztBQUtNO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0FBSFI7O0FBS007O0VBRUUsWUFBQTtBQUhSOztBQUlROztFQUNFLDBCQUFBO0VBRUEsZ0JBQUE7QUFGVjs7QUFNTTs7O0VBSUUsMkNBQUE7RUFDQSwwQkFBQTtBQUxSOztBQVFJO0VBQ0UsZUFBQTtBQU5OOztBQVlFO0VBQ0UsVUFBQTtFQUNBLHFCQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQVRKOztBQWNFO0VBQ0UscUJBQUE7QUFYSiIsImZpbGUiOiJzdW1tYXJ5LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciB7XG4gIGlvbi10b29sYmFyIHtcbiAgICAtLWJhY2tncm91bmQ6ICMwMDUxNTc7XG4gICAgY29sb3I6ICNmZmY7XG4gIH1cbn1cbmlvbi1jb250ZW50IHtcbiAgaW9uLWdyaWQge1xuICAgIGlvbi1sYWJlbCB7XG4gICAgICB0ZXh0LXRyYW5zZm9ybTogY2FwaXRhbGl6ZTtcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS10eHQpO1xuICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICB9XG4gICAgaW9uLWNvbCB7XG4gICAgICAubW9kaWZ5LWJ0bntcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiNmZmY7XG4gICAgICAgIGNvbG9yOiNmNTQ1NWE7XG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNmNTQ1NWE7XG4gICAgICB9XG4gICAgICAuY2FuY2VsLWJ0bntcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiNmZmY7XG4gICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1iZyk7XG4gICAgICAgIGJvcmRlcjoxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLXByaW1hcnktYmcpO1xuICAgICAgfVxuICAgICAgaW9uLWJ1dHRvbixcbiAgICAgIGlvbi1pbnB1dCxcbiAgICAgIGlvbi10ZXh0YXJlYSB7XG4gICAgICAgIHRleHQtdHJhbnNmb3JtOiBjYXBpdGFsaXplO1xuICAgICAgfVxuICAgICAgLm91dHB1dC1sYWJlbHtcbiAgICAgICAgZGlzcGxheTpmbGV4O1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgfVxuICAgICAgaW9uLWlucHV0LFxuICAgICAgLm91dHB1dC1sYWJlbCB7XG4gICAgICAgIGhlaWdodDogNTBweDtcbiAgICAgICAgaW9uLWxhYmVse1xuICAgICAgICAgIHRleHQtdHJhbnNmb3JtOiBjYXBpdGFsaXplO1xuICAgICAgICAgIC8vIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItdGVydGlhcnktY29udHJhc3QpO1xuICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICAgIH1cblxuICAgICAgfVxuICAgICAgaW9uLWlucHV0LFxuICAgICAgaW9uLXRleHRhcmVhLFxuICAgICAgLm91dHB1dC1sYWJlbCB7XG4gICAgICAgIC8vIGJhY2tncm91bmQtY29sb3I6ICNlNmVmZjA7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci10ZXJ0aWFyeSk7XG4gICAgICAgIHBhZGRpbmc6IDAgMTJweCAhaW1wb3J0YW50O1xuICAgICAgfVxuICAgIH1cbiAgICBpb24tcm93Omxhc3QtY2hpbGQge1xuICAgICAgbWFyZ2luLXRvcDogMnB4O1xuICAgIH1cbiAgfVxufVxuXG4uaW52ZXN0bWVudC1idG57XG4gIGlvbi1idXR0b24ge1xuICAgIG9wYWNpdHk6IDE7XG4gICAgLS1iYWNrZ3JvdW5kOiAjMDA1MTU3O1xuICAgIGNvbG9yOndoaXRlO1xuICAgIGJvcmRlci1yYWRpdXM6IDA7XG4gICAgZm9udC1zaXplOiAxMnB4O1xuICB9XG59XG5cbmJvZHkuZGFyayA6aG9zdCAuaW52ZXN0bWVudC1idG57XG4gIGlvbi1idXR0b24ge1xuICAgIC0tYmFja2dyb3VuZDogIzc4Nzg3ODtcbiAgfVxufVxuXG4iXX0= */";

/***/ }),

/***/ 98569:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/transfer/transfer-home/transfer-home.component.scss?ngResource ***!
  \**************************************************************************************/
/***/ ((module) => {

module.exports = "ion-header ion-toolbar {\n  --background: #005157;\n  color: #fff;\n}\n\nion-content ion-grid ion-row .iban-number {\n  font-weight: bold;\n  margin: 0 6px;\n}\n\nion-content ion-grid ion-label {\n  text-transform: capitalize;\n  color: var(--ion-color-primary-txt);\n  font-weight: 500;\n}\n\nion-content ion-grid .home-btn-padding {\n  padding: 5px 0;\n}\n\nion-content ion-grid ion-col ion-button,\nion-content ion-grid ion-col ion-input,\nion-content ion-grid ion-col ion-textarea {\n  text-transform: capitalize;\n}\n\nion-content ion-grid ion-col ion-select,\nion-content ion-grid ion-col ion-input {\n  height: 50px;\n}\n\nion-content ion-grid ion-col ion-select,\nion-content ion-grid ion-col ion-input,\nion-content ion-grid ion-col ion-textarea {\n  border: 1px solid #99b9bc;\n  padding: 0 12px !important;\n  color: var(--ion-color-primary-txt);\n}\n\n.investment-btn {\n  background: var(--ion-color-tertiary);\n  color: var(--ion-color-primary-txt);\n  border-radius: 0;\n  font-size: 11px;\n  text-align: center;\n}\n\nbody.dark :host .investment-btn {\n  background-color: #4b4b4b;\n  color: #a5a5a5;\n}\n\n.secondInvestment-btn {\n  background: var(--ion-color-primary);\n  color: white;\n  border-radius: 0;\n  font-size: 11px;\n  text-align: center;\n}\n\nbody.dark :host .secondInvestment-btn {\n  background: #787878;\n  color: white;\n}\n\n.amountHint {\n  font-weight: bold;\n  margin: 0 6px;\n  color: red !important;\n}\n\n.box-info {\n  background: #e4eef8;\n  border: 1px solid #7aabde;\n  color: #7aaade;\n}\n\n.suitability-box {\n  display: flex;\n  align-items: flex-start;\n}\n\n.suitability-box ion-label {\n  padding: 0 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRyYW5zZmVyLWhvbWUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0k7RUFDRSxxQkFBQTtFQUNBLFdBQUE7QUFBTjs7QUFNUTtFQUNFLGlCQUFBO0VBQ0EsYUFBQTtBQUhWOztBQU1NO0VBQ0UsMEJBQUE7RUFFQSxtQ0FBQTtFQUNBLGdCQUFBO0FBTFI7O0FBT007RUFDRSxjQUFBO0FBTFI7O0FBUVE7OztFQUdFLDBCQUFBO0FBTlY7O0FBUVE7O0VBRUUsWUFBQTtBQU5WOztBQVFROzs7RUFHRSx5QkFBQTtFQUNBLDBCQUFBO0VBQ0EsbUNBQUE7QUFOVjs7QUFZRTtFQUdJLHFDQUFBO0VBQ0EsbUNBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQVhOOztBQWNFO0VBQ0UseUJBQUE7RUFDRSxjQUFBO0FBWE47O0FBY0U7RUFFRSxvQ0FBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQVpKOztBQWVFO0VBQ0UsbUJBQUE7RUFDQSxZQUFBO0FBWko7O0FBZUU7RUFDRSxpQkFBQTtFQUNBLGFBQUE7RUFDQSxxQkFBQTtBQVpKOztBQWNFO0VBQ0UsbUJBQUE7RUFDQSx5QkFBQTtFQUNBLGNBQUE7QUFYSjs7QUFhQTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtBQVZGOztBQVlFO0VBQ0ksZUFBQTtBQVZOIiwiZmlsZSI6InRyYW5zZmVyLWhvbWUuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcbiAgICBpb24tdG9vbGJhciB7XG4gICAgICAtLWJhY2tncm91bmQ6ICMwMDUxNTc7XG4gICAgICBjb2xvcjogI2ZmZjtcbiAgICB9XG4gIH1cbiAgaW9uLWNvbnRlbnQge1xuICAgIGlvbi1ncmlkIHtcbiAgICAgIGlvbi1yb3d7XG4gICAgICAgIC5pYmFuLW51bWJlciB7XG4gICAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICAgICAgbWFyZ2luOiAwIDZweDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG4gICAgICAgIC8vIGNvbG9yOiAjMDA1MTU3O1xuICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktdHh0KTtcbiAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgIH1cbiAgICAgIC5ob21lLWJ0bi1wYWRkaW5ne1xuICAgICAgICBwYWRkaW5nOiA1cHggMDtcbiAgICAgIH1cbiAgICAgIGlvbi1jb2wge1xuICAgICAgICBpb24tYnV0dG9uLFxuICAgICAgICBpb24taW5wdXQsXG4gICAgICAgIGlvbi10ZXh0YXJlYSB7XG4gICAgICAgICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG4gICAgICAgIH1cbiAgICAgICAgaW9uLXNlbGVjdCxcbiAgICAgICAgaW9uLWlucHV0IHtcbiAgICAgICAgICBoZWlnaHQ6IDUwcHg7XG4gICAgICAgIH1cbiAgICAgICAgaW9uLXNlbGVjdCxcbiAgICAgICAgaW9uLWlucHV0LFxuICAgICAgICBpb24tdGV4dGFyZWEge1xuICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICM5OWI5YmM7XG4gICAgICAgICAgcGFkZGluZzogMCAxMnB4ICFpbXBvcnRhbnQ7XG4gICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXR4dCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgXG4gIC5pbnZlc3RtZW50LWJ0bntcbiAgIFxuICAgICAgLy8gLS1iYWNrZ3JvdW5kOiAjZTZlZmYwO1xuICAgICAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5KTtcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS10eHQpO1xuICAgICAgYm9yZGVyLXJhZGl1czogMDtcbiAgICAgIGZvbnQtc2l6ZTogMTFweDtcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgfVxuICBcbiAgYm9keS5kYXJrIDpob3N0IC5pbnZlc3RtZW50LWJ0bntcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNGI0YjRiO1xuICAgICAgY29sb3I6ICNhNWE1YTU7XG4gIH1cbiAgXG4gIC5zZWNvbmRJbnZlc3RtZW50LWJ0bntcbiAgICAvLyAtLWJhY2tncm91bmQ6ICNlNmVmZjA7XG4gICAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBib3JkZXItcmFkaXVzOiAwO1xuICAgIGZvbnQtc2l6ZTogMTFweDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIH1cbiAgXG4gIGJvZHkuZGFyayA6aG9zdCAuc2Vjb25kSW52ZXN0bWVudC1idG57XG4gICAgYmFja2dyb3VuZDogIzc4Nzg3ODtcbiAgICBjb2xvcjogd2hpdGU7XG4gIH1cbiAgXG4gIC5hbW91bnRIaW50e1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIG1hcmdpbjogMCA2cHg7XG4gICAgY29sb3I6IHJlZCAhaW1wb3J0YW50O1xuICB9XG4gIC5ib3gtaW5mbyB7XG4gICAgYmFja2dyb3VuZDogI2U0ZWVmODtcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjN2FhYmRlO1xuICAgIGNvbG9yOiAjN2FhYWRlO1xufVxuLnN1aXRhYmlsaXR5LWJveCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xuXG4gIGlvbi1sYWJlbCB7XG4gICAgICBwYWRkaW5nOiAwIDE1cHg7XG4gIH1cbn0iXX0= */";

/***/ }),

/***/ 40307:
/*!**************************************************************!*\
  !*** ./src/app/pages/transfer/transfer.page.scss?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0cmFuc2Zlci5wYWdlLnNjc3MifQ== */";

/***/ }),

/***/ 44095:
/*!********************************************************************!*\
  !*** ./src/app/pages/transfer/home/home.component.html?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <!-- <ion-menu-button autoHide=\"true\"></ion-menu-button> -->\n      <ion-back-button text=\"\"></ion-back-button>\n    </ion-buttons>\n  \n    <ion-title>\n          {{'transfer.fundTransfer' | translate}}\n  </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-grid>\n\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-label>{{'transfer.transferType' | translate}}</ion-label>\n      </ion-col>\n      <ion-col style=\"text-align: center;\" class=\"home-btn-padding\" [ngClass]=\"selectedTab == 2 ?  'secondInvestment-btn' : 'investment-btn'\" (click)=\"changeFund('2')\" size=\"5.2\">\n         \n        {{funds[1]?.name}}\n     \n    </ion-col>\n      \n        <ion-col size=\".3\"></ion-col>\n        \n        <ion-col size=\"6.2\" [ngClass]=\"selectedTab == 1 ?  'secondInvestment-btn' : 'investment-btn'\" (click)=\"changeFund('1')\">\n        \n          {{funds[0]?.name}}\n      \n      </ion-col>\n    </ion-row>\n\n\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-label>{{'transfer.fromAccount' | translate}}</ion-label>\n      </ion-col>\n      <ion-col size=\"12\">\n        <ion-select interface=\"action-sheet\" mode=\"ios\" [value]=\"firstSelectArr[0]?.accountValue\" [interfaceOptions]=\"{header: 'transfer.accounts' | translate, cssClass: 'app-select'}\" required=\"true\"  [(ngModel)]='fromAccount' (ionChange)=\"firstSelectChange()\"  okText=\"{{'transfer.SELECT' | translate}}\" cancelText=\"{{'transfer.CANCEL' | translate}}\">\n          <ion-select-option *ngFor=\"let item of firstSelectArr\" [value]=\"item.accountValue\" selected>{{item.accountLabel}}</ion-select-option>\n        </ion-select>\n        <!-- <ion-row class=\"standing-orders-wallet-select\" style=\"color: var(--ion-color-primary-txt);\" size=\"12\">\n   \n          <ion-col class=\"custom-select-box\" size=\"12\" (click)=\"presentFromAccountModal()\">\n            <ion-row size=\"12\">\n            <ion-col  size=\"11\">{{firstSelectedAccount?.accountLabel || t.choose}}</ion-col>\n            <ion-col  size=\"1\"><ion-icon name=\"chevron-down-outline\"></ion-icon></ion-col>\n          </ion-row>\n          </ion-col>\n         \n        </ion-row> -->\n      </ion-col>\n    \n    </ion-row>\n\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-label>{{secondSelectLable}}</ion-label>\n      </ion-col>\n      <ion-col size=\"12\">\n        <ion-select interface=\"action-sheet\" [value]=\"secondSelectArr[0]?.accountValue\" mode=\"ios\" [interfaceOptions]=\"{header: secondSelectHeader, cssClass: 'app-select'}\" required=\"true\" [disabled]=\"!fromAccount\"  [(ngModel)]='toAccount' (ionChange)=\"secondSelectChange()\"  okText=\"{{'transfer.SELECT' | translate}}\" cancelText=\"{{'transfer.CANCEL' | translate}}\">\n          <ion-select-option *ngFor=\"let item of secondSelectArr\" [value]=\"item.accountValue\" selected>{{item.accountLabel}}</ion-select-option>\n        </ion-select>\n        <!-- <ion-row class=\"standing-orders-wallet-select\" style=\"color: var(--ion-color-primary-txt);\" size=\"12\">\n          <ion-col class=\"custom-select-box\" size=\"12\" (click)=\"presentToAccountModal()\" [disabled]=\"!fromAccount\">\n            <ion-row size=\"12\">\n            <ion-col  size=\"11\">{{toAccountLabel || t.choose}}</ion-col>\n            <ion-col  size=\"1\"><ion-icon name=\"chevron-down-outline\"></ion-icon></ion-col>\n          </ion-row>\n          </ion-col>\n        </ion-row> -->\n      </ion-col>\n      <ion-row size=\"12\" [hidden] = \"showIban\">\n          <ion-label *ngIf=\"secondIban\" class=\"ion-text-capitalize iban-number\">{{'transfer.ibanNumber' | translate}}</ion-label>\n          <ion-label *ngIf=\"secondIban\" class=\"ion-text-capitalize\">{{secondIban}}</ion-label>\n      </ion-row>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-label>{{'transfer.amount' | translate}} </ion-label>\n      </ion-col>\n      <ion-col size=\"12\">\n        <ion-input required=\"true\" [disabled]=\"!fromAccount\" (keyup)=\"checkAmount(amount)\"  [(ngModel)]='amount'  type=\"number\"></ion-input>\n      </ion-col>\n      <ion-row size=\"12\" [hidden] = \"showAmountHint\">\n        <ion-label  class=\"ion-text-capitalize amountHint\">{{'transfer.amountHint' | translate}} {{firstSelectedAccount?.accountBalance}} </ion-label>\n    </ion-row>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-label>{{'transfer.notes' | translate}} </ion-label>\n      </ion-col>\n      <ion-col size=\"12\">\n        <ion-textarea required=\"true\"  [(ngModel)]='memo'  rows=\"3\" cols=\"20\"></ion-textarea>\n      </ion-col>\n    </ion-row>\n\n  </ion-grid>\n\n</ion-content>\n\n<ion-footer>\n  <ion-grid class=\"ion-padding\">\n      <app-button \n      (clickAction)=\"goToSummaryPage()\"\n      expand=\"block\" \n      size=\"\"\n      color=\"primary\"\n      fill=\"solid\"\n      strong=\"false\"\n      target=\"_blank\"\n      >\n      {{'transfer.review' | translate}}\n    </app-button>\n    \n  </ion-grid>\n</ion-footer>";

/***/ }),

/***/ 86056:
/*!**************************************************************************!*\
  !*** ./src/app/pages/transfer/success/success.component.html?ngResource ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>\n    <ion-grid>\n      <ion-row>\n        <ion-col class=\"ion-text-center ion-text-capitalize\">\n         {{'transfer.fundTransfer' | translate}}\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n\n  <ion-grid>\n\n    <ion-row>\n      <ion-col size=\"12\" class=\"ion-text-center\">\n        <img width=\"80px\" src=\"assets/icon/success.png\" alt=\"\">\n      </ion-col>\n      <ion-col size=\"12\" class=\"ion-text-center\">\n        <ion-label class=\"success-label\">{{'transfer.successMessage' | translate}}</ion-label>\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size=\"12\" class=\"ion-margin-top process-margin\">\n        <ion-label class=\"process-label\">{{'transfer.transferSummary' | translate}}</ion-label>\n      </ion-col>\n    </ion-row>\n\n    <ion-grid>\n      <ion-row>\n        <ion-col size=\"4\">\n          <ion-label>{{'transfer.transferType' | translate}}</ion-label>\n        </ion-col>\n        <ion-col size=\"8\">\n          <ion-label class=\"last-item\">{{summaryObj.fundName}} </ion-label>\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"4\">\n          <ion-label>{{'transfer.fromAccount' | translate}}</ion-label>\n        </ion-col>\n        <ion-col size=\"8\">\n          <ion-label class=\"last-item\">{{summaryObj.fromAccount.accountLabel}}</ion-label>\n        </ion-col>\n      </ion-row>\n      <!-- <ion-row>\n        <ion-col size=\"4\">\n          <ion-label>{{'transfer.accountNumber}}</ion-label>\n        </ion-col>\n        <ion-col size=\"8\">\n          <ion-label class=\"last-item\">{{summaryObj.fromAccount.accountValue}}</ion-label>\n        </ion-col>\n      </ion-row> -->\n      <ion-row>\n        <ion-col size=\"4\">\n          <ion-label>{{transferTo}}</ion-label>\n        </ion-col>\n        <ion-col size=\"8\">\n          <ion-label class=\"last-item\">{{summaryObj.toAccount.accountLabel}}</ion-label>\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"4\">\n          <ion-label>{{'transfer.amount' | translate}}</ion-label>\n        </ion-col>\n        <ion-col size=\"8\">\n          <ion-label class=\"last-item\">{{summaryObj.amount}}</ion-label>\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"4\">\n          <ion-label>{{'transfer.referanceNumber' | translate}}</ion-label>\n        </ion-col>\n        <ion-col size=\"8\">\n          <ion-label class=\"last-item\">{{summaryObj.referenceNumber}}</ion-label>\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"4\">\n          <ion-label>{{'transfer.date' | translate}}</ion-label>\n        </ion-col>\n        <ion-col size=\"8\">\n          <ion-label class=\"last-item\">{{summaryObj.date}}</ion-label>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n\n   \n\n  </ion-grid>\n\n</ion-content>\n<ion-footer>\n  <div class=\"ion-padding\">\n    <ion-row>\n      <ion-col size=\"\">\n        <!-- <ion-button class=\"new-transfer\" (click)=\"newTransfer()\" expand=\"full\">New transfer</ion-button> -->\n        <app-button \n        (clickAction)=\"shareScreenshot()\"\n        expand=\"block\" \n        size=\"\"\n        color=\"primary\"\n        fill=\"solid\"\n        shape=\"\"\n        type=\"submit\"\n        icon-name=\"share-outline\"\n        >\n        {{'transfer.share' | translate}}\n      </app-button>\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col >\n        <!-- <ion-button class=\"back-to-main\" (click)=\"backToHome()\" expand=\"full\">return to main screen</ion-button>-->\n        <app-button  \n        (clickAction)=\"backToHome()\"\n        expand=\"block\" \n        size=\"\"\n        color=\"txt\"\n        fill=\"outline\"\n        strong=\"false\"\n        target=\"_blank\"\n        >\n        {{'transfer.return' | translate}}\n        </app-button>\n      </ion-col>\n    </ion-row>\n  </div>\n</ion-footer>";

/***/ }),

/***/ 4670:
/*!**************************************************************************!*\
  !*** ./src/app/pages/transfer/summary/summary.component.html?ngResource ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>\n    <ion-grid>\n      <ion-row>\n        <ion-col class=\"ion-text-center ion-text-capitalize\">\n          {{'transfer.fundTransfer' | translate}}\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <!-- <tadawul-loader *ngIf=\"showLoader\"></tadawul-loader> -->\n  <ion-grid>\n\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-label class=\"walletClass\">{{'transfer.transferType' | translate}}</ion-label>\n      </ion-col>\n        <ion-col size=\"auto\" class=\"investment-btn\">\n          <ion-button expand=\"full\"  (click)=\"changePeriod(1)\" disabled=\"true\">\n            {{summaryObj.fundName}}\n          </ion-button>\n        </ion-col>\n     \n    </ion-row>\n\n      <!-- <ion-col size=\"12\">\n        <ion-label>{{'transfer.transferType}}</ion-label>\n      </ion-col>\n      <ion-col style=\"font-size: 12px;\" size=\"8\">\n      \n        <app-button \n        (clickAction)=\"transfer()\"\n        expand=\"block\" \n        size=\"\"\n        color=\"primary\"\n        fill=\"solid\"\n        strong=\"false\"\n        target=\"_blank\"\n        >\n        {{summaryObj.fundName}}\n      </app-button>\n      </ion-col> -->\n    \n\n\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-label>{{'transfer.fromAccount' | translate}}</ion-label>\n      </ion-col>\n      <ion-col size=\"12\">\n        <div class=\"output-label\">\n          <ion-label class=\"ion-text-capitalize\">{{summaryObj.fromAccount.accountLabel}}</ion-label>\n        </div>\n      </ion-col>\n    </ion-row>\n\n    <!-- <ion-row>\n      <ion-col size=\"12\">\n        <ion-label>{{'transfer.accountNumber}}</ion-label>\n      </ion-col>\n      <ion-col size=\"12\">\n        <div class=\"output-label\">\n          <ion-label class=\"ion-text-capitalize\">{{summaryObj.fromAccount.accountValue}}</ion-label>\n        </div>\n      </ion-col>\n    </ion-row> -->\n\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-label>{{transferTo}}</ion-label>\n      </ion-col>\n      <ion-col size=\"12\">\n        <div class=\"output-label\">\n          <ion-label class=\"ion-text-capitalize\">{{summaryObj.toAccount.accountLabel}}</ion-label>\n        </div>\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-label>{{'transfer.amount' | translate}} </ion-label>\n      </ion-col>\n      <ion-col size=\"12\">\n        <ion-label class=\"output-label\" type=\"number\" disabled=\"true\">{{summaryObj.amount}} {{'transfer.sar' | translate}}</ion-label>\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-label>{{'transfer.notes' | translate}}</ion-label>\n      </ion-col>\n      <ion-col size=\"12\">\n        <ion-textarea rows=\"3\" cols=\"20\" disabled=\"true\">{{summaryObj.memo}}</ion-textarea>\n      </ion-col>\n    </ion-row>\n\n  </ion-grid>\n\n</ion-content>\n\n<ion-footer>\n  <ion-grid class=\"ion-padding\">\n  <ion-row>\n    <ion-col size=\"8\">\n      <!-- <ion-button class=\"modify-btn\" expand=\"full\">Modify request</ion-button> -->\n      <app-button \n      (clickAction)=\"modifyRequest()\"\n      expand=\"block\" \n      size=\"\"\n      color=\"txt\"\n      fill=\"outline\"\n      strong=\"false\"\n      target=\"_blank\"\n      >\n      {{'transfer.modifyRequest' | translate}}\n      </app-button>\n    </ion-col>\n    <ion-col size=\"4\">\n      <!-- <ion-button class=\"cancel-btn\" expand=\"full\">cancel</ion-button> -->\n      <app-button \n      (clickAction)=\"cancel()\"\n      expand=\"block\" \n      size=\"\"\n      color=\"danger\"\n      fill=\"outline\"\n      strong=\"false\"\n      target=\"_blank\"\n      >\n     {{'transfer.cancel' | translate}}\n      </app-button>\n    </ion-col>\n  </ion-row>\n\n  <ion-row class=\"transfer-confirm-btn\">\n    <ion-col size=\"\">\n      <!-- <ion-button (click)=\"transfer()\" expand=\"full\">Transfer confirmation</ion-button> -->\n      <app-button \n      (clickAction)=\"transfer()\"\n      expand=\"block\" \n      size=\"\"\n      color=\"primary\"\n      fill=\"solid\"\n      strong=\"false\"\n      target=\"_blank\"\n      >\n      {{'transfer.transferConfirmation' | translate}}\n    </app-button>\n    </ion-col>\n    \n  </ion-row>\n</ion-grid>\n<tadawul-loader *ngIf=\"showLoader\"></tadawul-loader>\n</ion-footer>\n";

/***/ }),

/***/ 79036:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/transfer/transfer-home/transfer-home.component.html?ngResource ***!
  \**************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header translucent>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <!-- <ion-menu-button autoHide=\"true\"></ion-menu-button> -->\n      <ion-back-button text=\"\"></ion-back-button>\n    </ion-buttons>\n  \n    <ion-title>\n          {{'transfer.fundTransfer' | translate}}\n  </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-grid>\n\n    <!-- box-warn -->\n    <!-- 'warning-outline' -->\n    <div  class=\"ion-padding\" class=\"box-info\">\n    <div class=\"suitability-box\">\n      <ion-icon [name]=\"'alert-circle-outline'\"\n        style=\"font-size: 30px;\"></ion-icon>\n      <ion-label>\n        {{'transfer.fundAlertMsg' | translate}}\n        <!-- <span *ngIf=\"!(mutualFund?.suitability | async)?.isSuitabile\">{{ t.SUB_MSG }}</span>\n        <span *ngIf=\"!(mutualFund?.suitability | async)?.isSuitabile\" (click)=\"refuseSubscription()\" id='bold-text'>\n          {{t.BACK_TO_HOME}}\n        </span> -->\n\n        <!-- <br /> -->\n\n        <!-- <ion-button fill=\"solid\" type=\"button\" size=\"small\" (click)=\"openReport()\">\n          <ion-icon slot=\"start\" src=\"assets/icon/pdf.svg\" style=\"font-size: 16px;\"></ion-icon>\n          <span style=\"padding: 0px 5px 0px 5px;font-size: 14px;\">\n            {{t.REPORT_REVIEW}}\n          </span>\n        </ion-button> -->\n      </ion-label>\n    </div>\n  </div>\n\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-label>{{'transfer.transferType' | translate}}</ion-label>\n      </ion-col>\n      <ion-col style=\"text-align: center;\" class=\"home-btn-padding\" [ngClass]=\"selectedTab == 2 ?  'secondInvestment-btn' : 'investment-btn'\" (click)=\"changeFund('2')\" size=\"5.2\">\n         \n        {{funds[1]?.name}}\n     \n    </ion-col>\n      \n        <ion-col size=\".3\"></ion-col>\n        \n        <ion-col size=\"6.2\" [ngClass]=\"selectedTab == 1 ?  'secondInvestment-btn' : 'investment-btn'\" (click)=\"changeFund('1')\">\n        \n          {{funds[0]?.name}}\n      \n      </ion-col>\n    </ion-row>\n\n\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-label>{{'transfer.fromAccount' | translate}}</ion-label>\n      </ion-col>\n      <ion-col size=\"12\">\n        <ion-select *ngIf=\"!showLoader\" interface=\"action-sheet\" mode=\"ios\" [value]=\"firstSelectArr[1]?.accountValue\" [interfaceOptions]=\"{header: 'transfer.accounts' | translate, cssClass: 'app-select'}\" required=\"true\"  [(ngModel)]='fromAccount' (ionChange)=\"firstSelectChange()\"  okText=\"{{'product.SELECT' | translate}}\" cancelText=\"{{'product.CANCEL' | translate}}\">\n          <ion-select-option *ngFor=\"let item of firstSelectArr\" [value]=\"item.accountValue\" selected>{{item.accountLabel}}</ion-select-option>\n        </ion-select>\n        <ion-skeleton-text animated style=\"width: 100%;border-radius: 5px;height: 40px;\" *ngIf=\"showLoader\">\n        </ion-skeleton-text>\n        <!-- <ion-row class=\"standing-orders-wallet-select\" style=\"color: var(--ion-color-primary-txt);\" size=\"12\">\n   \n          <ion-col class=\"custom-select-box\" size=\"12\" (click)=\"presentFromAccountModal()\">\n            <ion-row size=\"12\">\n            <ion-col  size=\"11\">{{firstSelectedAccount?.accountLabel || t.choose}}</ion-col>\n            <ion-col  size=\"1\"><ion-icon name=\"chevron-down-outline\"></ion-icon></ion-col>\n          </ion-row>\n          </ion-col>\n         \n        </ion-row> -->\n      </ion-col>\n    \n    </ion-row>\n\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-label>{{secondSelectLable}}</ion-label>\n      </ion-col>\n      <ion-col size=\"12\">\n        <ion-select *ngIf=\"!showLoader\" interface=\"action-sheet\" [value]=\"secondSelectArr[1]?.accountValue\" mode=\"ios\" [interfaceOptions]=\"{header: secondSelectHeader, cssClass: 'app-select'}\" required=\"true\" [disabled]=\"!fromAccount\"  [(ngModel)]='toAccount' (ionChange)=\"secondSelectChange()\"  okText=\"{{'transfer.SELECT' | translate}}\" cancelText=\"{{'product.CANCEL' | translate}}\">\n          <ion-select-option *ngFor=\"let item of secondSelectArr\" [value]=\"item.accountValue\" selected>{{item.accountLabel}}</ion-select-option>\n        </ion-select>\n        <ion-skeleton-text *ngIf=\"showLoader\" animated style=\"width: 100%;border-radius: 5px;height: 40px;\">\n        </ion-skeleton-text>\n        <!-- <ion-row class=\"standing-orders-wallet-select\" style=\"color: var(--ion-color-primary-txt);\" size=\"12\">\n          <ion-col class=\"custom-select-box\" size=\"12\" (click)=\"presentToAccountModal()\" [disabled]=\"!fromAccount\">\n            <ion-row size=\"12\">\n            <ion-col  size=\"11\">{{toAccountLabel || t.choose}}</ion-col>\n            <ion-col  size=\"1\"><ion-icon name=\"chevron-down-outline\"></ion-icon></ion-col>\n          </ion-row>\n          </ion-col>\n        </ion-row> -->\n      </ion-col>\n      <ion-row size=\"12\" [hidden] = \"showIban\">\n          <ion-label *ngIf=\"secondIban\" class=\"ion-text-capitalize iban-number\">{{'transfer.ibanNumber' | translate}}</ion-label>\n          <ion-label *ngIf=\"secondIban\" class=\"ion-text-capitalize\">{{secondIban}}</ion-label>\n      </ion-row>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-label>{{'transfer.amount' | translate}} </ion-label>\n      </ion-col>\n      <ion-col size=\"12\">\n        <ion-input required=\"true\" [disabled]=\"!fromAccount\" (keyup)=\"checkAmount(amount)\"  [(ngModel)]='amount'  type=\"number\"></ion-input>\n      </ion-col>\n      <ion-row size=\"12\" [hidden] = \"showAmountHint\">\n        <ion-label  class=\"ion-text-capitalize amountHint\">{{'transfer.amountHint' | translate}} {{firstSelectedAccount?.accountBalance}} </ion-label>\n    </ion-row>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-label>{{'transfer.notes' | translate}} </ion-label>\n      </ion-col>\n      <ion-col size=\"12\">\n        <ion-textarea required=\"true\"  [(ngModel)]='memo'  rows=\"3\" cols=\"20\"></ion-textarea>\n      </ion-col>\n    </ion-row>\n\n  </ion-grid>\n\n</ion-content>\n\n<ion-footer>\n  <ion-grid class=\"ion-padding\">\n      <app-button \n      (clickAction)=\"goToSummaryPage()\"\n      expand=\"block\" \n      size=\"\"\n      color=\"primary\"\n      fill=\"solid\"\n      strong=\"false\"\n      target=\"_blank\"\n      >\n      {{'transfer.review' | translate}}\n    </app-button>\n    \n  </ion-grid>\n</ion-footer>";

/***/ }),

/***/ 73462:
/*!**************************************************************!*\
  !*** ./src/app/pages/transfer/transfer.page.html?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>transfer</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_transfer_transfer_module_ts.js.map