import { AppTranslations } from 'src/app/app.translations';

class Translations extends AppTranslations {
    FORGOT_USERNAME_OR_PASSWORD = ['نسيت اسم المستخدم أو كلمة المرور', 'Forgot username or password'];
    FORGOT_USERNAME = ['نسيت اسم المستخدم', 'Forgout username'];
    FORGOT_PASSWORD = ['نسيت كلمة المرور', 'Forgot password'];
    ID_TYPE = ["رقم الهوية أو الإقامة", "National ID or Iqama Number"];
    ACCOUNT_NUMBER = ["رقم الحساب الاستثماري", "Investment Account Number"];
    RETRIEVE = ["استرداد", "Retrieve"];
    USERNAME = ["اسم المستخدم", "Username"];
    OK = ["حسنا", "Ok"];
    CUSTOMER_TYPE = ["نوع المستخدم", "Customer type"];
    ALINMA_ID = ["رقم هوية الإنماء الاستثماري", "Alinma Investment ID"];
    COMMERCIAL_REGISTERATION = ["السجل التجاري", "Commercial Registeration"];
    FORGOT_PASSWORD_MOBILE_MESSAGE_NOTICE = ["في حال نسيت كلمة المرور الخاصة بك فإنك من خلال هذه الصفحة تستطيع استعادتها وذلك بإدخال البيانات المطلوبة وستصلك على جوالك المسجل لدى  الإنماء للاستثمار رسالة تحتوي كلمة مرور جديدة تستخدم لمرة واحدة من خلالها تستطيع تعيين كلمة مرور جديدة", "This page allows you to recover your password by entering the required data. You will revceive an SMS message containing a one-time password. After entering it, you will be able to set a new permanent password."];
    FORGOT_USERNAME_MESSAGE_NOTICE = ["في حال نسيت اسم المستخدم الخاص بك فإنك من خلال هذه الصفحة تستطيع استعادته وذلك بإدخال البيانات المطلوبة.", "This page allows you to recover your user name by entering the required data"];
    TOKEN = ["كلمة المرور لمرة واحدة", "One Time Password"];
    PASSWORD = ["كلمة المرور الجديدة", "New Password"];
    PASSWORD_CONFIRM = ["تأكيد كلمة المرور الجديدة", "Repeated New Password"];

}


export const forgotTranslations = new Translations();