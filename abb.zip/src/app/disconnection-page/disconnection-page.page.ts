import { Component, OnDestroy, OnInit } from '@angular/core';
import { BackgroundTimer } from '@inma/helpers/background-timer';
import { AppComponent } from '../app.component';
import { MenuComponent } from '../pages/menu';

@Component({
  selector: 'tadawul-disconnection-page',
  templateUrl: './disconnection-page.page.html',
  styleUrls: ['./disconnection-page.page.scss'],
})
export class DisconnectionPagePage implements OnInit, OnDestroy {
  retryTimer: BackgroundTimer;
  timerDisplayValue: any;

  period = 4 * 1000;
  constructor() { }
  ngOnDestroy() {
    this.retryTimer.cancel();
  }

  ngOnInit() {
    this.retryTimer = new BackgroundTimer(this.period, () => {
      AppComponent.logout(false, "Reconnection retries failed !");
    });
    this.timerDisplayValue = this.formatTime(this.period);

    this.retryTimer.enableTicking(1000, (remaining) => {
      this.timerDisplayValue = this.formatTime(remaining);
    });

    this.retryTimer.start();
  }

  private formatTime(t: number) {
    t /= 1000;
    let minutes: number = parseInt(String(t / 60));
    let minutesText = (minutes < 10) ? "0" + minutes : minutes;
    let seconds: number = parseInt(String(t % 60));
    let secondsText = (seconds < 10) ? "0" + seconds : seconds;
    return minutesText + ":" + secondsText;
  }

}
