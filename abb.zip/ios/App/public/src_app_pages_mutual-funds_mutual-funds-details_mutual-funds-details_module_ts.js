"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_mutual-funds_mutual-funds-details_mutual-funds-details_module_ts"],{

/***/ 33507:
/*!************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-details/mutual-funds-details-routing.module.ts ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsDetailsPageRoutingModule": () => (/* binding */ MutualFundsDetailsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _mutual_funds_details_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-funds-details.page */ 12512);




const routes = [
    {
        path: '',
        component: _mutual_funds_details_page__WEBPACK_IMPORTED_MODULE_0__.MutualFundsDetailsPage
    }
];
let MutualFundsDetailsPageRoutingModule = class MutualFundsDetailsPageRoutingModule {
};
MutualFundsDetailsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MutualFundsDetailsPageRoutingModule);



/***/ }),

/***/ 96742:
/*!****************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-details/mutual-funds-details.module.ts ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsDetailsPageModule": () => (/* binding */ MutualFundsDetailsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _mutual_funds_details_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-funds-details-routing.module */ 33507);
/* harmony import */ var _mutual_funds_details_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mutual-funds-details.page */ 12512);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);
/* harmony import */ var src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/pipes/pipes.module */ 41041);










let MutualFundsDetailsPageModule = class MutualFundsDetailsPageModule {
};
MutualFundsDetailsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _mutual_funds_details_routing_module__WEBPACK_IMPORTED_MODULE_0__.MutualFundsDetailsPageRoutingModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateModule.forChild(),
            src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_3__.PipesModule
        ],
        declarations: [
            _mutual_funds_details_page__WEBPACK_IMPORTED_MODULE_1__.MutualFundsDetailsPage,
            // CommafyPipe
        ]
    })
], MutualFundsDetailsPageModule);



/***/ }),

/***/ 12512:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-details/mutual-funds-details.page.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsDetailsPage": () => (/* binding */ MutualFundsDetailsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _mutual_funds_details_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-funds-details.page.html?ngResource */ 24371);
/* harmony import */ var _mutual_funds_details_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mutual-funds-details.page.scss?ngResource */ 93797);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../providers/mutual-funds.service */ 1835);







let MutualFundsDetailsPage = class MutualFundsDetailsPage {
    constructor(navCtrl, translate, mutualFundsService) {
        this.navCtrl = navCtrl;
        this.translate = translate;
        this.mutualFundsService = mutualFundsService;
        this.activeSegment = 'details';
    }
    ngOnInit() {
        this.mutualFund = this.mutualFundsService.getMutualFund();
        console.log(this.mutualFund);
        this.mutualFund.details.subscribe(details => {
            this.mfDetails = details;
            console.log(this.mfDetails);
        });
    }
    positiveChecker(n) {
        return parseFloat(n) > 0;
    }
    subscribe() {
        this.mutualFundsService.setMutualFund(this.mutualFund);
        this.navCtrl.navigateForward(['main/mutual-funds-subscribe']);
    }
    redemption() {
        this.mutualFundsService.setMutualFund(this.mutualFund);
        this.navCtrl.navigateForward(['main/mutual-funds-redemption']);
    }
};
MutualFundsDetailsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslateService },
    { type: _providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_2__.MutualFundsService }
];
MutualFundsDetailsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'tadawul-mutual-funds-details',
        template: _mutual_funds_details_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_mutual_funds_details_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslateService, _providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_2__.MutualFundsService])
], MutualFundsDetailsPage);



/***/ }),

/***/ 1835:
/*!***************************************************!*\
  !*** ./src/app/providers/mutual-funds.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsService": () => (/* binding */ MutualFundsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let MutualFundsService = class MutualFundsService {
    constructor() { }
    setMutualFund(mutualFund) {
        this.mutualFund = mutualFund;
    }
    getMutualFund() {
        return this.mutualFund;
    }
};
MutualFundsService.ctorParameters = () => [];
MutualFundsService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Injectable)({
        providedIn: 'root'
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__metadata)("design:paramtypes", [])
], MutualFundsService);



/***/ }),

/***/ 93797:
/*!***************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-details/mutual-funds-details.page.scss?ngResource ***!
  \***************************************************************************************************/
/***/ ((module) => {

module.exports = ".mutual-funds-segment-bar {\n  background: transparent;\n  border-radius: 0;\n}\n.mutual-funds-segment-bar ion-segment-button {\n  --border-radius: 0;\n  --background: #005157;\n  --background-checked: #005157;\n  --background-focused: #005157;\n  --color: #ffffff;\n}\n.mutual-funds-segment-bar ion-segment-button:not(.segment-button-checked) {\n  border: 1px solid white;\n}\nbody.dark :host .mutual-funds-segment-bar ion-segment-button:not(.segment-button-checked) {\n  border: 0px;\n}\nbody.dark :host .mutual-funds-segment-bar ion-segment-button {\n  --background: #4b4b4b;\n  --background-checked: #787878;\n  --background-focused: #787878;\n  --color: #a5a5a5;\n  --color-checked: white;\n}\n.subscribed-message {\n  border: 1px solid var(--ion-color-success);\n  background: var(--ion-color-tertiary);\n  padding: 10px 15px;\n}\nion-toolbar {\n  --color: #005157;\n  --background:#005157;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm11dHVhbC1mdW5kcy1kZXRhaWxzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHVCQUFBO0VBQ0EsZ0JBQUE7QUFDSjtBQUNJO0VBQ0ksa0JBQUE7RUFRQSxxQkFBQTtFQUNBLDZCQUFBO0VBQ0EsNkJBQUE7RUFDQSxnQkFBQTtBQU5SO0FBSFE7RUFDSSx1QkFBQTtBQUtaO0FBSFE7RUFDSSxXQUFBO0FBS1o7QUFDUTtFQUNJLHFCQUFBO0VBQ0EsNkJBQUE7RUFDQSw2QkFBQTtFQUNBLGdCQUFBO0VBQ0Esc0JBQUE7QUFDWjtBQUlBO0VBRUksMENBQUE7RUFDQSxxQ0FBQTtFQUNBLGtCQUFBO0FBRko7QUFLQTtFQUNFLGdCQUFBO0VBQ0Esb0JBQUE7QUFGRiIsImZpbGUiOiJtdXR1YWwtZnVuZHMtZGV0YWlscy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubXV0dWFsLWZ1bmRzLXNlZ21lbnQtYmFyIHtcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICBib3JkZXItcmFkaXVzOiAwO1xuXG4gICAgaW9uLXNlZ21lbnQtYnV0dG9uIHtcbiAgICAgICAgLS1ib3JkZXItcmFkaXVzOiAwO1xuICAgICAgICBcbiAgICAgICAgJjpub3QoLnNlZ21lbnQtYnV0dG9uLWNoZWNrZWQpIHtcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHdoaXRlO1xuICAgICAgICB9XG4gICAgICAgIGJvZHkuZGFyayA6aG9zdCAmOm5vdCguc2VnbWVudC1idXR0b24tY2hlY2tlZCkge1xuICAgICAgICAgICAgYm9yZGVyOiAwcHg7XG4gICAgICAgIH1cbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjMDA1MTU3O1xuICAgICAgICAtLWJhY2tncm91bmQtY2hlY2tlZDogIzAwNTE1NztcbiAgICAgICAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6ICMwMDUxNTc7XG4gICAgICAgIC0tY29sb3I6ICNmZmZmZmY7XG4gICAgICAgIGJvZHkuZGFyayA6aG9zdCAme1xuICAgICAgICAgICAgLS1iYWNrZ3JvdW5kOiAjNGI0YjRiO1xuICAgICAgICAgICAgLS1iYWNrZ3JvdW5kLWNoZWNrZWQ6ICM3ODc4Nzg7XG4gICAgICAgICAgICAtLWJhY2tncm91bmQtZm9jdXNlZDogIzc4Nzg3ODtcbiAgICAgICAgICAgIC0tY29sb3I6ICNhNWE1YTU7XG4gICAgICAgICAgICAtLWNvbG9yLWNoZWNrZWQgOiB3aGl0ZTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLnN1YnNjcmliZWQtbWVzc2FnZSB7XG4gICAgLy8gYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXN1Y2Nlc3Mtc2hhZGUpO1xuICAgIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1zdWNjZXNzKTtcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItdGVydGlhcnkpO1xuICAgIHBhZGRpbmc6IDEwcHggMTVweDtcbn1cblxuaW9uLXRvb2xiYXIge1xuICAtLWNvbG9yOiAjMDA1MTU3O1xuICAtLWJhY2tncm91bmQ6IzAwNTE1Nztcbn0iXX0= */";

/***/ }),

/***/ 24371:
/*!***************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-details/mutual-funds-details.page.html?ngResource ***!
  \***************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n    <ion-toolbar>\n      <ion-buttons slot=\"start\">\n        <ion-back-button text=\"\"></ion-back-button>\n      </ion-buttons>\n      <ion-segment class=\"mutual-funds-segment-bar\" [(ngModel)]=\"activeSegment\">\n        <ion-segment-button value=\"details\">\n          {{'mutualFund.MUTUAL_FUND_DETAILS' | translate}}\n        </ion-segment-button>\n        <ion-segment-button value=\"fees\">\n          {{'mutualFund.MUTUAL_FUND_FEES' | translate}}\n        </ion-segment-button>\n      </ion-segment>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <!-- FIRST TAB -->\n    <div class=\"ion-padding\" *ngIf=\"activeSegment === 'details'\">\n      <div class=\"subscribed-message ion-margin-bottom\" *ngIf=\"mutualFund.ownedUnits\">\n        <ion-text class=\"label font-size-overline\" color=\"success\">{{'mutualFund.YOU_ARE_SUBSCRIBED_TO_THIS_FUND' | translate}}</ion-text>\n      </div>\n      <ion-row class=\"data-row dark\">\n        <ion-col size=\"6\">\n          <ion-text class=\"label font-size-caption\" >{{'mutualFund.MUTUAL_FUND_NAME' | translate}}</ion-text>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-text class=\"value font-size-caption bold\" >{{ mutualFund?.name }}</ion-text>\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"data-row\">\n        <ion-col size=\"6\">\n          <ion-text class=\"label font-size-caption\" >{{'mutualFund.INVESTMENT_STRATEGY' | translate}}</ion-text>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-text class=\"value font-size-caption bold\" >{{ mfDetails?.investmentStrategy }}</ion-text>\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"data-row dark\">\n        <ion-col size=\"6\">\n          <ion-text class=\"label font-size-caption\" >{{'mutualFund.OBJECTIVE' | translate}}</ion-text>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-text class=\"value font-size-caption bold\" >{{ mfDetails?.objective }}</ion-text>\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"data-row\">\n        <ion-col size=\"6\">\n          <ion-text class=\"label font-size-caption\" >{{'mutualFund.CURRENCY' | translate}}</ion-text>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-text class=\"value font-size-caption bold\" >{{ translate.instant('mutualFund.'+mfDetails?.currency) }}</ion-text>\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"data-row dark\">\n        <ion-col size=\"6\">\n          <ion-text class=\"label font-size-caption\" >{{'mutualFund.EVALUATION_DAYS' | translate}}</ion-text>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-text class=\"value font-size-caption bold\" >{{ mfDetails?.evaluationDays }}</ion-text>\n          <ion-text class=\"value font-size-caption bold\"  *ngIf='mfDetails?.evaluationDaysTime'>\n              {{ 'mutualFund.AT_TIME' | translate }} {{ mfDetails?.evaluationDaysTime }}</ion-text>\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"data-row\">\n        <ion-col size=\"6\">\n          <ion-text class=\"label font-size-caption\" >{{'mutualFund.INCEPTION_DATE' | translate}}</ion-text>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-text class=\"value font-size-caption bold\" >{{ mfDetails?.inceptionDate }}</ion-text>\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"data-row dark\">\n        <ion-col size=\"6\">\n          <ion-text class=\"label font-size-caption\" >{{'mutualFund.INCEPTION_PRICE' | translate}}</ion-text>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-text class=\"value font-size-caption bold\" >{{ mfDetails?.inceptionPrice }}</ion-text>\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"data-row\">\n        <ion-col size=\"6\">\n          <ion-text class=\"label font-size-caption\" >{{'mutualFund.INVESTING_MARKETS' | translate}}</ion-text>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-text class=\"value font-size-caption bold\" >{{ mfDetails?.investingMarkets }}</ion-text>\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"data-row dark\">\n        <ion-col size=\"6\">\n          <ion-text class=\"label font-size-caption\" >{{'mutualFund.LAST_PRICE' | translate}}</ion-text>\n        </ion-col>\n        <ion-col size=\"6\">\n            <ion-text class=\"value font-size-caption bold\" >\n              {{ mfDetails?.lastPrice | number:'1.0-2' | commafy }}\n              {{ translate.instant('mutualFund.'+mfDetails?.lastPriceType) }}\n              {{'mutualFund.LAST_PRICE_AT' | translate}}\n              {{ mfDetails?.lastPriceDate }}\n            </ion-text>\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"data-row\">\n        <ion-col size=\"6\">\n          <ion-text class=\"label font-size-caption\" >{{'mutualFund.YEAR_TO_DAY_CHANGE_PERCENTAGE' | translate}}</ion-text>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-text class=\"value font-size-caption bold\" dir=\"ltr\" [color]=\"positiveChecker(mfDetails?.yearToDayChange) ? 'success' : 'danger'\">\n            {{ mfDetails?.yearToDayChange | number:'1.0-2' | commafy}}%\n          </ion-text>\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"data-row dark\">\n        <ion-col size=\"6\">\n          <ion-text class=\"label font-size-caption\" >{{'mutualFund.MINIMUM_INITIAL_SUBSCRIPTION' | translate}}</ion-text>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-text class=\"value font-size-caption bold\" >{{ mfDetails?.minimumInitialSubscription | number:'1.0-2' | commafy }} {{ translate.instant('mutualFund.'+mfDetails?.minimumInitialSubscriptionType) }}</ion-text>\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"data-row\">\n        <ion-col size=\"6\">\n          <ion-text class=\"label font-size-caption\" >{{'mutualFund.MIN_ADDITIONAL_SUBSCRIPTION' | translate}}</ion-text>\n        </ion-col>\n        <ion-col size=\"6\">\n            <ion-text class=\"value font-size-caption bold\" >{{ mfDetails?.minAdditionalSubscription | number:'1.0-2' | commafy }} {{ translate.instant('mutualFund.'+mfDetails?.minAdditionalSubscriptionType) }}</ion-text>\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"data-row dark\">\n        <ion-col size=\"6\">\n          <ion-text class=\"label font-size-caption\" >{{'mutualFund.MINIMUM_REDEMPTION' | translate}}</ion-text>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-text class=\"value font-size-caption bold\"  *ngIf=\"mutualFund?.isStandard == true\">\n            {{ mfDetails?.minimumRedemption | number:'1.0-2' | commafy }} {{ translate.instant('mutualFund.'+mfDetails?.minimumRedemptionUnit) }}\n          </ion-text>\n          <ion-text class=\"value font-size-caption bold\"  *ngIf=\"mutualFund?.isStandard == false\">\n            {{ 'mutualFund.NO_REDEMPTION' | translate }}\n          </ion-text>\n        </ion-col>\n      </ion-row>\n      <ion-grid>\n          <ion-row>\n            <ion-col>\n              <app-button \n                (clickAction)=\"subscribe()\"\n                expand=\"block\" \n                size=\"\"\n                color=\"success\"\n                fill=\"solid\"\n                shape=\"\"\n                type=\"button\"\n                >\n                {{'mutualFund.ADD_UNITS' | translate}}\n              </app-button>\n            </ion-col>\n            <!-- test: {{mutualFund?.isSubscribed | async}} -->\n            <!-- test: {{mutualFund?.isStandard}} -->\n            <ion-col *ngIf=\"!mutualFund.isCharity && (mutualFund?.isSubscribed | async)\">\n              <app-button \n                (clickAction)=\"redemption()\"\n                expand=\"block\" \n                size=\"\"\n                color=\"danger\"\n                fill=\"solid\"\n                shape=\"\"\n                type=\"button\"\n                >\n                {{'mutualFund.REDEEM_UNITS' | translate}}\n              </app-button>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n    </div>\n\n    <!-- SECOND TAB -->\n    <div class=\"ion-padding\" *ngIf=\"activeSegment === 'fees'\">\n      <!-- FIRST SECTION -->\n      <ion-text class=\"font-size-body ion-margin-bottom\" >{{'mutualFund.SUBSCRIPTION_FEES' | translate}}</ion-text>\n      <div class=\"box-with-bg bordered ion-margin-bottom\">\n        <ion-row class=\"data-row\">\n          <ion-col size=\"7\">\n            <ion-text class=\"label font-size-caption\" >{{'mutualFund.MINIMUM_INITIAL_SUBSCRIPTION' | translate}}</ion-text>\n          </ion-col>\n          <ion-col size=\"5\">\n            <ion-text class=\"value font-size-caption bold\" >\n              {{ mfDetails?.minimumInitialSubscription | number:'1.0-2' | commafy }} {{ translate.instant('mutualFund.'+mfDetails?.minimumInitialSubscriptionType) }}\n            </ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"data-row\">\n          <ion-col size=\"7\">\n            <ion-text class=\"label font-size-caption\" >{{'mutualFund.MIN_ADDITIONAL_SUBSCRIPTION' | translate}}</ion-text>\n          </ion-col>\n          <ion-col size=\"5\">\n            <ion-text class=\"value font-size-caption bold\" >\n              {{ mfDetails?.minAdditionalSubscription | number:'1.0-2' | commafy }} {{ translate.instant('mutualFund.'+mfDetails?.minAdditionalSubscriptionType) }}\n            </ion-text>\n          </ion-col>\n        </ion-row>\n      </div>\n\n      <!-- SECOND SECTION -->\n      <ion-text class=\"font-size-body\" >{{'mutualFund.REDEMPTION_FEES' | translate}}</ion-text>\n      <div class=\"box-with-bg bordered ion-margin-bottom\">\n        <ion-row class=\"data-row\">\n          <ion-col size=\"7\">\n            <ion-text class=\"label font-size-caption\" >{{'mutualFund.REDEMPTION_FEES' | translate}}</ion-text>\n          </ion-col>\n          <ion-col size=\"5\">\n            <ion-text class=\"value font-size-caption bold\" >\n              {{ mfDetails?.redemptionFees }} {{ translate.instant('mutualFund.'+mfDetails?.redemptionFeesType) }}\n            </ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"data-row\">\n          <ion-col size=\"7\">\n            <ion-text class=\"label font-size-caption\" >{{'mutualFund.CUSTODY_FEES' | translate}}</ion-text>\n          </ion-col>\n          <ion-col size=\"5\">\n            <ion-text class=\"value font-size-caption bold\" >\n              {{ mfDetails?.custodyFees }} {{ mfDetails?.custodyFeesType }}\n            </ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"data-row\">\n          <ion-col size=\"7\">\n            <ion-text class=\"label font-size-caption\" >{{'mutualFund.EARLY_REDEMPTION_FEES' | translate}}</ion-text>\n          </ion-col>\n          <ion-col size=\"5\">\n            <ion-text class=\"value font-size-caption bold\" >\n              {{ mfDetails?.earlyRedemptionFees }} {{ translate.instant('mutualFund.'+mfDetails?.earlyRedemptionFeesType) }}\n            </ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"data-row\">\n          <ion-col size=\"7\">\n            <ion-text class=\"label font-size-caption\" >{{'mutualFund.EARLY_REDEMPTION_FEES_POLICY' | translate}}</ion-text>\n          </ion-col>\n          <ion-col size=\"5\">\n            <ion-text class=\"value font-size-caption bold\" >{{ mfDetails?.earlyRedemptionFeesPolicy }}</ion-text>\n          </ion-col>\n        </ion-row>\n      </div>\n\n      <!-- THIRD SECTION -->\n      <ion-text class=\"font-size-body ion-margin-bottom\" >{{'mutualFund.OTHER_FEES' | translate}}</ion-text>\n      <div class=\"box-with-bg bordered ion-margin-bottom\">\n        <ion-row class=\"data-row\">\n          <ion-col size=\"7\">\n            <ion-text class=\"label font-size-caption\" >{{'mutualFund.OTHER_FEES' | translate}}</ion-text>\n          </ion-col>\n          <ion-col size=\"5\">\n            <ion-text class=\"value font-size-caption bold\" >\n              {{ mfDetails?.otherFees | number:'1.0-2' | commafy }} {{ mfDetails?.otherFeesType }}\n            </ion-text>\n          </ion-col>\n        </ion-row>\n      </div>\n      <ion-grid>\n          <ion-row>\n            <ion-col>\n              <app-button \n                expand=\"block\" \n                size=\"\"\n                color=\"success\"\n                fill=\"solid\"\n                shape=\"\"\n                type=\"button\"\n                (clickAction)=\"subscribe()\"\n                >\n                {{'mutualFund.SUBSCRIBE' | translate}}\n              </app-button>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n    </div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_mutual-funds_mutual-funds-details_mutual-funds-details_module_ts.js.map