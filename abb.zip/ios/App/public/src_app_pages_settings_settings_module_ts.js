"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_settings_settings_module_ts"],{

/***/ 70535:
/*!***********************************************************!*\
  !*** ./src/app/pages/settings/settings-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SettingsPageRoutingModule": () => (/* binding */ SettingsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _settings_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./settings.page */ 15311);




const routes = [
    {
        path: '',
        component: _settings_page__WEBPACK_IMPORTED_MODULE_0__.SettingsPage
    },
    {
        path: 'change-password',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_user-profile_change-password_change-password_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../user-profile/change-password/change-password.module */ 49638)).then(m => m.ChangePasswordPageModule)
    },
    {
        path: 'change-mobile',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_user-profile_change-mobile-number_change-mobile_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../user-profile/change-mobile-number/change-mobile.module */ 79671)).then(m => m.ChangeMobilePageModule)
    }
];
let SettingsPageRoutingModule = class SettingsPageRoutingModule {
};
SettingsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SettingsPageRoutingModule);



/***/ }),

/***/ 94932:
/*!***************************************************!*\
  !*** ./src/app/pages/settings/settings.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SettingsPageModule": () => (/* binding */ SettingsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _settings_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./settings-routing.module */ 70535);
/* harmony import */ var _settings_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./settings.page */ 15311);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);








let SettingsPageModule = class SettingsPageModule {
};
SettingsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _settings_routing_module__WEBPACK_IMPORTED_MODULE_0__.SettingsPageRoutingModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule
        ],
        providers: [],
        declarations: [_settings_page__WEBPACK_IMPORTED_MODULE_1__.SettingsPage]
    })
], SettingsPageModule);



/***/ }),

/***/ 15311:
/*!*************************************************!*\
  !*** ./src/app/pages/settings/settings.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SettingsPage": () => (/* binding */ SettingsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _settings_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./settings.page.html?ngResource */ 30869);
/* harmony import */ var _settings_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./settings.page.scss?ngResource */ 60297);
/* harmony import */ var _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/helpers/settings */ 96892);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_helpers_translations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/helpers/translations */ 69353);
/* harmony import */ var _settings_translations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./settings.translations */ 87374);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! jquery */ 85139);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _menu__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../menu */ 69626);
/* harmony import */ var _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @inma/helpers/cached */ 569);
/* harmony import */ var _inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @inma/helpers/biometric */ 16406);
/* harmony import */ var _inma_models_users__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @inma/models/users */ 17166);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 93819);














let SettingsPage = class SettingsPage {
    constructor(sharedData, elementRef, cdr, navCtrl) {
        this.sharedData = sharedData;
        this.elementRef = elementRef;
        this.cdr = cdr;
        this.navCtrl = navCtrl;
        this.t = _settings_translations__WEBPACK_IMPORTED_MODULE_4__.SettingsTranslations;
        this.showChangePwdSuccess = false;
        this.showChangeMobileSuccess = false;
        this.MenuComponent = _menu__WEBPACK_IMPORTED_MODULE_7__.MenuComponent;
        this.firstLanguageChange = true;
        this.firstBiometricChange = true;
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.getUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.enableBiometricKey).subscribe((val) => {
            if (val == null || val == "true")
                this.biometricEnabled = true;
            else
                this.biometricEnabled = false;
        });
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.getUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.enableNotficationKey).subscribe((val) => {
            if (val == null || val == "true")
                this.notificationEnabled = true;
            else
                this.notificationEnabled = false;
        });
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.getUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.preferedLanguageKey).subscribe((val) => {
            if (val == null || val == "ar")
                this.currentLanguage = "ar";
            else
                this.currentLanguage = "en";
        });
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.getUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.preferedThemeKey).subscribe((val) => {
            if (val == null || val == "light-theme")
                this.currentTheme = "light-theme";
            else
                this.currentTheme = "dark-theme";
        });
    }
    ngOnInit() {
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.getUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.preferedThemeKey).subscribe((val) => {
            if (val == null || val == "light-theme")
                this.currentTheme = "light-theme";
            else
                this.currentTheme = "dark-theme";
        });
    }
    currentThemeChanged(event) {
        const lastCurrentTheme = this.currentTheme;
        this.currentTheme = event.detail.value;
        this.saveTheme();
        if (lastCurrentTheme != this.currentTheme) {
            _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.setTheme();
        }
    }
    ionViewWillEnter() {
        let passwordchanged = this.sharedData.getSharedData("password_changed", false);
        if (passwordchanged) {
            this.showChangePwdSuccess = this.sharedData.getSharedData("password_changed", true);
        }
        else {
            this.showChangePwdSuccess = false;
        }
        let mobileChanged = this.sharedData.getSharedData("mobile_changed", false);
        if (mobileChanged) {
            this.showChangeMobileSuccess = this.sharedData.getSharedData("mobile_changed", true);
        }
        else {
            this.showChangeMobileSuccess = false;
        }
    }
    currentLanguageChanged(event) {
        const lastCurrentLanguage = this.currentLanguage;
        this.currentLanguage = event.detail.value;
        this.sharedData.appLanguage.next(this.currentLanguage);
        // Settings.language = Number(this.currentLanguage == 'ar' ? 0 : 1);
        this.saveLanguage();
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.setLanguage();
        if (!this.firstLanguageChange) {
            // IONIC bug, we have to do it manually !
            jquery__WEBPACK_IMPORTED_MODULE_6__("ion-back-button").toggleClass("flip-x");
            setTimeout(() => {
                _menu__WEBPACK_IMPORTED_MODULE_7__.MenuComponent.isLanguageToggled = !_menu__WEBPACK_IMPORTED_MODULE_7__.MenuComponent.isLanguageToggled;
                this.cdr.detectChanges();
            }, 100);
            (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_8__.resetGlobalCaches)();
        }
        this.firstLanguageChange = false;
        // debugger
        setTimeout(() => {
            (0,_inma_helpers_translations__WEBPACK_IMPORTED_MODULE_3__.localizeApp)(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.language);
        }, 100);
        // if (lastCurrentLanguage != this.currentLanguage) {
        //   AppComponent.restart();
        // }
    }
    saveBiometric($event) {
        console.log(this.firstBiometricChange);
        if (this.firstBiometricChange) {
            this.firstBiometricChange = false;
            return;
        }
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.setUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.enableBiometricKey, this.biometricEnabled.toString());
        //////
        if (this.biometricEnabled) {
            _inma_models_users__WEBPACK_IMPORTED_MODULE_10__.Users.current.biometricAuthenticate().subscribe((result) => {
                debugger;
                if (!result)
                    setTimeout(() => {
                        this.biometricEnabled = false;
                        this.firstBiometricChange = true;
                    }, 0);
                else
                    this.navCtrl.navigateBack("settings");
            });
        }
        else {
            _inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_9__.Biometric["delete"]().subscribe((result) => {
                debugger;
                if (!result)
                    setTimeout(() => {
                        this.biometricEnabled = true;
                        this.firstBiometricChange = true;
                    }, 0);
            });
        }
    }
    saveNotfication($event) {
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.setUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.enableNotficationKey, this.notificationEnabled.toString());
    }
    saveLanguage() {
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.setUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.preferedLanguageKey, this.currentLanguage);
    }
    saveTheme() {
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.setUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.preferedThemeKey, this.currentTheme);
    }
};
SettingsPage.ctorParameters = () => [
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_5__.SharedDataService },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_11__.ElementRef },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_11__.ChangeDetectorRef },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.NavController }
];
(0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([
    (0,_inma_helpers_translations__WEBPACK_IMPORTED_MODULE_3__.Translations)(),
    (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:type", Object)
], SettingsPage.prototype, "t", void 0);
SettingsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        selector: "tadawul-settings",
        template: _settings_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_settings_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:paramtypes", [src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_5__.SharedDataService,
        _angular_core__WEBPACK_IMPORTED_MODULE_11__.ElementRef,
        _angular_core__WEBPACK_IMPORTED_MODULE_11__.ChangeDetectorRef,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.NavController])
], SettingsPage);



/***/ }),

/***/ 87374:
/*!*********************************************************!*\
  !*** ./src/app/pages/settings/settings.translations.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SettingsTranslations": () => (/* binding */ SettingsTranslations)
/* harmony export */ });
class Translations {
    constructor() {
        this.SETTINGS = ['الإعدادات', 'Settings'];
        this.ENABLE_BIOMETRIC = ['تفعيل البصمة', 'Enable Biometric'];
        this.ENABLE_BIOMETRIC_DESCRIPTION = ['تفعيل استخدام البصمة أو إلغاؤها عند الدخول', 'Activate or cancel the use of the fingerprint upon entry'];
        this.ENABLE_NOTIFICATION = ['استقبال الإشعارات', 'Receive Notifications'];
        this.ENABLE_NOTIFICATION_DESCRIPTION = ['يمكنك الاختيار ما بين استقبال الإشعارات أو إلغاؤها', 'You can choose whether or not to receive notifications'];
        this.CHANGE_LANGUAGE = ['تغيير اللغة', 'Change Language'];
        this.CHANGE_LANGUAGE_DESCRIPTION = ['اختر اللغة المفضلة لديك لتظهر لك كل معلومات التطبيق بها', 'Choose your preferred language to show you all the application information in it'];
        this.CHANGE_THEME = ['تغيير المظهر', 'Change Theme'];
        this.LIGHT = ['فاتح', 'Light'];
        this.DARK = ['غامق', 'Dark'];
        this.CHANGE_MOBILE_NUMBER = ['تغيير رقم الجوال', 'Change mobile number'];
        this.CHANGE_PASSWORD = ['تغيير كلمة المرور', 'Change Password'];
        this.SAVE_SETTINGS = ['حفظ الإعدادات', 'Save Settings'];
        this.PASSWORD_CHANGE_SUCCESS = ['تم تغيير كلمة المرور بنجاح', 'Password changed successfully'];
        this.MOBILE_CHANGE_SUCCESS = ['تم تغيير رقم الجوال بنجاح', 'Mobile number changed successfully'];
    }
}
const SettingsTranslations = new Translations();


/***/ }),

/***/ 60297:
/*!**************************************************************!*\
  !*** ./src/app/pages/settings/settings.page.scss?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "ion-toolbar {\n  --background: #005157;\n  --color: white;\n}\n\nion-item {\n  --transition: none;\n  --color: var(--ion-color-primary-txt);\n  --border-color: rgba(205, 223, 225, 0.5);\n  --padding-start: 0px;\n}\n\nion-radio {\n  display: inline-block;\n}\n\n.img {\n  width: 37px;\n  height: 81px;\n  display: block;\n  border-radius: 7px;\n}\n\ndiv.change-theme {\n  display: inline-block;\n  margin-right: 24px;\n  margin-left: 24px;\n}\n\nion-radio-group {\n  display: block;\n  text-align: center;\n}\n\nion-back-button {\n  color: white;\n}\n\np {\n  font-size: 11px;\n  color: #787878;\n  margin-bottom: 0px;\n}\n\nion-segment {\n  border-radius: 28px;\n  --background: var(--ion-color-light);\n  border: 1px solid rgba(205, 223, 225, 0.5);\n}\n\nion-segment ion-segment-button {\n  --border-radius: 28px;\n  padding: 0;\n  --indicator-color: var(--ion-color-primary-txt);\n  margin: 0;\n  --color-checked: var(--ion-color-light);\n  --transition: color 0.25s;\n}\n\n.change-success {\n  color: #2ebd85;\n  height: 40px;\n  border: solid 1px #2ebd85;\n  background-color: #deffef;\n  vertical-align: middle;\n  display: flex;\n  align-items: center;\n  margin: 16px;\n  padding: 16px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNldHRpbmdzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHFCQUFBO0VBQ0EsY0FBQTtBQUNKOztBQUVBO0VBQ0ksa0JBQUE7RUFFQSxxQ0FBQTtFQUNBLHdDQUFBO0VBQ0Esb0JBQUE7QUFBSjs7QUFHQTtFQUNJLHFCQUFBO0FBQUo7O0FBR0E7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQUFKOztBQUdBO0VBQ0kscUJBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0FBQUo7O0FBR0E7RUFDSSxjQUFBO0VBQ0Esa0JBQUE7QUFBSjs7QUFHQTtFQUNJLFlBQUE7QUFBSjs7QUFHQTtFQUNJLGVBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUFBSjs7QUFJQTtFQUNJLG1CQUFBO0VBQ0Esb0NBQUE7RUFDQSwwQ0FBQTtBQURKOztBQUVJO0VBQ0kscUJBQUE7RUFDQSxVQUFBO0VBQ0EsK0NBQUE7RUFDQSxTQUFBO0VBQ0EsdUNBQUE7RUFDQSx5QkFBQTtBQUFSOztBQUlBO0VBQ0ksY0FBQTtFQUNBLFlBQUE7RUFDQSx5QkFBQTtFQUNBLHlCQUFBO0VBQ0Esc0JBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtBQURKIiwiZmlsZSI6InNldHRpbmdzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10b29sYmFyIHtcbiAgICAtLWJhY2tncm91bmQ6ICMwMDUxNTc7XG4gICAgLS1jb2xvcjogd2hpdGU7XG59XG5cbmlvbi1pdGVtIHtcbiAgICAtLXRyYW5zaXRpb24gIDogbm9uZTtcbiAgICAvLyAtLWNvbG9yICAgICAgIDogIzAwNTE1NztcbiAgICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS10eHQpO1xuICAgIC0tYm9yZGVyLWNvbG9yOiByZ2JhKDIwNSwgMjIzLCAyMjUsIDAuNSk7XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAwcHg7XG59XG5cbmlvbi1yYWRpbyB7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xufVxuXG4uaW1nIHtcbiAgICB3aWR0aDogMzdweDtcbiAgICBoZWlnaHQ6IDgxcHg7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgYm9yZGVyLXJhZGl1czogN3B4O1xufVxuXG5kaXYuY2hhbmdlLXRoZW1lIHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgbWFyZ2luLXJpZ2h0OiAyNHB4O1xuICAgIG1hcmdpbi1sZWZ0OiAyNHB4O1xufVxuXG5pb24tcmFkaW8tZ3JvdXB7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG5pb24tYmFjay1idXR0b24ge1xuICAgIGNvbG9yOiB3aGl0ZTtcbn1cblxucCB7XG4gICAgZm9udC1zaXplOiAxMXB4O1xuICAgIGNvbG9yOiAjNzg3ODc4O1xuICAgIG1hcmdpbi1ib3R0b206IDBweDtcbn1cblxuXG5pb24tc2VnbWVudCB7XG4gICAgYm9yZGVyLXJhZGl1czogMjhweDtcbiAgICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1saWdodCk7XG4gICAgYm9yZGVyOiAxcHggc29saWQgcmdiYSgyMDUsIDIyMywgMjI1LCAwLjUpO1xuICAgIGlvbi1zZWdtZW50LWJ1dHRvbiB7XG4gICAgICAgIC0tYm9yZGVyLXJhZGl1czogMjhweDtcbiAgICAgICAgcGFkZGluZzogMDtcbiAgICAgICAgLS1pbmRpY2F0b3ItY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXR4dCk7XG4gICAgICAgIG1hcmdpbjogMDtcbiAgICAgICAgLS1jb2xvci1jaGVja2VkOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xuICAgICAgICAtLXRyYW5zaXRpb246IGNvbG9yIDAuMjVzO1xuICAgIH1cbn1cblxuLmNoYW5nZS1zdWNjZXNzIHtcbiAgICBjb2xvcjogIzJlYmQ4NTtcbiAgICBoZWlnaHQ6IDQwcHg7XG4gICAgYm9yZGVyOiBzb2xpZCAxcHggIzJlYmQ4NTtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZGVmZmVmO1xuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIG1hcmdpbjogMTZweDtcbiAgICBwYWRkaW5nOiAxNnB4O1xuICB9Il19 */";

/***/ }),

/***/ 30869:
/*!**************************************************************!*\
  !*** ./src/app/pages/settings/settings.page.html?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button [text]=\"''\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{t.SETTINGS}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div *ngIf=\"showChangePwdSuccess\" class='change-success'>\n    {{t.PASSWORD_CHANGE_SUCCESS}}\n  </div>\n  <div *ngIf=\"showChangeMobileSuccess\" class='change-success'>\n    {{t.MOBILE_CHANGE_SUCCESS}}\n  </div>\n\n  <ion-list>\n    \n    <ion-item>\n      <ion-grid>\n      <ion-row>\n        <ion-col size=\"10\">\n          <ion-label>\n            {{t.ENABLE_BIOMETRIC}}\n          </ion-label>\n          <ion-text><p>{{t.ENABLE_BIOMETRIC_DESCRIPTION}}</p></ion-text>\n        </ion-col>\n        <ion-col size=\"2\">\n          <ion-toggle (ionChange)=\"saveBiometric($event)\" mode=\"ios\" [(ngModel)]=\"biometricEnabled\" ></ion-toggle>\n        </ion-col>\n      </ion-row>\n      </ion-grid>\n    </ion-item>\n\n    <ion-item>\n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"10\">\n            <ion-label>\n              {{t.ENABLE_NOTIFICATION}}\n            </ion-label>\n            <ion-text><p>{{t.ENABLE_NOTIFICATION_DESCRIPTION}}</p></ion-text>\n          </ion-col>\n          <ion-col size=\"2\">\n            <ion-toggle (ionChange)=\"saveNotfication($event)\" mode=\"ios\" [(ngModel)]=\"notificationEnabled\" ></ion-toggle>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </ion-item>\n\n    <ion-item>\n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"6\">\n            <ion-label>\n              {{t.CHANGE_LANGUAGE}}\n            </ion-label>\n            <ion-text><p>{{t.CHANGE_LANGUAGE_DESCRIPTION}}</p></ion-text>\n          </ion-col>\n          <ion-col size=\"6\">\n            <ion-segment\n              [value]=\"currentLanguage\"\n              (ionChange)=\"currentLanguageChanged($event)\">\n              <ion-segment-button value=\"ar\">\n                العربية\n              </ion-segment-button>\n              <ion-segment-button value=\"en\">\n                English\n              </ion-segment-button>\n            </ion-segment>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </ion-item>\n\n    <ion-item>\n      <ion-grid>\n        \n        <ion-row>\n          <ion-label>\n            {{t.CHANGE_THEME}}\n          </ion-label>\n        </ion-row>\n\n        <ion-row>\n          <ion-col text-center>\n            <ion-radio-group \n            (ionChange)=\"currentThemeChanged($event)\"\n            [value]=\"currentTheme\">\n              <ion-col>\n                <div class=\"change-theme\">\n                  <img class=\"img\" src=\"../../../assets/icon/light-theme@3x.jpg\" alt=\"\">\n                  <p>{{t.LIGHT}}</p>\n                  <ion-radio mode=\"md\" value=\"light-theme\"></ion-radio>\n              </div>\n              </ion-col>\n              <ion-col>\n                <div class=\"change-theme\">\n                  <img class=\"img\" src=\"../../../assets/icon/dark-theme@3x.jpg\" alt=\"\">\n                  <p>{{t.DARK}}</p>\n                  <ion-radio mode=\"md\" value=\"dark-theme\"></ion-radio>\n                </div>\n              </ion-col>\n            </ion-radio-group>\n          </ion-col>\n        </ion-row>\n\n      </ion-grid>\n    </ion-item>\n\n    <ion-item button routerLink=\"/settings/change-mobile\">\n      <ion-label>\n        {{t.CHANGE_MOBILE_NUMBER}}\n      </ion-label>\n    </ion-item>\n\n    <ion-item button routerLink=\"/settings/change-password\">\n      <ion-label>\n        {{t.CHANGE_PASSWORD}}\n      </ion-label>\n    </ion-item>\n\n  </ion-list>\n  \n  <!-- <app-button\n  expand=\"block\"\n  (click)=\"saveSettings()\"\n  >\n    {{t.SAVE_SETTINGS}}\n  </app-button> -->\n  \n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_settings_settings_module_ts.js.map