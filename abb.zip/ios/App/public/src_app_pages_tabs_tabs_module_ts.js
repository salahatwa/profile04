"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_tabs_tabs_module_ts"],{

/***/ 31604:
/*!****************************************************************************!*\
  !*** ./src/app/common-ui-components/unlocker/unlocker.component.module.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UnlockerComponentModule": () => (/* binding */ UnlockerComponentModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _unlocker__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./unlocker */ 88534);



let UnlockerComponentModule = class UnlockerComponentModule {
};
UnlockerComponentModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_unlocker__WEBPACK_IMPORTED_MODULE_0__.Unlocker],
        imports: [],
        exports: [_unlocker__WEBPACK_IMPORTED_MODULE_0__.Unlocker]
    })
], UnlockerComponentModule);



/***/ }),

/***/ 88534:
/*!***********************************************************!*\
  !*** ./src/app/common-ui-components/unlocker/unlocker.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Unlocker": () => (/* binding */ Unlocker)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _unlocker_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./unlocker.html?ngResource */ 58863);
/* harmony import */ var _unlocker_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./unlocker.scss?ngResource */ 40593);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! jquery */ 85139);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_2__);





const MIN_VALUE_TO_UNLOCK = 90; // How much percentage the user should reach to make the unlock effect, max is 100 (=100%)
let Unlocker = class Unlocker {
    constructor(el) {
        this.el = el;
        this.unlocked = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
        this.progress = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
        this.wasUnlocked = false;
    }
    checkUnlock(evt) {
        let theRange = Number(this.input.nativeElement.value);
        // if (theRange === (100 - MIN_VALUE_TO_UNLOCK)) {
        //   this.unlockAction();
        // } else {
        clearInterval(this.setIntID);
        this.setIntID = setInterval(() => {
            if (this.input.nativeElement.value < 100) {
                this.input.nativeElement.value = theRange++;
            }
            else {
                this.input.nativeElement.value = 100;
                this.wasUnlocked = false;
                clearInterval(this.setIntID);
            }
            this.onProgress(null);
        }, 1);
        // }
    }
    onProgress(evt) {
        let progress = this.input.nativeElement.value;
        if (this.wasUnlocked == false && progress <= (100 - MIN_VALUE_TO_UNLOCK)) {
            this.unlockAction();
            this.wasUnlocked = true;
        }
        this.progress.emit(progress);
    }
    unlockAction() {
        this.unlocked.emit(true);
        jquery__WEBPACK_IMPORTED_MODULE_2__(this.el.nativeElement).fadeOut('fast', () => {
            this.input.nativeElement.value = 100;
            jquery__WEBPACK_IMPORTED_MODULE_2__(this.el.nativeElement).fadeIn('slow');
            this.onProgress(null);
        });
    }
    ngOnDestroy() {
        clearInterval(this.setIntID);
    }
};
Unlocker.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.ElementRef }
];
Unlocker.propDecorators = {
    unlocked: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }],
    progress: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }],
    input: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.ViewChild, args: ['unlock',] }],
    disabled2: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }]
};
Unlocker = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'unlocker',
        template: _unlocker_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_3__.ViewEncapsulation.None,
        styles: [_unlocker_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__metadata)("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_3__.ElementRef])
], Unlocker);



/***/ }),

/***/ 81376:
/*!*****************************************************!*\
  !*** ./src/app/pages/order/order-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderPageRoutingModule": () => (/* binding */ OrderPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _order_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./order.page */ 28798);




const routes = [
    {
        path: '',
        component: _order_page__WEBPACK_IMPORTED_MODULE_0__.OrderPage
    }
];
let OrderPageRoutingModule = class OrderPageRoutingModule {
};
OrderPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], OrderPageRoutingModule);



/***/ }),

/***/ 48983:
/*!*********************************************!*\
  !*** ./src/app/pages/order/order.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderPageModule": () => (/* binding */ OrderPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _symbols_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../symbols.service */ 4757);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _portfolios_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../portfolios.service */ 48587);
/* harmony import */ var _common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../common-ui-components/tadawul-common-ui.module */ 50773);
/* harmony import */ var _providers_order_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../providers/order.service */ 1098);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _order_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./order-routing.module */ 81376);
/* harmony import */ var _order_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./order.page */ 28798);
/* harmony import */ var _commission_commission_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./commission/commission.module */ 89080);
/* harmony import */ var _common_ui_components_unlocker_unlocker_component_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../common-ui-components/unlocker/unlocker.component.module */ 31604);
/* harmony import */ var src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/pipes/pipes.module */ 41041);
/* harmony import */ var _symbol_symbol_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./symbol/symbol.module */ 18506);
















let OrderPageModule = class OrderPageModule {
};
OrderPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_12__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_13__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.IonicModule,
            _order_routing_module__WEBPACK_IMPORTED_MODULE_4__.OrderPageRoutingModule,
            _commission_commission_module__WEBPACK_IMPORTED_MODULE_6__.CommissionComponentModule,
            _common_ui_components_unlocker_unlocker_component_module__WEBPACK_IMPORTED_MODULE_7__.UnlockerComponentModule,
            src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_8__.PipesModule,
            _symbol_symbol_module__WEBPACK_IMPORTED_MODULE_9__.SymbolComponentModule,
            _common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_15__.TranslateModule.forChild()
        ],
        declarations: [
            _order_page__WEBPACK_IMPORTED_MODULE_5__.OrderPage
        ],
        providers: [
            _providers_order_service__WEBPACK_IMPORTED_MODULE_3__.OrderService,
            _portfolios_service__WEBPACK_IMPORTED_MODULE_1__.PortfoliosService,
            _symbols_service__WEBPACK_IMPORTED_MODULE_0__.SymbolsService
        ]
    })
], OrderPageModule);



/***/ }),

/***/ 99950:
/*!********************************************************!*\
  !*** ./src/app/pages/order/symbol/symbol.component.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SymbolComponent": () => (/* binding */ SymbolComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _symbol_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./symbol.component.html?ngResource */ 11923);
/* harmony import */ var _symbol_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./symbol.component.scss?ngResource */ 22354);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_models_symbol__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/models/symbol */ 61202);
/* harmony import */ var _inma_models_order__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/models/order */ 39344);







let SymbolComponent = class SymbolComponent {
    //#endregion
    constructor(cdr) {
        this.cdr = cdr;
        this.Number = Number;
        this.symbolMinPrice = 0;
        this.symbolMaxPrice = 0;
        this.symbolClosedPrice = 0;
        this.symbolCurrentPrice = 0;
    }
    set symbol(symbol) {
        this._symbol = symbol;
        console.log(this._symbol);
        this.onSymbolChange();
    }
    get symbol() {
        return this._symbol;
    }
    ngOnChanges(changes) {
        if (changes['symbol']) {
            console.log('_________', this._symbol);
        }
    }
    onSymbolChange() {
        var _a;
        _inma_models_order__WEBPACK_IMPORTED_MODULE_3__.Orders.loadPriceRange((_a = this.symbol) === null || _a === void 0 ? void 0 : _a.id).subscribe((result) => {
            this.symbolMinPrice = result === null || result === void 0 ? void 0 : result.minPrice;
            this.symbolMaxPrice = result === null || result === void 0 ? void 0 : result.maxPrice;
            this.symbolClosedPrice = result === null || result === void 0 ? void 0 : result.closedPrice;
            // this.updateValidators();
        });
    }
    ngOnInit() {
        this.updateInterval = setInterval(() => {
            this.cdr.detectChanges();
        }, 1000);
    }
    ngOnDestroy() {
        clearInterval(this.updateInterval);
    }
};
SymbolComponent.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.ChangeDetectorRef }
];
SymbolComponent.propDecorators = {
    symbol: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input }]
};
SymbolComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'tadawul-symbol',
        template: _symbol_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_4__.ChangeDetectionStrategy.OnPush,
        styles: [_symbol_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_4__.ChangeDetectorRef])
], SymbolComponent);



/***/ }),

/***/ 18506:
/*!*****************************************************!*\
  !*** ./src/app/pages/order/symbol/symbol.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SymbolComponentModule": () => (/* binding */ SymbolComponentModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/pipes/pipes.module */ 41041);
/* harmony import */ var _symbol_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./symbol.component */ 99950);







let SymbolComponentModule = class SymbolComponentModule {
};
SymbolComponentModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule,
            src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_0__.PipesModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateModule.forChild()
        ],
        declarations: [_symbol_component__WEBPACK_IMPORTED_MODULE_1__.SymbolComponent],
        exports: [_symbol_component__WEBPACK_IMPORTED_MODULE_1__.SymbolComponent]
    })
], SymbolComponentModule);



/***/ }),

/***/ 8151:
/*!***************************************************!*\
  !*** ./src/app/pages/tabs/tabs-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabsPageRoutingModule": () => (/* binding */ TabsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tabs.page */ 22562);




// const routes: Routes = [
//   {
//     path: '',
//     component: TabsPage
//   }
// ];
const routes = [
    {
        path: '',
        component: _tabs_page__WEBPACK_IMPORTED_MODULE_0__.TabsPage,
        children: [
            {
                path: 'home',
                // loadChildren: () => import('./pages/home/home.module').then(m => m.HomePageModule),
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_pages_mutual-funds_mutual-fund-actions_mutual-fund-actions_page_ts"), __webpack_require__.e("src_app_tadawul-home_home_home_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./../../tadawul-home/home/home.module */ 77403)).then(m => m.HomeComponentModule)
            },
            {
                path: 'tradestation',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_tradestation_tradestation_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./../tradestation/tradestation.module */ 20142)).then(m => m.TradestationPageModule)
            },
            {
                path: 'tradestation/:market_id',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_tradestation_tradestation_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./../tradestation/tradestation.module */ 20142)).then(m => m.TradestationPageModule)
            },
            // {
            //   path: 'order',
            //   loadChildren: () => import('./../order/order.module').then(m => m.OrderPageModule)
            // },
            {
                path: 'standing-orders',
                loadChildren: () => __webpack_require__.e(/*! import() */ "default-src_app_pages_standing-orders_standing-orders_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./../standing-orders/standing-orders.module */ 47425)).then(m => m.StandingOrdersPageModule)
            },
            {
                path: 'more',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_more_more_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./../more/more.module */ 84908)).then(m => m.MorePageModule)
            },
            {
                path: '',
                redirectTo: 'home',
                pathMatch: 'full'
            }
        ]
    },
    {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
    }
];
let TabsPageRoutingModule = class TabsPageRoutingModule {
};
TabsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], TabsPageRoutingModule);



/***/ }),

/***/ 4987:
/*!*******************************************!*\
  !*** ./src/app/pages/tabs/tabs.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabsPageModule": () => (/* binding */ TabsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _tradestation_symbol_swiper_symbol_swiper_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../tradestation/symbol-swiper/symbol-swiper.module */ 69554);
/* harmony import */ var ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ion-bottom-drawer */ 74272);
/* harmony import */ var _order_order_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../order/order.module */ 48983);
/* harmony import */ var src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/pipes/pipes.module */ 41041);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _tabs_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./tabs-routing.module */ 8151);
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./tabs.page */ 22562);












let TabsPageModule = class TabsPageModule {
};
TabsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_2__.PipesModule,
            _tabs_routing_module__WEBPACK_IMPORTED_MODULE_3__.TabsPageRoutingModule,
            _order_order_module__WEBPACK_IMPORTED_MODULE_1__.OrderPageModule,
            ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_10__.IonBottomDrawerModule,
            _tradestation_symbol_swiper_symbol_swiper_module__WEBPACK_IMPORTED_MODULE_0__.SymbolSwiperModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__.TranslateModule.forChild()
        ],
        declarations: [_tabs_page__WEBPACK_IMPORTED_MODULE_4__.TabsPage]
    })
], TabsPageModule);



/***/ }),

/***/ 22562:
/*!*****************************************!*\
  !*** ./src/app/pages/tabs/tabs.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabsPage": () => (/* binding */ TabsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _tabs_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tabs.page.html?ngResource */ 97867);
/* harmony import */ var _tabs_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tabs.page.scss?ngResource */ 74436);
/* harmony import */ var _events_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../events.service */ 31782);
/* harmony import */ var src_app_pages_order_order_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/pages/order/order.page */ 28798);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/platform-browser */ 50318);
/* harmony import */ var _inma_helpers_translations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/helpers/translations */ 69353);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _tabs_translations__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./tabs.translations */ 43631);










let TabsPage = class TabsPage {
    constructor(sanitizer, modalCtrl, event) {
        this.sanitizer = sanitizer;
        this.modalCtrl = modalCtrl;
        this.event = event;
        this.t = _tabs_translations__WEBPACK_IMPORTED_MODULE_5__.TabTranslations;
        this.HOME_ICON = ``;
    }
    ngOnInit() {
        this.icon = this.sanitizer.bypassSecurityTrustHtml(this.HOME_ICON);
        let sab = getComputedStyle(document.documentElement).getPropertyValue("--sab");
        sab = sab.substring(0, sab.indexOf('px'));
        let _bottomSfeArea = Number(sab);
        this.dockHeight = 270 + 20 + _bottomSfeArea;
        this.distanceFromTop = window.innerHeight - this.dockHeight;
    }
    openModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: src_app_pages_order_order_page__WEBPACK_IMPORTED_MODULE_3__.OrderPage,
                cssClass: 'buy-sell',
                swipeToClose: true
            });
            return yield modal.present();
        });
    }
};
TabsPage.ctorParameters = () => [
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__.DomSanitizer },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController },
    { type: _events_service__WEBPACK_IMPORTED_MODULE_2__.EventsService }
];
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_inma_helpers_translations__WEBPACK_IMPORTED_MODULE_4__.Translations)(),
    (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", Object)
], TabsPage.prototype, "t", void 0);
TabsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'tadawul-tabs',
        template: _tabs_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_tabs_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:paramtypes", [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__.DomSanitizer,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController,
        _events_service__WEBPACK_IMPORTED_MODULE_2__.EventsService])
], TabsPage);



/***/ }),

/***/ 43631:
/*!*************************************************!*\
  !*** ./src/app/pages/tabs/tabs.translations.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabTranslations": () => (/* binding */ TabTranslations)
/* harmony export */ });
class Translations {
    constructor() {
        this.HOME = ['الرئيسية', 'Home'];
        this.MARKET = ['السوق', 'Tradestation'];
        this.BUY_SELL = ['بيع/شراء', 'Buy/Sell'];
        this.OUTSTANDING_ORDERS = ['الأوامر القائمة', 'Outstanding Orders'];
        this.MORE = ['المزيد', 'More'];
    }
}
const TabTranslations = new Translations();


/***/ }),

/***/ 40593:
/*!************************************************************************!*\
  !*** ./src/app/common-ui-components/unlocker/unlocker.scss?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = "@charset \"UTF-8\";\nunlocker {\n  pointer-events: none;\n  display: block;\n}\nunlocker input[type=range] {\n  width: 100%;\n  background: transparent;\n  -webkit-appearance: none;\n  padding: 0px;\n  transition: opacity 0.5s;\n  position: relative;\n  font-size: 1.2rem;\n  width: 100%;\n  height: 30px !important;\n  padding: 8px 0px;\n  zoom: 1.1;\n}\nunlocker input[type=range]::-webkit-slider-thumb {\n  -webkit-appearance: none;\n  border: none;\n  background-color: rgba(255, 255, 255, 0);\n  background-position: center, center;\n  background-repeat: no-repeat, no-repeat;\n  background-size: 2em, contain;\n  z-index: 1;\n  width: 26px;\n  position: relative;\n  top: 1px;\n  height: 26px;\n  pointer-events: all;\n  cursor: pointer;\n  border-radius: 4px;\n}\nunlocker input[type=range]::-webkit-slider-thumb:active {\n  background-color: rgba(255, 255, 255, 0), rgba(255, 255, 255, 0);\n  background-position: center, center;\n  background-repeat: no-repeat, no-repeat;\n  background-size: 2em, contain;\n}\n.buy unlocker input[type=range]::-webkit-slider-thumb:active {\n  background: #2ebd85 url(\"data:image/svg+xml,%3Csvg version='1.0' id='Layer_1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 16 16' enable-background='new 0 0 16 16' xml:space='preserve'%3E%3Cpath fill='%23FFFFFF' d='M10.1,7.7L6.6,4.1C6.4,4,6.1,4,5.9,4.1c-0.2,0.2-0.2,0.5,0,0.7L9.1,8l-3.2,3.2c-0.2,0.2-0.2,0.5,0,0.7 C6,12,6.1,12,6.2,12s0.2,0,0.3-0.1l3.5-3.5C10.3,8.1,10.3,7.9,10.1,7.7z'/%3E%3C/svg%3E\");\n}\n.sell unlocker input[type=range]::-webkit-slider-thumb:active {\n  background: #f5455a url(\"data:image/svg+xml,%3Csvg version='1.0' id='Layer_1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 16 16' enable-background='new 0 0 16 16' xml:space='preserve'%3E%3Cpath fill='%23FFFFFF' d='M10.1,7.7L6.6,4.1C6.4,4,6.1,4,5.9,4.1c-0.2,0.2-0.2,0.5,0,0.7L9.1,8l-3.2,3.2c-0.2,0.2-0.2,0.5,0,0.7 C6,12,6.1,12,6.2,12s0.2,0,0.3-0.1l3.5-3.5C10.3,8.1,10.3,7.9,10.1,7.7z'/%3E%3C/svg%3E\");\n}\n[dir=ltr] unlocker input[type=range]::-webkit-slider-thumb:active {\n  transform: scaleX(-1);\n  z-index: 999;\n}\n.buy unlocker input[type=range]::-webkit-slider-thumb {\n  background: #2ebd85 url(\"data:image/svg+xml,%3Csvg version='1.0' id='Layer_1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 16 16' enable-background='new 0 0 16 16' xml:space='preserve'%3E%3Cpath fill='%23FFFFFF' d='M10.1,7.7L6.6,4.1C6.4,4,6.1,4,5.9,4.1c-0.2,0.2-0.2,0.5,0,0.7L9.1,8l-3.2,3.2c-0.2,0.2-0.2,0.5,0,0.7 C6,12,6.1,12,6.2,12s0.2,0,0.3-0.1l3.5-3.5C10.3,8.1,10.3,7.9,10.1,7.7z'/%3E%3C/svg%3E\");\n}\n.sell unlocker input[type=range]::-webkit-slider-thumb {\n  background: #f5455a url(\"data:image/svg+xml,%3Csvg version='1.0' id='Layer_1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 16 16' enable-background='new 0 0 16 16' xml:space='preserve'%3E%3Cpath fill='%23FFFFFF' d='M10.1,7.7L6.6,4.1C6.4,4,6.1,4,5.9,4.1c-0.2,0.2-0.2,0.5,0,0.7L9.1,8l-3.2,3.2c-0.2,0.2-0.2,0.5,0,0.7 C6,12,6.1,12,6.2,12s0.2,0,0.3-0.1l3.5-3.5C10.3,8.1,10.3,7.9,10.1,7.7z'/%3E%3C/svg%3E\");\n}\n[dir=ltr] unlocker input[type=range]::-webkit-slider-thumb {\n  transform: scaleX(-1);\n  z-index: 999;\n}\n.plt-mobileweb unlocker input[type=range]::-webkit-slider-thumb {\n  top: -3px;\n}\n.plt-android unlocker input[type=range]::-webkit-slider-thumb {\n  top: -1px;\n}\nunlocker input[type=range]:before {\n  content: \"\";\n  color: #8a8a8a;\n  position: absolute;\n  left: 100px;\n  top: 14px;\n  z-index: 1;\n  font-size: 28px;\n}\nunlocker input[type=range]::-webkit-slider-thumb:before {\n  color: #8a8a8a;\n  position: absolute;\n  left: 5px;\n  top: -10px;\n  z-index: 1;\n  font-size: 56px;\n  font-weight: bold;\n  content: \"→\";\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVubG9ja2VyLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZ0JBQWdCO0FBQWhCO0VBQ0ksb0JBQUE7RUFDQSxjQUFBO0FBRUo7QUFBSTtFQUNJLFdBQUE7RUFFQSx1QkFBQTtFQUNBLHdCQUFBO0VBRUEsWUFBQTtFQUNBLHdCQUFBO0VBQ0Esa0JBQUE7RUFFQSxpQkFBQTtFQUNBLFdBQUE7RUFHQSx1QkFBQTtFQUNBLGdCQUFBO0VBQ0EsU0FBQTtBQUhSO0FBTUk7RUFDSSx3QkFBQTtFQUVBLFlBQUE7RUF1REEsd0NBQUE7RUFDQSxtQ0FBQTtFQUVBLHVDQUFBO0VBRUEsNkJBQUE7RUFHQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQVVBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQXhFUjtBQUxRO0VBc0JJLGdFQUFBO0VBRUEsbUNBQUE7RUFFQSx1Q0FBQTtFQUVBLDZCQUFBO0FBakJaO0FBUFk7RUFDSSw4Y0FBQTtBQVNoQjtBQU5ZO0VBQ0ksOGNBQUE7QUFRaEI7QUFMWTtFQUNJLHFCQUFBO0VBQ0EsWUFBQTtBQU9oQjtBQWFRO0VBQ0ksOGNBQUE7QUFYWjtBQWdCUTtFQUNJLDhjQUFBO0FBZFo7QUFpQlE7RUFDSSxxQkFBQTtFQUNBLFlBQUE7QUFmWjtBQW1DUTtFQUNJLFNBQUE7QUFqQ1o7QUFvQ1E7RUFDSSxTQUFBO0FBbENaO0FBMkNJO0VBQ0ksV0FBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0EsVUFBQTtFQUNBLGVBQUE7QUF6Q1I7QUE0Q0k7RUFDSSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0VBQ0EsVUFBQTtFQUNBLFVBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0FBMUNSIiwiZmlsZSI6InVubG9ja2VyLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJ1bmxvY2tlciB7XG4gICAgcG9pbnRlci1ldmVudHM6IG5vbmU7XG4gICAgZGlzcGxheTogYmxvY2s7XG5cbiAgICBpbnB1dFt0eXBlPVwicmFuZ2VcIl0ge1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgLy8gYmFja2dyb3VuZDogLXdlYmtpdC1ncmFkaWVudChsaW5lYXIsIDAgMCwgMCBib3R0b20sIGZyb20oIzAwMCksIHRvKCMxZjFmMWYpKTtcbiAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gICAgICAgIC13ZWJraXQtYXBwZWFyYW5jZTogbm9uZTtcbiAgICAgICAgLy8gYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICAgICAgcGFkZGluZzogMHB4O1xuICAgICAgICB0cmFuc2l0aW9uOiBvcGFjaXR5IDAuNXM7XG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcblxuICAgICAgICBmb250LXNpemU6IDEuMnJlbTtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG5cbiAgICAgICAgLy8gLnBsdC1pb3M6bm90KC5wbHQtbW9iaWxld2ViKSAmIHtcbiAgICAgICAgaGVpZ2h0OiAzMHB4ICFpbXBvcnRhbnQ7XG4gICAgICAgIHBhZGRpbmc6IDhweCAwcHg7XG4gICAgICAgIHpvb206IDEuMTtcbiAgICB9XG5cbiAgICBpbnB1dFt0eXBlPVwicmFuZ2VcIl06Oi13ZWJraXQtc2xpZGVyLXRodW1iIHtcbiAgICAgICAgLXdlYmtpdC1hcHBlYXJhbmNlOiBub25lO1xuXG4gICAgICAgIGJvcmRlcjogbm9uZTtcblxuICAgICAgICAmOmFjdGl2ZSB7XG4gICAgICAgICAgICAvLyBAaW5jbHVkZSBydGwge1xuICAgICAgICAgICAgLy8gYmFja2dyb3VuZC1pbWFnZTogdXJsKC9hc3NldHMvaWNvbi9zd2lwZS1yaWdodC5wbmcpO1xuXG4gICAgICAgICAgICAuYnV5ICYge1xuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICMyZWJkODUgdXJsKFwiZGF0YTppbWFnZS9zdmcreG1sLCUzQ3N2ZyB2ZXJzaW9uPScxLjAnIGlkPSdMYXllcl8xJyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHhtbG5zOnhsaW5rPSdodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rJyB4PScwcHgnIHk9JzBweCcgdmlld0JveD0nMCAwIDE2IDE2JyBlbmFibGUtYmFja2dyb3VuZD0nbmV3IDAgMCAxNiAxNicgeG1sOnNwYWNlPSdwcmVzZXJ2ZSclM0UlM0NwYXRoIGZpbGw9JyUyM0ZGRkZGRicgZD0nTTEwLjEsNy43TDYuNiw0LjFDNi40LDQsNi4xLDQsNS45LDQuMWMtMC4yLDAuMi0wLjIsMC41LDAsMC43TDkuMSw4bC0zLjIsMy4yYy0wLjIsMC4yLTAuMiwwLjUsMCwwLjcgQzYsMTIsNi4xLDEyLDYuMiwxMnMwLjIsMCwwLjMtMC4xbDMuNS0zLjVDMTAuMyw4LjEsMTAuMyw3LjksMTAuMSw3Ljd6Jy8lM0UlM0Mvc3ZnJTNFXCIpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAuc2VsbCAmIHtcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjZjU0NTVhIHVybChcImRhdGE6aW1hZ2Uvc3ZnK3htbCwlM0NzdmcgdmVyc2lvbj0nMS4wJyBpZD0nTGF5ZXJfMScgeG1sbnM9J2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJyB4bWxuczp4bGluaz0naHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluaycgeD0nMHB4JyB5PScwcHgnIHZpZXdCb3g9JzAgMCAxNiAxNicgZW5hYmxlLWJhY2tncm91bmQ9J25ldyAwIDAgMTYgMTYnIHhtbDpzcGFjZT0ncHJlc2VydmUnJTNFJTNDcGF0aCBmaWxsPSclMjNGRkZGRkYnIGQ9J00xMC4xLDcuN0w2LjYsNC4xQzYuNCw0LDYuMSw0LDUuOSw0LjFjLTAuMiwwLjItMC4yLDAuNSwwLDAuN0w5LjEsOGwtMy4yLDMuMmMtMC4yLDAuMi0wLjIsMC41LDAsMC43IEM2LDEyLDYuMSwxMiw2LjIsMTJzMC4yLDAsMC4zLTAuMWwzLjUtMy41QzEwLjMsOC4xLDEwLjMsNy45LDEwLjEsNy43eicvJTNFJTNDL3N2ZyUzRVwiKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgW2Rpcj1cImx0clwiXSAmIHtcbiAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlWCgtMSk7XG4gICAgICAgICAgICAgICAgei1pbmRleDogOTk5O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyB9XG4gICAgICAgICAgICAvLyBAaW5jbHVkZSBsdHIge1xuICAgICAgICAgICAgLy8gICAgIGJhY2tncm91bmQtaW1hZ2U6IHVybCguLi9hc3NldHMvaW1ncy9zd2lwZS1sZWZ0LnN2ZyksIGxpbmVhci1ncmFkaWVudCh0byBsZWZ0LCByZ2JhKDI1NSwgMjU1LCAyNTUsIDApIDAlLCAjOTBjNDRkIDEwMCUpO1xuICAgICAgICAgICAgLy8gfVxuXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDApLFxuICAgICAgICAgICAgcmdiYSgyNTUsIDI1NSwgMjU1LCAwKTtcbiAgICAgICAgICAgIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcixcbiAgICAgICAgICAgIGNlbnRlcjtcbiAgICAgICAgICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQsXG4gICAgICAgICAgICBuby1yZXBlYXQ7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kLXNpemU6IDJlbSxcbiAgICAgICAgICAgIGNvbnRhaW47XG4gICAgICAgIH1cblxuICAgICAgICAvLyBAaW5jbHVkZSBydGwge1xuICAgICAgICAvLyBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoL2Fzc2V0cy9pY29uL3N3aXBlLXJpZ2h0LnBuZyk7XG4gICAgICAgIC5idXkgJiB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAjMmViZDg1IHVybChcImRhdGE6aW1hZ2Uvc3ZnK3htbCwlM0NzdmcgdmVyc2lvbj0nMS4wJyBpZD0nTGF5ZXJfMScgeG1sbnM9J2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJyB4bWxuczp4bGluaz0naHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluaycgeD0nMHB4JyB5PScwcHgnIHZpZXdCb3g9JzAgMCAxNiAxNicgZW5hYmxlLWJhY2tncm91bmQ9J25ldyAwIDAgMTYgMTYnIHhtbDpzcGFjZT0ncHJlc2VydmUnJTNFJTNDcGF0aCBmaWxsPSclMjNGRkZGRkYnIGQ9J00xMC4xLDcuN0w2LjYsNC4xQzYuNCw0LDYuMSw0LDUuOSw0LjFjLTAuMiwwLjItMC4yLDAuNSwwLDAuN0w5LjEsOGwtMy4yLDMuMmMtMC4yLDAuMi0wLjIsMC41LDAsMC43IEM2LDEyLDYuMSwxMiw2LjIsMTJzMC4yLDAsMC4zLTAuMWwzLjUtMy41QzEwLjMsOC4xLDEwLjMsNy45LDEwLjEsNy43eicvJTNFJTNDL3N2ZyUzRVwiKTtcblxuICAgICAgICB9XG5cblxuICAgICAgICAuc2VsbCAmIHtcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICNmNTQ1NWEgdXJsKFwiZGF0YTppbWFnZS9zdmcreG1sLCUzQ3N2ZyB2ZXJzaW9uPScxLjAnIGlkPSdMYXllcl8xJyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHhtbG5zOnhsaW5rPSdodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rJyB4PScwcHgnIHk9JzBweCcgdmlld0JveD0nMCAwIDE2IDE2JyBlbmFibGUtYmFja2dyb3VuZD0nbmV3IDAgMCAxNiAxNicgeG1sOnNwYWNlPSdwcmVzZXJ2ZSclM0UlM0NwYXRoIGZpbGw9JyUyM0ZGRkZGRicgZD0nTTEwLjEsNy43TDYuNiw0LjFDNi40LDQsNi4xLDQsNS45LDQuMWMtMC4yLDAuMi0wLjIsMC41LDAsMC43TDkuMSw4bC0zLjIsMy4yYy0wLjIsMC4yLTAuMiwwLjUsMCwwLjcgQzYsMTIsNi4xLDEyLDYuMiwxMnMwLjIsMCwwLjMtMC4xbDMuNS0zLjVDMTAuMyw4LjEsMTAuMyw3LjksMTAuMSw3Ljd6Jy8lM0UlM0Mvc3ZnJTNFXCIpO1xuICAgICAgICB9XG5cbiAgICAgICAgW2Rpcj1cImx0clwiXSAmIHtcbiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGVYKC0xKTtcbiAgICAgICAgICAgIHotaW5kZXg6IDk5OTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIH1cbiAgICAgICAgLy8gQGluY2x1ZGUgbHRyIHtcbiAgICAgICAgLy8gICAgIGJhY2tncm91bmQtaW1hZ2U6IHVybCguLi9hc3NldHMvaW1ncy9zd2lwZS1sZWZ0LnN2ZyksIGxpbmVhci1ncmFkaWVudCh0byBsZWZ0LCAjOTBjNDRkIDAlLCByZ2JhKDI1NSwgMjU1LCAyNTUsIDApIDEwMCUpO1xuICAgICAgICAvLyB9XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMCk7XG4gICAgICAgIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcixcbiAgICAgICAgY2VudGVyO1xuICAgICAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0LFxuICAgICAgICBuby1yZXBlYXQ7XG4gICAgICAgIGJhY2tncm91bmQtc2l6ZTogMmVtLFxuICAgICAgICBjb250YWluO1xuXG4gICAgICAgIHotaW5kZXg6IDE7XG4gICAgICAgIHdpZHRoOiAyNnB4O1xuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgIHRvcDogMXB4O1xuXG4gICAgICAgIC5wbHQtbW9iaWxld2ViICYge1xuICAgICAgICAgICAgdG9wOiAtM3B4O1xuICAgICAgICB9XG5cbiAgICAgICAgLnBsdC1hbmRyb2lkICYge1xuICAgICAgICAgICAgdG9wOiAtMXB4O1xuICAgICAgICB9XG5cbiAgICAgICAgaGVpZ2h0OiAyNnB4O1xuICAgICAgICBwb2ludGVyLWV2ZW50czogYWxsO1xuICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgICB9XG5cbiAgICBpbnB1dFt0eXBlPVwicmFuZ2VcIl06YmVmb3JlIHtcbiAgICAgICAgY29udGVudDogXCJcIjtcbiAgICAgICAgY29sb3I6ICM4YThhOGE7XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgbGVmdDogMTAwcHg7XG4gICAgICAgIHRvcDogMTRweDtcbiAgICAgICAgei1pbmRleDogMTtcbiAgICAgICAgZm9udC1zaXplOiAyOHB4O1xuICAgIH1cblxuICAgIGlucHV0W3R5cGU9XCJyYW5nZVwiXTo6LXdlYmtpdC1zbGlkZXItdGh1bWI6YmVmb3JlIHtcbiAgICAgICAgY29sb3I6ICM4YThhOGE7XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgbGVmdDogNXB4O1xuICAgICAgICB0b3A6IC0xMHB4O1xuICAgICAgICB6LWluZGV4OiAxO1xuICAgICAgICBmb250LXNpemU6IDU2cHg7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICBjb250ZW50OiBcIuKGklwiO1xuICAgIH1cbn0iXX0= */";

/***/ }),

/***/ 22354:
/*!*********************************************************************!*\
  !*** ./src/app/pages/order/symbol/symbol.component.scss?ngResource ***!
  \*********************************************************************/
/***/ ((module) => {

module.exports = ":host {\n  display: block;\n}\n:host .blinking {\n  transition: background-color 0.25s ease-in-out;\n}\n:host .up {\n  background-color: rgba(33, 191, 115, 0.2) !important;\n}\n:host .down {\n  background-color: rgba(224, 82, 5, 0.2) !important;\n}\n:host .symbol-down {\n  color: #f5455a !important;\n}\n:host .symbol-up {\n  color: #2ebd85 !important;\n}\n:host .zero {\n  color: #005157 !important;\n}\n:host .stats-list {\n  border-top: 1px solid #cddcdd;\n  display: flex;\n  flex-direction: row;\n  flex-wrap: nowrap;\n  padding: 10px 16px;\n  justify-content: space-between;\n  background: #E6EFF0;\n  margin: 10px 0 0 0;\n}\nbody.dark :host .stats-list {\n  background: #2e2e2e;\n}\n:host .stats-list .label {\n  color: var(--ion-color-tertiary-contrast);\n  font-size: 10px;\n  display: block;\n}\nbody.dark :host .stats-list .label {\n  color: #787878;\n}\n:host .stats-list ion-text {\n  color: #005157;\n}\nbody.dark :host .stats-list ion-text {\n  color: #d2d2d2;\n}\n:host .font-size-title {\n  font-weight: bold;\n  font-size: inherit;\n}\n:host .change-percentage {\n  direction: ltr;\n}\n[dir=ltr] :host .change-percentage {\n  text-align: start;\n}\n[dir=rtl] :host .change-percentage {\n  text-align: end;\n}\n:host .flex-column-info {\n  display: flex;\n  align-items: flex-start;\n  justify-content: flex-start;\n  flex-direction: column;\n}\n:host .before-border-div {\n  -webkit-border-start: solid 1px #cddcdd;\n          border-inline-start: solid 1px #cddcdd;\n  -webkit-padding-start: 10px;\n          padding-inline-start: 10px;\n}\n:host .width-40 {\n  width: 40%;\n}\n:host .width-30 {\n  width: 30%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN5bWJvbC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGNBQUE7QUFDSjtBQUNJO0VBQ0ksOENBQUE7QUFDUjtBQUVJO0VBRUksb0RBQUE7QUFEUjtBQUlJO0VBQ0ksa0RBQUE7QUFGUjtBQUtJO0VBQ0kseUJBQUE7QUFIUjtBQU1JO0VBQ0kseUJBQUE7QUFKUjtBQU9JO0VBQ0kseUJBQUE7QUFMUjtBQVFJO0VBQ0ksNkJBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsOEJBQUE7RUFJQSxtQkFBQTtFQU1BLGtCQUFBO0FBZFI7QUFVUTtFQUNJLG1CQUFBO0FBUlo7QUFhUTtFQUVJLHlDQUFBO0VBQ0EsZUFBQTtFQU1BLGNBQUE7QUFqQlo7QUFhWTtFQUNJLGNBQUE7QUFYaEI7QUFpQlE7RUFFSSxjQUFBO0FBaEJaO0FBa0JZO0VBQ0ksY0FBQTtBQWhCaEI7QUFxQkk7RUFDSSxpQkFBQTtFQUNBLGtCQUFBO0FBbkJSO0FBc0JJO0VBQ0ksY0FBQTtBQXBCUjtBQXNCUTtFQUNJLGlCQUFBO0FBcEJaO0FBdUJRO0VBQ0ksZUFBQTtBQXJCWjtBQXlCSTtFQUNJLGFBQUE7RUFDQSx1QkFBQTtFQUNBLDJCQUFBO0VBQ0Esc0JBQUE7QUF2QlI7QUEwQkk7RUFDSSx1Q0FBQTtVQUFBLHNDQUFBO0VBQ0EsMkJBQUE7VUFBQSwwQkFBQTtBQXhCUjtBQTBCSTtFQUNJLFVBQUE7QUF4QlI7QUEwQkk7RUFDSSxVQUFBO0FBeEJSIiwiZmlsZSI6InN5bWJvbC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcbiAgICBkaXNwbGF5OiBibG9jaztcblxuICAgIC5ibGlua2luZyB7XG4gICAgICAgIHRyYW5zaXRpb246IGJhY2tncm91bmQtY29sb3IgMC4yNXMgZWFzZS1pbi1vdXQ7XG4gICAgfVxuXG4gICAgLnVwIHtcblxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMzMgMTkxIDExNSAvIDAuMikgIWltcG9ydGFudDtcbiAgICB9XG5cbiAgICAuZG93biB7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyMjQgODIgNSAvIDAuMikgIWltcG9ydGFudDtcbiAgICB9XG5cbiAgICAuc3ltYm9sLWRvd24ge1xuICAgICAgICBjb2xvcjogI2Y1NDU1YSAhaW1wb3J0YW50O1xuICAgIH1cblxuICAgIC5zeW1ib2wtdXAge1xuICAgICAgICBjb2xvcjogIzJlYmQ4NSAhaW1wb3J0YW50O1xuICAgIH1cblxuICAgIC56ZXJvIHtcbiAgICAgICAgY29sb3I6ICMwMDUxNTcgIWltcG9ydGFudDtcbiAgICB9XG5cbiAgICAuc3RhdHMtbGlzdCB7XG4gICAgICAgIGJvcmRlci10b3A6IDFweCBzb2xpZCAjY2RkY2RkO1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICAgICAgICBmbGV4LXdyYXA6IG5vd3JhcDtcbiAgICAgICAgcGFkZGluZzogMTBweCAxNnB4O1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgICAgIC8vIGJhY2tncm91bmQ6ICNmN2Y3Zjc7XG4gICAgICAgIC8vIGJhY2tncm91bmQ6ICMwMDUxNTc7XG4gICAgICAgIC8vIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LWJnKTtcbiAgICAgICAgYmFja2dyb3VuZDogI0U2RUZGMDtcblxuICAgICAgICBib2R5LmRhcmsgJiB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAjMmUyZTJlO1xuICAgICAgICB9XG5cbiAgICAgICAgbWFyZ2luOiAxMHB4IDAgMCAwO1xuXG4gICAgICAgIC5sYWJlbCB7XG4gICAgICAgICAgICAvLyBjb2xvcjogI2NkZGZlMTtcbiAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItdGVydGlhcnktY29udHJhc3QpO1xuICAgICAgICAgICAgZm9udC1zaXplOiAxMHB4O1xuXG4gICAgICAgICAgICBib2R5LmRhcmsgJiB7XG4gICAgICAgICAgICAgICAgY29sb3I6ICM3ODc4Nzg7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgICB9XG5cbiAgICAgICAgaW9uLXRleHQge1xuICAgICAgICAgICAgLy8gY29sb3I6IHdoaXRlO1xuICAgICAgICAgICAgY29sb3I6ICMwMDUxNTc7XG5cbiAgICAgICAgICAgIGJvZHkuZGFyayAmIHtcbiAgICAgICAgICAgICAgICBjb2xvcjogI2QyZDJkMjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5mb250LXNpemUtdGl0bGUge1xuICAgICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICAgICAgZm9udC1zaXplOiBpbmhlcml0O1xuICAgIH1cblxuICAgIC5jaGFuZ2UtcGVyY2VudGFnZSB7XG4gICAgICAgIGRpcmVjdGlvbjogbHRyO1xuXG4gICAgICAgIFtkaXI9bHRyXSAmIHtcbiAgICAgICAgICAgIHRleHQtYWxpZ246IHN0YXJ0O1xuICAgICAgICB9XG5cbiAgICAgICAgW2Rpcj1ydGxdICYge1xuICAgICAgICAgICAgdGV4dC1hbGlnbjogZW5kO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLmZsZXgtY29sdW1uLWluZm8ge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xuICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIH1cblxuICAgIC5iZWZvcmUtYm9yZGVyLWRpdiB7XG4gICAgICAgIGJvcmRlci1pbmxpbmUtc3RhcnQ6IHNvbGlkIDFweCAjY2RkY2RkO1xuICAgICAgICBwYWRkaW5nLWlubGluZS1zdGFydDogMTBweDtcbiAgICB9XG4gICAgLndpZHRoLTQwe1xuICAgICAgICB3aWR0aDogNDAlO1xuICAgIH1cbiAgICAud2lkdGgtMzB7XG4gICAgICAgIHdpZHRoOiAzMCU7XG4gICAgfVxufSJdfQ== */";

/***/ }),

/***/ 74436:
/*!******************************************************!*\
  !*** ./src/app/pages/tabs/tabs.page.scss?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = "ion-tab-bar {\n  height: 60px;\n  font-size: 12px;\n  --color: #65979A;\n  --color-selected: #005157;\n  --background: #e6eff0;\n}\nion-tab-bar ion-tab-button svg {\n  width: 20px;\n  height: 20px;\n  stroke-width: 1.25;\n  margin-bottom: 5px;\n}\nion-tab-bar ion-tab-button svg * {\n  fill: none;\n  stroke: var(--color);\n  stroke-miterlimit: 10;\n}\nion-tab-bar ion-tab-button .buy-sell-btn {\n  box-shadow: 0 2px 4px rgba(0, 81, 87, 0.3) !important;\n  width: 40px;\n  height: 40px;\n  background: #65979A !important;\n  border-radius: 50%;\n  display: grid;\n  place-items: center;\n}\nion-tab-bar ion-tab-button .buy-sell-btn svg {\n  width: 20px;\n  height: 20px;\n  margin: 0 !important;\n}\nion-tab-bar ion-tab-button .buy-sell-btn svg * {\n  stroke: #FFFFFF;\n}\nion-tab-bar ion-tab-button ion-label {\n  font-size: 10px !important;\n  font-weight: bold;\n  color: var(--color);\n}\nion-tab-bar ion-tab-button.tab-selected svg * {\n  stroke: var(--color-selected);\n}\nion-tab-bar ion-tab-button.tab-selected svg .fill-on-active {\n  fill: var(--color);\n}\nion-tab-bar ion-tab-button.tab-selected svg .no-fill-on-active {\n  fill: var(--background);\n}\nion-tab-bar ion-tab-button.tab-selected ion-label {\n  color: var(--color-selected);\n}\n.drawer-content {\n  height: 100%;\n  overflow: auto;\n  background: #347478 !important;\n}\n.bottom-sheet-header {\n  width: 100%;\n  height: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRhYnMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksWUFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLHlCQUFBO0VBQ0EscUJBQUE7QUFDSjtBQUVRO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FBQVo7QUFFWTtFQUNJLFVBQUE7RUFDQSxvQkFBQTtFQUNBLHFCQUFBO0FBQWhCO0FBSVE7RUFDSSxxREFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsOEJBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtBQUZaO0FBSVk7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG9CQUFBO0FBRmhCO0FBSWdCO0VBQ0ksZUFBQTtBQUZwQjtBQWVRO0VBQ0ksMEJBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0FBYlo7QUFtQlk7RUFDSSw2QkFBQTtBQWpCaEI7QUFvQlk7RUFDSSxrQkFBQTtBQWxCaEI7QUFvQlk7RUFDSSx1QkFBQTtBQWxCaEI7QUFzQlE7RUFDSSw0QkFBQTtBQXBCWjtBQXlCQTtFQUNJLFlBQUE7RUFDQSxjQUFBO0VBQ0EsOEJBQUE7QUF0Qko7QUF5QkE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtBQXRCSiIsImZpbGUiOiJ0YWJzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10YWItYmFyIHtcbiAgICBoZWlnaHQ6IDYwcHg7XG4gICAgZm9udC1zaXplOiAxMnB4O1xuICAgIC0tY29sb3I6ICM2NTk3OUE7XG4gICAgLS1jb2xvci1zZWxlY3RlZDogIzAwNTE1NztcbiAgICAtLWJhY2tncm91bmQ6ICNlNmVmZjA7XG5cbiAgICBpb24tdGFiLWJ1dHRvbiB7XG4gICAgICAgIHN2ZyB7XG4gICAgICAgICAgICB3aWR0aDogMjBweDtcbiAgICAgICAgICAgIGhlaWdodDogMjBweDtcbiAgICAgICAgICAgIHN0cm9rZS13aWR0aDogMS4yNTtcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDVweDtcblxuICAgICAgICAgICAgKiB7XG4gICAgICAgICAgICAgICAgZmlsbDogbm9uZTtcbiAgICAgICAgICAgICAgICBzdHJva2U6IHZhcigtLWNvbG9yKTtcbiAgICAgICAgICAgICAgICBzdHJva2UtbWl0ZXJsaW1pdDogMTA7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAuYnV5LXNlbGwtYnRuIHtcbiAgICAgICAgICAgIGJveC1zaGFkb3c6IDAgMnB4IDRweCByZ2JhKDAsIDgxLCA4NywgMC4zKSAhaW1wb3J0YW50O1xuICAgICAgICAgICAgd2lkdGg6IDQwcHg7XG4gICAgICAgICAgICBoZWlnaHQ6IDQwcHg7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAjNjU5NzlBICFpbXBvcnRhbnQ7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgICAgICBkaXNwbGF5OiBncmlkO1xuICAgICAgICAgICAgcGxhY2UtaXRlbXM6IGNlbnRlcjtcblxuICAgICAgICAgICAgc3ZnIHtcbiAgICAgICAgICAgICAgICB3aWR0aDogMjBweDtcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDIwcHg7XG4gICAgICAgICAgICAgICAgbWFyZ2luOiAwICFpbXBvcnRhbnQ7XG5cbiAgICAgICAgICAgICAgICAqIHtcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlOiAjRkZGRkZGO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIGlvbi1mYWItYnV0dG9ue1xuICAgICAgICAvLyAgICAgc3Zne1xuICAgICAgICAvLyAgICAgICAgIHdpZHRoOiAxN3B4O1xuICAgICAgICAvLyAgICAgICAgIGhlaWdodDogMTdweDtcbiAgICAgICAgLy8gICAgICAgICBtYXJnaW46IDA7XG4gICAgICAgIC8vICAgICB9XG4gICAgICAgIC8vIH1cblxuICAgICAgICBpb24tbGFiZWwge1xuICAgICAgICAgICAgZm9udC1zaXplOiAxMHB4ICFpbXBvcnRhbnQ7XG4gICAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1jb2xvcik7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBpb24tdGFiLWJ1dHRvbi50YWItc2VsZWN0ZWQge1xuICAgICAgICBzdmcge1xuICAgICAgICAgICAgKiB7XG4gICAgICAgICAgICAgICAgc3Ryb2tlOiB2YXIoLS1jb2xvci1zZWxlY3RlZCk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC5maWxsLW9uLWFjdGl2ZSB7XG4gICAgICAgICAgICAgICAgZmlsbDogdmFyKC0tY29sb3IpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLm5vLWZpbGwtb24tYWN0aXZlIHtcbiAgICAgICAgICAgICAgICBmaWxsOiB2YXIoLS1iYWNrZ3JvdW5kKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGlvbi1sYWJlbCB7XG4gICAgICAgICAgICBjb2xvcjogdmFyKC0tY29sb3Itc2VsZWN0ZWQpO1xuICAgICAgICB9XG4gICAgfVxufVxuXG4uZHJhd2VyLWNvbnRlbnQge1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBvdmVyZmxvdzogYXV0bztcbiAgICBiYWNrZ3JvdW5kOiAjMzQ3NDc4ICFpbXBvcnRhbnQ7XG59XG5cbi5ib3R0b20tc2hlZXQtaGVhZGVyIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwcHg7XG59Il19 */";

/***/ }),

/***/ 58863:
/*!************************************************************************!*\
  !*** ./src/app/common-ui-components/unlocker/unlocker.html?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = "<input [attr.disabled]=\"disabled2 == true ? true : null\" #unlock type=\"range\" (touchmove)=\"onProgress($event)\" class=\"slideToUnlock\" value=\"100\" max=\"100\" (touchend)=\"checkUnlock($event)\" (mouseout)=\"checkUnlock($event)\">\n";

/***/ }),

/***/ 11923:
/*!*********************************************************************!*\
  !*** ./src/app/pages/order/symbol/symbol.component.html?ngResource ***!
  \*********************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"stats-list\"\n  [ngClass]=\"{blinking: true, up: symbol?.changing > 0, down: symbol?.changing < 0}\">\n  <div class=\"flex-column-info width-40\">\n    <ion-text class=\"label font-size-overline\"><span>{{'component.LATEST_PRICE'| translate}}</span></ion-text>\n    <div >\n      <!--[ngClass]=\"{'symbol-down':(Number((symbol?.parameters | async)?.changePercentage)) < 0 ,'symbol-up':(Number((symbol?.parameters | async)?.changePercentage)) > 0 ,'zero':(Number((symbol?.parameters | async)?.changePercentage)) == 0 } \"-->\n      <span class='change-percentage' style=\"font-size: 14px;font-weight: bold;\"\n        [ngClass]=\"{'symbol-down':(Number((symbol?.parameters | async)?.changePercentage)) < 0 ,'symbol-up':(Number((symbol?.parameters | async)?.changePercentage)) > 0 ,'zero':(Number((symbol?.parameters | async)?.changePercentage)) == 0 }\">\n        {{((symbol?.parameters | async )?.lastTradedPrice | commafy:'number':2) || '0.00' }}\n      </span>\n      <span class='change-percentage' style=\"font-size: 10px;\"\n        [ngClass]=\"{'symbol-down':(Number((symbol?.parameters | async)?.changePercentage)) < 0 ,'symbol-up':(Number((symbol?.parameters | async)?.changePercentage)) > 0 ,'zero':(Number((symbol?.parameters | async)?.changePercentage)) == 0 }\">\n        ({{((symbol?.parameters | async)?.changePercentage | commafy:'number':2) || '0.00'}}%)\n      </span>\n      <!-- <span class='change-percentage' style=\"font-size: 10px;\"\n        [ngClass]=\"{'symbol-down':(Number((symbol?.parameters | async)?.changePercentage)) < 0 ,'symbol-up':(Number((symbol?.parameters | async)?.changePercentage)) > 0 ,'zero':(Number((symbol?.parameters | async)?.changePercentage)) == 0 }\">\n        {{(symbol?.parameters | async)?.change || '0.0'}}\n      </span> -->\n    </div>\n    <ion-text class=\"label font-size-overline\">{{'component.VOLUME'| translate}} <ion-text class=\"value font-size-title\" color=\"primary\">\n        {{((symbol?.parameters | async)?.numberOfTrades | commafy:'number':2) || '0.00'}}\n      </ion-text>\n    </ion-text>\n  </div>\n  <!---->\n  <div class=\"flex-column-info before-border-div width-30\">\n    <ion-text class=\"label font-size-overline\">{{'component.BID_PRICE'| translate}}</ion-text>\n    <ion-text class=\"value font-size-title\" color=\"primary\">\n      {{((symbol?.bid | async)?.price | commafy:'number':2) || '0.00'}}\n    </ion-text>\n    <ion-text class=\"label font-size-overline\">{{'component.VOLUME'| translate}} <ion-text class=\"value font-size-title\" color=\"primary\">\n        {{(symbol?.bid | async)?.quantity || '0'}}\n      </ion-text>\n    </ion-text>\n  </div>\n  <!---->\n  <div class=\"flex-column-info before-border-div width-30\">\n    <ion-text class=\"label font-size-overline\">{{'component.ASK_PRICE'| translate}}</ion-text>\n    <ion-text class=\"value font-size-title\" color=\"primary\">\n      {{((symbol?.ask | async)?.price | commafy:'number':2) || '0.00'}}\n    </ion-text>\n    <ion-text class=\"label font-size-overline\">{{'component.VOLUME'| translate}} <ion-text class=\"value font-size-title\" color=\"primary\">\n        {{(symbol?.ask | async)?.quantity || '0'}}\n      </ion-text>\n    </ion-text>\n  </div>\n\n</div>";

/***/ }),

/***/ 97867:
/*!******************************************************!*\
  !*** ./src/app/pages/tabs/tabs.page.html?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = "<ion-tabs>\n\n  <ion-tab-bar slot=\"bottom\">\n    <ion-tab-button tab=\"home\">\n      <!-- <svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" viewBox=\"0 0 18 18\">\n        <path class=\"fill-on-active\"\n          d=\"M14.5,16.5H3.6 c-1,0-1.8-0.8-1.8-1.8l0,0V7.5c0-0.6,0.3-1.1,0.7-1.5l5.4-4.1c0.7-0.5,1.6-0.5,2.2,0L15.5,6c0.5,0.3,0.7,0.9,0.7,1.5v7.2 C16.3,15.7,15.5,16.5,14.5,16.5z\" />\n        <path class=\"no-fill-on-active\"\n          d=\"M7.9,10.1h2.3 c0.6,0,1.1,0.5,1.1,1.1v5.3l0,0H6.8l0,0v-5.3C6.8,10.6,7.3,10.1,7.9,10.1z\" />\n      </svg> -->\n\n      <svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" viewBox=\"0 0 18 18\">\n        <path class=\"fill-on-active\" d=\"M16.4,4.9v-1c0-0.8-0.7-1.5-1.5-1.5H2.3 C1.5,2.3,0.8,3,0.8,3.9v2.4v6.3\"/>\n        <path class=\"fill-on-active\" d=\"M15.7,15.7H2.3c-0.8,0-1.5-0.7-1.5-1.5V4.8h15 c0.8,0,1.5,0.7,1.5,1.5v7.9C17.2,15,16.6,15.7,15.7,15.7z\"/>\n        <circle cx=\"13.9\" cy=\"10.1\" r=\"1.1\"/>\n      </svg>\n      <ion-label>{{'tabs.HOME' | translate}}</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"tradestation\">\n      <svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" viewBox=\"0 0 18 18\">\n            \n        <path class=\"fill-on-active\" d=\"M5,16.4H2V8.9c0-0.3,0.2-0.5,0.5-0.5h2 C4.8,8.4,5,8.6,5,8.9V16.4z\" />\n            \n        <path class=\"fill-on-active\" d=\"M10.5,16.5h-3V2c0-0.3,0.2-0.5,0.5-0.5h2 c0.3,0,0.5,0.2,0.5,0.5V16.5z\" />\n            \n        <path class=\"fill-on-active\" d=\"M16,16.4h-3V5.9c0-0.3,0.2-0.5,0.5-0.5h2 c0.3,0,0.5,0.2,0.5,0.5V16.4z\" />\n            \n        <line stroke-linecap=\"round\" x1=\"1\" y1=\"16.5\" x2=\"17\" y2=\"16.5\" />\n      </svg>\n      <ion-label>{{'tabs.MARKET' | translate}}</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"order\" (click)=\"openModal()\" style=\"display: grid;place-items: center;\">\n      <div class=\"buy-sell-btn\">\n        <!-- <span class=\"icon icon-trading\"></span> -->\n        <svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" viewBox=\"0 0 18 18\">\n          <path stroke=\"#ffffff\" stroke-linecap=\"round\"\n            d=\"M4.8,2.5L1.6,6.3 c-0.2,0.2,0,0.5,0.2,0.5h6.5c0.3,0,0.4-0.3,0.2-0.5L5.3,2.5C5.2,2.4,5,2.4,4.8,2.5z\" />\n          <line stroke=\"#ffffff\" stroke-linecap=\"round\" x1=\"5\" y1=\"15.7\" x2=\"5\" y2=\"6.8\" />\n          <path stroke=\"#ffffff\" stroke-linecap=\"round\"\n            d=\"M13.2,15.5l3.3-3.7 c0.2-0.2,0-0.5-0.2-0.5H9.7c-0.3,0-0.4,0.3-0.2,0.5l3.3,3.7C12.8,15.6,13,15.6,13.2,15.5z\" />\n          <line stroke=\"#ffffff\" stroke-linecap=\"round\" x1=\"13\" y1=\"2.3\" x2=\"13\" y2=\"11.2\" />\n        </svg>\n      </div>\n      <!-- <ion-label>{{'tabs.BUY_SELL' | translate}}</ion-label> -->\n    </ion-tab-button>\n    <ion-tab-button tab=\"standing-orders\">\n      <svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" viewBox=\"0 0 18 18\">\n        <g>\n          <path class=\"fill-on-active\"\n            d=\"M2.3,2.4h2.8 C5.6,2.4,6,2.8,6,3.3v2.8C6,6.6,5.6,7,5.1,7H2.3C1.8,7,1.4,6.6,1.4,6.1V3.3C1.3,2.8,1.8,2.4,2.3,2.4z\" />\n          <line stroke-linecap=\"round\" x1=\"8.8\" y1=\"3.1\" x2=\"16.3\" y2=\"3.1\" />\n          <line stroke-linecap=\"round\" x1=\"8.8\" y1=\"6\" x2=\"13.5\" y2=\"6\" />\n        </g>\n        <g>\n          <path class=\"fill-on-active\"\n            d=\"M2.3,10.8h2.8 c0.5,0,0.9,0.4,0.9,0.9v2.8c0,0.5-0.4,0.9-0.9,0.9H2.3c-0.5,0-0.9-0.4-0.9-0.9v-2.8C1.3,11.3,1.8,10.8,2.3,10.8z\" />\n          <line stroke-linecap=\"round\" x1=\"8.8\" y1=\"11.8\" x2=\"16.3\" y2=\"11.8\" />\n          <line stroke-linecap=\"round\" x1=\"8.8\" y1=\"14.6\" x2=\"13.5\" y2=\"14.6\" />\n        </g>\n      </svg>\n      <ion-label>{{'tabs.OUTSTANDING_ORDERS' | translate}}</ion-label>\n    </ion-tab-button>\n    <ion-tab-button tab=\"more\">\n      <svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" viewBox=\"0 0 18 18\">\n        <circle class=\"fill-on-active\" cx=\"3\" cy=\"9\" r=\"1.5\" />\n        <circle class=\"fill-on-active\" cx=\"9\" cy=\"9\" r=\"1.5\" />\n        <circle class=\"fill-on-active\" cx=\"15\" cy=\"9\" r=\"1.5\" />\n      </svg>\n      <ion-label>{{'tabs.MORE' | translate}}</ion-label>\n    </ion-tab-button>\n  </ion-tab-bar>\n</ion-tabs>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_tabs_tabs_module_ts.js.map