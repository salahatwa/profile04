"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_mutual-funds_mutual-funds-redemption-confirm_mutual-funds-redemption-confirm_mo-ee38fb"],{

/***/ 35183:
/*!**********************************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-redemption-confirm/mutual-funds-redemption-confirm-routing.module.ts ***!
  \**********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsRedemptionConfirmPageRoutingModule": () => (/* binding */ MutualFundsRedemptionConfirmPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _mutual_funds_redemption_confirm_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-funds-redemption-confirm.page */ 53019);




const routes = [
    {
        path: '',
        component: _mutual_funds_redemption_confirm_page__WEBPACK_IMPORTED_MODULE_0__.MutualFundsRedemptionConfirmPage
    }
];
let MutualFundsRedemptionConfirmPageRoutingModule = class MutualFundsRedemptionConfirmPageRoutingModule {
};
MutualFundsRedemptionConfirmPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MutualFundsRedemptionConfirmPageRoutingModule);



/***/ }),

/***/ 7824:
/*!**************************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-redemption-confirm/mutual-funds-redemption-confirm.module.ts ***!
  \**************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsRedemptionConfirmPageModule": () => (/* binding */ MutualFundsRedemptionConfirmPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _mutual_funds_redemption_confirm_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-funds-redemption-confirm-routing.module */ 35183);
/* harmony import */ var _mutual_funds_redemption_confirm_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mutual-funds-redemption-confirm.page */ 53019);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);









let MutualFundsRedemptionConfirmPageModule = class MutualFundsRedemptionConfirmPageModule {
};
MutualFundsRedemptionConfirmPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _mutual_funds_redemption_confirm_routing_module__WEBPACK_IMPORTED_MODULE_0__.MutualFundsRedemptionConfirmPageRoutingModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateModule.forChild()
        ],
        declarations: [_mutual_funds_redemption_confirm_page__WEBPACK_IMPORTED_MODULE_1__.MutualFundsRedemptionConfirmPage]
    })
], MutualFundsRedemptionConfirmPageModule);



/***/ }),

/***/ 53019:
/*!************************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-redemption-confirm/mutual-funds-redemption-confirm.page.ts ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsRedemptionConfirmPage": () => (/* binding */ MutualFundsRedemptionConfirmPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _mutual_funds_redemption_confirm_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-funds-redemption-confirm.page.html?ngResource */ 73853);
/* harmony import */ var _mutual_funds_redemption_confirm_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mutual-funds-redemption-confirm.page.scss?ngResource */ 86766);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../providers/mutual-funds.service */ 1835);
/* harmony import */ var _inma_models_mutual_funds_mutual_fund_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/models/mutual-funds/mutual-fund.model */ 51530);








let MutualFundsRedemptionConfirmPage = class MutualFundsRedemptionConfirmPage {
    constructor(mutualFundsService, formBuilder, navCtrl) {
        this.mutualFundsService = mutualFundsService;
        this.formBuilder = formBuilder;
        this.navCtrl = navCtrl;
        this.MutualFundRedemptionTypes = _inma_models_mutual_funds_mutual_fund_model__WEBPACK_IMPORTED_MODULE_3__.MutualFundRedemptionTypes;
    }
    ngOnInit() {
        this.mutualFund = this.mutualFundsService.getMutualFund();
        console.log(this.mutualFund);
        this.mutualFund.details.subscribe(details => {
            this.mfDetails = details;
            console.log(this.mfDetails);
        });
    }
    get maximumRedemptionUnits() {
        return this.mutualFund.ownedUnits;
    }
    confirmRedemption() {
        let redemptionType = this.mutualFund.formData.redemptionType;
        let amount = this.mutualFund.formData.amount;
        if (redemptionType == _inma_models_mutual_funds_mutual_fund_model__WEBPACK_IMPORTED_MODULE_3__.MutualFundRedemptionTypes.AllUnits) {
            redemptionType = _inma_models_mutual_funds_mutual_fund_model__WEBPACK_IMPORTED_MODULE_3__.MutualFundRedemptionTypes.NumberOfUnits;
            amount = this.maximumRedemptionUnits;
        }
        this.mutualFund.redeem(redemptionType, amount).subscribe(response => {
            this.mutualFund.summaryData = { processID: response.result };
            this.mutualFundsService.setMutualFund(this.mutualFund);
            this.navCtrl.navigateForward(['main/mutual-funds-redemption-summary']);
        });
        // this.navCtrl.navigateForward(['/mutual-funds-redemption-summary']);
    }
    cancelRedemption() {
        this.navCtrl.navigateBack('main/mutual-funds-details');
    }
    editRedemption() {
        this.navCtrl.navigateBack('main/mutual-funds-redemption');
    }
};
MutualFundsRedemptionConfirmPage.ctorParameters = () => [
    { type: _providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_2__.MutualFundsService },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController }
];
MutualFundsRedemptionConfirmPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'tadawul-mutual-funds-redemption-confirm',
        template: _mutual_funds_redemption_confirm_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_mutual_funds_redemption_confirm_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:paramtypes", [_providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_2__.MutualFundsService, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController])
], MutualFundsRedemptionConfirmPage);



/***/ }),

/***/ 1835:
/*!***************************************************!*\
  !*** ./src/app/providers/mutual-funds.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsService": () => (/* binding */ MutualFundsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let MutualFundsService = class MutualFundsService {
    constructor() { }
    setMutualFund(mutualFund) {
        this.mutualFund = mutualFund;
    }
    getMutualFund() {
        return this.mutualFund;
    }
};
MutualFundsService.ctorParameters = () => [];
MutualFundsService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Injectable)({
        providedIn: 'root'
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__metadata)("design:paramtypes", [])
], MutualFundsService);



/***/ }),

/***/ 86766:
/*!*************************************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-redemption-confirm/mutual-funds-redemption-confirm.page.scss?ngResource ***!
  \*************************************************************************************************************************/
/***/ ((module) => {

module.exports = "ion-toolbar {\n  --background: #005157;\n  color: #fff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm11dHVhbC1mdW5kcy1yZWRlbXB0aW9uLWNvbmZpcm0ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kscUJBQUE7RUFDQSxXQUFBO0FBQ0oiLCJmaWxlIjoibXV0dWFsLWZ1bmRzLXJlZGVtcHRpb24tY29uZmlybS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhciB7XG4gICAgLS1iYWNrZ3JvdW5kOiAjMDA1MTU3O1xuICAgIGNvbG9yOiAjZmZmO1xuICB9Il19 */";

/***/ }),

/***/ 73853:
/*!*************************************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-redemption-confirm/mutual-funds-redemption-confirm.page.html?ngResource ***!
  \*************************************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n    <ion-toolbar color=\"danger\">\n      <ion-buttons slot=\"start\">\n        <ion-back-button text=\"\"></ion-back-button>\n      </ion-buttons>\n      <ion-title slot=\"start\">{{ 'mutualFund.REDEMPTION' | translate }}</ion-title>\n    </ion-toolbar>\n  </ion-header>\n  \n  <ion-content class=\"ion-padding\">\n    <div class=\"ion-margin-bottom\">\n      <ion-text color=\"primary\" class=\"bold\">\n        {{ 'mutualFund.PORTFOLIO' | translate }}\n      </ion-text>\n      <div class=\"box-with-bg ion-padding\">\n        <ion-text color=\"primary\">\n          {{mutualFund?.portfolio?.name}}\n        </ion-text>\n      </div>\n    </div>\n    <div class=\"ion-margin-bottom\">\n      <ion-text color=\"primary\" class=\"bold\">\n        {{ 'mutualFund.MUTUAL_FUND' | translate }}\n      </ion-text>\n      <div class=\"box-with-bg ion-padding\">\n        <ion-text color=\"primary\">\n          {{mutualFund?.name}}\n        </ion-text>\n      </div>\n    </div>\n    <div class=\"ion-margin-bottom\">\n      <ion-text color=\"primary\" class=\"bold\">\n        {{ 'mutualFund.REDEMPTION_FEES' | translate }}\n      </ion-text>\n      <div class=\"box-with-bg ion-padding\">\n        <ion-text color=\"primary\">\n            {{ mfDetails?.redemptionFees }} {{ mfDetails?.redemptionFeesType }}\n        </ion-text>\n      </div>\n    </div>\n\n    <div class=\"ion-margin-bottom\" *ngIf=\"mutualFund?.formData?.redemptionType !== MutualFundRedemptionTypes.AllUnits\">\n      <ion-text color=\"primary\" class=\"bold\">\n        {{(mutualFund?.formData?.redemptionType == MutualFundRedemptionTypes.NumberOfUnits ? 'mutualFund.UNITS_NUMBER': 'mutualFund.REDEMPTION_AMOUNT') | translate}}\n      </ion-text>\n      <div class=\"box-with-bg ion-padding\">\n        <ion-text color=\"primary\">\n            {{ mutualFund?.formData.amount }}\n        </ion-text>\n      </div>\n    </div>\n\n    <div class=\"ion-margin-bottom\" *ngIf=\"mutualFund?.formData?.redemptionType == MutualFundRedemptionTypes.AllUnits\">\n        <ion-text color=\"primary\" class=\"bold\">\n          {{'mutualFund.ALLUNITS' | translate}}\n        </ion-text>\n        <div class=\"box-with-bg ion-padding\">\n          <ion-text color=\"primary\">\n            {{ 'mutualFund.ALL_UNITS_WARNING' | translate }}\n          </ion-text>\n        </div>\n      </div>\n\n  \n    <!-- SECOND SECTION -->\n    <ion-text class=\"bold\" color=\"primary\">{{'mutualFund.COMMISSION_DETAILS' | translate}}</ion-text>\n    <div class=\"box-with-bg bordered ion-margin-bottom\">\n      <ion-row class=\"data-row\">\n        <ion-col size=\"6\">\n          <ion-text class=\"label font-size-caption\" color=\"primary\">{{'mutualFund.TOTAL_COMMISSION' | translate}}</ion-text>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n              {{mutualFund?.totalCommission}}\n          </ion-text>\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"data-row\">\n        <ion-col size=\"6\">\n          <ion-text class=\"label font-size-caption\" color=\"primary\">{{'mutualFund.VAT_WITH_PERCENTAGE' | translate}}</ion-text>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n              {{mutualFund?.vat}}\n          </ion-text>\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"data-row\">\n        <ion-col size=\"6\">\n          <ion-text class=\"label font-size-caption\" color=\"primary\">{{'mutualFund.TOTAL_AMOUNT' | translate}}</ion-text>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n            {{mutualFund?.totalAmount}}\n          </ion-text>\n        </ion-col>\n      </ion-row>\n    </div>\n  \n    <ion-grid>\n      <ion-row>\n        <ion-col>\n          <app-button \n            (clickAction)=\"editRedemption()\"\n            expand=\"block\" \n            size=\"\"\n            color=\"success\"\n            fill=\"outline\"\n            shape=\"\"\n            type=\"button\"\n            >\n            {{'mutualFund.EDIT_ORDER' | translate}}\n          </app-button>\n        </ion-col>\n        <ion-col>\n          <app-button \n            (clickAction)=\"cancelRedemption()\"\n            expand=\"block\" \n            size=\"\"\n            color=\"danger\"\n            fill=\"outline\"\n            shape=\"\"\n            type=\"button\"\n            >\n            {{'mutualFund.CANCEL_ORDER' | translate}}\n          </app-button>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n    \n    <app-button\n    (clickAction)=\"confirmRedemption()\"\n    expand=\"block\" \n    size=\"\"\n    color=\"danger\"\n    fill=\"solid\"\n    type=\"button\"\n    >\n      {{'mutualFund.SEND_REDEMPTION_ORDER' | translate}}\n    </app-button>\n  </ion-content>\n    ";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_mutual-funds_mutual-funds-redemption-confirm_mutual-funds-redemption-confirm_mo-ee38fb.js.map