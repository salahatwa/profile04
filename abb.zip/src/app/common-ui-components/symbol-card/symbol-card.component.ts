import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'tadawul-symbol-card',
  templateUrl: './symbol-card.component.html',
  styleUrls: ['./symbol-card.component.scss'],
})
export class SymbolCardComponent implements OnInit {
  @Input() companyName: string;
  @Input() changeRate: string;

  @Input() quantity: string;
  @Input() cost: string;
  @Input() lastPrice: string;
  @Input() ratePercentage: number;
  @Input() formName: string;
  @Input() componentName: string;
  
  constructor() { }

  ngOnInit() {}

  uncommafy(value) {
    if(value || value === 0 || value === '0') {
      return value.toString().replace(/,/g, '');
    }
    else {
      return;
    }
  }

}
