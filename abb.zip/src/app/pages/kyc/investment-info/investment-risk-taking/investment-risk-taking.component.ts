import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NavController } from '@ionic/angular';
import { kycTranslations } from '../../../kyc/kyctranslation';
import { Translations } from '@inma/helpers/translations';
import { Kyc } from '@inma/models/kyc/';
import { resetCache } from '@inma/helpers/cached';


@Component({
  selector: 'tadawul-investment-risk-taking',
  templateUrl: './investment-risk-taking.component.html',
  styleUrls: ['./investment-risk-taking.component.scss'],
})
export class InvestmentRiskTakingComponent implements OnInit {
  form: FormGroup;
  t = kycTranslations;
  public showLoader = false;
  details = {
    investmentInfo: {
      investmentAssets:{
        EUROInvestmentAsset: "false",
        SARInvestmentAsset: "false",
        USDInvestmentAsset: "false",
        otherInvestmentAsset: "false",
      },
      riskLevel: "",
      investmentObjective: "",
      investmentExperience: ""
    }
  };
  investmentRisks;
  experiencesList;
  objectivesList;

  constructor(private formBuilder: FormBuilder, private navCtrl: NavController) { 
    this.buildForm();
  }

  ngOnInit() {
    // Kyc.detailsCountries.subscribe( investmentRisks => {
    // });

    // Kyc.detailsInvestmentObjectivesList.subscribe( investmentRisks => {
    // });

    // Kyc.detailsIncomeSourcesList.subscribe( investmentRisks => {
    // });

    // Kyc.detailsIncomeFrequenciesList.subscribe( investmentRisks => {
    // });

    // Kyc.detailsIncomeReceiveMethodsList.subscribe( investmentRisks => {
    // });

    // Kyc.detailsInvestmentExperiencesList.subscribe( investmentRisks => {
    // });

    // Kyc.detailsAddressIndicatorsList.subscribe( investmentRisks => {
    // });


    Kyc.detailsInvestmentRisks.subscribe( investmentRisks => {
      Kyc.detailsInvestmentExperiencesList.subscribe( experiencesList => {
        Kyc.detailsInvestmentObjectivesList.subscribe( objectivesList => {
          Kyc.details.subscribe( details => {
            console.log(details);
            console.log(investmentRisks);
            console.log(experiencesList);
            console.log(objectivesList);
            this.investmentRisks = investmentRisks;
            this.experiencesList = experiencesList;
            this.objectivesList = objectivesList;

            this.form.controls['riskAbility'].setValue(details.investmentInfo.riskLevel);
            this.form.controls['goals'].setValue(details.investmentInfo.investmentObjective);
            this.form.controls['experience'].setValue(details.investmentInfo.investmentExperience);
            this.form.controls['sarInvAsset'].setValue(details.investmentInfo.investmentAssets.SARInvestmentAsset);
            this.form.controls['usdInvAsset'].setValue(details.investmentInfo.investmentAssets.USDInvestmentAsset);
            this.form.controls['euroInvAsset'].setValue(details.investmentInfo.investmentAssets.EUROInvestmentAsset);
            this.form.controls['otherInvoAsset'].setValue(details.investmentInfo.investmentAssets.otherInvestmentAsset);

            this.details = details;
            console.log(this.details);
            this.findRiskAbility();
            this.findExperience();
            this.findGoal();
          });
        });
      });
    });
  }
  
  findRiskAbility() {
    this.investmentRisks.forEach(element => {
      if(element.code === this.details.investmentInfo['riskLevel']['code']) {
        this.details.investmentInfo['riskLevel'] = element;
      }
    });
  }
  findExperience() {
    this.experiencesList.forEach(element => {
      if(element.code === this.details.investmentInfo['investmentExperience']['code']) {
        this.details.investmentInfo['investmentExperience'] = element;
      }
    });
  }
  findGoal() {
    this.objectivesList.forEach(element => {
      if(element.code === this.details.investmentInfo['investmentObjective']['code']) {
        this.details.investmentInfo['investmentObjective'] = element;
      }
    });
  }

  buildForm() {
    this.form = this.formBuilder.group({
      riskAbility: [
        '', Validators.compose([
          Validators.required
        ])
      ],
      goals: [
        '', Validators.compose([
          Validators.required
        ])
      ],
      experience: [
        '', Validators.compose([
          Validators.required
        ])
      ],
      sarInvAsset: [],
      usdInvAsset: [],
      euroInvAsset: [],
      otherInvoAsset: [],
    });
  }

  goalsChanged() {

  }

  experienceChanged() {

  }

  riskAbilityChanged() {
    
  }

  saveSettings(form) {
    console.log(form.valid);
    if (form.invalid) {
      return;
    }
   // Kyc.updateDetails(this.details);
   this.showLoader = true;
    Kyc.updateDetails(this.details).subscribe(() => {
      resetCache(Kyc, 'details');
      this.showLoader = false;
      this.navCtrl.navigateRoot('/kyc/home', { animated: true });
    },
    err => {
      console.log('HTTP Error', err);
      this.showLoader = false;
    });
  }

}
