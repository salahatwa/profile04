import { TranslateModule } from '@ngx-translate/core';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ContactUsPageRoutingModule } from './contact-us-routing.module';

import { ContactUsPage } from './contact-us.page';
import { TadawulCommonUiModule } from 'src/app/common-ui-components/tadawul-common-ui.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ContactUsPageRoutingModule,
    ReactiveFormsModule,
    TadawulCommonUiModule,
    TranslateModule.forChild()
  ],
  declarations: [ContactUsPage]
})
export class ContactUsPageModule {}
