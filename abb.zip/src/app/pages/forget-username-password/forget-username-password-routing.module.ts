import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ForgetUsernamePasswordPage } from './forget-username-password.page';

const routes: Routes = [
  {
    path: '',
    component: ForgetUsernamePasswordPage
  },
  {
    path: 'forgot-username',
    loadChildren: () => import('./forgot-username/forgot-username.module').then( m => m.ForgotUsernamePageModule)
  },
  {
    path: 'forgot-password',
    loadChildren: () => import('./forgot-password/forgot-password.module').then( m => m.ForgotPasswordPageModule)
  },
  {
    path: 'change-password',
    loadChildren: () => import('./change-password/change-password.module').then( m => m.ChangePasswordPageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ForgetUsernamePasswordPageRoutingModule {}
