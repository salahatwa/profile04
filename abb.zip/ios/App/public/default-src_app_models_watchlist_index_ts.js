"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_models_watchlist_index_ts"],{

/***/ 12059:
/*!*********************************************!*\
  !*** ./src/app/🌱models/watchlist/index.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Watchlist": () => (/* reexport safe */ _watchlist_model__WEBPACK_IMPORTED_MODULE_1__.Watchlist),
/* harmony export */   "WatchlistType": () => (/* reexport safe */ _watchlist_model__WEBPACK_IMPORTED_MODULE_1__.WatchlistType),
/* harmony export */   "Watchlists": () => (/* reexport safe */ _watchlists_model__WEBPACK_IMPORTED_MODULE_0__.Watchlists),
/* harmony export */   "WatchlistsModel": () => (/* reexport safe */ _watchlists_model__WEBPACK_IMPORTED_MODULE_0__.WatchlistsModel)
/* harmony export */ });
/* harmony import */ var _watchlists_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlists.model */ 46523);
/* harmony import */ var _watchlist_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./watchlist.model */ 99307);




/***/ }),

/***/ 99307:
/*!*******************************************************!*\
  !*** ./src/app/🌱models/watchlist/watchlist.model.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Watchlist": () => (/* binding */ Watchlist),
/* harmony export */   "WatchlistType": () => (/* binding */ WatchlistType)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 19193);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 64139);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/helpers/cached */ 569);
/* harmony import */ var _symbol__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../symbol */ 61202);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 80522);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var _inma_helpers_localize__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/helpers/localize */ 38924);
/* harmony import */ var _inma_helpers_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/helpers/http */ 36802);
/* harmony import */ var _watchlists_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./watchlists.model */ 46523);








var WatchlistType;
(function (WatchlistType) {
    WatchlistType[WatchlistType["CustomWatchlist"] = 0] = "CustomWatchlist";
    WatchlistType[WatchlistType["PortfolioWatchlist"] = 1] = "PortfolioWatchlist";
})(WatchlistType || (WatchlistType = {}));
class Watchlist {
    constructor(options) {
        this.type = WatchlistType.CustomWatchlist;
        this.id = options === null || options === void 0 ? void 0 : options.listId;
        this._name = options === null || options === void 0 ? void 0 : options.nickName;
        this._nameAr = options === null || options === void 0 ? void 0 : options.nickNameAr;
        this.isDefault = options === null || options === void 0 ? void 0 : options.defaultValue;
        this.isSector = options === null || options === void 0 ? void 0 : options.isSector;
        this.optionsSymbols = (options === null || options === void 0 ? void 0 : options.symbols) || [];
        this.index = options === null || options === void 0 ? void 0 : options.indexValue;
        this.change = options === null || options === void 0 ? void 0 : options.netChange;
        this.changePercent = options === null || options === void 0 ? void 0 : options.priceChange;
    }
    // # region symbols
    get symbols() {
        this.symbolsIDs = this.optionsSymbols;
        return this._symbols;
    }
    set symbols(symbols) {
        this._symbols = symbols;
    }
    set symbolsIDs(symbolsIDs) {
        const findings = [];
        for (const s of this.optionsSymbols)
            findings.push(_symbol__WEBPACK_IMPORTED_MODULE_1__.Symbols.findById(s.id));
        this._symbols = (findings === null || findings === void 0 ? void 0 : findings.length) ? (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.combineLatest)(findings) : (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.of)([]);
    }
    //#endregion
    //#region name
    get name() {
        return (0,_inma_helpers_localize__WEBPACK_IMPORTED_MODULE_2__.localize)(this, '_name');
    }
    set name(name) {
        this._name = this._nameAr = name;
    }
    //#endregion
    addSymbol(symbol) {
        const symbolID = symbol instanceof _symbol__WEBPACK_IMPORTED_MODULE_1__.Symbol ? symbol.id : symbol;
        _symbol__WEBPACK_IMPORTED_MODULE_1__.Symbols.findById(symbolID).subscribe((foundSymbol) => {
            this.symbols
                .subscribe((symbols) => {
                if (!symbols.find((s) => s.id === symbolID))
                    symbols.push(foundSymbol);
                this.symbols = (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.of)(symbols);
                // foundSymbol.watchListsIds.push(this.id);
                //  resetCache(Watchlists, 'all');
            });
        });
    }
    delete(symbol) {
        this.symbols.subscribe((symbols) => {
            this.symbols = (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.of)(symbols.filter((s) => s.id !== symbol.id));
        });
        // let index = symbol.watchListsIds.indexOf(this.id);
        // symbol.watchListsIds.splice(index, 1);
        // this.cachedSymbols = this.deleteSymbolFromCachedSymbols(symbol);
        // return this.update();
    }
    create() {
        return this.createOrUpdate();
    }
    update() {
        return this.createOrUpdate();
    }
    createOrUpdate() {
        return this.symbols.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.mergeMap)((symbols) => {
            let symbolIds = symbols.map(s => { var _a; return (_a = s.id) === null || _a === void 0 ? void 0 : _a.toString(); });
            const result = [];
            symbolIds.forEach((item) => {
                if (!result.includes(item)) {
                    result.push(item);
                }
            });
            return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_3__.Http.request(this.id ? '/stockMarket/ManageWatchList/updateWatchList' : '/StockMarket/ManageWatchList/addWatchList', {
                watchListName: this.name,
                symbolIds: result,
                listId: this.id,
                defaultWatchList: this.isDefault
            }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.map)((result) => {
                this.id = this.id || (result === null || result === void 0 ? void 0 : result.listId);
                (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_0__.resetCache)(_watchlists_model__WEBPACK_IMPORTED_MODULE_4__.Watchlists, 'all');
                return result;
            }));
        }));
    }
    deleteWatchList(listID) {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_3__.Http.request('/stockMarket/ManageWatchList/deleteWatchList', { listId: listID })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.map)(result => {
            (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_0__.resetCache)(_watchlists_model__WEBPACK_IMPORTED_MODULE_4__.Watchlists, 'all');
            return result;
        }));
    }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_0__.cached,
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", rxjs__WEBPACK_IMPORTED_MODULE_10__.Observable),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", [rxjs__WEBPACK_IMPORTED_MODULE_10__.Observable])
], Watchlist.prototype, "symbols", null);


/***/ }),

/***/ 46523:
/*!********************************************************!*\
  !*** ./src/app/🌱models/watchlist/watchlists.model.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Watchlists": () => (/* binding */ Watchlists),
/* harmony export */   "WatchlistsModel": () => (/* binding */ WatchlistsModel)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _watchlist_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlist.model */ 99307);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 64139);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @inma/helpers/cached */ 569);
/* harmony import */ var _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/helpers/http */ 36802);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/helpers/streaming */ 9199);
/* harmony import */ var _users__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../users */ 17166);
/* harmony import */ var _symbol__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../symbol */ 61202);









class WatchlistsModel {
    get all() {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request('/stockMarket/ManageWatchList/loadAllWatchLists')
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(result => {
            const watchlists = new Array();
            for (const w of result || []) {
                const watchlist = new _watchlist_model__WEBPACK_IMPORTED_MODULE_0__.Watchlist(w);
                if (watchlist.name) {
                    watchlists.push(watchlist);
                    if (watchlist.isDefault)
                        this.default = watchlist;
                }
            }
            return watchlists;
        }));
    }
    resetCheckedWatchlists() {
        this.all.subscribe(watchlists => {
            for (let i = 0; i < watchlists.length; i++) {
                watchlists[i].checked = false;
            }
            return watchlists;
        });
    }
    findByID(id) {
        return this.all.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(watchlists => {
            return watchlists.find(watchlist => (watchlist === null || watchlist === void 0 ? void 0 : watchlist.id) === id);
        }));
    }
    findSectorByID(id) {
        return this.allSectors.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(sectors => {
            return sectors.find(watchlist => (watchlist === null || watchlist === void 0 ? void 0 : watchlist.id) === id);
        }));
    }
    get allSectors() {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request('/stockMarket/MarketSectorsService/getMarketSectors', {
            marketSymbol: 'TASI'
        })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(result => {
            const sectors = new Array();
            for (const w of result) {
                const sector = new _watchlist_model__WEBPACK_IMPORTED_MODULE_0__.Watchlist(w);
                sector.isSector = true;
                if (sector.name && sector.id !== 'TASI') {
                    sectors.push(sector);
                }
            }
            // const zone = Injector.get(NgZone);
            // this.connectToStream().subscribe((sectorInfoMessage) => {
            //   zone.run(() => {
            //     const streamedMarketInfo = JSON.parse(sectorInfoMessage["data"]);
            //     this._allSectors.next(streamedMarketInfo);
            //   })
            // });
            return sectors;
        }));
    }
    add(name, isDefault, symbolsIds) {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request('/StockMarket/ManageWatchList/addWatchList', { watchListName: name, defaultWatchList: isDefault, symbolIds: symbolsIds }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(result => {
            const watchlist = new _watchlist_model__WEBPACK_IMPORTED_MODULE_0__.Watchlist();
            watchlist.name = name;
            watchlist.isDefault = isDefault;
            watchlist.symbols = (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.of)(symbolsIds);
            return watchlist;
        }));
    }
    addSymbolToExistingOrNewWatchlist(newWatchLists, symbolCode, marketCode) {
        let listIdsArr = [];
        let included;
        Watchlists.all.subscribe(watchlists => {
            for (let i = 0; i < watchlists.length; i++) {
                if (watchlists[i].checked == true) {
                    listIdsArr.push(watchlists[i].id);
                }
                ;
            }
        });
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request('/stockMarket/ManageWatchList/updateWatchListsBasedOnSymbol', { listIds: listIdsArr, newWLNames: newWatchLists, symbolCode: symbolCode, marketCode: marketCode })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(result => {
            (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_1__.resetCache)(Watchlists, 'all');
            (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_1__.resetCache)(_symbol__WEBPACK_IMPORTED_MODULE_5__.Symbols, 'all');
            Watchlists.all.subscribe(watchlists => {
                for (let i = 0; i < newWatchLists.length; i++) {
                    for (let j = 0; j < watchlists.length; j++)
                        if (newWatchLists[i] == watchlists[j]._name) {
                            listIdsArr.push(watchlists[j].id);
                        }
                    ;
                }
            });
            if (newWatchLists.length > 0 || listIdsArr.length > 0) {
                included = true;
            }
            else
                (included = false);
            return { 'result': result,
                'included': included,
                'listIdsArr': listIdsArr
            };
        }));
    }
    get channelURL() {
        return _users__WEBPACK_IMPORTED_MODULE_4__.User.isLive.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)((isLive) => {
            return '/alinma/sectorInfo/TDWL/TASI';
        }));
    }
    connectToStream() {
        return new rxjs__WEBPACK_IMPORTED_MODULE_8__.Observable(observer => {
            _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_3__.Streaming.connect().subscribe(() => {
                this.channelURL.subscribe(channelURL => {
                    _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_3__.Streaming.subscribe(channelURL).subscribe(event => {
                        if (event.type === _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_3__.StreamingChannelEventType.Subscribed) {
                            _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_3__.Streaming.log(JSON.stringify(event));
                            // observer.next(this.marketStatus);
                        }
                        else if (event.type === _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_3__.StreamingChannelEventType.MessageReceived) {
                            _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_3__.Streaming.log(JSON.stringify(event));
                            // this.cachedMarketStatus = event.data["data"].replace(/\"/g,"");
                            observer.next(event.data);
                        }
                    });
                });
            });
        });
    }
    disconnectToStream() {
        this.channelURL.subscribe(channelURL => {
            _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_3__.Streaming.unsubscribe(channelURL);
        });
    }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_1__.cached,
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", Object),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", [])
], WatchlistsModel.prototype, "all", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_1__.cached,
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", rxjs__WEBPACK_IMPORTED_MODULE_8__.Observable),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", [])
], WatchlistsModel.prototype, "allSectors", null);
const Watchlists = new WatchlistsModel();


/***/ })

}]);
//# sourceMappingURL=default-src_app_models_watchlist_index_ts.js.map