"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_mutual-funds_mutual-funds-subscribe-summary_mutual-funds-subscribe-summary_module_ts"],{

/***/ 34178:
/*!********************************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-subscribe-summary/mutual-funds-subscribe-summary-routing.module.ts ***!
  \********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsSubscribeSummaryPageRoutingModule": () => (/* binding */ MutualFundsSubscribeSummaryPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _mutual_funds_subscribe_summary_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-funds-subscribe-summary.page */ 34190);




const routes = [
    {
        path: '',
        component: _mutual_funds_subscribe_summary_page__WEBPACK_IMPORTED_MODULE_0__.MutualFundsSubscribeSummaryPage
    }
];
let MutualFundsSubscribeSummaryPageRoutingModule = class MutualFundsSubscribeSummaryPageRoutingModule {
};
MutualFundsSubscribeSummaryPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MutualFundsSubscribeSummaryPageRoutingModule);



/***/ }),

/***/ 296:
/*!************************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-subscribe-summary/mutual-funds-subscribe-summary.module.ts ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsSubscribeSummaryPageModule": () => (/* binding */ MutualFundsSubscribeSummaryPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _mutual_funds_subscribe_summary_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-funds-subscribe-summary-routing.module */ 34178);
/* harmony import */ var _mutual_funds_subscribe_summary_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mutual-funds-subscribe-summary.page */ 34190);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);









let MutualFundsSubscribeSummaryPageModule = class MutualFundsSubscribeSummaryPageModule {
};
MutualFundsSubscribeSummaryPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _mutual_funds_subscribe_summary_routing_module__WEBPACK_IMPORTED_MODULE_0__.MutualFundsSubscribeSummaryPageRoutingModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateModule.forChild()
        ],
        declarations: [_mutual_funds_subscribe_summary_page__WEBPACK_IMPORTED_MODULE_1__.MutualFundsSubscribeSummaryPage]
    })
], MutualFundsSubscribeSummaryPageModule);



/***/ }),

/***/ 34190:
/*!**********************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-subscribe-summary/mutual-funds-subscribe-summary.page.ts ***!
  \**********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsSubscribeSummaryPage": () => (/* binding */ MutualFundsSubscribeSummaryPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _mutual_funds_subscribe_summary_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-funds-subscribe-summary.page.html?ngResource */ 82084);
/* harmony import */ var _mutual_funds_subscribe_summary_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mutual-funds-subscribe-summary.page.scss?ngResource */ 63638);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../providers/mutual-funds.service */ 1835);
/* harmony import */ var src_app_providers_share_screenshot_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/providers/share-screenshot.service */ 92802);








let MutualFundsSubscribeSummaryPage = class MutualFundsSubscribeSummaryPage {
    constructor(mutualFundsService, navCtrl, translate, shareScreenshotService) {
        this.mutualFundsService = mutualFundsService;
        this.navCtrl = navCtrl;
        this.translate = translate;
        this.shareScreenshotService = shareScreenshotService;
        this.terms = false;
        this.submitted = false;
    }
    ngOnInit() {
        this.mutualFund = this.mutualFundsService.getMutualFund();
        console.log(this.mutualFund);
        this.mutualFund.details.subscribe(details => {
            this.mfDetails = details;
            console.log(this.mfDetails);
        });
    }
    addNew() {
        this.navCtrl.navigateBack('main/mutual-funds-details');
    }
    backToHome() {
        this.navCtrl.navigateRoot('main/tabs');
    }
    shareScreenshot() {
        let data = [
            { key: this.translate.instant('mutualFund.PORTFOLIO'), value: this.mutualFund.portfolio.name },
            { key: this.translate.instant('mutualFund.MUTUAL_FUND'), value: this.mutualFund.name },
            { key: this.translate.instant('mutualFund.SUBSCRIPTION_FEES'), value: this.mfDetails.subscriptionFees + ' ' + this.mfDetails.subscriptionFeesType },
            { key: this.translate.instant('mutualFund.SUBSCRIPTION_AMOUNT'), value: this.mutualFund.formData.amount }
        ];
        this.shareScreenshotService.createModal(data);
    }
};
MutualFundsSubscribeSummaryPage.ctorParameters = () => [
    { type: _providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_2__.MutualFundsService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslateService },
    { type: src_app_providers_share_screenshot_service__WEBPACK_IMPORTED_MODULE_3__.ShareScreenshotService }
];
MutualFundsSubscribeSummaryPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'tadawul-mutual-funds-subscribe-summary',
        template: _mutual_funds_subscribe_summary_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_mutual_funds_subscribe_summary_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:paramtypes", [_providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_2__.MutualFundsService,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController,
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslateService,
        src_app_providers_share_screenshot_service__WEBPACK_IMPORTED_MODULE_3__.ShareScreenshotService])
], MutualFundsSubscribeSummaryPage);



/***/ }),

/***/ 1835:
/*!***************************************************!*\
  !*** ./src/app/providers/mutual-funds.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsService": () => (/* binding */ MutualFundsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let MutualFundsService = class MutualFundsService {
    constructor() { }
    setMutualFund(mutualFund) {
        this.mutualFund = mutualFund;
    }
    getMutualFund() {
        return this.mutualFund;
    }
};
MutualFundsService.ctorParameters = () => [];
MutualFundsService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Injectable)({
        providedIn: 'root'
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__metadata)("design:paramtypes", [])
], MutualFundsService);



/***/ }),

/***/ 63638:
/*!***********************************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-subscribe-summary/mutual-funds-subscribe-summary.page.scss?ngResource ***!
  \***********************************************************************************************************************/
/***/ ((module) => {

module.exports = ".summary-title {\n  color: #2ebd85;\n  justify-content: center;\n  flex-direction: column;\n  text-align: center;\n  padding: 32px;\n}\n\n.success-text {\n  font-size: 120%;\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm11dHVhbC1mdW5kcy1zdWJzY3JpYmUtc3VtbWFyeS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFBO0VBRUEsdUJBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtBQUFKOztBQUdBO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0FBQUoiLCJmaWxlIjoibXV0dWFsLWZ1bmRzLXN1YnNjcmliZS1zdW1tYXJ5LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zdW1tYXJ5LXRpdGxlIHtcbiAgICBjb2xvcjogIzJlYmQ4NTtcbiAgIC8vIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgcGFkZGluZzogMzJweDtcbn1cblxuLnN1Y2Nlc3MtdGV4dCB7XG4gICAgZm9udC1zaXplOiAxMjAlO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xufSJdfQ== */";

/***/ }),

/***/ 82084:
/*!***********************************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-subscribe-summary/mutual-funds-subscribe-summary.page.html?ngResource ***!
  \***********************************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"success\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\"></ion-back-button>\n    </ion-buttons>\n    <ion-title slot=\"start\">{{ ((mutualFund?.ownedUnits)? 'mutualFund.ADD_UNIT_HEADER':'mutualFund.SUBSCRIPTION_HEADER') | translate }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"summary-title\">\n    <img src=\"assets/icon/success.svg\" class=\"success-img\">\n    <div class=\"success-text\">\n      {{ ((mutualFund?.ownedUnits)?'mutualFund.ADDUNITS_REQUEST_SUCCESS_MESSAGE':'mutualFund.SUBSCRIPTION_REQUEST_SUCCESS_MESSAGE') | translate }}\n    </div>\n  </div>\n\n  <div class=\"ion-padding\">\n    <ion-text class=\"bold\" color=\"primary\">{{'mutualFund.ORDER_DETAILS' | translate}}</ion-text>\n    <div class=\"box-with-bg bordered ion-margin-bottom\">\n      <ion-row class=\"data-row\">\n        <ion-col size=\"6\">\n          <ion-text class=\"label font-size-caption\" color=\"primary\">{{'mutualFund.PORTFOLIO' | translate}}</ion-text>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n              {{mutualFund?.portfolio?.name}}\n          </ion-text>\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"data-row\">\n        <ion-col size=\"6\">\n          <ion-text class=\"label font-size-caption\" color=\"primary\">{{'mutualFund.MUTUAL_FUND' | translate}}</ion-text>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n              {{mutualFund?.name}}\n          </ion-text>\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"data-row\">\n        <ion-col size=\"6\">\n          <ion-text class=\"label font-size-caption\" color=\"primary\">{{'mutualFund.SUBSCRIPTION_FEES' | translate}}</ion-text>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n              {{ mfDetails?.subscriptionFees }} {{ mfDetails?.subscriptionFeesType }}\n          </ion-text>\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"data-row\">\n        <ion-col size=\"6\">\n          <ion-text class=\"label font-size-caption\" color=\"primary\">{{'mutualFund.SUBSCRIPTION_AMOUNT' | translate}}</ion-text>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n              {{ mutualFund?.formData.amount }}\n          </ion-text>\n        </ion-col>\n      </ion-row>\n    </div>\n    <app-button\n    (clickAction)=\"shareScreenshot()\"\n    expand=\"block\" \n    size=\"\"\n    color=\"primary\"\n    fill=\"solid\"\n    type=\"button\"\n    >\n      {{'mutualFund.SHARE' | translate}}\n    </app-button>\n    \n    <app-button\n    (clickAction)=\"backToHome()\"\n    expand=\"block\" \n    size=\"\"\n    color=\"medium\"\n    fill=\"outline\"\n    type=\"button\"\n    >\n      {{'mutualFund.BACK_TO_HOME' | translate}}\n    </app-button>\n  </div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_mutual-funds_mutual-funds-subscribe-summary_mutual-funds-subscribe-summary_module_ts.js.map