import { TranslateService } from '@ngx-translate/core';
import { Component, OnInit } from '@angular/core';
import { Plugins } from '@capacitor/core';
import { Environment } from '@inma/environment';
import { Settings } from '@inma/helpers/settings';
import { Translations } from '@inma/helpers/translations';
import { NavController } from '@ionic/angular';
import { AppComponent } from 'src/app/app.component';
import { SharedDataService } from 'src/app/providers/shared-data.service';
import { IDExpiryTranslations } from './IDExpired.translation';

export enum ExpireType {
  ID = 0,
  KYC = 1
}
export class ExpiredMsg {
  type: ExpireType;
  title?: string[];
  subtitle?: string[];
  msg?: string[];
  isLinkExist?: boolean;
  linkTxt?: string[];
}

const { Browser } = Plugins;
@Component({
  selector: 'tadawul-id-expired',
  templateUrl: './id-expired.page.html',
  styleUrls: ['./id-expired.page.scss'],
})
export class IdExpiredPage implements OnInit {

  expiredMsg: ExpiredMsg = { type: ExpireType.ID };


  constructor(private navCtrl: NavController, public translate: TranslateService,private sharedData: SharedDataService) { }

  ngOnInit() {
    this.expiredMsg = this.sharedData.getSharedData('expiredMsg');
    this.prepareDefaultMessage();
  }

  prepareDefaultMessage() {
    if (!this.expiredMsg || this.expiredMsg == null) {
      this.expiredMsg = {
        type: ExpireType.ID,
        title: this.translate.instant('loginPage.textOne'),
        subtitle: this.translate.instant('loginPage.textTwo'),
        msg: this.translate.instant('loginPage.textThree')
      }
    }
  }

  continueToHomePage() {
    this.sharedData.setSharedData(this.expiredMsg, 'expiredMsg');
    this.navCtrl.navigateRoot('main/tabs', { animated: true });
    AppComponent.idExpiryDate = (this.expiredMsg.type == ExpireType.ID) ? true : false;
    AppComponent.ExpiredUserID = (this.expiredMsg.type == ExpireType.KYC) ? true : false;
  }

  async openTadawulSite() {
    await Browser.open({
      url:
        `${Environment.hostURL}/alinmaTadawul/public/login.jsf?session_locale=${Settings?.languageAsString?.toLowerCase()}`
    });
  }
}
