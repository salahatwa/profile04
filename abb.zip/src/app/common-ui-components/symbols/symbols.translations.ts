class Translations {
    PAGE_TITLE = ['قائمة', 'Watchlist'];
    
    SAVED_SUCCESSFULLY = ['تم حفظ التغييرات بنجاح', 'Your changes have been saved successfully'];
    WATCHLISTS_INDEX_PAGE_TITLE = ['القوائم المفضلة', 'Watchlists'];
    SECTORS_INDEX_PAGE_TITLE = ['مؤشر القطاعات', 'Sectors'];

    NAME = ['اسم القائمة', 'Watchlist Name'];
    IS_DEFAULT = ['تعيين كقائمة افتراضية', 'Set as defualt list'];
    SYMBOLS = ['قائمة الشركات', 'Symbols'];
    SYMBOL_ID = ['الرمز', 'Symbol'];
    SYMBOL_NAME = ['الشركة', 'Name'];
    ADD_SYMBOLS = ['إضافة شركات', 'Add Symbols'];
    EMPTY_SYMBOLS_EDIT = [
        'عفواً ، لا توجد شركات مضافة حتى الآن في القائمة',
        'Sorry, there are no added symbols yet'
    ];
    EMPTY_SYMBOLS_FILTERING = [
        'عفواً ، لا توجد شركات',
        'Sorry, there are no symbols'
    ];
    SAVE = ['حفظ القائمة', 'Save Watchlist'];


    LAST_PRICE = ['السعر / التغير', 'Price / Change'];

    BID = ['أفضل عرض', 'Bid Price'];

    ASK = ['أفضل طلب', 'Ask Price'];

    HIGHEST_LOWEST = ['أعلى / أدنى', 'Highest / Lowest'];

    NEW_WATCHLIST = ['قائمة جديدة', 'New Watchlist'];
    FILTER_PLACEHOLDER = ['رمز أو اسم الشركة', 'the symbol\'s code or name'];
}

export const SymbolsTranslations = new Translations();
