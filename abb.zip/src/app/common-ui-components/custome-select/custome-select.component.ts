import { Component, Input, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'tadawul-custome-select',
  templateUrl: './custome-select.component.html',
  styleUrls: ['./custome-select.component.scss'],
})
export class CustomeSelectComponent implements OnInit {

  @Input() data: any;
  @Input() rowData: any;
  @Input() text: string;
 

  constructor(private modalControl: ModalController) { }

  ngOnInit() {}

  closeModal() {
    this.modalControl.dismiss();
  }


  selectData(item) {
     // const data = item;
      this.modalControl.dismiss(item);
    }

}
