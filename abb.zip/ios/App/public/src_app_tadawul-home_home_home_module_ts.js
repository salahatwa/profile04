"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tadawul-home_home_home_module_ts"],{

/***/ 52642:
/*!**********************************************************!*\
  !*** ./src/app/tadawul-home/home/home-routing.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeComponentRoutingModule": () => (/* binding */ HomeComponentRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _home_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.component */ 2256);




const routes = [
    {
        path: '',
        component: _home_component__WEBPACK_IMPORTED_MODULE_0__.HomeComponent
    }
];
let HomeComponentRoutingModule = class HomeComponentRoutingModule {
};
HomeComponentRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], HomeComponentRoutingModule);



/***/ }),

/***/ 2256:
/*!*****************************************************!*\
  !*** ./src/app/tadawul-home/home/home.component.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HammerDirection": () => (/* binding */ HammerDirection),
/* harmony export */   "HomeComponent": () => (/* binding */ HomeComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _home_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.component.html?ngResource */ 77177);
/* harmony import */ var _home_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.component.scss?ngResource */ 55463);
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @angular/animations */ 17329);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/helpers/cached */ 569);
/* harmony import */ var _inma_helpers_refreshable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/helpers/refreshable */ 2281);
/* harmony import */ var _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/helpers/settings */ 96892);
/* harmony import */ var _inma_models_market__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @inma/models/market */ 1874);
/* harmony import */ var _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @inma/models/portfolio */ 65082);
/* harmony import */ var _inma_models_symbol__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @inma/models/symbol */ 61202);
/* harmony import */ var _inma_models_users__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @inma/models/users */ 17166);
/* harmony import */ var _ionic_native_native_page_transitions_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/native-page-transitions/ngx */ 78810);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ion-bottom-drawer */ 74272);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! jquery */ 85139);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var src_app_app_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/app.component */ 20721);
/* harmony import */ var src_app_enum_mutual_fund_types_enum__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/enum/mutual-fund-types.enum */ 68975);
/* harmony import */ var src_app_enum_skeleton_type_enum__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/enum/skeleton-type.enum */ 88617);
/* harmony import */ var src_app_helpers_localized_string__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/helpers/localized-string */ 41734);
/* harmony import */ var src_app_providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/providers/mutual-funds.service */ 1835);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var _events_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./../../events.service */ 31782);
/* harmony import */ var _pages_mutual_funds_mutual_fund_actions_mutual_fund_actions_page__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./../../pages/mutual-funds/mutual-fund-actions/mutual-fund-actions.page */ 4225);
/* harmony import */ var _pages_portfolio_actions_portfolio_actions_page__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./../../pages/portfolio-actions/portfolio-actions.page */ 51049);
/* harmony import */ var _portfolios_service__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./../../portfolios.service */ 48587);
/* harmony import */ var cupertino_pane__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! cupertino-pane */ 25990);





























let HomeComponent = class HomeComponent {
    constructor(sharedData, router, event, navCtrl, loadingCtrl, route, modalCtrl, gestureCtrl, portfoliosService, mutualFundsService, nativePageTransitions, translate) {
        this.sharedData = sharedData;
        this.router = router;
        this.event = event;
        this.navCtrl = navCtrl;
        this.loadingCtrl = loadingCtrl;
        this.route = route;
        this.modalCtrl = modalCtrl;
        this.gestureCtrl = gestureCtrl;
        this.portfoliosService = portfoliosService;
        this.mutualFundsService = mutualFundsService;
        this.nativePageTransitions = nativePageTransitions;
        this.translate = translate;
        this.market = new _inma_models_market__WEBPACK_IMPORTED_MODULE_5__.MarketModel(_inma_models_market__WEBPACK_IMPORTED_MODULE_5__.MarketsNames.TASI);
        this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_22__.DrawerState.Bottom;
        this.arr = [1, 2, 3, 4, 5];
        this.slideOptsOne = {
            slidesPerView: 1.1,
            centeredSlides: true,
            spaceBetween: 10,
            effect: 'flip'
        };
        this._showPortfolioSymbolsLoader = false;
        this._showPortfolioMutualFundsLoader = false;
        /***********************Portfolios **********/
        this.allPortfolios = [];
        this.portfolioValue = "0";
        this.buyingPower = "0";
        this.portfolioIndex = 0;
        this.portfoliosActiveSegment = "lp";
        this.portfolioLoader = false;
        /***********************tabs************** */
        this.activeSegment = 'INV';
        //public symbolGridHeaderList = () => [{ title: this.t.companyName, size: '4.7' }, { title: this.t.quantity, size: '1.6' }, { title: this.t.costAverage, size: '1.4' }, { title: this.t.lastPrice, size: '1.4' }, { title: this.t.ProfitLossUnrealized, size: '1.9' }];
        // public mutualFundHeaderList = () => [{ title: this.t.fundName, size: '4.5' }, { title: this.t.mutualFundUnits, size: '2' }, { title: this.t.priceAverage, size: '1.8' }, { title: this.t.totalCost, size: '2.5' }];
        this.charitiesMutualFundsArr = [];
        this.standardMutualFundsArr = [];
        this.closedMutualFundsArr = [];
        this.PortfolioType = "";
        this.symbolTabType = 'SYMBOLS';
        this.userPortfolios = [];
        this.segmentPortfolios = [];
        this.userMFPortfolios = [];
        this.userIPPortfolios = [];
        this.SkeletonType = src_app_enum_skeleton_type_enum__WEBPACK_IMPORTED_MODULE_13__.SkeletonType;
        this.MutualFundType = src_app_enum_mutual_fund_types_enum__WEBPACK_IMPORTED_MODULE_12__.MutualFundType;
        this.scrollable = false;
        this.scrolled = false;
        this.mfDetails = [];
        this.Number = Number;
        this.cupertinoPaneSlides = {
            autoHeight: true
        };
        this.Portfolios = _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_6__.Portfolios;
        this.User = _inma_models_users__WEBPACK_IMPORTED_MODULE_8__.User;
        this.modalCtrl.dismiss(null, null, "TOKEN_MODAL");
        this.subscription = this.router.events.subscribe(this.onRouteChange.bind(this));
        this.route.params.subscribe(() => {
            setTimeout(() => {
                this.sharedData.setSharedData("home", 'opend');
            }, 100);
        });
        this.PortfolioType = 'MF';
        // this.event.subscribe('CLOSE_DRAWER',()=>{
        //   this.drawerState = DrawerState.Bottom;
        // })
    }
    symbolSlidesChanged() {
        this.symbolSlides.getActiveIndex().then((idx) => {
            if (idx == 0) {
                this.symbolTabType = 'SYMBOLS';
            }
            else {
                this.symbolTabType = 'SUKUK';
            }
        });
    }
    symbolSegmentChanged() {
        if (this.symbolTabType == 'SYMBOLS') {
            this.symbolSlides.slideTo(0);
        }
        else {
            this.symbolSlides.slideTo(1);
        }
    }
    fundSlidesChanged() {
        this.fundSlides.getActiveIndex().then((idx) => {
            if (idx == 0) {
                this.activeSegment = 'INV';
            }
            else if (idx == 1) {
                this.activeSegment = 'FUND';
            }
            else {
                this.activeSegment = 'CLOSEDFUND';
            }
        });
    }
    fundSegmentChanged() {
        if (this.activeSegment == 'INV') {
            this.fundSlides.slideTo(0);
        }
        else if (this.activeSegment == 'FUND') {
            this.fundSlides.slideTo(1);
        }
        else {
            this.fundSlides.slideTo(2);
        }
    }
    set showPortfolioSymbolsLoader(value) {
        this._showPortfolioSymbolsLoader = value;
    }
    set showPortfolioMutualFundsLoader(value) {
        this._showPortfolioMutualFundsLoader = value;
    }
    get showLoader() {
        return this._showPortfolioSymbolsLoader || this._showPortfolioMutualFundsLoader;
    }
    set showLoader(value) {
        if (value) {
            this._showPortfolioSymbolsLoader = this._showPortfolioMutualFundsLoader = value;
        }
        else {
            throw "hide individual elements first";
        }
    }
    ngAfterViewInit() {
        // setTimeout(() => {
        //   let height = this.inViewport($('.drawer-content'));
        //   console.log('height init: ' + height);
        //   $('.symbols-ion-list').height(height - 95 - 60);
        //   $('.swiper-slide').height(height - 95 - 60);
        //   this.initGestureDrawerDrag();
        // }, 400);
        /*----- Bottom Drawer Events - Start ----- */
        // const hammer = new Hammer(this.drawerContent.nativeElement);
        // hammer.get('pan').set({ enable: true, direction: Hammer.DIRECTION_VERTICAL });
        // hammer.on('pan pandown panup', (ev: any) => {
        //   switch (ev.type) {
        //     case 'panup':
        //       this.openBottomDrawer();
        //       break;
        //     case 'pandown':
        //       this.closeBottomDrawer()
        //       break;
        //     default:
        //   }
        // });
        // this.myPane.present({ animate: true });
    }
    // checkState() {
    //   this.scrolled = false;
    //   if (this.drawerState > DrawerState.Bottom) {
    //     this.scrollable = true;
    //   }
    // }
    // triggerScrollEvent() {
    //   if (this.drawerContent.nativeElement.scrollTop <= 0 && this.scrolled) {
    //     this.scrollable = false
    //   }
    //   this.scrolled = true;
    // }
    // openBottomDrawer() {
    //   if (this.drawerState == DrawerState.Bottom) {
    //     this.drawerState = DrawerState.Top;
    //   }
    // }
    // closeBottomDrawer() {
    //   if (this.drawerContent.nativeElement.scrollTop <= 0 && this.drawerState > DrawerState.Bottom) {
    //     this.drawerState = DrawerState.Bottom;
    //     this.scrollable = false;
    //     this.scrolled = false;
    //   }
    // }
    /*----- Bottom Drawer Events - End ----- */
    inViewport($el) {
        var elH = $el.outerHeight(), H = jquery__WEBPACK_IMPORTED_MODULE_10__(window).height(), r = $el[0].getBoundingClientRect(), t = r.top, b = r.bottom;
        return Math.max(0, t > 0 ? Math.min(elH, H - t) : Math.min(b, H));
    }
    initGestureDrawerDrag() {
        let gesture = this.gestureCtrl.create({
            el: this.bDrawer.nativeElement,
            onMove: (detail) => { this.onMove(detail); },
            gestureName: 'dragDrawer'
        }, true);
        gesture.enable();
    }
    onMove(detail) {
        console.log("🚀 ~ file: home.component.ts ~ line 216 ~ HomeComponent ~ onMove ~ detail", detail);
        const type = detail.type;
        const currentY = detail.currentY;
        const deltaY = detail.deltaY;
        const velocityY = detail.velocityY;
        if (deltaY > 0) {
            console.log(deltaY);
        }
        else {
            console.log(deltaY);
        }
    }
    initDrawerStateVariables() {
        let sat = getComputedStyle(document.documentElement).getPropertyValue("--sat");
        sat = sat.substring(0, sat.indexOf('px'));
        let _topSafeArea = Number(sat);
        this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_22__.DrawerState.Bottom;
        let screenHeight = window.innerHeight;
        let androidPadding = 0;
        if (src_app_app_component__WEBPACK_IMPORTED_MODULE_11__.App.platformType == 'android') {
            androidPadding = 25;
        }
        this.distanceTop = 105 + _topSafeArea + androidPadding;
        this.dockedHeight = screenHeight - this.distanceTop;
        console.log("🚀 ~ file: home.component.ts ~ line 143 ~ HomeComponent ~ constructor ~ dockedHeight", this.dockedHeight);
        this.minHeight = screenHeight - 375 - _topSafeArea - androidPadding;
        console.log("🚀 ~ file: home.component.ts ~ line 146 ~ HomeComponent ~ constructor ~ minHeight", this.minHeight);
    }
    initPortfolioDetailsModalVariables() {
        let screenHeight = window.innerHeight;
        let sab = getComputedStyle(document.documentElement).getPropertyValue("--sab");
        sab = sab.substring(0, sab.indexOf('px'));
        let _bottomSfeArea = Number(sab);
        let modalContent = 250 + _bottomSfeArea; // 250px for all screen should all the content shown;
        this.portfolioDetailsModalHeight = Number((modalContent / screenHeight).toFixed(2));
    }
    ngOnInit() {
        this.onEnter();
        // this.initDrawerStateVariables();
        this.initPortfolioDetailsModalVariables();
        setTimeout(() => {
            _inma_models_symbol__WEBPACK_IMPORTED_MODULE_7__.Symbols.preload();
        }, 5000);
        this.initCupertinoPaneDrawer();
    }
    initCupertinoPaneDrawer() {
        let sat = getComputedStyle(document.documentElement).getPropertyValue("--sat");
        let sab = getComputedStyle(document.documentElement).getPropertyValue("--sab");
        sat = sat.substring(0, sat.indexOf('px'));
        let _topSafeArea = Number(sat);
        sab = sab.substring(0, sat.indexOf('px'));
        let _bottomSafeArea = Number(sat);
        this.drawerState = 0;
        let screenHeight = window.innerHeight;
        let androidPadding = 0;
        if (src_app_app_component__WEBPACK_IMPORTED_MODULE_11__.App.platformType == 'android') {
            androidPadding = 25;
        }
        this.distanceTop = screenHeight - 102 - _topSafeArea - androidPadding - 45 - _bottomSafeArea;
        this.minHeight = screenHeight - 102 - _topSafeArea - androidPadding - 270 - 45 - _bottomSafeArea;
        this.myPane = new cupertino_pane__WEBPACK_IMPORTED_MODULE_21__.CupertinoPane('.bottom-drawer', {
            initialBreak: 'bottom',
            lowerThanBottom: false,
            clickBottomOpen: false,
            buttonDestroy: false,
            bottomOffset: 45 + _bottomSafeArea,
            // lowerThanBottom: false,
            // fitHeight: true,
            breaks: {
                top: { enabled: true, height: this.distanceTop },
                middle: { enabled: false },
                bottom: { enabled: true, height: this.minHeight },
            }
        });
        this.myPane.present();
        this.myPane.on('onTransitionEnd', () => {
            if (this.myPane.currentBreak() === 'top') {
                this.drawerState = 1;
            }
            else if (this.myPane.currentBreak() === 'bottom') {
                this.drawerState = 0;
            }
        });
    }
    onRouteChange(event) {
        if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_23__.NavigationStart) {
            // console.log(event.url);
            if (event.url == 'main/tabs' || event.url == 'main/tabs/home') {
                this.onEnter();
            }
        }
    }
    onEnter(portfolioNumber) {
        // if (this.portfolioIndex) {
        //   this.getFunds(this.allPortfolios[this.portfolioIndex]);
        // } else {
        (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_2__.resetCache)(_inma_models_market__WEBPACK_IMPORTED_MODULE_5__.Market, 'info');
        (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_2__.resetCache)(_inma_models_portfolio__WEBPACK_IMPORTED_MODULE_6__.Portfolios, 'all');
        (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_2__.resetCache)(_inma_models_portfolio__WEBPACK_IMPORTED_MODULE_6__.Portfolios, 'allStandardPortfolios');
        (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_2__.resetCache)(_inma_models_portfolio__WEBPACK_IMPORTED_MODULE_6__.Portfolios, 'allMutualFundPortfolios');
        // if(!portfolioNumber){
        //   this.porDetails = null;
        // }
        this.portfolioIndex = 0;
        if (this.portfoliosActiveSegment == 'lp') {
            this.PortfolioType = 'IN';
            this.symbolTabType = 'SYMBOLS';
            this.symbolArray = null;
            this.symbols_arr = null;
            this.sukuk_arr = null;
            this.getAllStandardPortfolios();
        }
        else {
            this.PortfolioType = 'MF';
            this.activeSegment = 'INV';
            this.mfDetails = null;
            if (this.userMFPortfolios.length > 0) {
                this.getAllMutualFundPortfolios(this.userMFPortfolios[this.portfolioIndex]);
            }
        }
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_4__.Settings.getUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_4__.Settings.preferedThemeKey).subscribe(val => {
            if (val == null || val == "light-theme") {
                this.firstSegmentIcon = 'assets/icon/mutualfund.png';
                this.secondSegmentIcon = 'assets/icon/mutualfund.png';
            }
            else {
                this.firstSegmentIcon = 'assets/icon/mutualfund-dark.svg';
                this.secondSegmentIcon = 'assets/icon/mutualfund-dark.svg';
            }
        });
        this.isExpired = src_app_app_component__WEBPACK_IMPORTED_MODULE_11__.AppComponent.idExpiryDate || src_app_app_component__WEBPACK_IMPORTED_MODULE_11__.AppComponent.ExpiredUserID;
        // }
    }
    ngOnDestroy() {
        console.log('home closed');
        this.subscription.unsubscribe();
    }
    collapsSymbole(item, dataArr) {
        for (let i = 0; i < dataArr.length; i++) {
            if (dataArr[i].id == item.id) {
                if (dataArr[i].expanded == true) {
                    dataArr[i].expanded = false;
                    return;
                }
                else {
                    dataArr[i].expanded = true;
                }
            }
            else {
                dataArr[i].expanded = false;
            }
        }
    }
    openIDExpiryDate() {
        let options = {
            direction: 'up',
            duration: 500,
            slowdownfactor: 3,
            slidePixels: 20,
            iosdelay: 100,
            androiddelay: 150,
            fixedPixelsTop: 0,
            fixedPixelsBottom: 60
        };
        this.nativePageTransitions.slide(options);
        this.navCtrl.navigateForward('/id-expired', { animated: false });
    }
    /****************Portfolio************************* */
    getAllPortfolio() {
        _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_6__.Portfolios.all.subscribe(Portfolios => {
            // this.allPortfolios = Portfolios;
            // this.getFunds(Portfolios[this.portfolioIndex]);
        });
    }
    getAllMutualFundPortfolios(por) {
        this.porDetails = null;
        this.isPortfolioLoaded = false;
        this.segmentPortfolios.forEach((p) => {
            p._currentPortfolio = p.number == por.number ? true : false;
        });
        this.mfDetails = [];
        // this.portfoliosService.getPortfolioDetailsInfo(por.number).subscribe((res: PortfolioDetailsInfo) => {
        // });
        this.portfoliosService.getMFPortfolioDetails(por.number).subscribe((response) => {
            var _a, _b, _c, _d, _e, _f, _g;
            this.isPortfolioLoaded = true;
            this.porDetails = {
                totalMrktValue: Number((_a = response === null || response === void 0 ? void 0 : response.totalMarketValue) === null || _a === void 0 ? void 0 : _a.amount).toFixed(2),
                totalProfitLoss: Number((_b = response === null || response === void 0 ? void 0 : response.totalUnrealizedprofitLossAmt) === null || _b === void 0 ? void 0 : _b.amount).toFixed(2),
                totalCost: Number((_c = response === null || response === void 0 ? void 0 : response.totalCost) === null || _c === void 0 ? void 0 : _c.amount).toFixed(2),
                buyingPwrAmt: response._buyingPower,
                availableBalance: Number((_d = response === null || response === void 0 ? void 0 : response.availableBalance) === null || _d === void 0 ? void 0 : _d.amount).toFixed(2),
                margin: (_e = response === null || response === void 0 ? void 0 : response.margin) === null || _e === void 0 ? void 0 : _e.amount,
                portfolioPostionAmt: Number((_f = response === null || response === void 0 ? void 0 : response.portfolioPostionAmt) === null || _f === void 0 ? void 0 : _f.amount).toFixed(2),
                coverageRatio: response === null || response === void 0 ? void 0 : response.coverageRatio,
                accountNumber: response === null || response === void 0 ? void 0 : response.accountNumber,
                accountType: response === null || response === void 0 ? void 0 : response.accountType,
                samaAccountNumber: response === null || response === void 0 ? void 0 : response.samaAccountNumber,
                _portfolioNumber: por.number,
                _type: por.portfolioType.code,
                _isDefault: por.defaultPortfolio,
                actualBalance: Number((_g = response === null || response === void 0 ? void 0 : response.buyingPwrAmt) === null || _g === void 0 ? void 0 : _g.amount).toFixed(2),
                blockedAmt: null,
                tradeSecurties: null,
                _cashValue: response._cashValue,
                _unitValue: response._unitValue,
                _portfolioValue: response._portfolioValue,
                _cashPercentage: response._cashPercentage,
                _unitPercentage: response._unitPercentage,
                _buyingPower: response._buyingPower,
                _totalLoss: response._totalLoss
            };
            this.isAllPortfolioLoaded = true;
            if (this.isPortfolioSegmentChanged) {
                this.isPortfolioSegmentChanged = false;
            }
            response.mutualFundPositionList.forEach(element => {
                this.mfDetails.push({
                    name: element.arName,
                    changeRate: Number(element.unrealizedGainLoss.amount),
                    changeRatePercentage: Number(element.unrealizedGainLossPer.amount),
                    quantity: Number(element.units.amount),
                    cost: Number(element.avgPrice.amount),
                    price: Number(element.lastValuationPrice.amount),
                    type: element.type,
                    closedFund: element.closedFund
                });
            });
            if (this.porDetails) {
                this.porDetails._MFDetails = this.mfDetails;
            }
            this.standardMutualFundsArr = this.mfDetails.filter((mf) => mf.type == 'MF' && !mf.closedFund);
            this.charitiesMutualFundsArr = this.mfDetails.filter((mf) => mf.type == 'CF');
            this.closedMutualFundsArr = this.mfDetails.filter((mf) => mf.type == 'MF' && mf.closedFund);
        });
    }
    portfolioSegmentChanged(event) {
        var _a, _b;
        // console.log(event.detail.value);
        if (!this.isAllPortfolioLoaded) {
            return false;
        }
        ;
        this.isPortfolioSegmentChanged = true;
        this.portfolioIndex = 0;
        (_a = this.portfolioSlides) === null || _a === void 0 ? void 0 : _a.update();
        this.porDetails = null;
        if (this.portfoliosActiveSegment == 'lp') {
            this.segmentPortfolios = [];
            this.PortfolioType = 'IN';
            this.symbolTabType = 'SYMBOLS';
            if (this.userIPPortfolios.length != 0) {
                this.getAllStandardPortfolios();
            }
            else {
                this.isPortfolioSegmentChanged = false;
            }
        }
        else if (this.portfoliosActiveSegment == 'mf') {
            this.segmentPortfolios = this.userMFPortfolios;
            this.PortfolioType = 'MF';
            this.activeSegment = 'INV';
            if (((_b = this.userMFPortfolios) === null || _b === void 0 ? void 0 : _b.length) != 0) {
                this.isAllPortfolioLoaded = false;
                this.getAllMutualFundPortfolios(this.segmentPortfolios[this.portfolioIndex]);
            }
            else {
                this.isPortfolioSegmentChanged = false;
            }
        }
    }
    portfolioChanged(por) {
        console.log(' Portfolio Number ' + por.number + ' Portfolios [ ' + this.segmentPortfolios.map((p) => p.number) + ' ] currentIndex ' + this.portfolioIndex);
        setTimeout(() => {
            var _a;
            this.symbolArray = [];
            this.symbols_arr = [];
            this.sukuk_arr = [];
            this.porDetails = null;
            this.isPortfolioLoaded = false;
            (_a = this.portfolioSlides) === null || _a === void 0 ? void 0 : _a.update();
            this.portfolioDetailsSubscriber = this.portfoliosService.getPortfolioDetailsInfo(por.number).subscribe((res) => {
                var _a;
                this.porDetails = res;
                this.porDetails._portfolioNumber = por.number;
                this.porDetails._type = por.portfolioType.code;
                this.porDetails._isDefault = por.defaultPortfolio;
                if (this.refreshLoaded) {
                    this.portfolioSlides.slideTo(this.segmentPortfolios.findIndex((p) => p.number == this.porDetails._portfolioNumber)).then(() => {
                        this.portfolioIndex = this.segmentPortfolios.findIndex((p) => p.number == this.porDetails._portfolioNumber);
                        // this.portfolioIndex = await this.portfolioSlides.getActiveIndex();
                        setTimeout(() => {
                            this.refreshLoaded = false;
                        }, 200);
                    });
                    // this.refreshLoaded = false;
                }
                if (this.isPortfolioSegmentChanged) {
                    this.isPortfolioSegmentChanged = false;
                }
                //this.portfolioSlides.slideTo(this.portfolioIndex).then(() => {
                this.isPortfolioLoaded = true;
                // });
                this.porDetails.tradeSecurties.forEach((s) => {
                    s._secName = new src_app_helpers_localized_string__WEBPACK_IMPORTED_MODULE_14__.LocalizedString(s === null || s === void 0 ? void 0 : s.secEnName, s === null || s === void 0 ? void 0 : s.secArName, this.translate);
                });
                this.symbols_arr = this.porDetails.tradeSecurties.filter((s) => s.securityType == 'STOCK');
                this.sukuk_arr = this.porDetails.tradeSecurties.filter((s) => s.securityType == 'BOND');
                (_a = this.portfolioSlides) === null || _a === void 0 ? void 0 : _a.update();
            });
        }, 300);
    }
    getAllStandardPortfolios() {
        var _a;
        this.PortfolioType = 'IN';
        (_a = this.portfolioSlides) === null || _a === void 0 ? void 0 : _a.update();
        this.isPortfolioLoaded = false;
        this.portfolioLoader = true;
        this.userIPPortfolios = [];
        this.isAllPortfolioLoaded = false;
        this.allPortfolioSubscriber = _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_6__.Portfolios.loadPortfolios.subscribe((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__awaiter)(this, void 0, void 0, function* () {
            var _b;
            this.userPortfolios = res;
            let idx = this.userPortfolios.findIndex(p => { var _a; return p.defaultPortfolio == true && ((_a = p.portfolioType) === null || _a === void 0 ? void 0 : _a.code) == _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_6__.PortfolioType.STANDARD_PORTFOLIO; }); // get the index of default portfolio
            if (idx >= 0) {
                this.userPortfolios.unshift(this.userPortfolios.splice(idx, 1)[0]); // reorder portfolios by shift the default one in the beginning 
            }
            this.userIPPortfolios = this.userPortfolios.filter(por => { var _a; return ((_a = por.portfolioType) === null || _a === void 0 ? void 0 : _a.code) == _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_6__.PortfolioType.STANDARD_PORTFOLIO; }); // investment portfolios 
            // this.userIPPortfolios = [] // investment portfolios 
            this.userMFPortfolios = this.userPortfolios.filter(por => { var _a; return ((_a = por.portfolioType) === null || _a === void 0 ? void 0 : _a.code) == _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_6__.PortfolioType.MUTUAL_FUND; }); //mutual fund portfolios
            // this.userMFPortfolios = []; //mutual fund portfolios
            (_b = this.portfolioDetailsSubscriber) === null || _b === void 0 ? void 0 : _b.unsubscribe();
            this.isAllPortfolioLoaded = true;
            if (this.userIPPortfolios.length > 0) {
                this.segmentPortfolios = this.userIPPortfolios;
                if (this.porDetails && this.porDetails._type == _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_6__.PortfolioType.STANDARD_PORTFOLIO) {
                    this.portfolioIndex = this.segmentPortfolios.findIndex((p) => p.number == this.porDetails._portfolioNumber);
                    // this.portfolioIndex = await this.portfolioSlides.getActiveIndex();
                    this.portfolioChanged(this.segmentPortfolios[this.portfolioIndex]);
                }
                else {
                    this.portfolioIndex = 0;
                    this.portfolioChanged(this.segmentPortfolios[0]); // get portfolio details 
                }
            }
            else {
                this.portfoliosActiveSegment = 'mf';
            }
        }), (err) => {
        }, () => {
        });
    }
    getCurrentPortfolioChanges() {
        _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_6__.Portfolios.onCurrentPortfolioChange.subscribe(() => {
            //UNDO console.log('onCurrentPortfolioChange>>>>>>>>>>' + onCurrentPortfolioChange);
            //UNDO console.log('current>>>>>>>>>>' + Portfolios.current?.name);
        });
    }
    // getCurrentPortfolio() {
    //   Portfolios.current.subscribe(currentPortfolios => {
    //     //UNDO console.log('currentPortfolios>>>>>>>>>>' + currentPortfolios);
    //   });
    // }
    slideForward() {
        var _a;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__awaiter)(this, void 0, void 0, function* () {
            if (!this.isAllPortfolioLoaded) {
                return false;
            }
            ;
            this.isPortfolioLoaded = false;
            this.portfolioIndex = yield this.portfolioSlides.getActiveIndex();
            this.symbolArray = [];
            this.symbols_arr = [];
            this.sukuk_arr = [];
            this.charitiesMutualFundsArr = [];
            this.standardMutualFundsArr = [];
            this.closedMutualFundsArr = [];
            (_a = this.portfolioDetailsSubscriber) === null || _a === void 0 ? void 0 : _a.unsubscribe();
            if (this.PortfolioType == 'IN') {
                this.portfolioIndex = Math.min(this.portfolioIndex, this.userIPPortfolios.length - 1);
                this.portfolioChanged(this.segmentPortfolios[this.portfolioIndex]);
                this.symbolTabType = 'SYMBOLS';
            }
            else if (this.PortfolioType != 'IN') {
                this.portfolioIndex = Math.min(this.portfolioIndex, this.userMFPortfolios.length - 1);
                this.getAllMutualFundPortfolios(this.segmentPortfolios[this.portfolioIndex]);
                this.activeSegment = 'INV';
            }
        });
    }
    slideBack() {
        var _a;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__awaiter)(this, void 0, void 0, function* () {
            if (!this.isAllPortfolioLoaded) {
                return false;
            }
            ;
            this.isPortfolioLoaded = false;
            this.portfolioIndex = yield this.portfolioSlides.getActiveIndex();
            this.symbolArray = [];
            this.symbols_arr = [];
            this.sukuk_arr = [];
            this.charitiesMutualFundsArr = [];
            this.standardMutualFundsArr = [];
            this.closedMutualFundsArr = [];
            (_a = this.portfolioDetailsSubscriber) === null || _a === void 0 ? void 0 : _a.unsubscribe();
            if (this.PortfolioType == 'IN') {
                this.portfolioIndex = Math.max(0, this.portfolioIndex);
                this.portfolioChanged(this.userIPPortfolios[this.portfolioIndex]);
                this.symbolTabType = 'SYMBOLS';
            }
            else {
                this.portfolioIndex = Math.max(0, this.portfolioIndex);
                this.getAllMutualFundPortfolios(this.userMFPortfolios[this.portfolioIndex]);
                this.activeSegment = 'INV';
            }
        });
    }
    openPortfolioDetail() {
        // this.router.navigate(['portfolios/details']);
        this.navCtrl.navigateForward('/portfolios/details', { animated: true });
    }
    setDefaultPortfolio() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingCtrl.create({
                message: this.translate.currentLang == 'ar' ? 'جاري تعيين المحفظة الرئيسية' : 'Setting Default Portfolio',
            });
            loading.present();
            _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_6__.Portfolios.manageDefaultPortfolio(this.porDetails._portfolioNumber, this.porDetails._type, 'SET_DEFAULT').subscribe((res) => {
                this.userPortfolios.forEach(p => {
                    p.defaultPortfolio = p.number == this.porDetails._portfolioNumber ? true : false;
                });
                (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_2__.resetCache)(_inma_models_portfolio__WEBPACK_IMPORTED_MODULE_6__.Portfolios, 'loadPortfolios');
                (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_2__.resetCache)(_inma_models_portfolio__WEBPACK_IMPORTED_MODULE_6__.Portfolios, 'getOrderPagePortfolios');
                this.porDetails._isDefault = true;
                this.loadingCtrl.dismiss();
                // this.userPortfolios.find((p)=> p.number == this.porDetails._portfolioNumber).defaultPortfolio = true;
            });
            // for (let i = 0; i < this.userPortfolios.length; i++) {
            //   if (this.userPortfolios[i].number == portfolio.number) {
            //     this.userPortfolios[i].defaultPortfolio = true;
            //   } else { this.userPortfolios[i].defaultPortfolio = false; }
            // }
        });
    }
    resetDefaultPortfolio() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingCtrl.create({
                message: this.translate.currentLang == 'ar' ? 'جاري إلغاء المحفظة الرئيسية' : 'Resetting Default Portfolio',
            });
            loading.present();
            _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_6__.Portfolios.manageDefaultPortfolio(this.porDetails._portfolioNumber, this.porDetails._type, 'RESET_DEFAULT').subscribe((res) => {
                this.porDetails._isDefault = false;
                this.userPortfolios.forEach((p) => {
                    p.defaultPortfolio = false;
                });
                (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_2__.resetCache)(_inma_models_portfolio__WEBPACK_IMPORTED_MODULE_6__.Portfolios, 'loadPortfolios');
                (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_2__.resetCache)(_inma_models_portfolio__WEBPACK_IMPORTED_MODULE_6__.Portfolios, 'getOrderPagePortfolios');
                this.loadingCtrl.dismiss();
            });
        });
    }
    /*******************Symbols**************************** */
    getSymbolDetail(symbol) {
        // this.symbolArray = [];
        // let symbolArray = [];
        // tslint:disable-next-line: prefer-for-of
        for (let i = 0; i < symbol.length; i++) {
            const obj = {};
            // //UNDO console.log('portfolioID>>>>>>>>' + symbol[i].portfolioID);
            obj.id = symbol[i].id;
            obj.gainLossRealized = symbol[i].gainLossRealized;
            obj.gainLossPercentageRealized = symbol[i].gainLossPercentageRealized;
            obj.gainLossUnrealized = symbol[i].gainLossUnrealized;
            obj.gainLossPercentageUnrealized = symbol[i].gainLossPercentageUnrealized;
            obj.costTotal = symbol[i].costTotal;
            obj.costAverage = symbol[i].costAverage;
            obj.marketValue = symbol[i].marketValue;
            obj.expanded = false;
            obj.symbol = symbol[i];
            obj.symbolName = symbol[i].symbolName;
            obj.securityType = symbol[i].securityType;
            symbol[i].name.subscribe(() => {
                //UNDO console.log('name>>>>>>>>' + name);
                //obj.name = name;
            });
            symbol[i].parameters.subscribe(() => {
                //UNDO console.log('parameters>>>>>>>>' + parameters);
                // obj.parameters = parameters;
            });
            symbol[i].abbreviation.subscribe(abbreviation => {
                //UNDO console.log('abbreviation>>>>>>>>' + abbreviation);
                obj.abbreviation = abbreviation;
            });
            obj.ownedQuantity = symbol[i].ownedQuantity;
            obj.symbolPrice = symbol[i].symbolPrice;
            symbol[i].symbolChange.subscribe(symbolChange => {
                obj.change = symbolChange;
            });
            // this.symbolArray.push(obj);
        }
        this.orderSymbolArrDec();
        this.symbols_arr = this.symbolArray.filter((s) => s.securityType == 'STOCK');
        this.sukuk_arr = this.symbolArray.filter((s) => s.securityType == 'BOND');
    }
    orderSymbolArrAsc() {
        this.symbolArray.sort(function (a, b) {
            const keyA = a.unrealizedProfitLoss.amount, keyB = b.unrealizedProfitLoss.amount;
            // Compare the 2 dates
            if (keyA < keyB)
                return -1;
            if (keyA > keyB)
                return 1;
            return 0;
        });
        //console.log(this.symbolArray);
    }
    orderSymbolArrDec() {
        this.symbolArray.sort(function (a, b) {
            const keyA = a.unrealizedProfitLoss.amount, keyB = b.unrealizedProfitLoss.amount;
            // Compare the 2 dates
            if (keyA < keyB)
                return 1;
            if (keyA > keyB)
                return -1;
            return 0;
        });
        //console.log(this.symbolArray);
    }
    openBuySellSymbols(symbol, operation) {
        this.sharedData.setSharedData(symbol, 'sharedSymbol');
        this.sharedData.setSharedData(operation, 'operation');
        this.navCtrl.navigateForward('order', { animated: true });
        // OrderPage.initialize();
    }
    openSymbol(item) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingCtrl.create({});
            loading.present();
            _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_6__.Portfolios.all.subscribe((res) => {
                _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_6__.Portfolios.current = res.find((p) => p.id == this.porDetails._portfolioNumber);
                _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_6__.Portfolios.current.symbols.subscribe(symbol => {
                    symbol = symbol.filter((s) => s.id == item.symbol.code);
                    this.sharedData.setSharedData({ symbol: symbol[0] }, 'sharedSymbol');
                    loading.dismiss();
                    this.navCtrl.navigateForward('main/symbol');
                });
            });
            // OrderPage.initialize();
        });
    }
    /*************************segments */
    segmentChanged(event) {
        this.activeSegment = event;
        //UNDO console.log("segment>>>>>>>>" + this.activeSegment)
    }
    openSubscription(item) {
        //UNDO console.log(item);
        this.mutualFundsService.setMutualFund(item);
        this.navCtrl.navigateForward(['/mutual-funds-subscribe']);
    }
    openRedemption(item) {
        this.mutualFundsService.setMutualFund(item);
        this.navCtrl.navigateForward(['/mutual-funds-redemption']);
    }
    openMFActions(item, type) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _pages_mutual_funds_mutual_fund_actions_mutual_fund_actions_page__WEBPACK_IMPORTED_MODULE_18__.MutualFundActionsPage,
                cssClass: 'auto-height-modal ipad-full-width-modal',
                componentProps: {
                    mutualFund: item,
                    type: type
                },
                swipeToClose: true
            });
            return yield modal.present();
        });
    }
    openReports(item) {
        // //UNDO console.log(item);
        this.navCtrl.navigateForward(['/reports', item.id]);
    }
    goToBuyAndSell() {
        this.navCtrl.navigateForward('/order');
    }
    goToMutualFunds(dist) {
        if (dist === 'investment') {
            this.sharedData.setSharedData('investment', 'MF_emptyState');
        }
        if (dist === 'endowment') {
            this.sharedData.setSharedData('endowment', 'MF_emptyState');
        }
        this.navCtrl.navigateForward('/mutual-funds');
    }
    doRefresh(event) {
        var _a, _b, _c;
        this.refreshLoaded = true;
        (_a = this.portfolioDetailsSubscriber) === null || _a === void 0 ? void 0 : _a.unsubscribe();
        (_b = this.allPortfolioSubscriber) === null || _b === void 0 ? void 0 : _b.unsubscribe();
        // set skeleton loader variables to be shown
        this.isPortfolioLoaded = false;
        this.symbolArray = null;
        if (this.porDetails) {
            this.portfoliosActiveSegment = ((_c = this.porDetails) === null || _c === void 0 ? void 0 : _c._type) == 'IP' ? 'lp' : 'mf';
        }
        else {
            this.portfoliosActiveSegment = 'lp';
        }
        this.onEnter();
        setTimeout(() => {
            event.target.complete();
            // set skeleton loader variables to be hidden
            // this.isPortfolioLoaded = true;
        }, 500);
    }
    // changeState() {
    //   if (this.drawerState >= DrawerState.Docked) {
    //     this.drawerState = DrawerState.Bottom;
    //     this.drawerCheck = false;
    //   }
    //   else if (this.drawerState == DrawerState.Bottom) {
    //     this.drawerState = DrawerState.Docked;
    //     if($('.drawer-content .content').height() > $('.drawer-content').height()) {
    //       this.drawerCheck = true;
    //     }
    //   }
    //   // setTimeout(() => {
    //   //   let height = this.inViewport($('.drawer-content'));
    //   //   console.log('height : ' + height);
    //   //   $('.symbols-ion-list').height(height - 95 - 60);
    //   //   $('.swiper-slide').height(height - 95 - 60);
    //   // }, 400);
    // }
    openActions() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _pages_portfolio_actions_portfolio_actions_page__WEBPACK_IMPORTED_MODULE_19__.PortfolioActionsPage,
                cssClass: 'auto-height-modal ipad-full-width-modal',
                componentProps: {
                    portfolio: this.porDetails
                },
                swipeToClose: true
            });
            modal.onDidDismiss().then((data) => {
            });
            return yield modal.present();
        });
    }
    ionViewWillEnter() {
        this.refreshLoaded = false;
        if (src_app_app_component__WEBPACK_IMPORTED_MODULE_11__.App.platformType == 'android') {
            this.headerClass = 'android-header';
        }
        else {
            this.headerClass = '';
        }
        this.direction = document.dir;
        console.log(':::::::::::::: Direction :::::::::::::: ', document.dir);
        // this.event.publish('CHANGE_HOME_DIR', this.direction);
        this.directionChanged = true;
        (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_2__.resetCache)(_inma_models_market__WEBPACK_IMPORTED_MODULE_5__.Market, 'info');
        _inma_models_market__WEBPACK_IMPORTED_MODULE_5__.Market.changeMarkets("TASI");
        this.sharedData.marketName.next("TASI");
    }
    ionViewWillLeave() {
        console.log(':::::::::::::: Direction 8:::::::::::::: ');
        // this.subscription.unsubscribe();
        this.market.disconnectToStream();
    }
    openProfile() {
        this.navCtrl.navigateForward('main/user-profile');
    }
    openNotification() {
        this.navCtrl.navigateForward('main/notifications');
    }
};
HomeComponent.ctorParameters = () => [
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_16__.SharedDataService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_23__.Router },
    { type: _events_service__WEBPACK_IMPORTED_MODULE_17__.EventsService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_25__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_25__.LoadingController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_23__.ActivatedRoute },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_25__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_25__.GestureController },
    { type: _portfolios_service__WEBPACK_IMPORTED_MODULE_20__.PortfoliosService },
    { type: src_app_providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_15__.MutualFundsService },
    { type: _ionic_native_native_page_transitions_ngx__WEBPACK_IMPORTED_MODULE_9__.NativePageTransitions },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_26__.TranslateService }
];
HomeComponent.propDecorators = {
    portfolioSlides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_27__.ViewChild, args: ['portfolioSlides',] }],
    bDrawer: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_27__.ViewChild, args: ['bDrawer',] }],
    symbolSlides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_27__.ViewChild, args: ['symbolSlides',] }],
    drawerContent: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_27__.ViewChild, args: ['drawerContent',] }],
    fundSlides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_27__.ViewChild, args: ['fundSlides',] }]
};
(0,tslib__WEBPACK_IMPORTED_MODULE_24__.__decorate)([
    _inma_helpers_refreshable__WEBPACK_IMPORTED_MODULE_3__.onRefresh,
    (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__metadata)("design:type", Function),
    (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__metadata)("design:paramtypes", [String]),
    (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__metadata)("design:returntype", void 0)
], HomeComponent.prototype, "onEnter", null);
HomeComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_27__.Component)({
        selector: 'tadawul-home',
        template: _home_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_27__.ViewEncapsulation.None,
        animations: [
            (0,_angular_animations__WEBPACK_IMPORTED_MODULE_28__.trigger)('inOutAnimation', [
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_28__.transition)(':enter', [
                    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_28__.style)({ opacity: 0 }),
                    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_28__.animate)('1s ease-in', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_28__.style)({ opacity: 1 }))
                ]),
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_28__.transition)(':leave', [
                    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_28__.style)({ opacity: 1 }),
                    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_28__.animate)('1s ease-in', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_28__.style)({ opacity: 0 }))
                ])
            ])
        ],
        styles: [_home_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__metadata)("design:paramtypes", [src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_16__.SharedDataService,
        _angular_router__WEBPACK_IMPORTED_MODULE_23__.Router,
        _events_service__WEBPACK_IMPORTED_MODULE_17__.EventsService,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_25__.NavController,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_25__.LoadingController,
        _angular_router__WEBPACK_IMPORTED_MODULE_23__.ActivatedRoute,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_25__.ModalController,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_25__.GestureController,
        _portfolios_service__WEBPACK_IMPORTED_MODULE_20__.PortfoliosService,
        src_app_providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_15__.MutualFundsService,
        _ionic_native_native_page_transitions_ngx__WEBPACK_IMPORTED_MODULE_9__.NativePageTransitions,
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_26__.TranslateService])
], HomeComponent);

var HammerDirection;
(function (HammerDirection) {
    HammerDirection[HammerDirection["UP"] = 8] = "UP";
    HammerDirection[HammerDirection["DOWN"] = 16] = "DOWN";
    HammerDirection[HammerDirection["NO_MOVEMENT"] = 0] = "NO_MOVEMENT";
    HammerDirection[HammerDirection["LEFT"] = 2] = "LEFT";
    HammerDirection[HammerDirection["RIGHT"] = 4] = "RIGHT";
    HammerDirection[HammerDirection["HORIZONTA"] = 5] = "HORIZONTA";
})(HammerDirection || (HammerDirection = {}));


/***/ }),

/***/ 77403:
/*!**************************************************!*\
  !*** ./src/app/tadawul-home/home/home.module.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeComponentModule": () => (/* binding */ HomeComponentModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _portfolios_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../portfolios.service */ 48587);
/* harmony import */ var src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/pipes/pipes.module */ 41041);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);
/* harmony import */ var _home_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./home.component */ 2256);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./home-routing.module */ 52642);
/* harmony import */ var ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ion-bottom-drawer */ 74272);












let HomeComponentModule = class HomeComponentModule {
};
HomeComponentModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            _home_routing_module__WEBPACK_IMPORTED_MODULE_4__.HomeComponentRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.ReactiveFormsModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_1__.PipesModule,
            ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_10__.IonBottomDrawerModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__.TranslateModule.forChild()
        ],
        providers: [_portfolios_service__WEBPACK_IMPORTED_MODULE_0__.PortfoliosService],
        declarations: [_home_component__WEBPACK_IMPORTED_MODULE_3__.HomeComponent]
    })
], HomeComponentModule);



/***/ }),

/***/ 25990:
/*!********************************************************************!*\
  !*** ./node_modules/cupertino-pane/dist/cupertino-pane.esm.min.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CupertinoPane": () => (/* binding */ CupertinoPane)
/* harmony export */ });
/**
 * Cupertino Pane 1.3.13
 * New generation interfaces for web3 progressive applications
 * https://github.com/roman-rr/cupertino-pane/
 *
 * Copyright 2019-2022 Roman Antonov (roman-rr)
 *
 * Released under the MIT License
 *
 * Released on: September 13, 2022
 */

function __awaiter(t,e,s,i){return new(s||(s=Promise))((function(n,r){function o(t){try{h(i.next(t))}catch(t){r(t)}}function a(t){try{h(i.throw(t))}catch(t){r(t)}}function h(t){var e;t.done?n(t.value):(e=t.value,e instanceof s?e:new s((function(t){t(e)}))).then(o,a)}h((i=i.apply(t,e||[])).next())}))}class Support{static get touch(){return window.Modernizr&&!0===window.Modernizr.touch||!!(window.navigator.maxTouchPoints>0||"ontouchstart"in window||window.DocumentTouch&&document instanceof window.DocumentTouch)}static get observer(){return"MutationObserver"in window||"WebkitMutationObserver"in window}static get backdropFilter(){return CSS.supports("backdrop-filter","blur(0px)")||CSS.supports("-webkit-backdrop-filter","blur(0px)")}static get passiveListener(){let t=!1;try{const e=Object.defineProperty({},"passive",{get(){t=!0}});window.addEventListener("testPassiveListener",null,e)}catch(t){}return t}static get gestures(){return"ongesturestart"in window}}class Device{constructor(){this.ios=!1,this.android=!1,this.androidChrome=!1,this.desktop=!1,this.iphone=!1,this.ipod=!1,this.ipad=!1,this.edge=!1,this.ie=!1,this.firefox=!1,this.macos=!1,this.windows=!1,this.cordova=!(!window.cordova&&!window.phonegap),this.phonegap=!(!window.cordova&&!window.phonegap),this.electron=!1,this.ionic=!!document.querySelector("ion-app");const t=window.navigator.platform,e=window.navigator.userAgent,s=window.screen.width,i=window.screen.height;let n=e.match(/(Android);?[\s\/]+([\d.]+)?/),r=e.match(/(iPad).*OS\s([\d_]+)/),o=e.match(/(iPod)(.*OS\s([\d_]+))?/),a=!this.ipad&&e.match(/(iPhone\sOS|iOS)\s([\d_]+)/),h=e.indexOf("MSIE ")>=0||e.indexOf("Trident/")>=0,l=e.indexOf("Edge/")>=0,c=e.indexOf("Gecko/")>=0&&e.indexOf("Firefox/")>=0,p="Win32"===t,d=e.toLowerCase().indexOf("electron")>=0,u="MacIntel"===t;!r&&u&&Support.touch&&(1024===s&&1366===i||834===s&&1194===i||834===s&&1112===i||768===s&&1024===i)&&(r=e.match(/(Version)\/([\d.]+)/),u=!1),this.ie=h,this.edge=l,this.firefox=c,n&&!p&&(this.os="android",this.osVersion=n[2],this.android=!0,this.androidChrome=e.toLowerCase().indexOf("chrome")>=0),(r||a||o)&&(this.os="ios",this.ios=!0),a&&!o&&(this.osVersion=a[2].replace(/_/g,"."),this.iphone=!0),r&&(this.osVersion=r[2].replace(/_/g,"."),this.ipad=!0),o&&(this.osVersion=o[3]?o[3].replace(/_/g,"."):null,this.ipod=!0),this.ios&&this.osVersion&&e.indexOf("Version/")>=0&&"10"===this.osVersion.split(".")[0]&&(this.osVersion=e.toLowerCase().split("version/")[1].split(" ")[0]),this.webView=!(!(a||r||o)||!e.match(/.*AppleWebKit(?!.*Safari)/i)&&!window.navigator.standalone)||window.matchMedia&&window.matchMedia("(display-mode: standalone)").matches,this.webview=this.webView,this.standalone=this.webView,this.desktop=!(this.ios||this.android)||d,this.desktop&&(this.electron=d,this.macos=u,this.windows=p,this.macos&&(this.os="macos"),this.windows&&(this.os="windows")),this.pixelRatio=window.devicePixelRatio||1}}class Events{constructor(t,e,s,i,n){this.instance=t,this.settings=e,this.device=s,this.breakpoints=i,this.transitions=n,this.allowClick=!0,this.disableDragAngle=!1,this.mouseDown=!1,this.contentScrollTop=0,this.steps=[],this.isScrolling=!1,this.keyboardVisible=!1,this.inputBluredbyMove=!1,this.inputBottomOffset=0,this.previousInputBottomOffset=0,this.prevNewHeight=0,this.touchStartCb=t=>this.touchStart(t),this.touchMoveCb=t=>this.touchMove(t),this.touchEndCb=t=>this.touchEnd(t),this.onScrollCb=t=>this.onScroll(t),this.onClickCb=t=>this.onClick(t),this.onKeyboardShowCb=t=>this.onKeyboardShow(t),this.onKeyboardWillHideCb=t=>this.onKeyboardWillHide(t),this.onWindowResizeCb=t=>this.onWindowResize(t),this.touchEvents=this.getTouchEvents(),this.swipeNextSensivity=window.hasOwnProperty("cordova")?this.settings.fastSwipeSensivity+2:this.settings.fastSwipeSensivity}getTouchEvents(){const t=["touchstart","touchmove","touchend","touchcancel"];let e=["mousedown","mousemove","mouseup","mouseleave"];const s={start:t[0],move:t[1],end:t[2],cancel:t[3]},i={start:e[0],move:e[1],end:e[2],cancel:e[3]};return Support.touch||!this.settings.simulateTouch?s:i}attachAllEvents(){if(this.settings.dragBy?this.settings.dragBy.forEach((t=>{const e=document.querySelector(t);e&&this.eventListeners("addEventListener",e)})):this.eventListeners("addEventListener",this.instance.paneEl),this.settings.topperOverflow&&this.instance.overflowEl.addEventListener("scroll",this.onScrollCb),this.settings.handleKeyboard&&this.device.cordova&&(window.addEventListener("keyboardWillShow",this.onKeyboardShowCb),window.addEventListener("keyboardWillHide",this.onKeyboardWillHideCb)),this.device.ionic&&this.device.android){document.querySelectorAll(".ion-page").forEach((t=>{t.addEventListener("scroll",(e=>{t.scrollTop&&t.scrollTo({top:0})}))}))}window.addEventListener("resize",this.onWindowResizeCb)}detachAllEvents(){this.settings.dragBy?this.settings.dragBy.forEach((t=>{const e=document.querySelector(t);e&&this.eventListeners("removeEventListener",e)})):this.eventListeners("removeEventListener",this.instance.paneEl),this.settings.topperOverflow&&this.instance.overflowEl.removeEventListener("scroll",this.onScrollCb),this.settings.handleKeyboard&&this.device.cordova&&(window.removeEventListener("keyboardWillShow",this.onKeyboardShowCb),window.removeEventListener("keyboardWillHide",this.onKeyboardWillHideCb)),window.removeEventListener("resize",this.onWindowResizeCb)}resetEvents(){this.detachAllEvents(),this.attachAllEvents()}eventListeners(t,e){if(Support.touch){const s=!("touchstart"!==this.touchEvents.start||!Support.passiveListener||!this.settings.passiveListeners)&&{passive:!0,capture:!1};e[t](this.touchEvents.start,this.touchStartCb,s),e[t](this.touchEvents.move,this.touchMoveCb,!!Support.passiveListener&&{passive:!1,capture:!1}),e[t](this.touchEvents.end,this.touchEndCb,s),e[t](this.touchEvents.cancel,this.touchEndCb,s)}else e[t](this.touchEvents.start,this.touchStartCb,!1),e[t](this.touchEvents.move,this.touchMoveCb,!1),e[t](this.touchEvents.end,this.touchEndCb,!1),e[t](this.touchEvents.cancel,this.touchEndCb,!1);this.settings.preventClicks&&e[t]("click",this.onClickCb,!0)}touchStart(t){if(this.instance.emit("onDragStart",t),this.allowClick=!0,this.instance.disableDragEvents)return;this.disableDragAngle=!1,this.isScrolling=!1,this.instance.preventedDismiss=!1;const{clientY:e,clientX:s}=this.getEventClientYX(t,"touchstart");this.startY=e,this.startX=s,"mousedown"===t.type&&(this.mouseDown=!0),this.contentScrollTop&&this.willScrolled()&&(this.startY+=this.contentScrollTop),this.steps.push({posY:this.startY,posX:this.startX,time:Date.now()})}touchMove(t){var e;const{clientY:s,clientX:i,velocityY:n}=this.getEventClientYX(t,"touchmove");if("mousemove"===t.type&&!this.mouseDown)return;if(this.steps.length||this.steps.push({posY:s,posX:i,time:Date.now()}),t.delta=(null===(e=this.steps[0])||void 0===e?void 0:e.posY)-s,this.allowClick=!1,this.isFormElement(t.target)&&this.isElementScrollable(t.target))return;if(this.instance.disableDragEvents)return void(this.steps=[]);if(this.disableDragAngle)return;if(this.instance.preventedDismiss)return;this.settings.touchMoveStopPropagation&&t.stopPropagation();const r=s-this.steps[this.steps.length-1].posY,o=i-this.steps[this.steps.length-1].posX;if(!Math.abs(r)&&!Math.abs(o))return;this.instance.emit("onDrag",t),this.instance.setGrabCursor(!0,!0);let a=this.instance.getPanelTransformY()+r,h=this.instance.getPanelTransformX()+o;if(this.steps.length<2){n<1&&(a=this.instance.getPanelTransformY()+r*n);let t=new WebKitCSSMatrix(window.getComputedStyle(this.instance.paneEl).transform).m42-this.instance.getPanelTransformY();Math.abs(t)&&(a+=t)}if(this.steps.length>2&&this.isFormElement(document.activeElement)&&!this.isFormElement(t.target)&&(document.activeElement.blur(),this.inputBluredbyMove=!0),this.settings.touchAngle&&!this.isScrolling){let t;const e=i-this.startX,n=s-this.startY;if(t=180*Math.atan2(Math.abs(n),Math.abs(e))/Math.PI,e*e+n*n>=25&&90-t>this.settings.touchAngle&&1===this.steps.length)return void(this.disableDragAngle=!0)}if("auto"===this.instance.overflowEl.style.overflowY&&this.scrollPreventDrag(t))return;let l=this.handleTopperLowerPositions({clientX:i,clientY:s,newVal:a,diffY:r});if(isNaN(l)||(a=l),this.instance.getPanelTransformY()!==a||this.instance.getPanelTransformX()!==h){if(!this.instance.preventedDismiss&&this.instance.preventDismissEvent&&this.settings.bottomClose){let t=(-this.breakpoints.topper+this.breakpoints.topper-this.instance.getPanelTransformY())/this.breakpoints.topper/-8;if(a=this.instance.getPanelTransformY()+r*(.5-t),-1*(s-220-this.instance.screen_height)<=this.instance.screen_height-this.breakpoints.bottomer)return this.instance.preventedDismiss=!0,this.instance.emit("onWillDismiss",{prevented:!0}),void this.instance.moveToBreak(this.breakpoints.prevBreakpoint)}this.instance.checkOpacityAttr(a),this.instance.checkOverflowAttr(a),this.transitions.doTransition({type:"move",translateY:a,translateX:h}),this.steps.push({posY:s,posX:i,time:Date.now()})}}touchEnd(t){var e,s;if(this.instance.disableDragEvents)return;if("mouseleave"===t.type&&!this.mouseDown)return;"mouseup"!==t.type&&"mouseleave"!==t.type||(this.mouseDown=!1);let i,n=this.breakpoints.getClosestBreakY();this.fastSwipeNext("Y")&&(n=this.instance.swipeNextPoint((null===(e=this.steps[this.steps.length-1])||void 0===e?void 0:e.posY)-(null===(s=this.steps[this.steps.length-2])||void 0===s?void 0:s.posY),this.swipeNextSensivity,n),i=this.settings.fastSwipeClose&&this.breakpoints.currentBreakpoint<n);let r=!1;this.isFormElement(document.activeElement)&&!this.isFormElement(t.target)&&2===this.steps.length&&(r=!0),this.instance.emit("onDragEnd",t),this.steps=[],delete this.startPointOverTop,this.allowClick||r||(i?this.instance.destroy({animate:!0}):(this.instance.checkOpacityAttr(n),this.instance.checkOverflowAttr(n),this.instance.setGrabCursor(!0,!1),this.settings.bottomClose&&n===this.breakpoints.breaks.bottom?this.instance.destroy({animate:!0}):(this.instance.getPanelTransformY()===n&&this.instance.emit("onTransitionEnd",{target:this.instance.paneEl}),this.breakpoints.currentBreakpoint=n,this.transitions.doTransition({type:"end",translateY:n}))))}onScroll(t){return __awaiter(this,void 0,void 0,(function*(){this.isScrolling=!0,this.contentScrollTop=t.target.scrollTop}))}onClick(t){if(this.allowClick){if(!this.device.cordova&&this.device.android&&this.isFormElement(t.target))this.onKeyboardShow({keyboardHeight:this.instance.screen_height-window.innerHeight});else if(this.settings.clickBottomOpen){if(this.isFormElement(document.activeElement))return;if(this.breakpoints.breaks.bottom===this.instance.getPanelTransformY()){let t;this.settings.breaks.top.enabled&&(t="top"),this.settings.breaks.middle.enabled&&(t="middle"),this.instance.moveToBreak(t)}}}else this.settings.preventClicks&&(t.preventDefault(),t.stopPropagation(),t.stopImmediatePropagation())}onKeyboardShow(t){return __awaiter(this,void 0,void 0,(function*(){if(!this.isPaneDescendant(document.activeElement))return;if(!this.isOnViewport())return;this.keyboardVisible=!0;const e=this.settings.breaks[this.breakpoints.prevBreakpoint].height,s=document.activeElement,i=s.getBoundingClientRect().bottom,n=this.instance.screen_height-i-this.inputBottomOffset,r=this.device.cordova&&this.device.android?150:100;let o=0,a=e+(t.keyboardHeight-n);if(this.prevNewHeight&&(o=this.previousInputBottomOffset-i,a=this.prevNewHeight),!s.isEqualNode(this.prevFocusedElement)&&t.keyboardHeight>n){this.prevNewHeight=a-o,this.prevFocusedElement=document.activeElement,yield this.instance.moveToHeight(a-o+r);const t=s.getBoundingClientRect().bottom;this.previousInputBottomOffset=t,this.inputBottomOffset||(this.inputBottomOffset=i-t)}}))}onKeyboardWillHide(t){this.isOnViewport()&&(this.keyboardVisible=!1,this.inputBottomOffset=0,this.previousInputBottomOffset=0,this.prevNewHeight=0,delete this.prevFocusedElement,this.inputBluredbyMove?this.inputBluredbyMove=!1:this.instance.isHidden()||this.instance.getPanelTransformY()!==this.breakpoints.breaks[this.breakpoints.prevBreakpoint]&&this.instance.moveToBreak(this.breakpoints.prevBreakpoint))}onWindowResize(t){return __awaiter(this,void 0,void 0,(function*(){if(this.isKeyboardEvent()){if(this.device.cordova||this.device.ios)return;this.isFormElement(document.activeElement)?this.onKeyboardShow({keyboardHeight:this.instance.screen_height-window.innerHeight}):this.onKeyboardWillHide({})}else yield new Promise((t=>setTimeout((()=>t(!0)),150))),this.instance.updateScreenHeights(),this.breakpoints.buildBreakpoints(JSON.parse(this.breakpoints.lockedBreakpoints))}))}fastSwipeNext(t){var e,s;const i=(null===(e=this.steps[this.steps.length-1])||void 0===e?void 0:e["pos"+t])-(null===(s=this.steps[this.steps.length-2])||void 0===s?void 0:s["pos"+t]);return Math.abs(i)>=this.swipeNextSensivity}isKeyboardEvent(){return!!this.isFormElement(document.activeElement)||!(this.isFormElement(document.activeElement)||!this.keyboardVisible)&&(this.keyboardVisible=!1,!0)}handleTopperLowerPositions(t){if(!this.settings.upperThanTop&&t.newVal<=this.breakpoints.topper)return this.breakpoints.topper;if(this.settings.upperThanTop&&(t.newVal<=this.breakpoints.topper||this.startPointOverTop)){this.startPointOverTop||(this.startPointOverTop=t.clientY),this.startPointOverTop<t.clientY&&delete this.startPointOverTop;const e=this.instance.screen_height-this.instance.screenHeightOffset,s=(e-this.instance.getPanelTransformY())/(e-this.breakpoints.topper)/8;return this.instance.getPanelTransformY()+t.diffY*s}return!this.settings.lowerThanBottom&&t.newVal>=this.breakpoints.bottomer?this.breakpoints.bottomer:void 0}getEventClientYX(t,e){var s,i;const n=t.type===e&&t.targetTouches&&(t.targetTouches[0]||t.changedTouches[0]),r=t.type===e?n.clientY:t.clientY,o=t.type===e?n.clientX:t.clientX,a=Date.now()-((null===(s=this.steps[this.steps.length-1])||void 0===s?void 0:s.time)||0);return{clientY:r,clientX:o,velocityY:Math.abs(r-((null===(i=this.steps[this.steps.length-1])||void 0===i?void 0:i.posY)||0))/a}}scrollPreventDrag(t){let e=!1;return this.contentScrollTop>0&&(e=!0),e}willScrolled(){return!(!this.isElementScrollable(this.instance.overflowEl)||"hidden"===this.instance.overflowEl.style.overflow)}isPaneDescendant(t){if(!t)return!1;let e=t.parentNode;for(;null!=e;){if(e==this.instance.paneEl)return!0;e=e.parentNode}return!1}isFormElement(t){return!!(t&&t.tagName&&["input","select","option","textarea","button","label"].includes(t.tagName.toLowerCase()))}isElementScrollable(t){return t.scrollHeight>t.clientHeight}isOnViewport(){return!this.instance.paneEl||0!==this.instance.paneEl.offsetWidth||0!==this.instance.paneEl.offsetHeight}}class Settings{constructor(){this.instance={initialBreak:"middle",horizontal:!1,horizontalOffset:null,inverse:!1,parentElement:null,followerElement:null,cssClass:null,fitHeight:!1,maxFitHeight:null,fitScreenHeight:!0,backdrop:!1,backdropOpacity:.4,animationType:"ease",animationDuration:300,dragBy:null,bottomOffset:0,bottomClose:!1,fastSwipeClose:!1,fastSwipeSensivity:3,freeMode:!1,buttonDestroy:!0,topperOverflow:!0,topperOverflowOffset:0,lowerThanBottom:!0,upperThanTop:!1,showDraggable:!0,draggableOver:!1,clickBottomOpen:!0,preventClicks:!0,handleKeyboard:!0,simulateTouch:!0,passiveListeners:!0,touchMoveStopPropagation:!1,touchAngle:45,breaks:{},zStack:null,events:null,modules:null}}}class Breakpoints{constructor(t,e){this.instance=t,this.settings=e,this.breaks={},this.brs=[],this.beforeBuildBreakpoints=()=>{},this.defaultBreaksConf={top:{enabled:!0,height:window.innerHeight-47.25},middle:{enabled:!0,height:300},bottom:{enabled:!0,height:100}}}buildBreakpoints(t,e=0,s=!0){var i,n;return __awaiter(this,void 0,void 0,(function*(){if(this.breaks={},this.conf=t,this.settings.bottomOffset=e||this.settings.bottomOffset,yield this.beforeBuildBreakpoints(),["top","middle","bottom"].forEach((t=>{var e;this.settings.breaks[t]||(this.settings.breaks[t]=this.defaultBreaksConf[t]),this.conf&&this.conf[t]&&(this.settings.breaks[t]=this.conf[t]),this.instance.emit("beforeBreakHeightApplied",{break:t}),(null===(e=this.settings.breaks[t])||void 0===e?void 0:e.enabled)&&(this.breaks[t]=this.breaks[t]||this.instance.screenHeightOffset,this.breaks[t]-=this.settings.bottomOffset,this.breaks[t]-=this.settings.breaks[t].height)})),this.lockedBreakpoints||(this.lockedBreakpoints=JSON.stringify(this.settings.breaks)),this.instance.isPanePresented()||this.settings.breaks[this.settings.initialBreak].enabled||console.warn("Cupertino Pane: Please set initialBreak for enabled breakpoint"),this.settings.breaks.middle.height>=this.settings.breaks.top.height&&console.warn("Cupertino Pane: Please set middle height lower than top height"),this.settings.breaks.middle.height<=this.settings.breaks.bottom.height&&console.warn("Cupertino Pane: Please set bottom height lower than middle height"),this.brs=[],["top","middle","bottom"].forEach((t=>{this.settings.breaks[t].enabled&&this.brs.push(this.breaks[t])})),this.topper=this.brs.reduce(((t,e)=>e<t?e:t)),this.bottomer=this.brs.reduce(((t,e)=>Math.abs(e)>Math.abs(t)?e:t)),this.instance.isPanePresented()||(this.currentBreakpoint=this.breaks[this.settings.initialBreak]),this.instance.isPanePresented()){if((null===(i=this.settings.breaks[this.prevBreakpoint])||void 0===i?void 0:i.enabled)&&(this.instance.isHidden()||this.instance.moveToBreak(this.prevBreakpoint,s?"breakpoint":"move")),!(null===(n=this.settings.breaks[this.prevBreakpoint])||void 0===n?void 0:n.enabled)&&!this.instance.isHidden()){let t=this.instance.swipeNextPoint(1,1,this.getClosestBreakY());const e=Object.entries(this.breaks).find((e=>e[1]===t));this.instance.moveToBreak(e[0])}this.instance.paneEl.style.height=`${this.instance.getPaneHeight()}px`,this.instance.scrollElementInit(),this.instance.checkOpacityAttr(this.currentBreakpoint),this.instance.checkOverflowAttr(this.currentBreakpoint)}this.instance.emit("buildBreakpointsCompleted")}))}getCurrentBreakName(){return this.breaks.top===this.currentBreakpoint?"top":this.breaks.middle===this.currentBreakpoint?"middle":this.breaks.bottom===this.currentBreakpoint?"bottom":null}getClosestBreakY(){return this.brs.reduce(((t,e)=>Math.abs(e-this.instance.getPanelTransformY())<Math.abs(t-this.instance.getPanelTransformY())?e:t))}}var CupertinoTransition;!function(t){t.Present="present",t.Destroy="destroy",t.Move="move",t.Breakpoint="breakpoint",t.Hide="hide",t.TouchEnd="end"}(CupertinoTransition||(CupertinoTransition={}));class Transitions{constructor(t,e,s){this.instance=t,this.settings=e,this.breakpoints=s,this.isPaneHidden=!1}doTransition(t={}){return new Promise((e=>__awaiter(this,void 0,void 0,(function*(){var s,i;if(t.type===CupertinoTransition.Move)return this.instance.emit("onMoveTransitionStart",{translateY:t.translateY}),this.instance.paneEl.style.transition="all 0ms linear 0ms",this.setPaneElTransform(t),e(!0);const n=()=>(t.type===CupertinoTransition.Destroy&&this.instance.destroyResets(),this.instance.paneEl.style.transition="initial",t.type===CupertinoTransition.Hide&&(this.isPaneHidden=!0),t.type!==CupertinoTransition.Breakpoint&&t.type!==CupertinoTransition.TouchEnd||(this.isPaneHidden=!1),this.instance.emit("onTransitionEnd",{type:t.type,target:document.body.contains(this.instance.paneEl)?this.instance.paneEl:null}),this.instance.paneEl.removeEventListener("transitionend",n),e(!0));if(t.type===CupertinoTransition.Breakpoint||t.type===CupertinoTransition.TouchEnd||t.type===CupertinoTransition.Present||t.type===CupertinoTransition.Hide||t.type===CupertinoTransition.Destroy){let r=(null===(s=t.conf)||void 0===s?void 0:s.transition)||{};if(t.type===CupertinoTransition.TouchEnd&&this.settings.freeMode)return e(!0);const o=Object.entries(this.breakpoints.breaks).find((e=>e[1]===t.translateY));let a=o&&(null===(i=this.settings.breaks[o[0]])||void 0===i?void 0:i.bounce),h=this.buildTransitionValue(a,r.duration);this.instance.paneEl.style.setProperty("transition",h),this.instance.emit("onTransitionStart",{type:t.type,translateY:{new:t.translateY},transition:this.instance.paneEl.style.transition}),this.setPaneElTransform(t),Object.assign(this.instance.paneEl.style,r.to);let l=Object.entries(this.breakpoints.breaks).find((e=>e[1]===t.translateY));l&&(this.breakpoints.prevBreakpoint=l[0]),this.instance.paneEl.addEventListener("transitionend",n)}}))))}setPaneElTransform(t){this.instance.paneEl.style.transform=`translateY(${t.translateY}px) translateZ(0px)`}buildTransitionValue(t,e){return t?"all 300ms cubic-bezier(.155,1.105,.295,1.12)":`all ${e||this.settings.animationDuration}ms ${this.settings.animationType}`}}function on(t,e,s){if(!this.eventsListeners)return;if("function"!=typeof e)return;const i=s?"unshift":"push";t.split(" ").forEach((t=>{this.eventsListeners[t]||(this.eventsListeners[t]=[]),this.eventsListeners[t][i](e)}))}function emit(...t){if(!this.eventsListeners)return;let e=t[0],s=t.slice(1,t.length);(Array.isArray(e)?e:e.split(" ")).forEach((t=>{var e;(null===(e=this.eventsListeners)||void 0===e?void 0:e[t])&&this.eventsListeners[t].forEach((t=>t.apply(this,s)))}))}class ZStackModule{constructor(t){this.instance=t,this.zStackDefaults={pushElements:null,minPushHeight:null,cardYOffset:0,cardZScale:.93,cardContrast:.85,stackZAngle:160},this.breakpoints=this.instance.breakpoints,this.settings=this.instance.settings,this.settings.zStack&&(this.instance.setZstackConfig=t=>__awaiter(this,void 0,void 0,(function*(){return this.setZstackConfig(t)})),this.instance.on("rendered",(()=>{this.setZstackConfig(this.settings.zStack),this.setPushMultiplicators()})),this.instance.on("beforePresentTransition",(t=>{t.animate||this.settings.zStack.pushElements.forEach((t=>this.pushTransition(document.querySelector(t),this.breakpoints.breaks[this.settings.initialBreak],"unset")))})),this.instance.on("onMoveTransitionStart",(()=>{this.settings.zStack.pushElements.forEach((t=>this.pushTransition(document.querySelector(t),this.instance.getPanelTransformY(),"all 0ms linear 0ms")))})),this.instance.on("onTransitionStart",(t=>{this.settings.zStack.pushElements.forEach((e=>this.pushTransition(document.querySelector(e),t.translateY.new,`all ${this.settings.animationDuration}ms ${this.settings.animationType} 0s`)))})))}setZstackConfig(t){this.settings.zStack=t?Object.assign(Object.assign({},this.zStackDefaults),t):null}pushTransition(t,e,s){let i=this.settings.zStack.pushElements;t.style.transition=s,e=this.instance.screenHeightOffset-e;const n=this.settings.zStack.minPushHeight?this.settings.zStack.minPushHeight:this.instance.screenHeightOffset-this.breakpoints.bottomer,r=this.instance.screenHeightOffset-this.breakpoints.topper;let o=this.getPushMulitplicator(t),a=Math.pow(this.settings.zStack.cardZScale,o),h=Math.pow(this.settings.zStack.cardZScale,o-1),l=6+this.settings.zStack.cardYOffset,c=l*o*-1,p=c+l,d=Math.pow(this.settings.zStack.cardContrast,o),u=Math.pow(this.settings.zStack.cardContrast,o-1);const g=(s,n,r,o)=>{let a=Math.pow(s,this.settings.zStack.stackZAngle/100);t.style.transform=`translateY(${n*(a/s)}px) scale(${s})`,t.style.borderRadius=`${o}px`,t.style.filter=`contrast(${r})`;let h=document.querySelector(i[i.length-1]);e||t.className!==h.className||this.clearPushMultiplicators()};if(e<=n)return void g(h,p,u,0);const b=(t,s)=>{let i=-1*(r*s-n*t);return i-=(t-s)*e,i/=n-r,i>s&&(i=s),i<t&&(i=t),i};g(b(a,h),b(c,p),b(d,u),-1*b(-10,0))}setPushMultiplicators(){this.settings.zStack.pushElements.forEach((t=>{let e=document.querySelector(t),s=this.getPushMulitplicator(e);s=s?s+1:1,e.style.setProperty("--push-multiplicator",`${s}`)}))}getPushMulitplicator(t){let e=t.style.getPropertyValue("--push-multiplicator");return parseInt(e)}clearPushMultiplicators(){for(let t=0;t<this.settings.zStack.pushElements.length;t++){let e=document.querySelector(this.settings.zStack.pushElements[t]),s=this.getPushMulitplicator(e);s-=1,s?e.style.setProperty("--push-multiplicator",`${s}`):e.style.removeProperty("--push-multiplicator")}}}class FollowerModule{constructor(t){this.instance=t,this.breakpoints=this.instance.breakpoints,this.transitions=this.instance.transitions,this.settings=this.instance.settings,this.settings.followerElement&&(this.instance.on("rendered",(()=>{var t;document.querySelector(this.settings.followerElement)?(this.followerEl=document.querySelector(this.settings.followerElement),this.followerEl.style.willChange="transform, border-radius",this.followerEl.style.transform="translateY(0px) translateZ(0px)",this.followerEl.style.transition=this.transitions.buildTransitionValue(null===(t=this.settings.breaks[this.instance.currentBreak()])||void 0===t?void 0:t.bounce)):console.warn("Cupertino Pane: wrong follower element selector specified",this.settings.followerElement)})),this.instance.on("onMoveTransitionStart",(t=>{this.followerEl.style.transition="all 0ms linear 0ms",this.followerEl.style.transform=`translateY(${t.translateY-this.breakpoints.breaks[this.settings.initialBreak]}px) translateZ(0px)`})),this.instance.on("onMoveTransitionStart",(t=>{this.followerEl.style.transition="initial"})),this.instance.on("onTransitionStart",(t=>{this.followerEl.style.transition=t.transition,this.followerEl.style.transform=`translateY(${t.translateY.new-this.breakpoints.breaks[this.settings.initialBreak]}px) translateZ(0px)`})))}}class BackdropModule{constructor(t){this.instance=t,this.touchMoveBackdropCb=t=>this.touchMoveBackdrop(t),this.settings=this.instance.settings,this.events=this.instance.events,this.settings.backdrop&&(this.instance.backdrop=t=>this.backdrop(t),this.instance.on("rendered",(()=>{this.instance.addStyle("\n        .cupertino-pane-wrapper .backdrop {\n          overflow: hidden;\n          position: fixed;\n          width: 100%;\n          bottom: 0;\n          right: 0;\n          left: 0;\n          top: 0;\n          display: none;\n          z-index: 10;\n        }\n      "),this.settings.backdrop&&this.renderBackdrop()})),this.instance.on("beforePresentTransition",(t=>{t.animate||(this.backdropEl.style.display="block")})),this.instance.on("onTransitionStart",(t=>{this.settings.backdrop&&(this.instance.isHidden()||t.type===CupertinoTransition.Hide||t.type===CupertinoTransition.Destroy||t.type===CupertinoTransition.Present)&&(this.backdropEl.style.backgroundColor="rgba(0,0,0,.0)",this.backdropEl.style.transition=`all ${this.settings.animationDuration}ms ${this.settings.animationType} 0s`,t.type!==CupertinoTransition.Hide&&t.type!==CupertinoTransition.Destroy&&(this.backdropEl.style.display="block",setTimeout((()=>{this.backdropEl.style.backgroundColor=`rgba(0,0,0, ${this.settings.backdropOpacity})`}),50)))})),this.instance.on("onTransitionEnd",(t=>{this.backdropEl&&(t.type!==CupertinoTransition.Destroy&&t.type!==CupertinoTransition.Hide||(this.backdropEl.style.transition="initial",this.backdropEl.style.display="none"))})),Support.touch&&(this.instance.on("onDidPresent",(()=>{var t;null===(t=this.backdropEl)||void 0===t||t.addEventListener(this.events.touchEvents.move,this.touchMoveBackdropCb,!!Support.passiveListener&&{passive:!1,capture:!1})})),this.instance.on("onDidDismiss",(t=>{var e;null===(e=this.backdropEl)||void 0===e||e.removeEventListener(this.events.touchEvents.move,this.touchMoveBackdropCb)}))))}backdrop(t={show:!0}){var e,s;if(!this.instance.isPanePresented())return console.warn("Cupertino Pane: Present pane before call backdrop()"),null;this.isBackdropPresented()||(this.renderBackdrop(),Support.touch&&(null===(e=this.backdropEl)||void 0===e||e.removeEventListener(this.events.touchEvents.move,this.touchMoveBackdropCb),null===(s=this.backdropEl)||void 0===s||s.addEventListener(this.events.touchEvents.move,this.touchMoveBackdropCb,!!Support.passiveListener&&{passive:!1,capture:!1})));const i=()=>{this.backdropEl.style.transition="initial",this.backdropEl.style.display="none",this.backdropEl.removeEventListener("transitionend",i)};if(this.backdropEl.style.transition=`all ${this.settings.animationDuration}ms ${this.settings.animationType} 0s`,this.backdropEl.style.backgroundColor="rgba(0,0,0,.0)",t.show)this.backdropEl.style.display="block",setTimeout((()=>{this.backdropEl.style.backgroundColor=`rgba(0,0,0, ${this.settings.backdropOpacity})`}),50);else{if("none"===this.backdropEl.style.display)return;this.backdropEl.addEventListener("transitionend",i)}}renderBackdrop(){this.backdropEl=document.createElement("div"),this.backdropEl.classList.add("backdrop"),this.backdropEl.style.transition=`all ${this.settings.animationDuration}ms ${this.settings.animationType} 0s`,this.backdropEl.style.backgroundColor=`rgba(0,0,0, ${this.settings.backdropOpacity})`,this.instance.wrapperEl.appendChild(this.backdropEl),this.backdropEl.addEventListener("click",(()=>this.instance.emit("onBackdropTap")))}isBackdropPresented(){return!!document.querySelector(".cupertino-pane-wrapper .backdrop")}touchMoveBackdrop(t){this.settings.touchMoveStopPropagation&&t.stopPropagation()}}class FitHeightModule{constructor(t){this.instance=t,this.calcHeightInProcess=!1,this.breakpoints=this.instance.breakpoints,this.settings=this.instance.settings,this.settings.fitHeight&&(this.instance.calcFitHeight=t=>__awaiter(this,void 0,void 0,(function*(){return this.calcFitHeight(t)})),this.instance.on("DOMElementsReady",(()=>{this.instance.wrapperEl.classList.add("fit-height")})),this.instance.on("onWillPresent",(()=>{this.breakpoints.beforeBuildBreakpoints=()=>this.beforeBuildBreakpoints()})),this.instance.on("beforeBreakHeightApplied",(t=>{var e;this.settings.fitScreenHeight&&((null===(e=this.settings.breaks[t.break])||void 0===e?void 0:e.height)>this.instance.screen_height&&(this.settings.breaks[t.break].height=this.instance.screen_height-this.settings.bottomOffset),this.settings.breaks.top&&this.settings.breaks.middle&&this.settings.breaks.top.height-50<=this.settings.breaks.middle.height&&(this.settings.breaks.middle.enabled=!1,this.settings.initialBreak="top")),this.settings.fitHeight&&"top"===t.break&&(this.settings.breaks.top.height>this.instance.screen_height?(this.settings.breaks.top.height=this.instance.screen_height-2*this.settings.bottomOffset,this.settings.topperOverflow=!0):this.instance.overflowEl&&!this.settings.maxFitHeight&&(this.settings.topperOverflow=!1,this.instance.overflowEl.style.overflowY="hidden"))}),!0))}beforeBuildBreakpoints(){var t,e,s;return __awaiter(this,void 0,void 0,(function*(){this.settings.fitScreenHeight=!1,this.settings.initialBreak="top",this.settings.topperOverflow=!1;let i=yield this.getPaneFitHeight();this.settings.maxFitHeight&&i>this.settings.maxFitHeight&&(i=this.settings.maxFitHeight,this.settings.topperOverflow=!0),this.breakpoints.conf={top:{enabled:!0,height:i},middle:{enabled:!1}},this.breakpoints.conf.top.bounce=null===(e=null===(t=this.settings.breaks)||void 0===t?void 0:t.top)||void 0===e?void 0:e.bounce,this.breakpoints.conf.bottom=(null===(s=this.settings.breaks)||void 0===s?void 0:s.bottom)||{enabled:!0,height:0}}))}calcFitHeight(t=!0){return __awaiter(this,void 0,void 0,(function*(){return this.instance.wrapperEl&&this.instance.el?this.calcHeightInProcess?(console.warn("Cupertino Pane: calcFitHeight() already in process"),null):void(yield this.breakpoints.buildBreakpoints(this.breakpoints.lockedBreakpoints,null,t)):null}))}getPaneFitHeight(){return __awaiter(this,void 0,void 0,(function*(){this.calcHeightInProcess=!0;let t=this.instance.el.querySelectorAll("img");this.instance.el.style.height="unset",this.instance.rendered||(this.instance.el.style.visibility="hidden",this.instance.el.style.pointerEvents="none",this.instance.el.style.display="block",this.instance.wrapperEl.style.visibility="hidden",this.instance.wrapperEl.style.pointerEvents="none",this.instance.wrapperEl.style.display="block");let e=[];t.length&&(e=Array.from(t).map((t=>new Promise((e=>{if(t.height||t.complete&&t.naturalHeight)return e(!0);t.onload=()=>e(!0),t.onerror=()=>e(!0)}))))),yield Promise.all(e),yield new Promise((t=>requestAnimationFrame(t)));const s=t=>Math.round(t.getBoundingClientRect().height);let i=s(this.instance.el),n=this.contentElHeight-i,r=s(this.instance.paneEl);return Math.abs(n)&&(r-=n),this.contentElHeight=s(this.instance.el),s(this.instance.el)>this.instance.screen_height&&(this.contentElHeight=this.instance.screen_height),this.instance.rendered||(this.instance.el.style.visibility="unset",this.instance.el.style.pointerEvents="unset",this.instance.el.style.display="none",this.instance.wrapperEl.style.visibility="unset",this.instance.wrapperEl.style.pointerEvents="unset",this.instance.wrapperEl.style.display="none"),this.calcHeightInProcess=!1,r}))}}class InverseModule{constructor(t){this.instance=t,this.breakpoints=this.instance.breakpoints,this.settings=this.instance.settings,this.events=this.instance.events,this.settings.inverse&&(this.settings.buttonDestroy=!1,this.instance.getPaneHeight=()=>this.getPaneHeight(),this.instance.updateScreenHeights=()=>this.updateScreenHeights(),this.instance.setOverflowHeight=()=>this.setOverflowHeight(),this.instance.checkOpacityAttr=()=>{},this.instance.checkOverflowAttr=t=>this.checkOverflowAttr(t),this.instance.prepareBreaksSwipeNextPoint=()=>this.prepareBreaksSwipeNextPoint(),this.events.handleTopperLowerPositions=t=>this.handleTopperLowerPositions(t),this.events.scrollPreventDrag=t=>this.scrollPreventDrag(t),this.events.onScroll=()=>this.onScroll(),this.instance.on("DOMElementsReady",(()=>{this.instance.wrapperEl.classList.add("inverse")})),this.instance.on("rendered",(()=>{this.instance.addStyle("\n        .cupertino-pane-wrapper.inverse .pane {\n          border-radius: 0 0 20px 20px;\n          border-radius: 0 0\n                        var(--cupertino-pane-border-radius, 20px) \n                        var(--cupertino-pane-border-radius, 20px);\n        }\n        .cupertino-pane-wrapper.inverse:not(.fit-height) .pane {\n          padding-bottom: 15px; \n        }\n        .cupertino-pane-wrapper.inverse .draggable {\n          bottom: 0;\n          top: initial;\n        }\n        .cupertino-pane-wrapper.inverse .draggable.over {\n          bottom: -30px;\n          top: initial;\n        }\n        .cupertino-pane-wrapper.inverse .move {\n          margin-top: 15px;\n        }\n        .cupertino-pane-wrapper.inverse .draggable.over .move {\n          margin-top: -5px;\n        }\n      ")})),this.instance.on("beforeBreakHeightApplied",(t=>{var e;(null===(e=this.settings.breaks[t.break])||void 0===e?void 0:e.enabled)&&(this.breakpoints.breaks[t.break]=2*(this.settings.breaks[t.break].height+this.settings.bottomOffset))}),!1),this.instance.on("buildBreakpointsCompleted",(()=>{this.breakpoints.topper=this.breakpoints.bottomer,this.instance.paneEl.style.top=`-${this.breakpoints.bottomer-this.settings.bottomOffset}px`})))}getPaneHeight(){return this.breakpoints.bottomer-this.settings.bottomOffset}updateScreenHeights(){this.instance.screen_height=window.innerHeight,this.instance.screenHeightOffset=0}setOverflowHeight(){this.instance.overflowEl.style.height=this.getPaneHeight()-30-this.settings.topperOverflowOffset-this.instance.overflowEl.offsetTop+"px"}checkOverflowAttr(t){this.settings.topperOverflow&&this.instance.overflowEl&&(this.instance.overflowEl.style.overflowY=t>=this.breakpoints.bottomer?"auto":"hidden")}prepareBreaksSwipeNextPoint(){let t={},e={};return t.top=this.breakpoints.breaks.bottom,t.middle=this.breakpoints.breaks.middle,t.bottom=this.breakpoints.breaks.top,e.top=Object.assign({},this.settings.breaks.bottom),e.middle=Object.assign({},this.settings.breaks.middle),e.bottom=Object.assign({},this.settings.breaks.top),{brs:t,settingsBreaks:e}}handleTopperLowerPositions(t){if(this.settings.upperThanTop&&(t.newVal>=this.breakpoints.topper||this.events.startPointOverTop)){this.events.startPointOverTop||(this.events.startPointOverTop=t.clientY),this.events.startPointOverTop>t.clientY&&delete this.events.startPointOverTop;const e=this.instance.screen_height-this.instance.screenHeightOffset,s=(e-this.instance.getPanelTransformY())/(e-this.breakpoints.topper)/8;return this.instance.getPanelTransformY()+t.diffY*s}if(!this.settings.upperThanTop&&t.newVal>=this.breakpoints.topper)return this.breakpoints.topper}scrollPreventDrag(t){let e=!1;return this.events.willScrolled()&&this.isOverflowEl(t.target)&&(e=!0),e}isOverflowEl(t){if(!t)return!1;let e=t.parentNode;for(;null!=e;){if(e==this.instance.overflowEl)return!0;e=e.parentNode}return!1}onScroll(){return __awaiter(this,void 0,void 0,(function*(){this.events.isScrolling=!0}))}}class HorizontalModule{constructor(t){this.instance=t,this.settings=this.instance.settings,this.transitions=this.instance.transitions,this.events=this.instance.events,this.settings.horizontal&&(this.settings.touchAngle=null,this.transitions.setPaneElTransform=t=>this.setPaneElTransform(t),this.instance.on("onTransitionEnd",(t=>{"breakpoint"!==t.type&&"present"!==t.type||this.instance.getPanelTransformX()||this.calcHorizontalBreaks()})),this.instance.on("onDragEnd",(t=>{this.fastSwipeNext=this.events.fastSwipeNext("X")})))}calcHorizontalBreaks(){this.defaultRect={width:this.instance.paneEl.getBoundingClientRect().width,left:this.instance.paneEl.getBoundingClientRect().left,right:this.instance.paneEl.getBoundingClientRect().right},this.horizontalBreaks=[-this.defaultRect.left+this.settings.horizontalOffset,window.innerWidth-this.defaultRect.left-this.defaultRect.width-this.settings.horizontalOffset]}setPaneElTransform(t){let e=t.translateX;"end"===t.type&&(e=this.getClosestBreakX(),this.fastSwipeNext&&("left"===this.currentBreakpoint&&this.instance.getPanelTransformX()>this.horizontalBreaks[0]&&(e=this.horizontalBreaks[1]),"right"===this.currentBreakpoint&&this.instance.getPanelTransformX()<this.horizontalBreaks[1]&&(e=this.horizontalBreaks[0])),this.currentBreakpoint=e===this.horizontalBreaks[0]?"left":"right"),this.instance.paneEl.style.transform=`translateX(${e||0}px) translateY(${t.translateY}px) translateZ(0px)`}getClosestBreakX(){return this.horizontalBreaks.reduce(((t,e)=>Math.abs(e-this.instance.getPanelTransformX())<Math.abs(t-this.instance.getPanelTransformX())?e:t))}}const Modules={ZStackModule:ZStackModule,FollowerModule:FollowerModule,BackdropModule:BackdropModule,FitHeightModule:FitHeightModule,InverseModule:InverseModule,HorizontalModule:HorizontalModule};class CupertinoPane{constructor(t,e={}){if(this.selector=t,this.disableDragEvents=!1,this.preventDismissEvent=!1,this.preventedDismiss=!1,this.rendered=!1,this.settings=(new Settings).instance,this.device=new Device,this.modules={},this.eventsListeners={},this.on=on,this.emit=emit,this.swipeNextPoint=(t,e,s)=>{let{brs:i,settingsBreaks:n}=this.prepareBreaksSwipeNextPoint();if(this.breakpoints.currentBreakpoint===i.top){if(t>e){if(n.middle.enabled)return i.middle;if(n.bottom.enabled)return i.middle<s?s:i.bottom}return i.top}if(this.breakpoints.currentBreakpoint===i.middle)return t<-e&&n.top.enabled?i.top:t>e&&n.bottom.enabled?i.bottom:i.middle;if(this.breakpoints.currentBreakpoint===i.bottom){if(t<-e){if(n.middle.enabled)return i.middle>s?s:i.middle;if(n.top.enabled)return i.top}return i.bottom}return s},t instanceof HTMLElement?this.selector=t:this.selector=document.querySelector(t),!this.selector)return void console.warn("Cupertino Pane: wrong selector or DOM element specified",this.selector);if(this.isPanePresented())return void console.error("Cupertino Pane: specified selector or DOM element already in use",this.selector);this.el=this.selector,this.el.style.display="none",this.settings=Object.assign(Object.assign({},this.settings),e),this.settings.parentElement?this.settings.parentElement=document.querySelector(this.settings.parentElement):this.settings.parentElement=this.el.parentElement,this.settings.events&&Object.keys(this.settings.events).forEach((t=>this.on(t,this.settings.events[t]))),this.breakpoints=new Breakpoints(this,this.settings),this.transitions=new Transitions(this,this.settings,this.breakpoints),this.events=new Events(this,this.settings,this.device,this.breakpoints,this.transitions);let s=Object.keys(Modules).map((t=>Modules[t]));(this.settings.modules||s).forEach((t=>this.modules[this.getModuleRef(t.name)]=new t(this)))}drawBaseElements(){this.parentEl=this.settings.parentElement,this.wrapperEl=document.createElement("div"),this.wrapperEl.classList.add("cupertino-pane-wrapper"),this.settings.cssClass&&this.settings.cssClass.split(" ").filter((t=>!!t)).forEach((t=>this.wrapperEl.classList.add(t)));let t="";t+="\n      .cupertino-pane-wrapper {\n        display: none;\n        position: absolute;\n        top: 0;\n        left: 0;\n      }\n    ",this.paneEl=document.createElement("div"),this.paneEl.style.transform=`translateY(${this.screenHeightOffset}px) translateZ(0px)`,this.paneEl.classList.add("pane"),t+="\n      .cupertino-pane-wrapper .pane {\n        position: fixed;\n        z-index: 11;\n        width: 100%;\n        max-width: 500px;\n        left: 0px;\n        right: 0px;\n        margin-left: auto;\n        margin-right: auto;\n        background: var(--cupertino-pane-background, #ffffff);\n        color: var(--cupertino-pane-color, #333333);\n        box-shadow: var(--cupertino-pane-shadow, 0 4px 16px rgba(0,0,0,.12));\n        will-change: transform;\n        padding-top: 15px; \n        border-radius: var(--cupertino-pane-border-radius, 20px) \n                       var(--cupertino-pane-border-radius, 20px) \n                       0 0;\n        -webkit-user-select: none;\n      }\n      .cupertino-pane-wrapper .pane img {\n        -webkit-user-drag: none;\n      }\n    ",this.draggableEl=document.createElement("div"),this.draggableEl.classList.add("draggable"),this.settings.draggableOver&&this.draggableEl.classList.add("over"),t+="\n      .cupertino-pane-wrapper .draggable {\n        padding: 5px;\n        position: absolute;\n        left: 0;\n        right: 0;\n        margin-left: auto;\n        margin-right: auto;\n        height: 30px;\n        z-index: -1;\n        top: 0;\n        bottom: initial;\n      }\n      .cupertino-pane-wrapper .draggable.over {\n        top: -30px;\n        padding: 15px;\n      }\n    ",this.moveEl=document.createElement("div"),this.moveEl.classList.add("move"),t+=`\n      .cupertino-pane-wrapper .move {\n        margin: 0 auto;\n        height: 5px;\n        background: var(--cupertino-pane-move-background, #c0c0c0);\n        width: 36px;\n        border-radius: 4px;\n      }\n      .cupertino-pane-wrapper .draggable.over .move {\n        width: 70px; \n        background: var(--cupertino-pane-move-background, rgba(225, 225, 225, 0.6));\n        ${Support.backdropFilter?"\n          backdrop-filter: saturate(180%) blur(20px);\n          -webkit-backdrop-filter: saturate(180%) blur(20px);\n        ":""}\n      }\n    `,this.destroyButtonEl=document.createElement("div"),this.destroyButtonEl.classList.add("destroy-button"),t+="\n      .cupertino-pane-wrapper .destroy-button {\n        width: 26px;\n        height: 26px;\n        position: absolute;\n        background: var(--cupertino-pane-destroy-button-background, #ebebeb);\n        fill: var(--cupertino-pane-icon-close-color, #7a7a7e);\n        right: 20px;\n        z-index: 14;\n        border-radius: 100%;\n        top: 16px;\n      }\n    ",this.contentEl=this.el,this.contentEl.style.transition=`opacity ${this.settings.animationDuration}ms ${this.settings.animationType} 0s`,this.contentEl.style.overflowX="hidden",this.addStyle(t),this.parentEl.appendChild(this.wrapperEl),this.wrapperEl.appendChild(this.paneEl),this.paneEl.appendChild(this.contentEl),this.settings.showDraggable&&(this.paneEl.appendChild(this.draggableEl),this.draggableEl.appendChild(this.moveEl)),this.emit("DOMElementsReady")}present(t={animate:!1}){var e;return __awaiter(this,void 0,void 0,(function*(){if(this.el&&document.body.contains(this.el))if(this.isPanePresented()&&this.rendered)this.moveToBreak(this.settings.initialBreak);else{if(!this.isPanePresented()||this.rendered)return this.emit("onWillPresent"),this.updateScreenHeights(),this.drawBaseElements(),yield this.setBreakpoints(),this.paneEl.style.height=`${this.getPaneHeight()}px`,Object.assign(this.paneEl.style,null===(e=null==t?void 0:t.transition)||void 0===e?void 0:e.from),this.wrapperEl.style.display="block",yield new Promise((t=>setTimeout(t,100))),this.contentEl.style.display="block",this.wrapperEl.classList.add("rendered"),this.rendered=!0,this.scrollElementInit(),this.checkOverflowAttr(this.breakpoints.currentBreakpoint),this.emit("rendered"),this.settings.buttonDestroy&&(this.paneEl.appendChild(this.destroyButtonEl),this.destroyButtonEl.addEventListener("click",(t=>this.destroy({animate:!0,destroyButton:!0}))),this.destroyButtonEl.innerHTML='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">\n          <path d="M278.6 256l68.2-68.2c6.2-6.2 6.2-16.4 0-22.6-6.2-6.2-16.4-6.2-22.6 0L256 233.4l-68.2-68.2c-6.2-6.2-16.4-6.2-22.6 0-3.1 3.1-4.7 7.2-4.7 11.3 0 4.1 1.6 8.2 4.7 11.3l68.2 68.2-68.2 68.2c-3.1 3.1-4.7 7.2-4.7 11.3 0 4.1 1.6 8.2 4.7 11.3 6.2 6.2 16.4 6.2 22.6 0l68.2-68.2 68.2 68.2c6.2 6.2 16.4 6.2 22.6 0 6.2-6.2 6.2-16.4 0-22.6L278.6 256z"/>\n        </svg>'),this.settings.bottomClose&&(this.settings.breaks.bottom.enabled=!0),this.settings.freeMode&&(this.settings.lowerThanBottom=!1),this.setGrabCursor(!0),this.checkOpacityAttr(this.breakpoints.currentBreakpoint),this.device.android&&(document.body.style.overscrollBehaviorY="none"),this.emit("beforePresentTransition",{animate:t.animate}),t.animate?yield this.transitions.doTransition({type:"present",conf:t,translateY:this.breakpoints.breaks[this.settings.initialBreak]}):(this.breakpoints.prevBreakpoint=this.settings.initialBreak,this.paneEl.style.transform=`translateY(${this.breakpoints.breaks[this.settings.initialBreak]}px) translateZ(0px)`),this.events.attachAllEvents(),this.emit("onDidPresent"),this;console.warn("Cupertino Pane: specified selector or DOM element already in use",this.selector)}else console.warn("Cupertino Pane: specified DOM element must be attached to the DOM")}))}getPaneHeight(){return this.screen_height-this.breakpoints.topper-this.settings.bottomOffset}updateScreenHeights(){this.screen_height=window.innerHeight,this.screenHeightOffset=window.innerHeight}scrollElementInit(){let t=this.el.querySelectorAll("[overflow-y]");!t.length||t.length>1?this.overflowEl=this.contentEl:(this.overflowEl=t[0],this.overflowEl.style.overflowX="hidden"),this.overflowEl.style.overscrollBehavior="none",this.settings.topperOverflow&&(this.settings.upperThanTop&&console.warn('Cupertino Pane: "upperThanTop" allowed for disabled "topperOverflow"'),this.setOverflowHeight())}setOverflowHeight(t=0){this.overflowEl.style.height=this.getPaneHeight()-this.settings.topperOverflowOffset-this.overflowEl.offsetTop-t+"px"}checkOpacityAttr(t){let e=this.el.querySelectorAll("[hide-on-bottom]");e.length&&e.forEach((e=>{e.style.transition=`opacity ${this.settings.animationDuration}ms ${this.settings.animationType} 0s`,e.style.opacity=t>=this.breakpoints.breaks.bottom?"0":"1"}))}checkOverflowAttr(t){this.settings.topperOverflow&&this.overflowEl&&(this.overflowEl.style.overflowY=t<=this.breakpoints.topper?"auto":"hidden")}isPanePresented(){let t=Array.from(document.querySelectorAll(".cupertino-pane-wrapper.rendered"));return!!t.length&&!!t.find((t=>t.contains(this.selector)))}prepareBreaksSwipeNextPoint(){return{brs:Object.assign({},this.breakpoints.breaks),settingsBreaks:Object.assign({},this.settings.breaks)}}addStyle(t){if(t=t.replace(/\s\s+/g," "),document.querySelector("#cupertino-panes-internal")){document.querySelector("#cupertino-panes-internal").textContent+=t}else{const e=document.createElement("style");e.id="cupertino-panes-internal",e.textContent=t,document.head.prepend(e)}}getModuleRef(t){return(t.charAt(0).toLowerCase()+t.slice(1)).replace("Module","")}getPanelTransformY(){return parseFloat(/\.*translateY\((.*)px\)/i.exec(this.paneEl.style.transform)[1])}getPanelTransformX(){let t=/\.*translateX\((.*)px\)/i.exec(this.paneEl.style.transform);return t?parseFloat(t[1]):0}preventDismiss(t=!1){this.preventDismissEvent=t}setGrabCursor(t,e){this.device.desktop&&(this.paneEl.style.cursor=t?e?"grabbing":"grab":"")}disableDrag(){this.disableDragEvents=!0,this.setGrabCursor(!1)}enableDrag(){this.disableDragEvents=!1,this.setGrabCursor(!0)}setBreakpoints(t,e){return __awaiter(this,void 0,void 0,(function*(){!this.isPanePresented()||t?yield this.breakpoints.buildBreakpoints(t,e):console.warn("Cupertino Pane: Provide any breaks configuration")}))}moveToBreak(t,e="breakpoint"){return __awaiter(this,void 0,void 0,(function*(){return this.isPanePresented()?this.settings.breaks[t].enabled?(this.checkOpacityAttr(this.breakpoints.breaks[t]),this.checkOverflowAttr(this.breakpoints.breaks[t]),yield this.transitions.doTransition({type:e,translateY:this.breakpoints.breaks[t]}),this.breakpoints.currentBreakpoint=this.breakpoints.breaks[t],Promise.resolve(!0)):void console.warn("Cupertino Pane: %s breakpoint disabled",t):(console.warn("Cupertino Pane: Present pane before call moveToBreak()"),null)}))}moveToHeight(t){return __awaiter(this,void 0,void 0,(function*(){if(!this.isPanePresented())return console.warn("Cupertino Pane: Present pane before call moveToHeight()"),null;let e=this.screenHeightOffset?this.screen_height-t:t;this.checkOpacityAttr(e),yield this.transitions.doTransition({type:"breakpoint",translateY:e})}))}hide(){return __awaiter(this,void 0,void 0,(function*(){return this.isPanePresented()?this.isHidden()?(console.warn("Cupertino Pane: Pane already hidden"),null):void(yield this.transitions.doTransition({type:"hide",translateY:this.screenHeightOffset})):(console.warn("Cupertino Pane: Present pane before call hide()"),null)}))}isHidden(){return this.isPanePresented()?this.transitions.isPaneHidden:(console.warn("Cupertino Pane: Present pane before call isHidden()"),null)}currentBreak(){return this.isPanePresented()?this.breakpoints.getCurrentBreakName():(console.warn("Cupertino Pane: Present pane before call currentBreak()"),null)}destroy(t={animate:!1,destroyButton:!1}){return __awaiter(this,void 0,void 0,(function*(){if(!this.rendered)return console.warn("Cupertino Pane: Present pane before call destroy()"),null;this.preventDismissEvent?this.preventedDismiss||(this.emit("onWillDismiss",{prevented:!0}),this.moveToBreak(this.breakpoints.prevBreakpoint)):(this.emit("onWillDismiss"),t.animate?yield this.transitions.doTransition({type:"destroy",conf:t,translateY:this.screenHeightOffset,destroyButton:t.destroyButton}):this.destroyResets(),this.emit("onDidDismiss",{destroyButton:t.destroyButton}))}))}destroyResets(){this.parentEl.appendChild(this.contentEl),this.wrapperEl.remove(),this.events.detachAllEvents(),delete this.rendered,delete this.breakpoints.prevBreakpoint,this.contentEl.style.display="none"}}


/***/ }),

/***/ 55463:
/*!******************************************************************!*\
  !*** ./src/app/tadawul-home/home/home.component.scss?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = ":host {\n  background: #347478;\n}\n\n::ng-deep .ion-page {\n  background: #347378;\n}\n\nion-toolbar .profile-avatar {\n  width: 24px;\n  height: 24px;\n  -webkit-margin-start: 16px;\n          margin-inline-start: 16px;\n  border-radius: 50%;\n  border: 2px solid white;\n  vertical-align: middle !important;\n}\n\nion-toolbar .icon {\n  font-size: 20px !important;\n}\n\nion-toolbar .icon-link {\n  color: #99b9bc;\n}\n\nion-toolbar .icon-link .icon-alinma-symbol {\n  color: #FFFFFF;\n  font-size: 24px !important;\n}\n\nion-toolbar ion-title .icon-link {\n  margin: auto;\n}\n\nion-refresher {\n  --color: #FFFFFF;\n  --ion-text-color: #FFFFFF;\n  background: #347378;\n}\n\nion-refresher {\n  background: #347378;\n}\n\n.market-container {\n  background-color: #cddfe1;\n}\n\nbody.dark :host .market-container {\n  background-color: black;\n}\n\n.tadawulSegment {\n  margin-top: -25px;\n}\n\n.collabseableListScroll {\n  margin-top: -25px;\n  overflow-y: scroll;\n  height: 200px;\n}\n\n.home-scroll-view {\n  overflow-y: scroll;\n}\n\n.home-order-toolbar {\n  --background: #ffffff;\n}\n\nbody.dark :host .home-order-toolbar {\n  --background: #1e1e1e;\n}\n\n.home-title {\n  text-align: center;\n  color: #005157;\n}\n\nbody.dark :host .home-title {\n  color: #ffffff;\n}\n\n.portfolioShareText {\n  width: 81px;\n  height: 17px;\n  font-size: 13px;\n  font-weight: bold;\n  text-align: start;\n  color: var(--ion-color-primary-txt);\n  padding: 5px;\n}\n\nbody.dark :host .portfolioShareText {\n  color: #d2d2d2;\n}\n\nbody.dark :host .homecolor {\n  --background: black;\n}\n\nbody.dark :host ion-menu-button {\n  --color: #ffffff;\n}\n\n.star {\n  height: 20px !important;\n  width: 20px !important;\n  outline: none;\n}\n\n.no-data {\n  width: 100%;\n  height: 220px;\n  background-color: #005157;\n  background-image: url(/assets/icon/card-bg-shape.png);\n  background-repeat: no-repeat;\n  background-size: 120%;\n  background-position: center;\n  margin-top: 10px;\n  text-align: center;\n  padding-top: 15%;\n}\n\nbody.dark :host .star {\n  content: url(\"/assets/icon/dark-favourite.svg\");\n}\n\nbody.dark :host .portfolioShareIcon {\n  content: url(\"/assets/icon/local-portfolio-dark.svg\");\n}\n\nbody.dark :host .home-dark {\n  background-color: #000000;\n}\n\n.mutual-funds-segment-bar {\n  background: transparent;\n  border-radius: 0;\n  padding-left: 19%;\n  padding-right: 19%;\n}\n\n.mutual-funds-segment-bar ion-segment-button {\n  --border-radius: 0;\n  font-size: 11px;\n  --background-checked: #005157;\n  --color: #005157;\n}\n\n.mutual-funds-segment-bar ion-segment-button.segment-button-checked {\n  --color: white;\n  border: 1px solid #005157;\n  --indicator-color: transparent !important;\n}\n\n.mutual-funds-segment-bar ion-segment-button:not(.segment-button-checked) {\n  border: 1px solid #005157;\n}\n\nbody.dark :host .mutual-funds-segment-bar ion-segment-button:not(.segment-button-checked) {\n  border: 0px;\n}\n\nbody.dark :host .mutual-funds-segment-bar ion-segment-button {\n  --background: #4b4b4b;\n  --background-checked: #787878;\n  --background-focused: #787878;\n  --color: #a5a5a5;\n  --color-checked: white;\n}\n\n.bottom-sheet-header {\n  width: 50px;\n  height: 5px;\n  margin: 10px auto;\n  border-radius: 3px;\n  background-color: #e6eff0;\n}\n\nion-segment.portfolio-type {\n  --background: #0f5a61;\n  max-width: -webkit-max-content;\n  max-width: -moz-max-content;\n  max-width: max-content;\n  margin: 10px auto !important;\n}\n\nion-segment.portfolio-type ion-segment-button {\n  color: #99b9bc;\n  font-size: 10px;\n}\n\nion-segment.portfolio-type ion-segment-button.segment-button-checked {\n  color: white;\n}\n\n.homecolor {\n  --background: #347478 !important;\n}\n\nion-bottom-drawer {\n  border-radius: 10px 10px 0 0 !important;\n  transition: all 0.15s linear 0s !important;\n}\n\nion-bottom-drawer ion-content {\n  --background: #F4F8F8 !important;\n}\n\nion-bottom-drawer ion-content::part(background) {\n  border-radius: 10px 10px 0 0 !important;\n}\n\nion-bottom-drawer ion-content::part(scroll) {\n  -webkit-overflow-scrolling: inherit !important;\n  border-top-left-radius: 10px;\n  border-top-right-radius: 10px;\n}\n\nion-bottom-drawer .drawer-content {\n  background: #F4F8F8;\n  height: 100%;\n  border-radius: 10px !important;\n  overflow: auto;\n  display: flex;\n  flex-direction: column;\n}\n\nion-bottom-drawer .drawer-content .drawer-content-header {\n  position: fixed;\n  top: 0;\n  width: 100%;\n  z-index: 2;\n  background: #FFFFFF;\n  border-top-left-radius: 10px;\n  border-top-right-radius: 10px;\n}\n\nion-bottom-drawer .drawer-content .content {\n  display: flex;\n  margin-top: 110px;\n  padding-bottom: calc(75px + 0 + 0);\n  padding-bottom: calc(75px + var(--ion-safe-area-bottom, 0) + var(--ion-safe-area-top, 0));\n  flex-grow: 1;\n  flex-direction: column;\n}\n\nion-bottom-drawer .drawer-content .content ion-slides {\n  min-height: 100%;\n}\n\nion-bottom-drawer .drawer-content .content ion-slides ion-slide {\n  width: 100%;\n}\n\nion-bottom-drawer.scrollable {\n  touch-action: initial !important;\n  -webkit-user-drag: auto !important;\n}\n\nion-bottom-drawer.scrollable .drawer-content {\n  touch-action: initial !important;\n  -webkit-user-drag: auto !important;\n}\n\nion-segment.form-segment {\n  max-width: -webkit-max-content;\n  max-width: -moz-max-content;\n  max-width: max-content;\n  margin: 10px auto;\n}\n\nion-segment.form-segment ion-segment-button {\n  min-width: 100px;\n}\n\n.symbols-ion-list {\n  background: #F4F8F8;\n  width: 100%;\n}\n\ntadawul-symbol-card:last-child {\n  margin-bottom: 50px;\n}\n\nion-slides {\n  height: 100%;\n}\n\nion-slides,\nion-slide {\n  width: 100%;\n  display: inline-block !important;\n}\n\n.swiper-slide {\n  display: inline-block !important;\n}\n\n.app-toolbar-home {\n  display: flex;\n  box-sizing: border-box;\n  flex-direction: column;\n  width: 100%;\n  justify-content: space-between;\n  background: #005157;\n}\n\n.app-toolbar-row {\n  display: flex;\n  box-sizing: border-box;\n  padding: 6px 11px;\n  width: 100%;\n  flex-direction: row;\n  align-items: center;\n  white-space: nowrap;\n}\n\n.portfolio-number {\n  font-size: 16px;\n  font-weight: bold;\n  text-align: right;\n  color: #fff;\n}\n\n.font-15 {\n  font-size: 15px !important;\n}\n\n.portfolio-footer-value-green {\n  color: #2ebd85;\n  font-size: 12px;\n  display: block;\n  font-weight: bold;\n}\n\n.portfolio-footer-value-red {\n  color: #c43c35;\n  font-size: 12px;\n  display: block;\n  font-weight: bold;\n}\n\n.portfolio-last-row {\n  height: 55px;\n  padding: 0px 11px;\n  background: #005157;\n}\n\n.vertical-text {\n  display: flex;\n  flex-direction: column;\n}\n\n.portfolio-footer-text {\n  color: #cddcdd;\n  font-size: 11px;\n}\n\n.portfolio-footer-value {\n  color: #ffffff;\n  font-size: 14px;\n  display: block;\n  font-weight: bold;\n}\n\n.currency-font {\n  font-size: 11px !important;\n}\n\n.spacer {\n  flex: 1 1 auto !important;\n}\n\n.secondText {\n  font-size: 20px;\n  font-weight: bolder;\n  color: white;\n}\n\n.portfolio-brief-info {\n  background: #005157;\n  position: absolute;\n  top: 0;\n  left: 0;\n  z-index: -1;\n  opacity: 0;\n  width: 100%;\n}\n\n.portfolio-brief-info.android-header {\n  padding-top: 25px !important;\n}\n\n.portfolio-brief-info.show {\n  z-index: 11;\n  opacity: 1;\n}\n\n.portfolio-brief-info-header {\n  padding-top: 0;\n  padding-top: var(--ion-safe-area-top, 0);\n  --ion-grid-column-padding: 0;\n}\n\n.portfolio-brief-info-header .portfolio-name {\n  color: #FFFFFF;\n  font-size: 18px;\n  font-weight: bold;\n  -webkit-padding-start: 11px;\n          padding-inline-start: 11px;\n  display: flex;\n  align-items: center;\n}\n\n.portfolio-brief-info-header .portfolio-name .currency {\n  background: #347478;\n  border-radius: 3px;\n  padding: 2px 5px;\n  font-size: 9px;\n  -webkit-margin-start: 10px;\n          margin-inline-start: 10px;\n}\n\n.portfolio-brief-info-header .icon-link {\n  color: #99b9bc;\n  display: inline-flex;\n}\n\n.portfolio-brief-info-content {\n  border-top: 1px solid #22666d;\n  padding: 6px 11px;\n  --ion-grid-column-padding: 0;\n}\n\n.portfolio-brief-info-content .item-label {\n  color: #cddcdd;\n}\n\n.portfolio-brief-info-content .item-value {\n  color: #FFFFFF;\n}\n\n.margin-5px-horizontal {\n  margin: 0 5px;\n  color: #99b9bc;\n}\n\n.padding-start {\n  -webkit-padding-start: 11px;\n          padding-inline-start: 11px;\n}\n\nion-slides {\n  --bullet-background: #908c8c !important;\n  --bullet-background-active: #1e1e1e !important;\n}\n\nion-slides .swiper-pagination-bullet {\n  opacity: 1 !important;\n}\n\n.sliderContainer {\n  width: 100%;\n  padding-bottom: 30px;\n}\n\n[dir=rtl].swiper-wrapper {\n  justify-content: center !important;\n}\n\n[dir=ltr].swiper-wrapper {\n  justify-content: end !important;\n}\n\n.cupertino-pane-wrapper .pane {\n  border-radius: 10px 10px 0 0 !important;\n  padding-top: 0 !important;\n  overflow: hidden;\n}\n\n.cupertino-pane-wrapper .move {\n  width: 50px;\n  height: 5px;\n  margin: 5px auto;\n  border-radius: 3px;\n  background-color: #e6eff0;\n}\n\n.cupertino-pane-wrapper .draggable {\n  height: 25px;\n  z-index: 3;\n}\n\n.cupertino-pane-wrapper .bottom-drawer {\n  height: 100% !important;\n}\n\n.cupertino-pane-wrapper .bottom-drawer .drawer-header {\n  position: absolute;\n  width: 100%;\n  background: #FFFFFF;\n  z-index: 2;\n  padding-top: 15px;\n}\n\n.cupertino-pane-wrapper .bottom-drawer .drawer-content {\n  background: #F4F8F8;\n  flex-grow: 1;\n  padding-top: 102px;\n  min-height: 100%;\n  display: flex;\n  flex-direction: column;\n}\n\n.cupertino-pane-wrapper ion-slides {\n  min-height: 100%;\n  flex-grow: 1;\n}\n\n.cupertino-pane-wrapper app-empty-state img {\n  margin-top: 50px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxtQkFBQTtBQUNGOztBQVdBO0VBQ0UsbUJBQUE7QUFSRjs7QUF5QkU7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLDBCQUFBO1VBQUEseUJBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0VBQ0EsaUNBQUE7QUF0Qko7O0FBeUJFO0VBQ0UsMEJBQUE7QUF2Qko7O0FBMEJFO0VBQ0UsY0FBQTtBQXhCSjs7QUEwQkk7RUFDRSxjQUFBO0VBQ0EsMEJBQUE7QUF4Qk47O0FBNkJJO0VBQ0UsWUFBQTtBQTNCTjs7QUE4REE7RUFDRSxnQkFBQTtFQUNBLHlCQUFBO0VBQ0EsbUJBQUE7QUEzREY7O0FBOERBO0VBQ0UsbUJBQUE7QUEzREY7O0FBOERBO0VBQ0UseUJBQUE7QUEzREY7O0FBOERBO0VBQ0UsdUJBQUE7QUEzREY7O0FBOERBO0VBQ0UsaUJBQUE7QUEzREY7O0FBOERBO0VBQ0UsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7QUEzREY7O0FBOERBO0VBRUUsa0JBQUE7QUE1REY7O0FBK0RBO0VBQ0UscUJBQUE7QUE1REY7O0FBK0RBO0VBQ0UscUJBQUE7QUE1REY7O0FBK0RBO0VBQ0Usa0JBQUE7RUFDQSxjQUFBO0FBNURGOztBQStEQTtFQUNFLGNBQUE7QUE1REY7O0FBZ0VBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtFQUNBLG1DQUFBO0VBQ0EsWUFBQTtBQTdERjs7QUFnRUE7RUFDRSxjQUFBO0FBN0RGOztBQWdFQTtFQUNFLG1CQUFBO0FBN0RGOztBQXFFQTtFQUNFLGdCQUFBO0FBbEVGOztBQXFFQTtFQUNFLHVCQUFBO0VBQ0Esc0JBQUE7RUFDQSxhQUFBO0FBbEVGOztBQXFFQTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0EseUJBQUE7RUFDQSxxREFBQTtFQUNBLDRCQUFBO0VBQ0EscUJBQUE7RUFDQSwyQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQWxFRjs7QUFxRUE7RUFDRSwrQ0FBQTtBQWxFRjs7QUFxRUE7RUFDRSxxREFBQTtBQWxFRjs7QUFxRUE7RUFDRSx5QkFBQTtBQWxFRjs7QUFxRUE7RUFDRSx1QkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQWxFRjs7QUFvRUU7RUFDRSxrQkFBQTtFQUNBLGVBQUE7RUFFQSw2QkFBQTtFQUNBLGdCQUFBO0FBbkVKOztBQXFFSTtFQUNFLGNBQUE7RUFFQSx5QkFBQTtFQUNBLHlDQUFBO0FBcEVOOztBQXVFSTtFQUNFLHlCQUFBO0FBckVOOztBQXlFSTtFQUNFLFdBQUE7QUF2RU47O0FBMEVJO0VBQ0UscUJBQUE7RUFDQSw2QkFBQTtFQUNBLDZCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxzQkFBQTtBQXhFTjs7QUE2RUE7RUFDRSxXQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtBQTFFRjs7QUE2RUE7RUFFRSxxQkFBQTtFQUVBLDhCQUFBO0VBQUEsMkJBQUE7RUFBQSxzQkFBQTtFQUNBLDRCQUFBO0FBNUVGOztBQThFRTtFQUNFLGNBQUE7RUFDQSxlQUFBO0FBNUVKOztBQThFSTtFQUNFLFlBQUE7QUE1RU47O0FBaUZBO0VBQ0UsZ0NBQUE7QUE5RUY7O0FBaUZBO0VBQ0UsdUNBQUE7RUFNQSwwQ0FBQTtBQW5GRjs7QUFxRkU7RUFDRSxnQ0FBQTtBQW5GSjs7QUFxRkk7RUFDRSx1Q0FBQTtBQW5GTjs7QUFzRkk7RUFDRSw4Q0FBQTtFQUNBLDRCQUFBO0VBQ0EsNkJBQUE7QUFwRk47O0FBd0ZFO0VBQ0UsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsOEJBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtFQUVBLHNCQUFBO0FBdkZKOztBQXlGSTtFQUNFLGVBQUE7RUFDQSxNQUFBO0VBQ0EsV0FBQTtFQUNBLFVBQUE7RUFDQSxtQkFBQTtFQUNBLDRCQUFBO0VBQ0EsNkJBQUE7QUF2Rk47O0FBMEZJO0VBQ0UsYUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0NBQUE7RUFBQSx5RkFBQTtFQUNBLFlBQUE7RUFDQSxzQkFBQTtBQXhGTjs7QUEyRk07RUFDRSxnQkFBQTtBQXpGUjs7QUEyRlE7RUFDRSxXQUFBO0FBekZWOztBQStGRTtFQUNFLGdDQUFBO0VBQ0Esa0NBQUE7QUE3Rko7O0FBK0ZJO0VBQ0UsZ0NBQUE7RUFDQSxrQ0FBQTtBQTdGTjs7QUFrR0E7RUFDRSw4QkFBQTtFQUFBLDJCQUFBO0VBQUEsc0JBQUE7RUFDQSxpQkFBQTtBQS9GRjs7QUFpR0U7RUFDRSxnQkFBQTtBQS9GSjs7QUFtR0E7RUFDRSxtQkFBQTtFQUNBLFdBQUE7QUFoR0Y7O0FBbUdBO0VBQ0UsbUJBQUE7QUFoR0Y7O0FBbUdBO0VBQ0UsWUFBQTtBQWhHRjs7QUFrR0E7O0VBRUUsV0FBQTtFQUNBLGdDQUFBO0FBL0ZGOztBQWtHQTtFQUNFLGdDQUFBO0FBL0ZGOztBQWtHQTtFQUNFLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHNCQUFBO0VBQ0EsV0FBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7QUEvRkY7O0FBa0dBO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsaUJBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0FBL0ZGOztBQWtHQTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtBQS9GRjs7QUFrR0E7RUFDRSwwQkFBQTtBQS9GRjs7QUFrR0E7RUFFRSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQWhHRjs7QUFxR0E7RUFFRSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQW5HRjs7QUF1R0E7RUFDRSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtBQXBHRjs7QUF1R0E7RUFDRSxhQUFBO0VBQ0Esc0JBQUE7QUFwR0Y7O0FBdUdBO0VBRUUsY0FBQTtFQUNBLGVBQUE7QUFyR0Y7O0FBMkdBO0VBRUUsY0FBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUF6R0Y7O0FBNkdBO0VBQ0UsMEJBQUE7QUExR0Y7O0FBNkdBO0VBQ0UseUJBQUE7QUExR0Y7O0FBNkdBO0VBQ0UsZUFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtBQTFHRjs7QUE2R0E7RUFFRSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsTUFBQTtFQUVBLE9BQUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7QUE1R0Y7O0FBK0dFO0VBQ0UsNEJBQUE7QUE3R0o7O0FBZ0hFO0VBQ0UsV0FBQTtFQUNBLFVBQUE7QUE5R0o7O0FBaUhFO0VBQ0UsY0FBQTtFQUFBLHdDQUFBO0VBQ0EsNEJBQUE7QUEvR0o7O0FBa0hJO0VBQ0UsY0FBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLDJCQUFBO1VBQUEsMEJBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUFoSE47O0FBa0hNO0VBQ0UsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLDBCQUFBO1VBQUEseUJBQUE7QUFoSFI7O0FBb0hJO0VBQ0UsY0FBQTtFQUNBLG9CQUFBO0FBbEhOOztBQXNIRTtFQUNFLDZCQUFBO0VBRUEsaUJBQUE7RUFDQSw0QkFBQTtBQXJISjs7QUF1SEk7RUFDRSxjQUFBO0FBckhOOztBQXdISTtFQUNFLGNBQUE7QUF0SE47O0FBMkhBO0VBQ0UsYUFBQTtFQUNBLGNBQUE7QUF4SEY7O0FBMkhBO0VBQ0UsMkJBQUE7VUFBQSwwQkFBQTtBQXhIRjs7QUEySEE7RUFDRSx1Q0FBQTtFQUNBLDhDQUFBO0FBeEhGOztBQTJIQTtFQUNFLHFCQUFBO0FBeEhGOztBQTJIQTtFQUNFLFdBQUE7RUFDQSxvQkFBQTtBQXhIRjs7QUEySEE7RUFDRSxrQ0FBQTtBQXhIRjs7QUEySEE7RUFDRSwrQkFBQTtBQXhIRjs7QUFnSUU7RUFDRSx1Q0FBQTtFQUNBLHlCQUFBO0VBQ0EsZ0JBQUE7QUE3SEo7O0FBZ0lFO0VBQ0UsV0FBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EseUJBQUE7QUE5SEo7O0FBaUlFO0VBQ0UsWUFBQTtFQUNBLFVBQUE7QUEvSEo7O0FBa0lFO0VBR0UsdUJBQUE7QUFsSUo7O0FBb0lJO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSxVQUFBO0VBQ0EsaUJBQUE7QUFsSU47O0FBcUlJO0VBQ0UsbUJBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtBQW5JTjs7QUF1SUU7RUFDRSxnQkFBQTtFQUNBLFlBQUE7QUFySUo7O0FBZ0pJO0VBQ0UsZ0JBQUE7QUE5SU4iLCJmaWxlIjoiaG9tZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcbiAgYmFja2dyb3VuZDogIzM0NzQ3ODtcbn1cblxuLy8gaW9uLWhlYWRlciB7XG4vLyAgIHBhZGRpbmctdG9wOiBlbnYoc2FmZS1hcmVhLWluc2V0LXRvcCkgIWltcG9ydGFudDtcbi8vICAgLy8gYmFja2dyb3VuZDogIzAwNTE1NyAhaW1wb3J0YW50O1xuXG4vLyAgICYuYW5kcm9pZC1oZWFkZXIge1xuLy8gICAgIHBhZGRpbmctdG9wOiAyNXB4ICFpbXBvcnRhbnQ7XG4vLyAgIH1cbi8vIH1cblxuOjpuZy1kZWVwIC5pb24tcGFnZSB7XG4gIGJhY2tncm91bmQ6ICMzNDczNzg7XG59XG5cblxuXG4vLyBpb24taGVhZGVyLmhvbWUtcGFnZSB7XG4vLyAgIHBhZGRpbmctdG9wOiBlbnYoc2FmZS1hcmVhLWluc2V0LXRvcCkgIWltcG9ydGFudDtcbi8vICAgYmFja2dyb3VuZDogIzAwNTE1NztcblxuLy8gICAmLmFuZHJvaWQtaGVhZGVyIHtcbi8vICAgICBwYWRkaW5nLXRvcDogMjVweDtcbi8vICAgfVxuLy8gfVxuXG5pb24tdG9vbGJhciB7XG4gIC8vIC0tYmFja2dyb3VuZDogIzAwNTE1NztcbiAgLy8gLS1jb2xvcjogd2hpdGU7XG4gIC5wcm9maWxlLWF2YXRhciB7XG4gICAgd2lkdGg6IDI0cHg7XG4gICAgaGVpZ2h0OiAyNHB4O1xuICAgIG1hcmdpbi1pbmxpbmUtc3RhcnQ6IDE2cHg7XG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgIGJvcmRlcjogMnB4IHNvbGlkIHdoaXRlO1xuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGUgIWltcG9ydGFudDtcbiAgfVxuXG4gIC5pY29uIHtcbiAgICBmb250LXNpemU6IDIwcHggIWltcG9ydGFudDtcbiAgfVxuXG4gIC5pY29uLWxpbmsge1xuICAgIGNvbG9yOiAjOTliOWJjO1xuXG4gICAgLmljb24tYWxpbm1hLXN5bWJvbCB7XG4gICAgICBjb2xvcjogI0ZGRkZGRjtcbiAgICAgIGZvbnQtc2l6ZTogMjRweCAhaW1wb3J0YW50O1xuICAgIH1cbiAgfVxuXG4gIGlvbi10aXRsZSB7XG4gICAgLmljb24tbGluayB7XG4gICAgICBtYXJnaW46IGF1dG87XG4gICAgfVxuICB9XG5cbiAgLy8gLmhvbWUtaGVhZGVyLXRvcCB7XG4gIC8vICAgLy8gcGFkZGluZzogMDtcbiAgLy8gICAvLyBib3JkZXItYm90dG9tOiAxcHggc29saWQgIzIyNjY2ZDtcbiAgLy8gICAvLyAtLWlvbi1ncmlkLWNvbHVtbi1wYWRkaW5nOiAwO1xuXG5cblxuICAvLyAgIC5wcm9maWxlLWF2YXRhciB7XG4gIC8vICAgICB3aWR0aDogMjRweDtcbiAgLy8gICAgIGhlaWdodDogMjRweDtcbiAgLy8gICAgIG1hcmdpbi1pbmxpbmUtc3RhcnQ6IDE2cHg7XG4gIC8vICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIC8vICAgICBib3JkZXI6IDJweCBzb2xpZCB3aGl0ZTtcbiAgLy8gICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGUgIWltcG9ydGFudDtcbiAgLy8gICB9XG5cbiAgLy8gICAuaWNvbiB7XG4gIC8vICAgICBmb250LXNpemU6IDIwcHg7XG4gIC8vICAgfVxuXG4gIC8vICAgLmljb24tbGluayB7XG4gIC8vICAgICBjb2xvcjogIzk5YjliYztcblxuICAvLyAgICAgLmljb24tYWxpbm1hLXN5bWJvbCB7XG4gIC8vICAgICAgIGNvbG9yOiAjRkZGRkZGO1xuICAvLyAgICAgICBmb250LXNpemU6IDI0cHg7XG4gIC8vICAgICB9XG4gIC8vICAgfVxuICAvLyB9XG59XG5cbmlvbi1yZWZyZXNoZXIge1xuICAtLWNvbG9yOiAjRkZGRkZGO1xuICAtLWlvbi10ZXh0LWNvbG9yOiAjRkZGRkZGO1xuICBiYWNrZ3JvdW5kOiAjMzQ3Mzc4O1xufVxuXG5pb24tcmVmcmVzaGVyIHtcbiAgYmFja2dyb3VuZDogIzM0NzM3ODtcbn1cblxuLm1hcmtldC1jb250YWluZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjY2RkZmUxO1xufVxuXG5ib2R5LmRhcmsgOmhvc3QgLm1hcmtldC1jb250YWluZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFja1xufVxuXG4udGFkYXd1bFNlZ21lbnQge1xuICBtYXJnaW4tdG9wOiAtMjVweDtcbn1cblxuLmNvbGxhYnNlYWJsZUxpc3RTY3JvbGwge1xuICBtYXJnaW4tdG9wOiAtMjVweDtcbiAgb3ZlcmZsb3cteTogc2Nyb2xsO1xuICBoZWlnaHQ6IDIwMHB4O1xufVxuXG4uaG9tZS1zY3JvbGwtdmlldyB7XG4gIC8vICBoZWlnaHQ6IDM0OHB4O1xuICBvdmVyZmxvdy15OiBzY3JvbGw7XG59XG5cbi5ob21lLW9yZGVyLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6ICNmZmZmZmY7XG59XG5cbmJvZHkuZGFyayA6aG9zdCAuaG9tZS1vcmRlci10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMWUxZTFlO1xufVxuXG4uaG9tZS10aXRsZSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6ICMwMDUxNTc7XG59XG5cbmJvZHkuZGFyayA6aG9zdCAuaG9tZS10aXRsZSB7XG4gIGNvbG9yOiAjZmZmZmZmO1xufVxuXG5cbi5wb3J0Zm9saW9TaGFyZVRleHQge1xuICB3aWR0aDogODFweDtcbiAgaGVpZ2h0OiAxN3B4O1xuICBmb250LXNpemU6IDEzcHg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICB0ZXh0LWFsaWduOiBzdGFydDtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXR4dCk7XG4gIHBhZGRpbmc6IDVweDtcbn1cblxuYm9keS5kYXJrIDpob3N0IC5wb3J0Zm9saW9TaGFyZVRleHQge1xuICBjb2xvcjogI2QyZDJkMjtcbn1cblxuYm9keS5kYXJrIDpob3N0IC5ob21lY29sb3Ige1xuICAtLWJhY2tncm91bmQ6IGJsYWNrO1xufVxuXG4vLyBpb24tbWVudS1idXR0b24sXG4vLyBpb24tYmFjay1idXR0b24ge1xuLy8gICAtLWNvbG9yOiAjMDA1MTU3O1xuLy8gfVxuXG5ib2R5LmRhcmsgOmhvc3QgaW9uLW1lbnUtYnV0dG9uIHtcbiAgLS1jb2xvcjogI2ZmZmZmZjtcbn1cblxuLnN0YXIge1xuICBoZWlnaHQ6IDIwcHggIWltcG9ydGFudDtcbiAgd2lkdGg6IDIwcHggIWltcG9ydGFudDtcbiAgb3V0bGluZTogbm9uZTtcbn1cblxuLm5vLWRhdGEge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAyMjBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzAwNTE1NztcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKC9hc3NldHMvaWNvbi9jYXJkLWJnLXNoYXBlLnBuZyk7XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gIGJhY2tncm91bmQtc2l6ZTogMTIwJTtcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICBtYXJnaW4tdG9wOiAxMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBhZGRpbmctdG9wOiAxNSU7XG59XG5cbmJvZHkuZGFyayA6aG9zdCAuc3RhciB7XG4gIGNvbnRlbnQ6IHVybChcIi9hc3NldHMvaWNvbi9kYXJrLWZhdm91cml0ZS5zdmdcIik7XG59XG5cbmJvZHkuZGFyayA6aG9zdCAucG9ydGZvbGlvU2hhcmVJY29uIHtcbiAgY29udGVudDogdXJsKFwiL2Fzc2V0cy9pY29uL2xvY2FsLXBvcnRmb2xpby1kYXJrLnN2Z1wiKTtcbn1cblxuYm9keS5kYXJrIDpob3N0IC5ob21lLWRhcmsge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAwMDAwO1xufVxuXG4ubXV0dWFsLWZ1bmRzLXNlZ21lbnQtYmFyIHtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIGJvcmRlci1yYWRpdXM6IDA7XG4gIHBhZGRpbmctbGVmdDogMTklO1xuICBwYWRkaW5nLXJpZ2h0OiAxOSU7XG5cbiAgaW9uLXNlZ21lbnQtYnV0dG9uIHtcbiAgICAtLWJvcmRlci1yYWRpdXM6IDA7XG4gICAgZm9udC1zaXplOiAxMXB4O1xuICAgIC8vICAtLWJhY2tncm91bmQ6ICMwMDUxNTc7XG4gICAgLS1iYWNrZ3JvdW5kLWNoZWNrZWQ6ICMwMDUxNTc7XG4gICAgLS1jb2xvcjogIzAwNTE1NztcblxuICAgICYuc2VnbWVudC1idXR0b24tY2hlY2tlZCB7XG4gICAgICAtLWNvbG9yOiB3aGl0ZTtcbiAgICAgIC8vICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuICAgICAgYm9yZGVyOiAxcHggc29saWQgIzAwNTE1NztcbiAgICAgIC0taW5kaWNhdG9yLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuICAgIH1cblxuICAgICY6bm90KC5zZWdtZW50LWJ1dHRvbi1jaGVja2VkKSB7XG4gICAgICBib3JkZXI6IDFweCBzb2xpZCAjMDA1MTU3O1xuXG4gICAgfVxuXG4gICAgYm9keS5kYXJrIDpob3N0ICY6bm90KC5zZWdtZW50LWJ1dHRvbi1jaGVja2VkKSB7XG4gICAgICBib3JkZXI6IDBweDtcbiAgICB9XG5cbiAgICBib2R5LmRhcmsgOmhvc3QgJiB7XG4gICAgICAtLWJhY2tncm91bmQ6ICM0YjRiNGI7XG4gICAgICAtLWJhY2tncm91bmQtY2hlY2tlZDogIzc4Nzg3ODtcbiAgICAgIC0tYmFja2dyb3VuZC1mb2N1c2VkOiAjNzg3ODc4O1xuICAgICAgLS1jb2xvcjogI2E1YTVhNTtcbiAgICAgIC0tY29sb3ItY2hlY2tlZDogd2hpdGU7XG4gICAgfVxuICB9XG59XG5cbi5ib3R0b20tc2hlZXQtaGVhZGVyIHtcbiAgd2lkdGg6IDUwcHg7XG4gIGhlaWdodDogNXB4O1xuICBtYXJnaW46IDEwcHggYXV0bztcbiAgYm9yZGVyLXJhZGl1czogM3B4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTZlZmYwO1xufVxuXG5pb24tc2VnbWVudC5wb3J0Zm9saW8tdHlwZSB7XG4gIC8vIC0tYmFja2dyb3VuZDogI2U2ZWZmMDtcbiAgLS1iYWNrZ3JvdW5kOiAjMGY1YTYxO1xuICAvLyB3aWR0aDogMTAwJTtcbiAgbWF4LXdpZHRoOiBtYXgtY29udGVudDtcbiAgbWFyZ2luOiAxMHB4IGF1dG8gIWltcG9ydGFudDtcblxuICBpb24tc2VnbWVudC1idXR0b24ge1xuICAgIGNvbG9yOiAjOTliOWJjO1xuICAgIGZvbnQtc2l6ZTogMTBweDtcblxuICAgICYuc2VnbWVudC1idXR0b24tY2hlY2tlZCB7XG4gICAgICBjb2xvcjogd2hpdGU7XG4gICAgfVxuICB9XG59XG5cbi5ob21lY29sb3Ige1xuICAtLWJhY2tncm91bmQ6ICMzNDc0NzggIWltcG9ydGFudDtcbn1cblxuaW9uLWJvdHRvbS1kcmF3ZXIge1xuICBib3JkZXItcmFkaXVzOiAxMHB4IDEwcHggMCAwICFpbXBvcnRhbnQ7XG4gIC8vIG1heC1oZWlnaHQ6IGNhbGMoMTAwdmggLSA5NXB4IC0gNjBweCAtIGVudihzYWZlLWFyZWEtaW5zZXQtdG9wKSAtIGVudihzYWZlLWFyZWEtaW5zZXQtYm90dG9tKSk7XG4gIC8vIHRyYW5zaXRpb246IGFsbCAwLjJzIGVhc2UgMHMgIWltcG9ydGFudDtcbiAgLy8gdHJhbnNpdGlvbi1wcm9wZXJ0eTogYWxsICFpbXBvcnRhbnQ7XG4gIC8vIHRyYW5zaXRpb24tZHVyYXRpb246IDAuMTVzICFpbXBvcnRhbnQ7XG4gIC8vIHRyYW5zaXRpb24tdGltaW5nLWZ1bmN0aW9uOiBsaW5lYXIgIWltcG9ydGFudDtcbiAgdHJhbnNpdGlvbjogYWxsIDAuMTVzIGxpbmVhciAwcyAhaW1wb3J0YW50O1xuICBcbiAgaW9uLWNvbnRlbnQge1xuICAgIC0tYmFja2dyb3VuZDogI0Y0RjhGOCAhaW1wb3J0YW50O1xuXG4gICAgJjo6cGFydChiYWNrZ3JvdW5kKSB7XG4gICAgICBib3JkZXItcmFkaXVzOiAxMHB4IDEwcHggMCAwICFpbXBvcnRhbnQ7XG4gICAgfVxuXG4gICAgJjo6cGFydChzY3JvbGwpIHtcbiAgICAgIC13ZWJraXQtb3ZlcmZsb3ctc2Nyb2xsaW5nOiBpbmhlcml0ICFpbXBvcnRhbnQ7XG4gICAgICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAxMHB4O1xuICAgICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDEwcHg7XG4gICAgfVxuICB9XG5cbiAgLmRyYXdlci1jb250ZW50IHtcbiAgICBiYWNrZ3JvdW5kOiAjRjRGOEY4O1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4ICFpbXBvcnRhbnQ7XG4gICAgb3ZlcmZsb3c6IGF1dG87XG4gICAgZGlzcGxheTogZmxleDtcbiAgICAvLyBtaW4taGVpZ2h0OiAxMDAlO1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIFxuICAgIC5kcmF3ZXItY29udGVudC1oZWFkZXIge1xuICAgICAgcG9zaXRpb246IGZpeGVkO1xuICAgICAgdG9wOiAwO1xuICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICB6LWluZGV4OiAyO1xuICAgICAgYmFja2dyb3VuZDogI0ZGRkZGRjtcbiAgICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDEwcHg7XG4gICAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMTBweDtcbiAgICB9XG4gIFxuICAgIC5jb250ZW50IHtcbiAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICBtYXJnaW4tdG9wOiAxMTBweDtcbiAgICAgIHBhZGRpbmctYm90dG9tOiBjYWxjKDc1cHggKyB2YXIoLS1pb24tc2FmZS1hcmVhLWJvdHRvbSwgMCkgKyB2YXIoLS1pb24tc2FmZS1hcmVhLXRvcCwgMCkpO1xuICAgICAgZmxleC1ncm93OiAxO1xuICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgIC8vIG1pbi1oZWlnaHQ6IGNhbGMoMTAwJSAtIDExMHB4KTtcbiAgXG4gICAgICBpb24tc2xpZGVzIHtcbiAgICAgICAgbWluLWhlaWdodDogMTAwJTtcbiAgXG4gICAgICAgIGlvbi1zbGlkZSB7XG4gICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAmLnNjcm9sbGFibGUge1xuICAgIHRvdWNoLWFjdGlvbjogaW5pdGlhbCAhaW1wb3J0YW50O1xuICAgIC13ZWJraXQtdXNlci1kcmFnOiBhdXRvICFpbXBvcnRhbnQ7XG5cbiAgICAuZHJhd2VyLWNvbnRlbnQge1xuICAgICAgdG91Y2gtYWN0aW9uOiBpbml0aWFsICFpbXBvcnRhbnQ7XG4gICAgICAtd2Via2l0LXVzZXItZHJhZzogYXV0byAhaW1wb3J0YW50O1xuICAgIH1cbiAgfVxufVxuXG5pb24tc2VnbWVudC5mb3JtLXNlZ21lbnQge1xuICBtYXgtd2lkdGg6IG1heC1jb250ZW50O1xuICBtYXJnaW46IDEwcHggYXV0bztcblxuICBpb24tc2VnbWVudC1idXR0b24ge1xuICAgIG1pbi13aWR0aDogMTAwcHg7XG4gIH1cbn1cblxuLnN5bWJvbHMtaW9uLWxpc3Qge1xuICBiYWNrZ3JvdW5kOiAjRjRGOEY4O1xuICB3aWR0aDogMTAwJTtcbn1cblxudGFkYXd1bC1zeW1ib2wtY2FyZDpsYXN0LWNoaWxkIHtcbiAgbWFyZ2luLWJvdHRvbTogNTBweDtcbn1cblxuaW9uLXNsaWRlcyB7XG4gIGhlaWdodDogMTAwJTtcbn1cbmlvbi1zbGlkZXMsXG5pb24tc2xpZGUge1xuICB3aWR0aDogMTAwJTtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrICFpbXBvcnRhbnQ7XG59XG5cbi5zd2lwZXItc2xpZGUge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2sgIWltcG9ydGFudDtcbn1cblxuLmFwcC10b29sYmFyLWhvbWUge1xuICBkaXNwbGF5OiBmbGV4O1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICB3aWR0aDogMTAwJTtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBiYWNrZ3JvdW5kOiAjMDA1MTU3O1xufVxuXG4uYXBwLXRvb2xiYXItcm93IHtcbiAgZGlzcGxheTogZmxleDtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgcGFkZGluZzogNnB4IDExcHg7XG4gIHdpZHRoOiAxMDAlO1xuICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xufVxuXG4ucG9ydGZvbGlvLW51bWJlciB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xuICBjb2xvcjogI2ZmZjtcbn1cblxuLmZvbnQtMTUge1xuICBmb250LXNpemU6IDE1cHggIWltcG9ydGFudDtcbn1cblxuLnBvcnRmb2xpby1mb290ZXItdmFsdWUtZ3JlZW4ge1xuICAvLyB0ZXh0LWFsaWduOiByaWdodDtcbiAgY29sb3I6ICMyZWJkODU7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgZGlzcGxheTogYmxvY2s7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAvL2RpcmVjdGlvbjogbHRyIWltcG9ydGFudDtcblxufVxuXG4ucG9ydGZvbGlvLWZvb3Rlci12YWx1ZS1yZWQge1xuICAvLyB0ZXh0LWFsaWduOiByaWdodDtcbiAgY29sb3I6ICNjNDNjMzU7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgZGlzcGxheTogYmxvY2s7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAvLyBkaXJlY3Rpb246IGx0ciFpbXBvcnRhbnQ7XG59XG5cbi5wb3J0Zm9saW8tbGFzdC1yb3cge1xuICBoZWlnaHQ6IDU1cHg7XG4gIHBhZGRpbmc6IDBweCAxMXB4O1xuICBiYWNrZ3JvdW5kOiAjMDA1MTU3O1xufVxuXG4udmVydGljYWwtdGV4dCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG59XG5cbi5wb3J0Zm9saW8tZm9vdGVyLXRleHQge1xuICAvLyB0ZXh0LWFsaWduOiByaWdodDtcbiAgY29sb3I6ICNjZGRjZGQ7XG4gIGZvbnQtc2l6ZTogMTFweDtcbiAgLy8gZGlzcGxheTogYmxvY2s7XG4gIC8vIGZvbnQtd2VpZ2h0OiBib2xkO1xuXG59XG5cbi5wb3J0Zm9saW8tZm9vdGVyLXZhbHVlIHtcbiAgLy8gdGV4dC1hbGlnbjogcmlnaHQ7XG4gIGNvbG9yOiAjZmZmZmZmO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBmb250LXdlaWdodDogYm9sZDtcblxufVxuXG4uY3VycmVuY3ktZm9udCB7XG4gIGZvbnQtc2l6ZTogMTFweCAhaW1wb3J0YW50O1xufVxuXG4uc3BhY2VyIHtcbiAgZmxleDogMSAxIGF1dG8gIWltcG9ydGFudDtcbn1cblxuLnNlY29uZFRleHQge1xuICBmb250LXNpemU6IDIwcHg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkZXI7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cblxuLnBvcnRmb2xpby1icmllZi1pbmZvIHtcbiAgLy8gaGVpZ2h0OiAxMDUuNXB4ICFpbXBvcnRhbnQ7XG4gIGJhY2tncm91bmQ6ICMwMDUxNTc7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAwO1xuICAvLyBwYWRkaW5nLXRvcDogZW52KHNhZmUtYXJlYS1pbnNldC10b3ApO1xuICBsZWZ0OiAwO1xuICB6LWluZGV4OiAtMTtcbiAgb3BhY2l0eTogMDtcbiAgd2lkdGg6IDEwMCU7XG4gIC8vIHRyYW5zaXRpb246IDAuMjVzO1xuICBcbiAgJi5hbmRyb2lkLWhlYWRlciB7XG4gICAgcGFkZGluZy10b3A6IDI1cHggIWltcG9ydGFudDtcbiAgfVxuXG4gICYuc2hvdyB7XG4gICAgei1pbmRleDogMTE7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuXG4gICYtaGVhZGVyIHtcbiAgICBwYWRkaW5nLXRvcDogdmFyKC0taW9uLXNhZmUtYXJlYS10b3AsIDApO1xuICAgIC0taW9uLWdyaWQtY29sdW1uLXBhZGRpbmc6IDA7XG4gICAgLy8gcGFkZGluZzogMDtcblxuICAgIC5wb3J0Zm9saW8tbmFtZSB7XG4gICAgICBjb2xvcjogI0ZGRkZGRjtcbiAgICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgcGFkZGluZy1pbmxpbmUtc3RhcnQ6IDExcHg7XG4gICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICAgICAgLmN1cnJlbmN5IHtcbiAgICAgICAgYmFja2dyb3VuZDogIzM0NzQ3ODtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogM3B4O1xuICAgICAgICBwYWRkaW5nOiAycHggNXB4O1xuICAgICAgICBmb250LXNpemU6IDlweDtcbiAgICAgICAgbWFyZ2luLWlubGluZS1zdGFydDogMTBweDtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAuaWNvbi1saW5rIHtcbiAgICAgIGNvbG9yOiAjOTliOWJjO1xuICAgICAgZGlzcGxheTogaW5saW5lLWZsZXg7XG4gICAgfVxuICB9XG5cbiAgJi1jb250ZW50IHtcbiAgICBib3JkZXItdG9wOiAxcHggc29saWQgIzIyNjY2ZDtcbiAgICAvLyBiYWNrZ3JvdW5kOiAjMGU1YTYxO1xuICAgIHBhZGRpbmc6IDZweCAxMXB4O1xuICAgIC0taW9uLWdyaWQtY29sdW1uLXBhZGRpbmc6IDA7XG5cbiAgICAuaXRlbS1sYWJlbCB7XG4gICAgICBjb2xvcjogI2NkZGNkZDtcbiAgICB9XG5cbiAgICAuaXRlbS12YWx1ZSB7XG4gICAgICBjb2xvcjogI0ZGRkZGRjtcbiAgICB9XG4gIH1cbn1cblxuLm1hcmdpbi01cHgtaG9yaXpvbnRhbCB7XG4gIG1hcmdpbjogMCA1cHg7XG4gIGNvbG9yOiAjOTliOWJjO1xufVxuXG4ucGFkZGluZy1zdGFydCB7XG4gIHBhZGRpbmctaW5saW5lLXN0YXJ0OiAxMXB4O1xufVxuXG5pb24tc2xpZGVzIHtcbiAgLS1idWxsZXQtYmFja2dyb3VuZDogIzkwOGM4YyAhaW1wb3J0YW50O1xuICAtLWJ1bGxldC1iYWNrZ3JvdW5kLWFjdGl2ZTogIzFlMWUxZSAhaW1wb3J0YW50O1xufVxuXG5pb24tc2xpZGVzIC5zd2lwZXItcGFnaW5hdGlvbi1idWxsZXQge1xuICBvcGFjaXR5OiAxICFpbXBvcnRhbnQ7XG59XG5cbi5zbGlkZXJDb250YWluZXIge1xuICB3aWR0aDogMTAwJTtcbiAgcGFkZGluZy1ib3R0b206IDMwcHg7XG59XG5cbltkaXI9XCJydGxcIl0uc3dpcGVyLXdyYXBwZXIge1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlciAhaW1wb3J0YW50O1xufVxuXG5bZGlyPVwibHRyXCJdLnN3aXBlci13cmFwcGVyIHtcbiAganVzdGlmeS1jb250ZW50OiBlbmQgIWltcG9ydGFudDtcbn1cblxuXG5cblxuXG4uY3VwZXJ0aW5vLXBhbmUtd3JhcHBlcntcbiAgLnBhbmUge1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHggMTBweCAwIDAgIWltcG9ydGFudDtcbiAgICBwYWRkaW5nLXRvcDogMCAhaW1wb3J0YW50O1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gIH1cblxuICAubW92ZSB7XG4gICAgd2lkdGg6IDUwcHg7XG4gICAgaGVpZ2h0OiA1cHg7XG4gICAgbWFyZ2luOiA1cHggYXV0bztcbiAgICBib3JkZXItcmFkaXVzOiAzcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2U2ZWZmMDtcbiAgfVxuXG4gIC5kcmFnZ2FibGUge1xuICAgIGhlaWdodDogMjVweDtcbiAgICB6LWluZGV4OiAzO1xuICB9XG5cbiAgLmJvdHRvbS1kcmF3ZXIge1xuICAgIC8vIGRpc3BsYXk6IGZsZXggIWltcG9ydGFudDtcbiAgICAvLyBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIGhlaWdodDogMTAwJSAhaW1wb3J0YW50O1xuXG4gICAgLmRyYXdlci1oZWFkZXIge1xuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICBiYWNrZ3JvdW5kOiAjRkZGRkZGO1xuICAgICAgei1pbmRleDogMjtcbiAgICAgIHBhZGRpbmctdG9wOiAxNXB4O1xuICAgIH1cblxuICAgIC5kcmF3ZXItY29udGVudCB7XG4gICAgICBiYWNrZ3JvdW5kOiAjRjRGOEY4O1xuICAgICAgZmxleC1ncm93OiAxO1xuICAgICAgcGFkZGluZy10b3A6IDEwMnB4O1xuICAgICAgbWluLWhlaWdodDogMTAwJTtcbiAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIH1cbiAgfVxuXG4gIGlvbi1zbGlkZXMge1xuICAgIG1pbi1oZWlnaHQ6IDEwMCU7XG4gICAgZmxleC1ncm93OiAxO1xuICAgIC8vIGRpc3BsYXk6IGZsZXggIWltcG9ydGFudDtcbiAgICAvLyBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuXG4gICAgLy8gLnN3aXBlci13cmFwcGVyIHtcbiAgICAvLyAgIG1pbi1oZWlnaHQ6IDEwMCU7XG4gICAgLy8gICBmbGV4LWdyb3c6IDE7XG4gICAgLy8gfVxuICB9XG5cbiAgYXBwLWVtcHR5LXN0YXRlIHtcbiAgICBpbWcge1xuICAgICAgbWFyZ2luLXRvcDogNTBweDtcbiAgICB9XG4gIH1cbiAgXG59Il19 */";

/***/ }),

/***/ 77177:
/*!******************************************************************!*\
  !*** ./src/app/tadawul-home/home/home.component.html?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = "<ion-header [class]=\"headerClass\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"openProfile()\">\n        <div class=\"icon-link\">\n          <span class=\"icon icon-user-profile\"></span>\n        </div>\n      </ion-button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"openNotification()\">\n        <div class=\"icon-link\">\n          <span class=\"icon icon-notification\"></span>\n        </div>\n      </ion-button>\n    </ion-buttons>\n    <ion-buttons>\n      <ion-button>\n        <div class=\"icon-link\">\n          <img class=\"\" *ngIf=\"isExpired\" slot=\"end\" (click)=\"openIDExpiryDate();\" src=\"assets/icon/alert.svg\" style=\"margin-left: 5px;width: 44px !important;\n      height: 44px !important\" />\n        </div>\n      </ion-button>\n    </ion-buttons>\n    <ion-title>\n      <div class=\"icon-link\">\n        <span class=\"icon icon-alinma-symbol\"></span>\n      </div>\n    </ion-title>\n  </ion-toolbar>\n\n\n  <tadawul-market-sub-header class=\"sub-header sub-header-dark\" page='home' [market]='market' marketName='TASI'>\n  </tadawul-market-sub-header>\n\n  <div [class]=\"headerClass\" [ngClass]=\"drawerState != 0 ? 'portfolio-brief-info show' : 'portfolio-brief-info'\">\n    <ion-grid class=\"portfolio-brief-info-header\" *ngIf=\"porDetails\">\n      <ion-row class=\"ion-justify-content-between ion-align-items-center\">\n        <ion-col size=\"auto\">\n          <div class=\"portfolio-name\">{{porDetails?._portfolioNumber}} <span\n              class=\"currency\">{{ 'homePage.SAR' | translate  }}</span></div>\n        </ion-col>\n        <ion-col size=\"auto\">\n          <div class=\"icon-link\" *ngIf=\"porDetails._isDefault\" (click)='resetDefaultPortfolio()'>\n            <span class=\"icon icon-star\" style=\"color: #fc0;\"></span>\n          </div>\n          <div class=\"icon-link\" *ngIf=\"!porDetails._isDefault\" (click)='setDefaultPortfolio()'>\n            <span class=\"icon icon-star-o\"></span>\n          </div>\n          <div class=\"icon-link\" (click)='openActions()'>\n            <span class=\"icon icon-more-vertical\"></span>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n\n    <ion-grid *ngIf=\"porDetails\" class=\"sub-header portfolio-brief-info-content ion-text-center\">\n      <ion-row>\n        <ion-col size=\"4\">\n          <div class=\"item-label\">{{ 'homePage.walletValue' | translate  }}</div>\n          <div class=\"item-value\">{{porDetails.portfolioPostionAmt }}</div>\n        </ion-col>\n\n        <ion-col size=\"4\">\n          <div class=\"item-label\">{{ 'homePage.buyingBower' | translate  }}</div>\n          <div class=\"item-value\">{{porDetails._buyingPower }}</div>\n        </ion-col>\n\n        <ion-col size=\"4\">\n          <div class=\"item-label\">{{ 'homePage.profitLoss' | translate  }}</div>\n\n          <div *ngIf=\"porDetails._totalLoss != 0\"\n            [ngClass]=\"porDetails._totalLoss > 0 ?'item-value text-up':'item-value text-down' \">\n            {{porDetails._totalLoss | number : '1.2-2'}}</div>\n          <div *ngIf=\"porDetails._totalLoss == 0\" class=\"item-value\">{{porDetails._totalLoss | number : '1.2-2'}}</div>\n\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </div>\n</ion-header>\n\n<ion-content class=\"homecolor\" no-bounce>\n\n\n\n  <ion-refresher [disabled]=\"!isPortfolioLoaded\" slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\">\n    <ion-refresher-content pullingIcon=\"chevron-down-circle-outline\" refreshingSpinner=\"crescent\">\n    </ion-refresher-content>\n  </ion-refresher>\n\n  <div class=\"home-dark\">\n    <ion-segment class=\"portfolio-type\" [disabled]=\"(!isPortfolioLoaded && refreshLoaded) || isPortfolioSegmentChanged\" [(ngModel)]=\"portfoliosActiveSegment\"\n      (ionChange)=\"portfolioSegmentChanged($event)\">\n      <ion-segment-button value=\"lp\">\n        {{ 'homePage.localPortfolios' | translate }}\n      </ion-segment-button>\n      <ion-segment-button value=\"mf\">\n        {{ 'homePage.investmentPortfolios' | translate }}\n      </ion-segment-button>\n    </ion-segment>\n    <tadawul-skeleton-loader [type]=\"SkeletonType.PORTFOLIO_CARD\" *ngIf=\"!isAllPortfolioLoaded\">\n    </tadawul-skeleton-loader>\n    <ion-grid class=\"slider-pager-space ion-no-padding\">\n      <ng-container *ngIf=\"isAllPortfolioLoaded && segmentPortfolios?.length == 0 && PortfolioType == 'IN'\">\n        <app-empty-state msgColor=\"white-text\" [message]=\"'portfolio.emptyLocalPortfolios' | translate\"\n          image=\"assets/icon/no-portfolio.svg\"></app-empty-state>\n      </ng-container>\n      <ng-container *ngIf=\"isAllPortfolioLoaded && segmentPortfolios?.length == 0 && PortfolioType == 'MF'\">\n        <app-empty-state msgColor=\"white-text\" [message]=\"'portfolio.emptyMFPortfolios' | translate \"\n          image=\"assets/icon/no-portfolio.svg\"></app-empty-state>\n      </ng-container>\n      <ion-slides #portfolioSlides *ngIf=\"isAllPortfolioLoaded && segmentPortfolios?.length != 0\"\n        [options]=\"slideOptsOne\" (ionSlideNextEnd)=\"slideForward()\" (ionSlidePrevEnd)=\"slideBack()\">\n        <ion-slide *ngFor=\"let por of segmentPortfolios\">\n          <tadawul-portfolio [portfolio]=\"por\" [portfolioInfo]='porDetails' (detailClick)=\"openActions()\"\n            (defaultBtnClick)=\"setDefaultPortfolio()\" (notdefaultBtnClick)=\"resetDefaultPortfolio()\">\n          </tadawul-portfolio>\n        </ion-slide>\n      </ion-slides>\n    </ion-grid>\n  </div>\n</ion-content>\n<!--  *ngIf=\"(PortfolioType=='IN' && symbolArray && symbolArray.length > 0)||(PortfolioType =='MF' && mfDetails && mfDetails.length > 0)\"\n-->\n\n\n<div class=\"bottom-drawer\">\n  <div class=\"drawer-header\">\n    <ion-segment class=\"form-segment\" [(ngModel)]=\"symbolTabType\" [ngModelOptions]=\"{standalone: true}\"\n      *ngIf=\"PortfolioType=='IN'\" (ionChange)=\"symbolSegmentChanged()\" scrollable=\"true\">\n      <ion-segment-button value=\"SYMBOLS\">\n        {{ 'homePage.symbols' | translate }}\n      </ion-segment-button>\n      <ion-segment-button value=\"SUKUK\">\n        {{ 'homePage.sukuk' | translate }}\n      </ion-segment-button>\n    </ion-segment>\n    <ion-segment class=\"form-segment\" [(ngModel)]=\"activeSegment\" *ngIf=\"PortfolioType!='IN'\"\n      [ngModelOptions]=\"{standalone: true}\" (ionChange)=\"fundSegmentChanged()\">\n      <ion-segment-button value=\"INV\">\n        {{ 'homePage.investmentFunds' | translate }}\n      </ion-segment-button>\n      <ion-segment-button value=\"FUND\">\n        {{ 'homePage.charityFunds' | translate }}\n      </ion-segment-button>\n      <ion-segment-button value=\"CLOSEDFUND\">\n        {{ 'homePage.closedFunds' | translate }}\n      </ion-segment-button>\n    </ion-segment>\n    <ion-row class=\"table-row-header ion-padding-horizontal\">\n      <ion-col size=\"3\" class=\"ion-text-start padding-start\">{{ 'homePage.quantity' | translate }}</ion-col>\n      <ion-col size=\"2.5\" class=\"ion-text-center\">{{ 'homePage.Cost' | translate }}</ion-col>\n      <ion-col size=\"2.5\" class=\"ion-text-center\">{{ 'homePage.lastPrice' | translate }}</ion-col>\n      <ion-col size=\"4\" class=\"ion-text-center\">{{ 'homePage.change' | translate }}</ion-col>\n    </ion-row>\n  </div>\n\n\n\n  <div class=\"drawer-content\">\n    <ng-container\n      *ngIf=\"(!symbolArray && PortfolioType=='IN') || !porDetails || (!symbolArray && PortfolioType!='IN' && !standardMutualFundsArr && !standardMutualFundsArr)\">\n      <tadawul-skeleton-loader [hidden]=\"segmentPortfolios.length == 0\" *ngFor=\"let item of [].constructor(3)\"\n        [type]=\"SkeletonType.SYMBOL_CARD\">\n      </tadawul-skeleton-loader>\n      <app-empty-state *ngIf=\"segmentPortfolios.length == 0 && PortfolioType =='IN'\"\n        [message]=\"'portfolio.emptyShares' | translate\" image=\"assets/icon/no-shares.svg\"></app-empty-state>\n    </ng-container>\n\n    <ng-container *ngIf=\"segmentPortfolios?.length != 0 && PortfolioType=='IN' && porDetails\">\n      <ion-slides #symbolSlides (ionSlideDidChange)=\"symbolSlidesChanged()\" [options]=\"cupertinoPaneSlides\">\n        <ion-slide>\n          <div class=\"symbols-ion-list\">\n            <tadawul-symbol-card *ngFor=\"let item of symbols_arr;let i = index;\" formName=\"home\"\n              componentName=\"symbol\" [companyName]=\"item.symbol.code +' - '+ item._secName.toString()\"\n              [changeRate]=\"Number(item.unrealizedProfitLoss.amount) | number: '1.2-2'\"\n              [quantity]=\"item.ownedQuantity\" [cost]=\"Number(item.avgCostPrice.amount) | number: '1.2-2'\"\n              [lastPrice]=\"Number(item.mrktPrice.amount) | number: '1.2-2'\"\n              [ratePercentage]=\"item.unrealizedProfitLossPercen\" (click)=\"openSymbol(item)\">\n            </tadawul-symbol-card>\n            <div [hidden]=\"symbols_arr?.length != 0 || !isPortfolioLoaded\">\n              <app-empty-state message=\"{{ 'homePage.emptyShares' | translate  }}\" image=\"assets/icon/no-shares.svg\">\n              </app-empty-state>\n            </div>\n          </div>\n        </ion-slide>\n        <ion-slide>\n          <div class=\"symbols-ion-list\">\n            <tadawul-symbol-card *ngFor=\"let item of sukuk_arr;let i = index;\" formName=\"home\" componentName=\"symbol\"\n              [companyName]=\"item.symbol.code +' - '+ item._secName.toString()\"\n              [changeRate]=\"item.unrealizedProfitLoss.amount | commafy:'number':3\"\n              [quantity]=\"item.ownedQuantity | commafy:'integer'\"\n              [cost]=\"item.avgCostPrice.amount| commafy:'number':3 | commafy:'number':3\"\n              [lastPrice]=\"item.mrktPrice.amount | commafy:'number':3\"\n              [ratePercentage]=\"item.unrealizedProfitLossPercen | commafy:'number':3\" (click)=\"openSymbol(item)\">\n            </tadawul-symbol-card>\n            <div [hidden]=\"sukuk_arr?.length != 0 || !isPortfolioLoaded\">\n              <app-empty-state message=\"{{ 'homePage.emptySukuk' | translate  }}\" image=\"assets/icon/no-shares.svg\">\n              </app-empty-state>\n            </div>\n          </div>\n        </ion-slide>\n      </ion-slides>\n    </ng-container>\n\n    <ng-container *ngIf=\"PortfolioType!='IN'\">\n      <ion-slides #fundSlides (ionSlideDidChange)=\"fundSlidesChanged()\">\n        <ion-slide class=\"swiper-slide\">\n          <div class=\"symbols-ion-list\">\n            <div [hidden]=\"standardMutualFundsArr.length == 0\">\n              <tadawul-symbol-card *ngFor=\"let item of standardMutualFundsArr;let i = index;\" formName=\"home\"\n                componentName=\"symbol\" [companyName]=\"item.name\" [changeRate]=\"item.changeRate | commafy:'number':6\"\n                [quantity]=\"item.quantity| commafy:'number':6\" [cost]=\"item.cost | commafy:'number':6\"\n                [lastPrice]=\"item.price | commafy:'number':6\"\n                [ratePercentage]=\"item.changeRatePercentage | commafy:'number':2\"\n                (click)=\"openMFActions(item,MutualFundType.SUBSCRIPTION)\">\n              </tadawul-symbol-card>\n            </div>\n            <div [hidden]=\"standardMutualFundsArr?.length != 0 || !isPortfolioLoaded\">\n              <app-empty-state message=\"{{ 'homePage.emptyFunds' | translate  }}\"\n                image=\"assets/icon/no-shares.svg\" button=\"true\"\n                buttonValue=\"{{ 'homePage.investmentSubscribe' | translate  }}\"\n                (buttonClicked)=\"goToMutualFunds('investment')\">\n              </app-empty-state>\n            </div>\n          </div>\n        </ion-slide>\n        <ion-slide class=\"swiper-slide\">\n          <div class=\"symbols-ion-list\">\n            <div [hidden]=\"charitiesMutualFundsArr.length == 0\">\n              <tadawul-symbol-card *ngFor=\"let item of charitiesMutualFundsArr;let i = index;\" formName=\"home\"\n                [companyName]=\"item.name\" [changeRate]=\"item.changeRate | commafy:'number':6\"\n                [quantity]=\"item.quantity| commafy:'number':6\" [cost]=\"item.cost | commafy:'number':6\"\n                [lastPrice]=\"item.price | commafy:'number':6\"\n                [ratePercentage]=\"item.changeRatePercentage | commafy:'number':2\"\n                (click)=\"openMFActions(item,MutualFundType.REDEMPTION)\">\n              </tadawul-symbol-card>\n            </div>\n            <div [hidden]=\"charitiesMutualFundsArr?.length != 0 || !isPortfolioLoaded\">\n              <app-empty-state message=\"{{ 'homePage.emptyFunds' | translate  }}\"\n                image=\"assets/icon/no-shares.svg\" button=\"true\"\n                buttonValue=\"{{ 'homePage.charitiesSubscribe' | translate  }}\"\n                (buttonClicked)=\"goToMutualFunds('endowment')\">\n              </app-empty-state>\n            </div>\n          </div>\n        </ion-slide>\n        <ion-slide class=\"swiper-slide\">\n          <div class=\"symbols-ion-list\">\n            <div [hidden]=\"closedMutualFundsArr.length == 0 || !isPortfolioLoaded\">\n              <tadawul-symbol-card *ngFor=\"let item of closedMutualFundsArr;let i = index;\" formName=\"home\"\n                [companyName]=\"item.name\" [changeRate]=\"item.changeRate | commafy:'number':6\"\n                [quantity]=\"item.quantity| commafy:'number':6\" [cost]=\"item.cost | commafy:'number':6\"\n                [lastPrice]=\"item.price | commafy:'number':6\"\n                [ratePercentage]=\"item.changeRatePercentage | commafy:'number':2\">\n              </tadawul-symbol-card>\n            </div>\n            \n          </div>\n        </ion-slide>\n      </ion-slides>\n    </ng-container>\n  </div>   \n</div>";

/***/ })

}]);
//# sourceMappingURL=src_app_tadawul-home_home_home_module_ts.js.map