import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';


@Component({
  selector: 'tadawul-common-segment-group',
  templateUrl: './common-segment-group.component.html',
  styleUrls: ['./common-segment-group.component.scss'],
})
export class CommonSegmentGroupComponent implements OnInit {

  @Input() public activeSegment;

  @Input() firstSegmentText: string;
  @Input() secondSegmentText: string;
  @Input() thirdSegmentText: string;
  @Input() firstSegmentIcon: any;
  @Input() secondSegmentIcon: any;
  @Input() thirdSegmentIcon: any;
  @Output() segmentChange = new EventEmitter();
  constructor() {
    if(!this.activeSegment) {
      this.activeSegment = 'one'
    }
   }

  ngOnInit() {}

  public segmentChanged(event) {
    
    this.activeSegment = event.detail.value;
    console.log(this.activeSegment);
    this.segmentChange.emit(this.activeSegment);
}

}
