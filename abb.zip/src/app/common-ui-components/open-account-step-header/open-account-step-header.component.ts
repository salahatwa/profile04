import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'tadawul-open-account-step-header',
  templateUrl: './open-account-step-header.component.html',
  styleUrls: ['./open-account-step-header.component.scss'],
})
export class OpenAccountStepHeaderComponent implements OnInit {
  @Input() header: string;
  @Input() brief: string;
  constructor() { }

  ngOnInit() {}

}
