import { EventsService } from './../../events.service';
import { Component, OnInit, Input, ViewChild, ElementRef, Output, EventEmitter } from '@angular/core';
import { IonSlides, Platform } from '@ionic/angular';
@Component({
  selector: 'tadawul-slider-pager',
  templateUrl: './slider-pager.component.html',
  styleUrls: ['./slider-pager.component.scss'],
})


export class SliderPagerComponent implements OnInit {
 // @ViewChild('slidesRTL', {static: false}) slidesRTL: IonSlides;
  //@ViewChild('slidesLTR', {static: false}) slidesLTR: IonSlides;
  @Input() slideOption: any;
  @Output() forwardSlide = new EventEmitter();
  @Output() backSlide = new EventEmitter();
  direction: string;
  constructor(private event: EventsService) {
    this.event.subscribe('CHANGE_HOME_DIR', (dir) => {
      this.direction = dir;
      console.log('((((((((((((((( Direction ))))))))))))))', this.direction);
     
    });
  }

  ngOnInit() {

  }

  slideChanged(slides: IonSlides) {
    console.log(slides.getActiveIndex());
  }

  forward() {
    this.forwardSlide.emit();
  }

  back() {
    this.backSlide.emit();
  }
}
