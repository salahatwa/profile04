// Please merge from git branch 'release/phase-1-release'
///////////////////////////////////////
// Market
import { Market } from '@inma/models/market';

/**
 * MarketIndex (مؤشر السوق)
 * @returns Observable<string>
 */
// * To use inside component *.ts
Market.index.subscribe(marketIndex => {
    console.log(marketIndex);
});
// * To use inside component *.html
// {{ Markets.index | async }}

/**
 * MarketChange (تغير السوق)
 * @returns Observable<string>
 */
// * To use inside component *.ts
Market.change.subscribe(marketChange => {
    console.log(marketChange);
});
// * To use inside component *.html
// {{ Markets.change | async }}

// * Sample component usage
// <span id='index' *ngLet="{change: Markets.change | async, index: Markets.index | async} as l" [ngClass]="{'up': l.change >= 0 , 'down': l.change < 0 }">
//         <div *ngIf="l.change >= 0" id="market-up">
//             <img id="market-index-up-icon" src="assets/imgs/home/market-index-up.svg">
//             <span style="direction: ltr">{{ l.index }}</span>
//         </div>
//         <div *ngIf="l.change < 0" id="market-down">
//             <img id="market-index-down-icon" src="assets/imgs/home/market-index-down.svg">
//             <span style="direction: ltr">{{ l.index }}</span>
//         </div>
// </span>

/**
 * ChangePercentage (نسبة تغير السوق)
 * @returns Observable<string>
 */
Market.changePercentage

/**
 * Status (حالة السوق)
 * @returns Observable<string>, it will be one of the following strings ["MAINTENANCE", "PREOPEN", "OPEN", "CLOSING_AUCTION", "PRECLOSED", "CLOSED", "TRADE_AT_LAST"]
 */
Market.status

// Translations of possible MarketStatus
// {
//     "MAINTENANCE": "مغلق-صيانة",
//     "PREOPEN": "مفتوح-صيانة الأوامر",
//     "OPEN": "مفتوح-تنفيذ",
//     "CLOSING_AUCTION": "إغلاق المزاد",
//     "PRECLOSED": "تداول بعد الإغلاق",
//     "CLOSED": "مغلق",
//     "TRADE_AT_LAST": "تنفيذ بسعر الإغلاق",
//     ////
//     "MAINTENANCE": "Maintenance",
//     "PREOPEN": "Open - Orders",
//     "OPEN": "Open - Trading",
//     "CLOSING_AUCTION": "Closing Auction",
//     "PRECLOSED": "Post Trade",
//     "CLOSED": "Closed",
//     "TRADE_AT_LAST": "Trade At Last"
// }
///////////////////////////////////////
// Portfolios

import { Portfolios, PortfolioType } from '@inma/models/portfolio';


/**
 * Retreives all portfolios of all types
 * @returns Observable<Portfolio[]>
 */
// * To use inside component *.ts
Portfolios.all.subscribe(portfolios => {
    console.log(portfolios);
    // First portfolio ID
    console.log(portfolios[0]?.id);
});
// * To use inside component *.html
// {{ Portfolios.all | async }}

// <ion-slide *ngFor="let portfolio of (Portfolios.all | async)">
//   <portfolio-component [portfolio]="portfolio"></portfolio-component>
// </ion-slide>

/**
 * Get and sets current selected portfolio
 * @returns Portfolio
 */
Portfolios.current                     // Get current selected portfolio, How to call this function?
// * To use inside component *.ts
console.log(Portfolios.current?.name);

// * To use inside component *.html
// {{ Portfolios.current?.name }}

/**
 * Retreives standards portfolios
 * @returns Observable<Portfolio[]>
 */
Portfolios.allStandardPortfolios

/**
 * Retreives mutualFunds portfolios
 * @returns Observable<Portfolio[]>
 */
Portfolios.allMutualFundPortfolios

/**
 * Event fired on portfolioChanged, after you set it with `Portfolios.current = portfolio`
 * @returns Subject<Portfolio>
 */
Portfolios.onCurrentPortfolioChange.subscribe(portfolio => {
    console.log(portfolio?.id);
})

// * To use inside component *.ts
Portfolios.onCurrentPortfolioChange.subscribe(portfolio => {
    console.log(portfolio);
});

Portfolios.all.subscribe(portfolios => {
    const portfolio = portfolios[0];

    /**
     * @returns ID of portfolio
     */
    portfolio.id

    /**
     * Portfolio value (قيمة المحفظة)
     * @returns number
     */
    portfolio.portfolioValue                // Portfolio value "قيمة المحفظة"

    /**
     * Retreives portfolio buyingPower (القوة الشرائية)
     * @returns Observable<number>
     */
    portfolio.buyingPower

    /**
     * Get portfolio symbols
     * @returns Observable<Symbol[]>
     */
    portfolio.symbols

    /**
     * Get portfolio type
     * @returns enum PortfolioType
     */
    // portfolio.type === PortfolioType.MUTUAL_FUND
    // enum PortfolioType {
    //     ALL = '',
    //     STANDARD_PORTFOLIO = 'IP',
    //     MUTUAL_FUND = 'MP'
    // }
});

import { Symbols } from '@inma/models/symbol';

Symbols.all.subscribe(symbols => {
    const symbol = symbols[0];
    /**
     * Symbol's name
     * @returns Observable<string>
     */
    symbol.name

    /**
     * Symbol's abbreviation
     * @returns Observable<string>
     */
    symbol.abbreviation

    /**
     * Symbol's parameters
     * @returns Observable<SymbolParameters>
     */
    symbol.parameters


    /**
     * Get symbol's lastPrice
     * @returns Observable<number>
     */
    symbol.price                // اخر سعر
    symbol.price.subscribe(price => console.log(price));

    /**
     * Get symbol's quantity
     * @returns number
     */
    symbol.availableQuantity              // الكمية (الكمية المتاحة)
    symbol.ownedQuantity                  // الكمية المملوكة

    /**
     * Get symbol's change
     * @returns Observable<string>
     */
    symbol.change                         // التغير

    symbol.gainLossRealized               // ربح خسارة
    symbol.gainLossPercentageRealized     // نسبة ربح خسارة
    symbol.gainLossUnrealized             // ربح خسارة غير محققة
    symbol.gainLossPercentageUnrealized   // نسبة ربح خسارة غير محققة
    symbol.costTotal                      // التكلفة
    symbol.costAverage                    // متوسط التكلفة
    symbol.marketValue                    // القيمة السوقية
    ////
});


Portfolios.all.subscribe(portfolios => {
    const portfolio = portfolios[0];

    /**
     * صناديق الاستثمار
     * @returns Observable<MutualFund[]>
     */
    portfolio.standardMutualFunds

    /**
     * صناديق الوقفية
     * @returns Observable<MutualFund[]>
     */
    portfolio.charitiesMutualFunds

    /**
     * صناديق المغلقة
     * @returns Observable<MutualFund[]>
     */
    portfolio.closedMutualFunds

    portfolio.standardMutualFunds.subscribe(mutualFunds => {
        const mutualFund = mutualFunds[0];

        mutualFund.name                         // الاسم
        mutualFund.lastPrice                    // اخر سعر
        mutualFund.marketValue                  // القيمة السوقية
        mutualFund.changeRate                   // النسبة المئوية ربح و خسارة
        mutualFund.unitPrice                    // م.السعر
        mutualFund.ownedUnits                   // الكمية

        mutualFund.details.subscribe(details => {
            console.log(details.subscriptionFees);  // رسوم الاشتراك
        })

        mutualFund.gainLossUnrealized           // ربح خسارة (غير محققة)

    });
});
