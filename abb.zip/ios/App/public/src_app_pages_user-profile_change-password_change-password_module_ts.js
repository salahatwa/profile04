"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_user-profile_change-password_change-password_module_ts"],{

/***/ 96854:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/user-profile/change-password/change-password-routing.module.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChangePasswordPageRoutingModule": () => (/* binding */ ChangePasswordPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _change_password_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./change-password.page */ 21429);




const routes = [
    {
        path: '',
        component: _change_password_page__WEBPACK_IMPORTED_MODULE_0__.ChangePasswordPage
    }
];
let ChangePasswordPageRoutingModule = class ChangePasswordPageRoutingModule {
};
ChangePasswordPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ChangePasswordPageRoutingModule);



/***/ }),

/***/ 49638:
/*!******************************************************************************!*\
  !*** ./src/app/pages/user-profile/change-password/change-password.module.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChangePasswordPageModule": () => (/* binding */ ChangePasswordPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _change_password_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./change-password-routing.module */ 96854);
/* harmony import */ var _change_password_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./change-password.page */ 21429);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);









let ChangePasswordPageModule = class ChangePasswordPageModule {
};
ChangePasswordPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _change_password_routing_module__WEBPACK_IMPORTED_MODULE_0__.ChangePasswordPageRoutingModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateModule.forChild()
        ],
        declarations: [_change_password_page__WEBPACK_IMPORTED_MODULE_1__.ChangePasswordPage]
    })
], ChangePasswordPageModule);



/***/ }),

/***/ 21429:
/*!****************************************************************************!*\
  !*** ./src/app/pages/user-profile/change-password/change-password.page.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChangePasswordPage": () => (/* binding */ ChangePasswordPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _change_password_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./change-password.page.html?ngResource */ 90484);
/* harmony import */ var _change_password_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./change-password.page.scss?ngResource */ 86290);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _inma_models_change_password_change_password_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/models/change-password/change-password.model */ 57569);
/* harmony import */ var _password_hint_password_hint_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./password-hint/password-hint.component */ 49635);
/* harmony import */ var _inma_helpers_translations__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @inma/helpers/translations */ 69353);
/* harmony import */ var _change_password_translations__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./change-password.translations */ 99939);
/* harmony import */ var _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @inma/helpers/settings */ 96892);














let ChangePasswordPage = class ChangePasswordPage {
    constructor(formBuilder, sharedData, navCtrl, popoverController, toastController) {
        this.formBuilder = formBuilder;
        this.sharedData = sharedData;
        this.navCtrl = navCtrl;
        this.popoverController = popoverController;
        this.toastController = toastController;
        this.t = _change_password_translations__WEBPACK_IMPORTED_MODULE_6__.ChangePasswordTranslations;
        this.showCurrentPassword = false;
        this.showNewPassword = false;
        this.showConfirmNewPassword = false;
        this.showIconSRC = "";
        this.hideIconSRC = "";
        this.currentPassword = '';
        this.newPassword = '';
        this.confirmNewPassword = '';
        this.buildForm();
    }
    buildForm() {
        // const englishOnlyTester = /^[^\u0621-\u064A\u0660-\u0669]*$/;
        this.form = this.formBuilder.group({
            currentPassword: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.minLength(8), _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.maxLength(16), _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.pattern('[a-zA-Z0-9 ]*'), _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required])],
            newPassword: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.minLength(8), _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.maxLength(16), _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.pattern('[a-zA-Z0-9 ]*'), _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required])],
            confirmNewPassword: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required])]
        }, { validator: this.matchingPasswords('newPassword', 'confirmNewPassword') });
    }
    get f() { return this.form.controls; }
    ngOnInit() {
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_7__.Settings.getUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_7__.Settings.preferedThemeKey).subscribe(val => {
            if (val == null || val == "light-theme") {
                this.showIconSRC = "assets/icon/show-password.svg";
                this.hideIconSRC = "assets/icon/hide-password.svg";
            }
            else {
                this.showIconSRC = "assets/icon/show-password-dark.svg";
                this.hideIconSRC = "assets/icon/hide-password-dark.svg";
            }
        });
    }
    matchingPasswords(passwordKey, confirmPasswordKey) {
        return (group) => {
            let password = group.controls[passwordKey];
            let confirmPassword = group.controls[confirmPasswordKey];
            if (confirmPassword.errors && !confirmPassword.errors.matchingPasswords) {
                return;
            }
            if (password.value !== confirmPassword.value) {
                confirmPassword.setErrors({ matchingPasswords: true });
            }
            else {
                confirmPassword.setErrors(null);
            }
        };
    }
    togglePassword(name) {
        if (name === "current") {
            this.showCurrentPassword = !this.showCurrentPassword;
        }
        if (name === "new") {
            this.showNewPassword = !this.showNewPassword;
        }
        if (name === "confirm") {
            this.showConfirmNewPassword = !this.showConfirmNewPassword;
        }
    }
    saveChanges(form) {
        const oldPass = form.value.currentPassword;
        // console.log(oldPass, 'oldPass');
        const newPass = form.value.newPassword;
        // console.log(newPass, 'newPass');
        _inma_models_change_password_change_password_model__WEBPACK_IMPORTED_MODULE_3__.ChangePassword.changePassword(oldPass, newPass).subscribe(() => {
            this.sharedData.setSharedData(true, 'password_changed');
            // console.log("inside subscribe");
            this.navCtrl.navigateForward('/settings');
        }, err => {
            // this.presentToast();
            // console.log(err);
        });
    }
    // async presentToast() {
    //   const toast = await this.toastController.create({
    //     message: 'عذرا، حدث خطأ الرجاء المحاولة مرة اخرى',
    //     duration: 4000,
    //     cssClass: 'info-alert'
    //   });
    //   toast.present();
    // }
    showHint(event) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            const popover = yield this.popoverController.create({
                component: _password_hint_password_hint_component__WEBPACK_IMPORTED_MODULE_4__.PasswordHintComponent,
                // cssClass: 'my-custom-class',
                // event: event,
                translucent: true,
                mode: 'md'
            });
            return yield popover.present();
        });
    }
    forgetPassword() {
        this.navCtrl.navigateForward('forget-username-password/forgot-password');
    }
};
ChangePasswordPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormBuilder },
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_2__.SharedDataService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.PopoverController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.ToastController }
];
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_inma_helpers_translations__WEBPACK_IMPORTED_MODULE_5__.Translations)(),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", Object)
], ChangePasswordPage.prototype, "t", void 0);
ChangePasswordPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        selector: 'tadawul-change-password',
        template: _change_password_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_change_password_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormBuilder,
        src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_2__.SharedDataService,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.NavController,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.PopoverController,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.ToastController])
], ChangePasswordPage);



/***/ }),

/***/ 99939:
/*!************************************************************************************!*\
  !*** ./src/app/pages/user-profile/change-password/change-password.translations.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChangePasswordTranslations": () => (/* binding */ ChangePasswordTranslations)
/* harmony export */ });
class Translations {
    constructor() {
        this.CHANGE_PASSWORD = ['تغيير كلمة المرور', 'Change Password'];
        this.CURRENT_PASSWORD = ['كلمة المرور الحالية', 'Current Password'];
        this.FORGOT_PASSWORD = ['نسيت كلمة المرور', 'Forgot Password'];
        this.NEW_PASSWORD = ['كلمة المرور الجديدة', 'New Password'];
        this.CONFIRM_NEW_PASSWORD = ['تأكيد كلمة المرور الجديدة', 'Confirm New Password'];
        this.SAVE_CHANGES = ['حفظ التغييرات', 'Save Changes'];
        this.PASSWORD_RULES = [
            'كلمة المرور يجب ان لاتقل عن 8 خانات ولا تزيد عن 16\n\rكلمة المرور يجب ان تحتوي على الاقل على حرف واحد او رقم واحد\n\rكلمة المرور يجب ان لا تحتوي على فراغات\n\rكلمة المرور يجب ان لا تكون مطابقة لاسم المستخدم\n\rكلمة المرور حساسة لحالة الحروف الصغيرة والكبيرة\n\rكلمة المرور يجب ان لا تحتوي على رموز',
            'Password should be at least 8 characters and not more than 16 \n\r Password should have at least one charachter or one digit \n\r Password should not have spaces \n\r Password should not be the same as user name \n\r Password is case sensitive \n\r Password should not have symbols'
        ];
        this.CURRENT_PASSWORD_REQUIRED = ['الرجاء ادخال كلمة المرور الحالية', 'Please enter the current password'];
        this.NEW_PASSWORD_REQUIRED = ['الرجاء ادخال كلمة المرور الجديدة', 'Please enter the new password'];
        this.CONFIRM_PASSWORD_REQUIRED = ['الرجاء ادخال تأكيد كلمة المرور الجديدة', 'Please enter the confirm password'];
        this.PASSWORD_PATTERN = ['كلمة المرور يجب ان لا تحتوي على رموز', 'Password should not have symbols '];
        this.PASSWORD_MIN = ['كلمة المرور يجب أن لا تقل عن ٨ خانات', 'Password should be at least 8 characters'];
        this.PASSWORD_MAX = ['كلمة المرور يجب أن لا تكون اكثر من ١٦ خانة', 'Password should not be more than 16 characters'];
        this.UNMATCHED_PASSWORD = ['تأكيد كلمة المرور يجب ان يكون مطابق لكلمة المرور الجديدة', 'Confirm password must match the new password'];
    }
}
const ChangePasswordTranslations = new Translations();


/***/ }),

/***/ 49635:
/*!*********************************************************************************************!*\
  !*** ./src/app/pages/user-profile/change-password/password-hint/password-hint.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PasswordHintComponent": () => (/* binding */ PasswordHintComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _password_hint_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./password-hint.component.html?ngResource */ 20225);
/* harmony import */ var _password_hint_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./password-hint.component.scss?ngResource */ 85151);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_helpers_translations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/helpers/translations */ 69353);
/* harmony import */ var _change_password_translations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../change-password.translations */ 99939);






let PasswordHintComponent = class PasswordHintComponent {
    constructor() {
        this.t = _change_password_translations__WEBPACK_IMPORTED_MODULE_3__.ChangePasswordTranslations;
    }
    ngOnInit() { }
};
PasswordHintComponent.ctorParameters = () => [];
(0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_inma_helpers_translations__WEBPACK_IMPORTED_MODULE_2__.Translations)(),
    (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__metadata)("design:type", Object)
], PasswordHintComponent.prototype, "t", void 0);
PasswordHintComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'tadawul-password-hint',
        template: _password_hint_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_password_hint_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__metadata)("design:paramtypes", [])
], PasswordHintComponent);



/***/ }),

/***/ 57569:
/*!*******************************************************************!*\
  !*** ./src/app/🌱models/change-password/change-password.model.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChangePassword": () => (/* binding */ ChangePassword),
/* harmony export */   "ChangePasswordModel": () => (/* binding */ ChangePasswordModel)
/* harmony export */ });
/* harmony import */ var _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/helpers/http */ 36802);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ 86942);


// import { cat } from "rxjs/observable/ErrorObservable";
class ChangePasswordModel {
    changePassword(oldPass, newPass) {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request("/ForgetPassword/ForgetPassword/changePassword", { oldPass: oldPass, newPass: newPass })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.map)(response => { return response; }));
    }
}
const ChangePassword = new ChangePasswordModel;


/***/ }),

/***/ 86290:
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/user-profile/change-password/change-password.page.scss?ngResource ***!
  \*****************************************************************************************/
/***/ ((module) => {

module.exports = "ion-item {\n  --border-color: transparent;\n  color: var(--ion-color-primary-txt);\n}\n\nion-toolbar {\n  --background: #005157;\n  --color: white;\n}\n\nion-label {\n  font-weight: bold;\n}\n\nion-back-button {\n  color: white;\n}\n\nion-input {\n  --padding-start: 8px!important;\n  border: solid 1px #99b9bc;\n  --padding-end: 10%;\n}\n\n.pwdIcon {\n  position: absolute;\n  top: 40px;\n  right: 85%;\n  padding: 8px 8px;\n  z-index: 2;\n}\n\n:host-context(html[dir=ltr]) .pwdIcon {\n  left: 85%;\n  right: auto;\n}\n\nion-text {\n  color: #f5455a;\n  font-size: 12px;\n  text-decoration: underline;\n}\n\n.validator-error {\n  color: #f5455a;\n  font-size: 14px;\n}\n\n.validator-error .error-msg {\n  display: none;\n}\n\n.validator-error .error-msg:first-child {\n  display: block;\n}\n\n.pwd-hint {\n  position: absolute;\n  top: 10%;\n  right: 35%;\n}\n\n:host-context(html[dir=ltr]) .pwd-hint {\n  left: 35%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoYW5nZS1wYXNzd29yZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUE7RUFDSSwyQkFBQTtFQUVBLG1DQUFBO0FBRko7O0FBS0E7RUFDSSxxQkFBQTtFQUNBLGNBQUE7QUFGSjs7QUFLQTtFQUNJLGlCQUFBO0FBRko7O0FBS0E7RUFDSSxZQUFBO0FBRko7O0FBS0E7RUFDSSw4QkFBQTtFQUNBLHlCQUFBO0VBQ0Esa0JBQUE7QUFGSjs7QUFLQTtFQUNJLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7RUFDQSxnQkFBQTtFQUNBLFVBQUE7QUFGSjs7QUFNSTtFQUNJLFNBQUE7RUFDQSxXQUFBO0FBSFI7O0FBUUE7RUFDSSxjQUFBO0VBQ0EsZUFBQTtFQUNBLDBCQUFBO0FBTEo7O0FBUUE7RUFDSSxjQUFBO0VBQ0EsZUFBQTtBQUxKOztBQVFBO0VBRUksYUFBQTtBQU5KOztBQVNBO0VBQ0ksY0FBQTtBQU5KOztBQVNBO0VBQ0ksa0JBQUE7RUFDQSxRQUFBO0VBQ0EsVUFBQTtBQU5KOztBQVVJO0VBQ0ksU0FBQTtBQVBSIiwiZmlsZSI6ImNoYW5nZS1wYXNzd29yZC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcblxuaW9uLWl0ZW0ge1xuICAgIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgICAvLyBjb2xvcjogIzAwNTQ1NztcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktdHh0KTtcbn1cblxuaW9uLXRvb2xiYXIge1xuICAgIC0tYmFja2dyb3VuZDogIzAwNTE1NztcbiAgICAtLWNvbG9yOiB3aGl0ZTtcbn1cblxuaW9uLWxhYmVsIHtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbn1cblxuaW9uLWJhY2stYnV0dG9uIHtcbiAgICBjb2xvcjogd2hpdGU7XG59XG5cbmlvbi1pbnB1dCB7XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiA4cHghaW1wb3J0YW50O1xuICAgIGJvcmRlcjogc29saWQgMXB4ICM5OWI5YmM7XG4gICAgLS1wYWRkaW5nLWVuZDogMTAlO1xufVxuXG4ucHdkSWNvbiB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHRvcDogNDBweDtcbiAgICByaWdodDogODUlO1xuICAgIHBhZGRpbmc6IDhweCA4cHg7XG4gICAgei1pbmRleDogMjtcbn1cblxuOmhvc3QtY29udGV4dChodG1sW2Rpcj1sdHJdKSB7XG4gICAgLnB3ZEljb24ge1xuICAgICAgICBsZWZ0OiA4NSU7XG4gICAgICAgIHJpZ2h0OiBhdXRvO1xuICAgIH1cblxufVxuXG5pb24tdGV4dCB7XG4gICAgY29sb3I6ICNmNTQ1NWE7XG4gICAgZm9udC1zaXplOiAxMnB4O1xuICAgIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xufVxuXG4udmFsaWRhdG9yLWVycm9yIHtcbiAgICBjb2xvcjogI2Y1NDU1YTtcbiAgICBmb250LXNpemU6IDE0cHg7XG59XG5cbi52YWxpZGF0b3ItZXJyb3IgLmVycm9yLW1zZ3tcbiAgICAvLyBIaWRkZW4gYnkgZGVmYXVsdFxuICAgIGRpc3BsYXk6IG5vbmU7XG59XG5cbi52YWxpZGF0b3ItZXJyb3IgLmVycm9yLW1zZzpmaXJzdC1jaGlsZCB7XG4gICAgZGlzcGxheTogYmxvY2s7XG59XG5cbi5wd2QtaGludCB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHRvcDogMTAlO1xuICAgIHJpZ2h0OiAzNSU7XG59XG5cbjpob3N0LWNvbnRleHQoaHRtbFtkaXI9bHRyXSkge1xuICAgIC5wd2QtaGludCB7XG4gICAgICAgIGxlZnQ6IDM1JTtcbiAgICAgICAgLy8gcmlnaHQ6IGF1dG87XG4gICAgfVxuXG59XG4iXX0= */";

/***/ }),

/***/ 85151:
/*!**********************************************************************************************************!*\
  !*** ./src/app/pages/user-profile/change-password/password-hint/password-hint.component.scss?ngResource ***!
  \**********************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwYXNzd29yZC1oaW50LmNvbXBvbmVudC5zY3NzIn0= */";

/***/ }),

/***/ 90484:
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/user-profile/change-password/change-password.page.html?ngResource ***!
  \*****************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button [text]=\"''\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{'changePassword.CHANGE_PASSWORD' | translate}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <!-- [formGroup]=\"form\" (ngSubmit)=\"login(form)\" class=\"login-form ion-padding\" -->\n  <form [formGroup]=\"form\" (ngSubmit)=\"saveChanges(form)\">\n      <ion-list>\n      <ion-item>\n        <!-- <app-input [form]=\"form\" [formControl]=\"oldPassword\" label=\"كلمة المرور الحالية\" name=\"password\" type=\"password\" [(model)]=\"oldPassword\" ngDefaultControl></app-input> -->\n          <!-- <ion-label>Default Label</ion-label> -->\n          <ion-label position=\"stacked\">{{'changePassword.CURRENT_PASSWORD' | translate}}</ion-label>\n          <ion-input [type]=\"showCurrentPassword ? 'text' : 'password'\" name=\"currentPassword\"\n          formControlName=\"currentPassword\" [(ngModel)]=\"currentPassword\"\n          ></ion-input>\n          <img class=\"pwdIcon\" (click)=\"togglePassword('current')\" id=\"currentPassword\" [src]=\"showCurrentPassword ? hideIconSRC : showIconSRC \" >\n          <div *ngIf=\"f.currentPassword.errors && f.currentPassword.touched\" class=\"validator-error\">\n              <div class=\"error-msg\" *ngIf=\"f.currentPassword.errors.required\">{{'changePassword.CURRENT_PASSWORD_REQUIRED' | translate}}</div>\n              <div class=\"error-msg\" *ngIf=\"f.currentPassword.errors.pattern\">{{'changePassword.PASSWORD_PATTERN' | translate}}</div>\n              <div class=\"error-msg\" *ngIf=\"f.currentPassword.errors.minlength\">{{'changePassword.PASSWORD_MIN' | translate}}</div>\n              <div class=\"error-msg\" *ngIf=\"f.currentPassword.errors.maxlength\">{{'changePassword.PASSWORD_MAX' | translate}}</div>\n          </div>\n          <ion-text (click)=\"forgetPassword()\">{{'changePassword.FORGOT_PASSWORD' | translate}}</ion-text>\n      </ion-item>\n\n      <ion-item>\n        <ion-label position=\"stacked\">{{'changePassword.NEW_PASSWORD' | translate}}</ion-label>\n        <ion-icon class=\"pwd-hint\" (click)=\"showHint($event)\" name=\"help-circle\"></ion-icon>\n        <ion-input [type]=\"showNewPassword ? 'text' : 'password'\" name=\"newPassword\"\n        formControlName=\"newPassword\" [(ngModel)]=\"newPassword\"\n        ></ion-input>\n        <img class=\"pwdIcon\" (click)=\"togglePassword('new')\" id=\"newPassword\" [src]=\"showNewPassword ? hideIconSRC : showIconSRC \" >\n        <div *ngIf=\"f.newPassword.errors && f.newPassword.touched\" class=\"validator-error\">\n          <div class=\"error-msg\" *ngIf=\"f.newPassword.errors.required\"> {{'changePassword.NEW_PASSWORD_REQUIRED' | translate}}</div>\n          <div class=\"error-msg\" *ngIf=\"f.newPassword.errors.pattern\">{{'changePassword.PASSWORD_PATTERN' | translate}}</div>\n          <div class=\"error-msg\" *ngIf=\"f.newPassword.errors.minlength\">{{'changePassword.PASSWORD_MIN' | translate}}</div>\n          <div class=\"error-msg\" *ngIf=\"f.newPassword.errors.maxlength\">{{'changePassword.PASSWORD_MAX' | translate}}</div>\n      </div>\n        \n      </ion-item>\n\n      <ion-item>\n        <ion-label position=\"stacked\">{{'changePassword.CONFIRM_NEW_PASSWORD' | translate}}</ion-label>\n        <ion-input [type]=\"showConfirmNewPassword ? 'text' : 'password'\" name=\"confirmNewPassword\"\n        formControlName=\"confirmNewPassword\" [(ngModel)]=\"confirmNewPassword\"\n        ></ion-input>\n        <img class=\"pwdIcon\" (click)=\"togglePassword('confirm')\" id=\"confirmNewPassword\" [src]=\"showConfirmNewPassword ? hideIconSRC : showIconSRC \" >\n        <div *ngIf=\"f.confirmNewPassword.errors && f.confirmNewPassword.touched\" class=\"validator-error\">\n          <div *ngIf=\"f.confirmNewPassword.errors.required\">{{'changePassword.CONFIRM_PASSWORD_REQUIRED' | translate}}</div>\n          <div *ngIf=\"f.confirmNewPassword.errors.matchingPasswords\">{{'changePassword.UNMATCHED_PASSWORD' | translate}}</div>\n        </div>\n        \n      </ion-item>\n    </ion-list>\n    <ion-grid class=\"ion-padding\">\n      <app-button\n      class=\"save-button\"\n      [disabled]=\"!form.valid\" \n      expand=\"block\"\n      type=\"submit\"\n      >\n      {{'changePassword.SAVE_CHANGES' | translate}}\n      </app-button>\n    </ion-grid>\n</form>\n  \n</ion-content>";

/***/ }),

/***/ 20225:
/*!**********************************************************************************************************!*\
  !*** ./src/app/pages/user-profile/change-password/password-hint/password-hint.component.html?ngResource ***!
  \**********************************************************************************************************/
/***/ ((module) => {

module.exports = "<!-- <ion-content> -->\n<!-- <ion-label> -->\n     {{'changePassword.PASSWORD_RULES' | translate}}\n<!-- </ion-label> -->\n<!-- </ion-content> -->\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_user-profile_change-password_change-password_module_ts.js.map