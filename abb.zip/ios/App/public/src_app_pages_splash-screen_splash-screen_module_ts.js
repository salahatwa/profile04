"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_splash-screen_splash-screen_module_ts"],{

/***/ 38179:
/*!*********************************************************************!*\
  !*** ./src/app/pages/splash-screen/splash-screen-routing.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SplashScreenPageRoutingModule": () => (/* binding */ SplashScreenPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _splash_screen_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./splash-screen.page */ 72996);




const routes = [
    {
        path: '',
        component: _splash_screen_page__WEBPACK_IMPORTED_MODULE_0__.SplashScreenPage
    }
];
let SplashScreenPageRoutingModule = class SplashScreenPageRoutingModule {
};
SplashScreenPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SplashScreenPageRoutingModule);



/***/ }),

/***/ 52273:
/*!*************************************************************!*\
  !*** ./src/app/pages/splash-screen/splash-screen.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SplashScreenPageModule": () => (/* binding */ SplashScreenPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _splash_screen_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./splash-screen-routing.module */ 38179);
/* harmony import */ var _splash_screen_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./splash-screen.page */ 72996);







let SplashScreenPageModule = class SplashScreenPageModule {
};
SplashScreenPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _splash_screen_routing_module__WEBPACK_IMPORTED_MODULE_0__.SplashScreenPageRoutingModule
        ],
        declarations: [_splash_screen_page__WEBPACK_IMPORTED_MODULE_1__.SplashScreenPage]
    })
], SplashScreenPageModule);



/***/ }),

/***/ 72996:
/*!***********************************************************!*\
  !*** ./src/app/pages/splash-screen/splash-screen.page.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SplashScreenPage": () => (/* binding */ SplashScreenPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _splash_screen_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./splash-screen.page.html?ngResource */ 88582);
/* harmony import */ var _splash_screen_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./splash-screen.page.scss?ngResource */ 55601);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);





let SplashScreenPage = class SplashScreenPage {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
        setTimeout(() => {
            this.router.navigate(['login']);
        }, 3000);
    }
};
SplashScreenPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
SplashScreenPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'tadawul-splash-screen',
        template: _splash_screen_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_splash_screen_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__metadata)("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__.Router])
], SplashScreenPage);



/***/ }),

/***/ 55601:
/*!************************************************************************!*\
  !*** ./src/app/pages/splash-screen/splash-screen.page.scss?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = ".splash-screen {\n  --background: url(\"/assets/login/alinma-pattern-bg.svg\") repeat top left #005157;\n  --color: #99b9bc;\n}\n.splash-screen .gradient-bg {\n  content: \"\";\n  position: fixed;\n  height: 100vh;\n  width: 100%;\n  background: linear-gradient(to bottom, #00515700 25%, #005157 35%);\n  z-index: -1;\n  background-repeat: no-repeat;\n  background-position: center center;\n  background-size: cover;\n}\n.splash-screen .splash-content-wrapper {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  height: 100vh;\n}\n.splash-screen .splash-content-wrapper .logo-img {\n  width: 245px;\n  max-width: 80%;\n  margin: auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNwbGFzaC1zY3JlZW4ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZ0ZBQUE7RUFDQSxnQkFBQTtBQUNKO0FBRUk7RUFDRSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGFBQUE7RUFDQSxXQUFBO0VBQ0Esa0VBQUE7RUFDQSxXQUFBO0VBQ0EsNEJBQUE7RUFDQSxrQ0FBQTtFQUNBLHNCQUFBO0FBQU47QUFHSTtFQUNJLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsYUFBQTtBQURSO0FBSVE7RUFDRSxZQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7QUFGViIsImZpbGUiOiJzcGxhc2gtc2NyZWVuLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zcGxhc2gtc2NyZWVuIHtcbiAgICAtLWJhY2tncm91bmQ6IHVybCgnL2Fzc2V0cy9sb2dpbi9hbGlubWEtcGF0dGVybi1iZy5zdmcnKSByZXBlYXQgdG9wIGxlZnQgIzAwNTE1NztcbiAgICAtLWNvbG9yOiAjOTliOWJjO1xuICAgIFxuICBcbiAgICAuZ3JhZGllbnQtYmcge1xuICAgICAgY29udGVudDogJyc7XG4gICAgICBwb3NpdGlvbjogZml4ZWQ7XG4gICAgICBoZWlnaHQ6IDEwMHZoO1xuICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLCAjMDA1MTU3MDAgMjUlLCAjMDA1MTU3IDM1JSk7XG4gICAgICB6LWluZGV4OiAtMTtcbiAgICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gICAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXIgY2VudGVyO1xuICAgICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcbiAgICB9XG5cbiAgICAuc3BsYXNoLWNvbnRlbnQtd3JhcHBlciB7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgICBoZWlnaHQ6IDEwMHZoO1xuXG4gICAgXG4gICAgICAgIC5sb2dvLWltZyB7XG4gICAgICAgICAgd2lkdGg6IDI0NXB4O1xuICAgICAgICAgIG1heC13aWR0aDogODAlO1xuICAgICAgICAgIG1hcmdpbjogYXV0bztcbiAgICAgICAgfVxuICAgIH1cbn0iXX0= */";

/***/ }),

/***/ 88582:
/*!************************************************************************!*\
  !*** ./src/app/pages/splash-screen/splash-screen.page.html?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content class=\"splash-screen\">\n  <div class=\"gradient-bg\"></div>\n  <div class=\"splash-content-wrapper\">\n    <img src=\"./../../../assets/splash-logo.svg\" class=\"logo-img\" />\n  </div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_splash-screen_splash-screen_module_ts.js.map