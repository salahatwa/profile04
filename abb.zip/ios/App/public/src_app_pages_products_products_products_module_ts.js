"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_products_products_products_module_ts"],{

/***/ 33781:
/*!********************************************************************!*\
  !*** ./src/app/pages/products/products/products-routing.module.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductsPageRoutingModule": () => (/* binding */ ProductsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _products_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./products.page */ 54843);




const routes = [
    {
        path: '',
        component: _products_page__WEBPACK_IMPORTED_MODULE_0__.ProductsPage
    }
];
let ProductsPageRoutingModule = class ProductsPageRoutingModule {
};
ProductsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ProductsPageRoutingModule);



/***/ }),

/***/ 8518:
/*!************************************************************!*\
  !*** ./src/app/pages/products/products/products.module.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductsPageModule": () => (/* binding */ ProductsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _products_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./products-routing.module */ 33781);
/* harmony import */ var _products_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./products.page */ 54843);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);









let ProductsPageModule = class ProductsPageModule {
};
ProductsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _products_routing_module__WEBPACK_IMPORTED_MODULE_0__.ProductsPageRoutingModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateModule.forChild()
        ],
        declarations: [_products_page__WEBPACK_IMPORTED_MODULE_1__.ProductsPage]
    })
], ProductsPageModule);



/***/ }),

/***/ 54843:
/*!**********************************************************!*\
  !*** ./src/app/pages/products/products/products.page.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductsPage": () => (/* binding */ ProductsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _products_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./products.page.html?ngResource */ 22772);
/* harmony import */ var _products_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./products.page.scss?ngResource */ 6115);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_models_products_products_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/models/products/products.model */ 37426);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var src_app_models_products_product_status__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/🌱models/products/product-status */ 69082);









let ProductsPage = class ProductsPage {
    constructor(navCtrl, translate, sharedData) {
        this.navCtrl = navCtrl;
        this.translate = translate;
        this.sharedData = sharedData;
        this.ProductStatus = src_app_models_products_product_status__WEBPACK_IMPORTED_MODULE_4__.ProductStatus;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        _inma_models_products_products_model__WEBPACK_IMPORTED_MODULE_2__.Products.all.subscribe(res => {
            console.log(res);
            this.products = res;
        });
    }
    goToProduct(product) {
        console.log(product);
        this.sharedData.setSharedData(product, "sharedProduct");
        this.navCtrl.navigateForward('main/product-details');
    }
};
ProductsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateService },
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_3__.SharedDataService }
];
ProductsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'tadawul-products',
        template: _products_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_products_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__metadata)("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController,
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateService,
        src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_3__.SharedDataService])
], ProductsPage);



/***/ }),

/***/ 6115:
/*!***********************************************************************!*\
  !*** ./src/app/pages/products/products/products.page.scss?ngResource ***!
  \***********************************************************************/
/***/ ((module) => {

module.exports = "ion-header ion-toolbar {\n  --background: #005157;\n  color: #fff;\n}\n\nion-list ion-item .menu-brief {\n  font-weight: bold;\n}\n\nion-list ion-item .product-status {\n  font-size: 10px;\n  font-weight: bold;\n  padding: 2px 8px;\n  background: #E6EFF0;\n  border-radius: 3px;\n  color: #005157;\n}\n\nion-list ion-item .product-status.active {\n  background: #2ebd85;\n  color: #FFFFFF;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2R1Y3RzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFBO0VBQ0EsV0FBQTtBQUNGOztBQVVNO0VBQ0UsaUJBQUE7QUFQUjs7QUFVTTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7QUFSUjs7QUFVUTtFQUNFLG1CQUFBO0VBQ0EsY0FBQTtBQVJWIiwiZmlsZSI6InByb2R1Y3RzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXIgaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6ICMwMDUxNTc7XG4gIGNvbG9yOiAjZmZmO1xufVxuXG5pb24tbGlzdCB7XG4gIGlvbi1pdGVtIHtcbiAgICAgIC8vIC0tbWluLWhlaWdodDogNTVweCAhaW1wb3J0YW50O1xuICAgICAgLy8gYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlNmVmZjA7XG4gICAgICAvLyBtYXJnaW4taW5saW5lLXN0YXJ0OiAxNnB4O1xuICAgICAgLy8gLS1wYWRkaW5nLXN0YXJ0OiAwO1xuICAgICAgLy8gLS1pbm5lci1ib3JkZXItd2lkdGg6IDA7XG5cbiAgICAgIC5tZW51LWJyaWVmIHtcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICB9XG5cbiAgICAgIC5wcm9kdWN0LXN0YXR1cyB7XG4gICAgICAgIGZvbnQtc2l6ZTogMTBweDtcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICAgIHBhZGRpbmc6IDJweCA4cHg7XG4gICAgICAgIGJhY2tncm91bmQ6ICNFNkVGRjA7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDNweDtcbiAgICAgICAgY29sb3I6ICMwMDUxNTc7XG5cbiAgICAgICAgJi5hY3RpdmUge1xuICAgICAgICAgIGJhY2tncm91bmQ6ICMyZWJkODU7XG4gICAgICAgICAgY29sb3I6ICNGRkZGRkY7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgfVxufSJdfQ== */";

/***/ }),

/***/ 22772:
/*!***********************************************************************!*\
  !*** ./src/app/pages/products/products/products.page.html?ngResource ***!
  \***********************************************************************/
/***/ ((module) => {

module.exports = "<ion-header translucent>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\"></ion-back-button>\n    </ion-buttons>\n    <ion-title slot=\"start\">{{ 'product.PRODUCTS' | translate }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-list class=\"list-group\" >\n    <ion-item button *ngFor=\"let product of products\" (click)=\"goToProduct(product)\">\n      <ion-label>\n        <div class=\"menu-title\">{{product?.name}}</div>\n        <div class=\"menu-brief\">{{product?.plans[0]?.price}} {{translate.instant('product.'+product?.plans[0]?.currency)}} / {{product?.plans[0]?.months}} {{((product?.plans[0]?.months == 1) ? 'product.MONTH' : 'product.MONTHS' )| translate}}</div>\n      </ion-label>\n      <ion-label slot=\"end\">\n        <div class=\"product-status  {{product?.status === ProductStatus.Subscribed ? 'active' : ''}}\">{{ translate.instant('product.'+ product?.status) }}</div>\n      </ion-label>\n    </ion-item>\n  </ion-list>\n\n  <!-- <tadawul-product-box *ngFor=\"let product of products\"  class=\"ion-margin-bottom display-block\"\n    (click)=\"goToProduct(product)\"\n    title=\"{{product?.name}}\" \n    label=\"{{t[product?.status]}}\" \n    price-text=\"{{product?.plans[0]?.price}} {{t[product?.plans[0]?.currency]}} / {{product?.plans[0]?.months}} {{(product?.plans[0]?.months == 1) ? 'product.MONTH : 'product.MONTHS}}\" \n    active=\"{{(product?.status === ProductStatus.Subscribed) ? 'true' : 'false'}}\">\n  </tadawul-product-box> -->\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_products_products_products_module_ts.js.map