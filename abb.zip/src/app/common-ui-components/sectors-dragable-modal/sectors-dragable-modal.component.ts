import { TranslateService } from '@ngx-translate/core';
import { Component, Input, NgZone, OnInit } from '@angular/core';
import { Injector } from '@inma/helpers/injector';
import { Translations } from '@inma/helpers/translations';
import { Watchlist, Watchlists } from '@inma/models/watchlist';
import {  ModalController } from '@ionic/angular';
import { LocalizedString } from 'src/app/helpers/localized-string';
import { WatchlistTranslations } from 'src/app/pages/watchlists/watchlist.translations';

@Component({
  selector: 'tadawul-sectors-dragable-modal',
  templateUrl: './sectors-dragable-modal.component.html',
  styleUrls: ['./sectors-dragable-modal.component.scss'],
})
export class SectorsDragableModalComponent implements OnInit {
  Watchlists = Watchlists;
  @Input() sectorData: any;
  allSector: any;
  @Translations()
    t = WatchlistTranslations;
  // public sector:any;
  constructor(
    private modalControl: ModalController,
    private translate: TranslateService) { }

  ngOnInit() {
    this.Watchlists.allSectors.subscribe(Sectors => {
    this.allSector = Sectors;
    this.allSector.forEach((sec: Watchlist) => {
      sec._localizeName = new LocalizedString(sec._name, sec._nameAr, this.translate);
    });
    console.log(this.allSector);

  //  Watchlists.disconnectToStream();

    const zone = Injector.get(NgZone);
    Watchlists.connectToStream().subscribe((sectorInfoMessage) => {
        zone.run(() => {
          const streamedMarketInfo = JSON.parse(sectorInfoMessage["data"]);
          // this._allSectors.next(streamedMarketInfo);
          console.log(streamedMarketInfo);

        })

      });
    });
  }
  ionViewWillEnter() {

    
    
  }
  ionViewDidLeave() {
   // Watchlists.disconnectToStream();
  }

  closeModal(sector,i) {
    sector.i = i;
    const data = sector;
    this.modalControl.dismiss(data);
    
  }
}
