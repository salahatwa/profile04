import { AppTranslations } from '../../app.translations';

class Translations extends AppTranslations {
    ALINMA_INVESTMENT = ["الإنماء للاستثمار", "Alinma Investment"];

}


export const ShareModalTranslations = new Translations();