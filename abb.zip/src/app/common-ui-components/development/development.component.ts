import { Component, AfterViewInit, ElementRef, HostBinding, Input, ViewEncapsulation } from '@angular/core';
// import createReport from 'docx-templates';
import $ from 'jquery';
import { Environment } from '@inma/environment';

import { Users } from '@inma/models/users';
const createReport = null;
var inputElement;
@Component({
  selector: 'development-component',
  templateUrl: 'development.component.html',
  styleUrls: ['development.component.scss'],
  encapsulation: ViewEncapsulation.None
  // styles: [`
  //   display: block;

  //   color: white;
  //   display: block;
  //   position: absolute;
  //   width: 100%;
  //   padding: 16px;
  //   background: #83AFBA;
  //   text-align: center;`]
})
export class DevelopmentComponent implements AfterViewInit {

  Users = Users;
  Environment = Environment;
  
  static _captureStarted = false;
  public static set captureStarted(cS) {
    DevelopmentComponent._captureStarted = this.instance.state = cS;
  }
  public static get captureStarted() {
    return DevelopmentComponent._captureStarted;
  }

  private static instance: DevelopmentComponent;
  static template;
  ngAfterViewInit() {
    // var request = new XMLHttpRequest();
    // request.open('GET', 'assets/templates/template.docx', true);
    // request.responseType = 'blob';
    // request.onload = function () {
    //   var reader = new FileReader();
    //   reader.onload = function (e) {
    //     console.log('[capturing] Template was loaded');
    //     DevelopmentComponent.template = (e.target as any).result;
    //     // onTemplateChosen(e.target.result);
    //   };
    //   reader.readAsArrayBuffer(request.response);
    // };
    // request.send();
  }

  constructor() {
    DevelopmentComponent.instance = this;
  }

  @Input()
  @HostBinding('class.started') state = DevelopmentComponent.captureStarted;
  start() {
    DevelopmentComponent.captureStarted = this.state = true;
  }

  stop() {
    DevelopmentComponent.captureStarted = this.state = false;
  }
}

// export async function generateRequestDoc(params: {service, action, subaction, description, parameters, sample: {header, body, response}}) {
//   if (DevelopmentComponent.captureStarted == false) return;

//   if (Environment.requestDocs.filters) {
//     if ((Environment.requestDocs.filters as any).service && !params.service.match((Environment.requestDocs.filters as any).service)) return;
//   }

//   const template = DevelopmentComponent.template;
//   console.log('Creating RequestDoc (can take some time) ...');
//   const report = await createReport({
//     template,
//     data: params
//   });

//   saveDataToFile(
//     report,
//     `${params.service}/${params.action}/${params.subaction}.docx`,
//     'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
//   );
// }


// const saveDataToFile = (data, fileName, mimeType) => {
//   const blob = new Blob([data], { type: mimeType });
//   const url = window.URL.createObjectURL(blob);
//   downloadURL(url, fileName);
// };

// const downloadURL = (url, fileName) => {
//   var a = document.createElement("a");
//   a.href = url;
//   a.setAttribute("download", fileName);
//   a.click();
// };
