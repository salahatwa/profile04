class Translations {
    THANK_YOU = ['شكرًا لك!', 'Thank You!'];
    SEND_SUCCESS = ['تم إرسال رسالتك بنجاح!', 'Your message was sent successfully!'];
    BACK_TO_HOME = ['العودة إلى الرئيسية', 'Return to Home'];
}

export const ContactSuccessTranslations = new Translations();