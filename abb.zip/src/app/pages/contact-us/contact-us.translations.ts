class Translations {
    CONTACT_US = ['تواصل معنا', 'Contact Us'];
    SUBJECT = ['الغرض من الرسالة', 'The purpose of the message'];
    INVALID_SUBJECT = ['الرجاء إختيار الغرض من الرسالة', 'Please choose the purpose of the message'];
    TITLE = ['عنوان الرسالة', 'Message Title'];
    TITLE_PLACEHOLDER = ['ادخل عنوان وصفي', 'Enter a descriptive title'];
    INVALID_TITLE = ['الرجاء إدخال موضوع للرسالة', 'Please enter a valid title'];
    CONTENT = ['محتوى الرسالة', 'Message Content'];
    INVALID_CONTENT = ['الرجاء إدخال محتوى الرسالة', 'Please enter a valid content'];
    SEND = ['إرسال', 'Send'];
    email = ['البريد الاكترونى', 'Email'];
    emailPlaceholder = ['ادخل بريدك الالكترونى', 'Enter your email'];
    invalidEmail = ['الرجاء إدخال البريد الاكترونى', 'please enter your email'];
    contactOnWatsapp = ['راسلنا عبر الواتساب', 'Contact us on whatsapp'];
    orSendMessage = ['أو أرسل رسالة', 'or send message']
}
export const ContactUsTranslations = new Translations();


