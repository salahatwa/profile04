import { Component, OnInit } from '@angular/core';
import { Translations } from '@inma/helpers/translations';
import { kycTranslations } from '../kyctranslation';
import { Kyc } from '@inma/models/kyc/';
import { Settings } from '@inma/helpers/settings';

@Component({
  selector: 'tadawul-investment-info',
  templateUrl: './investment-info.component.html',
  styleUrls: ['./investment-info.component.scss'],
})
export class InvestmentInfoComponent implements OnInit {
  @Translations()
  t = kycTranslations;
  activeSegment = 'bankInfo';
  details = {
    bankInfo: {
      bank: {
        arDesc: '',
        enDesc: ''
      },
      branch: '',
      iban: '',
    }
  };
  lang;

  constructor() { }

  ngOnInit() {
    Kyc.details.subscribe( details => {
      console.log(details);
      this.details = details;
    });
  }

  segmentChanged($event) {

  }

}
