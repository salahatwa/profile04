"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_tradestation_markets-index_markets-index_module_ts"],{

/***/ 92017:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/tradestation/markets-index/markets-index-routing.module.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MarketsIndexPageRoutingModule": () => (/* binding */ MarketsIndexPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _markets_index_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./markets-index.page */ 95877);




const routes = [
    {
        path: '',
        component: _markets_index_page__WEBPACK_IMPORTED_MODULE_0__.MarketsIndexPage
    }
];
let MarketsIndexPageRoutingModule = class MarketsIndexPageRoutingModule {
};
MarketsIndexPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MarketsIndexPageRoutingModule);



/***/ }),

/***/ 16031:
/*!**************************************************************************!*\
  !*** ./src/app/pages/tradestation/markets-index/markets-index.module.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MarketsIndexPageModule": () => (/* binding */ MarketsIndexPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../pipes/pipes.module */ 41041);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _markets_index_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./markets-index-routing.module */ 92017);
/* harmony import */ var _markets_index_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./markets-index.page */ 95877);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);









let MarketsIndexPageModule = class MarketsIndexPageModule {
};
MarketsIndexPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _markets_index_routing_module__WEBPACK_IMPORTED_MODULE_1__.MarketsIndexPageRoutingModule,
            _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_0__.PipesModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateModule.forChild()
        ],
        declarations: [_markets_index_page__WEBPACK_IMPORTED_MODULE_2__.MarketsIndexPage]
    })
], MarketsIndexPageModule);



/***/ }),

/***/ 95877:
/*!************************************************************************!*\
  !*** ./src/app/pages/tradestation/markets-index/markets-index.page.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MarketsIndexPage": () => (/* binding */ MarketsIndexPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _markets_index_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./markets-index.page.html?ngResource */ 77490);
/* harmony import */ var _markets_index_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./markets-index.page.scss?ngResource */ 68555);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_models_market__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/models/market */ 1874);
/* harmony import */ var _inma_helpers_translations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/helpers/translations */ 69353);






let MarketsIndexPage = class MarketsIndexPage {
    constructor() {
        this.MarketsNames = _inma_models_market__WEBPACK_IMPORTED_MODULE_2__.MarketsNames;
        this.t = _inma_models_market__WEBPACK_IMPORTED_MODULE_2__.MarketNamesTranslations;
    }
    ngOnInit() {
    }
};
MarketsIndexPage.ctorParameters = () => [];
(0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_inma_helpers_translations__WEBPACK_IMPORTED_MODULE_3__.Translations)(),
    (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__metadata)("design:type", Object)
], MarketsIndexPage.prototype, "t", void 0);
MarketsIndexPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'tadawul-markets-index',
        template: _markets_index_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_markets_index_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__metadata)("design:paramtypes", [])
], MarketsIndexPage);



/***/ }),

/***/ 20320:
/*!***********************************!*\
  !*** ./src/app/pipes/camelize.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CamelizePipe": () => (/* binding */ CamelizePipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_strings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/strings */ 36782);



let CamelizePipe = class CamelizePipe {
    transform(value, args) {
        return _inma_strings__WEBPACK_IMPORTED_MODULE_0__.Strings.camelize(value);
    }
};
CamelizePipe = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Pipe)({ name: 'camelize' })
], CamelizePipe);



/***/ }),

/***/ 98302:
/*!**********************************!*\
  !*** ./src/app/pipes/commafy.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommafyPipe": () => (/* binding */ CommafyPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let CommafyPipe = class CommafyPipe {
    transform(value, ...args) {
        if (value) {
            if (args.length > 0 && args[2] == 'debug')
                debugger;
            if (value == '_')
                return value;
            value = parseFloat(value.toString().replace(new RegExp(',', 'g'), ''));
            let str = value.toString().split('.');
            let precision = 0;
            // if (args && args.length && args[0].toLowerCase() == 'integer')
            //   precision = 0;
            // else
            if (args[1] || str[1]) // already contains fraction part, or demanded explicitly
                precision = args[1] || 2;
            value = Number(value);
            if (value.toFixed)
                value = value.toFixed(precision);
            str = value.toString().split('.');
            if (str[0].length > 3)
                str[0] = str[0].replace(/(\d)(?=(\d{3})+$)/g, '$1,');
            if (args && args.length) {
                if ('number' == args[0].toLowerCase())
                    if (str[1])
                        return str[0] + '.' + str[1];
                    else
                        return str[0];
                else if ('integer' == args[0].toLowerCase())
                    return str[0];
                else if ('fraction' == args[0].toLowerCase())
                    return str[1] || '0';
                else if ('percentage' == args[0].toLowerCase())
                    return parseInt((parseFloat(str.join('.')) * 100).toString()) + '%';
            }
            return str.join('.');
        }
        else
            return ''; //{int: '', fraction: ''};
    }
};
CommafyPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
        name: 'commafy',
    })
], CommafyPipe);



/***/ }),

/***/ 15803:
/*!************************************!*\
  !*** ./src/app/pipes/constants.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConstantsPipe": () => (/* binding */ ConstantsPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let ConstantsPipe = class ConstantsPipe {
    transform(value, ...args) {
        let keys = [];
        for (let key in value) {
            if (isNaN(Number(key)))
                keys.push(key);
        }
        return keys;
    }
};
ConstantsPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({ name: 'constants' })
], ConstantsPipe);



/***/ }),

/***/ 74935:
/*!****************************************!*\
  !*** ./src/app/pipes/enum-to-array.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EnumToArrayPipe": () => (/* binding */ EnumToArrayPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let EnumToArrayPipe = class EnumToArrayPipe {
    transform(value, ...args) {
        let result = [];
        var keys = Object.keys(value);
        var values = Object.values(value);
        for (var i = 0; i < keys.length; i++) {
            result.push({ key: keys[i], value: values[i] });
        }
        return result;
    }
};
EnumToArrayPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
        name: 'enumToArray'
    })
], EnumToArrayPipe);



/***/ }),

/***/ 555:
/*!*******************************!*\
  !*** ./src/app/pipes/keys.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "KeysPipe": () => (/* binding */ KeysPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let KeysPipe = class KeysPipe {
    transform(value, args) {
        let keys = [];
        for (let key in value) {
            keys.push(key);
        }
        return keys;
    }
};
KeysPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({ name: 'keys' })
], KeysPipe);



/***/ }),

/***/ 41041:
/*!***************************************!*\
  !*** ./src/app/pipes/pipes.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PipesModule": () => (/* binding */ PipesModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _safe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./safe */ 37930);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _commafy__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./commafy */ 98302);
/* harmony import */ var _keys__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./keys */ 555);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./constants */ 15803);
/* harmony import */ var _camelize__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./camelize */ 20320);
/* harmony import */ var _price__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./price */ 78981);
/* harmony import */ var _enum_to_array__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./enum-to-array */ 74935);









let PipesModule = class PipesModule {
};
PipesModule = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.NgModule)({
        declarations: [_commafy__WEBPACK_IMPORTED_MODULE_1__.CommafyPipe, _keys__WEBPACK_IMPORTED_MODULE_2__.KeysPipe, _constants__WEBPACK_IMPORTED_MODULE_3__.ConstantsPipe, _camelize__WEBPACK_IMPORTED_MODULE_4__.CamelizePipe, _price__WEBPACK_IMPORTED_MODULE_5__.SARPipe, _enum_to_array__WEBPACK_IMPORTED_MODULE_6__.EnumToArrayPipe, _safe__WEBPACK_IMPORTED_MODULE_0__.SafeHtml],
        imports: [],
        exports: [_commafy__WEBPACK_IMPORTED_MODULE_1__.CommafyPipe, _keys__WEBPACK_IMPORTED_MODULE_2__.KeysPipe, _constants__WEBPACK_IMPORTED_MODULE_3__.ConstantsPipe, _camelize__WEBPACK_IMPORTED_MODULE_4__.CamelizePipe, _price__WEBPACK_IMPORTED_MODULE_5__.SARPipe, _enum_to_array__WEBPACK_IMPORTED_MODULE_6__.EnumToArrayPipe, _safe__WEBPACK_IMPORTED_MODULE_0__.SafeHtml]
    })
], PipesModule);



/***/ }),

/***/ 78981:
/*!********************************!*\
  !*** ./src/app/pipes/price.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SARPipe": () => (/* binding */ SARPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/helpers/settings */ 96892);



let SARPipe = class SARPipe {
    constructor() {
        // @Translations()
        // t = AppTranslations;
        this.arabic = 'ر.س';
        this.english = 'SAR';
    }
    transform(value, ...args) {
        if (_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_0__.Settings.language == _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_0__.Languages.English) {
            return value + " " + this.english;
        }
        else if (_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_0__.Settings.language == _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_0__.Languages.Arabic) {
            return value + " " + this.arabic;
        }
    }
};
SARPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Pipe)({ name: 'SAR' })
], SARPipe);



/***/ }),

/***/ 37930:
/*!*******************************!*\
  !*** ./src/app/pipes/safe.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SafeHtml": () => (/* binding */ SafeHtml)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ 50318);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);



let SafeHtml = class SafeHtml {
    constructor(sanitizer) {
        this.sanitizer = sanitizer;
    }
    transform(html) {
        return this.sanitizer.bypassSecurityTrustHtml(html);
    }
};
SafeHtml.ctorParameters = () => [
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__.DomSanitizer }
];
SafeHtml = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Pipe)({ name: 'safe' }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__metadata)("design:paramtypes", [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__.DomSanitizer])
], SafeHtml);



/***/ }),

/***/ 68555:
/*!*************************************************************************************!*\
  !*** ./src/app/pages/tradestation/markets-index/markets-index.page.scss?ngResource ***!
  \*************************************************************************************/
/***/ ((module) => {

module.exports = ":host {\n  height: 100%;\n}\n:host ion-item {\n  --color: var(--ion-color-primary-txt);\n  --border-color: transparent;\n  --border-color: transparent;\n}\n:host ion-toolbar {\n  --background: #005157;\n  --color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1hcmtldHMtaW5kZXgucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksWUFBQTtBQUNKO0FBQUk7RUFFSSxxQ0FBQTtFQUNBLDJCQUFBO0VBQ0EsMkJBQUE7QUFDUjtBQUVJO0VBQ0UscUJBQUE7RUFDQSxjQUFBO0FBQU4iLCJmaWxlIjoibWFya2V0cy1pbmRleC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdCB7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIGlvbi1pdGVtIHtcbiAgICAgICAgLy8gLS1jb2xvcjogIzAwNTQ1NztcbiAgICAgICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktdHh0KTtcbiAgICAgICAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICAgICAgICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gICAgfVxuICBcbiAgICBpb24tdG9vbGJhciB7XG4gICAgICAtLWJhY2tncm91bmQ6ICMwMDUxNTc7XG4gICAgICAtLWNvbG9yOiB3aGl0ZTtcbiAgICB9XG4gIH1cbiAgIl19 */";

/***/ }),

/***/ 77490:
/*!*************************************************************************************!*\
  !*** ./src/app/pages/tradestation/markets-index/markets-index.page.html?ngResource ***!
  \*************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>{{'tradestion.MARKETS' | translate}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-item button *ngFor=\"let market of MarketsNames | enumToArray\" [routerLink]=\"['/tradestation', market.key]\">\n    <ion-label>{{ translate.instant('tradestion.'+market.key) }}</ion-label>\n  </ion-item>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_tradestation_markets-index_markets-index_module_ts.js.map