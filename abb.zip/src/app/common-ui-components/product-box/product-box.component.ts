import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'tadawul-product-box',
  templateUrl: './product-box.component.html',
  styleUrls: ['./product-box.component.scss'],
})
export class ProductBoxComponent implements OnInit {
  @Input() title:any;
  @Input() label:any;
  @Input('price-text') priceText:any;
  @Input() active:any;
  
  constructor() { }

  ngOnInit() {}

}
