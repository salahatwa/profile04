"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_login_login_module_ts"],{

/***/ 36652:
/*!********************************************************************!*\
  !*** ./src/app/pages/login/force-update/force-update.component.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForceUpdateComponent": () => (/* binding */ ForceUpdateComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _force_update_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./force-update.component.html?ngResource */ 13262);
/* harmony import */ var _force_update_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./force-update.component.scss?ngResource */ 26374);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/core */ 26549);
/* harmony import */ var _inma_helpers_translations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/helpers/translations */ 69353);
/* harmony import */ var _login_translations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../login.translations */ 89927);







const { Browser } = _capacitor_core__WEBPACK_IMPORTED_MODULE_2__.Plugins;
let ForceUpdateComponent = class ForceUpdateComponent {
    constructor() {
        this.t = _login_translations__WEBPACK_IMPORTED_MODULE_4__.LoginTranslations;
    }
    ngOnInit() { }
    openStore() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            if (_capacitor_core__WEBPACK_IMPORTED_MODULE_2__.Capacitor.platform == 'ios') {
                yield Browser.open({
                    url: "https://apps.apple.com/sa/app/alinma-tadawul-%D8%AA%D8%AF%D8%A7%D9%88%D9%84-%D8%A7%D9%84%D8%A5%D9%86%D9%85%D8%A7%D8%A1/id1550503215"
                });
            }
            else if (_capacitor_core__WEBPACK_IMPORTED_MODULE_2__.Capacitor.platform == 'android') {
                yield Browser.open({
                    url: "https://play.google.com/store/apps/details?id=com.alinma.investment.mobile&hl=en&gl=US"
                });
            }
        });
    }
};
ForceUpdateComponent.ctorParameters = () => [];
(0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_inma_helpers_translations__WEBPACK_IMPORTED_MODULE_3__.Translations)(),
    (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:type", Object)
], ForceUpdateComponent.prototype, "t", void 0);
ForceUpdateComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'tadawul-force-update',
        template: _force_update_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_force_update_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:paramtypes", [])
], ForceUpdateComponent);



/***/ }),

/***/ 25926:
/*!*****************************************************!*\
  !*** ./src/app/pages/login/login-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageRoutingModule": () => (/* binding */ LoginPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _force_update_force_update_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./force-update/force-update.component */ 36652);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page */ 84418);





const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_1__.LoginPage
    },
    {
        path: 'force-update',
        component: _force_update_force_update_component__WEBPACK_IMPORTED_MODULE_0__.ForceUpdateComponent
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    })
], LoginPageRoutingModule);



/***/ }),

/***/ 60441:
/*!*********************************************!*\
  !*** ./src/app/pages/login/login.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageModule": () => (/* binding */ LoginPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login-routing.module */ 25926);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page */ 84418);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);
/* harmony import */ var _button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./button */ 25008);
/* harmony import */ var _force_update_force_update_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./force-update/force-update.component */ 36652);











let LoginPageModule = class LoginPageModule {
};
LoginPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__.TranslateModule.forChild(),
            _login_routing_module__WEBPACK_IMPORTED_MODULE_0__.LoginPageRoutingModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            _button__WEBPACK_IMPORTED_MODULE_3__.InButtonModule
        ],
        declarations: [
            _login_page__WEBPACK_IMPORTED_MODULE_1__.LoginPage,
            _force_update_force_update_component__WEBPACK_IMPORTED_MODULE_4__.ForceUpdateComponent
        ],
        providers: []
    })
], LoginPageModule);



/***/ }),

/***/ 84418:
/*!*******************************************!*\
  !*** ./src/app/pages/login/login.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPage": () => (/* binding */ LoginPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _login_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.page.html?ngResource */ 96752);
/* harmony import */ var _login_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page.scss?ngResource */ 98433);
/* harmony import */ var _events_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../events.service */ 31782);
/* harmony import */ var _helpers_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../helpers/constants */ 31777);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor/core */ 26549);
/* harmony import */ var _inma_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @inma/environment */ 80960);
/* harmony import */ var _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @inma/helpers/settings */ 96892);
/* harmony import */ var _inma_models_users__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @inma/models/users */ 17166);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! jquery */ 85139);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! moment */ 56908);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var src_app_app_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/app.component */ 20721);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var _id_expired_id_expired_page__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../id-expired/id-expired.page */ 78796);
/* harmony import */ var _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic-native/in-app-browser/ngx */ 49048);




















const { Browser } = _capacitor_core__WEBPACK_IMPORTED_MODULE_4__.Plugins;
const { Storage } = _capacitor_core__WEBPACK_IMPORTED_MODULE_4__.Plugins;
let LoginPage = class LoginPage {
    constructor(translate, formBuilder, sharedData, navCtrl, cdRef, event, ngZone, iab, document) {
        this.translate = translate;
        this.formBuilder = formBuilder;
        this.sharedData = sharedData;
        this.navCtrl = navCtrl;
        this.cdRef = cdRef;
        this.event = event;
        this.ngZone = ngZone;
        this.iab = iab;
        this.document = document;
        this.Languages = _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_6__.Languages;
        this.Settings = _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_6__.Settings;
        this.username = "";
        this.password = "";
        this.rememberMe = false;
        this.rememberMeStorageKey = "rememberMeUserName";
        this.loading = false;
        this.segmentValue = 'friends';
        this.Environment = _inma_environment__WEBPACK_IMPORTED_MODULE_5__.Environment;
        this.slideOpts = {
        // initialSlide: 1,
        // speed: 400
        };
        this.containerClass = '';
        this.direction = 'rtl';
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_6__.Settings.getUserPreferences(_helpers_constants__WEBPACK_IMPORTED_MODULE_3__.Constants._SETTINGS._PREFERRED_LANG).subscribe((lang) => {
            localStorage.setItem(_helpers_constants__WEBPACK_IMPORTED_MODULE_3__.Constants._SETTINGS._PREFERRED_LANG, lang.toString());
            this.appLang = lang ? lang.toString() : 'ar';
            this.handleLanguagePreferences(this.appLang);
        });
        this.buildForm();
        console.log('this.translate.instant(textOne)', this.translate.instant('loginPage.textOne'));
        // this.event.subscribe('KEYBOARD_SHOW',()=>{
        //   this.containerClass = 'keyboard-is-open';
        //   // alert('keyboard is open')
        // });
        // this.event.subscribe('KEYBOARD_HIDE',()=>{
        //   this.containerClass = '';
        //   // alert('keyboard is hidden')
        // });
    }
    buildForm() {
        const englishOnlyTester = /^[^\u0621-\u064A\u0660-\u0669]*$/;
        const noSpace = /^\S*$/;
        this.form = this.formBuilder.group({
            username: [
                "",
                _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.pattern(englishOnlyTester),
                    _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.pattern(noSpace),
                    _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required,
                ]),
            ],
            password: ["", _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.pattern(noSpace)])],
            rememberMe: [],
        });
    }
    //#endregion
    preventSpaceInUserName(value) {
        this.username = value.replaceAll(' ', '');
    }
    preventSpaceInPassword(value) {
        this.password = value.replaceAll(' ', '');
    }
    autoFill() {
        if (!_inma_environment__WEBPACK_IMPORTED_MODULE_5__.Environment.isProduction) {
            const credential = _inma_environment__WEBPACK_IMPORTED_MODULE_5__.Environment.autoFillCredential;
            if (credential === null || credential === void 0 ? void 0 : credential.username)
                this.username = credential === null || credential === void 0 ? void 0 : credential.username;
            if (credential === null || credential === void 0 ? void 0 : credential.password)
                this.password = credential === null || credential === void 0 ? void 0 : credential.password;
            // To avoid “expression has changed after it was checked”
            this.cdRef.detectChanges();
        }
    }
    ngOnInit() {
        //
        setTimeout(() => {
            Storage.get({ key: "RESTART_MESSAGE" }).then(message => {
                if (message === null || message === void 0 ? void 0 : message.value)
                    src_app_app_component__WEBPACK_IMPORTED_MODULE_10__.AppComponent.showError(message.value);
                Storage.remove({ key: "RESTART_MESSAGE" });
            });
        }, 1000);
        this.getRememberMeUserName().then((res) => {
            if (res !== null && res !== undefined) {
                this.username = String(res);
                this.rememberMe = true;
            }
            this.autoFill();
        });
    }
    login(form) {
        setTimeout(() => {
            this.login2(form);
        }, 0);
    }
    login2(form) {
        if (src_app_app_component__WEBPACK_IMPORTED_MODULE_10__.AppComponent.loggedoutDisconnected == true) {
            src_app_app_component__WEBPACK_IMPORTED_MODULE_10__.AppComponent.showError(this.translate.instant('loginPage.No_Internt'));
            return;
        }
        if (form.invalid) {
            return;
        }
        if (this.rememberMe) {
            this.setRememberMeUserName(this.username);
        }
        _inma_models_users__WEBPACK_IMPORTED_MODULE_7__.Users.login(this.username, this.password, () => {
            setTimeout(() => this.finishLoading(), 3000);
        }).subscribe((response) => {
            // this.event.publish('CHANGE_APP_ROUTER', this.appLang);
            if (_inma_environment__WEBPACK_IMPORTED_MODULE_5__.Environment.isProduction || !_inma_environment__WEBPACK_IMPORTED_MODULE_5__.Environment.startPage) {
                this.navCtrl.navigateRoot('main/tabs');
            }
            else {
                this.navCtrl.navigateRoot(_inma_environment__WEBPACK_IMPORTED_MODULE_5__.Environment.startPage, { animated: true });
            }
            this.validateIdExpired(response === null || response === void 0 ? void 0 : response.idExpiryDate);
        }, (error) => {
            this.finishLoading();
            if (error === _inma_models_users__WEBPACK_IMPORTED_MODULE_7__.Errors.WrongUsernameOrPassword)
                console.error(error);
            else if (error === _inma_models_users__WEBPACK_IMPORTED_MODULE_7__.Errors.ExpiredUserID) {
                const languageIndex = _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_6__.Settings.languageAsString == "ar" ? 0 : 1;
                const expiryErrors = ["تحتاج إلى تحديث معلوماتك ، يرجى الضغط هنا للتحديث",
                    "Your information need to be updated, please click here to update"];
                src_app_app_component__WEBPACK_IMPORTED_MODULE_10__.AppComponent.showError(expiryErrors[languageIndex], () => {
                    jquery__WEBPACK_IMPORTED_MODULE_8__('ion-toast').click(() => (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
                        const a = this.iab.create('https://www.alinmatadawul.com', "_blank", "usewkwebview=yes,location=no,enableViewportScale=yes,clearcache=yes");
                        yield a.show();
                        // await Browser.open({
                        //   url: 'https://www.alinmatadawul.com'
                        // });
                    }));
                });
            }
        });
    }
    /**
     * Redirect user to @id-expired@ page in case of id Expired
     * @param idExpiryDate
     */
    validateIdExpired(idExpiryDate) {
        let today = moment__WEBPACK_IMPORTED_MODULE_9__().format("YYYY-MM-DD");
        let d1 = new Date(idExpiryDate);
        let d2 = new Date(today);
        if (d1 < d2) {
            this.expiredMsg = {
                type: _id_expired_id_expired_page__WEBPACK_IMPORTED_MODULE_12__.ExpireType.ID,
                title: this.translate.instant('loginPage.textOne'),
                subtitle: this.translate.instant('loginPage.textTwo'),
                msg: this.translate.instant('loginPage.textThree'),
            };
            this.sharedData.setSharedData(this.expiredMsg, 'expiredMsg');
            this.navCtrl.navigateRoot('/id-expired', { animated: true });
            src_app_app_component__WEBPACK_IMPORTED_MODULE_10__.AppComponent.idExpiryDate = true;
        }
        else if (src_app_app_component__WEBPACK_IMPORTED_MODULE_10__.AppComponent.ExpiredUserID) {
            this.expiredMsg = {
                type: _id_expired_id_expired_page__WEBPACK_IMPORTED_MODULE_12__.ExpireType.KYC,
                title: this.translate.instant('loginPage.textFour'),
                subtitle: this.translate.instant('loginPage.textFive'),
                msg: this.translate.instant('loginPage.textSex'),
                isLinkExist: true,
                linkTxt: this.translate.instant('loginPage.textSeven')
            };
            this.sharedData.setSharedData(this.expiredMsg, 'expiredMsg');
            this.navCtrl.navigateRoot('/id-expired', { animated: true });
        }
    }
    finishLoading() {
        this.loading = false;
    }
    setRememberMeUserName(value) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            yield Storage.set({ key: this.rememberMeStorageKey, value: value });
        });
    }
    getRememberMeUserName() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            return yield Storage.get({ key: this.rememberMeStorageKey }).then((val) => {
                return val.value;
            });
        });
    }
    //Components NABIL
    clickBtn() { }
    openCreateAccount() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            const a = this.iab.create(`${_inma_environment__WEBPACK_IMPORTED_MODULE_5__.Environment.hostURL}/aiccreation/index.jsf?session_locale=${this.translate.currentLang.toLowerCase()}`, "_blank", "usewkwebview=yes,location=no,enableViewportScale=yes,clearcache=yes");
            yield a.show();
            // await Browser.open({
            //   url:
            //     `${Environment.hostURL}/aiccreation/index.jsf?session_locale=${this.translate.currentLang.toLowerCase()}`
            // });
        });
    }
    openRegisterNewUser() {
        var _a;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            // "https://www.alinmatadawul.com/alinmaTadawul/public/login.jsf?session_locale=en"
            yield Browser.open({
                url: `${_inma_environment__WEBPACK_IMPORTED_MODULE_5__.Environment.hostURL}/alinmaTadawul/public/login.jsf?session_locale=${(_a = _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_6__.Settings === null || _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_6__.Settings === void 0 ? void 0 : _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_6__.Settings.languageAsString) === null || _a === void 0 ? void 0 : _a.toLowerCase()}`
            });
        });
    }
    goToForgot() {
        this.navCtrl.navigateForward('forget-username-password', { animated: true });
    }
    changeLang() {
        if (this.translate.currentLang == 'en') {
            this.appLang = 'ar';
            this.handleLanguagePreferences('ar');
            this.direction = 'rtl';
        }
        else {
            this.handleLanguagePreferences('en');
            this.appLang = 'en';
            this.direction = 'ltr';
        }
    }
    handleLanguagePreferences(lang) {
        if (lang == 'ar') {
            this.translate.setDefaultLang('ar');
            this.translate.use('ar');
            this.appLang = 'ar';
            this.document.documentElement.dir = 'rtl';
        }
        else if (lang == 'en') {
            this.translate.setDefaultLang('en');
            this.appLang = 'en';
            this.translate.use('en');
            this.document.documentElement.dir = 'ltr';
        }
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_6__.Settings.setUserPreferences(_helpers_constants__WEBPACK_IMPORTED_MODULE_3__.Constants._SETTINGS._PREFERRED_LANG, lang);
        localStorage.setItem(_helpers_constants__WEBPACK_IMPORTED_MODULE_3__.Constants._SETTINGS._PREFERRED_LANG, lang.toString());
    }
    setKeyboardClass(check) {
        this.containerClass = check ? 'keyboard-is-open' : '';
    }
};
LoginPage.ctorParameters = () => [
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_16__.TranslateService },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormBuilder },
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_11__.SharedDataService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_17__.NavController },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_18__.ChangeDetectorRef },
    { type: _events_service__WEBPACK_IMPORTED_MODULE_2__.EventsService },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_18__.NgZone },
    { type: _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_13__.InAppBrowser },
    { type: Document, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_18__.Inject, args: [_angular_common__WEBPACK_IMPORTED_MODULE_19__.DOCUMENT,] }] }
];
LoginPage = (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_18__.Component)({
        selector: "app-login",
        template: _login_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_login_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:paramtypes", [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_16__.TranslateService,
        _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormBuilder,
        src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_11__.SharedDataService,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_17__.NavController,
        _angular_core__WEBPACK_IMPORTED_MODULE_18__.ChangeDetectorRef,
        _events_service__WEBPACK_IMPORTED_MODULE_2__.EventsService,
        _angular_core__WEBPACK_IMPORTED_MODULE_18__.NgZone,
        _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_13__.InAppBrowser,
        Document])
], LoginPage);



/***/ }),

/***/ 89927:
/*!***************************************************!*\
  !*** ./src/app/pages/login/login.translations.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginTranslations": () => (/* binding */ LoginTranslations)
/* harmony export */ });
class Translations {
    constructor() {
        this.USERNAME = ['اسم المستخدم', 'Username'];
        this.PASSWORD = ['كلمة المرور', 'Password'];
        this.LOGIN = ['تسجيل الدخول', 'Login'];
        this.OPEN_ACCOUNT = ['فتح حساب استثماري', 'Open Investment Account'];
        this.REGISTER_ACCOUNT = ['تسجيل مستخدم جديد', 'Register New User'];
        this.TRY_ALINMA_TADAWUL = ['جرب الإنماء تداول', 'Try Alinma Tadawul'];
        this.DONT_HAVE_ALINMA_INVESTMENT_ACCOUNT = ['ليس لديك حساب في الإنماء للاستثمار؟', "Don't have alinma investment account?"];
        this.DONT_HAVE_AN_ACCOUNT_AND_WANT_TO_TRY_THE_APPLICATION = ['ليس لديك حساب و تريد تجربة التطبيق؟', " Don't have account and want to try the application? "];
        this.FREE = ['مجاناً', 'free'];
        this.REMEMBER_ME = ['تذكرني', 'Remember me'];
        this.FORGOT_USERNAME_OR_PASSWORD = ['نسيت اسم المستخدم أو كلمة المرور', 'Forgot username or password'];
        this.No_Internt = ["خطأ في الاتصال، تأكد من إعدادات الشبكة", "Network Error, check your connection"];
        this.warning = ['تنبيه', 'Alert'];
        this.textOne = ['هويتك منتهية', 'ID Expired'];
        this.textTwo = ["قد لا تتمكن من الاستفادة من بعض خدمات التطبيق ", "You may not be able to use some of app services"];
        this.textThree = [' يرجى تحديث الهوية الوطنية أو الإقامة', 'Please update your national ID or Iqama'];
        this.textFour = ['تحديث بياناتكم الشخصية منتهية', 'Your KYC has been expired'];
        this.textFive = ["قد لا تتمكن من الإستفادة من بعض خدمات الإنماء للاستثمار. ", "you may not be able to benefit from some of the Alinma Investment service."];
        this.textSex = ['لتحديث بياناتكم الشخصية الرجاء الدخول على تداول الإنماء', 'To Update your KYC please login Alinma Tadawul website'];
        this.textSeven = ['من هنا', 'Here'];
        this.continue = ['الاستمرار', 'Continue'];
        /////////////////////////////////////////////////////
        //Force update page
        this.FIRSTMSG = ['يجب تحديث التطبيق', 'App update'];
        this.SECMSG = ['الإصدار الحالى من التطبيق لم يعد مدعومآ،يجب تحديث التطبيق لأحدث إصدار', 'The current version is no longer supported, the app must be updated to the latest version'];
        this.BTNMSG = ['التحديث الأن', 'Update now'];
    }
}
const LoginTranslations = new Translations();


/***/ }),

/***/ 26374:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/login/force-update/force-update.component.scss?ngResource ***!
  \*********************************************************************************/
/***/ ((module) => {

module.exports = ".container {\n  --background:url(\"/assets/icon/alinma-pattern-bg.svg\") repeat top left #cddcde;\n}\n.container .gradient-bg {\n  content: \"\";\n  position: fixed;\n  bottom: 0;\n  height: 100%;\n  width: 100%;\n  background: linear-gradient(to bottom, #FFFFFF00 0%, #FFFFFF 30%);\n  z-index: -1;\n  background-repeat: no-repeat;\n  background-position: center center;\n  background-size: cover;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZvcmNlLXVwZGF0ZS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLDhFQUFBO0FBQ0o7QUFDSTtFQUNJLFdBQUE7RUFDQSxlQUFBO0VBQ0EsU0FBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsaUVBQUE7RUFDQSxXQUFBO0VBQ0EsNEJBQUE7RUFDQSxrQ0FBQTtFQUNBLHNCQUFBO0FBQ1IiLCJmaWxlIjoiZm9yY2UtdXBkYXRlLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRhaW5lcntcbiAgICAtLWJhY2tncm91bmQ6dXJsKFwiL2Fzc2V0cy9pY29uL2FsaW5tYS1wYXR0ZXJuLWJnLnN2Z1wiKSByZXBlYXQgdG9wIGxlZnQgI2NkZGNkZTtcblxuICAgIC5ncmFkaWVudC1iZyB7XG4gICAgICAgIGNvbnRlbnQ6ICcnO1xuICAgICAgICBwb3NpdGlvbjogZml4ZWQ7XG4gICAgICAgIGJvdHRvbTogMDtcbiAgICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSwgI0ZGRkZGRjAwIDAlLCAjRkZGRkZGIDMwJSk7XG4gICAgICAgIHotaW5kZXg6IC0xO1xuICAgICAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICAgICAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXIgY2VudGVyO1xuICAgICAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xuICAgIH1cbn0iXX0= */";

/***/ }),

/***/ 98433:
/*!********************************************************!*\
  !*** ./src/app/pages/login/login.page.scss?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = "@-webkit-keyframes showLoginContent {\n  from {\n    max-height: 0;\n    opacity: 0;\n    top: 100px;\n    transition: all 1s;\n  }\n  to {\n    max-height: 500px;\n    opacity: 1;\n    top: 0;\n    transition: all 1s;\n  }\n}\n@keyframes showLoginContent {\n  from {\n    max-height: 0;\n    opacity: 0;\n    top: 100px;\n    transition: all 1s;\n  }\n  to {\n    max-height: 500px;\n    opacity: 1;\n    top: 0;\n    transition: all 1s;\n  }\n}\n@-webkit-keyframes addMarginBottom {\n  from {\n    margin-bottom: 0;\n  }\n  to {\n    margin-bottom: 100px;\n  }\n}\n@keyframes addMarginBottom {\n  from {\n    margin-bottom: 0;\n  }\n  to {\n    margin-bottom: 100px;\n  }\n}\n@-webkit-keyframes minimizeBackgroundHeight {\n  from {\n    height: 150%;\n  }\n  to {\n    height: 100%;\n  }\n}\n@keyframes minimizeBackgroundHeight {\n  from {\n    height: 150%;\n  }\n  to {\n    height: 100%;\n  }\n}\n@-webkit-keyframes showSwitchLanguage {\n  from {\n    opacity: 0;\n  }\n  to {\n    opacity: 1;\n  }\n}\n@keyframes showSwitchLanguage {\n  from {\n    opacity: 0;\n  }\n  to {\n    opacity: 1;\n  }\n}\n.login-screen {\n  --background: url(\"/assets/login/alinma-pattern-bg.svg\") repeat top left #005157;\n  --color: #99b9bc;\n}\n.login-screen .gradient-bg {\n  content: \"\";\n  position: fixed;\n  bottom: 0;\n  height: 150%;\n  width: 100%;\n  background: linear-gradient(to bottom, #00515700 25%, #005157 35%);\n  z-index: -1;\n  background-repeat: no-repeat;\n  background-position: center center;\n  background-size: cover;\n  -webkit-animation: minimizeBackgroundHeight linear 1s forwards;\n          animation: minimizeBackgroundHeight linear 1s forwards;\n}\n.login-screen .login-content-wrapper {\n  height: 100vh;\n  overflow: hidden;\n}\n.login-screen .login-content-wrapper .form-wrapper {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  height: 100vh;\n  transition: all 0.25s;\n}\n.login-screen .login-content-wrapper .logo-img {\n  position: relative;\n  width: 245px;\n  max-width: 80%;\n  margin-bottom: 0;\n  margin-inline: auto;\n  display: block;\n  transition: all 0.75s;\n  -webkit-animation: addMarginBottom 0.75s linear 3s forwards;\n          animation: addMarginBottom 0.75s linear 3s forwards;\n}\n.login-screen .login-content-wrapper .switch-language {\n  position: -webkit-sticky;\n  position: sticky;\n  bottom: 0;\n  width: 100%;\n  opacity: 0;\n  transition: all 0.25s;\n  -webkit-animation: showSwitchLanguage 0.25s linear 2s forwards;\n          animation: showSwitchLanguage 0.25s linear 2s forwards;\n}\n.login-screen .login-content-wrapper .login-form {\n  position: relative;\n  top: 100px;\n  max-height: 0;\n  opacity: 0;\n  transition: all 0.75s;\n  -webkit-animation: showLoginContent 0.75s linear 3s forwards;\n          animation: showLoginContent 0.75s linear 3s forwards;\n}\n.login-screen ion-item.floating-input {\n  --border-radius: 5px;\n  padding: 5px 16px;\n  font-size: 14px;\n  font-weight: bold;\n  --min-height: 50px;\n  color: #99b9bc;\n}\n.login-screen ion-item.floating-input::part(native) {\n  border: 1.5px solid #65979A;\n  background: #22666d;\n}\n.login-screen ion-item.floating-input ion-input {\n  padding: 3px;\n  height: 30px;\n  color: #FFFFFF;\n}\n.login-screen .remember-me {\n  --background: none;\n  --background-activated: none;\n  --inner-border-width: 0;\n  --padding-start: 0;\n}\n.login-screen .remember-me ion-checkbox {\n  --border-radius: 4px;\n  --background: transparent;\n  --background-checked: #FFFFFF;\n  --border-color: #99B9BC;\n  --border-color-checked: #FFFFFF;\n  --checkmark-color: #005157;\n  --checkmark-width: 2px;\n  --size: 20px;\n}\n.login-screen .remember-me ion-label {\n  font-size: 13px;\n  color: #99B9BC;\n}\n.login-screen ion-router-link {\n  font-size: 14px;\n  --color: #99B9BC;\n}\n.login-screen ion-router-link.open-account-link {\n  color: #FFFFFF;\n  font-size: 16px;\n  font-weight: bold;\n  display: block;\n  margin: 30px 0;\n}\n#overlay {\n  position: fixed;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  background: rgba(0, 0, 0, 0);\n  z-index: 9999;\n}\n.login-change-lang-button {\n  display: flex;\n  cursor: pointer;\n}\n.forgot-text {\n  text-decoration: underline;\n}\nion-slides {\n  height: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvZ2luLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFO0lBQ0UsYUFBQTtJQUNBLFVBQUE7SUFDQSxVQUFBO0lBRUEsa0JBQUE7RUFBRjtFQUVBO0lBQ0UsaUJBQUE7SUFDQSxVQUFBO0lBQ0EsTUFBQTtJQUVBLGtCQUFBO0VBREY7QUFDRjtBQWJBO0VBQ0U7SUFDRSxhQUFBO0lBQ0EsVUFBQTtJQUNBLFVBQUE7SUFFQSxrQkFBQTtFQUFGO0VBRUE7SUFDRSxpQkFBQTtJQUNBLFVBQUE7SUFDQSxNQUFBO0lBRUEsa0JBQUE7RUFERjtBQUNGO0FBR0E7RUFDRTtJQUNFLGdCQUFBO0VBREY7RUFHQTtJQUNFLG9CQUFBO0VBREY7QUFDRjtBQUxBO0VBQ0U7SUFDRSxnQkFBQTtFQURGO0VBR0E7SUFDRSxvQkFBQTtFQURGO0FBQ0Y7QUFHQTtFQUNFO0lBQ0UsWUFBQTtFQURGO0VBR0E7SUFDRSxZQUFBO0VBREY7QUFDRjtBQUxBO0VBQ0U7SUFDRSxZQUFBO0VBREY7RUFHQTtJQUNFLFlBQUE7RUFERjtBQUNGO0FBV0E7RUFDRTtJQUNFLFVBQUE7RUFURjtFQVdBO0lBQ0UsVUFBQTtFQVRGO0FBQ0Y7QUFHQTtFQUNFO0lBQ0UsVUFBQTtFQVRGO0VBV0E7SUFDRSxVQUFBO0VBVEY7QUFDRjtBQVlBO0VBQ0UsZ0ZBQUE7RUFDQSxnQkFBQTtBQVZGO0FBYUU7RUFDRSxXQUFBO0VBQ0EsZUFBQTtFQUNBLFNBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGtFQUFBO0VBQ0EsV0FBQTtFQUNBLDRCQUFBO0VBQ0Esa0NBQUE7RUFDQSxzQkFBQTtFQUNBLDhEQUFBO1VBQUEsc0RBQUE7QUFYSjtBQWNFO0VBR0UsYUFBQTtFQUNBLGdCQUFBO0FBZEo7QUFrQkk7RUFDRSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSx1QkFBQTtFQUNBLGFBQUE7RUFDQSxxQkFBQTtBQWhCTjtBQW1CSTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7RUFJQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtFQUNBLHFCQUFBO0VBQ0EsMkRBQUE7VUFBQSxtREFBQTtBQXBCTjtBQTRCSTtFQUVFLHdCQUFBO0VBQUEsZ0JBQUE7RUFDQSxTQUFBO0VBQ0EsV0FBQTtFQUVBLFVBQUE7RUFFQSxxQkFBQTtFQUNBLDhEQUFBO1VBQUEsc0RBQUE7QUE3Qk47QUErQkk7RUFDRSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxhQUFBO0VBQ0EsVUFBQTtFQUdBLHFCQUFBO0VBRUEsNERBQUE7VUFBQSxvREFBQTtBQWhDTjtBQTBERTtFQUNFLG9CQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7QUF4REo7QUEwREk7RUFDSSwyQkFBQTtFQUNBLG1CQUFBO0FBeERSO0FBNkRJO0VBQ0ksWUFBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0FBM0RSO0FBK0RFO0VBQ0Usa0JBQUE7RUFDQSw0QkFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7QUE3REo7QUFzRUk7RUFDRSxvQkFBQTtFQUNBLHlCQUFBO0VBQ0EsNkJBQUE7RUFDQSx1QkFBQTtFQUNBLCtCQUFBO0VBQ0EsMEJBQUE7RUFDQSxzQkFBQTtFQUNBLFlBQUE7QUFwRU47QUF1RUk7RUFDRSxlQUFBO0VBQ0EsY0FBQTtBQXJFTjtBQXlFRTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtBQXZFSjtBQXlFSTtFQUNFLGNBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtBQXZFTjtBQW9HQTtFQUNFLGVBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsNEJBQUE7RUFDQSxhQUFBO0FBakdGO0FBbUdBO0VBQ0UsYUFBQTtFQUNBLGVBQUE7QUFoR0Y7QUEwSEE7RUFFRSwwQkFBQTtBQXhIRjtBQWtJQTtFQUNFLFlBQUE7QUEvSEYiLCJmaWxlIjoibG9naW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQGtleWZyYW1lcyBzaG93TG9naW5Db250ZW50IHtcbiAgZnJvbSB7XG4gICAgbWF4LWhlaWdodDogMDtcbiAgICBvcGFjaXR5OiAwO1xuICAgIHRvcDogMTAwcHg7XG4gICAgLy8gbWFyZ2luLXRvcDogMDtcbiAgICB0cmFuc2l0aW9uOiBhbGwgMXM7XG4gIH1cbiAgdG8ge1xuICAgIG1heC1oZWlnaHQ6IDUwMHB4O1xuICAgIG9wYWNpdHk6IDE7XG4gICAgdG9wOiAwO1xuICAgIC8vIG1hcmdpbi10b3A6IGF1dG8gIWltcG9ydGFudDtcbiAgICB0cmFuc2l0aW9uOiBhbGwgMXM7XG4gIH1cbn1cbkBrZXlmcmFtZXMgYWRkTWFyZ2luQm90dG9tIHtcbiAgZnJvbSB7XG4gICAgbWFyZ2luLWJvdHRvbTogMDtcbiAgfVxuICB0byB7XG4gICAgbWFyZ2luLWJvdHRvbTogMTAwcHg7XG4gIH1cbn1cbkBrZXlmcmFtZXMgbWluaW1pemVCYWNrZ3JvdW5kSGVpZ2h0IHtcbiAgZnJvbSB7XG4gICAgaGVpZ2h0OiAxNTAlO1xuICB9XG4gIHRvIHtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gIH1cbn1cbi8vIEBrZXlmcmFtZXMgbW92ZUxvZ28ge1xuLy8gICBmcm9tIHtcbi8vICAgICB0b3A6IDEwMHB4O1xuLy8gICB9XG4vLyAgIHRvIHtcbi8vICAgICB0b3A6IDA7XG4vLyAgIH1cbi8vIH1cbkBrZXlmcmFtZXMgc2hvd1N3aXRjaExhbmd1YWdlIHtcbiAgZnJvbSB7XG4gICAgb3BhY2l0eTogMDtcbiAgfVxuICB0byB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxufVxuXG4ubG9naW4tc2NyZWVuIHtcbiAgLS1iYWNrZ3JvdW5kOiB1cmwoJy9hc3NldHMvbG9naW4vYWxpbm1hLXBhdHRlcm4tYmcuc3ZnJykgcmVwZWF0IHRvcCBsZWZ0ICMwMDUxNTc7XG4gIC0tY29sb3I6ICM5OWI5YmM7XG4gIFxuXG4gIC5ncmFkaWVudC1iZyB7XG4gICAgY29udGVudDogJyc7XG4gICAgcG9zaXRpb246IGZpeGVkO1xuICAgIGJvdHRvbTogMDtcbiAgICBoZWlnaHQ6IDE1MCU7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSwgIzAwNTE1NzAwIDI1JSwgIzAwNTE1NyAzNSUpO1xuICAgIHotaW5kZXg6IC0xO1xuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gICAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyIGNlbnRlcjtcbiAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xuICAgIGFuaW1hdGlvbjogbWluaW1pemVCYWNrZ3JvdW5kSGVpZ2h0IGxpbmVhciAxcyBmb3J3YXJkcztcbiAgfVxuXG4gIC5sb2dpbi1jb250ZW50LXdyYXBwZXIge1xuICAgIC8vIGRpc3BsYXk6IGZsZXg7XG4gICAgLy8gZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICBoZWlnaHQ6IDEwMHZoO1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgLy8gb3ZlcmZsb3c6IGF1dG87XG4gICAgLy8ganVzdGlmeS1jb250ZW50OiBzcGFjZS1ldmVubHk7XG4gICAgLy8gdHJhbnNpdGlvbjogYWxsIDAuNzVzO1xuICAgIC5mb3JtLXdyYXBwZXIge1xuICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgIGhlaWdodDogMTAwdmg7XG4gICAgICB0cmFuc2l0aW9uOiBhbGwgMC4yNXM7XG4gICAgfVxuXG4gICAgLmxvZ28taW1nIHtcbiAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgIHdpZHRoOiAyNDVweDtcbiAgICAgIG1heC13aWR0aDogODAlO1xuICAgICAgLy8gdG9wOiAxMDBweDtcbiAgICAgIC8vIG1hcmdpbjogYXV0bztcbiAgICAgIC8vIG1hcmdpbi10b3A6IDEwMCU7XG4gICAgICBtYXJnaW4tYm90dG9tOiAwO1xuICAgICAgbWFyZ2luLWlubGluZTogYXV0bztcbiAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgdHJhbnNpdGlvbjogYWxsIDAuNzVzO1xuICAgICAgYW5pbWF0aW9uOiBhZGRNYXJnaW5Cb3R0b20gMC43NXMgbGluZWFyIDNzIGZvcndhcmRzO1xuICAgIH1cblxuICAgIC8vID4gKiB7XG4gICAgLy8gICBtYXJnaW4tdG9wOiBhdXRvO1xuICAgIC8vIH1cblxuICAgIFxuICAgIC5zd2l0Y2gtbGFuZ3VhZ2Uge1xuICAgICAgLy9kaXNwbGF5OiBibG9jaztcbiAgICAgIHBvc2l0aW9uOiBzdGlja3k7XG4gICAgICBib3R0b206IDA7XG4gICAgICB3aWR0aDogMTAwJTtcbiAgICAgIC8vIG1heC1oZWlnaHQ6IDA7XG4gICAgICBvcGFjaXR5OiAwO1xuICAgICAgLy8gb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICAgIHRyYW5zaXRpb246IGFsbCAwLjI1cztcbiAgICAgIGFuaW1hdGlvbjogc2hvd1N3aXRjaExhbmd1YWdlIDAuMjVzIGxpbmVhciAycyBmb3J3YXJkcztcbiAgICB9XG4gICAgLmxvZ2luLWZvcm0ge1xuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgdG9wOiAxMDBweDtcbiAgICAgIG1heC1oZWlnaHQ6IDA7XG4gICAgICBvcGFjaXR5OiAwO1xuICAgICAgLy8gb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICAgIC8vbWFyZ2luLWJvdHRvbTogMDtcbiAgICAgIHRyYW5zaXRpb246IGFsbCAwLjc1cztcbiAgICAgIC8vYW5pbWF0aW9uOiBhZGRNYXJnaW5Cb3R0b20gMC43NXMgbGluZWFyIDMuNXMgZm9yd2FyZHMsIHNob3dMb2dpbkNvbnRlbnQgMC43NXMgbGluZWFyIDMuNXMgZm9yd2FyZHM7XG4gICAgICBhbmltYXRpb246ICBzaG93TG9naW5Db250ZW50IDAuNzVzIGxpbmVhciAzcyBmb3J3YXJkcztcbiAgICB9XG5cbiAgICAvLyAmLmFuaW1hdGlvbiB7XG4gICAgLy8gICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWV2ZW5seTtcblxuICAgIC8vICAgLmxvZ28taW1nIHtcbiAgICAvLyAgICAgbWFyZ2luLWJvdHRvbTogMDtcbiAgICAvLyAgIH1cbiAgICAvLyAgIC5mb3JtLXdyYXBwZXIsXG4gICAgLy8gICAuc3dpdGNoLWxhbmd1YWdlIHtcbiAgICAvLyAgICAgbWF4LWhlaWdodDogNTAwcHg7XG4gICAgLy8gICAgIG9wYWNpdHk6IDE7XG4gICAgLy8gICAgIC8vIG1hcmdpbi10b3A6IGF1dG87XG4gICAgLy8gICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgLy8gICAgIGFuaW1hdGlvbjogc2hvd0xvZ2luQ29udGVudCAwLjc1cyBlYXNlLWluIDFzIGZvcndhcmRzO1xuICAgIC8vICAgfVxuICAgIC8vIH1cbiAgfVxuXG5cbiAgXG5cblxuXG5cbiAgaW9uLWl0ZW0uZmxvYXRpbmctaW5wdXQge1xuICAgIC0tYm9yZGVyLXJhZGl1czogNXB4O1xuICAgIHBhZGRpbmc6IDVweCAxNnB4O1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICAtLW1pbi1oZWlnaHQ6IDUwcHg7XG4gICAgY29sb3I6ICM5OWI5YmM7XG4gIFxuICAgICY6OnBhcnQobmF0aXZlKSB7XG4gICAgICAgIGJvcmRlcjogMS41cHggc29saWQgIzY1OTc5QTtcbiAgICAgICAgYmFja2dyb3VuZDogIzIyNjY2ZDtcbiAgICB9XG4gIFxuICAgIC8vIGlvbi1sYWJlbC5sYWJlbC1mbG9hdGluZyB7XG4gICAgLy8gfVxuICAgIGlvbi1pbnB1dCB7XG4gICAgICAgIHBhZGRpbmc6IDNweDtcbiAgICAgICAgaGVpZ2h0OiAzMHB4O1xuICAgICAgICBjb2xvcjogI0ZGRkZGRjtcbiAgICB9XG4gIH1cblxuICAucmVtZW1iZXItbWUge1xuICAgIC0tYmFja2dyb3VuZDogbm9uZTtcbiAgICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiBub25lO1xuICAgIC0taW5uZXItYm9yZGVyLXdpZHRoOiAwO1xuICAgIC0tcGFkZGluZy1zdGFydDogMDtcbiAgICAvLyBkaXNwbGF5OiBmbGV4O1xuICAgIC8vIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIFxuICAgIC8vIGlvbi1sYWJlbCB7XG4gICAgLy8gICBjb2xvcjogd2hpdGU7XG4gICAgLy8gICBwYWRkaW5nOiAwIDVweDtcbiAgICAvLyB9XG4gIFxuICAgIGlvbi1jaGVja2JveCB7XG4gICAgICAtLWJvcmRlci1yYWRpdXM6IDRweDtcbiAgICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gICAgICAtLWJhY2tncm91bmQtY2hlY2tlZDogI0ZGRkZGRjtcbiAgICAgIC0tYm9yZGVyLWNvbG9yOiAjOTlCOUJDO1xuICAgICAgLS1ib3JkZXItY29sb3ItY2hlY2tlZDogI0ZGRkZGRjtcbiAgICAgIC0tY2hlY2ttYXJrLWNvbG9yOiAjMDA1MTU3O1xuICAgICAgLS1jaGVja21hcmstd2lkdGg6IDJweDtcbiAgICAgIC0tc2l6ZTogMjBweDtcbiAgICB9XG5cbiAgICBpb24tbGFiZWwge1xuICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgICAgY29sb3I6ICM5OUI5QkM7XG4gICAgfVxuICB9XG5cbiAgaW9uLXJvdXRlci1saW5rIHtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgLS1jb2xvcjogIzk5QjlCQztcblxuICAgICYub3Blbi1hY2NvdW50LWxpbmsge1xuICAgICAgY29sb3I6ICNGRkZGRkY7XG4gICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgbWFyZ2luOiAzMHB4IDA7XG4gICAgfVxuICB9XG59XG5cblxuLy8gLmtleWJvYXJkLWlzLW9wZW4gLnN3aXRjaC1sYW5ndWFnZSB7XG4vLyAgIC8vZGlzcGxheTogbm9uZSAhaW1wb3J0YW50O1xuLy8gICBvcGFjaXR5OiAwICFpbXBvcnRhbnQ7XG4vLyAgIGFuaW1hdGlvbjogbm9uZSAhaW1wb3J0YW50O1xuLy8gfVxuXG5cblxuLy8gLmxvZ2luLWZvcm0ge1xuLy8gICAvLyBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4vLyAgIGJhY2tncm91bmQ6IHVybCgnL2Fzc2V0cy9sb2dpbi9sb2dpbi10b3AtYmcuc3ZnJyk7XG4vLyAgIGJhY2tncm91bmQtcG9zaXRpb246IHRvcCByaWdodDtcbi8vICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbi8vICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcblxuLy8gICAvLy8vLy8vLyFUT0RPOiBUaGlzIG5lZWRzIHRvIGJlIG5vcm1hbGl6ZWRcbi8vICAgcGFkZGluZzogMzBweCFpbXBvcnRhbnQ7XG4vLyAgIHBhZGRpbmctdG9wOiAzMHB4IWltcG9ydGFudDtcbi8vICAgcGFkZGluZy10b3A6IGNhbGMoMzBweCArIGNvbnN0YW50KHNhZmUtYXJlYS1pbnNldC10b3ApKSFpbXBvcnRhbnQ7XG4vLyAgIHBhZGRpbmctdG9wOiBjYWxjKDMwcHggKyBlbnYoc2FmZS1hcmVhLWluc2V0LXRvcCkpIWltcG9ydGFudDtcbi8vICAgLy8vLy8vLy9cbi8vIH1cblxuI292ZXJsYXkge1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIHRvcDogMDtcbiAgbGVmdDogMDtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgYmFja2dyb3VuZDogcmdiYSgwLCAwLCAwLCAwKTtcbiAgei1pbmRleDogOTk5OTtcbn1cbi5sb2dpbi1jaGFuZ2UtbGFuZy1idXR0b24ge1xuICBkaXNwbGF5OiBmbGV4O1xuICBjdXJzb3I6IHBvaW50ZXI7XG59XG5cbi8vIC5yZW1lbWJlci1tZSB7XG4vLyAgIGRpc3BsYXk6IGZsZXg7XG4vLyAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cbi8vICAgaW9uLWxhYmVsIHtcbi8vICAgICBjb2xvcjogd2hpdGU7XG4vLyAgICAgcGFkZGluZzogMCA1cHg7XG4vLyAgIH1cblxuLy8gICBpb24tY2hlY2tib3gge1xuLy8gICAgIC0tYm9yZGVyLXJhZGl1czogMDtcbi8vICAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuLy8gICAgIC0tYmFja2dyb3VuZC1jaGVja2VkOiB0cmFuc3BhcmVudDtcbi8vICAgICAtLWJvcmRlci1jb2xvcjogd2hpdGU7XG4vLyAgICAgLS1ib3JkZXItY29sb3ItY2hlY2tlZDogd2hpdGU7XG4vLyAgICAgLS1jaGVja21hcmstY29sb3I6IHZhcigtLWlvbi1jb2xvci1zdWNjZXNzKTtcbi8vICAgfVxuLy8gfVxuXG4vLyBpb24tdGV4dCB7XG4vLyAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS10eHQpO1xuLy8gfVxuXG4uZm9yZ290LXRleHQge1xuICAvLyBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcbiAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG59XG4vLyBpb24taXRlbSB7XG4vLyAgIC0tYmFja2dyb3VuZDogIzM4ODBmZjtcbi8vICAgLS1jb2xvcjogI2ZmZjtcbi8vIH1cbi8vIGlvbi1idXR0b24ge1xuLy8gICAtLWJhY2tncm91bmQ6ICMwNjJmNzc7XG4vLyB9XG5cbmlvbi1zbGlkZXMge1xuICBoZWlnaHQ6IDEwMCU7XG59Il19 */";

/***/ }),

/***/ 13262:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/login/force-update/force-update.component.html?ngResource ***!
  \*********************************************************************************/
/***/ ((module) => {

module.exports = "\n<ion-content class=\"container\">\n  <div class=\"gradient-bg\"></div>\n  <div style=\"text-align: center;margin-top: 50%;\">\n    <ion-grid class=\"ion-padding\">\n      <ion-row class=\"ion-justify-content-center ion-text-center\">\n        <ion-col size=\"10\">\n          <img src=\"assets/icon/force-Icon.svg\" class=\"icon segmentIcon\">\n          <h2 style=\"font-weight: bold;\"> {{'loginPage.FIRSTMSG' | translate}}</h2>\n          <h5 style=\"color: #888888;\">{{'loginPage.SECMSG' | translate}}</h5>\n          <app-button (clickAction)=\"openStore()\" expand=\"block\" size=\"\" color=\"success\" fill=\"solid\" strong=\"false\"\n            target=\"_blank\">\n            {{'loginPage.BTNMSG' | translate}}\n          </app-button>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </div>\n  \n</ion-content>\n";

/***/ }),

/***/ 96752:
/*!********************************************************!*\
  !*** ./src/app/pages/login/login.page.html?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = "<ion-content class=\"login-screen\">\n  <div class=\"gradient-bg\"></div>\n  <div id=\"overlay\" [ngClass]=\"{fadeable: true, visible: loading}\"></div>\n  <div class=\"login-content-wrapper animation\" [ngClass]=\"containerClass\">\n    <div class=\"form-wrapper\">\n      <img src=\"./../../../assets/splash-logo.svg\" class=\"logo-img\" />\n\n      <form [formGroup]=\"form\" (ngSubmit)=\"login(form)\" class=\"login-form\">\n        <ion-item class=\"floating-input\">\n          <ion-label position=\"floating\">{{'loginPage.USERNAME' | translate}}</ion-label>\n          <ion-input (ionFocus)=\"setKeyboardClass(true)\" (ionBlur)=\"setKeyboardClass(false)\" [formControl]=\"form.controls.username\" name=\"username\" (keyup)=\"preventSpaceInUserName(username)\" [(ngModel)]=\"username\" ngDefaultControl></ion-input>\n          <span class=\"icon icon-user\" slot=\"start\"></span>\n\n        </ion-item>\n        <ion-item class=\"floating-input\">\n          <ion-label position=\"floating\">{{'loginPage.PASSWORD' | translate}}</ion-label>\n          <ion-input (ionFocus)=\"setKeyboardClass(true)\" (ionBlur)=\"setKeyboardClass(false)\" [formControl]=\"form.controls.password\" name=\"password\" type=\"password\" (keyup)=\"preventSpaceInPassword(password)\" [(ngModel)]=\"password\" ngDefaultControl></ion-input>\n          <span class=\"icon icon-lock\" slot=\"start\"></span>\n        </ion-item>\n\n        <ion-grid class=\"ion-padding\">\n          <ion-row class=\"ion-justify-content-between ion-align-items-center\">\n            <ion-col size=\"auto\" class=\"ion-no-padding\">\n              <ion-item class=\"remember-me\">\n                <ion-checkbox [formControl]=\"form.controls.rememberMe\" name=\"rememberMe\" [(ngModel)]=\"rememberMe\"></ion-checkbox>\n                <ion-label>{{'loginPage.REMEMBER_ME' | translate}}</ion-label>\n              </ion-item>\n            </ion-col>\n\n            <ion-col size=\"auto\" class=\"ion-no-padding\">\n              <ion-router-link class=\"underline\" (click)=\"goToForgot()\">{{'loginPage.FORGOT_USERNAME_OR_PASSWORD' | translate}}</ion-router-link>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n        <in-button color=\"success\" [(loading)]=\"loading\" [disabled]=\"!form.valid\" expand=\"block\" fill=\"solid\" type=\"submit\" class=\"ion-margin\">\n          {{ 'loginPage.LOGIN' | translate }}\n        </in-button>\n        <ion-router-link class=\"underline open-account-link ion-text-center\" (click)=\"openCreateAccount()\">{{'loginPage.OPEN_ACCOUNT' | translate}}</ion-router-link>\n        <ion-router-link class=\"underline open-account-link ion-text-center\" (click)=\"openRegisterNewUser()\">{{'loginPage.REGISTER_ACCOUNT' | translate}}</ion-router-link>\n      </form>\n    </div>\n    <div class=\"ion-padding ion-text-center switch-language\">\n      <p (click)=\"changeLang()\"><span class=\"icon icon-globe\"></span> {{ appLang == 'ar' ? 'English' : 'عربي' }}</p>\n    </div>\n  </div>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_login_login_module_ts.js.map