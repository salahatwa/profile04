"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_products_product-subscribe_product-subscribe_module_ts"],{

/***/ 85645:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/products/product-subscribe/product-subscribe-routing.module.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductSubscribePageRoutingModule": () => (/* binding */ ProductSubscribePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _product_subscribe_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./product-subscribe.page */ 48868);




const routes = [
    {
        path: '',
        component: _product_subscribe_page__WEBPACK_IMPORTED_MODULE_0__.ProductSubscribePage
    }
];
let ProductSubscribePageRoutingModule = class ProductSubscribePageRoutingModule {
};
ProductSubscribePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ProductSubscribePageRoutingModule);



/***/ }),

/***/ 89685:
/*!******************************************************************************!*\
  !*** ./src/app/pages/products/product-subscribe/product-subscribe.module.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductSubscribePageModule": () => (/* binding */ ProductSubscribePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _product_subscribe_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./product-subscribe-routing.module */ 85645);
/* harmony import */ var _product_subscribe_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./product-subscribe.page */ 48868);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);









let ProductSubscribePageModule = class ProductSubscribePageModule {
};
ProductSubscribePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _product_subscribe_routing_module__WEBPACK_IMPORTED_MODULE_0__.ProductSubscribePageRoutingModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateModule.forChild()
        ],
        declarations: [_product_subscribe_page__WEBPACK_IMPORTED_MODULE_1__.ProductSubscribePage]
    })
], ProductSubscribePageModule);



/***/ }),

/***/ 48868:
/*!****************************************************************************!*\
  !*** ./src/app/pages/products/product-subscribe/product-subscribe.page.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductSubscribePage": () => (/* binding */ ProductSubscribePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _product_subscribe_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./product-subscribe.page.html?ngResource */ 42975);
/* harmony import */ var _product_subscribe_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./product-subscribe.page.scss?ngResource */ 75120);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var src_app_providers_validation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/providers/validation */ 11852);
/* harmony import */ var _inma_models_products_products_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/models/products/products.model */ 37426);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var _inma_models_products_product_doings__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @inma/models/products/product-doings */ 50348);










let ProductSubscribePage = class ProductSubscribePage {
    constructor(navCtrl, formBuilder, sharedData) {
        this.navCtrl = navCtrl;
        this.formBuilder = formBuilder;
        this.sharedData = sharedData;
        this.product = { plan: "", account: "", autoRenewal: "" };
        this.productDoings = _inma_models_products_product_doings__WEBPACK_IMPORTED_MODULE_5__.ProductDoings;
        this.showLoader = false;
        this.buildForm();
        // this.getAccounts();
    }
    ngOnInit() {
        // this.sharedProduct = this.sharedData.getSharedData("sharedProduct", false);
        // this.sharedProductMode = this.sharedData.getSharedData("sharedProductMode", false);
    }
    ionViewWillEnter() {
        this.sharedProduct = this.sharedData.getSharedData("sharedProduct", false);
        this.sharedProductMode = this.sharedData.getSharedData("sharedProductMode", false);
        this.buildForm();
        this.getAccounts();
    }
    getAccounts() {
        _inma_models_products_products_model__WEBPACK_IMPORTED_MODULE_3__.Products.subscribableAccounts.subscribe((accounts) => {
            this.accounts = accounts;
            console.log(this.accounts);
        });
    }
    buildForm() {
        this.form = this.formBuilder.group({
            plan: ["", src_app_providers_validation__WEBPACK_IMPORTED_MODULE_2__.ValidationProvider.required],
            account: ["", src_app_providers_validation__WEBPACK_IMPORTED_MODULE_2__.ValidationProvider.required],
            autoRenewal: [],
        });
    }
    planChanged() {
        console.log('changed');
    }
    accountChanged() {
        console.log('changed');
    }
    subscribe(form) {
        console.log(form);
        if (form.invalid) {
            return;
        }
        this.showLoader = true;
        this.sharedProduct.do(this.product['plan'], this.product['account'], this.product['autoRenewal'], this.sharedProductMode).subscribe({
            next: (subscriptionResult) => {
                console.log(subscriptionResult);
                this.sharedProduct = Object.assign({}, this.sharedProduct, { selectedPlan: this.product['plan'] });
                console.log(this.sharedProduct);
                this.sharedData.setSharedData(subscriptionResult, "sharedProductSubscriptionResult");
                // this.sharedData.removeData("sharedProduct");
                this.sharedData.setSharedData(this.sharedProduct, "sharedProduct");
                this.showLoader = false;
                // MyApp.openPage(this.navCtrl, "ProductSubscriptionSummaryPage", false, { productSubscriptionResult:  })
                this.navCtrl.navigateForward(['main/product-subscribe-summary']);
            },
            error: (err) => {
                this.showLoader = false;
                console.log(err);
            }
        });
    }
};
ProductSubscribePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder },
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_4__.SharedDataService }
];
ProductSubscribePage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'tadawul-product-subscribe',
        template: _product_subscribe_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_product_subscribe_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__metadata)("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder, src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_4__.SharedDataService])
], ProductSubscribePage);



/***/ }),

/***/ 11852:
/*!*****************************************!*\
  !*** ./src/app/providers/validation.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ValidationProvider": () => (/* binding */ ValidationProvider)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _inma_strings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/strings */ 36782);




let ValidationProvider = class ValidationProvider extends _angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators {
    static number(control) {
        let value = control.value;
        value = value ? _inma_strings__WEBPACK_IMPORTED_MODULE_0__.Strings.normalizeArabicNumbers(value) : value;
        if (value && !value.match(/^([0-9\u0660-\u0669]*)(\.([0-9\u0660-\u0669]*))?$/)) {
            return {
                'number': value
            };
        }
        else
            return null;
    }
    static integer(control) {
        let value = control.value;
        value = value ? _inma_strings__WEBPACK_IMPORTED_MODULE_0__.Strings.normalizeArabicNumbers(value) : value;
        if (value && !value.match(/^([0-9\u0660-\u0669]+)$/)) {
            return {
                'integer': value
            };
        }
        else
            return null;
    }
    static max(max) {
        return (control) => {
            let value = control.value;
            value = value ? _inma_strings__WEBPACK_IMPORTED_MODULE_0__.Strings.normalizeArabicNumbers(value) : value;
            if (max && (parseFloat(value) > max)) {
                return {
                    'max': {
                        value: value
                    }
                };
            }
            else
                return null;
        };
    }
    static min(min) {
        return (control) => {
            let value = control.value;
            value = value ? _inma_strings__WEBPACK_IMPORTED_MODULE_0__.Strings.normalizeArabicNumbers(value) : value;
            if (min && (parseFloat(value) < min)) {
                return {
                    'min': {
                        value: value
                    }
                };
            }
            else
                return null;
        };
    }
    static equals(equalityFunction, isNumber = false) {
        return (control) => {
            let value = control.value;
            if (isNumber)
                value = value ? _inma_strings__WEBPACK_IMPORTED_MODULE_0__.Strings.normalizeArabicNumbers(value) : value;
            if (equalityFunction(value) == false) {
                return {
                    'equals': {
                        value: value
                    }
                };
            }
            else
                return null;
        };
    }
    static priceTick(control) {
        let value = control.value;
        value = value ? _inma_strings__WEBPACK_IMPORTED_MODULE_0__.Strings.normalizeArabicNumbers(value) : value;
        if (value) {
            var tick = 0;
            if (value.indexOf(".") != "-1") {
                var fractionString = value.slice(value.indexOf(".") + 1, value.length);
                if (fractionString) {
                    var fraction = parseFloat("0." + fractionString);
                    if (value < 10)
                        tick = 0.01;
                    else if (value >= 10 && value < 25)
                        tick = 0.02;
                    else if (value >= 25 && value < 50)
                        tick = 0.05;
                    else if (value >= 50 && value < 100)
                        tick = 0.1;
                    else if (value >= 100)
                        tick = 0.2;
                    if (!(((fraction * 1000) / (tick * 1000)) % 1 === 0))
                        return {
                            'priceTick': tick
                        };
                    else
                        return null;
                }
            }
            else
                return null;
        }
        else
            return null;
    }
};
ValidationProvider = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)()
], ValidationProvider);



/***/ }),

/***/ 75120:
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/products/product-subscribe/product-subscribe.page.scss?ngResource ***!
  \*****************************************************************************************/
/***/ ((module) => {

module.exports = "form ion-item {\n  color: #005457;\n  --padding-start: 16px;\n  --padding-end: 8px;\n}\nform ion-item ion-select {\n  border: 1px solid #99b9bc;\n  padding: 10px;\n}\nbody.dark :host form ion-item {\n  color: white;\n}\nform ion-item {\n  --border-color: transparent;\n}\nion-toolbar {\n  --background: #005157;\n  --color: white;\n}\nbody.dark :host ion-text {\n  color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2R1Y3Qtc3Vic2NyaWJlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDSTtFQUNJLGNBQUE7RUFDQSxxQkFBQTtFQUNBLGtCQUFBO0FBQVI7QUFDUTtFQUNJLHlCQUFBO0VBQ0EsYUFBQTtBQUNaO0FBRVE7RUFDSSxZQUFBO0FBQVo7QUFJSTtFQUNJLDJCQUFBO0FBRlI7QUFNQTtFQUNJLHFCQUFBO0VBQ0EsY0FBQTtBQUhKO0FBT0k7RUFDSSxZQUFBO0FBSlIiLCJmaWxlIjoicHJvZHVjdC1zdWJzY3JpYmUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiZm9ybSB7XG4gICAgaW9uLWl0ZW0ge1xuICAgICAgICBjb2xvcjogIzAwNTQ1NztcbiAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAxNnB4O1xuICAgICAgICAtLXBhZGRpbmctZW5kOiA4cHg7XG4gICAgICAgIGlvbi1zZWxlY3Qge1xuICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgIzk5YjliYztcbiAgICAgICAgICAgIHBhZGRpbmc6IDEwcHg7XG4gICAgICAgIH1cblxuICAgICAgICBib2R5LmRhcmsgOmhvc3QgJiB7XG4gICAgICAgICAgICBjb2xvcjogd2hpdGU7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBpb24taXRlbSB7XG4gICAgICAgIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgICB9XG59XG5cbmlvbi10b29sYmFyIHtcbiAgICAtLWJhY2tncm91bmQ6ICMwMDUxNTc7XG4gICAgLS1jb2xvcjogd2hpdGU7XG4gIH1cblxuICBpb24tdGV4dHtcbiAgICBib2R5LmRhcmsgOmhvc3QgJntcbiAgICAgICAgY29sb3I6d2hpdGU7XG4gICAgfVxufSJdfQ== */";

/***/ }),

/***/ 42975:
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/products/product-subscribe/product-subscribe.page.html?ngResource ***!
  \*****************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\"></ion-back-button>\n    </ion-buttons>\n    <ion-title slot=\"start\">{{sharedProduct?.name}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <form [formGroup]=\"form\" (ngSubmit)=\"subscribe(form)\">\n    <!-- DURATION -->\n    <ion-item>\n      <ion-label position=\"stacked\">{{ 'product.DURATION' | translate }}</ion-label>\n      <ion-select placeholder=\"{{ 'product.SELECT' | translate }}\" formControlName=\"plan\" name=\"plan\" okText=\"{{ 'product.OK }}\"\n        interface=\"action-sheet\" mode=\"ios\" [interfaceOptions]=\"{header: 'product.DURATION' | translate, cssClass: 'app-select'}\"\n        cancelText=\"{{ 'product.CANCEL' | translate }}\" [(ngModel)]=\"product.plan\" (ngModelChange)=\"planChanged()\">\n\n        <ion-select-option *ngFor=\"let p of sharedProduct?.plans\" [value]=\"p\">\n         <b> {{ p.price }} {{ 'product.SAR' | translate }}</b> / {{ p.months }} {{ 'product.MONTH' | translate }}\n        </ion-select-option>\n\n      </ion-select>\n\n      <div *ngIf=\"!form.controls.plan.valid\n                  && form.controls.plan.dirty\" class=\"validator-error\">\n        {{ 'product.PLEASE_CHOOSE' | translate }} {{ 'product.DURATION' | translate }}\n      </div>\n    </ion-item>\n    <!-- ACCOUNTS -->\n    <ion-item>\n      <ion-label position=\"stacked\">{{ 'product.ACCOUNTS' | translate }}</ion-label>\n      <ion-select placeholder=\"{{ 'product.SELECT' | translate }}\" formControlName=\"account\" name=\"account\" okText=\"{{ 'product.OK' | translate }}\"\n        interface=\"action-sheet\" mode=\"ios\" [interfaceOptions]=\"{header: 'product.ACCOUNTS' | translate, cssClass: 'app-select'}\"\n        cancelText=\"{{ 'product.CANCEL' | translate }}\" [(ngModel)]=\"product.account\" (ngModelChange)=\"accountChanged()\">\n        <ion-select-option *ngFor=\"let account of accounts\" [value]=\"account\">\n          {{ account.name }}\n        </ion-select-option>\n      </ion-select>\n      <div *ngIf=\"!form.controls.account.valid\n                  && form.controls.account.dirty\" class=\"validator-error\">\n        {{ 'product.PLEASE_CHOOSE' | translate }} {{ 'product.ACCOUNT' | translate }}\n      </div>\n    </ion-item>\n\n    <!-- PRODUCT DATA -->\n    <div class=\"ion-padding\" *ngIf=\"product?.plan\">\n      <ion-text class=\"bold\" color=\"primary\">{{'product.FEE_CATEGORY' | translate}}</ion-text>\n      <div class=\"box-with-bg ion-margin-bottom\">\n        <ion-row class=\"data-row\">\n          <ion-col size=\"6\">\n            <ion-text class=\"label font-size-caption\" color=\"primary\">{{'product.MUBASHER_FEES' | translate}}</ion-text>\n          </ion-col>\n          <ion-col size=\"6\">\n            <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n                {{ product?.plan?.fees['MUBASHER_FEES_ID']?.price }} {{ product?.plan?.fees['MUBASHER_FEES_ID']?.currency }}\n            </ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"data-row\">\n          <ion-col size=\"6\">\n            <ion-text class=\"label font-size-caption\" color=\"primary\">{{'product.ALINMA_FEES' | translate}}</ion-text>\n          </ion-col>\n          <ion-col size=\"6\">\n            <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n                {{ product?.plan?.fees['INMA_FEES_ID']?.price }} {{ product?.plan?.fees['INMA_FEES_ID']?.currency }}\n            </ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"data-row\">\n          <ion-col size=\"6\">\n            <ion-text class=\"label font-size-caption\" color=\"primary\">{{'product.TADAWUL_FEES' | translate}}</ion-text>\n          </ion-col>\n          <ion-col size=\"6\">\n            <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n                {{ product?.plan?.fees['TADAWUL_FEES_ID']?.price }} {{ product?.plan?.fees['TADAWUL_FEES_ID']?.currency }}\n            </ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"data-row\">\n          <ion-col size=\"6\">\n            <ion-text class=\"label font-size-caption\" color=\"primary\">{{'product.IDEAL_CLASSIFICATION' | translate}}</ion-text>\n          </ion-col>\n          <ion-col size=\"6\">\n            <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n                {{ product?.plan?.fees['IDEAL_RATING_ID']?.price }} {{ product?.plan?.fees['IDEAL_RATING_ID']?.currency }}\n\n            </ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"data-row\">\n          <ion-col size=\"6\">\n            <ion-text class=\"label font-size-caption\" color=\"primary\">{{'product.VAT' | translate}}</ion-text>\n          </ion-col>\n          <ion-col size=\"6\">\n            <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n                {{ product?.plan?.fees['VAT_ID']?.price }} {{ product?.plan?.fees['VAT_ID']?.currency }}\n            </ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"data-row\">\n          <ion-col size=\"6\">\n            <ion-text class=\"label font-size-caption\" color=\"primary\">{{'product.TOTAL_COST' | translate}}</ion-text>\n          </ion-col>\n          <ion-col size=\"6\">\n            <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n                {{ product?.plan?.price }} {{ product?.plan?.currency }}\n            </ion-text>\n          </ion-col>\n        </ion-row>\n      </div>\n    </div>\n\n    <div class=\"autoRenewal\" *ngIf=\"sharedProductMode == productDoings.Subscribe\">\n      <ion-checkbox color=\"primary\" [formControl]=\"form.controls.autoRenewal\" name=\"autoRenewal\" [(ngModel)]=\"product.autoRenewal\"></ion-checkbox>\n      <ion-label>{{'product.AUTO_RENEWAL' | translate}}</ion-label>\n    </div>\n\n    <div class=\"ion-padding\">\n      <app-button \n          expand=\"block\" \n          size=\"\"\n          color=\"primary\"\n          fill=\"solid\"\n          shape=\"\"\n          type=\"submit\"\n          >\n          {{((sharedProductMode === productDoings.Subscribe) ? 'product.SUBSCRIBE' : '' )| translate}}\n          {{((sharedProductMode === productDoings.Extend) ? 'product.EXTEND_SUBSCRIPTION' : '' )| translate}}\n        </app-button>\n    </div>\n  </form>\n  <tadawul-loader *ngIf=\"showLoader\"></tadawul-loader>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_products_product-subscribe_product-subscribe_module_ts.js.map