import { TranslateService } from '@ngx-translate/core';
import { Component, OnInit } from '@angular/core';
import { Translations } from '@inma/helpers/translations';
import { forgotTranslations } from '../../forget-username-password/forgot.translations';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { forget } from '@inma/models/forget-user-pass';
import { AlertController } from '@ionic/angular';
import { NavController } from "@ionic/angular";


@Component({
  selector: 'tadawul-forgot-username',
  templateUrl: './forgot-username.page.html',
  styleUrls: ['./forgot-username.page.scss'],
})
export class ForgotUsernamePage implements OnInit {

  form: FormGroup;
  formData = {
    idType: '',
    accountNumber: ''
  };

  constructor(private formBuilder: FormBuilder, public translate: TranslateService,public alertController: AlertController, public navCtrl: NavController) {
    this.buildForm();
  }

  buildForm() {
    this.form = this.formBuilder.group({
      idType: [
        '', Validators.compose([
          Validators.required,
          Validators.minLength(10),
          Validators.maxLength(10)
        ])
      ],
      accountNumber: [
        '', Validators.compose([
          Validators.required,
          Validators.minLength(12),
          Validators.maxLength(12)
        ])
      ],
    });
  }

  ngOnInit() {
  }

  retrieve(form) {
    console.log(form);
    if (form.invalid) {
      return;
    }
    
    forget.forgetUsername(this.formData.idType, this.formData.accountNumber).subscribe(res=> {
      this.presentUsername(res);
      this.navCtrl.navigateRoot('', { animated: true });
    });
  }

  async presentUsername(res) {
    const alert = await this.alertController.create({
      header: this.translate.instant('forgot.USERNAME'),
      message: res.loginName,
      buttons: [this.translate.instant('forgot.OK')]
    });

    await alert.present();
  }

}
