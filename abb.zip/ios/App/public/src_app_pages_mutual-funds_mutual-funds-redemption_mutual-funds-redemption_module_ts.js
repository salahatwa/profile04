"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_mutual-funds_mutual-funds-redemption_mutual-funds-redemption_module_ts"],{

/***/ 56753:
/*!******************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-redemption/mutual-funds-redemption-routing.module.ts ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsRedemptionPageRoutingModule": () => (/* binding */ MutualFundsRedemptionPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _mutual_funds_redemption_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-funds-redemption.page */ 98540);




const routes = [
    {
        path: '',
        component: _mutual_funds_redemption_page__WEBPACK_IMPORTED_MODULE_0__.MutualFundsRedemptionPage
    }
];
let MutualFundsRedemptionPageRoutingModule = class MutualFundsRedemptionPageRoutingModule {
};
MutualFundsRedemptionPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MutualFundsRedemptionPageRoutingModule);



/***/ }),

/***/ 29292:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-redemption/mutual-funds-redemption.module.ts ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsRedemptionPageModule": () => (/* binding */ MutualFundsRedemptionPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _mutual_funds_redemption_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-funds-redemption-routing.module */ 56753);
/* harmony import */ var _mutual_funds_redemption_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mutual-funds-redemption.page */ 98540);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);
/* harmony import */ var src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/pipes/pipes.module */ 41041);










let MutualFundsRedemptionPageModule = class MutualFundsRedemptionPageModule {
};
MutualFundsRedemptionPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _mutual_funds_redemption_routing_module__WEBPACK_IMPORTED_MODULE_0__.MutualFundsRedemptionPageRoutingModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateModule.forChild(),
            src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_3__.PipesModule
        ],
        declarations: [
            _mutual_funds_redemption_page__WEBPACK_IMPORTED_MODULE_1__.MutualFundsRedemptionPage,
            // CommafyPipe,
            // SARPipe
        ]
    })
], MutualFundsRedemptionPageModule);



/***/ }),

/***/ 98540:
/*!********************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-redemption/mutual-funds-redemption.page.ts ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsRedemptionPage": () => (/* binding */ MutualFundsRedemptionPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _mutual_funds_redemption_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-funds-redemption.page.html?ngResource */ 4733);
/* harmony import */ var _mutual_funds_redemption_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mutual-funds-redemption.page.scss?ngResource */ 96516);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/core */ 26549);
/* harmony import */ var _inma_helpers_file__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/helpers/file */ 96245);
/* harmony import */ var _inma_models_mutual_funds_mutual_fund_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/models/mutual-funds/mutual-fund.model */ 51530);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 19193);
/* harmony import */ var src_app_providers_validation__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/providers/validation */ 11852);
/* harmony import */ var _providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../providers/mutual-funds.service */ 1835);













const { Browser } = _capacitor_core__WEBPACK_IMPORTED_MODULE_2__.Plugins;
let MutualFundsRedemptionPage = class MutualFundsRedemptionPage {
    constructor(mutualFundsService, translate, formBuilder, navCtrl, file) {
        this.mutualFundsService = mutualFundsService;
        this.translate = translate;
        this.formBuilder = formBuilder;
        this.navCtrl = navCtrl;
        this.file = file;
        this.terms = false;
        this.submitted = false;
        this.amount = 0;
        this.MutualFundRedemptionTypes = _inma_models_mutual_funds_mutual_fund_model__WEBPACK_IMPORTED_MODULE_4__.MutualFundRedemptionTypes;
        this.redemptionType = _inma_models_mutual_funds_mutual_fund_model__WEBPACK_IMPORTED_MODULE_4__.MutualFundRedemptionTypes.NumberOfUnits;
        this.loading = false;
        this.buildForm();
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.mutualFund = this.mutualFundsService.getMutualFund();
        console.log(this.mutualFund);
        this.form.controls.amount.setValue('');
        this.form.controls.terms.setValue(false);
        this.mutualFund.portfolios.subscribe((portfolios) => {
            console.log(portfolios);
            this.portfolios = portfolios;
            if (this.mutualFund.portfolio) {
                this.findPortfolioById(this.mutualFund.portfolio.id).then((res) => {
                    this.portfolio = res;
                });
            }
            else if (!this.mutualFund.portfolio && (portfolios && portfolios.length)) {
                this.mutualFund.portfolio = portfolios[0];
                this.portfolio = portfolios[0];
            }
        });
        this.mutualFund.details.subscribe(details => {
            this.details = details;
        });
    }
    findPortfolioById(id) {
        return new Promise((resolve, reject) => {
            this.portfolios.forEach((p) => {
                if (p.id === id) {
                    resolve(p);
                }
            });
        });
    }
    buildForm() {
        this.form = this.formBuilder.group({
            portfolio: [
                '', _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required
                ])
            ],
            amount: [
                '', _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required
                ])
            ],
            terms: [
                '', _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.requiredTrue
                ])
            ]
        });
    }
    redemption(form) {
        console.log(form);
        console.log(this.terms);
        this.submitted = true;
        if (form.invalid || !this.terms) {
            return;
        }
        this.mutualFund.formData = {
            portfolio: this.mutualFund.portfolio,
            amount: this.amount,
            redemptionType: this.redemptionType
        };
        this.mutualFundsService.setMutualFund(this.mutualFund);
        this.navCtrl.navigateForward('main/mutual-funds-redemption-confirm');
    }
    camelize(string) {
        var result = "";
        for (var i = 0; i < string.length; i++) {
            var word = string[i];
            var capitalizedWord = word.charAt(0).toUpperCase() + word.slice(1);
            result += capitalizedWord;
        }
        return result;
    }
    ;
    get minimumRedemptionUnits() {
        if (!this.details)
            return;
        if (this.details.minimumRedemptionUnitType == _inma_models_mutual_funds_mutual_fund_model__WEBPACK_IMPORTED_MODULE_4__.UnitTypes.Currency)
            return this.details.minimumRedemption / this.details.unitPrice;
        else
            return this.details.minimumRedemption;
    }
    get minimumRedemptionCurrency() {
        if (!this.details)
            return;
        if (this.details.minimumRedemptionUnitType == _inma_models_mutual_funds_mutual_fund_model__WEBPACK_IMPORTED_MODULE_4__.UnitTypes.Currency)
            return this.details.minimumRedemption;
        else
            return this.details.minimumRedemption * this.details.unitPrice;
    }
    get maximumRedemptionUnits() {
        var _a;
        return (_a = this.mutualFund) === null || _a === void 0 ? void 0 : _a.ownedUnits;
    }
    get maximumRedemptionCurrency() {
        var _a, _b;
        return ((_a = this.mutualFund) === null || _a === void 0 ? void 0 : _a.ownedUnits) * ((_b = this.mutualFund) === null || _b === void 0 ? void 0 : _b.unitPrice);
    }
    selectRedemptionType(redemptionType) {
        this.redemptionType = redemptionType;
        if (redemptionType == _inma_models_mutual_funds_mutual_fund_model__WEBPACK_IMPORTED_MODULE_4__.MutualFundRedemptionTypes.AllUnits) {
            this.form.controls['amount'].setValidators([src_app_providers_validation__WEBPACK_IMPORTED_MODULE_5__.ValidationProvider.nullValidator]);
        }
        else if (redemptionType == _inma_models_mutual_funds_mutual_fund_model__WEBPACK_IMPORTED_MODULE_4__.MutualFundRedemptionTypes.NumberOfUnits) {
            this.form.controls['amount'].setValidators([src_app_providers_validation__WEBPACK_IMPORTED_MODULE_5__.ValidationProvider.required, src_app_providers_validation__WEBPACK_IMPORTED_MODULE_5__.ValidationProvider.number, src_app_providers_validation__WEBPACK_IMPORTED_MODULE_5__.ValidationProvider.min(this.minimumRedemptionUnits), src_app_providers_validation__WEBPACK_IMPORTED_MODULE_5__.ValidationProvider.max(this.maximumRedemptionUnits)]);
        }
        else if (redemptionType == _inma_models_mutual_funds_mutual_fund_model__WEBPACK_IMPORTED_MODULE_4__.MutualFundRedemptionTypes.Amount) {
            this.form.controls['amount'].setValidators([src_app_providers_validation__WEBPACK_IMPORTED_MODULE_5__.ValidationProvider.required, src_app_providers_validation__WEBPACK_IMPORTED_MODULE_5__.ValidationProvider.number, src_app_providers_validation__WEBPACK_IMPORTED_MODULE_5__.ValidationProvider.min(this.minimumRedemptionCurrency), src_app_providers_validation__WEBPACK_IMPORTED_MODULE_5__.ValidationProvider.max(this.maximumRedemptionCurrency)]);
        }
        // this.form.controls['terms'].setValidators([ValidationProvider.requiredTrue]);
        this.form.controls['amount'].updateValueAndValidity();
        // this.form.controls['terms'].updateValueAndValidity();
    }
    portfolioChanged(val) {
        console.log(val);
        if (this.mutualFund) {
            this.mutualFund['portfolio'] = val;
        }
        // this.portfolio = val;
    }
    openTermsAndConditions() {
        this.loading = true;
        (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.combineLatest)([this.mutualFund.termsAndConditions]).subscribe((data) => {
            this.loading = false;
            this.file.openBase64File(data);
        });
    }
};
MutualFundsRedemptionPage.ctorParameters = () => [
    { type: _providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_6__.MutualFundsService },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateService },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.NavController },
    { type: _inma_helpers_file__WEBPACK_IMPORTED_MODULE_3__.Files }
];
MutualFundsRedemptionPage = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.Component)({
        selector: 'tadawul-mutual-funds-redemption',
        template: _mutual_funds_redemption_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_mutual_funds_redemption_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:paramtypes", [_providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_6__.MutualFundsService, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateService, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.NavController, _inma_helpers_file__WEBPACK_IMPORTED_MODULE_3__.Files])
], MutualFundsRedemptionPage);



/***/ }),

/***/ 1835:
/*!***************************************************!*\
  !*** ./src/app/providers/mutual-funds.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsService": () => (/* binding */ MutualFundsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let MutualFundsService = class MutualFundsService {
    constructor() { }
    setMutualFund(mutualFund) {
        this.mutualFund = mutualFund;
    }
    getMutualFund() {
        return this.mutualFund;
    }
};
MutualFundsService.ctorParameters = () => [];
MutualFundsService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Injectable)({
        providedIn: 'root'
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__metadata)("design:paramtypes", [])
], MutualFundsService);



/***/ }),

/***/ 11852:
/*!*****************************************!*\
  !*** ./src/app/providers/validation.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ValidationProvider": () => (/* binding */ ValidationProvider)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _inma_strings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/strings */ 36782);




let ValidationProvider = class ValidationProvider extends _angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators {
    static number(control) {
        let value = control.value;
        value = value ? _inma_strings__WEBPACK_IMPORTED_MODULE_0__.Strings.normalizeArabicNumbers(value) : value;
        if (value && !value.match(/^([0-9\u0660-\u0669]*)(\.([0-9\u0660-\u0669]*))?$/)) {
            return {
                'number': value
            };
        }
        else
            return null;
    }
    static integer(control) {
        let value = control.value;
        value = value ? _inma_strings__WEBPACK_IMPORTED_MODULE_0__.Strings.normalizeArabicNumbers(value) : value;
        if (value && !value.match(/^([0-9\u0660-\u0669]+)$/)) {
            return {
                'integer': value
            };
        }
        else
            return null;
    }
    static max(max) {
        return (control) => {
            let value = control.value;
            value = value ? _inma_strings__WEBPACK_IMPORTED_MODULE_0__.Strings.normalizeArabicNumbers(value) : value;
            if (max && (parseFloat(value) > max)) {
                return {
                    'max': {
                        value: value
                    }
                };
            }
            else
                return null;
        };
    }
    static min(min) {
        return (control) => {
            let value = control.value;
            value = value ? _inma_strings__WEBPACK_IMPORTED_MODULE_0__.Strings.normalizeArabicNumbers(value) : value;
            if (min && (parseFloat(value) < min)) {
                return {
                    'min': {
                        value: value
                    }
                };
            }
            else
                return null;
        };
    }
    static equals(equalityFunction, isNumber = false) {
        return (control) => {
            let value = control.value;
            if (isNumber)
                value = value ? _inma_strings__WEBPACK_IMPORTED_MODULE_0__.Strings.normalizeArabicNumbers(value) : value;
            if (equalityFunction(value) == false) {
                return {
                    'equals': {
                        value: value
                    }
                };
            }
            else
                return null;
        };
    }
    static priceTick(control) {
        let value = control.value;
        value = value ? _inma_strings__WEBPACK_IMPORTED_MODULE_0__.Strings.normalizeArabicNumbers(value) : value;
        if (value) {
            var tick = 0;
            if (value.indexOf(".") != "-1") {
                var fractionString = value.slice(value.indexOf(".") + 1, value.length);
                if (fractionString) {
                    var fraction = parseFloat("0." + fractionString);
                    if (value < 10)
                        tick = 0.01;
                    else if (value >= 10 && value < 25)
                        tick = 0.02;
                    else if (value >= 25 && value < 50)
                        tick = 0.05;
                    else if (value >= 50 && value < 100)
                        tick = 0.1;
                    else if (value >= 100)
                        tick = 0.2;
                    if (!(((fraction * 1000) / (tick * 1000)) % 1 === 0))
                        return {
                            'priceTick': tick
                        };
                    else
                        return null;
                }
            }
            else
                return null;
        }
        else
            return null;
    }
};
ValidationProvider = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)()
], ValidationProvider);



/***/ }),

/***/ 96516:
/*!*********************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-redemption/mutual-funds-redemption.page.scss?ngResource ***!
  \*********************************************************************************************************/
/***/ ((module) => {

module.exports = ".inner-box-label {\n  display: block;\n  color: var(--ion-color-primary-tint);\n}\n\n.terms-agree {\n  display: flex;\n  align-items: center;\n}\n\n.terms-agree ion-label {\n  padding: 0 5px;\n}\n\n.box-with-bg-tangerine {\n  background: #fdf9f2;\n  border: 1px solid var(--ion-color-warning);\n}\n\n.text-color-tangerine {\n  color: var(--ion-color-warning);\n}\n\n.amount-input ion-label {\n  color: var(--ion-color-primary);\n}\n\n.amount-input ion-input {\n  border: 1px solid #99b9bc;\n  color: var(--ion-color-primary);\n  --padding-start: 10px;\n}\n\n#link-to-terms-and-conditions {\n  text-decoration: underline;\n  color: #F93F03;\n}\n\n#amount-display {\n  font-size: 14px;\n  color: var(--ion-color-primary-txt);\n  margin-bottom: 16px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm11dHVhbC1mdW5kcy1yZWRlbXB0aW9uLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGNBQUE7RUFDQSxvQ0FBQTtBQUNKOztBQUVBO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0FBQ0o7O0FBQ0k7RUFDSSxjQUFBO0FBQ1I7O0FBR0E7RUFDSSxtQkFBQTtFQUNBLDBDQUFBO0FBQUo7O0FBR0E7RUFDSSwrQkFBQTtBQUFKOztBQUlJO0VBQ0ksK0JBQUE7QUFEUjs7QUFHSTtFQUNJLHlCQUFBO0VBQ0EsK0JBQUE7RUFDQSxxQkFBQTtBQURSOztBQUtBO0VBQ0ksMEJBQUE7RUFDQSxjQUFBO0FBRko7O0FBS0E7RUFDSSxlQUFBO0VBQ0EsbUNBQUE7RUFDQSxtQkFBQTtBQUZKIiwiZmlsZSI6Im11dHVhbC1mdW5kcy1yZWRlbXB0aW9uLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5pbm5lci1ib3gtbGFiZWwge1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS10aW50KTtcbn1cblxuLnRlcm1zLWFncmVlIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cbiAgICBpb24tbGFiZWwge1xuICAgICAgICBwYWRkaW5nOiAwIDVweDtcbiAgICB9XG59XG5cbi5ib3gtd2l0aC1iZy10YW5nZXJpbmUge1xuICAgIGJhY2tncm91bmQ6ICNmZGY5ZjI7XG4gICAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLXdhcm5pbmcpO1xufVxuXG4udGV4dC1jb2xvci10YW5nZXJpbmUge1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itd2FybmluZyk7XG59XG5cbi5hbW91bnQtaW5wdXQge1xuICAgIGlvbi1sYWJlbCB7XG4gICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gICAgfVxuICAgIGlvbi1pbnB1dCB7XG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICM5OWI5YmM7XG4gICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gICAgICAgIC0tcGFkZGluZy1zdGFydDogMTBweDtcbiAgICB9XG59XG5cbiNsaW5rLXRvLXRlcm1zLWFuZC1jb25kaXRpb25zIHtcbiAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgICBjb2xvcjogI0Y5M0YwMztcbn1cblxuI2Ftb3VudC1kaXNwbGF5IHtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXR4dCk7XG4gICAgbWFyZ2luLWJvdHRvbTogMTZweDtcbn0iXX0= */";

/***/ }),

/***/ 4733:
/*!*********************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-redemption/mutual-funds-redemption.page.html?ngResource ***!
  \*********************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"danger\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\"></ion-back-button>\n    </ion-buttons>\n    <ion-title slot=\"start\">{{ 'mutualFund.REDEMPTION' | translate }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<tadawul-loader *ngIf=\"loading\"></tadawul-loader>\n<ion-content class=\"ion-padding\">\n  <form [formGroup]=\"form\" (ngSubmit)=\"redemption(form)\" class=\"subscribe-form\">\n    <ion-item class=\"ion-margin-bottom\">\n      <ion-label position=\"stacked\">{{ 'mutualFund.PORTFOLIO' | translate }}</ion-label>\n      <ion-select placeholder=\"{{ 'mutualFund.SELECT' | translate }}\" formControlName=\"portfolio\" name=\"portfolio\" okText=\"{{ 'mutualFund.OK' | translate }}\"\n        interface=\"action-sheet\" mode=\"ios\" [interfaceOptions]=\"{header: 'mutualFund.PORTFOLIO' | translate, cssClass: 'app-select'}\"\n        cancelText=\"{{ 'mutualFund.CANCEL' | translate }}\" [(ngModel)]=\"portfolio\" (ngModelChange)=\"portfolioChanged($event)\">\n\n        <ion-select-option *ngFor=\"let p of portfolios\" [value]=\"p\">\n          {{ p.name }}\n        </ion-select-option>\n\n      </ion-select>\n\n      <div *ngIf=\"!form.controls.portfolio.valid\n                    && form.controls.portfolio.dirty\" class=\"validator-error\">\n        {{ 'mutualFund.PLEASE_CHOOSE' | translate }} {{ 'mutualFund.PORTFOLIO' | translate }}\n      </div>\n    </ion-item>\n    <!-- <div class=\"ion-margin-bottom\">\n        <ion-text color=\"primary\" class=\"bold\">\n          {{ 'mutualFund.PORTFOLIO }}\n        </ion-text>\n        <div class=\"box-with-bg ion-padding\">\n          <ion-text color=\"primary\">\n            {{mutualFund?.portfolio?.name}}\n          </ion-text>\n        </div>\n      </div> -->\n    <div class=\"ion-margin-bottom\">\n      <ion-text color=\"primary\" class=\"bold\">\n        {{ 'mutualFund.BALANCE' | translate }}\n      </ion-text>\n      <div class=\"box-with-bg ion-padding\">\n        <ion-text color=\"primary\">\n          {{mutualFund?.portfolio?.buyingPower | async | commafy}}\n        </ion-text>\n      </div>\n    </div>\n    <div class=\"ion-margin-bottom\">\n      <ion-text color=\"primary\" class=\"bold\">\n        {{ 'mutualFund.MUTUAL_FUND' | translate }}\n      </ion-text>\n      <div class=\"box-with-bg ion-padding\">\n        <ion-text color=\"primary\">\n          {{mutualFund?.name}}\n        </ion-text>\n      </div>\n    </div>\n    <div class=\"ion-margin-bottom\">\n      <div class=\"box-with-bg ion-padding\">\n        <ion-row>\n          <ion-col size=\"4\">\n            <ion-text class=\"inner-box-label font-size-overline\">{{ 'mutualFund.CURRENCY' | translate }}</ion-text>\n            <ion-text class=\"font-size-caption\" color=\"primary\">{{ details?.currency }}</ion-text>\n          </ion-col>\n          <ion-col size=\"4\">\n            <ion-text class=\"inner-box-label font-size-overline\">{{ 'mutualFund.UNIT_PRICE' | translate }}</ion-text>\n            <ion-text class=\"font-size-caption\" color=\"primary\">{{ mutualFund?.unitPrice }}</ion-text>\n          </ion-col>\n          <ion-col size=\"4\">\n            <ion-text class=\"inner-box-label font-size-overline\">{{ 'mutualFund.VALUATION_DATE' | translate }}</ion-text>\n            <ion-text class=\"font-size-caption\" color=\"primary\">{{ details?.lastPriceDate }}</ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size=\"4\">\n            <ion-text class=\"inner-box-label font-size-overline\">{{ 'mutualFund.MINIMUM_REDEMPTION' | translate }}</ion-text>\n            <ion-text class=\"font-size-caption\" color=\"primary\">{{ details?.minimumRedemption }}\n              {{ translate.instant('mutualFund.'+details?.minimumRedemptionUnit) }}</ion-text>\n          </ion-col>\n          <ion-col size=\"4\">\n            <ion-text class=\"inner-box-label font-size-overline\">{{ 'mutualFund.EVALUATION_DAYS' | translate }}</ion-text>\n            <ion-text class=\"font-size-caption\" color=\"primary\">{{ details?.evaluationDays  }}</ion-text>\n          </ion-col>\n          <ion-col size=\"4\">\n            <ion-text class=\"inner-box-label font-size-overline\">{{ 'mutualFund.REDEMPTION_FEES' | translate }}</ion-text>\n            <ion-text class=\"font-size-caption\" color=\"primary\">{{ details?.redemptionFees }}\n              {{ details?.redemptionFeesType }}</ion-text>\n          </ion-col>\n        </ion-row>\n      </div>\n    </div>\n\n    <ion-row style=\"margin-left: -8px; margin-right: -8px;\">\n      <ion-col *ngFor=\"let type of MutualFundRedemptionTypes | constants\" size=\"4\">\n        <app-button custom-class=\"font-size-caption\" expand=\"block\" size=\"\" color=\"primary\"\n          [fill]=\"redemptionType === MutualFundRedemptionTypes[type] ? 'solid' : 'outline'\" type=\"button\"\n          (clickAction)=\"selectRedemptionType(MutualFundRedemptionTypes[type])\">{{translate.instant('mutualFund.'+ camelize(type))}}</app-button>\n      </ion-col>\n    </ion-row>\n\n    <div class='all-units-warning' *ngIf=\"redemptionType == MutualFundRedemptionTypes.AllUnits\" style=\"width: 100%; display: block; text-align: justify;\">\n      <ion-text color=\"danger\" class=\"font-size-overline\">\n        {{ 'mutualFund.ALL_UNITS_WARNING' | translate }}\n      </ion-text>\n    </div>\n\n    <!--  -->\n    <div class=\"amount-input\" *ngIf=\"redemptionType !== MutualFundRedemptionTypes.AllUnits\">\n      <ion-label position=\"floating\">\n        {{(redemptionType == MutualFundRedemptionTypes.NumberOfUnits ? 'mutualFund.UNITS_NUMBER': 'mutualFund.REDEMPTION_AMOUNT') | translate}}</ion-label>\n      <ion-input type=\"number\" name=\"amount\" autocomplete=\"on\"\n        placeholder=\"{{(redemptionType == MutualFundRedemptionTypes.NumberOfUnits ? 'mutualFund.UNITS_NUMBER': 'mutualFund.REDEMPTION_AMOUNT' )| translate}}\"\n        formControlName=\"amount\" [(ngModel)]=\"amount\"></ion-input>\n\n      <div *ngIf=\"form.controls.amount.errors && form.controls.amount.errors.required && form.controls.amount.dirty\"\n        class=\"validator-error\">\n        {{'mutualFund.PLEASE_ENTER_A_VALID' | translate}}\n        {{(redemptionType == MutualFundRedemptionTypes.NumberOfUnits ? 'mutualFund.UNITS_NUMBER': 'mutualFund.REDEMPTION_AMOUNT') | translate}}\n      </div>\n      <div *ngIf=\"form.controls.amount.errors && form.controls.amount.errors.min && form.controls.amount.dirty\"\n        class=\"validator-error\">\n        {{'mutualFund.VALUE_SHOULD_BE_GREATER_THAN' | translate}} {{details?.minimumInitialSubscription}}\n      </div>\n    </div>\n\n    <div id='amount-display'>\n      <ion-label *ngIf=\"redemptionType != MutualFundRedemptionTypes.Amount\" position=\"floating\">{{'mutualFund.ownedUnits' | translate}}:\n        {{maximumRedemptionUnits | commafy:'number':2}}</ion-label>\n      <ion-label *ngIf=\"redemptionType == MutualFundRedemptionTypes.Amount\" position=\"floating\">{{'mutualFund.ownedAmount' | translate}}:\n        {{maximumRedemptionCurrency | commafy:'number':2}}</ion-label>\n    </div>\n\n\n    <!--  -->\n    <div class=\"ion-margin-bottom\">\n      <div class=\"box-with-bg-tangerine ion-padding\">\n        <ion-text class=\"font-size-overline text-color-tangerine\">\n          {{ 'mutualFund.MUTUAL_FUND_REQUEST_NOTICE_MESSAGE' | translate }}\n        </ion-text>\n      </div>\n    </div>\n\n    <!-- SECOND SECTION -->\n    <!-- <ion-text class=\"bold\" color=\"primary\">{{'mutualFund.COMMISSION_DETAILS' | translate}}</ion-text>\n      <div class=\"box-with-bg bordered ion-margin-bottom\">\n        <ion-row class=\"data-row\">\n          <ion-col size=\"6\">\n            <ion-text class=\"label font-size-caption\" color=\"primary\">{{'mutualFund.TOTAL_COMMISSION' | translate}}</ion-text>\n          </ion-col>\n          <ion-col size=\"6\">\n            <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n                {{mutualFund?.totalCommission | SAR}}\n            </ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"data-row\">\n          <ion-col size=\"6\">\n            <ion-text class=\"label font-size-caption\" color=\"primary\">{{'mutualFund.VAT_WITH_PERCENTAGE' | translate}}</ion-text>\n          </ion-col>\n          <ion-col size=\"6\">\n            <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n                {{mutualFund?.vat | SAR}}\n            </ion-text>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"data-row\">\n          <ion-col size=\"6\">\n            <ion-text class=\"label font-size-caption\" color=\"primary\">{{'mutualFund.TOTAL_AMOUNT' | translate}}</ion-text>\n          </ion-col>\n          <ion-col size=\"6\">\n            <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n              {{mutualFund?.totalAmount | SAR}}\n            </ion-text>\n          </ion-col>\n        </ion-row>\n      </div> -->\n\n    <div class=\"terms-agree\" style=\"color: var(--ion-color-primary-txt);\">\n      <ion-checkbox [formControl]=\"form.controls.terms\" [(ngModel)]=\"terms\"></ion-checkbox>\n      <ion-label>{{'mutualFund.TERMS_CONDITIONS_CONFIRMATION' | translate}}\n\n        <span (click)=\"openTermsAndConditions()\" id='link-to-terms-and-conditions'>\n          {{ 'mutualFund.TERMS_CONDITIONS' | translate }}\n        </span>\n      </ion-label>\n    </div>\n    <ion-text *ngIf=\"submitted && terms===false\" class=\"font-size-overline\" color=\"danger\">\n      {{'mutualFund.PLEASE_AGREE_ON_TERMS_AND_CONDITIONS' | translate}}\n    </ion-text>\n\n    <app-button [disabled]=\"!form.valid\" expand=\"block\" size=\"\" color=\"danger\" fill=\"solid\" type=\"submit\">\n      {{'mutualFund.SEND_REDEMPTION_ORDER' | translate}}\n    </app-button>\n  </form>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_mutual-funds_mutual-funds-redemption_mutual-funds-redemption_module_ts.js.map