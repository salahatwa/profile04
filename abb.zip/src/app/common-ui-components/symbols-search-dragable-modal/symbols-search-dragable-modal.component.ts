import { TranslateService } from '@ngx-translate/core';
import { Component, Input, OnInit } from '@angular/core';
import { Dialogs } from '@inma/helpers/dialogs';
import { Translations } from '@inma/helpers/translations';
import { Symbols, Symbol } from '@inma/models/symbol';
import { Watchlist } from '@inma/models/watchlist';
import { ModalController } from '@ionic/angular';
import sort from 'fast-sort';
import { of } from 'rxjs';
import { WatchlistTranslations } from 'src/app/pages/watchlists/watchlist.translations';

@Component({
  selector: 'tadawul-symbols-search-dragable-modal',
  templateUrl: './symbols-search-dragable-modal.component.html',
  styleUrls: ['./symbols-search-dragable-modal.component.scss'],
})
export class SymbolsSearchDragableModalComponent implements OnInit {
  @Input() title: any;
  @Input() prevPage : any;
  @Input() watchlistSymbolsList = [];
  @Input() watchList : any;
  _symbols: Symbol[];
  searchables = [];
  allSymbols: Symbol[];
  queryText: string;
  watchlistSymbols : Symbol[];
  WatchList: Watchlist;
  symbolsAddList = [];
  symbolsdeleteList = [];


  
  constructor(private modalControl: ModalController, public translate: TranslateService) { }

  ngOnInit() {
    this.WatchList = this.watchList;
    if(this.prevPage == 'watchlist'){
      for (let i of this.watchlistSymbolsList){
        for(let j of this.watchlistSymbols){
          if(i.id == j.id){
            j.checked = true;
            break;
          }
        }
        
      }
      this.watchlistSymbols = [].concat(sort(this.watchlistSymbols).desc(u => u.checked));
      this.searchables = this.watchlistSymbols;
    }else{
      this.searchables = this.allSymbols;
    }
  }

  @Input() set symbols(symbols: Symbol[]) {
    symbols = [].concat(sort(symbols).asc(u => u.id));
    this._symbols = symbols;
    this.allSymbols = symbols;
    this.searchables = this.allSymbols;
    //this.watchlistSymbols = Object.assign([], this.allSymbols);
    this.watchlistSymbols = this.allSymbols.map(x => Object.assign({}, x));
  }

  get symbols() {
    return this._symbols;
  }
  
  filter() {
    Symbols.filter(this.queryText, of(this.allSymbols)).subscribe(symbols => {
      this.searchables = symbols;
    });
  }

  closeModal(symbol) {
    const data = symbol;
    this.modalControl.dismiss(data);
  }
  addRemoveSymbols(symbol){
    if(symbol.checked){
      this.symbolsAddList.push(symbol);
        }else{
          this.symbolsdeleteList.push(symbol);
      };
    }


    saveSymbolsChanges(){
       for (var i = 0; i < this.symbolsAddList.length; i++) {
         if(this.symbolsAddList[i].checked){
           this.WatchList.addSymbol(this.symbolsAddList[i].id);
           }
          }
       for (var i = 0; i < this.symbolsdeleteList.length; i++) {
           if(!this.symbolsdeleteList[i].checked){
            this.WatchList.delete(this.symbolsdeleteList[i]);
            }
          }
        this.modalControl.dismiss(this.watchlistSymbolsList);
    }

    closeAddRemoveModal(){
      Dialogs.confirm(this.translate.instant('watchlist.CANCEL_CHANGES_MESSAGE') as any, this.translate.instant('watchlist.CANCEL_CHANGES') as any).subscribe(closemodal => {
        if (closemodal) {
          this.modalControl.dismiss();  
        }
         else {}
      });   
    }


}
