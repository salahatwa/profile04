

https://appcenter.ms/users/smartphone_support/applications

Email: Smartphone_support@alinma.com
Password (encoded): Alinma****


iOS Signing:
------------
    Bundle Identifier: com.alinma.investment.mobile.ent
    Provisioning Profile: Enterprise_InHouse_Tadawul3_PP
    Certificate: iPhone Distribution: ALINMA BANK (27 June 2021)

iOS UAT:
--------
    To Upload:
    ----------
    UAT iOS: https://appcenter.ms/users/smartphone_support/apps/UAT-Alinma-Tadawul-iOS/distribute/releases

To Share:
---------
Append ` /releases/{RELEASE_NUMBER} ` after the following
https://install.appcenter.ms/users/smartphone_support/apps/uat-alinma-tadawul-ios/distribution_groups/public%20testers/

iOS SoftLaunch:
---------------
    + To Upload:
    ------------
        SoftLaunch iOS: https://appcenter.ms/users/smartphone_support/apps/Alinma-Tadawul-SoftLaunch-iOS/distribute/releases

    + To Share:
    -----------
        Append ` /releases/{RELEASE_NUMBER} ` after the following
        install.appcenter.ms/users/smartphone_support/apps/alinma-tadawul-softlaunch-ios/distribution_groups/public

    *** Decativate all others versions at appcenter after successfully releasing a version, so users always redirect to the latest release

Build Android:

1. npm run android
2. Replace:
        import android.support.annotation.NonNull;
    with:
        import androidx.annotation.NonNull;
