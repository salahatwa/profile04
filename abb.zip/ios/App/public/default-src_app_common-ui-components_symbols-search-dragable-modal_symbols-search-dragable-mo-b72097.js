"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_common-ui-components_symbols-search-dragable-modal_symbols-search-dragable-mo-b72097"],{

/***/ 75846:
/*!***************************************************************************************************************!*\
  !*** ./src/app/common-ui-components/symbols-search-dragable-modal/symbols-search-dragable-modal.component.ts ***!
  \***************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SymbolsSearchDragableModalComponent": () => (/* binding */ SymbolsSearchDragableModalComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _symbols_search_dragable_modal_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./symbols-search-dragable-modal.component.html?ngResource */ 29696);
/* harmony import */ var _symbols_search_dragable_modal_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./symbols-search-dragable-modal.component.scss?ngResource */ 88221);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_helpers_dialogs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/helpers/dialogs */ 66695);
/* harmony import */ var _inma_models_symbol__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/models/symbol */ 61202);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var fast_sort__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! fast-sort */ 63559);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 64139);










let SymbolsSearchDragableModalComponent = class SymbolsSearchDragableModalComponent {
    constructor(modalControl, translate) {
        this.modalControl = modalControl;
        this.translate = translate;
        this.watchlistSymbolsList = [];
        this.searchables = [];
        this.symbolsAddList = [];
        this.symbolsdeleteList = [];
    }
    ngOnInit() {
        this.WatchList = this.watchList;
        if (this.prevPage == 'watchlist') {
            for (let i of this.watchlistSymbolsList) {
                for (let j of this.watchlistSymbols) {
                    if (i.id == j.id) {
                        j.checked = true;
                        break;
                    }
                }
            }
            this.watchlistSymbols = [].concat((0,fast_sort__WEBPACK_IMPORTED_MODULE_4__["default"])(this.watchlistSymbols).desc(u => u.checked));
            this.searchables = this.watchlistSymbols;
        }
        else {
            this.searchables = this.allSymbols;
        }
    }
    set symbols(symbols) {
        symbols = [].concat((0,fast_sort__WEBPACK_IMPORTED_MODULE_4__["default"])(symbols).asc(u => u.id));
        this._symbols = symbols;
        this.allSymbols = symbols;
        this.searchables = this.allSymbols;
        //this.watchlistSymbols = Object.assign([], this.allSymbols);
        this.watchlistSymbols = this.allSymbols.map(x => Object.assign({}, x));
    }
    get symbols() {
        return this._symbols;
    }
    filter() {
        _inma_models_symbol__WEBPACK_IMPORTED_MODULE_3__.Symbols.filter(this.queryText, (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.of)(this.allSymbols)).subscribe(symbols => {
            this.searchables = symbols;
        });
    }
    closeModal(symbol) {
        const data = symbol;
        this.modalControl.dismiss(data);
    }
    addRemoveSymbols(symbol) {
        if (symbol.checked) {
            this.symbolsAddList.push(symbol);
        }
        else {
            this.symbolsdeleteList.push(symbol);
        }
        ;
    }
    saveSymbolsChanges() {
        for (var i = 0; i < this.symbolsAddList.length; i++) {
            if (this.symbolsAddList[i].checked) {
                this.WatchList.addSymbol(this.symbolsAddList[i].id);
            }
        }
        for (var i = 0; i < this.symbolsdeleteList.length; i++) {
            if (!this.symbolsdeleteList[i].checked) {
                this.WatchList.delete(this.symbolsdeleteList[i]);
            }
        }
        this.modalControl.dismiss(this.watchlistSymbolsList);
    }
    closeAddRemoveModal() {
        _inma_helpers_dialogs__WEBPACK_IMPORTED_MODULE_2__.Dialogs.confirm(this.translate.instant('watchlist.CANCEL_CHANGES_MESSAGE'), this.translate.instant('watchlist.CANCEL_CHANGES')).subscribe(closemodal => {
            if (closemodal) {
                this.modalControl.dismiss();
            }
            else { }
        });
    }
};
SymbolsSearchDragableModalComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__.TranslateService }
];
SymbolsSearchDragableModalComponent.propDecorators = {
    title: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input }],
    prevPage: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input }],
    watchlistSymbolsList: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input }],
    watchList: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input }],
    symbols: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input }]
};
SymbolsSearchDragableModalComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'tadawul-symbols-search-dragable-modal',
        template: _symbols_search_dragable_modal_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_symbols_search_dragable_modal_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__.TranslateService])
], SymbolsSearchDragableModalComponent);



/***/ }),

/***/ 9046:
/*!**************************************************!*\
  !*** ./src/app/providers/shared-data.service.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SharedDataService": () => (/* binding */ SharedDataService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 61555);
var SharedDataService_1;



let SharedDataService = SharedDataService_1 = class SharedDataService {
    constructor() {
        this.symbolSearchId = new rxjs__WEBPACK_IMPORTED_MODULE_0__.ReplaySubject();
        this.marketName = new rxjs__WEBPACK_IMPORTED_MODULE_0__.ReplaySubject();
        this.symbolsFilterType = new rxjs__WEBPACK_IMPORTED_MODULE_0__.ReplaySubject();
        this.appLanguage = new rxjs__WEBPACK_IMPORTED_MODULE_0__.ReplaySubject();
        this.commisionLoading = new rxjs__WEBPACK_IMPORTED_MODULE_0__.ReplaySubject();
    }
    getSharedData(key, remove = true) {
        const selectedData = SharedDataService_1.data[key];
        if (remove) {
            this.removeData(key);
        }
        return selectedData;
    }
    setSharedData(data, key) {
        SharedDataService_1.data[key] = data;
    }
    removeData(key) {
        delete SharedDataService_1.data[key];
    }
};
SharedDataService.data = [];
SharedDataService.ctorParameters = () => [];
SharedDataService = SharedDataService_1 = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__metadata)("design:paramtypes", [])
], SharedDataService);



/***/ }),

/***/ 88221:
/*!****************************************************************************************************************************!*\
  !*** ./src/app/common-ui-components/symbols-search-dragable-modal/symbols-search-dragable-modal.component.scss?ngResource ***!
  \****************************************************************************************************************************/
/***/ ((module) => {

module.exports = ":host {\n  height: calc(100vh - 45px - 0);\n  height: calc(100vh - 45px - var(--ion-safe-area-top, 0));\n}\n:host ion-searchbar {\n  position: -webkit-sticky;\n  position: sticky;\n  top: 0px;\n  z-index: 9;\n  background-color: #e6eff0;\n  padding: 12px 16px;\n}\n:host ion-searchbar .searchbar-input-container {\n  border: solid 1px #91babd;\n  border-radius: 5px !important;\n}\n:host ion-title {\n  color: #1e1e1e;\n  font-size: 18px;\n}\n:host .text {\n  color: #005157;\n  font-weight: bold;\n  font-size: 13px;\n  padding-top: 5px;\n}\n:host .number {\n  color: #65979a;\n  font-size: 12px;\n}\n:host ion-list .symbol-item {\n  display: flex;\n  align-items: center;\n}\n:host ion-list .symbol-item ion-checkbox {\n  --border-color: #91babd;\n  --border-radius: 4px;\n  --size: 20px;\n  --checkmark-width: 2px;\n}\n:host ion-list .symbol-item ion-checkbox :checked {\n  --background: #005157;\n  --border-color: #005157;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN5bWJvbHMtc2VhcmNoLWRyYWdhYmxlLW1vZGFsLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQXVCQTtFQUlFLDhCQUFBO0VBQUEsd0RBQUE7QUF6QkY7QUEyQkc7RUFDSyx3QkFBQTtFQUFBLGdCQUFBO0VBQ0EsUUFBQTtFQUNBLFVBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0FBekJSO0FBMkJRO0VBQ0kseUJBQUE7RUFDQSw2QkFBQTtBQXpCWjtBQW1DRztFQUNDLGNBQUE7RUFDQSxlQUFBO0FBakNKO0FBb0NHO0VBQ0MsY0FBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBbENKO0FBb0NHO0VBQ0MsY0FBQTtFQUNBLGVBQUE7QUFsQ0o7QUF5Q007RUFDRSxhQUFBO0VBQ0EsbUJBQUE7QUF2Q1I7QUF5Q1E7RUFDRSx1QkFBQTtFQUNBLG9CQUFBO0VBQ0EsWUFBQTtFQUNBLHNCQUFBO0FBdkNWO0FBd0NVO0VBQ0UscUJBQUE7RUFDQSx1QkFBQTtBQXRDWiIsImZpbGUiOiJzeW1ib2xzLXNlYXJjaC1kcmFnYWJsZS1tb2RhbC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxuICAgIFxuXG5cbi8vIDo6bmctZGVlcCBpb24tbW9kYWwgaW9uLWhlYWRlciBpb24tdG9vbGJhci5taW5pLW1vZGFsIHtcbi8vICAgICBtYXJnaW4tdG9wOiAxNXB4O1xuLy8gICAgIG1pbi1oZWlnaHQ6IDQ1cHg7XG4vLyAgICAgcGFkZGluZy10b3A6IDBweCAhaW1wb3J0YW50O1xuLy8gICAgIGRpc3BsYXk6IGZsZXg7XG4vLyAgICAgLS1iYWNrZ3JvdW5kOiNmZmZmZmY7XG4vLyAgIH1cbi8vICAgOjpuZy1kZWVwIGlvbi1tb2RhbCBpb24taGVhZGVyOjpiZWZvcmUge1xuLy8gICAgIGNvbnRlbnQ6ICcnO1xuLy8gICAgIGJhY2tncm91bmQ6ICNlNmVmZjA7XG4vLyAgICAgcG9zaXRpb246IGFic29sdXRlO1xuLy8gICAgIHdpZHRoOiA0MHB4O1xuLy8gICAgIGhlaWdodDogNXB4O1xuLy8gICAgIGxlZnQ6IDUwJTtcbi8vICAgICB0b3A6IDEwcHg7XG4vLyAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC01MCUpO1xuLy8gICAgIGJvcmRlci1yYWRpdXM6IDNweDtcbi8vIH1cblxuOmhvc3Qge1xuICAvLyAganVzdGlmeS1jb250ZW50OiBzdGFydDtcbiAgLy8gaGVpZ2h0OiBjYWxjKDEwMHZoIC0gNjBweCk7XG5cbiAgaGVpZ2h0OiBjYWxjKDEwMHZoIC0gNDVweCAtIHZhcigtLWlvbi1zYWZlLWFyZWEtdG9wLCAwKSk7XG5cbiAgIGlvbi1zZWFyY2hiYXIge1xuICAgICAgICBwb3NpdGlvbjogc3RpY2t5O1xuICAgICAgICB0b3A6IDBweDtcbiAgICAgICAgei1pbmRleDogOTtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2U2ZWZmMDtcbiAgICAgICAgcGFkZGluZzogMTJweCAxNnB4O1xuXG4gICAgICAgIC5zZWFyY2hiYXItaW5wdXQtY29udGFpbmVyIHtcbiAgICAgICAgICAgIGJvcmRlcjogc29saWQgMXB4ICM5MWJhYmQ7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1cHggIWltcG9ydGFudDtcbiAgICAgICAgfVxuICAgfVxuXG5cbiAgLy8gLnN5bWJvbHMtbGlzdC13cmFwcGVyIHtcbiAgLy8gICBmbGV4LWdyb3c6IDE7XG4gIC8vICAgb3ZlcmZsb3c6IGF1dG87XG4gIC8vIH1cblxuICAgaW9uLXRpdGxle1xuICAgIGNvbG9yOiMxZTFlMWU7XG4gICAgZm9udC1zaXplOjE4cHg7XG4gICB9XG5cbiAgIC50ZXh0e1xuICAgIGNvbG9yOiMwMDUxNTc7XG4gICAgZm9udC13ZWlnaHQ6Ym9sZDtcbiAgICBmb250LXNpemU6MTNweDtcbiAgICBwYWRkaW5nLXRvcDogNXB4O1xuICAgfVxuICAgLm51bWJlcntcbiAgICBjb2xvcjojNjU5NzlhO1xuICAgIGZvbnQtc2l6ZToxMnB4O1xuICAgfVxuXG4gICBpb24tbGlzdCB7XG4gICAgLy8gIGhlaWdodDogMTAwJTtcbiAgICAvLyAgb3ZlcmZsb3c6IGF1dG87XG5cbiAgICAgIC5zeW1ib2wtaXRlbSB7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cbiAgICAgICAgaW9uLWNoZWNrYm94IHtcbiAgICAgICAgICAtLWJvcmRlci1jb2xvcjogIzkxYmFiZDtcbiAgICAgICAgICAtLWJvcmRlci1yYWRpdXM6IDRweDtcbiAgICAgICAgICAtLXNpemU6IDIwcHg7XG4gICAgICAgICAgLS1jaGVja21hcmstd2lkdGg6IDJweDtcbiAgICAgICAgICA6Y2hlY2tlZCB7XG4gICAgICAgICAgICAtLWJhY2tncm91bmQ6ICMwMDUxNTc7XG4gICAgICAgICAgICAtLWJvcmRlci1jb2xvcjogIzAwNTE1NztcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgfVxuICAgfVxufSJdfQ== */";

/***/ }),

/***/ 29696:
/*!****************************************************************************************************************************!*\
  !*** ./src/app/common-ui-components/symbols-search-dragable-modal/symbols-search-dragable-modal.component.html?ngResource ***!
  \****************************************************************************************************************************/
/***/ ((module) => {

module.exports = "\n<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button *ngIf=\"prevPage == 'watchlist'\" (click)=\"closeAddRemoveModal()\"> \n        <span class=\"icon icon-close\"></span>\n      </ion-button>\n    </ion-buttons>\n    <ion-title>{{ title }}</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button *ngIf=\"prevPage == 'watchlist'\" (click)=\"saveSymbolsChanges()\"> \n        {{ 'watchlist.SAVE' | translate }}\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n\n  <!-- <ion-toolbar class=\"mini-modal\">\n    <ion-buttons *ngIf=\"prevPage == 'watchlist'\" slot=\"end\" (click)=\"saveSymbolsChanges()\">\n      <ion-button>{{ t.SAVE }}</ion-button>\n    </ion-buttons>\n    <ion-buttons slot=\"start\" *ngIf=\"prevPage == 'watchlist'\" (click)=\"closeAddRemoveModal()\">\n      <span class=\"icon icon-close\"></span>\n    </ion-buttons>\n    <ion-title>\n      {{ title }}\n    </ion-title>\n  </ion-toolbar> -->\n</ion-header>\n<ion-content>\n<!-- <ion-content class=\"symbols-list-wrapper\"> -->\n  <ion-searchbar [(ngModel)]=\"queryText\" (ngModelChange)=\"filter()\" [placeholder]=\"title\">\n  </ion-searchbar>\n\n  <ion-list>\n    <ion-item *ngFor=\"let s of searchables\"(click)=\"prevPage == 'watchlist'?addRemoveSymbols(s):closeModal(s)\">\n      <div class=\"symbol-item\">\n        <ion-checkbox *ngIf=\"prevPage == 'watchlist'\" [(ngModel)]=\"s.checked\" [checked]=\"s?.checked\" slot=\"start\"></ion-checkbox>\n        <ion-label>\n          <div class=\"text\">{{s.sortAbbreviation}}</div>\n          <div class=\"number\">{{s?.id}}</div>\n        </ion-label>\n      </div>\n    </ion-item>\n\n  </ion-list>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=default-src_app_common-ui-components_symbols-search-dragable-modal_symbols-search-dragable-mo-b72097.js.map