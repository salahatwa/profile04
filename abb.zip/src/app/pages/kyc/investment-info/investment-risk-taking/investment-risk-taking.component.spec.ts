import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { InvestmentRiskTakingComponent } from './investment-risk-taking.component';

describe('InvestmentRiskTakingComponent', () => {
  let component: InvestmentRiskTakingComponent;
  let fixture: ComponentFixture<InvestmentRiskTakingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvestmentRiskTakingComponent ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(InvestmentRiskTakingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
