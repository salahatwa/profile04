"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_pages_tradestation_symbol-swiper_symbol-swiper_module_ts"],{

/***/ 50417:
/*!*********************************************************************************************************************!*\
  !*** ./src/app/pages/tradestation/symbol-swiper/symbol-bids-and-asks-slide/symbol-bids-and-asks-slide.component.ts ***!
  \*********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SymbolBidsAndAsksSlideComponent": () => (/* binding */ SymbolBidsAndAsksSlideComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _symbol_bids_and_asks_slide_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./symbol-bids-and-asks-slide.component.html?ngResource */ 58351);
/* harmony import */ var _symbol_bids_and_asks_slide_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./symbol-bids-and-asks-slide.component.scss?ngResource */ 23245);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_models_symbol__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/models/symbol */ 61202);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 93819);








let SymbolBidsAndAsksSlideComponent = class SymbolBidsAndAsksSlideComponent {
    constructor(sharedData, navCtrl, translate) {
        this.sharedData = sharedData;
        this.navCtrl = navCtrl;
        this.translate = translate;
        this.close = new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter();
        this.askBids = [];
        this.asksListHeader = [
            this.translate.instant('tradestion.ASKS'),
            this.translate.instant('tradestion.ASK_QUANTITY'),
            this.translate.instant('tradestion.ASK_PRICE')
        ];
        this.bidsListHeader = [
            this.translate.instant('tradestion.BIDDING_PRICE'),
            this.translate.instant('tradestion.BIDDING_QUANTITY'),
            this.translate.instant('tradestion.BIDS')
        ];
    }
    ngOnChanges(changes) {
        if (changes['symbol']) {
            this.symbol.asksAndBids.subscribe((res) => {
                this.askBids = res;
                console.log("🚀 ~ file: symbol-bids-and-asks-slide.component.ts ~ line 55 ~ SymbolBidsAndAsksSlideComponent ~ this.symbol.asksAndBids.subscribe ~ res", res);
            });
        }
    }
    ngOnInit() { }
    onClose() {
        this.close.emit(this.symbol);
    }
    openSymbol() {
        this.sharedData.setSharedData({ symbol: this.symbol }, 'sharedSymbol');
        this.navCtrl.navigateForward('main/symbol', { animated: true });
        // OrderPage.initialize();
    }
};
SymbolBidsAndAsksSlideComponent.ctorParameters = () => [
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_3__.SharedDataService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateService }
];
SymbolBidsAndAsksSlideComponent.propDecorators = {
    close: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output }],
    symbol: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input }]
};
SymbolBidsAndAsksSlideComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: "tadawul-symbol-bids-and-asks-slide",
        template: _symbol_bids_and_asks_slide_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_symbol_bids_and_asks_slide_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__metadata)("design:paramtypes", [src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_3__.SharedDataService,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController,
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateService])
], SymbolBidsAndAsksSlideComponent);



/***/ }),

/***/ 76524:
/*!*************************************************************************************************************!*\
  !*** ./src/app/pages/tradestation/symbol-swiper/symbol-liquidity-slide/symbol-liquidity-slide.component.ts ***!
  \*************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SymbolLiquiditySlideComponent": () => (/* binding */ SymbolLiquiditySlideComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _symbol_liquidity_slide_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./symbol-liquidity-slide.component.html?ngResource */ 72557);
/* harmony import */ var _symbol_liquidity_slide_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./symbol-liquidity-slide.component.scss?ngResource */ 56984);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_models_symbol__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/models/symbol */ 61202);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 93819);







let SymbolLiquiditySlideComponent = class SymbolLiquiditySlideComponent {
    constructor(sharedData, navCtrl) {
        this.sharedData = sharedData;
        this.navCtrl = navCtrl;
        this.close = new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter();
    }
    ngOnInit() { }
    onClose() {
        this.close.emit(this.symbol);
    }
    openSymbol() {
        this.sharedData.setSharedData({ symbol: this.symbol }, 'sharedSymbol');
        this.navCtrl.navigateForward('main/symbol', { animated: true });
        // OrderPage.initialize();
    }
};
SymbolLiquiditySlideComponent.ctorParameters = () => [
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_3__.SharedDataService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController }
];
SymbolLiquiditySlideComponent.propDecorators = {
    close: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output }],
    symbol: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input }]
};
SymbolLiquiditySlideComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'tadawul-symbol-liquidity-slide',
        template: _symbol_liquidity_slide_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_symbol_liquidity_slide_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:paramtypes", [src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_3__.SharedDataService, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController])
], SymbolLiquiditySlideComponent);



/***/ }),

/***/ 82577:
/*!***************************************************************************************************************!*\
  !*** ./src/app/pages/tradestation/symbol-swiper/symbol-parameters-slide/symbol-parameters-slide.component.ts ***!
  \***************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SymbolParametersSlideComponent": () => (/* binding */ SymbolParametersSlideComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _symbol_parameters_slide_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./symbol-parameters-slide.component.html?ngResource */ 65053);
/* harmony import */ var _symbol_parameters_slide_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./symbol-parameters-slide.component.scss?ngResource */ 7482);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _symbols_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../../symbols.service */ 4757);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_models_symbol__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/models/symbol */ 61202);
/* harmony import */ var _app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../app/providers/shared-data.service */ 9046);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _app_pages_order_order_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../app/pages/order/order.page */ 28798);










let SymbolParametersSlideComponent = class SymbolParametersSlideComponent {
    constructor(sharedData, navCtrl, loadingCtrl, translate, toastController, symbolService, modalCtrl) {
        this.sharedData = sharedData;
        this.navCtrl = navCtrl;
        this.loadingCtrl = loadingCtrl;
        this.translate = translate;
        this.toastController = toastController;
        this.symbolService = symbolService;
        this.modalCtrl = modalCtrl;
        this.Number = Number;
        this.down = "down";
        this.up = "up";
        this.zero = "zero";
        this.close = new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter();
    }
    ngOnInit() {
    }
    onClose() {
        this.close.emit();
    }
    openSymbol() {
        this.sharedData.setSharedData({ symbol: this.symbol }, 'sharedSymbol');
        this.navCtrl.navigateForward('main/symbol', { animated: true });
        // OrderPage.initialize();
    }
    openBuySellSymbols(symbol, operation) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            if (operation == 'sell') {
                const loading = yield this.loadingCtrl.create({});
                loading.present();
                this.symbolService.getAllPortfoliosForASymbol(symbol.id).subscribe((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
                    loading.dismiss();
                    if (res.length > 0) {
                        this.handleOrderPage(symbol, operation);
                    }
                    else {
                        const toast = yield this.toastController.create({
                            message: this.translate.currentLang == 'ar' ? 'السهم المختار ليس من ضمن أسهمك' : 'The selected share is not owned',
                            duration: 4000,
                            cssClass: "info-alert"
                        });
                        toast.present();
                    }
                }));
            }
            else {
                this.handleOrderPage(symbol, operation);
            }
        });
    }
    openModal(symbol, operation) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _app_pages_order_order_page__WEBPACK_IMPORTED_MODULE_5__.OrderPage,
                cssClass: 'buy-sell',
                componentProps: {
                    sharedSymbol: symbol,
                    operation: operation,
                    previousPage: 'tradestation'
                },
                swipeToClose: true
            });
            return yield modal.present();
        });
    }
    handleOrderPage(symbol, operation) {
        this.onClose();
        setTimeout(() => {
            // this.sharedData.setSharedData({ symbol }, 'sharedSymbol');
            // this.sharedData.setSharedData(operation, 'operation');
            //this.navCtrl.navigateForward('order', { animated: true });
            this.openModal(symbol, operation);
            _app_pages_order_order_page__WEBPACK_IMPORTED_MODULE_5__.OrderPage.initialize();
        }, 100);
    }
};
SymbolParametersSlideComponent.ctorParameters = () => [
    { type: _app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_4__.SharedDataService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.LoadingController },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ToastController },
    { type: _symbols_service__WEBPACK_IMPORTED_MODULE_2__.SymbolsService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController }
];
SymbolParametersSlideComponent.propDecorators = {
    close: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Output }],
    symbol: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Input }]
};
SymbolParametersSlideComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'tadawul-symbol-parameters-slide',
        template: _symbol_parameters_slide_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_symbol_parameters_slide_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__metadata)("design:paramtypes", [_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_4__.SharedDataService,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.LoadingController,
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateService,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ToastController,
        _symbols_service__WEBPACK_IMPORTED_MODULE_2__.SymbolsService,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController])
], SymbolParametersSlideComponent);



/***/ }),

/***/ 8202:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/tradestation/symbol-swiper/symbol-swiper.component.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SymbolSwiperComponent": () => (/* binding */ SymbolSwiperComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _symbol_swiper_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./symbol-swiper.component.html?ngResource */ 9065);
/* harmony import */ var _symbol_swiper_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./symbol-swiper.component.scss?ngResource */ 5552);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_models_symbol__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/models/symbol */ 61202);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! jquery */ 85139);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_4__);








let SymbolSwiperComponent = class SymbolSwiperComponent {
    constructor(sharedData, navCtrl) {
        this.sharedData = sharedData;
        this.navCtrl = navCtrl;
        this.close = new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter();
        this.openSymbolWatchlists = new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter();
    }
    ngOnInit() {
    }
    move() {
        jquery__WEBPACK_IMPORTED_MODULE_4__('.ion-slides').animate({ scrollLeft: jquery__WEBPACK_IMPORTED_MODULE_4__('#first-slide').position().left }, 500);
    }
    onClose() {
        this.close.emit(this.symbol);
    }
    emitSymbolWatchlists() {
        this.openSymbolWatchlists.emit(this.symbol);
    }
    openSymbol() {
        const currentSymbol = this.symbol;
        this.onClose();
        setTimeout(() => {
            this.sharedData.setSharedData({ symbol: currentSymbol }, 'sharedSymbol');
            this.navCtrl.navigateForward('main/symbol', { animated: true });
        }, 100);
        // OrderPage.initialize();
    }
};
SymbolSwiperComponent.ctorParameters = () => [
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_3__.SharedDataService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController }
];
SymbolSwiperComponent.propDecorators = {
    symbol: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input }],
    close: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output }],
    openSymbolWatchlists: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output }]
};
SymbolSwiperComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'tadawul-symbol-swiper',
        template: _symbol_swiper_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_symbol_swiper_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__metadata)("design:paramtypes", [src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_3__.SharedDataService, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController])
], SymbolSwiperComponent);



/***/ }),

/***/ 69554:
/*!**************************************************************************!*\
  !*** ./src/app/pages/tradestation/symbol-swiper/symbol-swiper.module.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SymbolSwiperModule": () => (/* binding */ SymbolSwiperModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _symbols_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../symbols.service */ 4757);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/pipes/pipes.module */ 41041);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);
/* harmony import */ var _symbol_parameters_slide_symbol_parameters_slide_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./symbol-parameters-slide/symbol-parameters-slide.component */ 82577);
/* harmony import */ var _symbol_liquidity_slide_symbol_liquidity_slide_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./symbol-liquidity-slide/symbol-liquidity-slide.component */ 76524);
/* harmony import */ var _symbol_trades_slide_symbol_trades_slide_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./symbol-trades-slide/symbol-trades-slide.component */ 33489);
/* harmony import */ var _symbol_bids_and_asks_slide_symbol_bids_and_asks_slide_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./symbol-bids-and-asks-slide/symbol-bids-and-asks-slide.component */ 50417);
/* harmony import */ var _symbol_swiper_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./symbol-swiper.component */ 8202);














let SymbolSwiperModule = class SymbolSwiperModule {
};
SymbolSwiperModule = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_10__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonicModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_1__.PipesModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__.TranslateModule.forChild()
        ],
        declarations: [
            _symbol_parameters_slide_symbol_parameters_slide_component__WEBPACK_IMPORTED_MODULE_3__.SymbolParametersSlideComponent,
            _symbol_liquidity_slide_symbol_liquidity_slide_component__WEBPACK_IMPORTED_MODULE_4__.SymbolLiquiditySlideComponent,
            _symbol_trades_slide_symbol_trades_slide_component__WEBPACK_IMPORTED_MODULE_5__.SymbolTradesSlideComponent,
            _symbol_bids_and_asks_slide_symbol_bids_and_asks_slide_component__WEBPACK_IMPORTED_MODULE_6__.SymbolBidsAndAsksSlideComponent,
            _symbol_swiper_component__WEBPACK_IMPORTED_MODULE_7__.SymbolSwiperComponent,
        ],
        exports: [
            _symbol_parameters_slide_symbol_parameters_slide_component__WEBPACK_IMPORTED_MODULE_3__.SymbolParametersSlideComponent,
            _symbol_liquidity_slide_symbol_liquidity_slide_component__WEBPACK_IMPORTED_MODULE_4__.SymbolLiquiditySlideComponent,
            _symbol_trades_slide_symbol_trades_slide_component__WEBPACK_IMPORTED_MODULE_5__.SymbolTradesSlideComponent,
            _symbol_bids_and_asks_slide_symbol_bids_and_asks_slide_component__WEBPACK_IMPORTED_MODULE_6__.SymbolBidsAndAsksSlideComponent,
            _symbol_swiper_component__WEBPACK_IMPORTED_MODULE_7__.SymbolSwiperComponent,
        ],
        providers: [_symbols_service__WEBPACK_IMPORTED_MODULE_0__.SymbolsService]
    })
], SymbolSwiperModule);



/***/ }),

/***/ 33489:
/*!*******************************************************************************************************!*\
  !*** ./src/app/pages/tradestation/symbol-swiper/symbol-trades-slide/symbol-trades-slide.component.ts ***!
  \*******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SymbolTradesSlideComponent": () => (/* binding */ SymbolTradesSlideComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _symbol_trades_slide_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./symbol-trades-slide.component.html?ngResource */ 98744);
/* harmony import */ var _symbol_trades_slide_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./symbol-trades-slide.component.scss?ngResource */ 35459);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_models_symbol__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/models/symbol */ 61202);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 93819);








let SymbolTradesSlideComponent = class SymbolTradesSlideComponent {
    constructor(sharedData, navCtrl, translate) {
        this.sharedData = sharedData;
        this.navCtrl = navCtrl;
        this.translate = translate;
        this.down = "down";
        this.up = "up";
        this.close = new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter();
        this.listHeader = [this.translate.instant('tradestion.TRADE_TIME'),
            this.translate.instant('tradestion.QUANTITY'),
            this.translate.instant('tradestion.PRICE'),
            this.translate.instant('tradestion.SPLITS'),
            this.translate.instant('tradestion.TYPE')];
    }
    ngOnInit() { }
    onClose() {
        this.close.emit(this.symbol);
    }
    openSymbol() {
        this.sharedData.setSharedData({ symbol: this.symbol }, 'sharedSymbol');
        this.navCtrl.navigateForward('main/symbol', { animated: true });
        // OrderPage.initialize();
    }
};
SymbolTradesSlideComponent.ctorParameters = () => [
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_3__.SharedDataService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateService }
];
SymbolTradesSlideComponent.propDecorators = {
    close: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output }],
    symbol: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input }]
};
SymbolTradesSlideComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'tadawul-symbol-trades-slide',
        template: _symbol_trades_slide_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_symbol_trades_slide_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__metadata)("design:paramtypes", [src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_3__.SharedDataService,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController,
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateService])
], SymbolTradesSlideComponent);



/***/ }),

/***/ 23245:
/*!**********************************************************************************************************************************!*\
  !*** ./src/app/pages/tradestation/symbol-swiper/symbol-bids-and-asks-slide/symbol-bids-and-asks-slide.component.scss?ngResource ***!
  \**********************************************************************************************************************************/
/***/ ((module) => {

module.exports = ":host::ng-deep .table-header {\n  font-size: 10px;\n  color: #cddcdd;\n}\n:host::ng-deep #table {\n  font-size: 60%;\n  text-align: start;\n}\n:host::ng-deep #table #title {\n  font-size: 16px;\n  padding: 8px;\n  font-weight: bold;\n}\n:host::ng-deep #table #icons ion-icon {\n  width: 19px;\n  height: 19px;\n  position: absolute;\n  top: 10px;\n}\n[dir=rtl] :host::ng-deep #table #icons ion-icon {\n  left: 10px;\n}\n[dir=ltr] :host::ng-deep #table #icons ion-icon {\n  right: 10px;\n}\n[dir=rtl] :host::ng-deep #table #icons #fullscreen {\n  left: 36px;\n}\n[dir=ltr] :host::ng-deep #table #icons #fullscreen {\n  right: 36px;\n}\n:host::ng-deep #table #symbol-id {\n  border: 1px solid white;\n  font-size: 12px;\n  padding: 4px;\n}\n:host::ng-deep #table #symbol-name {\n  font-size: 16px;\n  padding: 8px;\n  font-weight: bold;\n}\n:host::ng-deep .ask-grid {\n  font-size: 12px;\n  font-weight: bold;\n  background: rgba(77, 203, 143, 0.7);\n  border-start-start-radius: 5px;\n  border-end-start-radius: 5px;\n}\n:host::ng-deep .bid-grid {\n  font-size: 12px;\n  font-weight: bold;\n  background: rgba(225, 87, 87, 0.7);\n  border-start-end-radius: 5px;\n  border-end-end-radius: 5px;\n}\n:host::ng-deep .symbol-asks-and-bids {\n  flex-grow: 1;\n  font-size: 12px;\n  font-weight: bold;\n  border-radius: 5px;\n  overflow: auto;\n}\n:host::ng-deep .symbol-asks-and-bids .ask-item {\n  background: rgba(77, 203, 143, 0.7);\n}\n:host::ng-deep .symbol-asks-and-bids .bid-item {\n  background: rgba(225, 87, 87, 0.7);\n}\n:host::ng-deep .symbol-asks-and-bids ion-row:not(:last-child) .ask-item, :host::ng-deep .symbol-asks-and-bids ion-row:not(:last-child) .bid-item {\n  border-bottom: 1px solid rgba(255, 255, 255, 0.2);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN5bWJvbC1iaWRzLWFuZC1hc2tzLXNsaWRlLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQVlFO0VBQ0UsZUFBQTtFQUNBLGNBQUE7QUFYSjtBQWFFO0VBd0NFLGNBQUE7RUFDQSxpQkFBQTtBQWxESjtBQVVJO0VBQ0UsZUFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtBQVJOO0FBV007RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtBQVRSO0FBV1E7RUFDRSxVQUFBO0FBVFY7QUFXUTtFQUNFLFdBQUE7QUFUVjtBQWNRO0VBQ0UsVUFBQTtBQVpWO0FBY1E7RUFDRSxXQUFBO0FBWlY7QUFnQkk7RUFDRSx1QkFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0FBZE47QUFnQkk7RUFDRSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0FBZE47QUFvQkU7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQ0FBQTtFQUNBLDhCQUFBO0VBQ0EsNEJBQUE7QUFsQko7QUFvQkU7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQ0FBQTtFQUNBLDRCQUFBO0VBQ0EsMEJBQUE7QUFsQko7QUFxQkU7RUFDRSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FBbkJKO0FBcUJJO0VBQ0UsbUNBQUE7QUFuQk47QUFxQkk7RUFDRSxrQ0FBQTtBQW5CTjtBQXVCTTtFQUNFLGlEQUFBO0FBckJSIiwiZmlsZSI6InN5bWJvbC1iaWRzLWFuZC1hc2tzLXNsaWRlLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Q6Om5nLWRlZXAge1xuICAvLyBkaXNwbGF5OiBibG9jaztcbiAgLy8gLy8gYmFja2dyb3VuZDogIzAwNTE1NztcbiAgLy8gLy9iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1iZyk7XG4gIC8vIGNvbG9yOiB3aGl0ZTtcbiAgLy8gaGVpZ2h0OiAxMDAlO1xuICAvLyB3aWR0aDogMTAwJTtcbiAgLy8gcGFkZGluZzogMHB4O1xuICAvLyBiYWNrZ3JvdW5kLWNsaXA6IGNvbnRlbnQtYm94O1xuICAvLyBkaXNwbGF5OiBmbGV4O1xuICAvLyBhbGlnbi1pdGVtczogdG9wO1xuXG4gIC50YWJsZS1oZWFkZXIge1xuICAgIGZvbnQtc2l6ZTogMTBweDtcbiAgICBjb2xvcjogI2NkZGNkZDtcbiAgfVxuICAjdGFibGUge1xuICAgICN0aXRsZSB7XG4gICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICBwYWRkaW5nOiA4cHg7XG4gICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICB9XG4gICAgI2ljb25zIHtcbiAgICAgIGlvbi1pY29uIHtcbiAgICAgICAgd2lkdGg6IDE5cHg7XG4gICAgICAgIGhlaWdodDogMTlweDtcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICB0b3A6IDEwcHg7XG4gICAgICAgIFxuICAgICAgICBbZGlyPVwicnRsXCJdICYge1xuICAgICAgICAgIGxlZnQ6IDEwcHg7XG4gICAgICAgIH1cbiAgICAgICAgW2Rpcj1cImx0clwiXSAmIHtcbiAgICAgICAgICByaWdodDogMTBweDtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAjZnVsbHNjcmVlbiB7XG4gICAgICAgIFtkaXI9XCJydGxcIl0gJiB7XG4gICAgICAgICAgbGVmdDogMzZweDtcbiAgICAgICAgfVxuICAgICAgICBbZGlyPVwibHRyXCJdICYge1xuICAgICAgICAgIHJpZ2h0OiAzNnB4O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgICNzeW1ib2wtaWQge1xuICAgICAgYm9yZGVyOiAxcHggc29saWQgd2hpdGU7XG4gICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICBwYWRkaW5nOiA0cHg7XG4gICAgfVxuICAgICNzeW1ib2wtbmFtZSB7XG4gICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICBwYWRkaW5nOiA4cHg7XG4gICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICB9XG4gICAgZm9udC1zaXplOiA2MCU7XG4gICAgdGV4dC1hbGlnbjogc3RhcnQ7XG4gIH1cblxuICAuYXNrLWdyaWQge1xuICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBiYWNrZ3JvdW5kOiByZ2JhKDc3LCAyMDMsIDE0MywgMC43KTtcbiAgICBib3JkZXItc3RhcnQtc3RhcnQtcmFkaXVzOiA1cHg7XG4gICAgYm9yZGVyLWVuZC1zdGFydC1yYWRpdXM6IDVweDtcbiAgfVxuICAuYmlkLWdyaWQge1xuICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBiYWNrZ3JvdW5kOiByZ2JhKDIyNSwgODcsIDg3LCAwLjcpO1xuICAgIGJvcmRlci1zdGFydC1lbmQtcmFkaXVzOiA1cHg7XG4gICAgYm9yZGVyLWVuZC1lbmQtcmFkaXVzOiA1cHg7XG4gIH1cblxuICAuc3ltYm9sLWFza3MtYW5kLWJpZHMge1xuICAgIGZsZXgtZ3JvdzogMTtcbiAgICBmb250LXNpemU6IDEycHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgIG92ZXJmbG93OiBhdXRvO1xuXG4gICAgLmFzay1pdGVtIHtcbiAgICAgIGJhY2tncm91bmQ6IHJnYmEoNzcsIDIwMywgMTQzLCAwLjcpO1xuICAgIH1cbiAgICAuYmlkLWl0ZW0ge1xuICAgICAgYmFja2dyb3VuZDogcmdiYSgyMjUsIDg3LCA4NywgMC43KTtcbiAgICB9XG5cbiAgICBpb24tcm93Om5vdCg6bGFzdC1jaGlsZCkge1xuICAgICAgLmFzay1pdGVtLCAuYmlkLWl0ZW0ge1xuICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjIpO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuIl19 */";

/***/ }),

/***/ 56984:
/*!**************************************************************************************************************************!*\
  !*** ./src/app/pages/tradestation/symbol-swiper/symbol-liquidity-slide/symbol-liquidity-slide.component.scss?ngResource ***!
  \**************************************************************************************************************************/
/***/ ((module) => {

module.exports = ":host .title-label {\n  font-size: 10px;\n  color: #cddcdd;\n  -webkit-margin-end: 5px;\n          margin-inline-end: 5px;\n  width: 50px;\n  display: inline-block;\n}\n:host .value {\n  font-size: 12px;\n  color: #FFFFFF;\n  font-weight: bold;\n}\n:host #table {\n  font-size: 60%;\n  text-align: start;\n}\n:host #table #icons ion-icon {\n  width: 19px;\n  height: 19px;\n  position: absolute;\n  top: 10px;\n}\n[dir=rtl] :host #table #icons ion-icon {\n  left: 10px;\n}\n[dir=ltr] :host #table #icons ion-icon {\n  right: 10px;\n}\n[dir=rtl] :host #table #icons #fullscreen {\n  left: 36px;\n}\n[dir=ltr] :host #table #icons #fullscreen {\n  right: 36px;\n}\n:host #table #symbol-id {\n  border: 1px solid white;\n  font-size: 12px;\n  padding: 4px;\n}\n:host #table #title,\n:host #table #symbol-name {\n  font-size: 16px;\n  padding: 8px;\n  font-weight: bold;\n}\n:host #text {\n  text-align: center !important;\n  font-size: 12px;\n  font-weight: bold;\n}\n:host #liquidity-percentage {\n  width: 100%;\n  background: #2ebd85;\n  text-align: center;\n  position: relative;\n  height: 6px;\n  vertical-align: middle;\n  border-radius: 3px;\n  overflow: hidden;\n}\n:host #liquidity-percentage #red {\n  background: #f5455a;\n  height: 6px;\n  position: absolute;\n  top: 0;\n  left: 0;\n}\n:host #flow-and-net {\n  border-top: 1px solid #337479;\n  border-bottom: 1px solid #337479;\n  margin: 5px;\n}\n:host #liquidity-in-title {\n  color: #2ebd85;\n  font-size: 12px;\n  font-weight: bold;\n}\n:host #liquidity-out-title {\n  color: #f5455a;\n  font-size: 12px;\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN5bWJvbC1saXF1aWRpdHktc2xpZGUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBV0U7RUFDRSxlQUFBO0VBQ0EsY0FBQTtFQUNBLHVCQUFBO1VBQUEsc0JBQUE7RUFDQSxXQUFBO0VBQ0EscUJBQUE7QUFWSjtBQVlFO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQVZKO0FBYUU7RUFtQ0UsY0FBQTtFQUNBLGlCQUFBO0FBN0NKO0FBV007RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtBQVRSO0FBVVE7RUFDRSxVQUFBO0FBUlY7QUFVUTtFQUNFLFdBQUE7QUFSVjtBQWFRO0VBQ0UsVUFBQTtBQVhWO0FBYVE7RUFDRSxXQUFBO0FBWFY7QUFlSTtFQUNFLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7QUFiTjtBQWVJOztFQUVFLGVBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7QUFiTjtBQW1CRTtFQUNFLDZCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FBakJKO0FBb0JFO0VBQ0UsV0FBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUFsQko7QUFvQkk7RUFDRSxtQkFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLE1BQUE7RUFDQSxPQUFBO0FBbEJOO0FBc0JFO0VBQ0UsNkJBQUE7RUFDQSxnQ0FBQTtFQUNBLFdBQUE7QUFwQko7QUF1QkU7RUFDRSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FBckJKO0FBd0JFO0VBQ0UsY0FBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQXRCSiIsImZpbGUiOiJzeW1ib2wtbGlxdWlkaXR5LXNsaWRlLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xuICAvLyBkaXNwbGF5OiBibG9jaztcbiAgLy8gLy8gYmFja2dyb3VuZDogIzAwNTE1NztcbiAgLy8gLy9iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1iZyk7XG4gIC8vIGNvbG9yOiB3aGl0ZTtcbiAgLy8gaGVpZ2h0OiAxMDAlO1xuICAvLyB3aWR0aDogMTAwJTtcbiAgLy8gcGFkZGluZzogMHB4O1xuICAvLyBiYWNrZ3JvdW5kLWNsaXA6IGNvbnRlbnQtYm94O1xuICAvLyBkaXNwbGF5OiBmbGV4O1xuICAvLyBhbGlnbi1pdGVtczogdG9wO1xuICAudGl0bGUtbGFiZWwge1xuICAgIGZvbnQtc2l6ZTogMTBweDtcbiAgICBjb2xvcjogI2NkZGNkZDtcbiAgICBtYXJnaW4taW5saW5lLWVuZDogNXB4O1xuICAgIHdpZHRoOiA1MHB4O1xuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgfVxuICAudmFsdWUge1xuICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICBjb2xvcjogI0ZGRkZGRjtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgfVxuXG4gICN0YWJsZSB7XG4gICAgI2ljb25zIHtcbiAgICAgIGlvbi1pY29uIHtcbiAgICAgICAgd2lkdGg6IDE5cHg7XG4gICAgICAgIGhlaWdodDogMTlweDtcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICB0b3A6IDEwcHg7XG4gICAgICAgIFtkaXI9XCJydGxcIl0gJiB7XG4gICAgICAgICAgbGVmdDogMTBweDtcbiAgICAgICAgfVxuICAgICAgICBbZGlyPVwibHRyXCJdICYge1xuICAgICAgICAgIHJpZ2h0OiAxMHB4O1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgICNmdWxsc2NyZWVuIHtcbiAgICAgICAgW2Rpcj1cInJ0bFwiXSAmIHtcbiAgICAgICAgICBsZWZ0OiAzNnB4O1xuICAgICAgICB9XG4gICAgICAgIFtkaXI9XCJsdHJcIl0gJiB7XG4gICAgICAgICAgcmlnaHQ6IDM2cHg7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgI3N5bWJvbC1pZCB7XG4gICAgICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcbiAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgIHBhZGRpbmc6IDRweDtcbiAgICB9XG4gICAgI3RpdGxlLFxuICAgICNzeW1ib2wtbmFtZSB7XG4gICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICBwYWRkaW5nOiA4cHg7XG4gICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICB9XG4gICAgZm9udC1zaXplOiA2MCU7XG4gICAgdGV4dC1hbGlnbjogc3RhcnQ7XG4gIH1cblxuICAjdGV4dCB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyICFpbXBvcnRhbnQ7XG4gICAgZm9udC1zaXplOiAxMnB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICB9XG5cbiAgI2xpcXVpZGl0eS1wZXJjZW50YWdlIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBiYWNrZ3JvdW5kOiAjMmViZDg1O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgaGVpZ2h0OiA2cHg7XG4gICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgICBib3JkZXItcmFkaXVzOiAzcHg7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcblxuICAgICNyZWQge1xuICAgICAgYmFja2dyb3VuZDogI2Y1NDU1YTtcbiAgICAgIGhlaWdodDogNnB4O1xuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgdG9wOiAwO1xuICAgICAgbGVmdDogMDtcbiAgICB9XG4gIH1cblxuICAjZmxvdy1hbmQtbmV0IHtcbiAgICBib3JkZXItdG9wOiAxcHggc29saWQgIzMzNzQ3OTtcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgIzMzNzQ3OTtcbiAgICBtYXJnaW46IDVweDtcbiAgfVxuXG4gICNsaXF1aWRpdHktaW4tdGl0bGUge1xuICAgIGNvbG9yOiAjMmViZDg1O1xuICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgfVxuXG4gICNsaXF1aWRpdHktb3V0LXRpdGxlIHtcbiAgICBjb2xvcjogI2Y1NDU1YTtcbiAgICBmb250LXNpemU6IDEycHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIH1cbn1cbiJdfQ== */";

/***/ }),

/***/ 7482:
/*!****************************************************************************************************************************!*\
  !*** ./src/app/pages/tradestation/symbol-swiper/symbol-parameters-slide/symbol-parameters-slide.component.scss?ngResource ***!
  \****************************************************************************************************************************/
/***/ ((module) => {

module.exports = ":host .title-label {\n  font-size: 10px;\n  color: #cddcdd;\n}\n:host .value {\n  font-size: 12px;\n  color: #FFFFFF;\n  font-weight: bold;\n}\n:host .index-price {\n  font-size: 16px;\n  font-weight: bold;\n  -webkit-margin-end: 5px;\n          margin-inline-end: 5px;\n}\n:host .index-change {\n  font-size: 12px;\n}\n:host .change-lable {\n  font-weight: normal;\n}\n:host #table {\n  font-size: 60%;\n  text-align: start;\n}\n:host #table #icons ion-icon {\n  width: 19px;\n  height: 19px;\n  position: absolute;\n  top: 10px;\n}\n[dir=rtl] :host #table #icons ion-icon {\n  left: 10px;\n}\n[dir=ltr] :host #table #icons ion-icon {\n  right: 10px;\n}\n[dir=rtl] :host #table #icons #fullscreen {\n  left: 36px;\n}\n[dir=ltr] :host #table #icons #fullscreen {\n  right: 36px;\n}\n:host #table #symbol-id {\n  border: 1px solid white;\n  font-size: 12px;\n  padding: 4px;\n  position: absolute;\n}\n:host #table #symbol-name {\n  font-size: 16px;\n  padding: 8px;\n  font-weight: bold;\n  width: 60vw;\n  display: block;\n  height: 30px;\n  top: -8px;\n  position: relative;\n  right: 32px;\n  left: 32px;\n}\n.down {\n  color: #f5455a !important;\n}\n.up {\n  color: #2ebd85 !important;\n}\n.zero {\n  color: #cddcdd !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN5bWJvbC1wYXJhbWV0ZXJzLXNsaWRlLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQVdJO0VBQ0ksZUFBQTtFQUNBLGNBQUE7QUFWUjtBQVlJO0VBQ0ksZUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQVZSO0FBYUk7RUFDSSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSx1QkFBQTtVQUFBLHNCQUFBO0FBWFI7QUFhSTtFQUNJLGVBQUE7QUFYUjtBQWNJO0VBQ0ksbUJBQUE7QUFaUjtBQWNJO0VBZ0RJLGNBQUE7RUFDQSxpQkFBQTtBQTNEUjtBQVlZO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7QUFWaEI7QUFZZ0I7RUFDSSxVQUFBO0FBVnBCO0FBYWdCO0VBQ0ksV0FBQTtBQVhwQjtBQWdCZ0I7RUFDSSxVQUFBO0FBZHBCO0FBaUJnQjtFQUNJLFdBQUE7QUFmcEI7QUFvQlE7RUFDSSx1QkFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUFsQlo7QUFxQlE7RUFDSSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0VBQ0EsU0FBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFVBQUE7QUFuQlo7QUEyQkU7RUFDRSx5QkFBQTtBQXhCSjtBQTJCRTtFQUNFLHlCQUFBO0FBeEJKO0FBMkJFO0VBQ0UseUJBQUE7QUF4QkoiLCJmaWxlIjoic3ltYm9sLXBhcmFtZXRlcnMtc2xpZGUuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdCB7XG4gICAgLy8gZGlzcGxheTogYmxvY2s7XG4gICAgLy8gLy8gYmFja2dyb3VuZDogIzAwNTE1NztcbiAgICAvLyAvL2JhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LWJnKTtcbiAgICAvLyBjb2xvcjogd2hpdGU7XG4gICAgLy8gaGVpZ2h0OiAxMDAlO1xuICAgIC8vIHdpZHRoOiAxMDAlO1xuICAgIC8vIHBhZGRpbmc6IDBweDtcbiAgICAvLyBiYWNrZ3JvdW5kLWNsaXA6IGNvbnRlbnQtYm94O1xuICAgIC8vIGRpc3BsYXk6IGZsZXg7XG4gICAgLy8gYWxpZ24taXRlbXM6IHRvcDtcbiAgICAudGl0bGUtbGFiZWwge1xuICAgICAgICBmb250LXNpemU6IDEwcHg7XG4gICAgICAgIGNvbG9yOiAjY2RkY2RkO1xuICAgIH1cbiAgICAudmFsdWUge1xuICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICAgIGNvbG9yOiAjRkZGRkZGO1xuICAgICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICB9XG5cbiAgICAuaW5kZXgtcHJpY2Uge1xuICAgICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICBtYXJnaW4taW5saW5lLWVuZDogNXB4O1xuICAgIH1cbiAgICAuaW5kZXgtY2hhbmdlIHtcbiAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgIH1cbiAgICBcbiAgICAuY2hhbmdlLWxhYmxlIHtcbiAgICAgICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICB9XG4gICAgI3RhYmxlIHtcbiAgICAgICAgI2ljb25zIHtcbiAgICAgICAgICAgIGlvbi1pY29uIHtcbiAgICAgICAgICAgICAgICB3aWR0aDogMTlweDtcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDE5cHg7XG4gICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgICAgIHRvcDogMTBweDtcblxuICAgICAgICAgICAgICAgIFtkaXI9XCJydGxcIl0gJiB7XG4gICAgICAgICAgICAgICAgICAgIGxlZnQ6IDEwcHg7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgW2Rpcj1cImx0clwiXSAmIHtcbiAgICAgICAgICAgICAgICAgICAgcmlnaHQ6IDEwcHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAjZnVsbHNjcmVlbiB7XG4gICAgICAgICAgICAgICAgW2Rpcj1cInJ0bFwiXSAmIHtcbiAgICAgICAgICAgICAgICAgICAgbGVmdDogMzZweDtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBbZGlyPVwibHRyXCJdICYge1xuICAgICAgICAgICAgICAgICAgICByaWdodDogMzZweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAjc3ltYm9sLWlkIHtcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHdoaXRlO1xuICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgICAgICAgcGFkZGluZzogNHB4O1xuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICB9XG5cbiAgICAgICAgI3N5bWJvbC1uYW1lIHtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAgICAgICAgIHBhZGRpbmc6IDhweDtcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICAgICAgd2lkdGg6IDYwdnc7XG4gICAgICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICAgICAgICAgIGhlaWdodDogMzBweDtcbiAgICAgICAgICAgIHRvcDogLThweDtcbiAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgICAgICAgIHJpZ2h0OiAzMnB4O1xuICAgICAgICAgICAgbGVmdDogMzJweDtcbiAgICAgICAgfVxuXG4gICAgICAgIGZvbnQtc2l6ZTogNjAlO1xuICAgICAgICB0ZXh0LWFsaWduOiBzdGFydDtcbiAgICB9XG59XG5cbiAgLmRvd24ge1xuICAgIGNvbG9yOiAjZjU0NTVhICFpbXBvcnRhbnQ7XG4gIH1cblxuICAudXAge1xuICAgIGNvbG9yOiAjMmViZDg1ICFpbXBvcnRhbnQ7XG4gIH1cblxuICAuemVyb3tcbiAgICBjb2xvcjogI2NkZGNkZCAhaW1wb3J0YW50OyAgXG4gIH0iXX0= */";

/***/ }),

/***/ 5552:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/tradestation/symbol-swiper/symbol-swiper.component.scss?ngResource ***!
  \******************************************************************************************/
/***/ ((module) => {

module.exports = ":host::ng-deep {\n  background: #337479;\n  padding-bottom: calc(16px + 0);\n  padding-bottom: calc(16px + var(--ion-safe-area-bottom, 0));\n  width: 100vw;\n  bottom: 10px;\n  touch-action: none;\n  z-index: 9999;\n}\n:host::ng-deep .symbol-details-wrapper .symbol-details-header {\n  --ion-grid-column-padding: 0;\n}\n:host::ng-deep .symbol-details-wrapper .symbol-details-header ion-row {\n  align-items: center;\n}\n:host::ng-deep .symbol-details-wrapper .symbol-details-header .symbol-title {\n  color: #FFFFFF;\n  font-weight: bold;\n  font-size: 16px;\n  margin: 0 10px;\n}\n:host::ng-deep .symbol-details-wrapper .symbol-details-header .symbol-details-action-links {\n  display: flex;\n}\n:host::ng-deep .symbol-details-wrapper .symbol-details-header .symbol-details-action-links .symbol-details-action-link {\n  width: 40px;\n  display: flex;\n  text-align: center;\n  color: #e6eff0;\n  height: 40px;\n  justify-content: center;\n  align-items: center;\n}\nbody.dark :host::ng-deep {\n  --ion-color-primary-bg: #2e2e2e;\n}\n:host::ng-deep .ion-slides {\n  margin: 0 !important;\n  --bullet-background: transparent;\n  --bullet-background-active: #99b9bc;\n  overflow-x: scroll;\n  display: flex;\n}\n:host::ng-deep .ion-slide {\n  color: #FFFFFF;\n  min-width: calc(100% - 40px);\n  height: 200px;\n  border-radius: 10px;\n  background: #0f5a61;\n  margin: 0 8px;\n}\n:host::ng-deep .ion-slide:first-child {\n  -webkit-margin-start: 16px;\n          margin-inline-start: 16px;\n}\n:host::ng-deep .ion-slide:last-child {\n  -webkit-margin-end: 16px;\n          margin-inline-end: 16px;\n}\n:host::ng-deep .ion-slide .card-header {\n  display: flex;\n  align-items: center;\n  background: #005157;\n  text-align: start;\n  border-bottom: 1px solid #337479;\n  height: 40px;\n  padding: 0 14px;\n  border-top-left-radius: 10px;\n  border-top-right-radius: 10px;\n}\n:host::ng-deep .ion-slide .card-header .title {\n  margin: 0;\n  font-size: 14px;\n  font-weight: bold;\n  -webkit-margin-end: 10px;\n          margin-inline-end: 10px;\n}\n:host::ng-deep .ion-slide .card-body {\n  height: calc(100% - 40px);\n  display: flex;\n  flex-direction: column;\n  padding: 10px;\n  padding-top: 0;\n}\n:host::ng-deep .ion-slide .card-body ion-grid {\n  margin-inline: inherit;\n  --ion-grid-padding: 0;\n}\n:host::ng-deep .ion-slide ion-text {\n  --ion-color-primary-txt: white;\n  --color: white;\n}\n:host::ng-deep .table-header {\n  --ion-grid-padding: 5px !important;\n}\n:host::ng-deep .table-header ion-col {\n  --ion-grid-column-padding: 0;\n  align-items: center;\n  justify-content: center;\n  text-align: center;\n}\n:host::ng-deep .table-content {\n  font-size: 12px;\n  font-weight: bold;\n  flex: 1 1 auto;\n  overflow: auto;\n}\n:host::ng-deep .table-content ion-grid {\n  --ion-grid-padding: 0;\n}\n:host::ng-deep .table-content ion-col {\n  --ion-grid-column-padding: 2px;\n  align-items: center;\n  justify-content: center;\n  text-align: center;\n}\n:host::ng-deep .table-content.symbol-asks-and-bids {\n  overflow: auto;\n}\n:host::ng-deep .slide-last-div {\n  width: 1px !important;\n  min-width: 1px !important;\n  background: transparent !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN5bWJvbC1zd2lwZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxtQkFBQTtFQUNBLDhCQUFBO0VBQUEsMkRBQUE7RUF5Q0EsWUFBQTtFQUVBLFlBQUE7RUFHQSxrQkFBQTtFQVVBLGFBQUE7QUFuREo7QUFBUTtFQUNJLDRCQUFBO0FBRVo7QUFBWTtFQUNJLG1CQUFBO0FBRWhCO0FBQ1k7RUFDSSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtBQUNoQjtBQUVZO0VBQ0ksYUFBQTtBQUFoQjtBQUVnQjtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFBcEI7QUFPSTtFQUNJLCtCQUFBO0FBTFI7QUEwQkk7RUFDSSxvQkFBQTtFQUNBLGdDQUFBO0VBQ0EsbUNBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7QUF4QlI7QUE2Qkk7RUFDSSxjQUFBO0VBRUEsNEJBQUE7RUFFQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLGFBQUE7QUE3QlI7QUErQlE7RUFDSSwwQkFBQTtVQUFBLHlCQUFBO0FBN0JaO0FBZ0NRO0VBQ0ksd0JBQUE7VUFBQSx1QkFBQTtBQTlCWjtBQWlDUTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQ0FBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsNEJBQUE7RUFDQSw2QkFBQTtBQS9CWjtBQWlDWTtFQUNJLFNBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSx3QkFBQTtVQUFBLHVCQUFBO0FBL0JoQjtBQW1DUTtFQUNJLHlCQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsYUFBQTtFQUNBLGNBQUE7QUFqQ1o7QUFtQ1k7RUFDSSxzQkFBQTtFQUNBLHFCQUFBO0FBakNoQjtBQXdDUTtFQUNJLDhCQUFBO0VBQ0EsY0FBQTtBQXRDWjtBQTBDSTtFQUNJLGtDQUFBO0FBeENSO0FBMENRO0VBQ0ksNEJBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7QUF4Q1o7QUE0Q0k7RUFDSSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtBQTFDUjtBQTRDUTtFQUNJLHFCQUFBO0FBMUNaO0FBNkNRO0VBQ0ksOEJBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7QUEzQ1o7QUE4Q1E7RUFDSSxjQUFBO0FBNUNaO0FBZ0RJO0VBQ0kscUJBQUE7RUFDQSx5QkFBQTtFQUNBLGtDQUFBO0FBOUNSIiwiZmlsZSI6InN5bWJvbC1zd2lwZXIuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdDo6bmctZGVlcCB7XG4gICAgYmFja2dyb3VuZDogIzMzNzQ3OTtcbiAgICBwYWRkaW5nLWJvdHRvbTogY2FsYyggMTZweCArIHZhcigtLWlvbi1zYWZlLWFyZWEtYm90dG9tLCAwKSApO1xuXG4gICAgLnN5bWJvbC1kZXRhaWxzLXdyYXBwZXIge1xuXG5cbiAgICAgICAgLnN5bWJvbC1kZXRhaWxzLWhlYWRlciB7XG4gICAgICAgICAgICAtLWlvbi1ncmlkLWNvbHVtbi1wYWRkaW5nOiAwO1xuXG4gICAgICAgICAgICBpb24tcm93IHtcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAuc3ltYm9sLXRpdGxlIHtcbiAgICAgICAgICAgICAgICBjb2xvcjogI0ZGRkZGRjtcbiAgICAgICAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICAgICAgICAgICAgbWFyZ2luOiAwIDEwcHg7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC5zeW1ib2wtZGV0YWlscy1hY3Rpb24tbGlua3Mge1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG5cbiAgICAgICAgICAgICAgICAuc3ltYm9sLWRldGFpbHMtYWN0aW9uLWxpbmsge1xuICAgICAgICAgICAgICAgICAgICB3aWR0aDogNDBweDtcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICAgICAgICAgICAgICBjb2xvcjogI2U2ZWZmMDtcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiA0MHB4O1xuICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgIH1cblxuICAgIGJvZHkuZGFyayAmIHtcbiAgICAgICAgLS1pb24tY29sb3ItcHJpbWFyeS1iZzogIzJlMmUyZTtcbiAgICB9XG5cbiAgICAvLyBwb3NpdGlvbjogZml4ZWQ7XG4gICAgd2lkdGg6IDEwMHZ3O1xuXG4gICAgYm90dG9tOiAxMHB4O1xuXG4gICAgLy8gUHJldmVudCBzY3JvbGxpbmcgb24gdGhlIGJhY2tcbiAgICB0b3VjaC1hY3Rpb246IG5vbmU7XG5cbiAgICAucGx0LWlvcyAmIHtcbiAgICAgICAgLy8gYm90dG9tOiA5MHB4O1xuICAgIH1cblxuICAgIC5wbHQtbW9iaWxld2ViICYge1xuICAgICAgICAvLyAgYm90dG9tOiAwO1xuICAgIH1cblxuICAgIHotaW5kZXg6IDk5OTk7XG5cbiAgICAuaW9uLXNsaWRlcyB7XG4gICAgICAgIG1hcmdpbjogMCAhaW1wb3J0YW50O1xuICAgICAgICAtLWJ1bGxldC1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICAgICAgLS1idWxsZXQtYmFja2dyb3VuZC1hY3RpdmU6ICM5OWI5YmM7XG4gICAgICAgIG92ZXJmbG93LXg6IHNjcm9sbDtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgLy9mbGV4LXdyYXA6IG5vd3JhcDtcbiAgICAgICAgLy9wYWRkaW5nOiAwIDZweDtcbiAgICB9XG5cbiAgICAuaW9uLXNsaWRlIHtcbiAgICAgICAgY29sb3I6ICNGRkZGRkY7XG4gICAgICAgIC8vd2lkdGg6IDEwMCU7XG4gICAgICAgIG1pbi13aWR0aDogY2FsYygxMDAlIC0gNDBweCk7XG4gICAgICAgIC8vZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgICAgICBoZWlnaHQ6IDIwMHB4O1xuICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgICAgICBiYWNrZ3JvdW5kOiAjMGY1YTYxO1xuICAgICAgICBtYXJnaW46IDAgOHB4O1xuXG4gICAgICAgICY6Zmlyc3QtY2hpbGQge1xuICAgICAgICAgICAgbWFyZ2luLWlubGluZS1zdGFydDogMTZweDtcbiAgICAgICAgfVxuXG4gICAgICAgICY6bGFzdC1jaGlsZCB7XG4gICAgICAgICAgICBtYXJnaW4taW5saW5lLWVuZDogMTZweDtcbiAgICAgICAgfVxuXG4gICAgICAgIC5jYXJkLWhlYWRlciB7XG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICMwMDUxNTc7XG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBzdGFydDtcbiAgICAgICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjMzM3NDc5O1xuICAgICAgICAgICAgaGVpZ2h0OiA0MHB4O1xuICAgICAgICAgICAgcGFkZGluZzogMCAxNHB4O1xuICAgICAgICAgICAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogMTBweDtcbiAgICAgICAgICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAxMHB4O1xuXG4gICAgICAgICAgICAudGl0bGUge1xuICAgICAgICAgICAgICAgIG1hcmdpbjogMDtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICAgICAgICAgICAgbWFyZ2luLWlubGluZS1lbmQ6IDEwcHg7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAuY2FyZC1ib2R5IHtcbiAgICAgICAgICAgIGhlaWdodDogY2FsYygxMDAlIC0gNDBweCk7XG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgICAgICAgIHBhZGRpbmc6IDEwcHg7XG4gICAgICAgICAgICBwYWRkaW5nLXRvcDogMDtcblxuICAgICAgICAgICAgaW9uLWdyaWQge1xuICAgICAgICAgICAgICAgIG1hcmdpbi1pbmxpbmU6IGluaGVyaXQ7XG4gICAgICAgICAgICAgICAgLS1pb24tZ3JpZC1wYWRkaW5nOiAwO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gLnBsdC1pb3MgJiB7XG4gICAgICAgIC8vICAgICBoZWlnaHQ6IDM1MnB4O1xuICAgICAgICAvLyB9XG4gICAgICAgIGlvbi10ZXh0IHtcbiAgICAgICAgICAgIC0taW9uLWNvbG9yLXByaW1hcnktdHh0OiB3aGl0ZTtcbiAgICAgICAgICAgIC0tY29sb3I6IHdoaXRlO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLnRhYmxlLWhlYWRlciB7XG4gICAgICAgIC0taW9uLWdyaWQtcGFkZGluZzogNXB4ICFpbXBvcnRhbnQ7XG5cbiAgICAgICAgaW9uLWNvbCB7XG4gICAgICAgICAgICAtLWlvbi1ncmlkLWNvbHVtbi1wYWRkaW5nOiAwO1xuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLnRhYmxlLWNvbnRlbnQge1xuICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICBmbGV4OiAxIDEgYXV0bztcbiAgICAgICAgb3ZlcmZsb3c6IGF1dG87XG5cbiAgICAgICAgaW9uLWdyaWQge1xuICAgICAgICAgICAgLS1pb24tZ3JpZC1wYWRkaW5nOiAwO1xuICAgICAgICB9XG5cbiAgICAgICAgaW9uLWNvbCB7XG4gICAgICAgICAgICAtLWlvbi1ncmlkLWNvbHVtbi1wYWRkaW5nOiAycHg7XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgIH1cblxuICAgICAgICAmLnN5bWJvbC1hc2tzLWFuZC1iaWRzIHtcbiAgICAgICAgICAgIG92ZXJmbG93OiBhdXRvO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLnNsaWRlLWxhc3QtZGl2IHtcbiAgICAgICAgd2lkdGg6IDFweCAhaW1wb3J0YW50O1xuICAgICAgICBtaW4td2lkdGg6IDFweCAhaW1wb3J0YW50O1xuICAgICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuICAgIH1cbn0iXX0= */";

/***/ }),

/***/ 35459:
/*!********************************************************************************************************************!*\
  !*** ./src/app/pages/tradestation/symbol-swiper/symbol-trades-slide/symbol-trades-slide.component.scss?ngResource ***!
  \********************************************************************************************************************/
/***/ ((module) => {

module.exports = ":host .table-header {\n  font-size: 10px;\n  color: #cddcdd;\n}\n:host #table {\n  font-size: 60%;\n  text-align: start;\n}\n:host #table #title {\n  font-size: 16px;\n  padding: 8px;\n  font-weight: bold;\n}\n:host #table #icons ion-icon {\n  width: 19px;\n  height: 19px;\n  position: absolute;\n  top: 10px;\n}\n[dir=rtl] :host #table #icons ion-icon {\n  left: 10px;\n}\n[dir=ltr] :host #table #icons ion-icon {\n  right: 10px;\n}\n[dir=rtl] :host #table #icons #fullscreen {\n  left: 36px;\n}\n[dir=ltr] :host #table #icons #fullscreen {\n  right: 36px;\n}\n:host #table #symbol-id {\n  border: 1px solid white;\n  font-size: 12px;\n  padding: 4px;\n}\n:host #table #symbol-name {\n  font-size: 16px;\n  padding: 8px;\n  font-weight: bold;\n}\n:host #trades-table ion-row:nth-child(even) {\n  background: rgba(255, 255, 255, 0.1);\n}\n:host #trades-table ion-col {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  text-align: center;\n}\n.down {\n  color: #f5455a !important;\n}\n.up {\n  color: #2ebd85 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN5bWJvbC10cmFkZXMtc2xpZGUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBZ0JJO0VBQ0ksZUFBQTtFQUNBLGNBQUE7QUFmUjtBQWtCSTtFQXVDSSxjQUFBO0VBQ0EsaUJBQUE7QUF0RFI7QUFlUTtFQUNJLGVBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7QUFiWjtBQWdCWTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0FBZGhCO0FBZWdCO0VBQ0ksVUFBQTtBQWJwQjtBQWVnQjtFQUNJLFdBQUE7QUFicEI7QUFrQmdCO0VBQ0ksVUFBQTtBQWhCcEI7QUFrQmdCO0VBQ0ksV0FBQTtBQWhCcEI7QUFvQlE7RUFDSSx1QkFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0FBbEJaO0FBb0JRO0VBQ0ksZUFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtBQWxCWjtBQXlCUTtFQUNJLG9DQUFBO0FBdkJaO0FBMEJRO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtBQXhCWjtBQTRCQTtFQUNJLHlCQUFBO0FBekJKO0FBNEJFO0VBQ0UseUJBQUE7QUF6QkoiLCJmaWxlIjoic3ltYm9sLXRyYWRlcy1zbGlkZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcbiAgICAvLyBkaXNwbGF5OiBibG9jaztcbiAgICAvLyAvLyBiYWNrZ3JvdW5kOiAjMDA1MTU3O1xuICAgIC8vIC8vYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktYmcpO1xuICAgIC8vIGNvbG9yOiB3aGl0ZTtcbiAgICAvLyBoZWlnaHQ6IDEwMCU7XG4gICAgLy8gd2lkdGg6IDEwMCU7XG4gICAgLy8gcGFkZGluZzogMHB4O1xuICAgIC8vIGJhY2tncm91bmQtY2xpcDogY29udGVudC1ib3g7XG4gICAgLy8gZGlzcGxheTogZmxleDtcbiAgICAvLyBhbGlnbi1pdGVtczogdG9wO1xuXG4gICAgLy8gaW9uLXRleHQge1xuICAgIC8vICAgICAtLWlvbi1jb2xvci1wcmltYXJ5LXR4dDogd2hpdGU7XG4gICAgLy8gfVxuXG4gICAgLnRhYmxlLWhlYWRlciB7XG4gICAgICAgIGZvbnQtc2l6ZTogMTBweDtcbiAgICAgICAgY29sb3I6ICNjZGRjZGQ7XG4gICAgfVxuXG4gICAgI3RhYmxlIHtcbiAgICAgICAgI3RpdGxlIHtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAgICAgICAgIHBhZGRpbmc6IDhweDtcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICB9XG4gICAgICAgICNpY29ucyB7XG4gICAgICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDE5cHg7XG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAxOXB4O1xuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgICAgICB0b3A6IDEwcHg7XG4gICAgICAgICAgICAgICAgW2Rpcj1cInJ0bFwiXSAmIHtcbiAgICAgICAgICAgICAgICAgICAgbGVmdDogMTBweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgW2Rpcj1cImx0clwiXSAmIHtcbiAgICAgICAgICAgICAgICAgICAgcmlnaHQ6IDEwcHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAjZnVsbHNjcmVlbiB7XG4gICAgICAgICAgICAgICAgW2Rpcj1cInJ0bFwiXSAmIHtcbiAgICAgICAgICAgICAgICAgICAgbGVmdDogMzZweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgW2Rpcj1cImx0clwiXSAmIHtcbiAgICAgICAgICAgICAgICAgICAgcmlnaHQ6IDM2cHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgICNzeW1ib2wtaWQge1xuICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgd2hpdGU7XG4gICAgICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICAgICAgICBwYWRkaW5nOiA0cHg7XG4gICAgICAgIH1cbiAgICAgICAgI3N5bWJvbC1uYW1lIHtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAgICAgICAgIHBhZGRpbmc6IDhweDtcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICB9XG4gICAgICAgIGZvbnQtc2l6ZTogNjAlO1xuICAgICAgICB0ZXh0LWFsaWduOiBzdGFydDtcbiAgICB9XG5cbiAgICAjdHJhZGVzLXRhYmxlIHtcbiAgICAgICAgaW9uLXJvdzpudGgtY2hpbGQoZXZlbikge1xuICAgICAgICAgICAgYmFja2dyb3VuZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjEpO1xuICAgICAgICB9XG5cbiAgICAgICAgaW9uLWNvbCB7XG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICB9XG4gICAgfVxufVxuLmRvd24ge1xuICAgIGNvbG9yOiAjZjU0NTVhICFpbXBvcnRhbnQ7XG4gIH1cblxuICAudXAge1xuICAgIGNvbG9yOiAjMmViZDg1ICFpbXBvcnRhbnQ7XG4gIH1cbiJdfQ== */";

/***/ }),

/***/ 58351:
/*!**********************************************************************************************************************************!*\
  !*** ./src/app/pages/tradestation/symbol-swiper/symbol-bids-and-asks-slide/symbol-bids-and-asks-slide.component.html?ngResource ***!
  \**********************************************************************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"card-header\">\n  <h4 class=\"title\">{{ 'tradestion.BIDS_AND_ASKS' | translate }}</h4>\n</div>\n<div class=\"card-body\">\n\n  <ion-grid class=\"table-header\">\n    <ion-row>\n      <ion-col *ngFor=\"let headerItem of asksListHeader\">\n        {{ headerItem }}\n      </ion-col>\n      <ion-col *ngFor=\"let headerItem of bidsListHeader\">\n        {{ headerItem }}\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <ion-grid class=\"table-content symbol-asks-and-bids\">\n    <ion-row *ngFor=\"let item of askBids\">\n    <!-- <ion-grid *ngFor=\"let item of symbol?.asksAndBids | async | slice: 0:4\"> -->\n        <ion-col class=\"ask-item\">\n          {{ item.askSplit }}\n        </ion-col>\n        <ion-col class=\"ask-item\">\n          {{ item.askQuantity }}\n        </ion-col>\n        <ion-col class=\"ask-item\">\n          {{ item.askPrice }}\n        </ion-col>\n      <!-- </ion-grid> -->\n    <!-- <ion-grid *ngFor=\"let bid of symbol?.bids | async | slice: 0:4\"> -->\n        <ion-col class=\"bid-item\">\n          {{ item.bidPrice }}\n        </ion-col>\n        <ion-col class=\"bid-item\">\n          {{ item.bidQuantity }}\n        </ion-col>\n        <ion-col class=\"bid-item\">\n          {{ item.bidSplit }}\n        </ion-col>\n      <!-- </ion-grid> -->\n    </ion-row>\n  </ion-grid>\n</div>";

/***/ }),

/***/ 72557:
/*!**************************************************************************************************************************!*\
  !*** ./src/app/pages/tradestation/symbol-swiper/symbol-liquidity-slide/symbol-liquidity-slide.component.html?ngResource ***!
  \**************************************************************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"card-header\">\n  <h4 class=\"title\">{{ 'tradestion.LIQUIDITY' | translate }}</h4>\n</div>\n\n<div class=\"card-body\">\n  <ion-grid id=\"table\">\n    <!-- <ion-row>\n      <ion-col>\n        <span id=\"title\">{{ 'tradestionLIQUIDITY }}</span>\n\n        <span id=\"icons\">\n          <ion-icon id=\"fullscreen\" src=\"assets/icon/fullscreen.svg\" (click)=\"openSymbol()\"></ion-icon>\n          <ion-icon\n            id=\"close\"\n            src=\"assets/icon/close.svg\"\n            (click)=\"onClose()\"\n          ></ion-icon>\n        </span>\n      </ion-col>\n    </ion-row> -->\n  <!-- \n    this.liquidityPercentage = options.cachePercent;\n    (symbol?.parameters | async)?.liquidityPercentage)\n    // تدفق\n    this.cashInTurnover = options.cashInTurnover;//: \"5611752.41\" تدفق\n    (symbol?.parameters | async)?.cashInTurnover)\n    // حجم السيولة الداخلة\n    this.cashInVolume = options.cashInVolume;//: \"75277\" حجم السيولة الداخلة\n    // تغير السيولة الخارجة\n    this.cashOutTurnover = options.cashOutTurnover;//: \"5959933.32\"\n    // حجم السيولة الخارجة\n    this.cashOutVolume = options.cashOutVolume;//: \"79937\" حجم السيولة الخارجة \n  -->\n\n    <ion-row>\n      <ion-col>\n        <!-- <span id=\"\">{{ 'tradestionLIQUIDITY_PERCENTAGE }}</span> -->\n\n        <div id=\"text\">{{(symbol?.parameters | async)?.liquidityPercentage}}%</div>\n        <div id=\"liquidity-percentage\">\n          <div id=\"red\" [ngStyle]=\"{width: (100 - (symbol?.parameters | async)?.liquidityPercentage) +'%'}\"></div>\n        </div>\n      </ion-col>\n    </ion-row>\n\n    <ion-row id=\"flow-and-net\">\n      <ion-col>\n        <span class=\"title-label\">{{ 'tradestion.LIQUIDITY_FLOW' | translate }}</span>\n        <span class=\"value\">{{(symbol?.parameters | async)?.liquidityFlow | commafy:'number':2}}</span>\n      </ion-col>\n      <ion-col>\n        <span class=\"title-label\">{{ 'tradestion.LIQUIDITY_NET' | translate }}</span>\n        <span class=\"value\">{{(symbol?.parameters | async)?.liquidityNet | commafy:'number':2}}</span>\n      </ion-col>\n    </ion-row>\n\n    <!-- FLOW IN AND OUT -->\n    <ion-row>\n      <!-- START OF LIQUIDITY IN COLUMN -->\n      <ion-col id=\"liquidity-in-title\" size=\"6\">\n        <div>{{ 'tradestion.LIQUIDITY_IN' | translate }}</div>\n        <div>\n          <span class=\"title-label\">{{ 'tradestion.LIQUIDITY_VOLUME' | translate }}</span>\n          <span class=\"value\">{{ (symbol?.parameters | async)?.cashInVolume }}</span>\n        </div>\n        <div>\n          <span class=\"title-label\">{{ 'tradestion.LIQUIDITY_VALUE' | translate }}</span>\n          <span class=\"value\">{{ (symbol?.parameters | async)?.cashInTurnover }}</span>\n        </div>\n      </ion-col>\n      <!-- END OF LIQUIDITY IN COLUMN -->\n      <!-- START OF LIQUIDITY OUT COLUMN -->\n      <!-- END OF LIQUIDITY OUT COLUMN -->\n\n      <ion-col id=\"liquidity-out-title\" size=\"6\">\n        <div>{{ 'tradestion.LIQUIDITY_OUT' | translate }}</div>\n\n        <div>\n          <span class=\"title-label\">{{ 'tradestion.LIQUIDITY_VOLUME' | translate }}</span>\n          <span class=\"value\">{{ (symbol?.parameters | async)?.cashOutVolume}}</span>\n        </div>\n\n        <div>\n          <span class=\"title-label\">{{ 'tradestion.LIQUIDITY_VALUE' | translate }}</span>\n          <span class=\"value\">{{ (symbol?.parameters | async)?.cashOutTurnover }}</span>\n        </div>\n      </ion-col>\n    </ion-row>\n\n    <!-- END OF FLOW IN AND OUT -->\n  </ion-grid>\n</div>";

/***/ }),

/***/ 65053:
/*!****************************************************************************************************************************!*\
  !*** ./src/app/pages/tradestation/symbol-swiper/symbol-parameters-slide/symbol-parameters-slide.component.html?ngResource ***!
  \****************************************************************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"card-header\">\n  <h4 class=\"title\">{{'tradestion.priceChange' | translate}}</h4>\n  <div class=\"index-price\" [ngClass]=\"{'down':(Number((symbol?.parameters | async)?.changePercentage)) < 0 ,'up':(Number((symbol?.parameters | async)?.changePercentage)) > 0 ,'zero':(Number((symbol?.parameters | async)?.changePercentage)) == 0 } \">\n    {{ ((symbol?.price | async) | commafy) || '0.000' }}\n  </div>\n  <div class=\"index-change\" [ngClass]=\"{'down':(Number((symbol?.parameters | async)?.changePercentage)) < 0 ,'up':(Number((symbol?.parameters | async)?.changePercentage)) > 0 ,'zero':(Number((symbol?.parameters | async)?.changePercentage)) == 0 } \">\n   ({{((symbol?.parameters | async)?.changePercentage)  || '0.000'}} % ) {{((symbol?.parameters | async)?.change | commafy) || '0.000'}}\n  </div>\n</div>\n\n<div class=\"card-body\">\n  <ion-grid id='table'>\n    <!-- <ion-row style=\"margin-bottom: 5px\">\n      <ion-col>\n        <span id='symbol-id'>{{ symbol?.id }}</span>\n        <span id='symbol-name'>{{ symbol?.name | async }}</span>\n\n        <span id='icons'>\n          <ion-icon id=\"fullscreen\" src='assets/icon/fullscreen.svg' (click)=\"openSymbol()\"></ion-icon>\n          <ion-icon id=\"close\" src='assets/icon/close.svg' (click)=\"onClose()\"></ion-icon>\n        </span>\n      </ion-col>\n    </ion-row> -->\n    <ion-row>\n\n      <ion-col size=\"3\">\n        <div class=\"title-label\">{{ 'tradestion.OPENNING' | translate }}</div>\n        <div class=\"value\">{{ ((symbol?.parameters | async)?.openPrice | commafy) || '0.000' }}</div>\n      </ion-col>\n\n      <ion-col size=\"3\">\n        <div class=\"title-label\">{{ 'tradestion.CLOSING' | translate }}</div>\n        <div class=\"value\">{{ ((symbol?.parameters | async)?.previousClosed | commafy) || '0.000' }}</div>\n      </ion-col>\n\n      <ion-col size=\"3\">\n        <div class=\"title-label\">{{ 'tradestion.MIN_LIMIT' | translate }}</div>\n        <div class=\"value\" style=\"color: #f5455a !important;\">{{ ((symbol?.parameters | async)?.lowestPrice | commafy) || '0.000'}}</div>\n      </ion-col>\n\n      <ion-col size=\"3\">\n        <div class=\"title-label\">{{ 'tradestion.MAX_LIMIT' | translate }}</div>\n        <div class=\"value\" style=\"color: #2ebd85 !important;\">{{ ((symbol?.parameters | async)?.highestPrice | commafy) || '0.000' }}</div>\n      </ion-col>\n\n      <ion-col size=\"3\">\n        <div class=\"title-label\">{{ 'tradestion.TRADES' | translate }}</div>\n        <div class=\"value\">{{ ((symbol?.parameters | async)?.noOfTrades) || '0.000' }}</div>\n      </ion-col>\n\n      <ion-col size=\"3\">\n        <div class=\"title-label\">{{ 'tradestion.VOLUME' | translate }}</div>\n        <div class=\"value\">{{ ((symbol?.parameters | async)?.tradingVolume | commafy) || '0.000' }} </div>\n      </ion-col>\n\n      <ion-col size=\"auto\">\n        <div class=\"title-label\">{{ 'tradestion.VALUE_OF_TRADING' | translate }}</div>\n        <div class=\"value\">{{ ((symbol?.parameters | async)?.tradingValue | commafy) || '0.000'}}</div>\n      </ion-col>\n    </ion-row>\n\n\n    <ion-row>\n\n\n\n      <ion-col>\n        \n        <app-button (clickAction)=\"openBuySellSymbols(symbol,'buy')\" expand=\"block\" size=\"small\" color=\"success\" fill=\"solid\"\n          shape=\"\" type=\"button\">\n          {{'tradestion.BUY' | translate}}\n        </app-button>\n      </ion-col>\n      <!-- *ngIf=\"symbol?.isOwned | async\" -->\n      <ion-col>\n        <app-button (clickAction)=\"openBuySellSymbols(symbol,'sell')\" expand=\"block\" size=\"small\" color=\"danger\" fill=\"solid\"\n          shape=\"\" type=\"button\">\n          {{'tradestion.SELL' | translate}}\n        </app-button>\n      </ion-col>\n\n\n\n    </ion-row>\n  </ion-grid>\n</div>";

/***/ }),

/***/ 9065:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/tradestation/symbol-swiper/symbol-swiper.component.html?ngResource ***!
  \******************************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"symbol-details-wrapper\">\n  <ion-input hidden  value='{{symbol?.id}}' (ionChange)='move()'></ion-input>\n  <ion-grid class=\"symbol-details-header\">\n    <ion-row>\n      <ion-col>\n        <h4 class=\"symbol-title\">{{ symbol?.id }} - {{ symbol?.abbreviation | async }}</h4>\n      </ion-col>\n\n      <ion-col size=\"auto\">\n        <div class=\"symbol-details-action-links\">\n        <div class=\"symbol-details-action-link\" (click)=\"emitSymbolWatchlists()\">\n          <span class=\"icon icon-bookmark\" *ngIf=\"symbol?.includedIntoWatchList\"></span>\n          <span class=\"icon icon-bookmark-o\" *ngIf=\"!symbol?.includedIntoWatchList\"></span>\n        </div>\n        <div class=\"symbol-details-action-link\" (click)=\"openSymbol()\">\n          <span class=\"icon icon-redirect\"></span>\n        </div>\n        <div class=\"symbol-details-action-link\" (click)=\"onClose()\">\n          <span class=\"icon icon-close\"></span>\n        </div>\n      </div>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <div class=\"ion-slides\">\n\n  <div id=\"first-slide\" class=\"ion-slide\">\n    <tadawul-symbol-parameters-slide\n      [symbol]=\"symbol\"\n      (close)=\"onClose()\"\n    ></tadawul-symbol-parameters-slide>\n  </div>\n\n  <div class=\"ion-slide\">\n    <tadawul-symbol-bids-and-asks-slide\n      [symbol]=\"symbol\"\n      (close)=\"onClose()\"\n    ></tadawul-symbol-bids-and-asks-slide>\n  </div>\n\n  <div class=\"ion-slide\">\n    <tadawul-symbol-trades-slide\n      [symbol]=\"symbol\"\n      (close)=\"onClose()\"\n    ></tadawul-symbol-trades-slide>\n  </div>\n\n  <div class=\"ion-slide\">\n    <tadawul-symbol-liquidity-slide\n      [symbol]=\"symbol\"\n      (close)=\"onClose()\"\n    ></tadawul-symbol-liquidity-slide>\n  </div>\n  <div class=\"ion-slide slide-last-div\"></div>\n  \n</div>\n\n</div>";

/***/ }),

/***/ 98744:
/*!********************************************************************************************************************!*\
  !*** ./src/app/pages/tradestation/symbol-swiper/symbol-trades-slide/symbol-trades-slide.component.html?ngResource ***!
  \********************************************************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"card-header\">\n  <h4 class=\"title\">{{ 'tradestion.TRADES' | translate }}</h4>\n</div>\n\n<div class=\"card-body\">\n  <ion-grid class=\"table-header\">\n    <ion-row>\n      <ion-col *ngFor=\"let headerItem of listHeader\">\n        {{ headerItem }}\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <ion-grid id=\"trades-table\" class=\"table-content\">\n    <ion-row *ngFor=\"let trade of (symbol?.trades | async); let index = index\" [ngClass]=\"{ odd: 1 === index % 2 }\">\n      <ion-col>\n        {{ trade.tradeTime }}\n      </ion-col>\n      <ion-col>\n        {{ trade.quantity }}\n      </ion-col>\n      <ion-col>\n        <ion-text [ngClass]=\"trade.type == 'S' ? 'down' : 'up' \">\n          {{ trade.price }}\n        </ion-text>\n      </ion-col>\n      <ion-col>\n        {{ trade.splits }}\n      </ion-col>\n\n      <ion-col [ngClass]=\"trade.type == 'S' ? 'down' : 'up' \">\n        {{ translate.instant('tradestion.'+trade.type)}}\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</div>\n\n\n\n\n\n\n\n\n\n\n\n\n<!-- \n<ion-grid id=\"table\">\n  <ion-row style=\"height: calc(100% - 74px); overflow-y: scroll;\">\n    <ion-col>\n   \n      <ion-grid id=\"trades-table\">\n        <ion-row class=\"table-header\">\n          <ion-col *ngFor=\"let headerItem of listHeader\">\n            {{ headerItem }}\n          </ion-col>\n        </ion-row>\n\n       \n        <ion-row class=\"ion-no-padding\" *ngFor=\"let trade of (symbol?.trades | async); let index = index\"\n          [ngClass]=\"{ odd: 1 === index % 2 }\">\n          <ion-col>\n              {{ trade.tradeTime }}\n          </ion-col>\n          <ion-col>\n              {{ trade.quantity }}\n          </ion-col>\n          <ion-col>\n            <ion-text color=\"danger\">\n              {{ trade.price }}\n            </ion-text>\n          </ion-col>\n          <ion-col>\n              {{ trade.splits }}\n          </ion-col>\n\n          <ion-col>\n              {{ t[trade.type] }}\n          </ion-col>\n\n        </ion-row>\n      </ion-grid>\n\n    </ion-col>\n  </ion-row>\n</ion-grid> -->";

/***/ })

}]);
//# sourceMappingURL=default-src_app_pages_tradestation_symbol-swiper_symbol-swiper_module_ts.js.map