import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { DisconnectionPagePage } from './disconnection-page.page';

describe('DisconnectionPagePage', () => {
  let component: DisconnectionPagePage;
  let fixture: ComponentFixture<DisconnectionPagePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisconnectionPagePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(DisconnectionPagePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
