"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_watchlists_index_watchlists-index_module_ts"],{

/***/ 99148:
/*!***************************************************************************!*\
  !*** ./src/app/pages/watchlists/index/watchlists-index-routing.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchlistsIndexPageRoutingModule": () => (/* binding */ WatchlistsIndexPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _watchlists_index_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlists-index.page */ 56889);




const routes = [
    {
        path: '',
        component: _watchlists_index_page__WEBPACK_IMPORTED_MODULE_0__.WatchlistsIndexPage
    }
];
let WatchlistsIndexPageRoutingModule = class WatchlistsIndexPageRoutingModule {
};
WatchlistsIndexPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], WatchlistsIndexPageRoutingModule);



/***/ }),

/***/ 79620:
/*!*******************************************************************!*\
  !*** ./src/app/pages/watchlists/index/watchlists-index.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchlistsIndexPageModule": () => (/* binding */ WatchlistsIndexPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _watchlists_index_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlists-index-routing.module */ 99148);
/* harmony import */ var _watchlists_index_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./watchlists-index.page */ 56889);








let WatchlistsIndexPageModule = class WatchlistsIndexPageModule {
};
WatchlistsIndexPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _watchlists_index_routing_module__WEBPACK_IMPORTED_MODULE_0__.WatchlistsIndexPageRoutingModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__.TranslateModule.forChild()
        ],
        declarations: [_watchlists_index_page__WEBPACK_IMPORTED_MODULE_1__.WatchlistsIndexPage]
    })
], WatchlistsIndexPageModule);



/***/ }),

/***/ 56889:
/*!*****************************************************************!*\
  !*** ./src/app/pages/watchlists/index/watchlists-index.page.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchlistsIndexPage": () => (/* binding */ WatchlistsIndexPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _watchlists_index_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlists-index.page.html?ngResource */ 25686);
/* harmony import */ var _watchlists_index_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./watchlists-index.page.scss?ngResource */ 36957);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_models_watchlist__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/models/watchlist */ 12059);
/* harmony import */ var _app_app_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../app/app.component */ 20721);






let WatchlistsIndexPage = class WatchlistsIndexPage {
    constructor() {
        this.Watchlists = _inma_models_watchlist__WEBPACK_IMPORTED_MODULE_2__.Watchlists;
    }
    ngOnInit() {
    }
    get isSectors() {
        return _app_app_component__WEBPACK_IMPORTED_MODULE_3__.App.isActive('/sectors');
    }
    get isWatchlists() {
        return !this.isSectors;
    }
};
WatchlistsIndexPage.ctorParameters = () => [];
WatchlistsIndexPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-watchlists',
        template: _watchlists_index_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_watchlists_index_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__metadata)("design:paramtypes", [])
], WatchlistsIndexPage);



/***/ }),

/***/ 36957:
/*!******************************************************************************!*\
  !*** ./src/app/pages/watchlists/index/watchlists-index.page.scss?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

module.exports = ":host {\n  height: 100%;\n}\n:host ion-item {\n  --color: var(--ion-color-primary-txt);\n  --border-color: transparent;\n  --border-color: transparent;\n}\n:host ion-fab {\n  position: absolute;\n  left: 16px;\n  bottom: 16px;\n}\n:host ion-toolbar {\n  --background: #005157;\n  --color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndhdGNobGlzdHMtaW5kZXgucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsWUFBQTtBQUNGO0FBQUU7RUFFSSxxQ0FBQTtFQUNBLDJCQUFBO0VBQ0EsMkJBQUE7QUFDTjtBQUVFO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtBQUFKO0FBR0U7RUFDRSxxQkFBQTtFQUNBLGNBQUE7QUFESiIsImZpbGUiOiJ3YXRjaGxpc3RzLWluZGV4LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcbiAgaGVpZ2h0OiAxMDAlO1xuICBpb24taXRlbSB7XG4gICAgICAvLyAtLWNvbG9yOiAjMDA1NDU3O1xuICAgICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktdHh0KTtcbiAgICAgIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgICAgIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgfVxuXG4gIGlvbi1mYWIge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBsZWZ0OiAxNnB4O1xuICAgIGJvdHRvbTogMTZweDtcbiAgfVxuXG4gIGlvbi10b29sYmFyIHtcbiAgICAtLWJhY2tncm91bmQ6ICMwMDUxNTc7XG4gICAgLS1jb2xvcjogd2hpdGU7XG4gIH1cblxuICAvLyBpb24tYmFjay1idXR0b24ge1xuICAvLyAgIGRpc3BsYXk6IGJsb2NrO1xuICAvLyB9XG5cbn1cbiJdfQ== */";

/***/ }),

/***/ 25686:
/*!******************************************************************************!*\
  !*** ./src/app/pages/watchlists/index/watchlists-index.page.html?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <!-- <ion-back-button></ion-back-button> -->\n      <ion-back-button [text]=\"''\"></ion-back-button>\n    </ion-buttons>\n\n    <ion-title *ngIf=\"isWatchlists\">\n      {{ 'watchlist.WATCHLISTS_INDEX_PAGE_TITLE' | translate }}\n    </ion-title>\n    <ion-title *ngIf=\"isSectors\"> {{ 'watchlist.SECTORS_INDEX_PAGE_TITLE' | translate }} </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-item\n    button\n    *ngFor=\"let w of (isSectors ? Watchlists.allSectors : Watchlists.all) | async\"\n    [routerLink]=\"isSectors ? ['/sectors/show', w?.id] : ['/watchlists/show', w?.id]\"\n  >\n    <ion-label> {{w.name}} </ion-label>\n  </ion-item>\n  <!-- editWatchlist -->\n  <ion-fab slot=\"fixed\" *ngIf=\"isWatchlists\">\n    <ion-fab-button [routerLink]=\"['/watchlists/add']\">\n      <ion-icon name=\"add-circle-outline\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n  <!--// -->\n\n  <!-- TODO: Empty and loading states -->\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_watchlists_index_watchlists-index_module_ts.js.map