import { TranslateService } from '@ngx-translate/core';
import { Component, Input, OnInit } from '@angular/core';
import { Dialogs } from '@inma/helpers/dialogs';
import { Toast } from '@inma/helpers/toast';
import { Translations } from '@inma/helpers/translations';
import { Symbols } from '@inma/models/symbol';
import { Watchlist, Watchlists } from '@inma/models/watchlist';
import { ModalController } from '@ionic/angular';
import { WatchlistTranslations } from 'src/app/pages/watchlists/watchlist.translations';
import { SymbolsSearchDragableModalComponent } from '../symbols-search-dragable-modal/symbols-search-dragable-modal.component';

@Component({
  selector: 'tadawul-view-edit-watclist-dragable-modal',
  templateUrl: './view-edit-watclist-dragable-modal.component.html',
  styleUrls: ['./view-edit-watclist-dragable-modal.component.scss'],
})
export class ViewEditWatclistDragableModalComponent implements OnInit {

  Watchlists = Watchlists;
  watchlist: Watchlist;

  @Input() watchlistData: any;
  showLoader = false;
  watchListSymbols = [];
  watchlistOriginalSymbols =[];
  watchListName: string = '';
  
  
  constructor(private modalControl: ModalController,
    public translate: TranslateService) { }

  ngOnInit() {
    if (this.watchlistData?.id) {
      Watchlists.findByID(this.watchlistData?.id).subscribe(watchlist => {
        this.watchlist = watchlist;
        this.watchlist.symbols.subscribe(symbols => {
          this.watchlistOriginalSymbols= symbols;
          });
        this.watchListName = this.watchlist.name;
      });
      this.subscribeWatchlistSymbols();
    } else {
      this.watchlist = new Watchlist();
    }
  }

  editOrCreate(){
    if(this.watchListName == ''){
      Dialogs.alert(this.translate.instant('watchlist.WATCHLIST_NAME_REQUIRED') as any).subscribe(ok => {
      });   
      return false;
    }
    this.watchlist.name = this.watchListName;
    this.showLoader = true;
    if (this.watchlist?.id) {
      this.watchlist.update().subscribe(() => {
        this.showLoader = false;
        Toast.present(this.translate.instant('watchlist.SAVED_SUCCESSFULLY'), { class: 'info-alert',duration: 2});
        this.modalControl.dismiss(this.watchlist);
      });
    } else {
      this.watchlist.create().subscribe(() => {
        this.showLoader = false;
        Toast.present(this.translate.instant('watchlist.SAVED_SUCCESSFULLY'), { class: 'info-alert',duration: 2});
        this.modalControl.dismiss();
      });
    }
  }

  makeAsDefault(){
    if(this.watchlist.isDefault == true){this.watchlist.isDefault = false}else{this.watchlist.isDefault = true}
  }
getAllSymbols(){
  Symbols.all.subscribe(symbols => {
    this.addRemoveSymbols(symbols);
  });
}
  async addRemoveSymbols(symbols?) {
    this.subscribeWatchlistSymbols();
    const modal = await this.modalControl.create({
      component: SymbolsSearchDragableModalComponent,
      cssClass: 'auto-height-modal ipad-full-width-modal',
      componentProps: {
        title: this.translate.instant('watchlist.SYMBOLS'),
        symbols: symbols,
        watchlistSymbolsList : this.watchListSymbols,
        prevPage:"watchlist",
        watchList: this.watchlist
      },
      swipeToClose: true
    });

    modal.onDidDismiss()
      .then((data) => {
        this.subscribeWatchlistSymbols();
        for(let i =0; i<= symbols.length;i++){
          symbols[i].checked = false;
        }
       // this.watchListSymbols = data.data;
      //  this.watchlist.symbols = data.data;
        //this.sharedData.symbolSearchId.next(this.symbol?.id);
      });

    return await modal.present();
  }


  deleteWatchList(){
    Dialogs.confirm(this.translate.instant('watchlist.DELETE_WATCHLIST_MESSAGE') as any, this.translate.instant('watchlist.DELETE_WATCLIST') as any).subscribe(closemodal => {
      if (closemodal) {
        this.showLoader = true;
        this.watchlist.deleteWatchList(this.watchlist.id).subscribe(() => {
        this.showLoader = false;
        Toast.present(this.translate.instant('watchlist.SAVED_SUCCESSFULLY'), { class: 'info-alert',duration: 2});
        this.modalControl.dismiss();
    });
      }
       else {}
    });   
   
  }

  closeModal(){
    Dialogs.confirm(this.translate.instant('watchlist.CANCEL_CHANGES_MESSAGE') as any, this.translate.instant('watchlist.CANCEL_CHANGES') as any, true).subscribe(closemodal => {
      if (closemodal) {
        for (let i = 0; i < this.watchListSymbols.length; i++) {
          this.watchlist.delete(this.watchListSymbols[i]);
         }
        for (let i = 0; i < this.watchlistOriginalSymbols.length; i++) {
            this.watchlist.addSymbol(this.watchlistOriginalSymbols[i].id);
           }
        this.modalControl.dismiss();  
      }
       else {}
    });   
  }


  subscribeWatchlistSymbols(){
    this.watchlist.symbols.subscribe(symbols => {
      this.watchListSymbols = symbols;
      });
  }
}
