"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_products_product-subscribe-summary_product-subscribe-summary_module_ts"],{

/***/ 49033:
/*!******************************************************************************************************!*\
  !*** ./src/app/pages/products/product-subscribe-summary/product-subscribe-summary-routing.module.ts ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductSubscribeSummaryPageRoutingModule": () => (/* binding */ ProductSubscribeSummaryPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _product_subscribe_summary_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./product-subscribe-summary.page */ 10681);




const routes = [
    {
        path: '',
        component: _product_subscribe_summary_page__WEBPACK_IMPORTED_MODULE_0__.ProductSubscribeSummaryPage
    }
];
let ProductSubscribeSummaryPageRoutingModule = class ProductSubscribeSummaryPageRoutingModule {
};
ProductSubscribeSummaryPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ProductSubscribeSummaryPageRoutingModule);



/***/ }),

/***/ 31667:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/products/product-subscribe-summary/product-subscribe-summary.module.ts ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductSubscribeSummaryPageModule": () => (/* binding */ ProductSubscribeSummaryPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _product_subscribe_summary_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./product-subscribe-summary-routing.module */ 49033);
/* harmony import */ var _product_subscribe_summary_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./product-subscribe-summary.page */ 10681);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);









let ProductSubscribeSummaryPageModule = class ProductSubscribeSummaryPageModule {
};
ProductSubscribeSummaryPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _product_subscribe_summary_routing_module__WEBPACK_IMPORTED_MODULE_0__.ProductSubscribeSummaryPageRoutingModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateModule.forChild()
        ],
        declarations: [_product_subscribe_summary_page__WEBPACK_IMPORTED_MODULE_1__.ProductSubscribeSummaryPage]
    })
], ProductSubscribeSummaryPageModule);



/***/ }),

/***/ 10681:
/*!********************************************************************************************!*\
  !*** ./src/app/pages/products/product-subscribe-summary/product-subscribe-summary.page.ts ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductSubscribeSummaryPage": () => (/* binding */ ProductSubscribeSummaryPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _product_subscribe_summary_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./product-subscribe-summary.page.html?ngResource */ 32774);
/* harmony import */ var _product_subscribe_summary_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./product-subscribe-summary.page.scss?ngResource */ 35597);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var _inma_models_products_product_doings__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/models/products/product-doings */ 50348);







let ProductSubscribeSummaryPage = class ProductSubscribeSummaryPage {
    constructor(navCtrl, sharedData) {
        this.navCtrl = navCtrl;
        this.sharedData = sharedData;
        this.productDoings = _inma_models_products_product_doings__WEBPACK_IMPORTED_MODULE_3__.ProductDoings;
    }
    ngOnInit() {
        // this.sharedProduct = this.sharedData.getSharedData("sharedProduct", false);
        // this.sharedProductMode = this.sharedData.getSharedData("sharedProductMode", false);
        // this.sharedProductSubscriptionResult = this.sharedData.getSharedData("sharedProductSubscriptionResult", false);
    }
    ionViewWillEnter() {
        this.sharedProduct = this.sharedData.getSharedData("sharedProduct", false);
        this.sharedProductMode = this.sharedData.getSharedData("sharedProductMode", false);
        this.sharedProductSubscriptionResult = this.sharedData.getSharedData("sharedProductSubscriptionResult", false);
    }
    backToProducts() {
        this.navCtrl.navigateBack('main/products');
    }
    backToHome() {
        this.navCtrl.navigateRoot('main/tabs');
    }
};
ProductSubscribeSummaryPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController },
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_2__.SharedDataService }
];
ProductSubscribeSummaryPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'tadawul-product-subscribe-summary',
        template: _product_subscribe_summary_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_product_subscribe_summary_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController, src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_2__.SharedDataService])
], ProductSubscribeSummaryPage);



/***/ }),

/***/ 35597:
/*!*********************************************************************************************************!*\
  !*** ./src/app/pages/products/product-subscribe-summary/product-subscribe-summary.page.scss?ngResource ***!
  \*********************************************************************************************************/
/***/ ((module) => {

module.exports = ".summary-title {\n  color: #2ebd85;\n  justify-content: center;\n  flex-direction: column;\n  text-align: center;\n  padding: 32px;\n}\n\n.success-text {\n  font-size: 120%;\n  font-weight: bold;\n}\n\nion-toolbar {\n  --background: #005157;\n  --color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2R1Y3Qtc3Vic2NyaWJlLXN1bW1hcnkucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtFQUVBLHVCQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7QUFBSjs7QUFHQTtFQUNJLGVBQUE7RUFDQSxpQkFBQTtBQUFKOztBQUdBO0VBQ0kscUJBQUE7RUFDQSxjQUFBO0FBQUoiLCJmaWxlIjoicHJvZHVjdC1zdWJzY3JpYmUtc3VtbWFyeS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc3VtbWFyeS10aXRsZSB7XG4gICAgY29sb3I6ICMyZWJkODU7XG4gICAvLyBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIHBhZGRpbmc6IDMycHg7XG59XG5cbi5zdWNjZXNzLXRleHQge1xuICAgIGZvbnQtc2l6ZTogMTIwJTtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbn1cblxuaW9uLXRvb2xiYXIge1xuICAgIC0tYmFja2dyb3VuZDogIzAwNTE1NztcbiAgICAtLWNvbG9yOiB3aGl0ZTtcbiAgfSJdfQ== */";

/***/ }),

/***/ 32774:
/*!*********************************************************************************************************!*\
  !*** ./src/app/pages/products/product-subscribe-summary/product-subscribe-summary.page.html?ngResource ***!
  \*********************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n    <ion-toolbar color=\"\">\n      <ion-buttons slot=\"start\">\n        <ion-back-button text=\"\"></ion-back-button>\n      </ion-buttons>\n      <ion-title slot=\"start\">{{sharedProduct?.name}}</ion-title>\n    </ion-toolbar>\n  </ion-header>\n\n  <ion-content>\n      <div class=\"summary-title\">\n        <img src=\"assets/icon/success.svg\" class=\"success-img\">\n        <div class=\"success-text\">\n          {{((sharedProductMode === productDoings.Subscribe) ? 'product.SUBSCRIPTION_SUCCESS_MESSAGE' : '' )| translate}}\n          {{((sharedProductMode === productDoings.Extend) ? 'product.SUBSCRIPTION_EXTENSION_SUCCESS_MESSAGE' : '')| translate}}\n          {{((sharedProductMode === productDoings.Unsubscribe) ? 'product.UNSUBSCRIPTION_SUCCESS_MESSAGE' : '')| translate}}\n        </div>\n      </div>\n    \n      <div class=\"ion-padding\">\n        <ion-text class=\"bold\" color=\"primary\">{{'product.REQUEST_SUMMARY' | translate}}</ion-text>\n        <div class=\"box-with-bg bordered ion-margin-bottom\">\n          <ion-row class=\"data-row\">\n            <ion-col size=\"6\">\n              <ion-text class=\"label font-size-caption\" color=\"primary\">{{'product.PRODUCT_NAME' | translate}}</ion-text>\n            </ion-col>\n            <ion-col size=\"6\">\n              <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n                {{sharedProduct?.name}}\n              </ion-text>\n            </ion-col>\n          </ion-row>\n          <ion-row class=\"data-row\">\n            <ion-col size=\"6\">\n              <ion-text class=\"label font-size-caption\" color=\"primary\">{{'product.OPERATION' | translate}}</ion-text>\n            </ion-col>\n            <ion-col size=\"6\">\n              <ion-text *ngIf=\"sharedProductMode === productDoings.Subscribe\" class=\"value font-size-caption bold\" color=\"primary\">\n                {{'product.SUBSCRIBE' | translate}}\n              </ion-text>\n              <ion-text *ngIf=\"sharedProductMode === productDoings.Extend\" class=\"value font-size-caption bold\" color=\"primary\">\n                {{'product.EXTEND_SUBSCRIPTION' | translate}}\n              </ion-text>\n              <ion-text *ngIf=\"sharedProductMode === productDoings.Unsubscribe\" class=\"value font-size-caption bold\" color=\"primary\">\n                {{'product.CANCEL_SUBSCRIPTION' | translate}}\n              </ion-text>\n            </ion-col>\n          </ion-row>\n          <ion-row class=\"data-row\" *ngIf=\"sharedProduct?.selectedPlan?.months\">\n            <ion-col size=\"6\">\n              <ion-text class=\"label font-size-caption\" color=\"primary\">{{'product.DURATION' | translate}}</ion-text>\n            </ion-col>\n            <ion-col size=\"6\">\n              <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n                {{sharedProduct?.selectedPlan?.months}} {{((sharedProduct?.selectedPlan?.months == 1) ? 'product.MONTH' : 'product.MONTHS')  | translate}}\n              </ion-text>\n            </ion-col>\n          </ion-row>\n          <ion-row class=\"data-row\" *ngIf=\"sharedProductSubscriptionResult?.debited?.amount\">\n            <ion-col size=\"6\">\n              <ion-text class=\"label font-size-caption\" color=\"primary\">{{'product.DISCOUNTED_PRICE' | translate}}</ion-text>\n            </ion-col>\n            <ion-col size=\"6\">\n              <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n                {{sharedProductSubscriptionResult?.debited?.amount}}\n              </ion-text>\n            </ion-col>\n          </ion-row>\n          <ion-row class=\"data-row\" *ngIf=\"sharedProductSubscriptionResult?.tax?.percent\">\n            <ion-col size=\"6\">\n              <ion-text class=\"label font-size-caption\" color=\"primary\">{{'product.VAT' | translate}}</ion-text>\n            </ion-col>\n            <ion-col size=\"6\">\n              <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n                {{sharedProductSubscriptionResult?.tax?.percent}} %\n              </ion-text>\n            </ion-col>\n          </ion-row>\n          <ion-row class=\"data-row\" *ngIf=\"sharedProductSubscriptionResult?.tax?.invoiceNumber\">\n            <ion-col size=\"6\">\n              <ion-text class=\"label font-size-caption\" color=\"primary\">{{'product.VAT_NUMBER' | translate}}</ion-text>\n            </ion-col>\n            <ion-col size=\"6\">\n              <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n                {{sharedProductSubscriptionResult?.tax?.invoiceNumber}}\n              </ion-text>\n            </ion-col>\n          </ion-row>\n          <ion-row class=\"data-row\">\n            <ion-col size=\"6\">\n              <ion-text class=\"label font-size-caption\" color=\"primary\">{{'product.DATE' | translate}}</ion-text>\n            </ion-col>\n            <ion-col size=\"6\">\n              <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n                  0\n              </ion-text>\n            </ion-col>\n          </ion-row>\n        </div>\n        <app-button\n        (clickAction)=\"backToProducts()\"\n        expand=\"block\" \n        size=\"\"\n        color=\"success\"\n        fill=\"solid\"\n        type=\"button\"\n        >\n          {{'product.BACK_TO_PRODUCTS' | translate}}\n        </app-button>\n        \n        <app-button\n        (clickAction)=\"backToHome()\"\n        expand=\"block\" \n        size=\"\"\n        color=\"primary\"\n        fill=\"outline\"\n        type=\"button\"\n        >\n          {{'product.BACK_TO_HOME' | translate}}\n        </app-button>\n      </div>\n    </ion-content>\n    \n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_products_product-subscribe-summary_product-subscribe-summary_module_ts.js.map