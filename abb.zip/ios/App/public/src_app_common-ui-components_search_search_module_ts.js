"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_common-ui-components_search_search_module_ts"],{

/***/ 90474:
/*!**********************************************************************!*\
  !*** ./src/app/common-ui-components/search/search-routing.module.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchPageRoutingModule": () => (/* binding */ SearchPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _search_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./search.page */ 5535);




const routes = [
    {
        path: '',
        component: _search_page__WEBPACK_IMPORTED_MODULE_0__.SearchPage
    }
];
let SearchPageRoutingModule = class SearchPageRoutingModule {
};
SearchPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SearchPageRoutingModule);



/***/ }),

/***/ 77477:
/*!**************************************************************!*\
  !*** ./src/app/common-ui-components/search/search.module.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchPageModule": () => (/* binding */ SearchPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _search_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./search-routing.module */ 90474);
/* harmony import */ var _search_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./search.page */ 5535);







let SearchPageModule = class SearchPageModule {
};
SearchPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _search_routing_module__WEBPACK_IMPORTED_MODULE_0__.SearchPageRoutingModule
        ],
        declarations: [_search_page__WEBPACK_IMPORTED_MODULE_1__.SearchPage]
    })
], SearchPageModule);



/***/ }),

/***/ 5535:
/*!************************************************************!*\
  !*** ./src/app/common-ui-components/search/search.page.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchPage": () => (/* binding */ SearchPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _search_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./search.page.html?ngResource */ 47494);
/* harmony import */ var _search_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./search.page.scss?ngResource */ 49802);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _inma_helpers_translations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/helpers/translations */ 69353);
/* harmony import */ var _search_translations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./search.translations */ 34238);
/* harmony import */ var _inma_helpers_strings__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/helpers/strings */ 36782);
/* harmony import */ var _inma_models_symbol__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @inma/models/symbol */ 61202);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 64139);










let SearchPage = class SearchPage {
    constructor(navCtrl, modalCtrl) {
        this.navCtrl = navCtrl;
        this.modalCtrl = modalCtrl;
        this.t = _search_translations__WEBPACK_IMPORTED_MODULE_3__.SearchTranslations;
        this.allSearchables = [];
        this.searchables = [];
    }
    ngOnInit() {
        _inma_models_symbol__WEBPACK_IMPORTED_MODULE_5__.Symbols.all.subscribe(symbols => {
            let s = this.symbols || symbols;
            this.allSearchables = s;
            this.searchables = this.allSearchables;
        });
    }
    filter() {
        console.log(this.queryText);
        _inma_models_symbol__WEBPACK_IMPORTED_MODULE_5__.Symbols.filter(this.queryText, (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.of)(this.allSearchables)).subscribe(symbols => {
            this.searchables = symbols;
        });
    }
    filter2() {
        console.log(this.queryText);
        let filteredSearchables = [];
        this.queryText = (this.queryText || '').trimStart();
        if (this.queryText != '') {
            this.queryText = _inma_helpers_strings__WEBPACK_IMPORTED_MODULE_4__.Strings.normalizeArabicNumbers(this.queryText.toLowerCase());
            const digitsRegex = /\d+/m;
            // Do extraction of the query text
            let queryNumbers = this.queryText.match(digitsRegex);
            let queryNumber = queryNumbers && queryNumbers.length > 0 ? queryNumbers[0].trim() : null;
            let queryWords = this.queryText.replace(digitsRegex, '').trim().toLowerCase();
            let secondFilteredSearchables = [];
            this.allSearchables.forEach((searchable) => {
                var _a;
                var matchValue = (_a = searchable === null || searchable === void 0 ? void 0 : searchable.toString()) === null || _a === void 0 ? void 0 : _a.toLocaleLowerCase();
                if (!matchValue)
                    return;
                let numberIndex = null, wordsIndex = null;
                if (queryNumber)
                    numberIndex = matchValue.indexOf(queryNumber);
                if (queryWords)
                    wordsIndex = matchValue.indexOf(queryWords);
                if (numberIndex != null && numberIndex != -1) {
                    if (wordsIndex == null || (wordsIndex != null && wordsIndex != -1)) {
                        if (numberIndex == 0)
                            filteredSearchables.push(searchable);
                        else
                            secondFilteredSearchables.push(searchable);
                    }
                }
                else if (numberIndex == null && wordsIndex && wordsIndex != -1) {
                    filteredSearchables.push(searchable);
                }
            });
            filteredSearchables.push(...secondFilteredSearchables);
        }
        else
            filteredSearchables = this.allSearchables;
        this.searchables = filteredSearchables;
    }
    select(searchable) {
        this.closeModal(searchable);
    }
    dismiss() {
        this.modalCtrl.dismiss();
    }
    closeModal(selectedSearchable) {
        this.modalCtrl.dismiss(selectedSearchable);
    }
};
SearchPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController }
];
SearchPage.propDecorators = {
    title: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input }],
    symbols: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input }],
    color: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input }]
};
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_inma_helpers_translations__WEBPACK_IMPORTED_MODULE_2__.Translations)(),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", Object)
], SearchPage.prototype, "t", void 0);
SearchPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'tadawul-search',
        template: _search_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_search_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController])
], SearchPage);



/***/ }),

/***/ 34238:
/*!********************************************************************!*\
  !*** ./src/app/common-ui-components/search/search.translations.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchTranslations": () => (/* binding */ SearchTranslations)
/* harmony export */ });
class Translations {
    constructor() {
        this.CLOSE = ['إغلاق', 'Close'];
        this.PAGE_TITLE = ['بحث', 'Search'];
    }
}
const SearchTranslations = new Translations();


/***/ }),

/***/ 49802:
/*!*************************************************************************!*\
  !*** ./src/app/common-ui-components/search/search.page.scss?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "ion-toolbar {\n  --color: white;\n  --background: #005157;\n}\nion-toolbar ion-searchbar {\n  --color: #65979a;\n  --icon-color: #65979a;\n  --background: #e6eff0;\n  --border-radius: 0;\n}\nbody.dark :host ion-toolbar ion-searchbar {\n  --color: white;\n  --icon-color: white;\n  border: 1px solid white;\n  height: 36px;\n  padding-top: 10px;\n}\nion-toolbar #close-button {\n  --color: #e6eff0;\n  font-size: 100%;\n}\n.searchbar-input {\n  border: 1px solid white;\n}\n.symbol-id {\n  font-weight: normal;\n  border: 1px solid #e6eff0;\n  padding: 0 2px;\n  width: 36px;\n  font-weight: bold;\n  text-align: center;\n}\n:host ion-item {\n  --color: #005457;\n  font-size: 12px;\n  --border-color: transparent;\n}\nbody.dark :host ion-item {\n  --color: #a5a5a5;\n}\n.search-name {\n  -webkit-margin-start: 8px;\n          margin-inline-start: 8px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlYXJjaC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFBO0VBQ0EscUJBQUE7QUFDSjtBQUNJO0VBQ0ksZ0JBQUE7RUFDQSxxQkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7QUFDUjtBQUFRO0VBQ0ksY0FBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7QUFFWjtBQUVJO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0FBQVI7QUFHQTtFQUNJLHVCQUFBO0FBQUo7QUFJQTtFQUNJLG1CQUFBO0VBQ0EseUJBQUE7RUFDQSxjQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUFESjtBQUtJO0VBQ0ksZ0JBQUE7RUFNQSxlQUFBO0VBQ0EsMkJBQUE7QUFQUjtBQUVRO0VBQ0ksZ0JBQUE7QUFBWjtBQVFBO0VBQ0kseUJBQUE7VUFBQSx3QkFBQTtBQUxKIiwiZmlsZSI6InNlYXJjaC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhciB7XG4gICAgLS1jb2xvcjogd2hpdGU7XG4gICAgLS1iYWNrZ3JvdW5kOiAjMDA1MTU3O1xuXG4gICAgaW9uLXNlYXJjaGJhciB7XG4gICAgICAgIC0tY29sb3I6ICM2NTk3OWE7XG4gICAgICAgIC0taWNvbi1jb2xvcjogIzY1OTc5YTtcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjZTZlZmYwO1xuICAgICAgICAtLWJvcmRlci1yYWRpdXM6IDA7XG4gICAgICAgIGJvZHkuZGFyayA6aG9zdCAmIHtcbiAgICAgICAgICAgIC0tY29sb3I6IHdoaXRlO1xuICAgICAgICAgICAgLS1pY29uLWNvbG9yOiB3aGl0ZTtcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHdoaXRlO1xuICAgICAgICAgICAgaGVpZ2h0OiAzNnB4O1xuICAgICAgICAgICAgcGFkZGluZy10b3A6IDEwcHg7XG4gICAgICAgICAgfVxuICAgIH1cblxuICAgICNjbG9zZS1idXR0b24ge1xuICAgICAgICAtLWNvbG9yOiAjZTZlZmYwO1xuICAgICAgICBmb250LXNpemU6IDEwMCU7XG4gICAgfVxufVxuLnNlYXJjaGJhci1pbnB1dHtcbiAgICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcbn1cblxuXG4uc3ltYm9sLWlkIHtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICNlNmVmZjA7XG4gICAgcGFkZGluZzogMCAycHg7XG4gICAgd2lkdGg6IDM2cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG46aG9zdCB7XG4gICAgaW9uLWl0ZW0ge1xuICAgICAgICAtLWNvbG9yOiAjMDA1NDU3O1xuXG4gICAgICAgIGJvZHkuZGFyayAmIHtcbiAgICAgICAgICAgIC0tY29sb3I6ICNhNWE1YTU7XG4gICAgICAgIH1cblxuICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICAgIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgICB9XG59XG5cbi5zZWFyY2gtbmFtZSB7XG4gICAgbWFyZ2luLWlubGluZS1zdGFydDogOHB4O1xufSJdfQ== */";

/***/ }),

/***/ 47494:
/*!*************************************************************************!*\
  !*** ./src/app/common-ui-components/search/search.page.html?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "<!-- <ion-header>\n  <ion-toolbar>\n    <ion-title>search</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n</ion-content> -->\n\n\n<ion-header>\n  <ion-toolbar [style.--background]=\"color\">\n    <ion-grid>\n      <ion-row>\n        <ion-col>\n          <ion-title>{{ title || t.PAGE_TITLE }}</ion-title>\n          <ion-buttons end>\n            <!-- <button ion-button class=\"close\" (click)=\"dismiss()\">{{ t.CLOSE }}</button> -->\n            <ion-button (click)=\"dismiss()\" id='close-button'>{{ t.CLOSE }}</ion-button>\n          </ion-buttons>\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col>\n        <ion-searchbar [(ngModel)]=\"queryText\" (ngModelChange)=\"filter()\" [placeholder]=\" t.PAGE_TITLE \">\n        </ion-searchbar>\n      </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n\n  <ion-list>\n    <ion-item (click)=\"select(searchable)\" *ngFor=\"let searchable of searchables\">\n      <span class=\"symbol-id\"> {{ searchable?.id }} </span>\n      <span class=\"search-name\">\n        {{ searchable?.name | async }}\n      </span>\n    </ion-item>\n  </ion-list>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_common-ui-components_search_search_module_ts.js.map