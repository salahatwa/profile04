// import { AppTranslations } from 'src/app/app.translations';
import { AppTranslations } from '../../app.translations';

class Translations extends AppTranslations {
    PLEASE_ENTER_A_VALID = ["الرجاء إدخال", "Please enter a valid"];

}


export const InputTranslations = new Translations();