"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_symbol_symbol_module_ts"],{

/***/ 28138:
/*!*******************************************************!*\
  !*** ./src/app/pages/symbol/symbol-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SymbolPageRoutingModule": () => (/* binding */ SymbolPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _symbol_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./symbol.page */ 30694);




const routes = [
    {
        path: '',
        component: _symbol_page__WEBPACK_IMPORTED_MODULE_0__.SymbolPage
    }
];
let SymbolPageRoutingModule = class SymbolPageRoutingModule {
};
SymbolPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SymbolPageRoutingModule);



/***/ }),

/***/ 85730:
/*!***********************************************!*\
  !*** ./src/app/pages/symbol/symbol.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SymbolPageModule": () => (/* binding */ SymbolPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _symbol_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./symbol-routing.module */ 28138);
/* harmony import */ var _symbol_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./symbol.page */ 30694);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);
/* harmony import */ var src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/pipes/pipes.module */ 41041);










let SymbolPageModule = class SymbolPageModule {
};
SymbolPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _symbol_routing_module__WEBPACK_IMPORTED_MODULE_0__.SymbolPageRoutingModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateModule.forChild(),
            src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_3__.PipesModule
        ],
        declarations: [
            _symbol_page__WEBPACK_IMPORTED_MODULE_1__.SymbolPage
        ]
    })
], SymbolPageModule);



/***/ }),

/***/ 30694:
/*!*********************************************!*\
  !*** ./src/app/pages/symbol/symbol.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SymbolPage": () => (/* binding */ SymbolPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _symbol_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./symbol.page.html?ngResource */ 61675);
/* harmony import */ var _symbol_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./symbol.page.scss?ngResource */ 43567);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_models_symbol__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/models/symbol */ 61202);
/* harmony import */ var _symbol_symbol_translations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../symbol/symbol.translations */ 7425);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_pages_order_order_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/pages/order/order.page */ 28798);
/* harmony import */ var fitty__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! fitty */ 5986);
/* harmony import */ var _tradestation_tradestation_translations__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../tradestation/tradestation.translations */ 87411);
/* harmony import */ var apexcharts__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! apexcharts */ 79604);
/* harmony import */ var apexcharts__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(apexcharts__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var src_app_enum_skeleton_type_enum__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/enum/skeleton-type.enum */ 88617);














const mergedT = Object.assign(Object.assign({}, _tradestation_tradestation_translations__WEBPACK_IMPORTED_MODULE_7__.TradestationTranslations), _symbol_symbol_translations__WEBPACK_IMPORTED_MODULE_3__.SymbolTranslations);
let SymbolPage = class SymbolPage {
    constructor(sharedData, translate, navCtrl, modalController) {
        this.sharedData = sharedData;
        this.translate = translate;
        this.navCtrl = navCtrl;
        this.modalController = modalController;
        this.pricesArr = [];
        this.timeArr = [];
        this.graphLoader = false;
        this.portfolioLoader = false;
        this.portfolioIndex = 0;
        this.SkeletonType = src_app_enum_skeleton_type_enum__WEBPACK_IMPORTED_MODULE_9__.SkeletonType;
        this.oredrsTradesSlidesType = 'orders';
        this.slideOptions = {
            slidesPerView: 1.1,
            centeredSlides: true,
            spaceBetween: 10,
            effect: 'flip'
        };
        this.data = [];
        this.headerListMenu = [];
        this.tradesHeaderListMenu = [];
        this.Number = Number;
    }
    ngOnInit() {
        var _a;
        this.sharedSymbol = this.sharedData.getSharedData("sharedSymbol", false);
        this.symbol = (_a = this.sharedData.getSharedData("sharedSymbol", false)) === null || _a === void 0 ? void 0 : _a.symbol;
        if (!this.symbol) {
            this.navCtrl.navigateRoot('main/tabs');
        }
        this.symbol.parameters.subscribe(parameters => {
            console.log(parameters);
        });
        this.symbol.asks.subscribe(asks => {
            console.log(asks);
            this.asks = asks;
        });
        this.symbol.bids.subscribe(bids => {
            console.log(bids);
            this.bids = bids;
        });
        this.symbol.trades.subscribe(trades => {
            console.log(trades);
            this.trades = trades;
        });
        this.headerListMenu = [{ title: this.translate.instant('symbolPage.NUMBER'), size: '1.75' }, { title: this.translate.instant('symbolPage.ASK_QUANTITY'), size: '2.5' }, { title: this.translate.instant('symbolPage.ASK_PRICE'), size: '1.75' }, { title: this.translate.instant('symbolPage.BIDDING_PRICE'), size: '1.75' }, { title: this.translate.instant('symbolPage.BIDDING_QUANTITY'), size: '2.5' }, { title: this.translate.instant('symbolPage.NUMBER'), size: '1.75' }];
        this.tradesHeaderListMenu = [this.translate.instant('symbolPage.TRADE_TIME'), this.translate.instant('symbolPage.PRICE'), this.translate.instant('symbolPage.QUANTITY'), this.translate.instant('symbolPage.CHANGE'), this.translate.instant('symbolPage.TYPE'), this.translate.instant('symbolPage.SPLITS')];
        setTimeout(() => {
            (0,fitty__WEBPACK_IMPORTED_MODULE_6__["default"])('#symbolDetailText .label', {
                minSize: 11,
                maxSize: 15,
                multiLine: false
            });
            (0,fitty__WEBPACK_IMPORTED_MODULE_6__["default"])('#symbol-header-box-container .font-size-caption', {
                minSize: 11,
                maxSize: 15,
                multiLine: false
            });
        }, 1500);
        this.priceChangeInPeriod('day');
        this.loadSymbolDataInAllPortfolios();
    }
    priceChangeInPeriod(period) {
        if (this.period == period) {
            return false;
        }
        ;
        var chartHTML = document.getElementById('chart-spark');
        chartHTML.innerHTML = '';
        this.graphLoader = true;
        this.pricesArr = [];
        this.timeArr = [];
        this.period = period;
        _inma_models_symbol__WEBPACK_IMPORTED_MODULE_2__.Symbols.priceChangeInPeriod(this.symbol.id, period).subscribe(data => {
            this.data = data;
            for (let i = 0; i <= data.length - 1; i++) {
                this.pricesArr.push(this.data[i].price);
                this.timeArr.push(this.data[i].lastTradeddTime);
            }
            setTimeout(() => {
                this.loadChart();
            }, 300);
        });
    }
    loadSymbolDataInAllPortfolios() {
        this.portfolioLoader = true;
        _inma_models_symbol__WEBPACK_IMPORTED_MODULE_2__.Symbols.loadSymbolDataInAllPortfolios(this.symbol.id).subscribe(data => {
            this.symbolDataInportfolios = data;
            this.portfolioLoader = false;
            this.portfolioIndex = 0;
        });
    }
    slideChanged() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            this.portfolioIndex = yield this.portfolioSlides.getActiveIndex();
        });
    }
    openBuySellSymbols(symbol, operation) {
        this.sharedData.setSharedData(symbol, 'sharedSymbol');
        this.sharedData.setSharedData(operation, 'operation');
        if (operation == "sell") {
            this.sharedData.setSharedData(this.symbolDataInportfolios.symbolPortfoliosInfo[this.portfolioIndex].portfolioNumber, 'porfolioID');
        }
        this.openModal(symbol, operation);
        // OrderPage.initialize();
    }
    openModal(symbol, operation) {
        var _a, _b;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: src_app_pages_order_order_page__WEBPACK_IMPORTED_MODULE_5__.OrderPage,
                cssClass: 'buy-sell',
                componentProps: {
                    sharedSymbol: this.symbol,
                    sharedPortfolio: (_b = (_a = this.symbolDataInportfolios) === null || _a === void 0 ? void 0 : _a.symbolPortfoliosInfo[this.portfolioIndex]) === null || _b === void 0 ? void 0 : _b.portfolioNumber,
                    operation: operation,
                    previousPage: "symbol"
                },
                swipeToClose: true
            });
            return yield modal.present();
        });
    }
    positiveChecker(n) {
        return parseFloat(n) > 0;
    }
    zeroChecker(n) {
        return parseFloat(n) == 0;
    }
    back() {
        this.navCtrl.back();
    }
    loadChart() {
        let seriesName = this.translate.instant('tradestion.PRICE');
        var options = {
            series: [
                {
                    name: seriesName,
                    data: this.pricesArr
                }
            ],
            chart: {
                type: 'area',
                height: 200,
                width: "100%",
                zoom: {
                    enabled: false
                },
                toolbar: {
                    show: false
                }
            },
            dataLabels: {
                enabled: false
            },
            stroke: {
                curve: 'smooth',
                width: 1.5,
                colors: ['#7aabde'],
            },
            fill: {
                gradientToColors: ['#000000'],
                opacityFrom: 0.4,
                opacityTo: 0,
            },
            xaxis: {
                categories: this.timeArr,
                labels: {
                    show: false
                }
            },
            yaxis: {
                labels: {
                    offsetX: -10,
                    style: {
                        colors: ['#65979a'],
                        fontSize: '10px',
                        fontFamily: 'AlinmaTheSans',
                        fontWeight: 900,
                        cssClass: 'apexcharts-yaxis-label',
                    },
                },
            },
            grid: {
                padding: {
                    left: 0,
                    right: 0
                },
                borderColor: '#e6eff0',
                strokeDashArray: 5,
            },
        };
        this.graphLoader = false;
        var chart = new apexcharts__WEBPACK_IMPORTED_MODULE_8__(document.querySelector("#chart-spark"), options);
        chart.render();
        // var optionsSpark = {
        //   series: [
        //     {
        //       data: this.pricesArr
        //     }
        //   ],
        //   chart: {
        //     height: 350,
        //     type: "area",
        //     zoom: {
        //       enabled: false
        //     }
        //   },
        //   dataLabels: {
        //     enabled: false
        //   },
        //   stroke: {
        //     curve: "straight"
        //   },
        //   grid: {
        //     row: {
        //       colors: ["#f3f3f3", "transparent"], // takes an array which will be repeated on columns
        //       opacity: 0.5
        //     }
        //   },
        //   xaxis: {
        //     categories: this.timeArr
        //   }
        // };
        // var chartSpark = new ApexCharts(document.querySelector("#chart-spark"), optionsSpark);
        // chartSpark.render();
    }
    SlidesChanged() {
        this.oredrsTradesSlides.getActiveIndex().then((idx) => {
            if (idx == 0) {
                this.oredrsTradesSlidesType = 'orders';
            }
            else {
                this.oredrsTradesSlidesType = 'trades';
            }
        });
    }
    SegmentChanged() {
        if (this.oredrsTradesSlidesType == 'orders') {
            this.oredrsTradesSlides.slideTo(0);
        }
        else {
            this.oredrsTradesSlides.slideTo(1);
        }
    }
};
SymbolPage.ctorParameters = () => [
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_4__.SharedDataService },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__.TranslateService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.ModalController }
];
SymbolPage.propDecorators = {
    portfolioSlides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_13__.ViewChild, args: ['portfolioSlides',] }],
    oredrsTradesSlides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_13__.ViewChild, args: ['oredrsTradesSlides',] }]
};
SymbolPage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.Component)({
        selector: 'app-symbol',
        template: _symbol_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_symbol_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__metadata)("design:paramtypes", [src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_4__.SharedDataService,
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__.TranslateService,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.NavController,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.ModalController])
], SymbolPage);



/***/ }),

/***/ 7425:
/*!*****************************************************!*\
  !*** ./src/app/pages/symbol/symbol.translations.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SymbolTranslations": () => (/* binding */ SymbolTranslations)
/* harmony export */ });
/* harmony import */ var src_app_app_translations__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/app.translations */ 32801);

class Translations extends src_app_app_translations__WEBPACK_IMPORTED_MODULE_0__.AppTranslations {
    constructor() {
        super(...arguments);
        this.LATEST_PRICE = ['آخر سعر', 'Market Price'];
        this.OPENING_PRICE = ['سعر الافتتاح', 'Opening Price'];
        this.CLOSING = ['الإغلاق السابق', 'Closing'];
        this.OWNED_AMOUNT = ['الكمية المملوكة', 'Owned Quantity'];
        this.SHARES = ['سهم', 'Shares'];
        this.GAIN_LOSE = ['ربح/خسارة', 'Gain/Lose'];
        this.BUY = ['شراء', 'Buy'];
        this.SELL = ['بيع', 'Sell'];
        this.AVERAGE_BUY = ['متوسط الشراء', 'Average Cost'];
        this.TOTAL_COST = ['إجمالى التكلفة', 'Total Cost'];
        this.MARKET_PRICE = ['القيمة السوقية', 'Market Price'];
        this.ASK_PRICE = ['سعر الطلب', 'Ask Price'];
        this.BIDDING_PRICE = ['سعر العرض', 'Bid Price'];
        this.MAXIMUM = ['أعلي سعر', 'Max Price'];
        this.ASK_QUANTITY = ['كمية الطلب', 'Ask Quantity'];
        this.BIDDING_QUANTITY = ['كمية العرض', 'Bid Quantity'];
        this.MINIMUM = ['أقل سعر', 'Min Price'];
        this.TRADING_VOLUME = ['حجم التداول', 'Trading Volume'];
        this.TRADING_VALUE = ['قيمة التداول', 'Trading Value'];
        this.LIQUIDITY_PERCENTAGE = ['نسبة السيولة', 'Liquidity Percentage'];
        this.LIQUIDITY = ['السيولة', 'Liquidity'];
        this.PRICES_CURRENCY_IS_SAUDI_RIYAL = ['عملة الأسعار هي الريال السعودي', 'Prices currency is Saudi Riyal'];
        this.NUMBER = ['عدد', 'Number'];
        this.ORDERS_ACCORDING_TO_PRICE = ['الأوامر حسب السعر', 'Orders according to price'];
        this.COMPANY_TRADES = ['صفقات الشركة', 'Company Trades'];
        this.TRADE_TIME = ['الوقت', 'Time'];
        this.PRICE = ['السعر', 'Price'];
        this.QUANTITY = ['الكمية', 'Quantity'];
        this.CHANGE = ['التغيّر', 'Change'];
        this.TYPE = ['النوع', 'Type'];
        this.SPLITS = ['عدد', 'Splits'];
        this.PORTFOLIOS = ['المحافظ', 'Portfolios'];
        //PERIODS
        this.DAY = ['يوم', 'Day'];
        this.WEEK = ['أسبوع', 'Week'];
        this.MONTH = ['شهر', 'Month'];
        this.SIX_MONTHS = ['٦ أشهر', '6 Months'];
        //New portfolio widget
        this.ALL_OWEND_QUANTITY = ['إجمالي الكمية المملوكة', 'Total Owend Quantity'];
        this.ALL_PROFIT_LOSS = ['إجمالي الربح والخسارة', 'Total Gain/Lose'];
    }
}
const SymbolTranslations = new Translations();


/***/ }),

/***/ 87411:
/*!*****************************************************************!*\
  !*** ./src/app/pages/tradestation/tradestation.translations.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TradestationTranslations": () => (/* binding */ TradestationTranslations)
/* harmony export */ });
/* harmony import */ var src_app_app_translations__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/app.translations */ 32801);

class Translations extends src_app_app_translations__WEBPACK_IMPORTED_MODULE_0__.AppTranslations {
    constructor() {
        super(...arguments);
        this.PAGE_TITLE = ['السوق', 'Tradestation'];
        this.WATCHLISTS = [
            `القوائم
		المفضلة`,
            'Watchlists'
        ];
        this.SECTORS = [
            `مؤشر
		القطاعات`, 'Sectors'
        ];
        this.LAST_PRICE = ['آخر سعر', 'Latest price'];
        this.OPENNING = ['الافتتاح', 'Openning'];
        this.MIN_LIMIT = ['أقل سعر', 'Min Price'];
        this.MAX_LIMIT = ['أعلي سعر', 'Max Price'];
        this.CLOSING = ['الإغلاق السابق', 'Closing'];
        this.VOLUME = ['حجم التداول', 'Trading Volume'];
        this.VALUE_OF_TRADING = ['قيمة التداول', 'Value Of Trading'];
        this.LAST_TRADE = ['آخر صفقة', 'Last Trade'];
        this.LAST_QUANTITY = ['آخر كمية', 'Last Quantity'];
        this.CHANGE = ['التغيّر', 'Change'];
        this.CHANGE_PERCENTAGE = ['التغيير ٪', 'Change %'];
        this.TRADES = ['صفقات الشركة', 'Trades'];
        this.ANNUAL_MAX = ['الأعلى سنوياً', 'Annual Max'];
        this.ANNUAL_MIN = ['الأدنى سنوياً', 'Annual Min'];
        this.LIQUIDITY = ['السيولة', 'Liquidity'];
        this.LIQUIDITY_PERCENTAGE = ['نسبة السيولة', 'Liquidity Percentage'];
        this.LIQUIDITY_FLOW = ['تدفق', 'Flow'];
        this.LIQUIDITY_NET = ['صافي', 'Net'];
        this.LIQUIDITY_IN = ['السيولة الداخلة', 'Liquidity In'];
        this.LIQUIDITY_VOLUME = ['حجم', 'Volume'];
        this.LIQUIDITY_VALUE = ['قيمة', 'Value'];
        this.LIQUIDITY_OUT = ['السيولة الخارجة', 'Liquidity Out'];
        this.LIQUIDITY_LAST_QUANTITY = ['آخر كمية', 'Last Quantity'];
        this.LIQUIDITY_CHANGE = ['التغيّر', 'Change'];
        this.TRADE_TIME = ['الوقت', 'Time'];
        this.QUANTITY = ['الكمية', 'Quantity'];
        this.PRICE = ['السعر', 'Price'];
        this.SPLITS = ['الانقسامات', 'Splits'];
        this.TYPE = ['النوع', 'Type'];
        this.BIDS_AND_ASKS = ['عمق السوق حسب السعر', 'Market depth by price'];
        this.ASKS = ['الطلبات', 'Asks'];
        this.BIDS = ['العروض', 'Bids'];
        this.ASK_QUANTITY = ['الكمية', 'Quantity'];
        this.BIDDING_QUANTITY = ['الكمية', 'Quantity'];
        this.ASK_PRICE = ['السعر', 'Price'];
        this.BIDDING_PRICE = ['السعر', 'Price'];
        this.BUY = ['شراء', 'Buy'];
        this.SELL = ['بيع', 'Sell'];
        this.B = ['شراء', 'Buy'];
        this.S = ['بيع', 'Sell'];
        this.All = ['كل الشركات', 'All'];
        this.myShares = ['أسهمي', 'My Shares'];
        this.topTen = ['أكثر 10 إرتفاعا', 'Top 10'];
        this.downTen = ['أكثر 10 إنخفاض', 'Down 10'];
        this.priceChange = ['السعر / التغير', 'Price / Change'];
        this.symabolsSearch = ['بحث الشركات', 'Symbols Search'];
    }
}
const TradestationTranslations = new Translations();


/***/ }),

/***/ 43567:
/*!**********************************************************!*\
  !*** ./src/app/pages/symbol/symbol.page.scss?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = "ion-content {\n  --background: #F4F8F8;\n}\nion-content .item-value {\n  font-size: 13px;\n}\nion-content .symbol-head-section {\n  background: #F4F8F8;\n  color: #65979A;\n  border-bottom: 1px solid #E6EFF0;\n  padding: 16px;\n  font-size: 11px;\n}\nion-content .symbol-head-section .item-value {\n  font-size: 16px;\n}\nion-content .symbol-main-info {\n  margin-top: 0;\n  border-top: 0;\n  padding-bottom: 16px;\n}\nion-content .symbol-main-info .symbol-graph {\n  position: relative;\n  width: 100%;\n}\nion-content .symbol-main-info .symbol-graph .apexcharts-area {\n  stroke: #7aabde;\n}\nion-content .symbol-main-info .period-buttons {\n  display: flex;\n  flex-direction: row;\n  justify-content: center;\n  position: relative;\n  top: -10px;\n}\nion-content .symbol-main-info .period-buttons .period-btn {\n  color: #65979a;\n  border: 1px solid #65979a;\n  border-radius: 4px;\n  -webkit-margin-end: 5px;\n          margin-inline-end: 5px;\n  padding: 2px 5px;\n  font-size: 11px;\n  width: 60px;\n  text-align: center;\n}\nion-content .symbol-main-info .period-buttons .period-btn:last-child {\n  -webkit-margin-end: 0;\n          margin-inline-end: 0;\n}\nion-content .symbol-main-info .period-buttons .period-btn.active {\n  background: #005157;\n  border-color: #005157;\n  color: #FFFFFF;\n}\nion-content .symbol-main-info .main-info {\n  padding: 0 11px;\n}\nion-content .symbol-main-info ion-grid {\n  padding: 0;\n}\n.liquidity-graph-container .percentage-value {\n  font-size: 14px;\n  font-weight: bold;\n  text-align: center;\n  color: #005157;\n}\n.liquidity-graph-container .liquidity-graph {\n  width: 100%;\n  background: #2ebd85;\n  text-align: center;\n  position: relative;\n  height: 6px;\n  vertical-align: middle;\n  border-radius: 3px;\n  overflow: hidden;\n}\n.liquidity-graph-container .liquidity-graph .liquidity-percentage-graph {\n  background: #f5455a;\n  height: 6px;\n  position: absolute;\n  top: 0;\n  left: 0;\n}\n.liquidity-flow-and-net {\n  border: 1px solid #E6EFF0;\n  border-radius: 5px;\n  margin-top: 16px;\n  padding: 0;\n}\n.liquidity-flow-and-net ion-col {\n  padding-inline: 10px;\n}\n.liquidity-flow-and-net ion-col:first-child {\n  -webkit-border-end: 1px solid #E6EFF0;\n          border-inline-end: 1px solid #E6EFF0;\n}\n.liquidity-flow-and-net item-value {\n  font-size: 12px;\n}\n.liquidity-cash-info {\n  border: 1px solid #E6EFF0;\n  border-radius: 5px;\n  margin-top: 16px;\n  padding: 0;\n}\n.liquidity-cash-info .cash-header {\n  font-size: 12px;\n  font-weight: bold;\n}\n.liquidity-cash-info .cash-header ion-col {\n  padding: 7px 10px;\n}\n.liquidity-cash-info .cash-header .cash-in-title {\n  background: #E9F8F3;\n  color: #2ebd85;\n  -webkit-border-end: 1px solid #D3EAE6;\n          border-inline-end: 1px solid #D3EAE6;\n}\n.liquidity-cash-info .cash-header .cash-out-title {\n  background: #FEECEE;\n  color: #f5455a;\n}\n.liquidity-cash-info .cash-values ion-col {\n  padding-inline: 10px;\n}\n.liquidity-cash-info .cash-values-in {\n  -webkit-border-end: 1px solid #E6EFF0;\n          border-inline-end: 1px solid #E6EFF0;\n}\n.liquidity-cash-info .cash-values-in .inline-label-with-value .item-value, .liquidity-cash-info .cash-values-out .inline-label-with-value .item-value {\n  font-size: 12px;\n}\n.section-symbol-portfolios .section-title {\n  margin: 16px;\n  -webkit-margin-end: 10px;\n          margin-inline-end: 10px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n.section-symbol-portfolios .section-title .title {\n  display: flex;\n  align-items: center;\n}\n.section-symbol-portfolios .section-title .icon-link {\n  width: 30px;\n  height: 30px;\n}\n.section-symbol-portfolios .portfolios-summary-info {\n  text-align: center;\n}\n.section-symbol-portfolios .portfolios-summary-info ion-col:first-child {\n  -webkit-border-end: 1px solid #E6EFF0;\n          border-inline-end: 1px solid #E6EFF0;\n}\n.section-symbol-portfolios .portfolios-slider ion-card {\n  box-shadow: none;\n  border: 1px solid #e6eff0;\n  margin: 16px 0;\n  border-radius: 5px;\n}\n.section-symbol-portfolios .portfolios-slider ion-card ion-card-header {\n  padding: 11px 16px;\n  background: #e6eff0;\n}\n.section-symbol-portfolios .portfolios-slider ion-card ion-card-header ion-card-title {\n  --color: #65979a;\n  font-size: 14px;\n  text-align: start;\n}\n.section-symbol-portfolios .portfolios-slider ion-card ion-card-content {\n  padding: 11px;\n  text-align: start;\n}\n.section-symbol-portfolios .portfolios-slider ion-card ion-card-content ion-grid {\n  padding: 0;\n}\n.symbol-orders-and-trades {\n  border-bottom: 0;\n  margin-bottom: 0;\n}\n.symbol-orders-and-trades ion-slides {\n  min-height: 620px;\n}\n.symbol-orders-and-trades-header {\n  position: -webkit-sticky;\n  position: sticky;\n  top: 0;\n  z-index: 999999;\n  background: #FFFFFF;\n  overflow: hidden;\n}\n.symbol-orders-and-trades-header ion-segment {\n  max-width: -webkit-fit-content;\n  max-width: -moz-fit-content;\n  max-width: fit-content;\n  margin: 16px auto;\n}\n.symbol-orders-and-trades .table {\n  text-align: center;\n  font-size: 12px;\n  font-weight: bold;\n}\n.symbol-orders-and-trades .table-row-header {\n  position: -webkit-sticky;\n  position: sticky;\n  top: 64px;\n  z-index: 999999;\n  text-align: center;\n}\n.symbol-orders-and-trades .table ion-row:not(.table-header, .asks-bids-wrapper) {\n  border-bottom: 1px solid #E6EFF0;\n  padding: 5px 0;\n}\n.symbol-orders-and-trades .table ion-row:not(.table-header, .asks-bids-wrapper):last-child {\n  border-bottom: 0;\n}\nion-footer ion-toolbar {\n  --background: #FFFFFF;\n  --border-width: 0;\n  border-top: 1px solid #E6EFF0;\n  --padding-bottom: var(--safe-area-inset-bottom, 0);\n}\n.color-success {\n  color: var(--ion-color-success) !important;\n}\n.color-danger {\n  color: var(--ion-color-danger) !important;\n}\n.main-content {\n  --padding-bottom: 9px;\n  --padding-top: 9px;\n  --padding-start: 9px;\n  --padding-end: 9px;\n}\n:host .white-box {\n  background: var(--ion-color-light);\n}\n:host .white-box .value {\n  display: block;\n}\n:host .white-box .label {\n  color: #83afb4;\n  display: block;\n}\nbody.dark :host .white-box .label {\n  color: #a5a5a5;\n}\n.lower-white-box {\n  background: var(--ion-color-light);\n}\nbody.dark :host .font-size-title {\n  color: #ffffff;\n}\n.table-header {\n  font-size: 10px;\n  color: #83afb4;\n  background: var(--ion-color-tertiary);\n}\nbody.dark :host .table-header {\n  color: var(--ion-color-tertiary-contrast);\n}\n.odd {\n  background: var(--ion-color-tertiary);\n}\n.symbol-tab-bar {\n  padding-left: 10px;\n  padding-right: 10px;\n  --background: transparent;\n}\n.symbol-tab-bar ion-segment-button {\n  min-width: auto;\n  --background: #e6eff0;\n  --background-checked: var(--ion-color-primary);\n  --background-focused: var(--ion-color-primary);\n  --color: var(--ion-color-primary);\n  --color-checked: white;\n  --color-focused: white;\n  --color-hover: white;\n  --margin-bottom: 0px;\n  --margin-top: 0;\n  --margin-start: 0;\n  --margin-end: 0;\n  --indicator-color: transparent;\n  --border-radius: 0;\n  margin: 0 5px;\n}\nbody.dark :host .symbol-tab-bar ion-segment-button {\n  --background: #5d5d5d;\n  --background-checked: #787878;\n  --background-focused: #787878;\n  --color: #a5a5a5;\n}\nbody.dark :host .txt-color-dark {\n  color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN5bWJvbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBR0E7RUFDSSxxQkFBQTtBQUZKO0FBSUk7RUFDSSxlQUFBO0FBRlI7QUFLSTtFQUNJLG1CQUFBO0VBQ0EsY0FBQTtFQUNBLGdDQUFBO0VBQ0EsYUFBQTtFQUNBLGVBQUE7QUFIUjtBQUlRO0VBQ0ksZUFBQTtBQUZaO0FBTUk7RUFDSSxhQUFBO0VBQ0EsYUFBQTtFQUNBLG9CQUFBO0FBSlI7QUFNUTtFQUNJLGtCQUFBO0VBQ0EsV0FBQTtBQUpaO0FBTVk7RUFDSSxlQUFBO0FBSmhCO0FBUVE7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtBQU5aO0FBUVk7RUFDSSxjQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO1VBQUEsc0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7QUFOaEI7QUFRZ0I7RUFDSSxxQkFBQTtVQUFBLG9CQUFBO0FBTnBCO0FBU2dCO0VBQ0ksbUJBQUE7RUFDQSxxQkFBQTtFQUNBLGNBQUE7QUFQcEI7QUFZUTtFQUNJLGVBQUE7QUFWWjtBQWFRO0VBQ0ksVUFBQTtBQVhaO0FBb0JJO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FBakJSO0FBb0JJO0VBQ0ksV0FBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUFsQlI7QUFvQlE7RUFDSSxtQkFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLE1BQUE7RUFDQSxPQUFBO0FBbEJaO0FBdUJBO0VBQ0kseUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsVUFBQTtBQXBCSjtBQXNCSTtFQUNJLG9CQUFBO0FBcEJSO0FBc0JRO0VBQ0kscUNBQUE7VUFBQSxvQ0FBQTtBQXBCWjtBQXdCSTtFQUNJLGVBQUE7QUF0QlI7QUEwQkE7RUFDSSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxVQUFBO0FBdkJKO0FBeUJJO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0FBdkJSO0FBeUJRO0VBQ0ksaUJBQUE7QUF2Qlo7QUEwQlE7RUFDSSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxxQ0FBQTtVQUFBLG9DQUFBO0FBeEJaO0FBMEJRO0VBQ0ksbUJBQUE7RUFDQSxjQUFBO0FBeEJaO0FBNkJRO0VBQ0ksb0JBQUE7QUEzQlo7QUE4QlE7RUFDSSxxQ0FBQTtVQUFBLG9DQUFBO0FBNUJaO0FBaUNnQjtFQUNJLGVBQUE7QUEvQnBCO0FBd0NJO0VBQ0ksWUFBQTtFQUNBLHdCQUFBO1VBQUEsdUJBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQkFBQTtBQXJDUjtBQXVDUTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtBQXJDWjtBQXdDUTtFQUNJLFdBQUE7RUFDQSxZQUFBO0FBdENaO0FBMENJO0VBQ0ksa0JBQUE7QUF4Q1I7QUEwQ1E7RUFDSSxxQ0FBQTtVQUFBLG9DQUFBO0FBeENaO0FBK0NRO0VBQ0ksZ0JBQUE7RUFDQSx5QkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQTdDWjtBQStDWTtFQUNJLGtCQUFBO0VBQ0EsbUJBQUE7QUE3Q2hCO0FBK0NnQjtFQUNJLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FBN0NwQjtBQWlEWTtFQUNJLGFBQUE7RUFDQSxpQkFBQTtBQS9DaEI7QUFpRGdCO0VBQ0ksVUFBQTtBQS9DcEI7QUEwREE7RUFDSSxnQkFBQTtFQUNBLGdCQUFBO0FBdkRKO0FBNERJO0VBQ0ksaUJBQUE7QUExRFI7QUE2REk7RUFDSSx3QkFBQTtFQUFBLGdCQUFBO0VBQ0EsTUFBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FBM0RSO0FBNkRRO0VBQ0ksOEJBQUE7RUFBQSwyQkFBQTtFQUFBLHNCQUFBO0VBQ0EsaUJBQUE7QUEzRFo7QUErREk7RUFDSSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQTdEUjtBQStEUTtFQUNJLHdCQUFBO0VBQUEsZ0JBQUE7RUFDQSxTQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FBN0RaO0FBZ0VRO0VBQ0ksZ0NBQUE7RUFDQSxjQUFBO0FBOURaO0FBZ0VZO0VBQ0ksZ0JBQUE7QUE5RGhCO0FBdUVJO0VBQ0kscUJBQUE7RUFDQSxpQkFBQTtFQUNBLDZCQUFBO0VBQ0Esa0RBQUE7QUFwRVI7QUF3R0E7RUFDSSwwQ0FBQTtBQXJHSjtBQXdHQTtFQUNJLHlDQUFBO0FBckdKO0FBd0dBO0VBRUkscUJBQUE7RUFDQSxrQkFBQTtFQUNBLG9CQUFBO0VBQ0Esa0JBQUE7QUF0R0o7QUEwR0k7RUFFSSxrQ0FBQTtBQXhHUjtBQXlHUTtFQUNJLGNBQUE7QUF2R1o7QUF5R1E7RUFDSSxjQUFBO0VBTUEsY0FBQTtBQTVHWjtBQXdHWTtFQUNJLGNBQUE7QUF0R2hCO0FBOEdBO0VBRUksa0NBQUE7QUE1R0o7QUFpSFE7RUFDSSxjQUFBO0FBOUdaO0FBbUhBO0VBQ0ksZUFBQTtFQUNBLGNBQUE7RUFFQSxxQ0FBQTtBQWpISjtBQW9IQTtFQUNJLHlDQUFBO0FBakhKO0FBb0hBO0VBRUkscUNBQUE7QUFsSEo7QUFzSEE7RUFDSSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EseUJBQUE7QUFuSEo7QUFxSEk7RUFHSSxlQUFBO0VBRUEscUJBQUE7RUFDQSw4Q0FBQTtFQUNBLDhDQUFBO0VBQ0EsaUNBQUE7RUFDQSxzQkFBQTtFQUNBLHNCQUFBO0VBQ0Esb0JBQUE7RUFtQkEsb0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsOEJBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7QUF4SVI7QUFpSFE7RUFDSSxxQkFBQTtFQUNBLDZCQUFBO0VBQ0EsNkJBQUE7RUFDQSxnQkFBQTtBQS9HWjtBQWlKQTtFQUNFLFlBQUE7QUE5SUYiLCJmaWxlIjoic3ltYm9sLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxuXG5cbmlvbi1jb250ZW50IHtcbiAgICAtLWJhY2tncm91bmQ6ICNGNEY4Rjg7XG5cbiAgICAuaXRlbS12YWx1ZSB7XG4gICAgICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICB9XG5cbiAgICAuc3ltYm9sLWhlYWQtc2VjdGlvbiB7XG4gICAgICAgIGJhY2tncm91bmQ6ICNGNEY4Rjg7XG4gICAgICAgIGNvbG9yOiAjNjU5NzlBO1xuICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI0U2RUZGMDtcbiAgICAgICAgcGFkZGluZzogMTZweDtcbiAgICAgICAgZm9udC1zaXplOiAxMXB4O1xuICAgICAgICAuaXRlbS12YWx1ZSB7XG4gICAgICAgICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAuc3ltYm9sLW1haW4taW5mbyB7XG4gICAgICAgIG1hcmdpbi10b3A6IDA7XG4gICAgICAgIGJvcmRlci10b3A6IDA7XG4gICAgICAgIHBhZGRpbmctYm90dG9tOiAxNnB4O1xuXG4gICAgICAgIC5zeW1ib2wtZ3JhcGgge1xuICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG5cbiAgICAgICAgICAgIC5hcGV4Y2hhcnRzLWFyZWEge1xuICAgICAgICAgICAgICAgIHN0cm9rZTogIzdhYWJkZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC5wZXJpb2QtYnV0dG9ucyB7XG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICAgICAgdG9wOiAtMTBweDtcblxuICAgICAgICAgICAgLnBlcmlvZC1idG4ge1xuICAgICAgICAgICAgICAgIGNvbG9yOiAjNjU5NzlhO1xuICAgICAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICM2NTk3OWE7XG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNHB4O1xuICAgICAgICAgICAgICAgIG1hcmdpbi1pbmxpbmUtZW5kOiA1cHg7XG4gICAgICAgICAgICAgICAgcGFkZGluZzogMnB4IDVweDtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDExcHg7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDYwcHg7XG4gICAgICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuXG4gICAgICAgICAgICAgICAgJjpsYXN0LWNoaWxkIHtcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWlubGluZS1lbmQ6IDA7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgJi5hY3RpdmUge1xuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjMDA1MTU3O1xuICAgICAgICAgICAgICAgICAgICBib3JkZXItY29sb3I6ICMwMDUxNTc7XG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjRkZGRkZGO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC5tYWluLWluZm8ge1xuICAgICAgICAgICAgcGFkZGluZzogMCAxMXB4O1xuICAgICAgICB9XG5cbiAgICAgICAgaW9uLWdyaWQge1xuICAgICAgICAgICAgcGFkZGluZzogMDtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuXG4ubGlxdWlkaXR5LWdyYXBoLWNvbnRhaW5lciB7XG4gICAgLy8gcGFkZGluZzogMTZweDtcbiAgICBcbiAgICAucGVyY2VudGFnZS12YWx1ZSB7XG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgY29sb3I6ICMwMDUxNTc7XG4gICAgfVxuXG4gICAgLmxpcXVpZGl0eS1ncmFwaCB7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICBiYWNrZ3JvdW5kOiAjMmViZDg1O1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgICAgaGVpZ2h0OiA2cHg7XG4gICAgICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDNweDtcbiAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcblxuICAgICAgICAubGlxdWlkaXR5LXBlcmNlbnRhZ2UtZ3JhcGgge1xuICAgICAgICAgICAgYmFja2dyb3VuZDogI2Y1NDU1YTtcbiAgICAgICAgICAgIGhlaWdodDogNnB4O1xuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgdG9wOiAwO1xuICAgICAgICAgICAgbGVmdDogMDtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLmxpcXVpZGl0eS1mbG93LWFuZC1uZXQge1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICNFNkVGRjA7XG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgIG1hcmdpbi10b3A6IDE2cHg7XG4gICAgcGFkZGluZzogMDtcblxuICAgIGlvbi1jb2wge1xuICAgICAgICBwYWRkaW5nLWlubGluZTogMTBweDtcblxuICAgICAgICAmOmZpcnN0LWNoaWxkIHtcbiAgICAgICAgICAgIGJvcmRlci1pbmxpbmUtZW5kOiAxcHggc29saWQgI0U2RUZGMDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGl0ZW0tdmFsdWUge1xuICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgfVxufVxuXG4ubGlxdWlkaXR5LWNhc2gtaW5mbyB7XG4gICAgYm9yZGVyOiAxcHggc29saWQgI0U2RUZGMDtcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgbWFyZ2luLXRvcDogMTZweDtcbiAgICBwYWRkaW5nOiAwO1xuXG4gICAgLmNhc2gtaGVhZGVyIHtcbiAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgICBmb250LXdlaWdodDogYm9sZDtcblxuICAgICAgICBpb24tY29sIHtcbiAgICAgICAgICAgIHBhZGRpbmc6IDdweCAxMHB4O1xuICAgICAgICB9XG5cbiAgICAgICAgLmNhc2gtaW4tdGl0bGUge1xuICAgICAgICAgICAgYmFja2dyb3VuZDogI0U5RjhGMztcbiAgICAgICAgICAgIGNvbG9yOiAjMmViZDg1O1xuICAgICAgICAgICAgYm9yZGVyLWlubGluZS1lbmQ6IDFweCBzb2xpZCAjRDNFQUU2O1xuICAgICAgICB9XG4gICAgICAgIC5jYXNoLW91dC10aXRsZSB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAjRkVFQ0VFO1xuICAgICAgICAgICAgY29sb3I6ICNmNTQ1NWE7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAuY2FzaC12YWx1ZXMge1xuICAgICAgICBpb24tY29sIHtcbiAgICAgICAgICAgIHBhZGRpbmctaW5saW5lOiAxMHB4O1xuICAgICAgICB9XG5cbiAgICAgICAgJi1pbiB7XG4gICAgICAgICAgICBib3JkZXItaW5saW5lLWVuZDogMXB4IHNvbGlkICNFNkVGRjA7XG4gICAgICAgIH1cblxuICAgICAgICAmLWluLCAmLW91dCB7XG4gICAgICAgICAgICAuaW5saW5lLWxhYmVsLXdpdGgtdmFsdWUge1xuICAgICAgICAgICAgICAgIC5pdGVtLXZhbHVlIHtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn1cblxuXG4uc2VjdGlvbi1zeW1ib2wtcG9ydGZvbGlvcyB7XG4gICAgLnNlY3Rpb24tdGl0bGUge1xuICAgICAgICBtYXJnaW46IDE2cHg7XG4gICAgICAgIG1hcmdpbi1pbmxpbmUtZW5kOiAxMHB4O1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cbiAgICAgICAgLnRpdGxlIHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICB9XG5cbiAgICAgICAgLmljb24tbGluayB7XG4gICAgICAgICAgICB3aWR0aDogMzBweDtcbiAgICAgICAgICAgIGhlaWdodDogMzBweDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5wb3J0Zm9saW9zLXN1bW1hcnktaW5mbyB7XG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcblxuICAgICAgICBpb24tY29sOmZpcnN0LWNoaWxkIHtcbiAgICAgICAgICAgIGJvcmRlci1pbmxpbmUtZW5kOiAxcHggc29saWQgI0U2RUZGMDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgXG5cbiAgICAucG9ydGZvbGlvcy1zbGlkZXIge1xuICAgICAgICBpb24tY2FyZCB7XG4gICAgICAgICAgICBib3gtc2hhZG93OiBub25lO1xuICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2U2ZWZmMDtcbiAgICAgICAgICAgIG1hcmdpbjogMTZweCAwO1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xuXG4gICAgICAgICAgICBpb24tY2FyZC1oZWFkZXIge1xuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDExcHggMTZweDtcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjZTZlZmYwO1xuXG4gICAgICAgICAgICAgICAgaW9uLWNhcmQtdGl0bGUge1xuICAgICAgICAgICAgICAgICAgICAtLWNvbG9yOiAjNjU5NzlhO1xuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgICAgICAgICAgICAgIHRleHQtYWxpZ246IHN0YXJ0O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaW9uLWNhcmQtY29udGVudCB7XG4gICAgICAgICAgICAgICAgcGFkZGluZzogMTFweDtcbiAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBzdGFydDtcblxuICAgICAgICAgICAgICAgIGlvbi1ncmlkIHtcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogMDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59XG5cblxuXG5cblxuLnN5bWJvbC1vcmRlcnMtYW5kLXRyYWRlcyB7XG4gICAgYm9yZGVyLWJvdHRvbTogMDtcbiAgICBtYXJnaW4tYm90dG9tOiAwO1xuICAgIC8vIGRpc3BsYXk6IGZsZXg7XG4gICAgLy8gYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAvLyBtYXgtaGVpZ2h0OiAxMDAlO1xuXG4gICAgaW9uLXNsaWRlc3tcbiAgICAgICAgbWluLWhlaWdodDogNjIwcHg7XG4gICAgfVxuXG4gICAgJi1oZWFkZXIge1xuICAgICAgICBwb3NpdGlvbjogc3RpY2t5O1xuICAgICAgICB0b3A6IDA7XG4gICAgICAgIHotaW5kZXg6IDk5OTk5OTtcbiAgICAgICAgYmFja2dyb3VuZDogI0ZGRkZGRjtcbiAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcblxuICAgICAgICBpb24tc2VnbWVudCB7XG4gICAgICAgICAgICBtYXgtd2lkdGg6IGZpdC1jb250ZW50O1xuICAgICAgICAgICAgbWFyZ2luOiAxNnB4IGF1dG87XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAudGFibGUge1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG5cbiAgICAgICAgJi1yb3ctaGVhZGVyIHtcbiAgICAgICAgICAgIHBvc2l0aW9uOiBzdGlja3k7XG4gICAgICAgICAgICB0b3A6IDY0cHg7XG4gICAgICAgICAgICB6LWluZGV4OiA5OTk5OTk7XG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgIH1cbiAgICAgICAgXG4gICAgICAgIGlvbi1yb3c6bm90KC50YWJsZS1oZWFkZXIsIC5hc2tzLWJpZHMtd3JhcHBlcikge1xuICAgICAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNFNkVGRjA7XG4gICAgICAgICAgICBwYWRkaW5nOiA1cHggMDtcblxuICAgICAgICAgICAgJjpsYXN0LWNoaWxkIHtcbiAgICAgICAgICAgICAgICBib3JkZXItYm90dG9tOiAwO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuXG5cblxuaW9uLWZvb3RlciB7XG4gICAgaW9uLXRvb2xiYXIge1xuICAgICAgICAtLWJhY2tncm91bmQ6ICNGRkZGRkY7XG4gICAgICAgIC0tYm9yZGVyLXdpZHRoOiAwO1xuICAgICAgICBib3JkZXItdG9wOiAxcHggc29saWQgI0U2RUZGMDtcbiAgICAgICAgLS1wYWRkaW5nLWJvdHRvbTogdmFyKC0tc2FmZS1hcmVhLWluc2V0LWJvdHRvbSwgMCk7XG4gICAgfVxufVxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cbi8vIC5zeW1ib2wtaGVhZGVyLWJveC1pbm5lciB7XG4vLyAgICAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXNlY29uZGFyeSk7XG4vLyAgICAgaGVpZ2h0OiAxMDAlO1xuLy8gICAgIC8vIC13ZWJraXQtcGFkZGluZy1zdGFydDogMTBweDtcbi8vICAgICAvLyBwYWRkaW5nLWlubGluZS1zdGFydDogMTBweDtcbi8vICAgICAvLyAtd2Via2l0LXBhZGRpbmctZW5kOiAxMHB4O1xuLy8gICAgIC8vIHBhZGRpbmctaW5saW5lLWVuZDogMTBweDtcbi8vIH1cblxuLy8gYm9keS5kYXJrIDpob3N0IC5zeW1ib2wtaGVhZGVyLWJveC1pbm5lcntcbi8vICAgICBiYWNrZ3JvdW5kIDogIzJlMmUyZTtcbi8vIH1cblxuLmNvbG9yLXN1Y2Nlc3Mge1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc3VjY2VzcykgIWltcG9ydGFudDtcbn1cblxuLmNvbG9yLWRhbmdlciB7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYW5nZXIpICFpbXBvcnRhbnQ7XG59XG5cbi5tYWluLWNvbnRlbnQge1xuICAgIC8vIGJhY2tncm91bmQ6ICNmN2Y3Zjc7XG4gICAgLS1wYWRkaW5nLWJvdHRvbTogOXB4O1xuICAgIC0tcGFkZGluZy10b3A6IDlweDtcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDlweDtcbiAgICAtLXBhZGRpbmctZW5kOiA5cHg7XG59XG5cbjpob3N0IHtcbiAgICAud2hpdGUtYm94IHtcbiAgICAgICAgLy8gYmFja2dyb3VuZDogd2hpdGU7XG4gICAgICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1saWdodCk7XG4gICAgICAgIC52YWx1ZXtcbiAgICAgICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgICB9XG4gICAgICAgIC5sYWJlbCB7XG4gICAgICAgICAgICBjb2xvcjogIzgzYWZiNDtcblxuICAgICAgICAgICAgYm9keS5kYXJrICYge1xuICAgICAgICAgICAgICAgIGNvbG9yOiAjYTVhNWE1O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLmxvd2VyLXdoaXRlLWJveCB7XG4gICAgLy8gYmFja2dyb3VuZDogd2hpdGU7XG4gICAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbn1cblxuOmhvc3Qge1xuICAgIC5mb250LXNpemUtdGl0bGUge1xuICAgICAgICBib2R5LmRhcmsgJiB7XG4gICAgICAgICAgICBjb2xvcjogI2ZmZmZmZjtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLnRhYmxlLWhlYWRlciB7XG4gICAgZm9udC1zaXplOiAxMHB4O1xuICAgIGNvbG9yOiAjODNhZmI0O1xuICAgIC8vIGJhY2tncm91bmQ6ICNlNmVmZjA7XG4gICAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5KTtcbn1cblxuYm9keS5kYXJrIDpob3N0IC50YWJsZS1oZWFkZXJ7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci10ZXJ0aWFyeS1jb250cmFzdCk7XG59XG5cbi5vZGQge1xuICAgIC8vIGJhY2tncm91bmQ6ICNlNmVmZjA7XG4gICAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5KTtcblxufVxuXG4uc3ltYm9sLXRhYi1iYXIge1xuICAgIHBhZGRpbmctbGVmdDogMTBweDtcbiAgICBwYWRkaW5nLXJpZ2h0OiAxMHB4O1xuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG5cbiAgICBpb24tc2VnbWVudC1idXR0b24ge1xuXG5cbiAgICAgICAgbWluLXdpZHRoOiBhdXRvO1xuICAgICAgIC8vIG1hcmdpbjogMCA0cHg7XG4gICAgICAgIC0tYmFja2dyb3VuZDogI2U2ZWZmMDtcbiAgICAgICAgLS1iYWNrZ3JvdW5kLWNoZWNrZWQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgICAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICAtLWNvbG9yLWNoZWNrZWRcdDogd2hpdGU7XG4gICAgICAgIC0tY29sb3ItZm9jdXNlZDogd2hpdGU7XG4gICAgICAgIC0tY29sb3ItaG92ZXI6IHdoaXRlO1xuICAgIFxuICAgICAgICBib2R5LmRhcmsgOmhvc3QgJntcbiAgICAgICAgICAgIC0tYmFja2dyb3VuZDogIzVkNWQ1ZDtcbiAgICAgICAgICAgIC0tYmFja2dyb3VuZC1jaGVja2VkOiAjNzg3ODc4O1xuICAgICAgICAgICAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6ICM3ODc4Nzg7XG4gICAgICAgICAgICAtLWNvbG9yOiAjYTVhNWE1O1xuICAgICAgICB9XG5cblxuICAgICAgICAvLyAvLyAtLWJhY2tncm91bmQ6ICNlNmVmZjA7XG4gICAgICAgIC8vIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5KTtcblxuICAgICAgICAvLyAvLyAtLWJhY2tncm91bmQtY2hlY2tlZDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICAvLyAtLWJhY2tncm91bmQtY2hlY2tlZDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktYmcpO1xuICAgICAgICAvLyAvLyAtLWJhY2tncm91bmQtZm9jdXNlZDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICAvLyAtLWJhY2tncm91bmQtZm9jdXNlZDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktYmcpO1xuICAgICAgICAvLyAtLWNvbG9yLWNoZWNrZWQ6IHdoaXRlO1xuICAgICAgICAvLyAtLWNvbG9yLWZvY3VzZWQ6IHdoaXRlO1xuICAgICAgICAtLW1hcmdpbi1ib3R0b206IDBweDtcbiAgICAgICAgLS1tYXJnaW4tdG9wOiAwO1xuICAgICAgICAtLW1hcmdpbi1zdGFydDogMDtcbiAgICAgICAgLS1tYXJnaW4tZW5kOiAwO1xuICAgICAgICAtLWluZGljYXRvci1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gICAgICAgIC0tYm9yZGVyLXJhZGl1czogMDtcbiAgICAgICAgbWFyZ2luOiAwIDVweDtcbiAgICB9XG59XG5cbi8vIGlvbi1oZWFkZXIge1xuLy8gICAgIGJhY2tncm91bmQ6ICMwMDUxNTc7XG4vLyAgICAgY29sb3I6ICNGRkZGRkY7XG5cbi8vICAgICBpb24tdG9vbGJhciB7XG4vLyAgICAgICAgIC0tYmFja2dyb3VuZDogIzAwNTE1Nztcbi8vICAgICAgICAgY29sb3I6ICNGRkZGRkY7XG4vLyAgICAgfVxuLy8gfVxuXG5cbmJvZHkuZGFyayA6aG9zdCAudHh0LWNvbG9yLWRhcmt7XG4gIGNvbG9yOndoaXRlO1xufVxuXG4iXX0= */";

/***/ }),

/***/ 61675:
/*!**********************************************************!*\
  !*** ./src/app/pages/symbol/symbol.page.html?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = "<ion-header translucent>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button [text]=\"''\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{ symbol?.abbreviation | async }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"symbol-head-section\">\n    <ion-grid class=\"ion-no-padding\">\n      <ion-row id=\"symbol-header-box-container\">\n        <ion-col size=\"4\">\n          <div class=\"symbol-header-box-inner ion-text-center\">\n            <div class=\"item-label\">{{ 'tradestion.OPENNING' | translate }}</div>\n            <div class=\"item-value\">\n              {{ (symbol?.parameters | async)?.openPrice | number:'1.0-2' | commafy }}\n              <div class=\"small\">ر.س</div>\n            </div>\n\n          </div>\n        </ion-col>\n\n        <ion-col size=\"4\">\n          <div class=\"symbol-header-box-inner ion-text-center\">\n            <div class=\"item-label\"> {{ 'tradestion.LAST_PRICE' | translate }}</div>\n            <div class=\"item-value\"\n              [ngClass]=\"zeroChecker((symbol?.parameters | async)?.changePercentage) ? '': positiveChecker((symbol?.parameters | async)?.changePercentage) ? 'text-up' : 'text-down'\">\n              {{ (symbol?.parameters | async)?.lastTradedPrice | number:'1.0-2' | commafy }}\n              <div class=\"small\">({{ (symbol?.parameters | async)?.changePercentage}}%)</div>\n            </div>\n          </div>\n        </ion-col>\n\n        <ion-col size=\"4\">\n          <div class=\"symbol-header-box-inner ion-text-center\">\n            <div class=\"item-label\"> {{ 'tradestion.CLOSING' | translate }}</div>\n            <div class=\"item-value\">\n              {{ (symbol?.parameters | async)?.previousClosed | number:'1.0-2' | commafy }}\n              <div class=\"small\">ر.س</div>\n            </div>\n          </div>\n        </ion-col>\n\n\n\n        <!-- <ion-col size=\"4\" [ngClass]=\"{'centered digit': true, 'up': symbol?.gainLossUnrealized >= 0 , 'down': symbol?.gainLossUnrealized < 0 }\">\n          <div class=\"symbol-header-box-inner ion-padding-vertical ion-text-center\">\n            <span class=\"symbol-header-label font-size-caption\">{{ t.GAIN_LOSE }}</span>\n            <br *ngIf=\"positiveChecker(symbol?.ownedQuantity)\"> -->\n\n\n\n\n        <!-- <span class=\"symbol-header-value\">\n              {{ symbol?.gainLossUnrealized }}\n              {{ symbol?.gainLossPercentageUnrealized }}\n            </span> -->\n        <!-- <ion-text *ngIf=\"positiveChecker(symbol?.ownedQuantity)\" class=\"symbol-header-value font-size-display\" dir=\"ltr\" \n              [color]=\"zeroChecker((symbol?.gainLossPercentageUnrealized)) ? 'white': positiveChecker(symbol?.gainLossPercentageUnrealized) ? 'success' : 'danger'\">\n              {{ symbol?.gainLossUnrealized | number:'1.0-2' | commafy}}\n            </ion-text >\n            <br *ngIf=\"positiveChecker(symbol?.ownedQuantity)\">\n            <ion-text *ngIf=\"positiveChecker(symbol?.ownedQuantity)\" class=\"font-size-caption\" dir=\"ltr\" \n              [color]=\"zeroChecker((symbol?.gainLossPercentageUnrealized)) ? 'white': positiveChecker(symbol?.gainLossPercentageUnrealized) ? 'success' : 'danger'\">\n              ({{ symbol?.gainLossPercentageUnrealized }}%)\n            </ion-text>\n            <br *ngIf=\"!positiveChecker(symbol?.ownedQuantity)\">\n            <ion-text *ngIf=\"!positiveChecker(symbol?.ownedQuantity)\" class=\"symbol-header-value font-size-display\" dir=\"ltr\" \n              color=\"white\">\n              0\n            </ion-text>\n            <br *ngIf=\"!positiveChecker(symbol?.ownedQuantity)\">\n            <ion-text *ngIf=\"!positiveChecker(symbol?.ownedQuantity)\" class=\"font-size-caption\" dir=\"ltr\" \n              color=\"white\">\n              (0%)\n            </ion-text> -->\n        <!-- <ion-text class=\"symbol-header-value font-size-display\" color=\"success\">665</ion-text >\n            <br>\n            <ion-text class=\"font-size-caption\" dir=\"ltr\" color=\"success\">(30.43%)</ion-text> -->\n        <!-- </div>\n        </ion-col> -->\n      </ion-row>\n    </ion-grid>\n  </div>\n\n  <div class=\"section symbol-main-info\">\n\n    <!-- <tadawul-skeleton-loader [type]=\"SkeletonType.SYMBOL_GRAPH\" [hidden]=\"!graphLoader\"></tadawul-skeleton-loader> -->\n\n    <div>\n      <div id=\"chart-spark\" dir=\"ltr\" class=\"symbol-graph\"></div>\n      <div class=\"period-buttons\">\n        <div class=\"period-btn\" [class]=\"period === 'day' ? 'active' : ''\" (click)=\"priceChangeInPeriod('day');\">\n          {{ 'symbolPage.DAY' | translate }}</div>\n        <div class=\"period-btn\" [class]=\"period === 'week' ? 'active' : ''\" (click)=\"priceChangeInPeriod('week');\">\n          {{ 'symbolPage.WEEK' | translate }}</div>\n        <div class=\"period-btn\" [class]=\"period === 'month' ? 'active' : ''\" (click)=\"priceChangeInPeriod('month');\">\n          {{ 'symbolPage.MONTH' | translate }}</div>\n        <div class=\"period-btn\" [class]=\"period === 'sixMonths' ? 'active' : ''\"\n          (click)=\"priceChangeInPeriod('sixMonths');\"> {{ 'symbolPage.SIX_MONTHS' | translate }}</div>\n      </div>\n\n    </div>\n\n    <ion-grid class=\"main-info\">\n      <ion-row>\n        <ion-col size=\"3\">\n          <div class=\"item-label\"> {{ 'symbolPage.ASK_PRICE' | translate }}</div>\n          <div class=\"item-value\">\n            {{(symbol?.parameters | async)?.askPrice | commafy}}\n          </div>\n        </ion-col>\n\n        <ion-col size=\"3\">\n          <div class=\"item-label\">{{ 'symbolPage.ASK_QUANTITY' | translate }}</div>\n          <div class=\"item-value\">\n            {{(symbol?.parameters | async)?.askQuantity | commafy}}\n          </div>\n        </ion-col>\n\n        <ion-col size=\"3\">\n          <div class=\"item-label\"> {{ 'symbolPage.BIDDING_PRICE' | translate }}</div>\n          <div class=\"item-value\">\n            {{(symbol?.parameters | async)?.biddingPrice | commafy}}\n          </div>\n        </ion-col>\n\n        <ion-col size=\"3\">\n          <div class=\"item-label\"> {{ 'symbolPage.BIDDING_QUANTITY' | translate }}</div>\n          <div class=\"item-value\">\n            {{(symbol?.parameters | async)?.biddingQuantity | commafy}}\n          </div>\n        </ion-col>\n\n        <ion-col size=\"3\">\n          <div class=\"item-label\"> {{ 'symbolPage.MAXIMUM' | translate }}</div>\n          <div class=\"item-value\">\n            {{(symbol?.parameters | async)?.highestPrice | commafy}}\n          </div>\n        </ion-col>\n\n        <ion-col size=\"3\">\n          <div class=\"item-label\"> {{ 'symbolPage.MINIMUM' | translate }}</div>\n          <div class=\"item-value\">\n            {{(symbol?.parameters | async)?.lowestPrice | commafy}}\n          </div>\n        </ion-col>\n\n        <ion-col size=\"3\">\n          <div class=\"item-label\"> {{ 'symbolPage.TRADING_VOLUME' | translate }}</div>\n          <div class=\"item-value\">\n            {{(symbol?.parameters | async)?.tradingVolume | commafy}}\n          </div>\n        </ion-col>\n\n        <ion-col size=\"3\">\n          <div class=\"item-label\"> {{ 'symbolPage.TRADING_VALUE' | translate }}</div>\n          <div class=\"item-value\">\n            {{(symbol?.parameters | async)?.tradingValue | commafy}}\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </div>\n\n  <div class=\"section ion-padding\">\n\n    <h3 class=\"section-title\">\n      <svg>\n        <use xlink:href=\"#icon-money-stack\"></use>\n      </svg>\n      {{ 'tradestion.LIQUIDITY' | translate }}\n    </h3>\n\n    <div class=\"liquidity-graph-container\">\n      <div id=\"text\" class=\"percentage-value\">{{(symbol?.parameters | async)?.liquidityPercentage}}%</div>\n      <div id=\"liquidity-percentage\" class=\"liquidity-graph\">\n        <div id=\"red\" class=\"liquidity-percentage-graph\"\n          [ngStyle]=\"{width: (100 - (symbol?.parameters | async)?.liquidityPercentage) +'%'}\"></div>\n      </div>\n    </div>\n\n    <ion-grid class=\"liquidity-flow-and-net\">\n      <ion-row>\n        <ion-col size=\"6\">\n          <div class=\"inline-label-with-value\">\n            <span class=\"item-label\">{{ 'tradestion.LIQUIDITY_FLOW' | translate }}</span>\n            <span class=\"item-value\">{{(symbol?.parameters | async)?.liquidityFlow | commafy:'number':2}}</span>\n          </div>\n        </ion-col>\n        <ion-col size=\"6\">\n          <div class=\"inline-label-with-value\">\n            <span class=\"item-label\"> {{ 'tradestion.LIQUIDITY_NET' | translate }}</span>\n            <span class=\"item-value\">{{(symbol?.parameters | async)?.liquidityNet | commafy:'number':2}}</span>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n\n    <ion-grid class=\"liquidity-cash-info\">\n      <ion-row class=\"cash-header\">\n        <ion-col size=\"6\" class=\"cash-in-title\">\n          {{ 'tradestion.LIQUIDITY_IN' | translate }}\n        </ion-col>\n        <ion-col size=\"6\" class=\"cash-out-title\">\n          {{ 'tradestion.LIQUIDITY_OUT' | translate }}\n        </ion-col>\n      </ion-row>\n\n      <ion-row class=\"cash-values\">\n        <ion-col size=\"6\" class=\"cash-values-in\">\n          <div class=\"inline-label-with-value\">\n            <span class=\"item-label\">{{ 'tradestion.LIQUIDITY_VOLUME' | translate }}</span>\n            <span class=\"item-value\">{{ (symbol?.parameters | async)?.cashInVolume }}</span>\n          </div>\n          <div class=\"inline-label-with-value\">\n            <span class=\"item-label\">{{ 'tradestion.LIQUIDITY_VALUE' | translate }}</span>\n            <span class=\"item-value\">{{ (symbol?.parameters | async)?.cashInTurnover }}</span>\n          </div>\n        </ion-col>\n\n        <ion-col size=\"6\" class=\"cash-values-out\">\n          <div class=\"inline-label-with-value\">\n            <span class=\"item-label\">{{ 'tradestion.LIQUIDITY_VOLUME' | translate }}</span>\n            <span class=\"item-value\">{{ (symbol?.parameters | async)?.cashOutVolume }}</span>\n          </div>\n          <div class=\"inline-label-with-value\">\n            <span class=\"item-label\"> {{ 'tradestion.LIQUIDITY_VALUE' | translate }}</span>\n            <span class=\"item-value\">{{ (symbol?.parameters | async)?.cashOutTurnover }}</span>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </div>\n\n  <div class=\"section section-symbol-portfolios\">\n\n    <h3 class=\"section-title\" *ngIf=\"!portfolioLoader\">\n      <div class=\"title\">\n        <svg>\n          <use xlink:href=\"#icon-portfolio\"></use>\n        </svg>\n        {{ 'morePage.PORTFOLIOS' | translate }}\n      </div>\n\n      <div class=\"icon-link\" (click)=\"loadSymbolDataInAllPortfolios()\">\n        <span class=\"icon icon-reload\"></span>\n      </div>\n    </h3>\n\n    <ion-grid *ngIf=\"!portfolioLoader\" class=\"portfolios-summary-info ion-padding-horizontal ion-no-padding\">\n      <ion-row>\n        <ion-col>\n          <div class=\"item-label\"> {{ 'symbolPage.ALL_OWEND_QUANTITY' | translate }}</div>\n          <div class=\"item-value\" *ngIf=\"symbolDataInportfolios?.totalOwnedQuantity\">\n            {{ symbolDataInportfolios?.totalOwnedQuantity }}\n          </div>\n          <div class=\"item-value\" *ngIf=\"!symbolDataInportfolios?.totalOwnedQuantity\">\n            0\n          </div>\n        </ion-col>\n        <ion-col>\n          <div class=\"item-label\"> {{ 'symbolPage.ALL_PROFIT_LOSS' | translate }}</div>\n          <div class=\"item-value\" *ngIf=\"symbolDataInportfolios?.totalProfitLoss\" dir=\"ltr\"\n            [ngClass]=\"zeroChecker((symbolDataInportfolios?.totalProfitLoss)) ? '': positiveChecker(symbolDataInportfolios?.totalProfitLoss) ? 'text-up' : 'text-down'\">\n            {{ symbolDataInportfolios?.totalProfitLoss }}\n          </div>\n          <div class=\"item-value\" *ngIf=\"!symbolDataInportfolios?.totalProfitLoss\">\n            0\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n\n    <tadawul-skeleton-loader *ngIf=\"portfolioLoader\" [type]=\"SkeletonType.SYMBOL_PORTFOLIO_CARD\">\n    </tadawul-skeleton-loader>\n\n    <!-- Portfolios Slider - Start -->\n    <ion-slides #portfolioSlides *ngIf=\"!portfolioLoader\" pager=\"false\" [options]=\"slideOptions\"\n      class=\"portfolios-slider\" (ionSlideNextEnd)=\"slideChanged()\" (ionSlidePrevEnd)=\"slideChanged()\">\n\n      <ion-slide *ngFor=\"let portfolio of symbolDataInportfolios?.symbolPortfoliosInfo\">\n        <ion-card>\n\n          <ion-card-header>\n            <ion-card-title>{{portfolio?.portfolioNumber}}</ion-card-title>\n          </ion-card-header>\n\n          <ion-card-content>\n            <ion-grid>\n              <ion-row>\n                <ion-col size=\"4\">\n                  <div class=\"item-label\"> {{ 'symbolPage.OWNED_AMOUNT' | translate }}</div>\n                  <div class=\"item-value\">\n                    {{portfolio?.ownedQuantity}}\n                  </div>\n                </ion-col>\n\n                <ion-col size=\"4\">\n                  <div class=\"item-label\"> {{ 'symbolPage.AVERAGE_BUY' | translate }}</div>\n                  <div class=\"item-value\">\n                    {{portfolio?.avgCostPrice?.amount}}\n                  </div>\n                </ion-col>\n\n                <ion-col size=\"4\">\n                  <div class=\"item-label\"> {{ 'symbolPage.TOTAL_COST' | translate }}</div>\n                  <div class=\"item-value\">\n                    {{portfolio?.totalCost?.amount}}\n                  </div>\n                </ion-col>\n\n                <ion-col size=\"4\">\n                  <div class=\"item-label\">{{ 'symbolPage.MARKET_PRICE' | translate }}</div>\n                  <div class=\"item-value\">\n                    {{portfolio?.totalMrktValue?.amount}}\n                  </div>\n                </ion-col>\n\n                <ion-col size=\"4\">\n                  <div class=\"item-label\"> {{ 'symbolPage.GAIN_LOSE' | translate }}</div>\n                  <div class=\"item-value\" [ngClass]=\"zeroChecker((portfolio?.unrealizedProfitLoss?.amount)) ? '': positiveChecker(portfolio?.unrealizedProfitLoss?.amount) ? 'text-up' : 'text-down'\">\n                    {{portfolio?.unrealizedProfitLoss?.amount}}\n                  </div>\n                </ion-col>\n              </ion-row>\n            </ion-grid>\n          </ion-card-content>\n\n        </ion-card>\n      </ion-slide>\n\n    </ion-slides>\n    <!-- Portfolios Slider - End -->\n  </div>\n\n  <div class=\"section symbol-orders-and-trades\">\n    <div class=\"symbol-orders-and-trades-header\">\n      <ion-segment [(ngModel)]=\"oredrsTradesSlidesType\" (ionChange)=\"SegmentChanged()\">\n        <ion-segment-button value=\"orders\">\n          {{ 'symbolPage.ORDERS_ACCORDING_TO_PRICE' | translate }}\n        </ion-segment-button>\n        <ion-segment-button value=\"trades\">\n          {{ 'symbolPage.COMPANY_TRADES' | translate }}\n        </ion-segment-button>\n      </ion-segment>\n    </div>\n\n    <ion-row class=\"table-row-header ion-justify-content-around\" *ngIf=\"oredrsTradesSlidesType === 'orders'\">\n      <ion-col *ngFor=\"let headerItem of headerListMenu\" [size]=\"headerItem.size\">\n        {{headerItem.title}}\n      </ion-col>\n    </ion-row>\n\n    <ion-row class=\"table-row-header ion-justify-content-around\" *ngIf=\"oredrsTradesSlidesType === 'trades'\">\n      <ion-col *ngFor=\"let headerItem of tradesHeaderListMenu\" size=\"2\">\n        {{headerItem}}\n      </ion-col>\n    </ion-row>\n    <!-- ORDERS TAB -->\n\n    <ion-slides #oredrsTradesSlides (ionSlideDidChange)=\"SlidesChanged()\">\n      <ion-slide>\n\n\n\n\n\n        <!-- <ion-row class=\"table-header\">\n        <ion-col *ngFor=\"let headerItem of headerListMenu\" size=\"2\">\n          {{headerItem}}\n        </ion-col>\n      </ion-row> -->\n        <ion-grid class=\"ion-no-padding table\" *ngIf=\"oredrsTradesSlidesType === 'orders'\">\n          <ion-row class=\"ion-no-padding asks-bids-wrapper\">\n            <ion-col size=\"6\" class=\"ion-no-padding\">\n              <ion-row *ngFor=\"let ask of asks; let index = index\">\n                <ion-col size=\"4\">\n                  <ion-text class=\"txt-color-dark\" color=\"primary\">\n                    {{ ask.split | commafy }}\n                    <!-- {{ Number(ask.quantity | commafy) || '-' }} -->\n                  </ion-text>\n                </ion-col>\n                <ion-col size=\"4\">\n                  <ion-text class=\"txt-color-dark\" color=\"primary\">\n                    {{ ask.quantity | commafy }}\n                    <!-- {{ Number(ask.split | commafy) || '-' }} -->\n                  </ion-text>\n                </ion-col>\n                <ion-col size=\"4\">\n                  <ion-text class=\"text-up\">\n                    {{ ask.price | commafy }}\n                    <!-- {{ Number(ask.price | commafy) || '-' }} -->\n                  </ion-text>\n                </ion-col>\n              </ion-row>\n            </ion-col>\n\n            <ion-col size=\"6\" class=\"ion-no-padding\">\n              <ion-row *ngFor=\"let bid of bids; let index = index\">\n                <ion-col size=\"4\">\n                  <ion-text class=\"text-down\">\n                    {{ bid.price | commafy }}\n                    <!-- {{ Number(bid.price | commafy) || '-' }} -->\n                  </ion-text>\n                </ion-col>\n                <ion-col size=\"4\">\n                  <ion-text class=\"txt-color-dark\" color=\"primary\">\n                    {{ bid.quantity | commafy }}\n                    <!-- {{ Number(bid.split | commafy) || '-' }} -->\n                  </ion-text>\n                </ion-col>\n                <ion-col size=\"4\">\n                  <ion-text class=\"txt-color-dark\" color=\"primary\">\n                    {{ bid.split | commafy}}\n                    <!-- {{ Number(bid.quantity | commafy) || '-' }} -->\n                  </ion-text>\n                </ion-col>\n              </ion-row>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n      </ion-slide>\n\n      <!-- TRADES TAB -->\n      <ion-slide>\n\n\n\n        <!-- <ion-row class=\"table-header\">\n        <ion-col *ngFor=\"let headerItem of tradesHeaderListMenu\" size=\"\">\n          {{headerItem}}\n        </ion-col>\n      </ion-row> -->\n        <ion-grid class=\"ion-no-padding table\" *ngIf=\"oredrsTradesSlidesType === 'trades'\">\n          <ion-row class=\"ion-justify-content-around\" *ngFor=\"let trade of trades; let index = index\">\n            <ion-col size=\"2\">\n              <ion-text>\n                {{ trade.tradeTime }}\n              </ion-text>\n            </ion-col>\n            <ion-col size=\"2\">\n              <ion-text [ngClass]=\"(trade.type == 'B') ? 'text-up' : 'text-down'\">\n                {{ trade.price | commafy }}\n              </ion-text>\n            </ion-col>\n            <ion-col size=\"2\">\n              <ion-text>\n                {{ trade.quantity | commafy }}\n              </ion-text>\n            </ion-col>\n            <ion-col size=\"2\">\n              <ion-text>\n                {{ Number(trade.change) || '-' }}\n              </ion-text>\n            </ion-col>\n            <ion-col size=\"2\">\n              <ion-text [ngClass]=\"(trade.type == 'B') ? 'text-up' : 'text-down'\">\n                {{ translate.instant('app.'+trade.type) }}\n              </ion-text>\n            </ion-col>\n            <ion-col size=\"2\">\n              <ion-text>\n                {{ trade.splits }}\n              </ion-text>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n      </ion-slide>\n    </ion-slides>\n  </div>\n</ion-content>\n\n<ion-footer>\n  <ion-toolbar>\n    <ion-grid>\n      <ion-row *ngIf=\"portfolioLoader\">\n        <ion-col>\n          <ion-skeleton-text animated style=\"width: 100%;border-radius: 5px;height: 40px;\">\n          </ion-skeleton-text>\n        </ion-col>\n        <ion-col>\n          <ion-skeleton-text animated style=\"width: 100%;border-radius: 5px;height: 40px;\">\n          </ion-skeleton-text>\n        </ion-col>\n      </ion-row>\n      <ion-row *ngIf=\"!portfolioLoader\">\n        <ion-col>\n          <app-button (clickAction)=\"openBuySellSymbols(sharedSymbol,'buy')\" expand=\"block\" size=\"\" color=\"success\"\n            fill=\"solid\" shape=\"\" type=\"button\">\n            {{ 'symbolPage.BUY' | translate }}\n          </app-button>\n        </ion-col>\n        <ion-col>\n          <app-button\n            [disabled]=\"symbolDataInportfolios?.symbolPortfoliosInfo?.length == 0 || !symbolDataInportfolios?.symbolPortfoliosInfo\"\n            (clickAction)=\"openBuySellSymbols(sharedSymbol,'sell')\" expand=\"block\" size=\"\" color=\"danger\" fill=\"solid\"\n            shape=\"\" type=\"button\">\n            {{ 'symbolPage.SELL' | translate }}\n          </app-button>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-toolbar>\n</ion-footer>\n\n\n\n<svg xmlns=\"http://www.w3.org/2000/svg\" style=\"display: none;\">\n  <symbol id=\"icon-money-stack\" viewBox=\"0 0 24 24\">\n    <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M1,14.5V6.6 C1,5.2,2.2,4,3.6,4h15.9\" />\n    <g>\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\"\n        d=\"M22,18H4 c-0.6,0-1-0.4-1-1V7c0-0.6,0.4-1,1-1h18c0.6,0,1,0.4,1,1v10C23,17.6,22.6,18,22,18z\" />\n      <circle stroke-linecap=\"round\" stroke-miterlimit=\"10\" cx=\"13\" cy=\"12\" r=\"2.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M6.5,6L6.5,6 c0,1.9-1.6,3.5-3.5,3.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M19.5,6L19.5,6 c0,1.9,1.6,3.5,3.5,3.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M3,14.5 c1.9,0,3.5,1.6,3.5,3.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M19.5,18 c0-1.9,1.6-3.5,3.5-3.5\" />\n    </g>\n  </symbol>\n\n  <symbol id=\"icon-portfolio\" viewBox=\"0 0 24 24\">\n    <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M21.5,6.8V5.5c0-1.1-0.9-2-2-2h-16 c-1.1,0-2,0.9-2,2v3v8\" />\n    <path stroke-linecap=\"round\" stroke-miterlimit=\"10\"\n      d=\"M20.5,20.5h-17c-1.1,0-2-0.9-2-2v-12h19 c1.1,0,2,0.9,2,2v10C22.5,19.6,21.7,20.5,20.5,20.5z\" />\n    <circle stroke-linecap=\"round\" stroke-miterlimit=\"10\" cx=\"18.3\" cy=\"13.5\" r=\"1.5\"></circle>\n  </symbol>\n</svg>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_symbol_symbol_module_ts.js.map