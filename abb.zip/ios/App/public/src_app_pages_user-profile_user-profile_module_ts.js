"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_user-profile_user-profile_module_ts"],{

/***/ 80773:
/*!*******************************************************************!*\
  !*** ./src/app/pages/user-profile/user-profile-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserProfilePageRoutingModule": () => (/* binding */ UserProfilePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _user_profile_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user-profile.page */ 59539);




const routes = [
    {
        path: '',
        component: _user_profile_page__WEBPACK_IMPORTED_MODULE_0__.UserProfilePage
    },
    {
        path: 'change-password',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_user-profile_change-password_change-password_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./change-password/change-password.module */ 49638)).then(m => m.ChangePasswordPageModule)
    },
    {
        path: 'change-mobile',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_user-profile_change-mobile-number_change-mobile_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./change-mobile-number/change-mobile.module */ 79671)).then(m => m.ChangeMobilePageModule)
    }
];
let UserProfilePageRoutingModule = class UserProfilePageRoutingModule {
};
UserProfilePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], UserProfilePageRoutingModule);



/***/ }),

/***/ 44032:
/*!***********************************************************!*\
  !*** ./src/app/pages/user-profile/user-profile.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserProfilePageModule": () => (/* binding */ UserProfilePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);
/* harmony import */ var _user_profile_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-profile-routing.module */ 80773);
/* harmony import */ var _user_profile_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./user-profile.page */ 59539);









let UserProfilePageModule = class UserProfilePageModule {
};
UserProfilePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_0__.TadawulCommonUiModule,
            _user_profile_routing_module__WEBPACK_IMPORTED_MODULE_1__.UserProfilePageRoutingModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateModule.forChild()
        ],
        declarations: [_user_profile_page__WEBPACK_IMPORTED_MODULE_2__.UserProfilePage]
    })
], UserProfilePageModule);



/***/ }),

/***/ 59539:
/*!*********************************************************!*\
  !*** ./src/app/pages/user-profile/user-profile.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserProfilePage": () => (/* binding */ UserProfilePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _user_profile_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user-profile.page.html?ngResource */ 89886);
/* harmony import */ var _user_profile_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-profile.page.scss?ngResource */ 19358);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/helpers/settings */ 96892);
/* harmony import */ var _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/models/portfolio */ 65082);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var src_app_app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/app.component */ 20721);
/* harmony import */ var _events_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./../../events.service */ 31782);
/* harmony import */ var _helpers_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./../../helpers/constants */ 31777);
/* harmony import */ var _inma_helpers_translations__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @inma/helpers/translations */ 69353);
/* harmony import */ var _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @inma/helpers/cached */ 569);
/* harmony import */ var _inma_models_users__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @inma/models/users */ 17166);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! jquery */ 85139);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var _menu__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../menu */ 69626);
/* harmony import */ var _inma_models_symbol__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @inma/models/symbol */ 61202);
/* harmony import */ var _inma_models_market__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @inma/models/market */ 1874);
/* harmony import */ var _ionic_native_open_native_settings_ngx__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic-native/open-native-settings/ngx */ 21512);
/* harmony import */ var _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ionic-native/diagnostic/ngx */ 20593);






















let UserProfilePage = class UserProfilePage {
    constructor(sharedData, loadingCtrl, cdr, event, navCtrl, translate, openNativeSettings, platform, diagnostic, zone, document) {
        this.sharedData = sharedData;
        this.loadingCtrl = loadingCtrl;
        this.cdr = cdr;
        this.event = event;
        this.navCtrl = navCtrl;
        this.translate = translate;
        this.openNativeSettings = openNativeSettings;
        this.platform = platform;
        this.diagnostic = diagnostic;
        this.zone = zone;
        this.document = document;
        this.showChangePwdSuccess = false;
        this.showChangeMobileSuccess = false;
        this.MenuComponent = _menu__WEBPACK_IMPORTED_MODULE_12__.MenuComponent;
        this.firstLanguageChange = true;
        this.appLang = this.translate.currentLang;
        // Settings.getUserPreferences<string>(Settings.enableBiometricKey).subscribe(
        //   (val) => {
        //     if (val == null || val == "true") this.biometricEnabled = true;
        //     else this.biometricEnabled = false;
        //   }
        // );
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.getUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.enableBiometricKey).subscribe((val) => {
            if (val == 'true') {
                this.biometricEnabled = true;
            }
            else {
                this.biometricEnabled = false;
            }
            // if (val != null && val != "" && val == "true") this.biometricEnabled = true;
            // else this.biometricEnabled = false;
        });
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.getUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.preferedLanguageKey).subscribe((val) => {
            if (val == null || val == "ar")
                this.currentLanguage = "ar";
            else
                this.currentLanguage = "en";
        });
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.getUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.preferedThemeKey).subscribe((val) => {
            if (val == null || val == "light-theme")
                this.currentTheme = "light-theme";
            else
                this.currentTheme = "dark-theme";
        });
    }
    ngOnInit() {
        var _a, _b, _c, _d;
        this.platform.resume.subscribe(() => (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
            // this.diagnostic.isRegisteredForRemoteNotifications().then((data) => {alert("isRegisteredForRemoteNotifications>>>" + data) }).catch((error: any) =>alert(error));
            this.diagnostic.isRemoteNotificationsEnabled().then((data) => {
                this.zone.run(() => {
                    if (data == true) {
                        this.notificationEnabled = true;
                    }
                    else if (data == false) {
                        this.notificationEnabled = false;
                    }
                });
                _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.setUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.enableNotficationKey, this.notificationEnabled.toString());
                localStorage.setItem(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.enableNotficationKey, this.notificationEnabled.toString());
                src_app_app_component__WEBPACK_IMPORTED_MODULE_4__.AppComponent.initPushwoosh();
            }).catch((error) => console.error(error));
        }));
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.getUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.preferedThemeKey).subscribe((val) => {
            if (val == null || val == "light-theme")
                this.currentTheme = "light-theme";
            else
                this.currentTheme = "dark-theme";
        });
        if (this.translate.currentLang == 'ar') {
            this.userName = (_a = _inma_models_users__WEBPACK_IMPORTED_MODULE_9__.Users.current) === null || _a === void 0 ? void 0 : _a.nameAr;
        }
        else {
            this.userName = (_b = _inma_models_users__WEBPACK_IMPORTED_MODULE_9__.Users.current) === null || _b === void 0 ? void 0 : _b.nameEn;
        }
        this.gender = ((_c = _inma_models_users__WEBPACK_IMPORTED_MODULE_9__.Users.current) === null || _c === void 0 ? void 0 : _c.gender) ? (_d = _inma_models_users__WEBPACK_IMPORTED_MODULE_9__.Users.current) === null || _d === void 0 ? void 0 : _d.gender : 'male';
    }
    currentThemeChanged(event) {
        const lastCurrentTheme = this.currentTheme;
        this.currentTheme = event.detail.value;
        this.saveTheme();
        if (lastCurrentTheme != this.currentTheme) {
            _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.setTheme();
        }
    }
    ionViewWillEnter() {
        if (localStorage.getItem(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.enableNotficationKey) == "true" || localStorage.getItem(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.enableNotficationKey) == null) {
            this.notificationEnabled = true;
        }
        else {
            this.notificationEnabled = false;
        }
        let passwordchanged = this.sharedData.getSharedData("password_changed", false);
        if (passwordchanged) {
            this.showChangePwdSuccess = this.sharedData.getSharedData("password_changed", true);
        }
        else {
            this.showChangePwdSuccess = false;
        }
        let mobileChanged = this.sharedData.getSharedData("mobile_changed", false);
        if (mobileChanged) {
            this.showChangeMobileSuccess = this.sharedData.getSharedData("mobile_changed", true);
        }
        else {
            this.showChangeMobileSuccess = false;
        }
        if (this.platform.is("ios")) {
            this.notificationPermission = "application_details";
        }
        else if (this.platform.is("android")) {
            this.notificationPermission = "notification_id";
        }
    }
    currentLanguageChanged(event) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
            const lastCurrentLanguage = this.currentLanguage;
            this.currentLanguage = event.detail.value;
            // Settings.language = Number(this.currentLanguage == 'ar' ? 0 : 1);
            this.saveLanguage();
            _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.setLanguage();
            if (!this.firstLanguageChange) {
                // IONIC bug, we have to do it manually !
                jquery__WEBPACK_IMPORTED_MODULE_10__("ion-back-button").toggleClass("flip-x");
                setTimeout(() => {
                    _menu__WEBPACK_IMPORTED_MODULE_12__.MenuComponent.isLanguageToggled = !_menu__WEBPACK_IMPORTED_MODULE_12__.MenuComponent.isLanguageToggled;
                    this.cdr.detectChanges();
                }, 100);
                (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_8__.resetGlobalCaches)();
            }
            this.firstLanguageChange = false;
            setTimeout(() => {
                (0,_inma_helpers_translations__WEBPACK_IMPORTED_MODULE_7__.localizeApp)(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.language);
            }, 100);
            const loading = yield this.loadingCtrl.create({
                message: this.currentLanguage == 'ar' ? 'جاري تغيير لغة التطبيق' : 'changing app language',
                duration: 1000
            });
            loading.present();
            loading.onWillDismiss().then((data) => {
                this.event.publish('CHANGE_APP_LANG', this.currentLanguage);
            });
        });
    }
    // firstBiometricChange = true;
    saveBiometric(event) {
        // console.log(this.firstBiometricChange);
        // if (this.firstBiometricChange) {
        //   this.firstBiometricChange = false;
        //   return;
        // }
        //////
        if (event) {
            _inma_models_users__WEBPACK_IMPORTED_MODULE_9__.Users.current.biometricAuthenticate().subscribe((result) => {
                if (!result) {
                    this.biometricEnabled = false;
                    // this.firstBiometricChange = true;
                }
                else {
                    this.biometricEnabled = true;
                    _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.setUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.enableBiometricKey, this.biometricEnabled.toString());
                }
            });
        }
        else {
            _inma_models_users__WEBPACK_IMPORTED_MODULE_9__.Users.current.cancelUserBiometric().subscribe((result) => {
                if (!result) {
                    this.biometricEnabled = true;
                    // this.firstBiometricChange = false;
                }
                else {
                    this.biometricEnabled = false;
                    _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.setUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.enableBiometricKey, this.biometricEnabled.toString());
                }
            });
            // Biometric.delete().subscribe((result) => {
            //   debugger
            //   if (!result) setTimeout(() => {
            //     this.biometricEnabled = true;
            //     this.firstBiometricChange = true;
            //   }, 0);
            // });
        }
    }
    saveNotfication($event) {
        // let savedNotificationVal= localStorage.getItem(Settings.enableNotficationKey);
        // if(savedNotificationVal != this.notificationEnabled.toString()){
        this.openNativeSettings.open(this.notificationPermission).then(val => {
        });
        // }
    }
    saveLanguage() {
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.setUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.preferedLanguageKey, this.currentLanguage);
    }
    saveTheme() {
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.setUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.preferedThemeKey, this.currentTheme);
    }
    logout(serverSide = true) {
        // this.menu.close('menu');
        _inma_models_users__WEBPACK_IMPORTED_MODULE_9__.Users.logout(serverSide).subscribe(() => {
            (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_8__.resetCache)(_inma_models_portfolio__WEBPACK_IMPORTED_MODULE_3__.Portfolios, 'loadPortfolios');
            src_app_app_component__WEBPACK_IMPORTED_MODULE_4__.AppComponent.restart(() => {
                setTimeout(() => {
                    this.navCtrl.navigateRoot('login');
                }, 100);
            });
        });
    }
    changeLang() {
        if (this.translate.currentLang == 'en') {
            this.handleLanguagePreferences('ar');
        }
        else {
            this.handleLanguagePreferences('en');
        }
        // reset cached symbols names in previous lang
        (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_8__.resetCache)(_inma_models_symbol__WEBPACK_IMPORTED_MODULE_13__.Symbols, 'all');
        (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_8__.resetCache)(_inma_models_symbol__WEBPACK_IMPORTED_MODULE_13__.Symbols, 'allHashed');
        _inma_models_market__WEBPACK_IMPORTED_MODULE_14__.MarketModel.reset();
        this.showAppLangLoader();
    }
    handleLanguagePreferences(lang) {
        if (lang == 'ar') {
            this.translate.setDefaultLang('ar');
            this.translate.use('ar');
            this.document.documentElement.dir = 'rtl';
        }
        else if (lang == 'en') {
            this.translate.setDefaultLang('en');
            this.translate.use('en');
            this.document.documentElement.dir = 'ltr';
        }
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_2__.Settings.setUserPreferences(_helpers_constants__WEBPACK_IMPORTED_MODULE_6__.Constants._SETTINGS._PREFERRED_LANG, lang);
        localStorage.setItem(_helpers_constants__WEBPACK_IMPORTED_MODULE_6__.Constants._SETTINGS._PREFERRED_LANG, lang.toString());
    }
    showAppLangLoader() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingCtrl.create({
                message: this.appLang == 'ar' ? 'جاري تغيير لغة التطبيق' : 'changing app language',
                duration: 1000
            });
            loading.present();
            loading.onWillDismiss().then((data) => {
                this.event.publish('CHANGE_APP_LANG', this.currentLanguage);
            });
        });
    }
};
UserProfilePage.ctorParameters = () => [
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_11__.SharedDataService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_18__.LoadingController },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_19__.ChangeDetectorRef },
    { type: _events_service__WEBPACK_IMPORTED_MODULE_5__.EventsService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_18__.NavController },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_20__.TranslateService },
    { type: _ionic_native_open_native_settings_ngx__WEBPACK_IMPORTED_MODULE_15__.OpenNativeSettings },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_18__.Platform },
    { type: _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_16__.Diagnostic },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_19__.NgZone },
    { type: Document, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_19__.Inject, args: [_angular_common__WEBPACK_IMPORTED_MODULE_21__.DOCUMENT,] }] }
];
UserProfilePage = (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_19__.Component)({
        selector: 'tadawul-user-profile',
        template: _user_profile_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_user_profile_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:paramtypes", [src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_11__.SharedDataService,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_18__.LoadingController,
        _angular_core__WEBPACK_IMPORTED_MODULE_19__.ChangeDetectorRef,
        _events_service__WEBPACK_IMPORTED_MODULE_5__.EventsService,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_18__.NavController,
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_20__.TranslateService,
        _ionic_native_open_native_settings_ngx__WEBPACK_IMPORTED_MODULE_15__.OpenNativeSettings,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_18__.Platform,
        _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_16__.Diagnostic,
        _angular_core__WEBPACK_IMPORTED_MODULE_19__.NgZone,
        Document])
], UserProfilePage);



/***/ }),

/***/ 19358:
/*!**********************************************************************!*\
  !*** ./src/app/pages/user-profile/user-profile.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "ion-radio {\n  display: inline-block;\n}\n\n.mode-img {\n  width: 70px;\n}\n\ndiv.change-theme {\n  display: inline-block;\n  margin-right: 24px;\n  margin-left: 24px;\n}\n\nion-radio-group {\n  display: block;\n  text-align: center;\n}\n\nion-back-button {\n  color: white;\n}\n\np {\n  font-size: 11px;\n  color: #787878;\n  margin-bottom: 0px;\n}\n\nion-segment {\n  width: auto;\n}\n\nion-segment ion-segment-button {\n  min-width: 80px;\n}\n\n.change-success {\n  color: #2ebd85;\n  height: 40px;\n  border: solid 1px #2ebd85;\n  background-color: #deffef;\n  vertical-align: middle;\n  display: flex;\n  align-items: center;\n  margin: 16px;\n  padding: 16px;\n}\n\n:host > ion-content {\n  --background: #F4F8F8;\n}\n\n.theme-options {\n  display: flex;\n  justify-content: center;\n}\n\n.theme-options ion-item {\n  --border-color: transparent;\n  margin: 0 15px;\n}\n\n.theme-options ion-item::part(native) {\n  flex-direction: column !important;\n  border-bottom: 0;\n}\n\n.profile-info {\n  margin: 24px 0;\n  display: flex;\n  flex-direction: column;\n}\n\n.profile-info .profile-img {\n  width: 75px;\n  height: 75px;\n  border: 2px solid #afcdeb;\n  border-radius: 50%;\n  margin: auto;\n}\n\n.profile-info .profile-img.female {\n  border-color: #fb8d68;\n}\n\n.profile-info .profile-name {\n  color: #005157;\n  font-weight: bold;\n  font-size: 16px;\n  margin-top: 16px;\n}\n\n.logout-link {\n  text-align: center;\n  color: #f5455a;\n  font-weight: bold;\n  font-size: 14px;\n  --min-height: 55px !important;\n  border-top: 1px solid #e6eff0;\n  border-bottom: 1px solid #e6eff0;\n  --padding-start: 0;\n  --inner-border-width: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZXItcHJvZmlsZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBa0JBO0VBQ0kscUJBQUE7QUFqQko7O0FBMkJBO0VBQ0ksV0FBQTtBQXhCSjs7QUEyQkE7RUFDSSxxQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QUF4Qko7O0FBMkJBO0VBQ0ksY0FBQTtFQUNBLGtCQUFBO0FBeEJKOztBQTJCQTtFQUNJLFlBQUE7QUF4Qko7O0FBMkJBO0VBQ0ksZUFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQXhCSjs7QUE0QkE7RUFDSSxXQUFBO0FBekJKOztBQTJCSTtFQUNJLGVBQUE7QUF6QlI7O0FBNkJBO0VBQ0ksY0FBQTtFQUNBLFlBQUE7RUFDQSx5QkFBQTtFQUNBLHlCQUFBO0VBQ0Esc0JBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtBQTFCSjs7QUFxQ0E7RUFDSSxxQkFBQTtBQWxDSjs7QUFzQ0E7RUFDSSxhQUFBO0VBQ0EsdUJBQUE7QUFuQ0o7O0FBcUNJO0VBQ0ksMkJBQUE7RUFDQSxjQUFBO0FBbkNSOztBQXFDUTtFQUNJLGlDQUFBO0VBQ0EsZ0JBQUE7QUFuQ1o7O0FBd0NBO0VBQ0ksY0FBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtBQXJDSjs7QUF1Q0k7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FBckNSOztBQXVDUTtFQUNJLHFCQUFBO0FBckNaOztBQXlDSTtFQUNJLGNBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQXZDUjs7QUEyQ0E7RUFDSSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFFQSw2QkFBQTtFQUNBLDZCQUFBO0VBQ0EsZ0NBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0FBekNKIiwiZmlsZSI6InVzZXItcHJvZmlsZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBpb24taGVhZGVyIHtcbi8vICAgICBiYWNrZ3JvdW5kOiAjMDA1MTU3O1xuLy8gICAgIGNvbG9yOiAjRkZGRkZGO1xuXG4vLyAgICAgaW9uLXRvb2xiYXIge1xuLy8gICAgICAgICAtLWJhY2tncm91bmQ6ICMwMDUxNTc7XG4vLyAgICAgICAgIGNvbG9yOiAjRkZGRkZGO1xuLy8gICAgIH1cbi8vIH1cblxuLy8gaW9uLWl0ZW0ge1xuLy8gICAgIC0tdHJhbnNpdGlvbiAgOiBub25lO1xuLy8gICAgIC8vIC0tY29sb3IgICAgICAgOiAjMDA1MTU3O1xuLy8gICAgIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXR4dCk7XG4vLyAgICAgLS1ib3JkZXItY29sb3I6IHJnYmEoMjA1LCAyMjMsIDIyNSwgMC41KTtcbi8vICAgICAtLXBhZGRpbmctc3RhcnQ6IDBweDtcbi8vIH1cblxuaW9uLXJhZGlvIHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG59XG5cbi8vIC5pbWcge1xuLy8gICAgIHdpZHRoOiAzN3B4O1xuLy8gICAgIGhlaWdodDogODFweDtcbi8vICAgICBkaXNwbGF5OiBibG9jaztcbi8vICAgICBib3JkZXItcmFkaXVzOiA3cHg7XG4vLyB9XG5cbi5tb2RlLWltZyB7XG4gICAgd2lkdGg6IDcwcHg7XG59XG5cbmRpdi5jaGFuZ2UtdGhlbWUge1xuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICBtYXJnaW4tcmlnaHQ6IDI0cHg7XG4gICAgbWFyZ2luLWxlZnQ6IDI0cHg7XG59XG5cbmlvbi1yYWRpby1ncm91cCB7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG5pb24tYmFjay1idXR0b24ge1xuICAgIGNvbG9yOiB3aGl0ZTtcbn1cblxucCB7XG4gICAgZm9udC1zaXplOiAxMXB4O1xuICAgIGNvbG9yOiAjNzg3ODc4O1xuICAgIG1hcmdpbi1ib3R0b206IDBweDtcbn1cblxuXG5pb24tc2VnbWVudCB7XG4gICAgd2lkdGg6IGF1dG87XG5cbiAgICBpb24tc2VnbWVudC1idXR0b24ge1xuICAgICAgICBtaW4td2lkdGg6IDgwcHg7XG4gICAgfVxufVxuXG4uY2hhbmdlLXN1Y2Nlc3Mge1xuICAgIGNvbG9yOiAjMmViZDg1O1xuICAgIGhlaWdodDogNDBweDtcbiAgICBib3JkZXI6IHNvbGlkIDFweCAjMmViZDg1O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNkZWZmZWY7XG4gICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgbWFyZ2luOiAxNnB4O1xuICAgIHBhZGRpbmc6IDE2cHg7XG59XG5cblxuXG5cblxuXG5cblxuXG46aG9zdD5pb24tY29udGVudCB7XG4gICAgLS1iYWNrZ3JvdW5kOiAjRjRGOEY4O1xufVxuXG5cbi50aGVtZS1vcHRpb25zIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuXG4gICAgaW9uLWl0ZW0ge1xuICAgICAgICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gICAgICAgIG1hcmdpbjogMCAxNXB4O1xuXG4gICAgICAgICY6OnBhcnQobmF0aXZlKSB7XG4gICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uICFpbXBvcnRhbnQ7XG4gICAgICAgICAgICBib3JkZXItYm90dG9tOiAwO1xuICAgICAgICB9XG4gICAgfVxufVxuXG4ucHJvZmlsZS1pbmZvIHtcbiAgICBtYXJnaW46IDI0cHggMDtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG5cbiAgICAucHJvZmlsZS1pbWcge1xuICAgICAgICB3aWR0aDogNzVweDtcbiAgICAgICAgaGVpZ2h0OiA3NXB4O1xuICAgICAgICBib3JkZXI6IDJweCBzb2xpZCAjYWZjZGViO1xuICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgIG1hcmdpbjogYXV0bztcblxuICAgICAgICAmLmZlbWFsZSB7XG4gICAgICAgICAgICBib3JkZXItY29sb3I6ICNmYjhkNjg7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAucHJvZmlsZS1uYW1lIHtcbiAgICAgICAgY29sb3I6ICMwMDUxNTc7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICAgIG1hcmdpbi10b3A6IDE2cHg7XG4gICAgfVxufVxuXG4ubG9nb3V0LWxpbmsge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogI2Y1NDU1YTtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXNpemU6IDE0cHg7XG5cbiAgICAtLW1pbi1oZWlnaHQ6IDU1cHggIWltcG9ydGFudDtcbiAgICBib3JkZXItdG9wOiAxcHggc29saWQgI2U2ZWZmMDtcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U2ZWZmMDtcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDA7XG4gICAgLS1pbm5lci1ib3JkZXItd2lkdGg6IDA7XG59Il19 */";

/***/ }),

/***/ 89886:
/*!**********************************************************************!*\
  !*** ./src/app/pages/user-profile/user-profile.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<ion-header translucent>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button [text]=\"''\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{'userProfile.SETTINGS' | translate}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <div class=\"profile-info ion-text-center\">\n    <img class=\"profile-img\"\n      [src]=\"gender == 'female' ? '../../../assets/icon/gender-female.svg':'../../../assets/icon/gender-male.svg'\"\n      [ngClass]=\"gender == 'female' ? 'female': ''\" alt=\"\">\n    <div class=\"profile-name\">{{userName}}</div>\n  </div>\n\n  <div *ngIf=\"showChangePwdSuccess\" class='change-success'>\n    {{'userProfile.PASSWORD_CHANGE_SUCCESS' | translate}}\n  </div>\n  <div *ngIf=\"showChangeMobileSuccess\" class='change-success'>\n    {{'userProfile.MOBILE_CHANGE_SUCCESS' | translate}}\n  </div>\n\n\n\n  <ion-list class=\"section list-group\">\n    <ion-item button routerLink=\"change-mobile\">\n      <div class=\"menu-title\">{{'userProfile.CHANGE_MOBILE_NUMBER' | translate}}</div>\n    </ion-item>\n\n    <ion-item button routerLink=\"change-password\">\n      <div class=\"menu-title\">{{'userProfile.CHANGE_PASSWORD' | translate}}</div>\n    </ion-item>\n  </ion-list>\n\n\n\n  <ion-list class=\"section list-group\">\n    <ion-item>\n      <ion-label class=\"ion-text-wrap\">\n        <div class=\"menu-title\">{{'userProfile.ENABLE_BIOMETRIC' | translate}}</div>\n        <div class=\"menu-brief\">{{'userProfile.ENABLE_BIOMETRIC_DESCRIPTION' | translate}}</div>\n      </ion-label>\n      <ion-toggle slot=\"end\" name=\"kiwi\" color=\"success\" (ngModelChange)=\"saveBiometric($event)\"\n        [ngModelOptions]=\"{standalone: true}\" [(ngModel)]=\"biometricEnabled\"></ion-toggle>\n    </ion-item>\n    <ion-item>\n      <ion-label class=\"ion-text-wrap\">\n        <div class=\"menu-title\">{{'userProfile.ENABLE_NOTIFICATION' | translate}}</div>\n        <div class=\"menu-brief\">{{'userProfile.ENABLE_NOTIFICATION_DESCRIPTION' | translate}}</div>\n      </ion-label>\n      <ion-toggle slot=\"end\" name=\"kiwi\" color=\"success\" (click)=\"saveNotfication($event)\"\n        [(ngModel)]=\"notificationEnabled\"></ion-toggle>\n    </ion-item>\n    <ion-item>\n      <ion-label class=\"ion-text-wrap\">\n        <div class=\"menu-title\">{{'userProfile.CHANGE_LANGUAGE' | translate}}</div>\n        <div class=\"menu-brief\">{{'userProfile.CHANGE_LANGUAGE_DESCRIPTION' | translate}}</div>\n      </ion-label>\n      <ion-segment slot=\"end\" [(ngModel)]=\"appLang\" [ngModelOptions]=\"{standalone: true}\" (ionChange)=\"changeLang()\">\n        <ion-segment-button value=\"ar\">العربية</ion-segment-button>\n        <ion-segment-button value=\"en\">English</ion-segment-button>\n      </ion-segment>\n    </ion-item>\n  </ion-list>\n\n  <!-- <div class=\"section ion-padding\">\n    <ion-radio-group class=\"theme-options\" (ionChange)=\"currentThemeChanged($event)\" [value]=\"currentTheme\">\n      <ion-item>\n        <img class=\"mode-img\" src=\"../../../assets/icon/light-mode.svg\" alt=\"\">\n        <p>{{'userProfile.LIGHT' | translate}}</p>\n        <ion-radio mode=\"md\" value=\"light-theme\"></ion-radio>\n      </ion-item>\n      <ion-item>\n        <img class=\"mode-img\" src=\"../../../assets/icon/dark-mode.svg\" alt=\"\">\n        <p>{{'userProfile.DARK' | translate}}</p>\n        <ion-radio disabled mode=\"md\" value=\"dark-theme\"></ion-radio>\n      </ion-item>\n    </ion-radio-group>\n  </div> -->\n\n  <!-- <ion-item class=\"logout-link\" (click)=\"logout()\">\n    <ion-label>\n      {{'userProfile.SIGNOUT' | translate}}\n    </ion-label>\n  </ion-item> -->\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_user-profile_user-profile_module_ts.js.map