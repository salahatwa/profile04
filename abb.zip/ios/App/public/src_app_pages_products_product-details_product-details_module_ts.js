"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_products_product-details_product-details_module_ts"],{

/***/ 51064:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/products/product-details/product-details-routing.module.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductDetailsPageRoutingModule": () => (/* binding */ ProductDetailsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _product_details_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./product-details.page */ 85346);




const routes = [
    {
        path: '',
        component: _product_details_page__WEBPACK_IMPORTED_MODULE_0__.ProductDetailsPage
    }
];
let ProductDetailsPageRoutingModule = class ProductDetailsPageRoutingModule {
};
ProductDetailsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ProductDetailsPageRoutingModule);



/***/ }),

/***/ 68454:
/*!**************************************************************************!*\
  !*** ./src/app/pages/products/product-details/product-details.module.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductDetailsPageModule": () => (/* binding */ ProductDetailsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _product_details_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./product-details-routing.module */ 51064);
/* harmony import */ var _product_details_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./product-details.page */ 85346);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);









let ProductDetailsPageModule = class ProductDetailsPageModule {
};
ProductDetailsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _product_details_routing_module__WEBPACK_IMPORTED_MODULE_0__.ProductDetailsPageRoutingModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateModule.forChild()
        ],
        declarations: [_product_details_page__WEBPACK_IMPORTED_MODULE_1__.ProductDetailsPage]
    })
], ProductDetailsPageModule);



/***/ }),

/***/ 85346:
/*!************************************************************************!*\
  !*** ./src/app/pages/products/product-details/product-details.page.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductDetailsPage": () => (/* binding */ ProductDetailsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _product_details_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./product-details.page.html?ngResource */ 92861);
/* harmony import */ var _product_details_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./product-details.page.scss?ngResource */ 54846);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var _inma_models_products_products_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/models/products/products.model */ 37426);
/* harmony import */ var src_app_models_products_product_status__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/🌱models/products/product-status */ 69082);
/* harmony import */ var _inma_models_products_product_doings__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @inma/models/products/product-doings */ 50348);
/* harmony import */ var src_app_app_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/app.component */ 20721);











let ProductDetailsPage = class ProductDetailsPage {
    constructor(navCtrl, translate, sharedData) {
        this.navCtrl = navCtrl;
        this.translate = translate;
        this.sharedData = sharedData;
        this.products = _inma_models_products_products_model__WEBPACK_IMPORTED_MODULE_3__.Products;
        this.ProductStatus = src_app_models_products_product_status__WEBPACK_IMPORTED_MODULE_4__.ProductStatus;
        this.showLoader = false;
    }
    ngOnInit() {
        // this.sharedProduct = this.sharedData.getSharedData("sharedProduct", false);
        // console.log(this.sharedProduct);
        // Products.subscribableAccounts.subscribe((accounts) => {
        //   this.accounts = accounts;
        //   if (accounts) {
        //     this.account = this.accounts[0];
        //   }
        // });
    }
    ionViewWillEnter() {
        this.sharedProduct = this.sharedData.getSharedData("sharedProduct", false);
        console.log(this.sharedProduct);
        this.showLoader = true;
        _inma_models_products_products_model__WEBPACK_IMPORTED_MODULE_3__.Products.subscribableAccounts.subscribe((accounts) => {
            this.showLoader = false;
            this.accounts = accounts;
            if (accounts) {
                if (this.accounts[0].id == "") {
                    this.account = this.accounts[1];
                }
                else {
                    this.account = this.accounts[0];
                }
            }
        }, err => {
            console.log('HTTP Error', err);
            this.showLoader = false;
        });
    }
    subscribe() {
        this.sharedData.setSharedData(this.sharedProduct, "sharedProduct");
        this.sharedData.setSharedData(_inma_models_products_product_doings__WEBPACK_IMPORTED_MODULE_5__.ProductDoings.Subscribe, "sharedProductMode");
        this.navCtrl.navigateForward(['main/product-subscribe']);
        // this.router.navigate([page.url], { replaceUrl: true });
        // this.navCtrl.navigateRoot(['/product-subscribe']);
    }
    extendSubscription() {
        this.sharedData.setSharedData(this.sharedProduct, "sharedProduct");
        this.sharedData.setSharedData(_inma_models_products_product_doings__WEBPACK_IMPORTED_MODULE_5__.ProductDoings.Extend, "sharedProductMode");
        this.navCtrl.navigateForward(['main/product-subscribe']);
    }
    cancelSubscription() {
        this.showLoader = true;
        this.sharedData.setSharedData(_inma_models_products_product_doings__WEBPACK_IMPORTED_MODULE_5__.ProductDoings.Unsubscribe, "sharedProductMode");
        this.sharedProduct.do(this.sharedProduct.plans[0], this.account, false, _inma_models_products_product_doings__WEBPACK_IMPORTED_MODULE_5__.ProductDoings.Unsubscribe).subscribe({
            next: (subscriptionResult) => {
                console.log(subscriptionResult);
                this.showLoader = false;
                this.navCtrl.navigateForward(['main/product-subscribe-summary']);
            },
            error: (err) => {
                this.showLoader = false;
                console.log(err);
            }
        });
    }
    cancelAutomaticRenew() {
        this.showLoader = true;
        this.sharedData.setSharedData(_inma_models_products_product_doings__WEBPACK_IMPORTED_MODULE_5__.ProductDoings.DisableAutoRenew, "sharedProductMode");
        this.sharedProduct.do(this.sharedProduct.plans[0], this.account, false, _inma_models_products_product_doings__WEBPACK_IMPORTED_MODULE_5__.ProductDoings.DisableAutoRenew).subscribe({
            next: (subscriptionResult) => {
                console.log(subscriptionResult);
                this.showLoader = false;
                src_app_app_component__WEBPACK_IMPORTED_MODULE_6__.AppComponent.showError(subscriptionResult === null || subscriptionResult === void 0 ? void 0 : subscriptionResult.message);
                this.sharedProduct.autoRenew = false;
            },
            error: (err) => {
                this.showLoader = false;
                console.log(err);
            }
        });
    }
    enableAutomaticRenew() {
        this.showLoader = true;
        this.sharedData.setSharedData(_inma_models_products_product_doings__WEBPACK_IMPORTED_MODULE_5__.ProductDoings.EnableAutoRenew, "sharedProductMode");
        this.sharedProduct.do(this.sharedProduct.plans[0], this.account, true, _inma_models_products_product_doings__WEBPACK_IMPORTED_MODULE_5__.ProductDoings.EnableAutoRenew).subscribe({
            next: (subscriptionResult) => {
                this.showLoader = false;
                console.log(subscriptionResult);
                src_app_app_component__WEBPACK_IMPORTED_MODULE_6__.AppComponent.showError(subscriptionResult === null || subscriptionResult === void 0 ? void 0 : subscriptionResult.message);
                this.sharedProduct.autoRenew = true;
            },
            error: (err) => {
                this.showLoader = false;
                console.log(err);
            }
        });
    }
};
ProductDetailsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateService },
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_2__.SharedDataService }
];
ProductDetailsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'tadawul-product-details',
        template: _product_details_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_product_details_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateService, src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_2__.SharedDataService])
], ProductDetailsPage);



/***/ }),

/***/ 54846:
/*!*************************************************************************************!*\
  !*** ./src/app/pages/products/product-details/product-details.page.scss?ngResource ***!
  \*************************************************************************************/
/***/ ((module) => {

module.exports = ".box-shadow {\n  box-shadow: 0px 1px 5px 2px rgba(0, 0, 0, 0.1);\n}\n\n.custom-product-padding {\n  padding: 10px;\n}\n\n.product-detail-box {\n  align-items: center;\n  padding: 10px 5px;\n  height: 100%;\n}\n\n.product-detail-box ion-icon {\n  -webkit-margin-end: 4px;\n          margin-inline-end: 4px;\n}\n\nbody.dark :host .dark-text {\n  color: white !important;\n}\n\nion-toolbar {\n  --background: #005157;\n  --color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2R1Y3QtZGV0YWlscy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSw4Q0FBQTtBQUNKOztBQUVBO0VBQ0ksYUFBQTtBQUNKOztBQUVBO0VBQ0ksbUJBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7QUFDSjs7QUFDSTtFQUNJLHVCQUFBO1VBQUEsc0JBQUE7QUFDUjs7QUFHQTtFQUNJLHVCQUFBO0FBQUo7O0FBRUE7RUFDSSxxQkFBQTtFQUNBLGNBQUE7QUFDSiIsImZpbGUiOiJwcm9kdWN0LWRldGFpbHMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmJveC1zaGFkb3cge1xuICAgIGJveC1zaGFkb3c6IDBweCAxcHggNXB4IDJweCByZ2IoMCAwIDAgLyAxMCUpO1xufVxuXG4uY3VzdG9tLXByb2R1Y3QtcGFkZGluZyB7XG4gICAgcGFkZGluZzogMTBweDtcbn1cblxuLnByb2R1Y3QtZGV0YWlsLWJveCB7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBwYWRkaW5nOiAxMHB4IDVweDtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgXG4gICAgaW9uLWljb24ge1xuICAgICAgICBtYXJnaW4taW5saW5lLWVuZDogNHB4O1xuICAgIH1cbn1cblxuYm9keS5kYXJrIDpob3N0IC5kYXJrLXRleHQge1xuICAgIGNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuaW9uLXRvb2xiYXIge1xuICAgIC0tYmFja2dyb3VuZDogIzAwNTE1NztcbiAgICAtLWNvbG9yOiB3aGl0ZTtcbiAgfSJdfQ== */";

/***/ }),

/***/ 92861:
/*!*************************************************************************************!*\
  !*** ./src/app/pages/products/product-details/product-details.page.html?ngResource ***!
  \*************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\"></ion-back-button>\n    </ion-buttons>\n    <ion-title slot=\"start\">{{ sharedProduct?.name }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"image\" *ngIf=\"products.Images[sharedProduct?.id]?.length\">\n    <ion-slides pager=\"true\" [options]=\"slideOpts\">\n      <ion-slide *ngFor=\"let i of products.Images[sharedProduct?.id]\">\n        <!-- <h1>Slide 1</h1> -->\n        <img src=\"{{'assets/' + i}}\" />\n      </ion-slide>\n    </ion-slides>\n  </div>\n  <div class=\"product-content custom-product-padding\">\n    <div class=\"box-wrap\">\n      <div class=\"box-shadow ion-padding\">\n        <!-- <p> -->\n          <ion-text class=\"font-size-caption bold display-block dark-text\" color=\"primary\">\n            {{sharedProduct?.name}}\n          </ion-text>\n        <!-- </p>\n        <p> -->\n          <ion-text class=\"font-size-overline display-block dark-text\" color=\"primary\">\n            {{sharedProduct?.description}}\n          </ion-text>\n        <!-- </p> -->\n      </div>\n    </div>\n    <ion-row class=\"ion-margin-top\">\n      <!-- COL -->\n      <ion-col size=\"\">\n        <div class=\"box-shadow product-detail-box display-flex\">\n          <ion-icon name=\"cash-outline\" color=\"primary\"></ion-icon>\n          <div class=\"box-content\">\n            <ion-text class=\"font-size-overline display-block dark-text\" color=\"primary\">\n              {{'product.PRODUCT_PRICE' | translate}}\n            </ion-text>\n            <ion-text class=\"font-size-overline bold display-block dark-text\" color=\"success\">\n              {{sharedProduct?.plans[0]?.price}} {{translate.instant('product.'+ sharedProduct?.plans[0]?.currency)}} / {{sharedProduct?.plans[0]?.months}} {{((sharedProduct?.plans[0]?.months == 1) ? 'product.MONTH' : 'product.MONTHS') | translate}}\n            </ion-text>\n          </div>\n        </div>\n      </ion-col>\n      <!-- COL -->\n      <ion-col size=\"\">\n        <div class=\"box-shadow product-detail-box display-flex\">\n          <ion-icon name=\"bulb-outline\" color=\"primary\"></ion-icon>\n          <div class=\"box-content\">\n            <ion-text class=\"font-size-overline display-block dark-text\" color=\"primary\">\n                {{'product.PRODUCT_STATUS' | translate}}\n            </ion-text>\n            <ion-text class=\"font-size-overline bold display-block dark-text\" color=\"success\">\n                {{translate.instant('product.'+sharedProduct?.status)}}\n            </ion-text>\n          </div>\n        </div>\n      </ion-col>\n      <!-- COL -->\n      <ion-col size=\"5\" *ngIf=\"sharedProduct?.status === ProductStatus.Subscribed\">\n        <div class=\"box-shadow product-detail-box display-flex\">\n          <ion-icon name=\"calendar-outline\" color=\"primary\"></ion-icon>\n          <div class=\"box-content\">\n            <ion-text class=\"font-size-overline display-block dark-text\" color=\"primary\">\n              {{'product.START_END_DATE' | translate}}\n            </ion-text>\n            <ion-text class=\"font-size-overline bold display-block dark-text\" color=\"success\">\n                {{sharedProduct?.startDate}}\n            </ion-text>\n            <ion-text class=\"font-size-overline bold display-block dark-text\" color=\"success\">\n                {{sharedProduct?.endDate}}\n            </ion-text>\n          </div>\n        </div>\n      </ion-col>\n    </ion-row>\n\n    <div class=\"ion-margin-top\" *ngIf=\"sharedProduct?.autoRenew == true\">\n        <app-button \n          (clickAction)=\"cancelAutomaticRenew()\"\n          expand=\"block\" \n          size=\"\"\n          color=\"txt\"\n          fill=\"outline\"\n          shape=\"\"\n          type=\"button\"\n          >\n          {{'product.CANCEL_AUTOMATIC_SUBSCRIPTION' | translate}}\n        </app-button>\n    </div>\n    <div class=\"ion-margin-top\" *ngIf=\"sharedProduct?.autoRenew == false\">\n        <app-button \n          (clickAction)=\"enableAutomaticRenew()\"\n          expand=\"block\" \n          size=\"\"\n          color=\"\"\n          fill=\"outline\"\n          shape=\"\"\n          type=\"button\"\n          >\n          {{'product.ENABLE_AUTOMATIC_SUBSCRIPTION' | translate}}\n        </app-button>\n    </div>\n    <div>\n        <ion-row>\n          <ion-col *ngIf=\"sharedProduct?.status !== ProductStatus.Subscribed\">\n            <app-button \n              (clickAction)=\"subscribe()\"\n              expand=\"block\" \n              size=\"\"\n              color=\"success\"\n              fill=\"solid\"\n              shape=\"\"\n              type=\"button\"\n              >\n              {{'product.SUBSCRIBE' | translate}}\n            </app-button>\n          </ion-col>\n          <ion-col *ngIf=\"sharedProduct?.status === ProductStatus.Subscribed\">\n            <app-button \n              (clickAction)=\"extendSubscription()\"\n              expand=\"block\" \n              size=\"\"\n              color=\"success\"\n              fill=\"solid\"\n              shape=\"\"\n              type=\"button\"\n              >\n              {{'product.EXTEND_SUBSCRIPTION' | translate}}\n            </app-button>\n          </ion-col>\n          <ion-col *ngIf=\"sharedProduct?.status === ProductStatus.Subscribed\">\n            <app-button \n              (clickAction)=\"cancelSubscription()\"\n              expand=\"block\" \n              size=\"\"\n              color=\"danger\"\n              fill=\"solid\"\n              shape=\"\"\n              type=\"button\"\n              >\n              {{'product.CANCEL_SUBSCRIPTION' | translate}}\n            </app-button>\n          </ion-col>\n        </ion-row>\n      </div>\n  </div>\n  <tadawul-loader *ngIf=\"showLoader\"></tadawul-loader>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_products_product-details_product-details_module_ts.js.map