"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_pages_mutual-funds_mutual-fund-actions_mutual-fund-actions_page_ts"],{

/***/ 68975:
/*!************************************************!*\
  !*** ./src/app/enum/mutual-fund-types.enum.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundType": () => (/* binding */ MutualFundType)
/* harmony export */ });
var MutualFundType;
(function (MutualFundType) {
    MutualFundType[MutualFundType["SUBSCRIPTION"] = 1] = "SUBSCRIPTION";
    MutualFundType[MutualFundType["REDEMPTION"] = 2] = "REDEMPTION";
})(MutualFundType || (MutualFundType = {}));


/***/ }),

/***/ 4225:
/*!************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-fund-actions/mutual-fund-actions.page.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundActionsPage": () => (/* binding */ MutualFundActionsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _mutual_fund_actions_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-fund-actions.page.html?ngResource */ 71684);
/* harmony import */ var _mutual_fund_actions_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mutual-fund-actions.page.scss?ngResource */ 87963);
/* harmony import */ var _providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../providers/mutual-funds.service */ 1835);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_enum_mutual_fund_types_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/enum/mutual-fund-types.enum */ 68975);







let MutualFundActionsPage = class MutualFundActionsPage {
    constructor(modalCtrl, navCtrl, mutualFundsService) {
        this.modalCtrl = modalCtrl;
        this.navCtrl = navCtrl;
        this.mutualFundsService = mutualFundsService;
        this.MutualFundType = src_app_enum_mutual_fund_types_enum__WEBPACK_IMPORTED_MODULE_3__.MutualFundType;
        this.portfolioActions = [];
    }
    ngOnInit() {
    }
    navigate(type) {
        this.modalCtrl.dismiss().then(() => {
            if (type == src_app_enum_mutual_fund_types_enum__WEBPACK_IMPORTED_MODULE_3__.MutualFundType.SUBSCRIPTION) {
                this.mutualFundsService.setMutualFund(this.mutualFund);
                this.navCtrl.navigateForward(['main/mutual-funds-subscribe']);
            }
            else if (type == src_app_enum_mutual_fund_types_enum__WEBPACK_IMPORTED_MODULE_3__.MutualFundType.REDEMPTION) {
                this.mutualFundsService.setMutualFund(this.mutualFund);
                this.navCtrl.navigateForward(['main/mutual-funds-redemption']);
            }
        });
    }
};
MutualFundActionsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController },
    { type: _providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_2__.MutualFundsService }
];
MutualFundActionsPage.propDecorators = {
    mutualFund: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input }]
};
MutualFundActionsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'tadawul-mutual-fund-actions',
        template: _mutual_fund_actions_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_mutual_fund_actions_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController,
        _providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_2__.MutualFundsService])
], MutualFundActionsPage);



/***/ }),

/***/ 1835:
/*!***************************************************!*\
  !*** ./src/app/providers/mutual-funds.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsService": () => (/* binding */ MutualFundsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let MutualFundsService = class MutualFundsService {
    constructor() { }
    setMutualFund(mutualFund) {
        this.mutualFund = mutualFund;
    }
    getMutualFund() {
        return this.mutualFund;
    }
};
MutualFundsService.ctorParameters = () => [];
MutualFundsService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Injectable)({
        providedIn: 'root'
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__metadata)("design:paramtypes", [])
], MutualFundsService);



/***/ }),

/***/ 87963:
/*!*************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-fund-actions/mutual-fund-actions.page.scss?ngResource ***!
  \*************************************************************************************************/
/***/ ((module) => {

module.exports = ".close-icon-container {\n  -webkit-margin-start: 10px;\n          margin-inline-start: 10px;\n}\n\nion-item {\n  --min-height: 55px !important;\n  font-size: 13px;\n  font-weight: bold;\n  color: #005157;\n  border-bottom: 1px solid #e6eff0;\n  -webkit-margin-start: 16px;\n          margin-inline-start: 16px;\n  --padding-start: 0;\n  --inner-border-width: 0;\n}\n\nion-item .icon-container {\n  flex-shrink: 0 !important;\n  height: 40px;\n  width: 40px;\n  padding: 8px;\n  background: #e6eff0;\n  border-radius: 5px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\nion-item .icon-container svg {\n  width: 24px;\n  height: 24px;\n  stroke-width: 1.5;\n}\n\nion-item .icon-container svg * {\n  fill: none;\n  stroke: #005157;\n  stroke-miterlimit: 10;\n}\n\n.color-1 {\n  stroke: #65979a !important;\n}\n\n.color-2 {\n  stroke: #005157 !important;\n}\n\n.modal-drag {\n  width: 40px;\n  height: 5px;\n  border-radius: 100px;\n  background-color: #e6eff0;\n  display: block;\n  margin: 10px auto 0 auto;\n}\n\nion-header ion-toolbar:first-of-type {\n  padding: 0 !important;\n  --background: white !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm11dHVhbC1mdW5kLWFjdGlvbnMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQVlBO0VBQ0ksMEJBQUE7VUFBQSx5QkFBQTtBQVhKOztBQW9CQTtFQUNJLDZCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLGdDQUFBO0VBQ0EsMEJBQUE7VUFBQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsdUJBQUE7QUFqQko7O0FBbUJJO0VBQ0kseUJBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFqQlI7O0FBbUJRO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtBQWpCWjs7QUFtQlk7RUFDSSxVQUFBO0VBQ0EsZUFBQTtFQUNBLHFCQUFBO0FBakJoQjs7QUF1QkE7RUFDSSwwQkFBQTtBQXBCSjs7QUF1QkE7RUFDSSwwQkFBQTtBQXBCSjs7QUF1QkE7RUFDSSxXQUFBO0VBQ0EsV0FBQTtFQUNBLG9CQUFBO0VBQ0EseUJBQUE7RUFDQSxjQUFBO0VBQ0Esd0JBQUE7QUFwQko7O0FBdUJBO0VBQ0kscUJBQUE7RUFDQSw4QkFBQTtBQXBCSiIsImZpbGUiOiJtdXR1YWwtZnVuZC1hY3Rpb25zLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxuXG5cbi8vIGRpdi5pY29uLXN0YXJ0IHtcbi8vICAgICBkaXNwbGF5OiBncmlkO1xuLy8gICAgIHBsYWNlLWl0ZW1zOiBjZW50ZXI7XG4vLyAgICAgd2lkdGg6IDM1cHg7XG4vLyAgICAgaGVpZ2h0OiAzNXB4O1xuLy8gICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbi8vICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTZlZmYwO1xuLy8gfVxuXG4uY2xvc2UtaWNvbi1jb250YWluZXIge1xuICAgIG1hcmdpbi1pbmxpbmUtc3RhcnQ6IDEwcHg7XG59XG5cbi8vIC5pY29uIHtcbi8vICAgICBmb250LXNpemU6IDI1cHg7XG4vLyAgICAgY29sb3I6ICMzMzc0Nzk7XG4vLyB9XG5cblxuaW9uLWl0ZW0ge1xuICAgIC0tbWluLWhlaWdodDogNTVweCAhaW1wb3J0YW50O1xuICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBjb2xvcjogIzAwNTE1NztcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U2ZWZmMDtcbiAgICBtYXJnaW4taW5saW5lLXN0YXJ0OiAxNnB4O1xuICAgIC0tcGFkZGluZy1zdGFydDogMDtcbiAgICAtLWlubmVyLWJvcmRlci13aWR0aDogMDtcblxuICAgIC5pY29uLWNvbnRhaW5lciB7XG4gICAgICAgIGZsZXgtc2hyaW5rOiAwICFpbXBvcnRhbnQ7XG4gICAgICAgIGhlaWdodDogNDBweDtcbiAgICAgICAgd2lkdGg6IDQwcHg7XG4gICAgICAgIHBhZGRpbmc6IDhweDtcbiAgICAgICAgYmFja2dyb3VuZDogI2U2ZWZmMDtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICAgICAgICBzdmcge1xuICAgICAgICAgICAgd2lkdGg6IDI0cHg7XG4gICAgICAgICAgICBoZWlnaHQ6IDI0cHg7XG4gICAgICAgICAgICBzdHJva2Utd2lkdGg6IDEuNTtcbiAgICAgICAgXG4gICAgICAgICAgICAqIHtcbiAgICAgICAgICAgICAgICBmaWxsOiBub25lO1xuICAgICAgICAgICAgICAgIHN0cm9rZTogIzAwNTE1NztcbiAgICAgICAgICAgICAgICBzdHJva2UtbWl0ZXJsaW1pdDogMTA7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi5jb2xvci0xIHtcbiAgICBzdHJva2U6ICM2NTk3OWEgIWltcG9ydGFudDtcbn1cblxuLmNvbG9yLTIge1xuICAgIHN0cm9rZTogIzAwNTE1NyAhaW1wb3J0YW50O1xufVxuXG4ubW9kYWwtZHJhZyB7XG4gICAgd2lkdGg6IDQwcHg7XG4gICAgaGVpZ2h0OiA1cHg7XG4gICAgYm9yZGVyLXJhZGl1czogMTAwcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2U2ZWZmMDtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBtYXJnaW46IDEwcHggYXV0byAwIGF1dG87O1xufVxuXG5pb24taGVhZGVyIGlvbi10b29sYmFyOmZpcnN0LW9mLXR5cGUge1xuICAgIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcbiAgICAtLWJhY2tncm91bmQ6IHdoaXRlICFpbXBvcnRhbnQ7XG59Il19 */";

/***/ }),

/***/ 71684:
/*!*************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-fund-actions/mutual-fund-actions.page.html?ngResource ***!
  \*************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>{{'outstandingOrder.mutualFund' | translate}}</ion-title>\n  </ion-toolbar>\n\n</ion-header>\n\n<ion-content>\n  <ion-item (click)=\"navigate(MutualFundType.SUBSCRIPTION)\">\n    <div class=\"icon-container\" slot=\"start\">\n      <svg>\n        <use xlink:href=\"#icon-money-transfer\"></use>\n      </svg>\n    </div>\n    <ion-text>{{'mutualFund.SUBSCRIBE' | translate}}</ion-text>\n  </ion-item>\n  <ion-item (click)=\"navigate(MutualFundType.REDEMPTION)\">\n    <div class=\"icon-container\" slot=\"start\">\n      <svg>\n        <use xlink:href=\"#icon-wallet-info\"></use>\n      </svg>\n    </div>\n    <ion-text>{{'mutualFund.REDEMPTION' | translate}}</ion-text>\n  </ion-item>\n</ion-content>\n\n\n\n\n\n<svg xmlns=\"http://www.w3.org/2000/svg\" style=\"display: none;\">\n  <symbol id=\"icon-blocked-money\" viewBox=\"0 0 24 24\">\n    <g class=\"color-1\">\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\"\n        d=\"M2.4,10V7.5V5 c0-0.6,0.5-1,1-1h2.5h13h2.5c0.5,0,1,0.5,1,1v2.5v5V15c0,0.6-0.5,1-1,1h-2.5h-6.5\" />\n      <circle stroke-linecap=\"round\" stroke-miterlimit=\"10\" cx=\"12.4\" cy=\"10\" r=\"2.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M5.9,4L5.9,4 c0,1.9-1.6,3.5-3.5,3.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M18.9,4L18.9,4 c0,1.9,1.6,3.5,3.5,3.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M18.9,16 c0-1.9,1.6-3.5,3.5-3.5\" />\n    </g>\n    <g class=\"color-2\">\n      <path stroke-miterlimit=\"10\"\n        d=\"M8.1,20h-5c-0.8,0-1.5-0.7-1.5-1.5v-2 c0-0.8,0.7-1.5,1.5-1.5h5c0.8,0,1.5,0.7,1.5,1.5v2C9.6,19.3,8.9,20,8.1,20z\" />\n      <path stroke-miterlimit=\"10\" d=\"M7.6,15h-4v-1c0-1.1,0.9-2,2-2h0c1.1,0,2,0.9,2,2 V15z\" />\n    </g>\n  </symbol>\n\n  <symbol id=\"icon-money-transfer\" viewBox=\"0 0 24 24\">\n    <g class=\"color-2\">\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"1\" y1=\"3\" x2=\"11\" y2=\"3\" />\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"1\" y1=\"3\" x2=\"3.1\" y2=\"0.9\" />\n    </g>\n    <g class=\"color-1\">\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\"\n        d=\"M22,18H2 c-0.6,0-1-0.4-1-1V7c0-0.6,0.4-1,1-1h20c0.6,0,1,0.4,1,1v10C23,17.6,22.6,18,22,18z\" />\n      <circle stroke-linecap=\"round\" stroke-miterlimit=\"10\" cx=\"12\" cy=\"12\" r=\"2.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M4.5,6L4.5,6 c0,1.9-1.6,3.5-3.5,3.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M19.5,6L19.5,6 c0,1.9,1.6,3.5,3.5,3.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M1,14.5 c1.9,0,3.5,1.6,3.5,3.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M19.5,18 c0-1.9,1.6-3.5,3.5-3.5\" />\n    </g>\n    <g class=\"color-2\">\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"23\" y1=\"21\" x2=\"13\" y2=\"21\" />\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"23\" y1=\"21\" x2=\"20.9\" y2=\"23.1\" />\n    </g>\n  </symbol>\n\n  <symbol id=\"icon-money-stack\" viewBox=\"0 0 24 24\">\n    <g class=\"color-1\">\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M22,18H4\n  c-0.6,0-1-0.4-1-1V7c0-0.6,0.4-1,1-1h18c0.6,0,1,0.4,1,1v10C23,17.6,22.6,18,22,18z\" />\n      <circle stroke-linecap=\"round\" stroke-miterlimit=\"10\" cx=\"13\" cy=\"12\" r=\"2.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M6.5,6L6.5,6 c0,1.9-1.6,3.5-3.5,3.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M19.5,6L19.5,6 c0,1.9,1.6,3.5,3.5,3.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M3,14.5 c1.9,0,3.5,1.6,3.5,3.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M19.5,18 c0-1.9,1.6-3.5,3.5-3.5\" />\n    </g>\n    <g class=\"color-2\">\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M1,14.5V6.6 C1,5.2,2.2,4,3.6,4h15.9\" />\n    </g>\n  </symbol>\n\n  <symbol id=\"icon-wallet\" viewBox=\"0 0 24 24\">\n    <g class=\"color-1\">\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M20.5,20.5h-17c-1.1,0-2-0.9-2-2v-12h19 c1.1,0,2,0.9,2,2v10C22.5,19.6,21.7,20.5,20.5,20.5z\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M21.5,6.8V5.5c0-1.1-0.9-2-2-2h-16 c-1.1,0-2,0.9-2,2v3v8\" />\n    </g>\n    <g class=\"color-2\">\n      <circle stroke-linecap=\"round\" stroke-miterlimit=\"10\" cx=\"18.3\" cy=\"13.5\" r=\"1.5\" />\n    </g>\n  </symbol>\n\n  <symbol id=\"icon-wallet-info\">\n    <g class=\"color-1\">\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M13.7,19.5h6.8 c1.2,0,2-0.9,2-2v-10c0-1.1-0.9-2-2-2h-19v4.7\" />\n      <path stroke-miterlimit=\"10\" d=\"M21.5,5.8V4.5c0-1.1-0.9-2-2-2h-16 c-1.1,0-2,0.9-2,2v3\" />\n    </g>\n    <circle stroke-miterlimit=\"10\" cx=\"18.3\" cy=\"12.5\" r=\"1.5\" />\n    <g class=\"color-2\">\n      <circle stroke-miterlimit=\"10\" cx=\"6.5\" cy=\"16.5\" r=\"5\" />\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"6.5\" y1=\"16\" x2=\"6.5\" y2=\"19\" />\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"6.5\" y1=\"14\" x2=\"6.5\" y2=\"14\" />\n    </g>\n  </symbol>\n\n  <symbol id=\"icon-money-limit\" viewBox=\"0 0 24 24\">\n    <g class=\"color-1\">\n      <polyline stroke-miterlimit=\"10\" points=\"13.2,11.6 13.2,9.4 13.2,8.1 13.2,4.5 \" />\n      <polyline stroke-miterlimit=\"10\" points=\"1,4.5 1,9.5 1,14.5 1,19.5 \" />\n      <ellipse stroke-miterlimit=\"10\" cx=\"7.1\" cy=\"4.5\" rx=\"6.1\" ry=\"3.1\" />\n      <path stroke-miterlimit=\"10\"\n        d=\"M13.2,8.5c0,0.5-0.2,1-0.9,1.3 c-1.1,0.9-3.1,1.3-5.3,1.3s-4.3-0.6-5.3-1.3C1.2,9.5,1,9,1,8.5\" />\n      <path stroke-miterlimit=\"10\" d=\"M1,12.2c0,0.5,0.2,1,0.9,1.3 c1.1,0.9,3.1,1.3,5.3,1.3c1.5,0,2.9-0.2,3.9-0.6\" />\n      <path stroke-miterlimit=\"10\" d=\"M1,15.9c0,1.5,2.7,2.7,6.1,2.7 c1.5,0,2.8-0.2,3.9-0.6\" />\n      <path stroke-miterlimit=\"10\" d=\"M1,19.5c0,1.5,2.7,2.7,6.1,2.7 c2.3,0,4.4-0.6,5.4-1.5\" />\n    </g>\n    <g class=\"color-1\">\n      <circle stroke-linecap=\"round\" stroke-miterlimit=\"10\" cx=\"16.9\" cy=\"16.5\" r=\"6.1\" />\n    </g>\n\n    <g class=\"color-2 stroke-sm\">\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\"\n        d=\"M13.8,16.6 c0,0,1.6-0.3,4.3,2.8c0.6,0.7,1.1,0.5,1.4,0.3c0.1-0.1,0.2-0.3,0.2-0.4\" />\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"18.8\" y1=\"18.9\" x2=\"17.6\" y2=\"20.1\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\"\n        d=\"M14,19.3 c0,0.2,0.1,0.3,0.2,0.4c0.3,0.2,0.9,0.4,1.4-0.3c0.2-0.2,0.4-0.5,0.6-0.7\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M16.9,18.2 c2-1.9,3-1.6,3-1.6\" />\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"15\" y1=\"18.9\" x2=\"16.2\" y2=\"20.1\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\"\n        d=\"M15.2,14.3 c-0.1-0.1-0.1-0.3-0.1-0.4c0-0.5,0.4-0.9,0.9-0.9c0.3,0,0.5,0.1,0.7,0.3c0,0,0.1,0.1,0.1,0.2\" />\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"16.9\" y1=\"12.5\" x2=\"16.9\" y2=\"15.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\"\n        d=\"M16.3,16 c0.2-0.2,0.4-0.2,0.6-0.2c0.2,0,0.5,0.1,0.6,0.2\" />\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"16.1\" y1=\"14.7\" x2=\"16.9\" y2=\"13.8\" />\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"16.9\" y1=\"13.4\" x2=\"15.2\" y2=\"14.3\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\"\n        d=\"M16.9,13.4 c0-0.1,0.1-0.1,0.1-0.2c0.2-0.2,0.4-0.3,0.7-0.3c0.5,0,0.9,0.4,0.9,0.9c0,0.1,0,0.3-0.1,0.4\" />\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"17.7\" y1=\"14.7\" x2=\"16.9\" y2=\"13.8\" />\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"18.6\" y1=\"14.3\" x2=\"16.9\" y2=\"13.4\" />\n    </g>\n  </symbol>\n</svg>";

/***/ })

}]);
//# sourceMappingURL=default-src_app_pages_mutual-funds_mutual-fund-actions_mutual-fund-actions_page_ts.js.map