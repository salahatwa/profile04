import { Component, ViewChild, Output, EventEmitter, ElementRef, Input, ViewEncapsulation } from '@angular/core';
import * as $ from 'jquery';

const MIN_VALUE_TO_UNLOCK = 90;  // How much percentage the user should reach to make the unlock effect, max is 100 (=100%)
@Component({
  selector: 'unlocker',
  templateUrl: 'unlocker.html',
  styleUrls: ['unlocker.scss'],
  encapsulation: ViewEncapsulation.None
})
export class Unlocker {
  setIntID;
  @Output() unlocked: EventEmitter<boolean> = new EventEmitter();
  @Output() progress: EventEmitter<boolean> = new EventEmitter();

  @ViewChild('unlock') input: any;
  @Input() disabled2: boolean;

  constructor(private el: ElementRef) {
  }

  checkUnlock(evt: Event) {
    let theRange = Number(this.input.nativeElement.value);
    // if (theRange === (100 - MIN_VALUE_TO_UNLOCK)) {
    //   this.unlockAction();
    // } else {
      clearInterval(this.setIntID);
      this.setIntID = setInterval(() => {
        if (this.input.nativeElement.value < 100) {
          this.input.nativeElement.value = theRange++;
        } else {
          this.input.nativeElement.value = 100;
          this.wasUnlocked = false;
          clearInterval(this.setIntID);
        }
        this.onProgress(null);
      }, 1)
    // }
  }
  wasUnlocked: boolean = false;
  onProgress(evt: Event) {
    let progress = this.input.nativeElement.value;

    if (this.wasUnlocked == false && progress <= (100 - MIN_VALUE_TO_UNLOCK)) {
      this.unlockAction();
      this.wasUnlocked = true;
    }
    this.progress.emit(progress);
  }

  unlockAction() {
    this.unlocked.emit(true);
    $(this.el.nativeElement).fadeOut('fast', () => {
      this.input.nativeElement.value = 100;
      $(this.el.nativeElement).fadeIn('slow')
      this.onProgress(null);
    })
  }

  ngOnDestroy() {
    clearInterval(this.setIntID);
  }
}
