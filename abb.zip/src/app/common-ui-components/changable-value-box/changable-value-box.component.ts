import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'tadawul-changable-value-box',
  templateUrl: './changable-value-box.component.html',
  styleUrls: ['./changable-value-box.component.scss'],
})
export class ChangableValueBoxComponent implements OnInit {

  @Input() containerClass: string;
  @Input() textClass: string;
  @Input() boxValue: string;
  constructor() { }

  ngOnInit() {}

}
