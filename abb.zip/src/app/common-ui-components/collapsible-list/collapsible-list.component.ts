import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import fitty from 'fitty';

@Component({
  selector: 'tadawul-collapsible-list',
  templateUrl: './collapsible-list.component.html',
  styleUrls: ['./collapsible-list.component.scss'],
})
export class CollapsibleListComponent implements OnInit {

 // public item = { expanded: false };
  public changeBoxContainer: string;
@Input() cardTextOne: string;
@Input() cardTextTwo: string;
@Input() cardTextThree: string;
@Input() cardTextFour: string;
@Input() cardTextFive: any;
@Input() cardTextSeven: any;
@Input() headerList = [];
@Input() cardTextOneSecondLine: string;
@Input() cardTextOneThirdLine: string;
@Input() cardTextOneFourthLine: string;
@Input() arrow = true;
@Input() default :boolean = false;
@Input() showDefault :boolean = false;
@Input() statusColor: string;
@Input() formName: string;
@Input() colOneSize: string;
@Input() colTwoSize: string;
@Input() colThreeSize: string;
@Input() colFourSize: string;
@Input() colFiveSize: string;
@Input() colSixSize : string;
 @Input() colSevenSize : string;
 @Input() symbolName: string;
 @Input() componentName: string;
 @Input() headerFirstValue: number;


@Input() expand: boolean;
@Input() rowClass: string;
@Output() collabseClick = new EventEmitter();
public boxColor = '';


  constructor() { }

  ngOnInit() {

    // setTimeout(() => {
    //   fitty('#code-container .code-container', {
    //     minSize: 10,
    //     maxSize: 8,
    //     multiLine: false
    //   });
    //  }, 1000);

    if(this.formName=="mutualFund"){
      this.cardTextFive =parseFloat(this.cardTextFive);
    }

   if(this.formName === "outstanding"){
     if(this.cardTextFive === "Rejected" || this.cardTextFive === "مرفوض"){
      this.boxColor = "changeValueContainerRed"
     }
     else if(this.cardTextFive === "Filled" || this.cardTextFive === "تم التنفيذ"){
      this.boxColor = "changeValueContainerGreen"
     }
     else if(this.cardTextFive === "Queued" || this.cardTextFive === "قائم"){
      this.boxColor = "changeValueContainerSkyBlue"
     }
     else if(this.cardTextFive === "Partially filled" || this.cardTextFive === "منفذ جزئيا"){
      this.boxColor = "changeValueContainerOrange"
     }
     else if(this.cardTextFive === "Replaced" || this.cardTextFive === "معدل"){
      this.boxColor = "changeValueContainerPurple"
     }else{
      this.boxColor = "changeValueContainerGrey"
     }
    }else if(this.formName === "MFOutstanding"){
      this.boxColor = "changeValueContainerGreen"
    }
  }

  expandItem() {
    this.collabseClick.emit();
    // if (this.expand) {

    //   this.expand = false;

    // } else {
    //   this.expand = true;
    //   // this.items.map(listItem => {

    //   //   if (item == listItem) {

    //   //     listItem.expanded = !listItem.expanded;

    //   //   } else {

    //   //     listItem.expanded = false;

    //   //   }

    //   //   return listItem;

    //   // });

    // }

  }

  uncommafy(value) {
    if(value || value === 0 || value === '0') {
      return value.toString().replace(/,/g, '');
    }
    else {
      return;
    }
  }


}
