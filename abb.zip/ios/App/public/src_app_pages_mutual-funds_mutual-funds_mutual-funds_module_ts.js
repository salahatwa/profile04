"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_mutual-funds_mutual-funds_mutual-funds_module_ts"],{

/***/ 59598:
/*!********************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds/mutual-funds-routing.module.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsPageRoutingModule": () => (/* binding */ MutualFundsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _mutual_funds_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-funds.page */ 13236);




const routes = [
    {
        path: '',
        component: _mutual_funds_page__WEBPACK_IMPORTED_MODULE_0__.MutualFundsPage
    }
];
let MutualFundsPageRoutingModule = class MutualFundsPageRoutingModule {
};
MutualFundsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MutualFundsPageRoutingModule);



/***/ }),

/***/ 32067:
/*!************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds/mutual-funds.module.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsPageModule": () => (/* binding */ MutualFundsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _mutual_funds_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-funds-routing.module */ 59598);
/* harmony import */ var _mutual_funds_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mutual-funds.page */ 13236);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);
/* harmony import */ var src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/pipes/pipes.module */ 41041);










let MutualFundsPageModule = class MutualFundsPageModule {
};
MutualFundsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _mutual_funds_routing_module__WEBPACK_IMPORTED_MODULE_0__.MutualFundsPageRoutingModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateModule.forChild(),
            src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_3__.PipesModule
        ],
        declarations: [
            _mutual_funds_page__WEBPACK_IMPORTED_MODULE_1__.MutualFundsPage,
            // CommafyPipe
        ]
    })
], MutualFundsPageModule);



/***/ }),

/***/ 13236:
/*!**********************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds/mutual-funds.page.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsPage": () => (/* binding */ MutualFundsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _mutual_funds_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-funds.page.html?ngResource */ 2945);
/* harmony import */ var _mutual_funds_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mutual-funds.page.scss?ngResource */ 90341);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../providers/mutual-funds.service */ 1835);
/* harmony import */ var _inma_models_mutual_funds_mutual_funds_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/models/mutual-funds/mutual-funds.model */ 64501);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 19193);
/* harmony import */ var _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @inma/helpers/settings */ 96892);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 44661);












let MutualFundsPage = class MutualFundsPage {
    constructor(navCtrl, translate, mutualFundsService, sharedData) {
        this.navCtrl = navCtrl;
        this.translate = translate;
        this.mutualFundsService = mutualFundsService;
        this.sharedData = sharedData;
        this.showLoader = false;
    }
    ngOnInit() {
        _inma_models_mutual_funds_mutual_funds_model__WEBPACK_IMPORTED_MODULE_3__.MutualFunds.all.subscribe((mutualFunds) => {
            // this.mutualFunds = mutualFunds.filter(mf => mf.type === 'MF');
            this.mutualFunds = [];
            for (let i = 0; i < this.mutualFunds.length; i++) {
                this.mutualFunds.expanded = false;
            }
            const mutualFundsDetails = [];
            this.mutualFunds.forEach((mf) => {
                mutualFundsDetails.push(mf.details);
            });
            (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.combineLatest)(mutualFundsDetails).subscribe(() => {
                this.showLoader = false;
            });
        });
        this.headerListMenu = () => [{ title: this.translate.instant('mutualFund.MUTUAL_FUND_NAME'), size: '5' }, { title: this.translate.instant('mutualFund.LAST_PRICE'), size: '2' }, { title: this.translate.instant('mutualFund.VALUATION_DATE'), size: '2' }, { title: this.translate.instant('mutualFund.YEAR_TO_DAY_CHANGE'), size: '2' }];
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_5__.Settings.getUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_5__.Settings.preferedThemeKey).subscribe((val) => {
            if (val == null || val == "light-theme") {
                this.firstSegmentIcon = "assets/icon/mutualfund.png";
                this.secondSegmentIcon = "assets/icon/mutualfund.png";
            }
            else {
                this.firstSegmentIcon = "assets/icon/mutualfund-dark.svg";
                this.secondSegmentIcon = "assets/icon/mutualfund-dark.svg";
            }
        });
    }
    ionViewWillEnter() {
        let active = this.sharedData.getSharedData("MF_emptyState");
        console.log(active);
        this.showLoader = true;
        if (active === "endowment") {
            this.segmentChanged("two");
        }
        else {
            this.segmentChanged("one");
        }
        console.log(this.activeSegment);
    }
    collapsSymbole(item, dataArr) {
        for (let i = 0; i < dataArr.length; i++) {
            if (dataArr[i].id == item.id) {
                if (dataArr[i].expanded == true) {
                    dataArr[i].expanded = false;
                    return;
                }
                else {
                    dataArr[i].expanded = true;
                }
            }
            else {
                dataArr[i].expanded = false;
            }
        }
    }
    openSubscription(item) {
        this.showLoader = true;
        (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.combineLatest)([item.suitability])
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.finalize)(() => {
            this.showLoader = false;
        }))
            .subscribe((mfSuitability) => {
            if (mfSuitability && (mfSuitability === null || mfSuitability === void 0 ? void 0 : mfSuitability.length) > 0)
                item.mfSuitability = mfSuitability[0];
            this.mutualFundsService.setMutualFund(item);
            this.navCtrl.navigateForward(['main/mutual-funds-subscribe']);
        }, (err) => {
            console.log(err);
            item.error = err;
            this.mutualFundsService.setMutualFund(item);
            this.navCtrl.navigateForward(['main/mutual-funds-subscribe']);
        });
    }
    openDetails(item) {
        this.mutualFundsService.setMutualFund(item);
        this.navCtrl.navigateForward(['main/mutual-funds-details']);
    }
    openReports(item) {
        this.navCtrl.navigateForward(['main/reports', item.id]);
    }
    segmentChanged(event) {
        this.activeSegment = event;
        console.log(this.activeSegment);
        this.showLoader = true;
        if (event === "one") {
            _inma_models_mutual_funds_mutual_funds_model__WEBPACK_IMPORTED_MODULE_3__.MutualFunds.all.subscribe((mutualFunds) => {
                console.log(mutualFunds);
                if (mutualFunds) {
                    // this.mutualFunds = mutualFunds;
                    this.mutualFunds = mutualFunds.filter((mf) => mf.type === "MF");
                    const mutualFundsDetails = [];
                    if (this.mutualFunds.length > 0) {
                        this.mutualFunds.forEach((mf) => {
                            mutualFundsDetails.push(mf.details);
                            mutualFundsDetails.push(mf.isSubscribed);
                        });
                        (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.combineLatest)(mutualFundsDetails).subscribe(() => {
                            this.showLoader = false;
                        });
                    }
                    else {
                        this.showLoader = false;
                    }
                }
            });
            // Portfolios.allMutualFundPortfolios.subscribe(portfolios => {
            //   const mutualFundPortfolio = portfolios[0];
            //   mutualFundPortfolio.allMutualFunds.subscribe(mutualFunds => {
            //     console.log(mutualFunds);
            //     this.mutualFunds = mutualFunds.filter(mf => mf.type === 'MF');
            //   });
            // });
        }
        else if (event === "two") {
            _inma_models_mutual_funds_mutual_funds_model__WEBPACK_IMPORTED_MODULE_3__.MutualFunds.all.subscribe((mutualFunds) => {
                console.log(mutualFunds);
                this.mutualFunds = mutualFunds.filter((mf) => mf.type === "CF");
                // setTimeout(()=>{
                //   this.showLoader = false;
                // },2000);
                const mutualFundsDetails = [];
                this.mutualFunds.forEach((mf) => {
                    mutualFundsDetails.push(mf.details);
                });
                (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.combineLatest)(mutualFundsDetails).subscribe(() => {
                    this.showLoader = false;
                });
            });
            // Portfolios.allMutualFundPortfolios.subscribe(portfolios => {
            //   const mutualFundPortfolio = portfolios[0];
            //   mutualFundPortfolio.allMutualFunds.subscribe(mutualFunds => {
            //     console.log(mutualFunds);
            //     this.mutualFunds = mutualFunds.filter(mf => mf.type === 'CF');
            //   });
            // });
        }
    }
};
MutualFundsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateService },
    { type: _providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_2__.MutualFundsService },
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_4__.SharedDataService }
];
MutualFundsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        selector: "tadawul-mutual-funds",
        template: _mutual_funds_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_mutual_funds_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__metadata)("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateService, _providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_2__.MutualFundsService, src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_4__.SharedDataService])
], MutualFundsPage);



/***/ }),

/***/ 1835:
/*!***************************************************!*\
  !*** ./src/app/providers/mutual-funds.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsService": () => (/* binding */ MutualFundsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let MutualFundsService = class MutualFundsService {
    constructor() { }
    setMutualFund(mutualFund) {
        this.mutualFund = mutualFund;
    }
    getMutualFund() {
        return this.mutualFund;
    }
};
MutualFundsService.ctorParameters = () => [];
MutualFundsService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Injectable)({
        providedIn: 'root'
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__metadata)("design:paramtypes", [])
], MutualFundsService);



/***/ }),

/***/ 90341:
/*!***********************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds/mutual-funds.page.scss?ngResource ***!
  \***********************************************************************************/
/***/ ((module) => {

module.exports = "tadawul-collapsible-list {\n  --col-font-size: 10px;\n}\n\n.custom-loader {\n  background: rgba(0, 0, 0, 0.89);\n  color: white;\n  position: fixed;\n  z-index: 2;\n  left: 0;\n  right: 0;\n  top: 0;\n  bottom: 0;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.custom-loader .icon {\n  font-size: 30px;\n}\n\nion-toolbar {\n  --background: #005157;\n  --color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm11dHVhbC1mdW5kcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxxQkFBQTtBQUNKOztBQUVBO0VBQ0ksK0JBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLFVBQUE7RUFDQSxPQUFBO0VBQ0EsUUFBQTtFQUNBLE1BQUE7RUFDQSxTQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7QUFDSjs7QUFDSTtFQUNJLGVBQUE7QUFDUjs7QUFHQTtFQUNJLHFCQUFBO0VBQ0EsY0FBQTtBQUFKIiwiZmlsZSI6Im11dHVhbC1mdW5kcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJ0YWRhd3VsLWNvbGxhcHNpYmxlLWxpc3Qge1xuICAgIC0tY29sLWZvbnQtc2l6ZTogMTBweDtcbn1cblxuLmN1c3RvbS1sb2FkZXIge1xuICAgIGJhY2tncm91bmQ6IHJnYigwIDAgMCAvIDg5JSk7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIHBvc2l0aW9uOiBmaXhlZDtcbiAgICB6LWluZGV4OiAyO1xuICAgIGxlZnQ6IDA7XG4gICAgcmlnaHQ6IDA7XG4gICAgdG9wOiAwO1xuICAgIGJvdHRvbTogMDtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG5cbiAgICAuaWNvbiB7XG4gICAgICAgIGZvbnQtc2l6ZTogMzBweDtcbiAgICB9XG59XG5cbmlvbi10b29sYmFyIHtcbiAgICAtLWJhY2tncm91bmQ6ICMwMDUxNTc7XG4gICAgLS1jb2xvcjogd2hpdGU7XG4gIH0iXX0= */";

/***/ }),

/***/ 2945:
/*!***********************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds/mutual-funds.page.html?ngResource ***!
  \***********************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header translucent>\n  <ion-toolbar color=\"\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\"></ion-back-button>\n    </ion-buttons>\n    <ion-title slot=\"start\">{{ 'mutualFund.MUTUAL_FUNDS' | translate }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-row size=\"12\">\n    <ion-col size=\".1\"></ion-col>\n    <ion-col size=\"11.5\">\n      <tadawul-common-segment-group firstSegmentText=\"{{ 'mutualFund.INVESTMENT_FUNDS' | translate }}\"\n        secondSegmentText=\"{{ 'mutualFund.CHARITY_FUNDS' | translate }}\" [firstSegmentIcon]=\"firstSegmentIcon\"\n        [secondSegmentIcon]=\"secondSegmentIcon\" (segmentChange)=\"segmentChanged($event)\"\n        activeSegment=\"{{ activeSegment }}\">\n      </tadawul-common-segment-group>\n\n      <!-- <tadawul-grid-header\n    [headerList]=headerListMenu()\n    ></tadawul-grid-header> -->\n      <ion-row class=\"gridHeaderClass\" size=\"12\">\n        <ion-col style=\"text-align: start;\" size=\"3.8\">\n          <ion-label>{{'mutualFund.MUTUAL_FUND_NAME' | translate}}</ion-label>\n        </ion-col>\n        <ion-col style=\"text-align: center;\" size=\"2.3\">\n          <ion-label>{{'mutualFund.LAST_PRICE' | translate}}</ion-label>\n        </ion-col>\n        <ion-col style=\"text-align: center;\" size=\"2.5\">\n          <ion-label>{{'mutualFund.VALUATION_DATE' | translate}}</ion-label>\n        </ion-col>\n        <ion-col style=\"text-align: center;\" size=\"2.1\">\n          <ion-label>{{'mutualFund.YEAR_TO_DAY_CHANGE' | translate}}</ion-label>\n        </ion-col>\n      </ion-row>\n      <!-- INVESTMENT FUNDS -->\n      <!-- <div [hidden]=\"mutualFunds == ''\"> -->\n      <div class=\"investment-funds-segment\" *ngIf=\"activeSegment === 'one'\" class=\"collaps-border\">\n        <div *ngFor=\"let item of mutualFunds;let i = index;\">\n          <div>\n            <tadawul-collapsible-list [cardTextOne]=\"item.localizedName.toString()\"\n              [cardTextTwo]=\"((item?.details | async)?.lastPrice) | number:'1.0-2'\"\n              [cardTextThree]=\"(item?.details | async)?.lastPriceDate\"\n              [cardTextFive]=\"(((item?.details | async)?.yearToDayChange) | number:'1.0-2')\" [colOneSize]=\"3.8\"\n              [colTwoSize]=\"2.3\" [colThreeSize]=\"2.5\" [colFiveSize]=\"2.1\" [arrow]=\"false\" [expand]=\"item.expanded\"\n              (collabseClick)=\"collapsSymbole(item,mutualFunds)\" formName=\"mutualFund\"\n              [rowClass]=\"(i % 2 == 0) ? 'odd' : 'even'\">\n              <tadawul-stock-quick-view headerFirstText=\"{{ 'mutualFund.MUTUAL_FUND_TYPE' | translate }}\"\n                headerSecondText=\"{{ 'mutualFund.CURRENCY' | translate }}\"\n                headerThirdText=\"{{ 'mutualFund.SUBSCRIPTION_PRICE' | translate }}\"\n                [headerFourthText]=\"((item?.isSubscribed | async)? 'mutualFund.MIN_ADDITIONAL_SUBSCRIPTION':'mutualFund.MINIMUM_SUBSCRIPTION') | translate\"\n                [headerFirstValue]=\"((item?.isCharity) ? 'mutualFund.CHARITY_FUND_TYPE' : (item?.isClosed) ? 'mutualFund.CLOSED_FUND_TYPE' : (item?.isStandard) ? 'mutualFund.INVESTMENT_FUND_TYPE' : '') | translate\"\n                [headerSecondValue]=\"translate.instant( 'mutualFund.'+(item?.details | async)?.currency)\"\n                [headerThirdValue]=\"item.unitPrice | number:'1.0-2'\"\n                [headerFourthValue]=\"(item?.isSubscribed | async)?(item?.details | async)?.minAdditionalSubscription:(item?.details | async)?.minimumInitialSubscription + (item?.details | async)?.minimumInitialSubscriptionType\"\n                [firstBtnText]=\"((item?.isSubscribed | async)?'mutualFund.ADD_UNITS':'mutualFund.SUBSCRIBE') | translate \"\n                secondBtnText=\"{{ 'mutualFund.DETAILS' | translate }}\"\n                firstBtnColor=\"stockButtonGreen\"\n                secondBtnColor=\"stockButtonTransparent\" (firstBtnClick)=\"openSubscription(item)\"\n                (secondBtnClick)=\"openDetails(item)\">\n              </tadawul-stock-quick-view>\n            </tadawul-collapsible-list>\n          </div>\n        </div>\n      </div>\n\n      <!-- CHARITY FUNDS -->\n      <div class=\"endowment-funds-segment\" *ngIf=\"activeSegment === 'two'\" class=\"collaps-border\">\n        <div *ngFor=\"let item of mutualFunds\">\n          <div>\n            <tadawul-collapsible-list [cardTextOne]=\"item.name\"\n              [cardTextTwo]=\"((item?.details | async)?.lastPrice) | number:'1.0-2'\"\n              [cardTextThree]=\"(item?.details | async)?.lastPriceDate\"\n              [cardTextFive]=\"(((item?.details | async)?.yearToDayChange) | number:'1.0-2')\" [colOneSize]=\"3.8\"\n              [colTwoSize]=\"2.3\" [colThreeSize]=\"2.5\" [colFiveSize]=\"2.1\" formName=\"\" [arrow]=\"false\"\n              [expand]=\"item.expanded\" (collabseClick)=\"collapsSymbole(item,mutualFunds)\" formName=\"mutualFund\">\n              <tadawul-stock-quick-view headerFirstText=\"{{ 'mutualFund.MUTUAL_FUND_TYPE' | translate }}\"\n                headerSecondText=\"{{ 'mutualFund.CURRENCY' | translate }}\"\n                headerThirdText=\"{{ 'mutualFund.SUBSCRIPTION_PRICE' | translate }}\"\n                headerFourthText=\"{{ 'mutualFund.MINIMUM_SUBSCRIPTION' | translate }}\"\n                [headerFirstValue]=\"((item?.isCharity) ? 'mutualFund.CHARITY_FUND_TYPE' : (item?.isClosed) ? 'mutualFund.CLOSED_FUND_TYPE' : (item?.isStandard) ? 'mutualFund.INVESTMENT_FUND_TYPE' : '') | translate\"\n                [headerSecondValue]=\"(item?.details | async)?.currency\"\n                [headerThirdValue]=\"item.unitPrice | number:'1.0-2'\"\n                [headerFourthValue]=\"(item?.details | async)?.minimumInitialSubscription + (item?.details | async)?.minimumInitialSubscriptionType\"\n                firstBtnText=\"{{ 'mutualFund.SUBSCRIBE' | translate }}\"\n                secondBtnText=\"{{ 'mutualFund.DETAILS' | translate }}\" firstBtnColor=\"stockButtonGreen\"\n                secondBtnColor=\"stockButtonTransparent\" (firstBtnClick)=\"openSubscription(item)\"\n                (secondBtnClick)=\"openDetails(item)\">\n              </tadawul-stock-quick-view>\n            </tadawul-collapsible-list>\n          </div>\n        </div>\n      </div>\n    </ion-col>\n  </ion-row>\n\n  <!-- <ng-template #loading> -->\n  <tadawul-loader *ngIf=\"showLoader\"></tadawul-loader>\n  <!-- </ng-template> -->\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_mutual-funds_mutual-funds_mutual-funds_module_ts.js.map