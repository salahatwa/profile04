import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Http } from '@inma/helpers/http';
import { ModalController } from '@ionic/angular';
import { ContactSuccessPage } from './contact-success/contact-success.page'
import { Contact } from '@inma/models/contact-us/contact.model'
import { Translations } from '@inma/helpers/translations';
import { ContactUsTranslations } from './contact-us.translations';

@Component({
  selector: 'tadawul-contact-us',
  templateUrl: './contact-us.page.html',
  styleUrls: ['./contact-us.page.scss'],
})
export class ContactUsPage implements OnInit {

  constructor(private formBuilder: FormBuilder, public modalController: ModalController) {
    this.buildForm();
    this.getsubjects();
   }

  subjects: string[] = [];
  subject: string;
  title: string;
  content: string;
  email: string;

  submitted


  ngOnInit() {
  }

  form: FormGroup;
  buildForm() {
    this.form = this.formBuilder.group({
      subject: ['', Validators.compose([
        Validators.required
      ])],
      title: ['', Validators.compose([
        Validators.required
      ])],
      content: ['', Validators.compose([
        Validators.required
      ])],
      email: ['', Validators.compose([
        Validators.required,
        Validators.email
      ])]
    });
  }

  getsubjects(){
    Contact.getsubjects().subscribe(result => {
      result.forEach(s => {
        this.subjects.push(s.value)
      })
      this.form.patchValue({
        subject : this.subjects[0]
      })
    });

  }

  async presentSuccessModal() {
    const modal = await this.modalController.create({
      component: ContactSuccessPage,
      cssClass: ''
    });

    return await modal.present();
  }
  sendMessage(form:FormGroup) {
    console.log(this.form);
    this.submitted = true;
    if(!this.form.valid) {
      return;
    }
    Contact.send(
      this.form.value.title,
      this.form.value.content,
      this.form.value.subject,
      this.form.value.email
    ).subscribe( result => {
      console.log(result);
      this.form.reset();
      this.submitted = false;
      this.presentSuccessModal();

    });
  }
}

