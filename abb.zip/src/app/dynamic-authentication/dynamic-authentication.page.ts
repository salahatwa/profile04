import { TranslateService } from '@ngx-translate/core';
import { Component, OnInit } from '@angular/core';
import { Biometric } from '@inma/helpers/biometric';
import { Injector } from '@inma/helpers/injector';
import { Translations } from '@inma/helpers/translations';
import { Authentication } from '@inma/models/authentication/authentication.model';
import { Authentication2 } from '@inma/models/users/authentication';
import { AuthenticationGroup } from '@inma/models/users/authentication-group';
import { ModalController, NavController, NavParams } from '@ionic/angular';
import { TokenAuthenticationPage } from '../token-authentication/token-authentication.page';
import { BiometricAuthenticationPage } from './biometric-authentication/biometric-authentication.page';
import { DynamicAuthenticationTranslations } from './dynamic-authentication.translations';

@Component({
  selector: 'tadawul-dynamic-authentication',
  templateUrl: './dynamic-authentication.page.html',
  styleUrls: ['./dynamic-authentication.page.scss'],
})
export class DynamicAuthenticationPage {

  @Translations()
  t = DynamicAuthenticationTranslations;
  static opened: boolean;
  static authenticationGroups: Array<AuthenticationGroup>;

  get authenticationGroups() {
    return DynamicAuthenticationPage.authenticationGroups;
  }

  static selectedGroup: string;

  public get selectedGroup(): string {
    return DynamicAuthenticationPage.selectedGroup;
  }
  public set selectedGroup(value: string) {
    DynamicAuthenticationPage.selectedGroup = value;
  }
  static open() {
    if (Authentication2.touchIdAvailable && Biometric.isAvailableSync) {
      let authenticationGroup: AuthenticationGroup = this.authenticationGroups.find(group => group.groupName == Authentication2.biometricGroupNumber)
      this.goToBiometricPage(authenticationGroup, Authentication2.sourceAction);
    } else {
      const navCtrl = Injector.get(NavController);
      navCtrl.navigateForward("/dynamic-authentication");
    }
  }
  constructor(public navCtrl: NavController, private modalCtrl: ModalController, private translate: TranslateService) {

    // if (Authentication2.touchIdAvailable && Biometric.isAvailableSync) {
    //   let authenticationGroup: AuthenticationGroup = this.authenticationGroups.find(group => group.groupName == Authentication2.biometricGroupNumber)
    //   this.goToBiometricPage(authenticationGroup, Authentication2.sourceAction);
    // }
  }

  ionViewDidLoad() {
    this.selectedGroup = Authentication2.smsGroupNumber;
  }

  goToTokenPage() {
    DynamicAuthenticationPage.goToTokenPage();
  }

  static goToTokenPage() {

    let selectedAuthenticationGroup: AuthenticationGroup;

    for (var i = 0; i < this.authenticationGroups.length; i++) {
      if (this.authenticationGroups[i].groupName == this.selectedGroup)
        selectedAuthenticationGroup = this.authenticationGroups[i];
    }

    if (this.selectedGroup == Authentication2.biometricGroupNumber && Biometric.isAvailableSync) {
      DynamicAuthenticationPage.goToBiometricPage(selectedAuthenticationGroup, Authentication2.sourceAction);
    }
    else {
      Authentication2.generateAuthenticationToken(this.selectedGroup)
        .subscribe(async (result) => {
          TokenAuthenticationPage.group = selectedAuthenticationGroup;
          const modalCtrl = Injector.get(ModalController);
          const tokenAuthenticationModal = await modalCtrl.create({
            id: 'TOKEN_MODAL',
            component: TokenAuthenticationPage,
            cssClass: 'auto-height-modal',
            swipeToClose: true
          });
          return await tokenAuthenticationModal.present();
        });
    }

  }

  // isStored = false;
  static async goToBiometricPage(authenticationGroup: AuthenticationGroup, action: string) {

    this.opened = true;
    if (!Biometric.type) {
      this.handleTokenPage();
    }

    Biometric.verify("Verify" + (action == "Authenticate" ? action : "Other")).subscribe(result => {
      if (result) {
        if (result == "NOT_STORED" || result == "NOT_VERIFIED" || result == "CANCELLED" || result?.startsWith('Error')) {
          this.handleTokenPage();
        } else {
          var storedUsername = result.split('#:#')[0];
          var storedKey = result.split('#:#')[1];
          this.authenticateBiometric(authenticationGroup,storedUsername, storedKey)
        }
      }
      else {
        if (this.opened) {
          Biometric.delete().subscribe();
          this.handleTokenPage();
        }
      }
    });

  }

  static handleTokenPage() {
    this.opened = false;
    this.selectedGroup = Authentication2.smsGroupNumber;
    this.goToTokenPage();
  }

  static authenticateBiometric(authenticationGroup: AuthenticationGroup,storedUsername, storedKey) {
    console.log("Login key " + storedKey);
    Authentication.encrypt(storedKey).subscribe(encryptedKey => {
      authenticationGroup.methods[0].value = encryptedKey;
      console.log("Login Key encrypted" + encryptedKey);


      Authentication2.authenticateSourceAction(authenticationGroup.groupName, authenticationGroup.methods)
        .subscribe(response => {

          if (response) {
            Authentication2.dynamicAuthenticationSubject.next(response);
          }
          else {
            Authentication2.dynamicAuthenticationSubject.error(response);
          }
          Authentication2.dynamicAuthenticationSubject.complete();

        });
    });
  }

  // static closeBiometricAuthentication(isSuccess = null) {
  //   setTimeout(() => {
  //     this.opened = false;
  //     this.modalCtrl.dismiss(isSuccess, null, 'biometric-authentication-page');
  //   }, 500);
  // }
}
