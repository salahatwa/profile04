"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_portfolios_portfolios_module_ts"],{

/***/ 86422:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/portfolios/portfolio-detail/portfolio-detail.component.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PortfolioDetailComponent": () => (/* binding */ PortfolioDetailComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _portfolio_detail_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./portfolio-detail.component.html?ngResource */ 56021);
/* harmony import */ var _portfolio_detail_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./portfolio-detail.component.scss?ngResource */ 90149);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/models/portfolio */ 65082);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _order_order_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../order/order.page */ 28798);
/* harmony import */ var src_app_providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/providers/mutual-funds.service */ 1835);
/* harmony import */ var _inma_helpers_clipboard__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @inma/helpers/clipboard */ 71286);
/* harmony import */ var _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @inma/helpers/settings */ 96892);













let PortfolioDetailComponent = class PortfolioDetailComponent {
    constructor(sharedData, navCtrl, router, translate, ngZone, loadingCtrl, mutualFundsService, route) {
        this.sharedData = sharedData;
        this.navCtrl = navCtrl;
        this.router = router;
        this.translate = translate;
        this.ngZone = ngZone;
        this.loadingCtrl = loadingCtrl;
        this.mutualFundsService = mutualFundsService;
        this.route = route;
        this.Number = Number;
        this.symbolArray = [];
        this.sukuk_arr = null;
        this.symbols_arr = null;
        this.charitiesMutualFundsArr = [];
        this.standardMutualFundsArr = [];
        this.detailPageMarketValue = this.translate.instant('portfolio.marketValueDetailPage');
        this.symbolTabType = 'SYMBOLS';
        this.activeSegment = 'INV';
        // public symbolGridHeaderList = () => [{title:this.translate.instant('portfolio.companyName,size:'5'},{title:this.translate.instant('portfolio.quantity,size:''} ,{title:this.translate.instant('portfolio.costAverage,size:''} ,{title:this.translate.instant('portfolio.lastPrice,size:''},{title:this.translate.instant('portfolio.ProfitLossUnrealized,size:'2.5'}];
        // public mutualFundHeaderList = () => [{title:this.translate.instant('portfolio.fundName,size:'5'},{title:this.translate.instant('portfolio.mutualFundUnits,size:''} ,{title:this.translate.instant('portfolio.priceAverage,size:''} ,{title:this.translate.instant('portfolio.totalCost,size:''} ];
        this.symbolGridHeaderList = () => [{ title: this.translate.instant('portfolio.companyName'), size: '4.7' }, { title: this.translate.instant('portfolio.quantity'), size: '1.6' }, { title: this.translate.instant('portfolio.costAverage'), size: '1.4' }, { title: this.translate.instant('portfolio.lastPrice'), size: '1.4' }, { title: this.translate.instant('portfolio.ProfitLossUnrealized'), size: '1.9' }];
        this.mutualFundHeaderList = () => [{ title: this.translate.instant('portfolio.fundName'), size: '4.5' }, { title: this.translate.instant('portfolio.mutualFundUnits'), size: '2' }, { title: this.translate.instant('portfolio.priceAverage'), size: '1.8' }, { title: this.translate.instant('portfolio.totalCost'), size: '2.5' }];
        this.route.params.subscribe(val => {
            setTimeout(() => {
                this.ngOnInit();
            }, 100);
        });
    }
    symbolSlidesChanged() {
        this.symbolSlides.getActiveIndex().then((idx) => {
            if (idx == 0) {
                this.symbolTabType = 'SYMBOLS';
            }
            else {
                this.symbolTabType = 'SUKUK';
            }
        });
    }
    symbolSegmentChanged() {
        if (this.symbolTabType == 'SYMBOLS') {
            this.symbolSlides.slideTo(0);
        }
        else {
            this.symbolSlides.slideTo(1);
        }
    }
    fundSlidesChanged() {
        this.fundSlides.getActiveIndex().then((idx) => {
            if (idx == 0) {
                this.activeSegment = 'INV';
            }
            else if (idx == 1) {
                this.activeSegment = 'FUND';
            }
            else {
                this.activeSegment = 'CLOSEDFUND';
            }
        });
    }
    fundSegmentChanged() {
        if (this.activeSegment == 'INV') {
            this.fundSlides.slideTo(0);
        }
        else if (this.activeSegment == 'FUND') {
            this.fundSlides.slideTo(1);
        }
        else {
            this.fundSlides.slideTo(2);
        }
    }
    ngOnInit() {
        this.setCurrentPortfolio();
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_7__.Settings.getUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_7__.Settings.preferedThemeKey).subscribe(val => {
            if (val == null || val == "light-theme") {
                this.dark = false;
            }
            else {
                this.dark = true;
            }
        });
    }
    collapsSymbole(item, dataArr) {
        for (let i = 0; i < dataArr.length; i++) {
            if (dataArr[i].id == item.id) {
                if (dataArr[i].expanded == true) {
                    dataArr[i].expanded = false;
                    return;
                }
                else {
                    dataArr[i].expanded = true;
                }
            }
            else {
                dataArr[i].expanded = false;
            }
        }
    }
    setCurrentPortfolio() {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p;
        this.portfolio = this.sharedData.getSharedData("sharedPortfolio", false);
        if (this.portfolio) {
            if (((_a = this.portfolio) === null || _a === void 0 ? void 0 : _a.tradeSecurties) && ((_c = (_b = this.portfolio) === null || _b === void 0 ? void 0 : _b.tradeSecurties) === null || _c === void 0 ? void 0 : _c.length) > 0) {
                this.symbols_arr = (_e = (_d = this.portfolio) === null || _d === void 0 ? void 0 : _d.tradeSecurties) === null || _e === void 0 ? void 0 : _e.filter((s) => s.securityType == 'STOCK');
                this.sukuk_arr = (_g = (_f = this.portfolio) === null || _f === void 0 ? void 0 : _f.tradeSecurties) === null || _g === void 0 ? void 0 : _g.filter((s) => s.securityType == 'BOND');
            }
            if (((_h = this.portfolio) === null || _h === void 0 ? void 0 : _h._MFDetails) && ((_k = (_j = this.portfolio) === null || _j === void 0 ? void 0 : _j._MFDetails) === null || _k === void 0 ? void 0 : _k.length) > 0) {
                this.standardMutualFundsArr = (_m = (_l = this.portfolio) === null || _l === void 0 ? void 0 : _l._MFDetails) === null || _m === void 0 ? void 0 : _m.filter((mf) => mf.type == 'MF');
                this.charitiesMutualFundsArr = (_p = (_o = this.portfolio) === null || _o === void 0 ? void 0 : _o._MFDetails) === null || _p === void 0 ? void 0 : _p.filter((mf) => mf.type == 'CF');
            }
            this.profitLoss = Number(this.portfolio._totalLoss);
            this.opendFrom = this.sharedData.getSharedData("opend", false);
            this.getPortfolioData();
        }
        else {
            this.router.navigateByUrl('tabs/home');
        }
    }
    // public x() {
    //   this.ngZone.run(() => {
    //     this.portfolio = this.sharedData.getSharedData("sharedPortfolio",false);
    //   //console.log("this.portfolio>>>>>>>>>>>>>"+this.portfolio)
    //   this.getPortfolioData();
    //   });
    // }
    uncommafy(value) {
        if (value) {
            return value.toString().replace(/,/g, '');
        }
        else {
            return;
        }
    }
    copyText(txt) {
        if (txt) {
            _inma_helpers_clipboard__WEBPACK_IMPORTED_MODULE_6__.Clipboard.copy(txt);
        }
    }
    getPortfolioData() {
        // this.portfolio.buyingPower.subscribe(buyingPower => {
        //   console.log('buyingPower>>>>>>>>>>' + buyingPower);
        //   this.portfolio.buyingPowerValue=buyingPower;
        //   console.log('allStandardPortfolios>>>>>>>>>>' + this.portfolio);
        // });
        if (this.portfolio._type == _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_3__.PortfolioType.MUTUAL_FUND) {
            this.detailPageMarketValue = this.translate.instant('portfolio.mutualFundMarketValue');
            // this.portfolio.standardMutualFunds.subscribe(standardMutualFunds => {
            //   const mutualFund = standardMutualFunds[0];
            //   this.standardMutualFundsArr = standardMutualFunds;
            //   this.owend = this.translate.instant('portfolio.owendFunds;
            // });
        }
        else if (this.portfolio._type == _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_3__.PortfolioType.STANDARD_PORTFOLIO) {
            this.detailPageMarketValue = this.translate.instant('portfolio.marketValueDetailPage');
            this.owend = this.translate.instant('portfolio.owendShares');
            // this.portfolio.symbols.subscribe(symbol => {
            //    this.getSymbolDetail(symbol);
            //  });
        }
    }
    getSymbolDetail(symbol) {
        // let symbolArray = [];
        // tslint:disable-next-line: prefer-for-of
        this.symbolArray = [];
        for (let i = 0; i < symbol.length; i++) {
            const obj = {};
            console.log('portfolioID>>>>>>>>' + symbol[i].id);
            obj.id = symbol[i].id;
            obj.gainLossRealized = symbol[i].gainLossRealized;
            obj.gainLossPercentageRealized = symbol[i].gainLossPercentageRealized;
            obj.gainLossUnrealized = symbol[i].gainLossUnrealized;
            obj.gainLossPercentageUnrealized = symbol[i].gainLossPercentageUnrealized;
            obj.costTotal = symbol[i].costTotal;
            obj.costAverage = symbol[i].costAverage;
            obj.marketValue = symbol[i].marketValue;
            obj.symbolName = symbol[i].symbolName;
            obj.symbol = symbol[i];
            obj.securityType = symbol[i].securityType;
            symbol[i].name.subscribe(name => {
                console.log('name>>>>>>>>' + name);
                //obj.name = name;
            });
            symbol[i].parameters.subscribe(parameters => {
                console.log('parameters>>>>>>>>' + parameters);
                // obj.parameters = parameters;
            });
            symbol[i].abbreviation.subscribe(abbreviation => {
                console.log('abbreviation>>>>>>>>' + abbreviation);
                obj.abbreviation = abbreviation;
            });
            console.log('quantity>>>>>>>>' + symbol[i].ownedQuantity);
            obj.ownedQuantity = symbol[i].ownedQuantity;
            symbol[i].price.subscribe(price => {
                console.log(price);
                obj.price = price;
            });
            symbol[i].change.subscribe(change => {
                console.log('change>>>>>>>>' + change);
                obj.change = change;
            });
            this.symbolArray.push(obj);
        }
        this.symbols_arr = this.symbolArray.filter((s) => s.securityType == 'STOCK');
        this.sukuk_arr = this.symbolArray.filter((s) => s.securityType == 'BOND');
        console.log(this.symbolArray);
    }
    Back() {
        if (this.opendFrom == "portfolio") {
            this.navCtrl.navigateBack('/portfolios/home');
        }
        else {
            this.navCtrl.navigateBack('main/tabs');
            // this.router.navigate(['tadawul-home/home']);
        }
    }
    openBuySellSymbols(symbol, operation) {
        this.sharedData.setSharedData(symbol, 'sharedSymbol');
        this.sharedData.setSharedData(operation, 'operation');
        this.navCtrl.navigateForward('order');
        _order_order_page__WEBPACK_IMPORTED_MODULE_4__.OrderPage.initialize();
    }
    openSymbol(item) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingCtrl.create({});
            loading.present();
            _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_3__.Portfolios.all.subscribe((res) => {
                _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_3__.Portfolios.current = res.find((p) => p.id == this.portfolio._portfolioNumber);
                _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_3__.Portfolios.current.symbols.subscribe(symbol => {
                    symbol = symbol.filter((s) => s.id == item.symbol.code);
                    this.sharedData.setSharedData({ symbol: symbol[0] }, 'sharedSymbol');
                    loading.dismiss();
                    this.navCtrl.navigateForward(['/symbol']);
                });
            });
            // this.sharedData.setSharedData(symbol, 'sharedSymbol');
            // this.navCtrl.navigateForward('symbol');
            // OrderPage.initialize();
        });
    }
    openSubscription(item) {
        console.log(item);
        this.mutualFundsService.setMutualFund(item);
        this.navCtrl.navigateForward(['/mutual-funds-subscribe']);
    }
    openRedemption(item) {
        this.mutualFundsService.setMutualFund(item);
        this.navCtrl.navigateForward(['/mutual-funds-redemption']);
    }
    sellAll() {
        console.log("Sell All");
    }
    goToMutualFunds(dist) {
        this.sharedData.setSharedData('investment', 'MF_emptyState');
        this.navCtrl.navigateForward('/mutual-funds');
    }
    setDefaultPortfolio() {
        // Portfolios.manageDefaultPortfolio(this.portfolio.id, this.portfolio.type, 'SET_DEFAULT');
        // this.portfolio.defaultPortfolio = true;
    }
    resetDefaultPortfolio() {
        // Portfolios.manageDefaultPortfolio(this.portfolio.id, this.portfolio.type, 'RESET_DEFAULT');
        // this.portfolio.defaultPortfolio = false;
    }
};
PortfolioDetailComponent.ctorParameters = () => [
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_2__.SharedDataService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.NavController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.Router },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__.TranslateService },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.NgZone },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.LoadingController },
    { type: src_app_providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_5__.MutualFundsService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute }
];
PortfolioDetailComponent.propDecorators = {
    symbolSlides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.ViewChild, args: ['symbolSlides',] }],
    fundSlides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.ViewChild, args: ['fundSlides',] }]
};
PortfolioDetailComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.Component)({
        selector: 'tadawul-portfolio-detail',
        template: _portfolio_detail_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_portfolio_detail_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__metadata)("design:paramtypes", [src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_2__.SharedDataService,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.NavController,
        _angular_router__WEBPACK_IMPORTED_MODULE_10__.Router,
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__.TranslateService,
        _angular_core__WEBPACK_IMPORTED_MODULE_12__.NgZone,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.LoadingController,
        src_app_providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_5__.MutualFundsService,
        _angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute])
], PortfolioDetailComponent);

// removed from symbol Details html
// middelFirstText="{{ t.change }}"
// middelSecondText="{{ t.ProfitLossPercentage }}"
// middleThirdText="{{ t.lastPrice }}"
// [middelFirstValue]="item.change | commafy:'number':2"
// [middelSecondValue]="item.gainLossPercentageRealized | commafy:'number':2"
// [middelThirdValue]="item.price"


/***/ }),

/***/ 82194:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/portfolios/portfolio-home/portfolio-home.component.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PortfolioHomeComponent": () => (/* binding */ PortfolioHomeComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _portfolio_home_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./portfolio-home.component.html?ngResource */ 72086);
/* harmony import */ var _portfolio_home_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./portfolio-home.component.scss?ngResource */ 15750);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/models/portfolio */ 65082);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/helpers/settings */ 96892);
/* harmony import */ var _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @inma/helpers/cached */ 569);











let PortfolioHomeComponent = class PortfolioHomeComponent {
    constructor(sharedData, translate, router, navCtrl) {
        this.sharedData = sharedData;
        this.translate = translate;
        this.router = router;
        this.navCtrl = navCtrl;
        this.standardPortfoliosArr = [];
        this.mutualFundPortfoliosArr = [];
        this.activeSegment = "one";
        this.standardPortfolioGridHeaderList = () => [{ title: this.translate.instant('portfolio.walletNumber'), size: '2.5' }, { title: this.translate.instant('portfolio.buyingBower'), size: '2.5' }, { title: this.translate.instant('portfolio.walletValue'), size: '2.5' }, { title: this.translate.instant('portfolio.profitLoss'), size: '2.7' }];
    }
    ngOnInit() {
        this.getAllStandardPortfolios();
        this.getAllMutualFundPortfolios();
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_4__.Settings.getUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_4__.Settings.preferedThemeKey).subscribe(val => {
            if (val == null || val == "light-theme") {
                this.firstSegmentIcon = 'assets/icon/local-portfolio.png';
                this.secondSegmentIcon = 'assets/icon/mutualfund.png';
            }
            else {
                this.firstSegmentIcon = 'assets/icon/local-portfolio-dark.svg';
                this.secondSegmentIcon = 'assets/icon/mutualfund-dark.svg';
            }
        });
    }
    collapsSymbole(item, dataArr) {
        for (let i = 0; i < dataArr.length; i++) {
            if (dataArr[i].id == item.id) {
                if (dataArr[i].expanded == true) {
                    dataArr[i].expanded = false;
                    return;
                }
                else {
                    dataArr[i].expanded = true;
                }
            }
            else {
                dataArr[i].expanded = false;
            }
        }
    }
    getAllStandardPortfolios() {
        _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_2__.Portfolios.allStandardPortfolios.subscribe(allStandardPortfolios => {
            this.standardPortfoliosArr = allStandardPortfolios;
            for (let i = 0; i < this.standardPortfoliosArr.length; i++) {
                this.standardPortfoliosArr[i].buyingPower.subscribe(buyingPower => {
                    this.standardPortfoliosArr[i].buyingPowerValue = buyingPower;
                });
                if (this.standardPortfoliosArr[i].defaultPortfolio == true) {
                    this.standardPortfoliosArr[i].unshift(this.standardPortfoliosArr[i].splice(i, 1)[0]);
                    break;
                }
            }
        });
    }
    getAllMutualFundPortfolios() {
        _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_2__.Portfolios.allMutualFundPortfolios.subscribe(mutualFundPortfolios => {
            this.mutualFundPortfoliosArr = mutualFundPortfolios;
            for (let i = 0; i < this.mutualFundPortfoliosArr.length; i++) {
                this.mutualFundPortfoliosArr[i].buyingPower.subscribe(buyingPower => {
                    this.mutualFundPortfoliosArr[i].buyingPowerValue = buyingPower;
                });
                if (this.mutualFundPortfoliosArr[i].defaultPortfolio == true) {
                    this.mutualFundPortfoliosArr.unshift(this.mutualFundPortfoliosArr.splice(i, 1)[0]);
                }
            }
        });
    }
    openPortfolioDetail(portfolio) {
        this.sharedData.setSharedData("portfolio", 'opend');
        this.sharedData.setSharedData(portfolio, 'sharedPortfolio');
        //this.router.navigate(['portfolios/details']);
        this.navCtrl.navigateForward('portfolios/details', { animated: true });
    }
    setDefaultPortfolio(portfolio, type) {
        _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_2__.Portfolios.manageDefaultPortfolio(portfolio.id, portfolio.type, 'SET_DEFAULT').subscribe((res) => {
            if (type == 'mf') {
                for (let i = 0; i < this.mutualFundPortfoliosArr.length; i++) {
                    if (this.mutualFundPortfoliosArr[i].id == portfolio.id) {
                        this.mutualFundPortfoliosArr[i].defaultPortfolio = true;
                    }
                    else {
                        this.mutualFundPortfoliosArr[i].defaultPortfolio = false;
                    }
                }
            }
            else {
                for (let i = 0; i < this.standardPortfoliosArr.length; i++) {
                    if (this.standardPortfoliosArr[i].id == portfolio.id) {
                        this.standardPortfoliosArr[i].defaultPortfolio = true;
                    }
                    else {
                        this.standardPortfoliosArr[i].defaultPortfolio = false;
                    }
                }
            }
            (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_5__.resetCache)(_inma_models_portfolio__WEBPACK_IMPORTED_MODULE_2__.Portfolios, 'getOrderPagePortfolios');
        });
    }
    resetDefaultPortfolio(portfolio) {
        _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_2__.Portfolios.manageDefaultPortfolio(portfolio.id, portfolio.type, 'RESET_DEFAULT').subscribe((res) => {
            portfolio.defaultPortfolio = false;
            (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_5__.resetCache)(_inma_models_portfolio__WEBPACK_IMPORTED_MODULE_2__.Portfolios, 'getOrderPagePortfolios');
        });
    }
    segmentChanged(event) {
        this.activeSegment = event;
        console.log("segment>>>>>>>>" + this.activeSegment);
    }
};
PortfolioHomeComponent.ctorParameters = () => [
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_3__.SharedDataService },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController }
];
PortfolioHomeComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'tadawul-portfolio-home',
        template: _portfolio_home_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_portfolio_home_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", [src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_3__.SharedDataService, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateService, _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController])
], PortfolioHomeComponent);



/***/ }),

/***/ 91984:
/*!***************************************************************!*\
  !*** ./src/app/pages/portfolios/portfolios-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PortfoliosPageRoutingModule": () => (/* binding */ PortfoliosPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _portfolios_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./portfolios.page */ 32381);
/* harmony import */ var _portfolio_detail_portfolio_detail_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./portfolio-detail/portfolio-detail.component */ 86422);
/* harmony import */ var _portfolio_home_portfolio_home_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./portfolio-home/portfolio-home.component */ 82194);






const routes = [
    {
        path: '',
        component: _portfolios_page__WEBPACK_IMPORTED_MODULE_0__.PortfoliosPage
    },
    {
        path: 'details',
        component: _portfolio_detail_portfolio_detail_component__WEBPACK_IMPORTED_MODULE_1__.PortfolioDetailComponent
    },
    {
        path: 'home',
        component: _portfolio_home_portfolio_home_component__WEBPACK_IMPORTED_MODULE_2__.PortfolioHomeComponent
    }
];
let PortfoliosPageRoutingModule = class PortfoliosPageRoutingModule {
};
PortfoliosPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule],
    })
], PortfoliosPageRoutingModule);



/***/ }),

/***/ 1661:
/*!*******************************************************!*\
  !*** ./src/app/pages/portfolios/portfolios.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PortfoliosPageModule": () => (/* binding */ PortfoliosPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _portfolios_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./portfolios-routing.module */ 91984);
/* harmony import */ var _portfolios_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./portfolios.page */ 32381);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);
/* harmony import */ var _portfolio_detail_portfolio_detail_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./portfolio-detail/portfolio-detail.component */ 86422);
/* harmony import */ var _portfolio_home_portfolio_home_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./portfolio-home/portfolio-home.component */ 82194);
/* harmony import */ var src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/pipes/pipes.module */ 41041);












let PortfoliosPageModule = class PortfoliosPageModule {
};
PortfoliosPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_8__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonicModule,
            _portfolios_routing_module__WEBPACK_IMPORTED_MODULE_0__.PortfoliosPageRoutingModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_5__.PipesModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__.TranslateModule.forChild()
        ],
        declarations: [_portfolios_page__WEBPACK_IMPORTED_MODULE_1__.PortfoliosPage, _portfolio_detail_portfolio_detail_component__WEBPACK_IMPORTED_MODULE_3__.PortfolioDetailComponent, _portfolio_home_portfolio_home_component__WEBPACK_IMPORTED_MODULE_4__.PortfolioHomeComponent]
    })
], PortfoliosPageModule);



/***/ }),

/***/ 32381:
/*!*****************************************************!*\
  !*** ./src/app/pages/portfolios/portfolios.page.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PortfoliosPage": () => (/* binding */ PortfoliosPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _portfolios_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./portfolios.page.html?ngResource */ 64080);
/* harmony import */ var _portfolios_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./portfolios.page.scss?ngResource */ 36930);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let PortfoliosPage = class PortfoliosPage {
    constructor() { }
    ngOnInit() {
    }
};
PortfoliosPage.ctorParameters = () => [];
PortfoliosPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'tadawul-portfolios',
        template: _portfolios_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_portfolios_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:paramtypes", [])
], PortfoliosPage);



/***/ }),

/***/ 1835:
/*!***************************************************!*\
  !*** ./src/app/providers/mutual-funds.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsService": () => (/* binding */ MutualFundsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let MutualFundsService = class MutualFundsService {
    constructor() { }
    setMutualFund(mutualFund) {
        this.mutualFund = mutualFund;
    }
    getMutualFund() {
        return this.mutualFund;
    }
};
MutualFundsService.ctorParameters = () => [];
MutualFundsService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Injectable)({
        providedIn: 'root'
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__metadata)("design:paramtypes", [])
], MutualFundsService);



/***/ }),

/***/ 90149:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/portfolios/portfolio-detail/portfolio-detail.component.scss?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

module.exports = ".info-label {\n  color: #CDDCDD !important;\n  font-size: 11px;\n  display: block;\n}\n\n.info-value {\n  font-weight: bold;\n  color: #FFFFFF !important;\n  font-size: 13px;\n}\n\n.info-value span {\n  font-weight: regular;\n}\n\n.info-value.changableValueTextGreen {\n  color: #2ebd85 !important;\n}\n\n.info-value.changableValueTextRed {\n  color: #f5455a !important;\n}\n\n.home-scroll-view {\n  overflow-y: scroll;\n}\n\nion-content .portfolio-info {\n  background: #337478;\n  padding: 11px;\n}\n\nion-content .portfolio-info ion-grid {\n  --ion-grid-padding: 0;\n}\n\nion-content .portfolio-info .portfolio-details-item {\n  display: flex;\n  align-items: center;\n}\n\nion-content .portfolio-info .portfolio-details-item .icon-container {\n  flex-shrink: 0 !important;\n  -webkit-margin-end: 10px;\n          margin-inline-end: 10px;\n  height: 40px;\n  width: 40px;\n  padding: 8px;\n  background: #20676c;\n  border-radius: 5px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\nion-content .portfolio-info .portfolio-details-item .item-info {\n  flex-grow: 1 !important;\n}\n\nion-content .account-info {\n  -webkit-padding-start: 10px;\n          padding-inline-start: 10px;\n  -webkit-border-start: 3px solid #FFCC00;\n          border-inline-start: 3px solid #FFCC00;\n}\n\nion-content .account-info .currency {\n  background: #20676c;\n  border-radius: 3px;\n  padding: 2px 5px;\n  font-size: 9px;\n  -webkit-margin-start: 10px;\n          margin-inline-start: 10px;\n}\n\nion-content .icon-box {\n  padding: 2px;\n}\n\nion-content .icon-box .box-bg {\n  background-color: var(--ion-color-tertiary);\n  padding: 5px;\n  height: 100%;\n}\n\nion-content .icon-box .title {\n  color: var(--ion-color-secondary-tint);\n}\n\nbody.dark :host ion-content .icon-box .title {\n  color: white;\n}\n\nion-content .icon-box .desc {\n  font-weight: bold;\n}\n\nbody.dark :host ion-content .icon-box .desc {\n  color: white;\n}\n\nion-content .changableValueTextGreen {\n  color: #2ebd85 !important;\n  display: inline-block;\n  direction: ltr !important;\n}\n\nion-content .changableValueTextRed {\n  color: red !important;\n  display: inline-block;\n  direction: ltr !important;\n}\n\nion-content .row-bk {\n  background-color: var(--ion-color-tertiary);\n}\n\nion-content .owned-shares ion-row .shared-title {\n  color: var(--ion-color-primary-txt);\n  font-weight: 700;\n  margin: 0 25px;\n}\n\nion-content .detailImg {\n  width: 20px;\n  height: 20px;\n  display: block;\n  padding-bottom: 2px;\n}\n\nion-content .headerlImg {\n  width: 24px !important;\n  height: 24px !important;\n  display: block;\n  padding-bottom: 2px;\n}\n\nion-content .portfolioShareText {\n  width: 81px;\n  height: 17px;\n  font-size: 13px;\n  font-weight: bold;\n  text-align: start;\n  color: var(--ion-color-primary-txt);\n  padding: 5px;\n}\n\nion-content body.dark :host .portfolioShareText {\n  color: #d2d2d2;\n}\n\nbody.dark :host .local-portfolio-img {\n  content: url(\"/assets/icon/local-portfolio-dark.svg\");\n}\n\nbody.dark :host .mutual-fund-img {\n  content: url(\"/assets/icon/mutualfund-dark.svg\");\n}\n\n.sticky {\n  position: -webkit-sticky;\n  position: sticky;\n  top: 0;\n  z-index: 999999;\n  overflow: hidden;\n}\n\n.portfolio-detail-segemt {\n  margin: 15px auto !important;\n}\n\nsymbol .color-1 * {\n  fill: none;\n  stroke: #FFFFFF;\n  stroke-width: 1.5px;\n}\n\nsymbol .color-2 * {\n  fill: none;\n  stroke: #FFCC00;\n  stroke-width: 1.5px;\n}\n\nsymbol .color-2 .stroke-sm {\n  stroke-width: 0.75px !important;\n}\n\n.portfolio-details-screen {\n  display: flex;\n  height: 100%;\n  flex-direction: column;\n}\n\n.portfolio-details-screen .portfolio-assets-wrapper {\n  display: flex;\n  flex-grow: 1;\n  flex-direction: column;\n}\n\n.portfolio-details-screen .portfolio-assets-wrapper .portfolio-assets {\n  display: flex;\n  flex-grow: 1;\n  background: #F4F8F8;\n  padding-bottom: env(safe-area-inset-bottom) !important;\n}\n\n.portfolio-details-screen .portfolio-assets-wrapper .portfolio-assets ion-slides {\n  display: flex;\n  flex-grow: 1;\n}\n\n.portfolio-detail-container {\n  padding: 0 11px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBvcnRmb2xpby1kZXRhaWwuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBV0E7RUFFRSx5QkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0FBWEY7O0FBY0E7RUFFRSxpQkFBQTtFQUNBLHlCQUFBO0VBQ0EsZUFBQTtBQVpGOztBQWNFO0VBQ0Usb0JBQUE7QUFaSjs7QUFlRTtFQUNFLHlCQUFBO0FBYko7O0FBZ0JFO0VBQ0UseUJBQUE7QUFkSjs7QUFtQkE7RUFFRSxrQkFBQTtBQWpCRjs7QUFzQkU7RUFDRSxtQkFBQTtFQUNBLGFBQUE7QUFuQko7O0FBcUJJO0VBQ0UscUJBQUE7QUFuQk47O0FBc0JJO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0FBcEJOOztBQXNCTTtFQUNFLHlCQUFBO0VBQ0Esd0JBQUE7VUFBQSx1QkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQXBCUjs7QUF1Qk07RUFDRSx1QkFBQTtBQXJCUjs7QUEwQkU7RUFDRSwyQkFBQTtVQUFBLDBCQUFBO0VBQ0EsdUNBQUE7VUFBQSxzQ0FBQTtBQXhCSjs7QUEwQkk7RUFDRSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsMEJBQUE7VUFBQSx5QkFBQTtBQXhCTjs7QUFrQ0U7RUFDRSxZQUFBO0FBaENKOztBQWtDSTtFQUNFLDJDQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7QUFoQ047O0FBbUNJO0VBRUUsc0NBQUE7QUFsQ047O0FBb0NNO0VBQ0UsWUFBQTtBQWxDUjs7QUFzQ0k7RUFFRSxpQkFBQTtBQXJDTjs7QUF1Q007RUFDRSxZQUFBO0FBckNSOztBQTJDRTtFQUNFLHlCQUFBO0VBQ0EscUJBQUE7RUFDQSx5QkFBQTtBQXpDSjs7QUE0Q0U7RUFDRSxxQkFBQTtFQUNBLHFCQUFBO0VBQ0EseUJBQUE7QUExQ0o7O0FBNkNFO0VBRUUsMkNBQUE7QUE1Q0o7O0FBaURNO0VBRUUsbUNBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFoRFI7O0FBcURFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0VBQ0EsbUJBQUE7QUFuREo7O0FBc0RFO0VBQ0Usc0JBQUE7RUFDQSx1QkFBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtBQXBESjs7QUF1REU7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUNBQUE7RUFDQSxZQUFBO0FBckRKOztBQXdERTtFQUNFLGNBQUE7QUF0REo7O0FBMERBO0VBQ0UscURBQUE7QUF2REY7O0FBMERBO0VBQ0UsZ0RBQUE7QUF2REY7O0FBMERBO0VBQ0Usd0JBQUE7RUFBQSxnQkFBQTtFQUNBLE1BQUE7RUFDQSxlQUFBO0VBRUEsZ0JBQUE7QUF4REY7O0FBMkRBO0VBQ0UsNEJBQUE7QUF4REY7O0FBNkRFO0VBQ0UsVUFBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtBQTFESjs7QUFnRUU7RUFDRSxVQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0FBN0RKOztBQWdFRTtFQUNFLCtCQUFBO0FBOURKOztBQWtFQTtFQUNFLGFBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7QUEvREY7O0FBaUVFO0VBQ0UsYUFBQTtFQUNBLFlBQUE7RUFDQSxzQkFBQTtBQS9ESjs7QUFpRUk7RUFDRSxhQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0Esc0RBQUE7QUEvRE47O0FBaUVNO0VBQ0UsYUFBQTtFQUNBLFlBQUE7QUEvRFI7O0FBb0VBO0VBQ0UsZUFBQTtBQWpFRiIsImZpbGUiOiJwb3J0Zm9saW8tZGV0YWlsLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gaW9uLWhlYWRlciB7XG4vLyAgLy8gcGFkZGluZy10b3A6IGVudihzYWZlLWFyZWEtaW5zZXQtdG9wKTtcbi8vICAgYmFja2dyb3VuZDogIzAwNTE1Nztcbi8vICAgY29sb3I6ICNGRkZGRkY7XG5cbi8vICAgaW9uLXRvb2xiYXIge1xuLy8gICAgIC0tYmFja2dyb3VuZDogIzAwNTE1Nztcbi8vICAgICBjb2xvcjogI0ZGRkZGRjtcbi8vICAgfVxuLy8gfVxuXG4uaW5mby1sYWJlbCB7XG4gIC8vIGNvbG9yOiMwMDUxNTdcbiAgY29sb3I6ICNDRERDREQgIWltcG9ydGFudDtcbiAgZm9udC1zaXplOiAxMXB4O1xuICBkaXNwbGF5OiBibG9jaztcbn1cblxuLmluZm8tdmFsdWUge1xuICAvLyBjb2xvcjojMDA1MTU3XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBjb2xvcjogI0ZGRkZGRiAhaW1wb3J0YW50O1xuICBmb250LXNpemU6IDEzcHg7XG5cbiAgc3BhbiB7XG4gICAgZm9udC13ZWlnaHQ6IHJlZ3VsYXI7XG4gIH1cblxuICAmLmNoYW5nYWJsZVZhbHVlVGV4dEdyZWVuIHtcbiAgICBjb2xvcjogIzJlYmQ4NSAhaW1wb3J0YW50XG4gIH1cblxuICAmLmNoYW5nYWJsZVZhbHVlVGV4dFJlZCB7XG4gICAgY29sb3I6ICNmNTQ1NWEgIWltcG9ydGFudFxuICB9XG59XG5cblxuLmhvbWUtc2Nyb2xsLXZpZXcge1xuICAvL2hlaWdodDogMzQ4cHg7XG4gIG92ZXJmbG93LXk6IHNjcm9sbDtcbn1cblxuaW9uLWNvbnRlbnQge1xuXG4gIC5wb3J0Zm9saW8taW5mbyB7XG4gICAgYmFja2dyb3VuZDogIzMzNzQ3ODtcbiAgICBwYWRkaW5nOiAxMXB4O1xuXG4gICAgaW9uLWdyaWQge1xuICAgICAgLS1pb24tZ3JpZC1wYWRkaW5nOiAwO1xuICAgIH1cblxuICAgIC5wb3J0Zm9saW8tZGV0YWlscy1pdGVtIHtcbiAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuXG4gICAgICAuaWNvbi1jb250YWluZXIge1xuICAgICAgICBmbGV4LXNocmluazogMCAhaW1wb3J0YW50O1xuICAgICAgICBtYXJnaW4taW5saW5lLWVuZDogMTBweDtcbiAgICAgICAgaGVpZ2h0OiA0MHB4O1xuICAgICAgICB3aWR0aDogNDBweDtcbiAgICAgICAgcGFkZGluZzogOHB4O1xuICAgICAgICBiYWNrZ3JvdW5kOiAjMjA2NzZjO1xuICAgICAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgfVxuXG4gICAgICAuaXRlbS1pbmZvIHtcbiAgICAgICAgZmxleC1ncm93OiAxICFpbXBvcnRhbnQ7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLmFjY291bnQtaW5mbyB7XG4gICAgcGFkZGluZy1pbmxpbmUtc3RhcnQ6IDEwcHg7XG4gICAgYm9yZGVyLWlubGluZS1zdGFydDogM3B4IHNvbGlkICNGRkNDMDA7XG5cbiAgICAuY3VycmVuY3kge1xuICAgICAgYmFja2dyb3VuZDogIzIwNjc2YztcbiAgICAgIGJvcmRlci1yYWRpdXM6IDNweDtcbiAgICAgIHBhZGRpbmc6IDJweCA1cHg7XG4gICAgICBmb250LXNpemU6IDlweDtcbiAgICAgIG1hcmdpbi1pbmxpbmUtc3RhcnQ6IDEwcHg7XG4gICAgfVxuICB9XG5cbiAgLy8gaW9uLXRleHQge1xuICAvLyAgIGJvZHkuZGFyayA6aG9zdHtcbiAgLy8gICAgIGNvbG9yOiB3aGl0ZTtcbiAgLy8gICB9XG4gIC8vIH1cblxuICAuaWNvbi1ib3gge1xuICAgIHBhZGRpbmc6IDJweDtcblxuICAgIC5ib3gtYmcge1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5KTtcbiAgICAgIHBhZGRpbmc6IDVweDtcbiAgICAgIGhlaWdodDogMTAwJTtcbiAgICB9XG5cbiAgICAudGl0bGUge1xuICAgICAgLy8gY29sb3I6IzAwNTE1N1xuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnktdGludCk7XG5cbiAgICAgIGJvZHkuZGFyayA6aG9zdCAmIHtcbiAgICAgICAgY29sb3I6IHdoaXRlO1xuICAgICAgfVxuICAgIH1cblxuICAgIC5kZXNjIHtcbiAgICAgIC8vIGNvbG9yOiMwMDUxNTdcbiAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuXG4gICAgICBib2R5LmRhcmsgOmhvc3QgJiB7XG4gICAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAgIH1cbiAgICB9XG5cbiAgfVxuXG4gIC5jaGFuZ2FibGVWYWx1ZVRleHRHcmVlbiB7XG4gICAgY29sb3I6ICMyZWJkODUgIWltcG9ydGFudDtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgZGlyZWN0aW9uOiBsdHIgIWltcG9ydGFudDtcbiAgfVxuXG4gIC5jaGFuZ2FibGVWYWx1ZVRleHRSZWQge1xuICAgIGNvbG9yOiByZWQgIWltcG9ydGFudDtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgZGlyZWN0aW9uOiBsdHIgIWltcG9ydGFudDtcbiAgfVxuXG4gIC5yb3ctYmsge1xuICAgIC8vIGJhY2tncm91bmQtY29sb3I6ICNlNmVmZjA7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5KTtcbiAgfVxuXG4gIC5vd25lZC1zaGFyZXMge1xuICAgIGlvbi1yb3cge1xuICAgICAgLnNoYXJlZC10aXRsZSB7XG4gICAgICAgIC8vIGNvbG9yOiMwMDUxNTc7XG4gICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS10eHQpO1xuICAgICAgICBmb250LXdlaWdodDogNzAwO1xuICAgICAgICBtYXJnaW46IDAgMjVweFxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC5kZXRhaWxJbWcge1xuICAgIHdpZHRoOiAyMHB4O1xuICAgIGhlaWdodDogMjBweDtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBwYWRkaW5nLWJvdHRvbTogMnB4O1xuICB9XG5cbiAgLmhlYWRlcmxJbWcge1xuICAgIHdpZHRoOiAyNHB4ICFpbXBvcnRhbnQ7XG4gICAgaGVpZ2h0OiAyNHB4ICFpbXBvcnRhbnQ7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgcGFkZGluZy1ib3R0b206IDJweDtcbiAgfVxuXG4gIC5wb3J0Zm9saW9TaGFyZVRleHQge1xuICAgIHdpZHRoOiA4MXB4O1xuICAgIGhlaWdodDogMTdweDtcbiAgICBmb250LXNpemU6IDEzcHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgdGV4dC1hbGlnbjogc3RhcnQ7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXR4dCk7XG4gICAgcGFkZGluZzogNXB4O1xuICB9XG5cbiAgYm9keS5kYXJrIDpob3N0IC5wb3J0Zm9saW9TaGFyZVRleHQge1xuICAgIGNvbG9yOiAjZDJkMmQyO1xuICB9XG59XG5cbmJvZHkuZGFyayA6aG9zdCAubG9jYWwtcG9ydGZvbGlvLWltZyB7XG4gIGNvbnRlbnQ6IHVybChcIi9hc3NldHMvaWNvbi9sb2NhbC1wb3J0Zm9saW8tZGFyay5zdmdcIik7XG59XG5cbmJvZHkuZGFyayA6aG9zdCAubXV0dWFsLWZ1bmQtaW1nIHtcbiAgY29udGVudDogdXJsKFwiL2Fzc2V0cy9pY29uL211dHVhbGZ1bmQtZGFyay5zdmdcIik7XG59XG5cbi5zdGlja3kge1xuICBwb3NpdGlvbjogc3RpY2t5O1xuICB0b3A6IDA7XG4gIHotaW5kZXg6IDk5OTk5OTtcbiAgLy8gYmFja2dyb3VuZDogI0ZGRkZGRjtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLnBvcnRmb2xpby1kZXRhaWwtc2VnZW10IHtcbiAgbWFyZ2luOiAxNXB4IGF1dG8gIWltcG9ydGFudDtcbn1cblxuXG5zeW1ib2wgLmNvbG9yLTEge1xuICAqIHtcbiAgICBmaWxsOiBub25lO1xuICAgIHN0cm9rZTogI0ZGRkZGRjtcbiAgICBzdHJva2Utd2lkdGg6IDEuNXB4O1xuICB9XG59XG5cblxuc3ltYm9sIC5jb2xvci0yIHtcbiAgKiB7XG4gICAgZmlsbDogbm9uZTtcbiAgICBzdHJva2U6ICNGRkNDMDA7XG4gICAgc3Ryb2tlLXdpZHRoOiAxLjVweDtcbiAgfVxuXG4gIC5zdHJva2Utc20ge1xuICAgIHN0cm9rZS13aWR0aDogMC43NXB4ICFpbXBvcnRhbnQ7XG4gIH1cbn1cblxuLnBvcnRmb2xpby1kZXRhaWxzLXNjcmVlbiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGhlaWdodDogMTAwJTtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcblxuICAucG9ydGZvbGlvLWFzc2V0cy13cmFwcGVyIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZ3JvdzogMTtcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuXG4gICAgLnBvcnRmb2xpby1hc3NldHMge1xuICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgIGZsZXgtZ3JvdzogMTtcbiAgICAgIGJhY2tncm91bmQ6I0Y0RjhGODtcbiAgICAgIHBhZGRpbmctYm90dG9tOiBlbnYoc2FmZS1hcmVhLWluc2V0LWJvdHRvbSkgIWltcG9ydGFudDtcblxuICAgICAgaW9uLXNsaWRlcyB7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGZsZXgtZ3JvdzogMTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbi5wb3J0Zm9saW8tZGV0YWlsLWNvbnRhaW5lcntcbiAgcGFkZGluZzogMCAxMXB4O1xuICAvLyBiYWNrZ3JvdW5kOiAjMDA1MTU3O1xuICAvLyBjb2xvcjogI0ZGRkZGRjtcbn0iXX0= */";

/***/ }),

/***/ 15750:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/portfolios/portfolio-home/portfolio-home.component.scss?ngResource ***!
  \******************************************************************************************/
/***/ ((module) => {

module.exports = "ion-toolbar {\n  --background: #005157;\n  --color: #ffffff;\n}\n\n.home-scroll-view {\n  overflow-y: scroll;\n  padding: 0px;\n}\n\n.standing-order-toolbar {\n  --background: #005157;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBvcnRmb2xpby1ob21lLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UscUJBQUE7RUFDQSxnQkFBQTtBQUNGOztBQUVBO0VBRUUsa0JBQUE7RUFDQSxZQUFBO0FBQUY7O0FBR0E7RUFDRSxxQkFBQTtBQUFGIiwiZmlsZSI6InBvcnRmb2xpby1ob21lLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6ICMwMDUxNTc7XG4gIC0tY29sb3I6ICNmZmZmZmY7XG59XG4gIFxuLmhvbWUtc2Nyb2xsLXZpZXd7XG4gLy8gaGVpZ2h0OiA1ODBweDtcbiAgb3ZlcmZsb3cteTogc2Nyb2xsO1xuICBwYWRkaW5nOiAwcHg7XG59XG5cbi5zdGFuZGluZy1vcmRlci10b29sYmFye1xuICAtLWJhY2tncm91bmQ6ICMwMDUxNTc7XG59XG4gICJdfQ== */";

/***/ }),

/***/ 36930:
/*!******************************************************************!*\
  !*** ./src/app/pages/portfolios/portfolios.page.scss?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwb3J0Zm9saW9zLnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 56021:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/portfolios/portfolio-detail/portfolio-detail.component.html?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header translucent>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\"></ion-back-button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n      <div class=\"icon-link\" (click)=\"resetDefaultPortfolio()\" *ngIf=\"portfolio?._isDefault\">\n        <span class=\"icon icon-star\" style=\"color: #fc0;\"></span>\n      </div>\n      <div class=\"icon-link\" (click)=\"setDefaultPortfolio()\" *ngIf=\"!portfolio?._isDefault\">\n        <span class=\"icon icon-star-o\"></span>\n      </div>\n    </ion-buttons>\n    <ion-title>{{portfolio?._portfolioNumber}} </ion-title>\n  </ion-toolbar>\n\n  <ion-grid class=\"portfolio-detail-container sub-header\">\n    <ion-row class=\"ion-text-center\">\n      <ion-col size=\"4\">\n        <ion-text class=\"info-label\">{{'portfolio.walletValue' | translate}}</ion-text>\n        <ion-text class=\"info-value\">{{ portfolio?.portfolioPostionAmt }}</ion-text>\n      </ion-col>\n      <ion-col size=\"4\">\n        <ion-text class=\"info-label\">{{'portfolio.buyingBower' | translate}}</ion-text>\n        <ion-text class=\"info-value\">{{ portfolio?._buyingPower  || 0 }}</ion-text>\n      </ion-col>\n      <ion-col size=\"4\">\n        <ion-text class=\"info-label\">{{'portfolio.profitLoss' | translate}}</ion-text>\n        <ion-text class=\"info-value font-size-caption changableValueTextGreen\" *ngIf=\"profitLoss > 0\"> {{\n          portfolio?._totalLoss | number : '1.2-2' }}</ion-text>\n        <ion-text class=\"info-value font-size-caption changableValueTextRed\" *ngIf=\"profitLoss < 0\"> {{\n          portfolio?._totalLoss | number : '1.2-2' }}</ion-text>\n        <ion-text class=\"info-value font-size-caption\" *ngIf=\"profitLoss == 0\"> {{ portfolio?._totalLoss |\n          number : '1.2-2' }}</ion-text>\n        <!-- <ion-text class=\"info-value font-size-caption\"> {{'portfolio.SAR }} </ion-text> -->\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-header>\n\n<ion-content>\n\n  <div class=\"portfolio-details-screen\">\n    <div class=\"portfolio-info\">\n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"12\">\n            <div class=\"account-info\">\n              <ion-text class=\"info-label\">{{'portfolio.accountNumber' | translate}}</ion-text>\n              <ion-text class=\"info-value\">{{ portfolio?.accountNumber }} -\n               <!-- <span> {{ translate.instant('portfolio.'+portfolio?.accountType) }}</span> -->\n                 <span\n                  class=\"currency\">{{'homePage.SAR' | translate }}</span></ion-text>\n            </div>\n          </ion-col>\n          <ion-col size=\"6\">\n            <div class=\"portfolio-details-item\">\n              <div class=\"icon-container\">\n                <svg>\n                  <use xlink:href=\"#icon-money-transfer\"></use>\n                </svg>\n              </div>\n              <div class=\"item-info\">\n                <ion-text class=\"info-label\">{{'portfolio.moneyBalance' | translate}}</ion-text>\n                <ion-text class=\"info-value\">{{ portfolio?.availableBalance || '0.0'}}</ion-text>\n              </div>\n            </div>\n          </ion-col>\n\n          <ion-col size=\"6\">\n            <div class=\"portfolio-details-item\">\n              <div class=\"icon-container\">\n                <svg>\n                  <use xlink:href=\"#icon-money-stack\"></use>\n                </svg>\n              </div>\n              <div class=\"item-info\">\n                <ion-text class=\"info-label\" *ngIf=\"portfolio?._type!='MF'\">{{'portfolio.marketValueDetailPage' | translate}}</ion-text>\n                <ion-text class=\"info-label\" *ngIf=\"portfolio?._type=='MF'\">{{'portfolio.mutualFundMarketValue' | translate}}</ion-text>\n                   <ion-text class=\"info-value\">{{ portfolio?.totalMrktValue || '0.0'}}</ion-text>\n              </div>\n            </div>\n          </ion-col>\n\n          <ion-col size=\"6\">\n            <div class=\"portfolio-details-item\">\n              <div class=\"icon-container\">\n                <svg>\n                  <use xlink:href=\"#icon-wallet\"></use>\n                </svg>\n              </div>\n              <div class=\"item-info\">\n                <ion-text class=\"info-label\">{{'portfolio.walletCost' | translate}}</ion-text>\n                <ion-text class=\"info-value\">{{ portfolio?.totalCost || '0.0'}}</ion-text>\n              </div>\n            </div>\n          </ion-col>\n\n          <ion-col size=\"6\">\n            <div class=\"portfolio-details-item\">\n              <div class=\"icon-container\">\n                <svg>\n                  <use xlink:href=\"#icon-money-limit\"></use>\n                </svg>\n              </div>\n              <div class=\"item-info\">\n                <ion-text class=\"info-label\">{{'portfolio.facilities' | translate}}</ion-text>\n                <ion-text class=\"info-value\">{{ portfolio?.margin || '0.0'}}</ion-text>\n              </div>\n            </div>\n          </ion-col>\n\n          <ion-col size=\"6\">\n            <div class=\"portfolio-details-item\">\n              <div class=\"icon-container\">\n                <svg>\n                  <use xlink:href=\"#icon-blocked-money\"></use>\n                </svg>\n              </div>\n              <div class=\"item-info\">\n                <ion-text class=\"info-label\">{{'portfolio.blockedAmount' | translate}}</ion-text>\n                <ion-text class=\"info-value\">{{ portfolio?.blockedAmt || '0.0'}}</ion-text>\n              </div>\n            </div>\n          </ion-col>\n\n        </ion-row>\n      </ion-grid>\n    </div>\n    <div class=\"portfolio-assets-wrapper\">\n      <div class=\"sticky\">\n        <ion-segment class=\"form-segment portfolio-detail-segemt\" [(ngModel)]=\"symbolTabType\"\n          [ngModelOptions]=\"{standalone: true}\" *ngIf=\"portfolio?._type=='IP'\" (ionChange)=\"symbolSegmentChanged()\">\n          <ion-segment-button value=\"SYMBOLS\">\n            {{'homePage.symbols' | translate}}\n          </ion-segment-button>\n          <ion-segment-button value=\"SUKUK\">\n            {{'homePage.sukuk' | translate}}\n          </ion-segment-button>\n        </ion-segment>\n        <ion-segment class=\"form-segment sticky\" [(ngModel)]=\"activeSegment\" *ngIf=\"portfolio?._type!='IP'\"\n          [ngModelOptions]=\"{standalone: true}\" (ionChange)=\"fundSegmentChanged()\">\n          <ion-segment-button value=\"INV\">\n            {{'homePage.investmentFunds' | translate}}\n          </ion-segment-button>\n          <ion-segment-button value=\"FUND\">\n            {{'homePage.charityFunds' | translate}}\n          </ion-segment-button>\n          <ion-segment-button value=\"CLOSEDFUND\">\n            {{ 'homePage.closedFunds' | translate }}\n          </ion-segment-button>\n        </ion-segment>\n\n        <ion-row class=\"table-row-header ion-padding-horizontal\" *ngIf=\"portfolio?._type=='IP'\">\n          <ion-col class=\"ion-text-center\">{{'portfolio.quantity' | translate}}</ion-col>\n          <ion-col class=\"ion-text-center\">{{'portfolio.Cost' | translate}}</ion-col>\n          <ion-col class=\"ion-text-center\">{{'portfolio.lastPrice' | translate}}</ion-col>\n          <ion-col class=\"ion-text-center\">{{'portfolio.change' | translate}}</ion-col>\n        </ion-row>\n      </div>\n      <!-- <ion-item *ngFor=\"let item of [0,1,2,3,4,5,6,7,8,9,10]\" >{{item}}</ion-item> -->\n      <div class=\"portfolio-assets\" *ngIf=\"portfolio?.tradeSecurties?.length != 0 && portfolio?._type=='IP'\">\n        <ion-slides #symbolSlides (ionSlideDidChange)=\"symbolSlidesChanged()\">\n          <ion-slide>\n            <ion-list class=\"symbols-ion-list\">\n              <tadawul-symbol-card *ngFor=\"let item of symbols_arr;let i = index;\" formName=\"home\"\n                componentName=\"symbol\" [companyName]=\"item.symbol.code +' - '+ item.secArName\"\n                [changeRate]=\"item.unrealizedProfitLoss.amount | commafy:'number':2\"\n                [quantity]=\"item.ownedQuantity | commafy:'integer'\"\n                [cost]=\"item.avgCostPrice.amount| commafy:'number':2 | commafy:'number':2\"\n                [lastPrice]=\"item.mrktPrice.amount | commafy:'number':2\"\n                [ratePercentage]=\"item.unrealizedProfitLossPercen | commafy:'number':2\" (click)=\"openSymbol(item)\">\n              </tadawul-symbol-card>\n            </ion-list>\n          </ion-slide>\n          <ion-slide>\n            <ion-list class=\"symbols-ion-list\">\n              <tadawul-symbol-card *ngFor=\"let item of sukuk_arr;let i = index;\" formName=\"home\" componentName=\"symbol\"\n                [companyName]=\"item.symbol.code +' - '+ item.secArName\"\n                [changeRate]=\"item.unrealizedProfitLoss.amount | commafy:'number':3\"\n                [quantity]=\"item.ownedQuantity | commafy:'integer'\"\n                [cost]=\"item.avgCostPrice.amount| commafy:'number':3 | commafy:'number':3\"\n                [lastPrice]=\"item.mrktPrice.amount | commafy:'number':3\"\n                [ratePercentage]=\"item.unrealizedProfitLossPercen | commafy:'number':3\" (click)=\"openSymbol(item)\">\n              </tadawul-symbol-card>\n            </ion-list>\n          </ion-slide>\n        </ion-slides>\n      </div>\n\n      <ion-row size=\"12\" *ngIf=\"portfolio?._type!='IP'\">\n        <ion-row class=\"table-row-header ion-padding-horizontal\">\n          <ion-col class=\"ion-text-center\">{{'portfolio.quantity' | translate}}</ion-col>\n          <ion-col class=\"ion-text-center\">{{'portfolio.Cost' | translate}}</ion-col>\n          <ion-col class=\"ion-text-center\">{{'portfolio.lastPrice' | translate}}</ion-col>\n          <ion-col class=\"ion-text-center\">{{'portfolio.change' | translate}}</ion-col>\n        </ion-row>\n        <!-- mutual fund -->\n        <ion-slides #fundSlides (ionSlideDidChange)=\"fundSlidesChanged()\">\n          <ion-slide>\n            <ion-list class=\"symbols-ion-list\">\n              <div [hidden]=\"standardMutualFundsArr.length == 0\">\n                <tadawul-symbol-card *ngFor=\"let item of standardMutualFundsArr;let i = index;\" formName=\"home\"\n                  componentName=\"symbol\" [companyName]=\"item.name\" [changeRate]=\"item.changeRate | commafy:'number':2\"\n                  [quantity]=\"item.quantity| commafy:'number':2\" [cost]=\"item.cost | commafy:'number':2\"\n                  [lastPrice]=\"item.price | commafy:'number':2\"\n                  [ratePercentage]=\"item.changeRatePercentage | commafy:'number':2\" (click)=\"openSubscription(item)\">\n                </tadawul-symbol-card>\n              </div>\n              <div [hidden]=\"standardMutualFundsArr?.length != 0\">\n                <app-empty-state message=\"{{ 'portfolio.emptyFunds' | translate }}\"\n                  image=\"assets/icon/empty-portfolio.png\" button=\"true\"\n                  buttonValue=\"{{ 'portfolio.investmentSubscribe' | translate }}\"\n                  (buttonClicked)=\"goToMutualFunds('investment')\">\n                </app-empty-state>\n              </div>\n            </ion-list>\n          </ion-slide>\n          <ion-slide>\n            <ion-list class=\"symbols-ion-list\">\n              <div [hidden]=\"charitiesMutualFundsArr.length == 0\">\n                <tadawul-symbol-card *ngFor=\"let item of charitiesMutualFundsArr;let i = index;\" formName=\"home\"\n                  componentName=\"symbol\" [companyName]=\"item.name\" [changeRate]=\"item.changeRate | commafy:'number':2\"\n                  [quantity]=\"item.ownedUnits | commafy:'number':2\" [cost]=\"item.totalCost | commafy:'number':2\"\n                  [lastPrice]=\"item.lastPrice | commafy:'number':2\"\n                  [ratePercentage]=\"item.gainLossUnrealizedPercentage | commafy:'number':2\"\n                  (click)=\"openRedemption(item)\">\n                </tadawul-symbol-card>\n              </div>\n              <div [hidden]=\"charitiesMutualFundsArr?.length != 0\">\n                <app-empty-state message=\"{{ 'portfolio.emptyFunds' | translate }}\"\n                  image=\"assets/icon/empty-portfolio.png\" button=\"true\"\n                  buttonValue=\"{{ 'homePage.charitiesSubscribe' | translate }}\"\n                  (buttonClicked)=\"goToMutualFunds('endowment')\">\n                </app-empty-state>\n              </div>\n            </ion-list>\n          </ion-slide>\n        </ion-slides>\n      </ion-row>\n    </div>\n  </div>\n</ion-content>\n\n<svg xmlns=\"http://www.w3.org/2000/svg\" style=\"display: none;\">\n  <symbol id=\"icon-blocked-money\" viewBox=\"0 0 24 24\">\n    <g class=\"color-1\">\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\"\n        d=\"M2.4,10V7.5V5 c0-0.6,0.5-1,1-1h2.5h13h2.5c0.5,0,1,0.5,1,1v2.5v5V15c0,0.6-0.5,1-1,1h-2.5h-6.5\" />\n      <circle stroke-linecap=\"round\" stroke-miterlimit=\"10\" cx=\"12.4\" cy=\"10\" r=\"2.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M5.9,4L5.9,4 c0,1.9-1.6,3.5-3.5,3.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M18.9,4L18.9,4 c0,1.9,1.6,3.5,3.5,3.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M18.9,16 c0-1.9,1.6-3.5,3.5-3.5\" />\n    </g>\n    <g class=\"color-2\">\n      <path stroke-miterlimit=\"10\"\n        d=\"M8.1,20h-5c-0.8,0-1.5-0.7-1.5-1.5v-2 c0-0.8,0.7-1.5,1.5-1.5h5c0.8,0,1.5,0.7,1.5,1.5v2C9.6,19.3,8.9,20,8.1,20z\" />\n      <path stroke-miterlimit=\"10\" d=\"M7.6,15h-4v-1c0-1.1,0.9-2,2-2h0c1.1,0,2,0.9,2,2 V15z\" />\n    </g>\n  </symbol>\n\n  <symbol id=\"icon-money-transfer\" viewBox=\"0 0 24 24\">\n    <g class=\"color-2\">\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"1\" y1=\"3\" x2=\"11\" y2=\"3\" />\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"1\" y1=\"3\" x2=\"3.1\" y2=\"0.9\" />\n    </g>\n    <g class=\"color-1\">\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\"\n        d=\"M22,18H2 c-0.6,0-1-0.4-1-1V7c0-0.6,0.4-1,1-1h20c0.6,0,1,0.4,1,1v10C23,17.6,22.6,18,22,18z\" />\n      <circle stroke-linecap=\"round\" stroke-miterlimit=\"10\" cx=\"12\" cy=\"12\" r=\"2.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M4.5,6L4.5,6 c0,1.9-1.6,3.5-3.5,3.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M19.5,6L19.5,6 c0,1.9,1.6,3.5,3.5,3.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M1,14.5 c1.9,0,3.5,1.6,3.5,3.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M19.5,18 c0-1.9,1.6-3.5,3.5-3.5\" />\n    </g>\n    <g class=\"color-2\">\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"23\" y1=\"21\" x2=\"13\" y2=\"21\" />\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"23\" y1=\"21\" x2=\"20.9\" y2=\"23.1\" />\n    </g>\n  </symbol>\n\n  <symbol id=\"icon-money-stack\" viewBox=\"0 0 24 24\">\n    <g class=\"color-1\">\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M22,18H4\n      c-0.6,0-1-0.4-1-1V7c0-0.6,0.4-1,1-1h18c0.6,0,1,0.4,1,1v10C23,17.6,22.6,18,22,18z\" />\n      <circle stroke-linecap=\"round\" stroke-miterlimit=\"10\" cx=\"13\" cy=\"12\" r=\"2.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M6.5,6L6.5,6 c0,1.9-1.6,3.5-3.5,3.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M19.5,6L19.5,6 c0,1.9,1.6,3.5,3.5,3.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M3,14.5 c1.9,0,3.5,1.6,3.5,3.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M19.5,18 c0-1.9,1.6-3.5,3.5-3.5\" />\n    </g>\n    <g class=\"color-2\">\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M1,14.5V6.6 C1,5.2,2.2,4,3.6,4h15.9\" />\n    </g>\n  </symbol>\n\n  <symbol id=\"icon-wallet\" viewBox=\"0 0 24 24\">\n    <g class=\"color-1\">\n      <path stroke-miterlimit=\"10\"\n        d=\"M20.5,20.5h-17c-1.1,0-2-0.9-2-2v-12h19 c1.1,0,2,0.9,2,2v10C22.5,19.6,21.7,20.5,20.5,20.5z\" />\n      <path stroke-miterlimit=\"10\" d=\"M21.5,6.8V5.5c0-1.1-0.9-2-2-2h-16 c-1.1,0-2,0.9-2,2v3v8\" />\n    </g>\n    <g class=\"color-2\">\n      <circle stroke-miterlimit=\"10\" cx=\"18.3\" cy=\"13.5\" r=\"1.5\" />\n    </g>\n  </symbol>\n\n  <symbol id=\"icon-money-limit\" viewBox=\"0 0 24 24\">\n    <g class=\"color-1\">\n      <polyline stroke-miterlimit=\"10\" points=\"13.2,11.6 13.2,9.4 13.2,8.1 13.2,4.5 \" />\n      <polyline stroke-miterlimit=\"10\" points=\"1,4.5 1,9.5 1,14.5 1,19.5 \" />\n      <ellipse stroke-miterlimit=\"10\" cx=\"7.1\" cy=\"4.5\" rx=\"6.1\" ry=\"3.1\" />\n      <path stroke-miterlimit=\"10\"\n        d=\"M13.2,8.5c0,0.5-0.2,1-0.9,1.3 c-1.1,0.9-3.1,1.3-5.3,1.3s-4.3-0.6-5.3-1.3C1.2,9.5,1,9,1,8.5\" />\n      <path stroke-miterlimit=\"10\" d=\"M1,12.2c0,0.5,0.2,1,0.9,1.3 c1.1,0.9,3.1,1.3,5.3,1.3c1.5,0,2.9-0.2,3.9-0.6\" />\n      <path stroke-miterlimit=\"10\" d=\"M1,15.9c0,1.5,2.7,2.7,6.1,2.7 c1.5,0,2.8-0.2,3.9-0.6\" />\n      <path stroke-miterlimit=\"10\" d=\"M1,19.5c0,1.5,2.7,2.7,6.1,2.7 c2.3,0,4.4-0.6,5.4-1.5\" />\n    </g>\n    <g class=\"color-1\">\n      <circle stroke-linecap=\"round\" stroke-miterlimit=\"10\" cx=\"16.9\" cy=\"16.5\" r=\"6.1\" />\n    </g>\n\n    <g class=\"color-2 stroke-sm\">\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\"\n        d=\"M13.8,16.6 c0,0,1.6-0.3,4.3,2.8c0.6,0.7,1.1,0.5,1.4,0.3c0.1-0.1,0.2-0.3,0.2-0.4\" />\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"18.8\" y1=\"18.9\" x2=\"17.6\" y2=\"20.1\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\"\n        d=\"M14,19.3 c0,0.2,0.1,0.3,0.2,0.4c0.3,0.2,0.9,0.4,1.4-0.3c0.2-0.2,0.4-0.5,0.6-0.7\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M16.9,18.2 c2-1.9,3-1.6,3-1.6\" />\n\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"15\" y1=\"18.9\" x2=\"16.2\" y2=\"20.1\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\"\n        d=\"M15.2,14.3 c-0.1-0.1-0.1-0.3-0.1-0.4c0-0.5,0.4-0.9,0.9-0.9c0.3,0,0.5,0.1,0.7,0.3c0,0,0.1,0.1,0.1,0.2\" />\n\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"16.9\" y1=\"12.5\" x2=\"16.9\" y2=\"15.5\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M16.3,16 c0.2-0.2,0.4-0.2,0.6-0.2c0.2,0,0.5,0.1,0.6,0.2\" />\n\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"16.1\" y1=\"14.7\" x2=\"16.9\" y2=\"13.8\" />\n\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"16.9\" y1=\"13.4\" x2=\"15.2\" y2=\"14.3\" />\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\"\n        d=\"M16.9,13.4 c0-0.1,0.1-0.1,0.1-0.2c0.2-0.2,0.4-0.3,0.7-0.3c0.5,0,0.9,0.4,0.9,0.9c0,0.1,0,0.3-0.1,0.4\" />\n\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"17.7\" y1=\"14.7\" x2=\"16.9\" y2=\"13.8\" />\n\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"18.6\" y1=\"14.3\" x2=\"16.9\" y2=\"13.4\" />\n    </g>\n  </symbol>\n</svg>";

/***/ }),

/***/ 72086:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/portfolios/portfolio-home/portfolio-home.component.html?ngResource ***!
  \******************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header translucent>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <!-- <ion-menu-button autoHide=\"true\"></ion-menu-button> -->\n      <ion-back-button text=\"\"></ion-back-button>\n    </ion-buttons>\n  \n    <ion-title>\n            {{'portfolio.portfolios' | translate}}\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <ion-grid class=\"tadawulSegment\">\n    <tadawul-common-segment-group firstSegmentText=\"{{ 'portfolio.IN' | translate }}\" secondSegmentText=\"{{ 'portfolio.MF' | translate }}\"\n      [firstSegmentIcon]=\"firstSegmentIcon\" [secondSegmentIcon]=\"secondSegmentIcon\"\n      (segmentChange)=\"segmentChanged($event)\">\n    </tadawul-common-segment-group>\n  </ion-grid>\n\n  <!-- standard Portfolios -->\n\n  <div class=\"order-segment\" *ngIf=\"activeSegment === 'one' && standardPortfoliosArr?.length != 0\">\n      <ion-grid style=\"padding: 0px;\">\n        <tadawul-grid-header\n          [headerList]=\"standardPortfolioGridHeaderList()\"\n        ></tadawul-grid-header>\n      </ion-grid>\n\n  <ion-grid class=\"home-scroll-view\">\n        <div *ngFor=\"let item of standardPortfoliosArr\">\n          <tadawul-collapsible-list\n            [cardTextOne]=\"item.id\"\n            [cardTextTwo]=\"(item.buyingPowerValue | commafy:'number':2) || 0\"\n            [cardTextThree]=\"(item.portfolioValue | commafy:'number':2) || 0\"\n            [cardTextFive]=\"(item.profitLoss | commafy:'number':2) || 0\"\n            formName=\"home\"\n            [arrow]=\"false\"\n            [default]=\"item.defaultPortfolio\"\n            [showDefault]=\"true\"\n            [expand]=\"item.expanded\"\n            colOneSize=\"2.5\"\n            colTwoSize=\"2.5\" colThreeSize=\"2.5\" colFiveSize=\"2.5\"\n            (collabseClick)=\"collapsSymbole(item,standardPortfoliosArr)\"\n          >\n            <tadawul-stock-quick-view\n              headerFirstText=\"{{ 'portfolio.tadawulAccount' | translate }}\"\n              headerSecondText=\"{{ 'portfolio.accountNumber' | translate }}\"\n              headerThirdText=\"{{ 'portfolio.currency' | translate }}\"\n              [headerFirstValue]=\"item.samaAccount\"\n              [headerSecondValue]=\"item.accountNumber\"\n              [headerThirdValue]=\"item.currency\"\n              middelFirstText=\"{{ 'portfolio.blockedAmount' | translate }}\"\n              middelSecondText=\"{{ 'portfolio.facilities' | translate }}\"\n              middleThirdText=\"{{ 'portfolio.moneyBalanc' | translate }}\"\n              [middelFirstValue]=\"item.blockedAmount | commafy:'number':2\"\n              [middelSecondValue]=\"item.facilities | commafy:'number':2\"\n              [middelThirdValue]=\"item.moneyBalance | commafy:'number':2\"\n              thirdRowFirstText=\"{{ 'portfolio.marketValue' | translate }}\"\n              thirdRowSecondText=\"{{ 'portfolio.buyingBower' | translate }}\"\n              [thirdRowFirstValue]=\"item.marketValue | commafy:'number':2\"\n              [thirdRowSecondValue]=\"item.buyingPowerValue | commafy:'number':2\"\n              firstBtnText=\"{{ 'portfolio.units' | translate }}\"\n              (firstBtnClick)=\"openPortfolioDetail(item)\"\n              (defaultBtnClick)=\"setDefaultPortfolio(item,'lp')\"\n              (notdefaultBtnClick)=\"resetDefaultPortfolio(item)\"\n              firstBtnColor=\"stockButtonPurple\"\n              [default]=\"item.defaultPortfolio\"\n              componentName=\"port\"\n            >\n            </tadawul-stock-quick-view>\n          </tadawul-collapsible-list>\n        </div>\n    </ion-grid>\n  </div>\n  <div *ngIf=\"activeSegment === 'one' && standardPortfoliosArr?.length == 0\" >\n    <app-empty-state\n      message=\"{{ 'portfolio.noSharesOne' | translate }}\"\n      secondMessage=\"{{ 'portfolio.noSharesTwo' | translate }}\"\n     \n      image=\"assets/icon/no-data-light.svg\"\n    >\n    </app-empty-state>\n  </div>\n   <!-- mutual fund Portfolios -->\n\n   <div class=\"order-segment\" *ngIf=\"activeSegment === 'two' && mutualFundPortfoliosArr?.length != 0\">\n    <ion-grid style=\"padding: 0px;\">\n        <tadawul-grid-header\n          [headerList]=\"standardPortfolioGridHeaderList()\"\n        ></tadawul-grid-header>\n    </ion-grid>\n\n  <ion-grid class=\"home-scroll-view\">\n        <div *ngFor=\"let item of mutualFundPortfoliosArr\">\n          <tadawul-collapsible-list\n            [cardTextOne]=\"item.id\"\n            [cardTextTwo]=\"(item.buyingPowerValue | commafy:'number':2) || 0\"\n            [cardTextThree]=\"(item.portfolioValue | commafy:'number':2) || 0\"\n            [cardTextFive]=\"(item.profitLoss | commafy:'number':2) || 0\"\n            formName=\"home\"\n            [arrow]=\"false\"\n            [expand]=\"item.expanded\"\n            (collabseClick)=\"collapsSymbole(item,mutualFundPortfoliosArr)\"\n            colOneSize=\"2.5\"\n            colTwoSize=\"2.5\"\n            colThreeSize=\"2.5\"\n            colFiveSize=\"2.5\"\n            [default]=\"item.defaultPortfolio\"\n            [showDefault]=\"true\"\n          >\n            <tadawul-stock-quick-view\n              headerFirstText=\"{{ 'portfolio.accountNumber' | translate }}\"\n              headerSecondText=\"{{ 'portfolio.currency' | translate }}\"\n              headerThirdText=\"{{ 'portfolio.blockedAmount' | translate }}\"\n              [headerFirstValue]=\"item.accountNumber\"\n              [headerSecondValue]=\"item.currency\"\n              [headerThirdValue]=\"item.blockedAmount | commafy:'number':2\"\n              middelFirstText=\"{{ 'portfolio.moneyBalance' | translate }}\"\n              middelSecondText=\"{{ 'portfolio.marketValue' | translate }}\"\n              middleThirdText=\"{{ 'portfolio.buyingBower' | translate }}\"\n              [middelFirstValue]=\"item.moneyBalance | commafy:'number':2\"\n              [middelSecondValue]=\"item.marketValue | commafy:'number':2\"\n              [middelThirdValue]=\"item.buyingPowerValue | commafy:'number':2\"\n              firstBtnText=\"{{ 'portfolio.unitsMutualFunds' | translate }}\"\n              (firstBtnClick)=\"openPortfolioDetail(item)\"\n              (defaultBtnClick)=\"setDefaultPortfolio(item,'mf')\"\n              (notdefaultBtnClick)=\"resetDefaultPortfolio(item)\"\n              firstBtnColor=\"stockButtonPurple\"\n              [default]=\"item.defaultPortfolio\"\n              componentName=\"port\"\n            >\n            </tadawul-stock-quick-view>\n          </tadawul-collapsible-list>\n        </div>\n    </ion-grid>\n  </div>\n  <div *ngIf=\"activeSegment === 'two' && mutualFundPortfoliosArr?.length == 0\" >\n    <app-empty-state\n      message=\"{{ 'portfolio.noSharesOne' | translate }}\"\n      secondMessage=\"{{ 'portfolio.noSharesTwo' | translate }}\"\n     \n      image=\"assets/icon/no-data-light.svg\"\n    >\n    </app-empty-state>\n  </div>\n\n\n</ion-content>";

/***/ }),

/***/ 64080:
/*!******************************************************************!*\
  !*** ./src/app/pages/portfolios/portfolios.page.html?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>portfolios</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_portfolios_portfolios_module_ts.js.map