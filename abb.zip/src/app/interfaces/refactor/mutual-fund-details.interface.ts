export interface PaginationInfo {
    wholeResultSetSize: number;
    currentResultSetSize: number;
}

export interface Units {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface AvgPrice {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface TotalCost {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface LastValuationPrice {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface MarketValue {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface UnrealizedGainLoss {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface UnrealizedGainLossPer {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface MutualFundPer {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface MutualFundPositionList {
    id: string;
    type: string;
    arName: string;
    enName: string;
    units: Units;
    avgPrice: AvgPrice;
    totalCost: TotalCost;
    lastValuationPrice: LastValuationPrice;
    marketValue: MarketValue;
    unrealizedGainLoss: UnrealizedGainLoss;
    unrealizedGainLossPer: UnrealizedGainLossPer;
    mutualFundPer: MutualFundPer;
    closedFund: boolean;
}

// export interface TotalMarketValue {
//     currencyCode?: any;
//     currencyRate?: any;
//     amount: string;
//     formatedAmount?: any;
//     localAmount?: any;
// }

// export interface TotalUnrealizedprofitLossAmt {
//     currencyCode?: any;
//     currencyRate?: any;
//     amount: string;
//     formatedAmount?: any;
//     localAmount?: any;
// }

// export interface TotalCost2 {
//     currencyCode?: any;
//     currencyRate?: any;
//     amount: string;
//     formatedAmount?: any;
//     localAmount?: any;
// }
export interface Amount {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface MFPortfolioDetails {
    paginationInfo: PaginationInfo;
    mutualFundPositionList: MutualFundPositionList[];
    totalMarketValue: Amount;
    totalUnrealizedprofitLossAmt: Amount;
    totalCost: Amount;
    buyingPwrAmt: Amount;
    availableBalance: Amount;
    margin: Amount;
    portfolioPostionAmt: Amount;
    coverageRatio: string;
    accountNumber: string;
    accountType: string;
    samaAccountNumber: string;
    _MFDetails?: MFDetails[];
    _portfolioNumber?: string;
    _cashPercentage?: number;
    _unitPercentage?: number;
    _cashValue?: number;
    _unitValue?: number;
    _portfolioValue?: number;
    _buyingPower?: string;
    _totalLoss?: number;
    _type?: string;
    _isDefault?: boolean;

}

export interface MFDetails {
    name: string;
    changeRate: number;
    changeRatePercentage: number;
    quantity: number;
    cost: number;
    price: number;
    type: string;
    closedFund: boolean;
}