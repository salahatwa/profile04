import { NgModule } from '@angular/core';
import { Unlocker } from './unlocker';

@NgModule({
	declarations: [Unlocker],
	imports: [],
	exports: [Unlocker]
})
export class UnlockerComponentModule {}
