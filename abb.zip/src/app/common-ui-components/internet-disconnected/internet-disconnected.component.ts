import { Component, OnInit } from '@angular/core';
import { Translations } from '@inma/helpers/translations';
import { Network } from '@ionic-native/network/ngx';
import { ModalController, NavController, Platform } from '@ionic/angular';
import { AppComponent } from 'src/app/app.component';
import { MenuComponent } from 'src/app/pages/menu/menu.component';
import { InternetDisconnectTranslations } from './internet-disconnect.translation';

@Component({
  selector: 'tadawul-internet-disconnected',
  templateUrl: './internet-disconnected.component.html',
  styleUrls: ['./internet-disconnected.component.scss'],
})
export class InternetDisconnectedComponent implements OnInit {
  @Translations()
  t = InternetDisconnectTranslations;
  public disableBackBtn: any;
 
  constructor(private modalControl: ModalController,private network: Network, private platform: Platform, public navCtrl: NavController) { }

  ngOnInit() {
    // watch network for a connection
    let connectSubscription = this.network.onConnect().subscribe(() => {
      AppComponent.loggedoutDisconnected = false;
     this.modalControl.dismiss();
    });
  }
  ionViewDidEnter() {
    this.disableBackBtn = this.platform.backButton.subscribeWithPriority(9999, () => {
      // do nothing
    });
  }
  
  ionViewWillLeave() {
    this.disableBackBtn.unsubscribe();
  }

  goToLoginPage(){
   
    this.modalControl.dismiss();
    this.navCtrl.navigateRoot('login', { animated: false }); 
    //MenuComponent.logout(false);
  }

 
}
