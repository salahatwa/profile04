import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Translations } from '@inma/helpers/translations';
import { Portfolios } from '@inma/models/portfolio';
import { StockQuickViewTranslations } from './stock-quick-view.translations';

@Component({
  selector: 'tadawul-stock-quick-view',
  templateUrl: './stock-quick-view.component.html',
  styleUrls: ['./stock-quick-view.component.scss'],
})
export class StockQuickViewComponent implements OnInit {

  @Input() headerFirstText: string;
  @Input() headerSecondText: string;
  @Input() headerThirdText: string;
  @Input() headerFourthText: string;
  @Input() headerFirstValue: any;
  @Input() headerSecondValue: string;
  @Input() headerThirdValue: number;
  @Input() headerFourthValue: string;
  @Input() middelFirstText: string;
  @Input() middelSecondText: string;
  @Input() middleThirdText: string;
  @Input() middelFirstValue: number;
  @Input() middelSecondValue: number;
  @Input() middelThirdValue: number;
  @Input() thirdRowFirstText: string;
  @Input() thirdRowSecondText: string;
  @Input() thirdRowThirdText: string;
  @Input() thirdRowFirstValue: number;
  @Input() thirdRowSecondValue: number;
  @Input() thirdRowThirdValue: number;
  @Input() firstBtnText: string;
  @Input() secondBtnText: string;
  @Input() thirdBtnText: string;
  @Input() fourthBtnText: string;
  @Input() firstBtnIcon: any;
  @Input() secondBtnIcon: any;
  @Input() thirdBtnIcon: any;
  @Input() fourthBtnIcon: string;
  @Input() firstBtnColor: string;
  @Input() secondBtnColor: string;
  @Input() thirdBtnColor: string;
  @Input() fourthBtnColor: string;
  @Input() statusFlag: string;
  @Input() componentName: string;
  @Input() default :boolean;
  
  @Output() firstBtnClick = new EventEmitter();
  @Output() secondBtnClick = new EventEmitter();
  @Output() thirdBtnClick = new EventEmitter();
  @Output() fourthBtnClick = new EventEmitter();
  @Output() defaultBtnClick = new EventEmitter();
  @Output() notdefaultBtnClick = new EventEmitter();
  public btnFlag = false;

  @Translations()
  t = StockQuickViewTranslations;

  constructor() { }

  ngOnInit() {
    if (this.statusFlag == "Filled" || this.statusFlag == "Cancelled" || this.statusFlag == "Expired" || this.statusFlag == "Pending for cancel "|| this.statusFlag == "Rejected" || this.statusFlag == "تم التنفيذ" || this.statusFlag == "ملغى" || this.statusFlag == "منتهي الصلاحية"|| this.statusFlag == "في انتظار الالغاء" || this.statusFlag == "مرفوض") {
      this.btnFlag = true;
    }
  }

  public firstBtnClicked() {
    this.firstBtnClick.emit();
  }

  public secondBtnClicked() {
    this.secondBtnClick.emit();
  }

  public thirdBtnClicked() {
    this.thirdBtnClick.emit();
  }
  public fourthBtnClicked() {
    this.fourthBtnClick.emit();
  }

  public defaultBtnClicked() {
    this.defaultBtnClick.emit();
  }

  public notDefaultBtnClicked() {
    this.notdefaultBtnClick.emit();
  }

  public manageDefaultPortfolio(){
    Portfolios.manageDefaultPortfolio('1031-1','IP','SET_DEFAULT')
  }

  uncommafy(value) {
    if(value || value === 0 || value === '0') {
      return value.toString().replace(/,/g, '');
    }
    else {
      return;
    }
  }
}
