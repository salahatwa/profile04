"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_more_more_module_ts"],{

/***/ 18586:
/*!***************************************************!*\
  !*** ./src/app/pages/more/more-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MorePageRoutingModule": () => (/* binding */ MorePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _more_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./more.page */ 65793);




const routes = [
    {
        path: '',
        component: _more_page__WEBPACK_IMPORTED_MODULE_0__.MorePage
    }
];
let MorePageRoutingModule = class MorePageRoutingModule {
};
MorePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MorePageRoutingModule);



/***/ }),

/***/ 84908:
/*!*******************************************!*\
  !*** ./src/app/pages/more/more.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MorePageModule": () => (/* binding */ MorePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _menu_menu_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../menu/menu.component */ 88020);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _more_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./more-routing.module */ 18586);
/* harmony import */ var _more_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./more.page */ 65793);









let MorePageModule = class MorePageModule {
};
MorePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _more_routing_module__WEBPACK_IMPORTED_MODULE_1__.MorePageRoutingModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateModule.forChild()
        ],
        declarations: [_more_page__WEBPACK_IMPORTED_MODULE_2__.MorePage, _menu_menu_component__WEBPACK_IMPORTED_MODULE_0__.MenuComponent]
    })
], MorePageModule);



/***/ }),

/***/ 65793:
/*!*****************************************!*\
  !*** ./src/app/pages/more/more.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MorePage": () => (/* binding */ MorePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _more_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./more.page.html?ngResource */ 37788);
/* harmony import */ var _more_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./more.page.scss?ngResource */ 90954);
/* harmony import */ var _models_portfolio_portfolios_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../🌱models/portfolio/portfolios.model */ 39620);
/* harmony import */ var _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/helpers/cached */ 569);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/app.component */ 20721);
/* harmony import */ var _inma_models_users__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @inma/models/users */ 17166);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);











let MorePage = class MorePage {
    constructor(navCtrl, cdr, translate, modalCtrl) {
        this.navCtrl = navCtrl;
        this.cdr = cdr;
        this.translate = translate;
        this.modalCtrl = modalCtrl;
        this.Portfolios = _models_portfolio_portfolios_model__WEBPACK_IMPORTED_MODULE_2__.Portfolios;
    }
    ionViewWillEnter() {
        this.direction = this.translate.currentLang == 'en' ? 'ltr' : 'rtl';
        console.log("🚀 ~ file: more.page.ts ~ line 26 ~ MorePage ~ ionViewWillEnter ~ this.direction", this.direction);
        this.cdr.detectChanges();
    }
    ngOnInit() {
    }
    logout(serverSide = true) {
        // this.menu.close('menu');
        _inma_models_users__WEBPACK_IMPORTED_MODULE_5__.Users.logout(serverSide).subscribe(() => {
            (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_3__.resetCache)(_models_portfolio_portfolios_model__WEBPACK_IMPORTED_MODULE_2__.Portfolios, 'loadPortfolios');
            src_app_app_component__WEBPACK_IMPORTED_MODULE_4__.AppComponent.restart(() => {
                setTimeout(() => {
                    this.navCtrl.navigateRoot('login');
                }, 100);
            });
        });
    }
};
MorePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ChangeDetectorRef },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController }
];
MorePage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'tadawul-more',
        template: _more_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_more_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController,
        _angular_core__WEBPACK_IMPORTED_MODULE_7__.ChangeDetectorRef,
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateService,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController])
], MorePage);



/***/ }),

/***/ 90954:
/*!******************************************************!*\
  !*** ./src/app/pages/more/more.page.scss?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = ":host > ion-content {\n  --background: #F4F8F8;\n}\n\n.logout-link {\n  text-align: center;\n  color: #f5455a;\n  font-weight: bold;\n  font-size: 14px;\n  --min-height: 55px !important;\n  border-top: 1px solid #e6eff0;\n  border-bottom: 1px solid #e6eff0;\n  --padding-start: 0;\n  --inner-border-width: 0;\n}\n\n.logout-link ion-label {\n  margin: 0;\n}\n\nion-list ion-item .icon-container {\n  flex-shrink: 0 !important;\n  -webkit-margin-end: 10px;\n          margin-inline-end: 10px;\n  height: 30px;\n  width: 30px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\nion-list ion-item .icon-container svg {\n  fill: #E6EFF0;\n  stroke: #65979A;\n  stroke-width: 1.25;\n  width: 20px;\n  height: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1vcmUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUtBO0VBQ0kscUJBQUE7QUFKSjs7QUFZQTtFQUNJLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUVBLDZCQUFBO0VBQ0EsNkJBQUE7RUFDQSxnQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsdUJBQUE7QUFWSjs7QUFZSTtFQUNJLFNBQUE7QUFWUjs7QUF5QlE7RUFDSSx5QkFBQTtFQUNBLHdCQUFBO1VBQUEsdUJBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBdEJaOztBQXdCWTtFQUNJLGFBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQXRCaEIiLCJmaWxlIjoibW9yZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBpb24taGVhZGVyIGlvbi10b29sYmFyIHtcbi8vICAgICAtLWJhY2tncm91bmQ6ICMwMDUxNTc7XG4vLyAgICAgY29sb3I6ICNmZmY7XG4vLyB9XG5cbjpob3N0Pmlvbi1jb250ZW50IHtcbiAgICAtLWJhY2tncm91bmQ6ICNGNEY4Rjg7XG5cbiAgICAvLyA6Zmlyc3QtY2hpbGQge1xuICAgIC8vICAgICBtYXJnaW4tdG9wOiAwO1xuICAgIC8vIH1cbn1cblxuXG4ubG9nb3V0LWxpbmsge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogI2Y1NDU1YTtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXNpemU6IDE0cHg7XG5cbiAgICAtLW1pbi1oZWlnaHQ6IDU1cHggIWltcG9ydGFudDtcbiAgICBib3JkZXItdG9wOiAxcHggc29saWQgI2U2ZWZmMDtcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U2ZWZmMDtcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDA7XG4gICAgLS1pbm5lci1ib3JkZXItd2lkdGg6IDA7XG5cbiAgICBpb24tbGFiZWwge1xuICAgICAgICBtYXJnaW46IDA7XG4gICAgfVxufVxuXG5pb24tbGlzdCB7XG4gICAgaW9uLWl0ZW0ge1xuICAgICAgICAvLyAtLW1pbi1oZWlnaHQ6IDU1cHggIWltcG9ydGFudDtcbiAgICAgICAgLy8gZm9udC1zaXplOiAxM3B4O1xuICAgICAgICAvLyBmb250LXdlaWdodDogYm9sZDtcbiAgICAgICAgLy8gY29sb3I6ICMwMDUxNTc7XG4gICAgICAgIC8vIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZTZlZmYwO1xuICAgICAgICAvLyBtYXJnaW4taW5saW5lLXN0YXJ0OiAxNnB4O1xuICAgICAgICAvLyAtLXBhZGRpbmctc3RhcnQ6IDA7XG4gICAgICAgIC8vIC0taW5uZXItYm9yZGVyLXdpZHRoOiAwO1xuXG4gICAgICAgIC5pY29uLWNvbnRhaW5lciB7XG4gICAgICAgICAgICBmbGV4LXNocmluazogMCAhaW1wb3J0YW50O1xuICAgICAgICAgICAgbWFyZ2luLWlubGluZS1lbmQ6IDEwcHg7XG4gICAgICAgICAgICBoZWlnaHQ6IDMwcHg7XG4gICAgICAgICAgICB3aWR0aDogMzBweDtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cbiAgICAgICAgICAgIHN2ZyB7XG4gICAgICAgICAgICAgICAgZmlsbDogI0U2RUZGMDtcbiAgICAgICAgICAgICAgICBzdHJva2U6ICM2NTk3OUE7XG4gICAgICAgICAgICAgICAgc3Ryb2tlLXdpZHRoOiAxLjI1O1xuICAgICAgICAgICAgICAgIHdpZHRoOiAyMHB4O1xuICAgICAgICAgICAgICAgIGhlaWdodDogMjBweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn0iXX0= */";

/***/ }),

/***/ 37788:
/*!******************************************************!*\
  !*** ./src/app/pages/more/more.page.html?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>{{ 'morePage.MORE' | translate }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n<!-- <ion-content>\n  <ion-item button *ngFor=\"let item of [0,1,2,3,4,5]\" >\n    <ion-label>Item {{item}}</ion-label>\n  </ion-item>\n</ion-content> -->\n\n<ion-content [dir]=\"direction\">\n  <ion-list class=\"section list-group\" >\n\n    <ion-item button routerLink=\"/main/user-profile\" >\n      <div class=\"icon-container\">\n        <svg>\n          <use xlink:href=\"#icon-profile\"></use>\n        </svg>\n      </div>\n      <ion-label>{{ 'morePage.SETTINGS' | translate }}</ion-label>\n    </ion-item>\n  </ion-list>\n\n  <ion-list class=\"section list-group\" >\n    <!-- <ion-item button routerLink=\"/main/portfolios/home\" >\n      <div class=\"icon-container\">\n        <svg>\n          <use xlink:href=\"#icon-menu-wallet\"></use>\n        </svg>\n      </div>\n      <ion-label>{{ 'morePage.PORTFOLIOS' | translate }}</ion-label>\n    </ion-item> -->\n\n    <ion-item button routerLink=\"/main/standing-orders/filter-order\">\n      <div class=\"icon-container\">\n        <svg>\n          <use xlink:href=\"#icon-menu-search\"></use>\n        </svg>\n      </div>\n      <ion-label>{{ 'morePage.SEARCH_ORDERS' | translate }}</ion-label>\n    </ion-item>\n\n    <ion-item button routerLink=\"/main/products\">\n      <div class=\"icon-container\">\n        <svg>\n          <use xlink:href=\"#icon-menu-grid\"></use>\n        </svg>\n      </div>\n      <ion-label>{{ 'morePage.PRODUCTS' | translate }}</ion-label>\n    </ion-item>\n\n    <ion-item button routerLink=\"/main/transfer/transfer-home\">\n      <div class=\"icon-container\">\n        <svg>\n          <use xlink:href=\"#icon-menu-money-transfer\"></use>\n        </svg>\n      </div>\n      <ion-label>{{ 'morePage.MONEY_TRANSFER' | translate }}</ion-label>\n    </ion-item>\n\n    <ion-item button routerLink=\"/main/mutual-funds\">\n      <div class=\"icon-container\">\n        <svg>\n          <use xlink:href=\"#icon-menu-box-money\"></use>\n        </svg>\n      </div>\n      <ion-label>{{ 'morePage.MUTUAL_FUNDS' | translate }}</ion-label>\n    </ion-item>\n\n    <!-- <ion-item button routerLink=\"/main/reports-mutual-funds\">\n      <div class=\"icon-container\">\n        <svg>\n          <use xlink:href=\"#icon-menu-files\"></use>\n        </svg>\n      </div>\n      <ion-label>{{ 'morePage.REPORTS' | translate }}</ion-label>\n    </ion-item> -->\n\n    <!-- <ion-item button routerLink=\"/standing-orders/filter-order\"  >\n      <ion-icon  color=\"txt\" slot=\"start\" src=\"assets/icon/order-search-icon.svg\"></ion-icon>\n      <ion-label color=\"txt\">\n        searchOrder\n      </ion-label>\n    </ion-item>\n\n    <ion-item button routerLink=\"/mutual-funds\"  >\n      <ion-icon  color=\"txt\" slot=\"start\" src=\"assets/icon/mutualfunds.svg\"></ion-icon>\n      <ion-label>MUTUAL_FUNDS</ion-label>\n    </ion-item> -->\n\n\n    <!-- <ion-item button routerLink=\"/reports-mutual-funds\"  >\n      <ion-icon  color=\"txt\" slot=\"start\" src=\"assets/icon/reports.svg\"></ion-icon>\n      <ion-label>REPORTS</ion-label>\n    </ion-item> -->\n    <!-- <ion-item button routerLink=\"/settings\"  >\n      <ion-icon  slot=\"start\" src=\"assets/icon/settings.svg\"></ion-icon>\n      <ion-label>SETTINGS</ion-label>\n    </ion-item> -->\n    <ion-item button routerLink=\"/main/contact-us\">\n      <div class=\"icon-container\">\n        <svg>\n          <use xlink:href=\"#icon-menu-envelope\"></use>\n        </svg>\n      </div>\n      <ion-label>{{ 'morePage.CONTACT_US' | translate }}</ion-label>\n    </ion-item>\n    <!-- <br>\n    <ion-item button color='danger' (click)=\"logout()\">\n      <ion-icon  slot=\"start\" src=\"assets/icon/signout.svg\"></ion-icon>\n      <ion-label>SIGNOUT</ion-label>\n    </ion-item> -->\n  </ion-list>\n\n\n  <ion-item class=\"logout-link\" (click)=\"logout()\">\n    <ion-label>\n      {{'userProfile.SIGNOUT' | translate}}\n    </ion-label>\n  </ion-item> \n</ion-content>\n\n\n\n<svg xmlns=\"http://www.w3.org/2000/svg\" style=\"display: none;\">\n  <symbol id=\"icon-profile\" viewBox=\"0 0 16 16\">\n    <circle stroke-linecap=\"round\" stroke-linejoin=\"round\" cx=\"8\" cy=\"8\" r=\"7.2\"/>\n    <circle stroke-linecap=\"round\" stroke-linejoin=\"round\" cx=\"8\" cy=\"6\" r=\"2.5\"/>\n    <path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M3.5,13.7 C4.4,12,6.2,10.9,8.1,11c1.8,0,3.5,1,4.3,2.7\"/>\n  </symbol>\n\n  <symbol id=\"icon-menu-envelope\" viewBox=\"0 0 16 16\">\n    <path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M1.9,3.6H14c0.5,0,1,0.4,1,1v8.1c0,0.5-0.4,1-1,1H1.9c-0.5,0-1-0.4-1-1V4.6C0.9,4,1.4,3.6,1.9,3.6z\"/>\n    <path stroke-linecap=\"round\" d=\"M8.7,9.2c-0.4,0.3-1,0.3-1.4,0 L1.4,5.3C0.9,5,0.8,4.4,1.2,4c0.2-0.2,0.5-0.4,0.9-0.4h11.7c0.6,0,1.1,0.4,1.1,1c0,0.3-0.2,0.6-0.4,0.7L8.7,9.2z\"/>\n  </symbol>\n\n  <symbol id=\"icon-menu-wallet\" viewBox=\"0 0 16 16\">\n    <path stroke-linejoin=\"round\" stroke-miterlimit=\"10\" d=\"M14.3,4.5V3.7 c0-0.7-0.6-1.3-1.3-1.3H2.3C1.6,2.3,1,2.9,1,3.7v2V11\"/>\n    <path stroke-linejoin=\"round\" stroke-miterlimit=\"10\" d=\"M13.7,13.7H2.3 c-0.7,0-1.3-0.6-1.3-1.3v-8h12.7c0.7,0,1.3,0.6,1.3,1.3v6.7C15,13.1,14.5,13.7,13.7,13.7z\"/>\n    <circle stroke-linejoin=\"round\" stroke-miterlimit=\"10\" cx=\"12.2\" cy=\"9\" r=\"1\"/>\n  </symbol>\n\n  <symbol id=\"icon-menu-grid\" viewBox=\"0 0 16 16\">\n    <path stroke-linejoin=\"round\" stroke-miterlimit=\"10\" d=\"M5.5,7h-3C1.7,7,1,6.3,1,5.5v-3 C1,1.7,1.7,1,2.5,1h3C6.3,1,7,1.7,7,2.5v3C7,6.3,6.3,7,5.5,7z\"/>\n    <path stroke-linejoin=\"round\" stroke-miterlimit=\"10\" d=\"M13.5,7h-3C9.7,7,9,6.3,9,5.5v-3 C9,1.7,9.7,1,10.5,1h3C14.3,1,15,1.7,15,2.5v3C15,6.3,14.3,7,13.5,7z\"/>\n    <path stroke-linejoin=\"round\" stroke-miterlimit=\"10\" d=\"M5.5,15h-3C1.7,15,1,14.3,1,13.5v-3 C1,9.7,1.7,9,2.5,9h3C6.3,9,7,9.7,7,10.5v3C7,14.3,6.3,15,5.5,15z\"/>\n    <path stroke-linejoin=\"round\" stroke-miterlimit=\"10\" d=\"M13.5,15h-3C9.7,15,9,14.3,9,13.5v-3 C9,9.7,9.7,9,10.5,9h3c0.8,0,1.5,0.7,1.5,1.5v3C15,14.3,14.3,15,13.5,15z\"/>\n  </symbol>\n\n  <symbol id=\"icon-menu-search\" viewBox=\"0 0 16 16\">\n    <circle stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-miterlimit=\"10\" cx=\"7.1\" cy=\"7.1\" r=\"6.1\"/>\n    <line stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-miterlimit=\"10\" x1=\"15\" y1=\"15\" x2=\"11.4\" y2=\"11.4\"/>\n  </symbol>\n\n  <symbol id=\"icon-menu-money-transfer\" viewBox=\"0 0 16 16\">\n    <g>\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"1\" y1=\"2.3\" x2=\"7.4\" y2=\"2.3\"/>\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"1\" y1=\"2.3\" x2=\"2.3\" y2=\"1\"/>\n    </g>\n    <g>\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M14.4,11.8H1.6 c-0.4,0-0.6-0.3-0.6-0.6V4.8c0-0.4,0.3-0.6,0.6-0.6h12.7c0.4,0,0.6,0.3,0.6,0.6v6.3C15,11.5,14.7,11.8,14.4,11.8z\"/>\n      <ellipse stroke-linecap=\"round\" stroke-miterlimit=\"10\" cx=\"8\" cy=\"8\" rx=\"1.6\" ry=\"1.6\"/>\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M3.2,4.2L3.2,4.2 c0,1.2-1,2.2-2.2,2.2\"/>\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M12.8,4.2L12.8,4.2 c0,1.2,1,2.2,2.2,2.2\"/>\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M1,9.6 c1.2,0,2.2,1,2.2,2.2\"/>\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M12.8,11.8 c0-1.2,1-2.2,2.2-2.2\"/>\n    </g>\n    <g>\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"15\" y1=\"13.7\" x2=\"8.6\" y2=\"13.7\"/>\n      <line stroke-linecap=\"round\" stroke-miterlimit=\"10\" x1=\"15\" y1=\"13.7\" x2=\"13.7\" y2=\"15\"/>\n    </g>\n  </symbol>\n\n  <symbol id=\"icon-menu-box-money\" viewBox=\"0 0 16 16\">\n    <line stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-miterlimit=\"10\" x1=\"5.88\" y1=\"6\" x2=\"10.12\" y2=\"6\"/>\n    <path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-miterlimit=\"10\" d=\"M15,3H1V1h14V3z\"/>\n    <path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-miterlimit=\"10\" d=\"M2,7.69V3h12v10c0,0.55-0.45,1-1,1h-3\"/>\n    <g>\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M7.55,15.09h-6.1C1.18,15.09,1,14.91,1,14.64\n        v-4.5c0-0.27,0.18-0.45,0.45-0.45h6.1C7.82,9.69,8,9.87,8,10.14v4.5C8,14.91,7.82,15.09,7.55,15.09z\"/>\n      <circle stroke-linecap=\"round\" stroke-miterlimit=\"10\" cx=\"4.5\" cy=\"12.39\" r=\"1.12\"/>\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M2.58,9.69L2.58,9.69\n        c0,0.86-0.72,1.57-1.58,1.57\"/>\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M6.43,9.69L6.43,9.69 c0,0.86,0.72,1.57,1.57,1.57\"/>\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M1,13.51c0.86,0,1.58,0.72,1.58,1.57\"/>\n      <path stroke-linecap=\"round\" stroke-miterlimit=\"10\" d=\"M6.43,15.09c0-0.85,0.72-1.57,1.57-1.57\"/>\n    </g>\n  </symbol>\n\n  <symbol id=\"icon-menu-files\" viewBox=\"0 0 16 16\">\n    <path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-miterlimit=\"10\" d=\"M11.91,13.31v0.88c0,0.48-0.4,0.87-0.88,0.87H3.16c-0.49,0-0.88-0.39-0.88-0.87V3.69c0-0.49,0.39-0.88,0.88-0.88h0.87\"/>\n    <path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-miterlimit=\"10\" d=\"M13.66,4.6v7.84c0,0.48-0.39,0.88-0.88,0.88H4.91c-0.48,0-0.88-0.39-0.88-0.88V1.94c0-0.48,0.39-0.88,0.88-0.88h5.21L13.66,4.6z\"/>\n    <polygon stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-miterlimit=\"10\" points=\"13.66,4.6 10.12,4.6 10.12,1.06 \"/>\n    <line stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-miterlimit=\"10\" x1=\"6.22\" y1=\"9.94\" x2=\"8.84\" y2=\"9.94\"/>\n    <line stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-miterlimit=\"10\" x1=\"6.22\" y1=\"7.93\" x2=\"10.59\" y2=\"7.93\"/>\n  </symbol>\n  \n</svg>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_more_more_module_ts.js.map