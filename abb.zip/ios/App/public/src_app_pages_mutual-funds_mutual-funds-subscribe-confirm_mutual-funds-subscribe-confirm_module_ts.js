"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_mutual-funds_mutual-funds-subscribe-confirm_mutual-funds-subscribe-confirm_module_ts"],{

/***/ 15990:
/*!********************************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-subscribe-confirm/mutual-funds-subscribe-confirm-routing.module.ts ***!
  \********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsSubscribeConfirmPageRoutingModule": () => (/* binding */ MutualFundsSubscribeConfirmPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _mutual_funds_subscribe_confirm_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-funds-subscribe-confirm.page */ 59137);




const routes = [
    {
        path: '',
        component: _mutual_funds_subscribe_confirm_page__WEBPACK_IMPORTED_MODULE_0__.MutualFundsSubscribeConfirmPage
    }
];
let MutualFundsSubscribeConfirmPageRoutingModule = class MutualFundsSubscribeConfirmPageRoutingModule {
};
MutualFundsSubscribeConfirmPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MutualFundsSubscribeConfirmPageRoutingModule);



/***/ }),

/***/ 15540:
/*!************************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-subscribe-confirm/mutual-funds-subscribe-confirm.module.ts ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsSubscribeConfirmPageModule": () => (/* binding */ MutualFundsSubscribeConfirmPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _mutual_funds_subscribe_confirm_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-funds-subscribe-confirm-routing.module */ 15990);
/* harmony import */ var _mutual_funds_subscribe_confirm_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mutual-funds-subscribe-confirm.page */ 59137);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);









let MutualFundsSubscribeConfirmPageModule = class MutualFundsSubscribeConfirmPageModule {
};
MutualFundsSubscribeConfirmPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _mutual_funds_subscribe_confirm_routing_module__WEBPACK_IMPORTED_MODULE_0__.MutualFundsSubscribeConfirmPageRoutingModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateModule.forChild()
        ],
        declarations: [_mutual_funds_subscribe_confirm_page__WEBPACK_IMPORTED_MODULE_1__.MutualFundsSubscribeConfirmPage]
    })
], MutualFundsSubscribeConfirmPageModule);



/***/ }),

/***/ 59137:
/*!**********************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-subscribe-confirm/mutual-funds-subscribe-confirm.page.ts ***!
  \**********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsSubscribeConfirmPage": () => (/* binding */ MutualFundsSubscribeConfirmPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _mutual_funds_subscribe_confirm_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-funds-subscribe-confirm.page.html?ngResource */ 71797);
/* harmony import */ var _mutual_funds_subscribe_confirm_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mutual-funds-subscribe-confirm.page.scss?ngResource */ 82787);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../providers/mutual-funds.service */ 1835);
/* harmony import */ var _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/helpers/cached */ 569);







let MutualFundsSubscribeConfirmPage = class MutualFundsSubscribeConfirmPage {
    constructor(mutualFundsService, navCtrl) {
        this.mutualFundsService = mutualFundsService;
        this.navCtrl = navCtrl;
    }
    ngOnInit() {
        this.mutualFund = this.mutualFundsService.getMutualFund();
        console.log(this.mutualFund);
        this.mutualFund.details.subscribe(details => {
            this.mfDetails = details;
            console.log(this.mfDetails);
        });
    }
    confirmSubscription() {
        var _a;
        if ((_a = this.mutualFund) === null || _a === void 0 ? void 0 : _a.ownedUnits) {
            this.mutualFund.addUnits(this.mutualFund.formData.amount).subscribe(response => {
                this.subSummary(response);
            });
        }
        else {
            this.mutualFund.subscribe(this.mutualFund.formData.amount).subscribe(response => {
                this.subSummary(response);
            });
        }
        // this.navCtrl.navigateForward(['/mutual-funds-subscribe-summary']);
    }
    subSummary(response) {
        this.mutualFund.summaryData = { processID: response.result };
        this.mutualFundsService.setMutualFund(this.mutualFund);
        (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_3__.resetCache)(this.mutualFund, 'isSubscribed');
        this.navCtrl.navigateForward(['main/mutual-funds-subscribe-summary']);
    }
    cancelSubscription() {
        this.navCtrl.navigateBack('main/mutual-funds-details');
    }
    editSubscription() {
        this.navCtrl.navigateBack('main/mutual-funds-subscribe');
    }
};
MutualFundsSubscribeConfirmPage.ctorParameters = () => [
    { type: _providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_2__.MutualFundsService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController }
];
MutualFundsSubscribeConfirmPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'tadawul-mutual-funds-subscribe-confirm',
        template: _mutual_funds_subscribe_confirm_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_mutual_funds_subscribe_confirm_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:paramtypes", [_providers_mutual_funds_service__WEBPACK_IMPORTED_MODULE_2__.MutualFundsService, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController])
], MutualFundsSubscribeConfirmPage);



/***/ }),

/***/ 1835:
/*!***************************************************!*\
  !*** ./src/app/providers/mutual-funds.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsService": () => (/* binding */ MutualFundsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let MutualFundsService = class MutualFundsService {
    constructor() { }
    setMutualFund(mutualFund) {
        this.mutualFund = mutualFund;
    }
    getMutualFund() {
        return this.mutualFund;
    }
};
MutualFundsService.ctorParameters = () => [];
MutualFundsService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Injectable)({
        providedIn: 'root'
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__metadata)("design:paramtypes", [])
], MutualFundsService);



/***/ }),

/***/ 82787:
/*!***********************************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-subscribe-confirm/mutual-funds-subscribe-confirm.page.scss?ngResource ***!
  \***********************************************************************************************************************/
/***/ ((module) => {

module.exports = "body.dark :host ion-text {\n  color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm11dHVhbC1mdW5kcy1zdWJzY3JpYmUtY29uZmlybS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0k7RUFDSSxZQUFBO0FBQVIiLCJmaWxlIjoibXV0dWFsLWZ1bmRzLXN1YnNjcmliZS1jb25maXJtLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10ZXh0e1xuICAgIGJvZHkuZGFyayA6aG9zdCAme1xuICAgICAgICBjb2xvcjp3aGl0ZTtcbiAgICB9XG59Il19 */";

/***/ }),

/***/ 71797:
/*!***********************************************************************************************************************!*\
  !*** ./src/app/pages/mutual-funds/mutual-funds-subscribe-confirm/mutual-funds-subscribe-confirm.page.html?ngResource ***!
  \***********************************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"success\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\"></ion-back-button>\n    </ion-buttons>\n    <ion-title slot=\"start\">\n      {{ ((mutualFund?.ownedUnits)?'mutualFund.ADD_UNIT_HEADER':'mutualFund.SUBSCRIPTION_HEADER' )| translate }}\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <div class=\"ion-margin-bottom\">\n    <ion-text color=\"primary\" class=\"bold\">\n      {{ 'mutualFund.PORTFOLIO' | translate }}\n    </ion-text>\n    <div class=\"box-with-bg ion-padding\">\n      <ion-text color=\"primary\">\n        {{mutualFund?.portfolio?.name}}\n      </ion-text>\n    </div>\n  </div>\n  <div class=\"ion-margin-bottom\">\n    <ion-text color=\"primary\" class=\"bold\">\n      {{ 'mutualFund.MUTUAL_FUND' | translate }}\n    </ion-text>\n    <div class=\"box-with-bg ion-padding\">\n      <ion-text color=\"primary\">\n        {{mutualFund?.name}}\n      </ion-text>\n    </div>\n  </div>\n  <div class=\"ion-margin-bottom\">\n    <ion-text color=\"primary\" class=\"bold\">\n      {{ 'mutualFund.SUBSCRIPTION_FEES' | translate }}\n    </ion-text>\n    <div class=\"box-with-bg ion-padding\">\n      <ion-text color=\"primary\">\n        {{ mfDetails?.subscriptionFees }} {{ mfDetails?.subscriptionFeesType }}\n      </ion-text>\n    </div>\n  </div>\n  <div class=\"ion-margin-bottom\">\n    <ion-text color=\"primary\" class=\"bold\">\n      {{ 'mutualFund.SUBSCRIPTION_AMOUNT' | translate }}\n    </ion-text>\n    <div class=\"box-with-bg ion-padding\">\n      <ion-text color=\"primary\">\n        {{ mutualFund?.formData.amount }}\n      </ion-text>\n    </div>\n  </div>\n\n\n  <!-- SECOND SECTION -->\n  <ion-text class=\"bold\" color=\"primary\">{{'mutualFund.COMMISSION_DETAILS' | translate}}</ion-text>\n  <div class=\"box-with-bg bordered ion-margin-bottom\">\n    <ion-row class=\"data-row\">\n      <ion-col size=\"6\">\n        <ion-text class=\"label font-size-caption\" color=\"primary\">{{'mutualFund.TOTAL_COMMISSION' | translate}}\n        </ion-text>\n      </ion-col>\n      <ion-col size=\"6\">\n        <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n          {{mutualFund?.totalCommission}}\n        </ion-text>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"data-row\">\n      <ion-col size=\"6\">\n        <ion-text class=\"label font-size-caption\" color=\"primary\">{{'mutualFund.VAT_WITH_PERCENTAGE' | translate}}\n        </ion-text>\n      </ion-col>\n      <ion-col size=\"6\">\n        <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n          {{mutualFund?.vat}}\n        </ion-text>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"data-row\">\n      <ion-col size=\"6\">\n        <ion-text class=\"label font-size-caption\" color=\"primary\">{{'mutualFund.TOTAL_AMOUNT' | translate}}</ion-text>\n      </ion-col>\n      <ion-col size=\"6\">\n        <ion-text class=\"value font-size-caption bold\" color=\"primary\">\n          {{mutualFund?.totalAmount}}\n        </ion-text>\n      </ion-col>\n    </ion-row>\n  </div>\n\n  <ion-grid>\n    <ion-row>\n      <ion-col>\n        <app-button (clickAction)=\"editSubscription()\" expand=\"block\" size=\"\" color=\"success\" fill=\"outline\" shape=\"\"\n          type=\"button\">\n          {{'mutualFund.EDIT_ORDER' | translate}}\n        </app-button>\n      </ion-col>\n      <ion-col>\n        <app-button (clickAction)=\"cancelSubscription()\" expand=\"block\" size=\"\" color=\"danger\" fill=\"outline\" shape=\"\"\n          type=\"button\">\n          {{'mutualFund.CANCEL_ORDER' | translate}}\n        </app-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <app-button (clickAction)=\"confirmSubscription()\" expand=\"block\" size=\"\" color=\"success\" fill=\"solid\" type=\"button\">\n\n    {{ ((mutualFund?.ownedUnits)?'mutualFund.ADD_UNITS':'mutualFund.SEND_SUBSCRIPTION_ORDER') | translate }}\n  </app-button>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_mutual-funds_mutual-funds-subscribe-confirm_mutual-funds-subscribe-confirm_module_ts.js.map