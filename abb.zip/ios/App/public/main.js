(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["main"],{

/***/ 32892:
/*!******************************************!*\
  !*** ./src/app/animations/fade-enter.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "fadeEnterAnimation": () => (/* binding */ fadeEnterAnimation),
/* harmony export */   "fadeLeaveAnimation": () => (/* binding */ fadeLeaveAnimation)
/* harmony export */ });
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic/angular */ 26710);

const fadeEnterAnimation = (baseEl) => {
    const backdropAnimation = (0,_ionic_angular__WEBPACK_IMPORTED_MODULE_0__.createAnimation)()
        .addElement(baseEl.querySelector('ion-backdrop'))
        .fromTo('opacity', '0', '0');
    const wrapperAnimation = (0,_ionic_angular__WEBPACK_IMPORTED_MODULE_0__.createAnimation)()
        .addElement(baseEl.querySelector('.modal-wrapper'))
        .keyframes([
        { offset: 0, opacity: '0', transform: 'scale(1)' },
        { offset: 1, opacity: '1', transform: 'scale(1)' }
    ]);
    baseEl.classList.add('fade-enter-animation-container');
    //   const backgroundAnimation = createAnimation()
    //   .addElement(baseEl.querySelector('ion-modal')!)
    //   .keyframes([
    //     { offset: 0, opacity: '1', transform: 'scale(0)', 'backdrop-filter': 'blur(10px)' },
    //     { offset: 1, opacity: '1', transform: 'scale(1)', 'backdrop-filter': 'blur(10px)' }
    //   ]);
    return (0,_ionic_angular__WEBPACK_IMPORTED_MODULE_0__.createAnimation)()
        .addElement(baseEl)
        .easing('ease-in-out')
        .duration(500)
        .addAnimation([backdropAnimation, wrapperAnimation]);
};
const fadeLeaveAnimation = (baseEl) => {
    return fadeEnterAnimation(baseEl).direction('reverse');
};


/***/ }),

/***/ 70809:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 52816);



const routes = [
    // {
    //   path: '',
    //   redirectTo: 'splash-screen',
    //   pathMatch: 'full'
    // },
    // {
    //   path: 'login',
    //   loadChildren: () => import('./pages/login/login.module').then(m => m.LoginPageModule)
    // },
    {
        path: '',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_models_watchlist_index_ts"), __webpack_require__.e("default-src_app_common-ui-components_symbols-search-dragable-modal_symbols-search-dragable-mo-b72097"), __webpack_require__.e("default-src_app_common-ui-components_tadawul-common-ui_module_ts"), __webpack_require__.e("default-src_app_pages_login_button_index_ts"), __webpack_require__.e("common"), __webpack_require__.e("src_app_pages_login_login_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/login/login.module */ 60441)).then(m => m.LoginPageModule)
    },
    {
        path: 'splash-screen',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_splash-screen_splash-screen_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/splash-screen/splash-screen.module */ 52273)).then(m => m.SplashScreenPageModule)
    },
    {
        path: 'ui-samples',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_models_watchlist_index_ts"), __webpack_require__.e("default-src_app_common-ui-components_symbols-search-dragable-modal_symbols-search-dragable-mo-b72097"), __webpack_require__.e("default-src_app_common-ui-components_tadawul-common-ui_module_ts"), __webpack_require__.e("src_app_ui-samples_ui-samples_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./ui-samples/ui-samples.module */ 18016)).then(m => m.UiSamplesPageModule)
    },
    {
        path: 'main',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_models_watchlist_index_ts"), __webpack_require__.e("default-src_app_common-ui-components_symbols-search-dragable-modal_symbols-search-dragable-mo-b72097"), __webpack_require__.e("default-src_app_common-ui-components_tadawul-common-ui_module_ts"), __webpack_require__.e("src_app_tadawul-home_tadawul-home_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./tadawul-home/tadawul-home.module */ 61805)).then(m => m.TadawulHomePageModule)
    },
    {
        path: 'market',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_market_market_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/market/market.module */ 37990)).then(m => m.MarketPageModule)
    },
    //#region Create module region
    {
        path: 'watchlists/add',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_models_watchlist_index_ts"), __webpack_require__.e("src_app_pages_watchlists_edit_watchlist-edit_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/watchlists/edit/watchlist-edit.module */ 7792)).then(m => m.WatchlistEditPageModule)
    },
    {
        path: 'watchlists/edit/:id',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_models_watchlist_index_ts"), __webpack_require__.e("src_app_pages_watchlists_edit_watchlist-edit_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/watchlists/edit/watchlist-edit.module */ 7792)).then(m => m.WatchlistEditPageModule)
    },
    {
        path: 'watchlists/show/:id',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_models_watchlist_index_ts"), __webpack_require__.e("default-src_app_common-ui-components_symbols-search-dragable-modal_symbols-search-dragable-mo-b72097"), __webpack_require__.e("default-src_app_common-ui-components_tadawul-common-ui_module_ts"), __webpack_require__.e("default-src_app_pages_order_confirm_order-confirm_page_ts-src_app_pages_order_order_page_ts"), __webpack_require__.e("default-src_app_pages_tradestation_symbol-swiper_symbol-swiper_module_ts"), __webpack_require__.e("src_app_pages_watchlists_show_watchlist-show_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/watchlists/show/watchlist-show.module */ 76004)).then(m => m.WatchlistShowPageModule)
    },
    {
        path: 'watchlists',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_models_watchlist_index_ts"), __webpack_require__.e("src_app_pages_watchlists_index_watchlists-index_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/watchlists/index/watchlists-index.module */ 79620)).then(m => m.WatchlistsIndexPageModule)
    },
    ////
    {
        path: 'sectors/add',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_models_watchlist_index_ts"), __webpack_require__.e("src_app_pages_watchlists_edit_watchlist-edit_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/watchlists/edit/watchlist-edit.module */ 7792)).then(m => m.WatchlistEditPageModule)
    },
    {
        path: 'sectors/edit/:id',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_models_watchlist_index_ts"), __webpack_require__.e("src_app_pages_watchlists_edit_watchlist-edit_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/watchlists/edit/watchlist-edit.module */ 7792)).then(m => m.WatchlistEditPageModule)
    },
    {
        path: 'sectors/show/:id',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_models_watchlist_index_ts"), __webpack_require__.e("default-src_app_common-ui-components_symbols-search-dragable-modal_symbols-search-dragable-mo-b72097"), __webpack_require__.e("default-src_app_common-ui-components_tadawul-common-ui_module_ts"), __webpack_require__.e("default-src_app_pages_order_confirm_order-confirm_page_ts-src_app_pages_order_order_page_ts"), __webpack_require__.e("default-src_app_pages_tradestation_symbol-swiper_symbol-swiper_module_ts"), __webpack_require__.e("src_app_pages_watchlists_show_watchlist-show_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/watchlists/show/watchlist-show.module */ 76004)).then(m => m.WatchlistShowPageModule)
    },
    {
        path: 'sectors',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_models_watchlist_index_ts"), __webpack_require__.e("src_app_pages_watchlists_index_watchlists-index_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/watchlists/index/watchlists-index.module */ 79620)).then(m => m.WatchlistsIndexPageModule)
    },
    //#endregion
    {
        path: 'search',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_common-ui-components_search_search_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./common-ui-components/search/search.module */ 77477)).then(m => m.SearchPageModule)
    },
    {
        path: 'order/summary',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_common-ui-components_symbols-search-dragable-modal_symbols-search-dragable-mo-b72097"), __webpack_require__.e("default-src_app_pages_order_confirm_order-confirm_page_ts-src_app_pages_order_order_page_ts"), __webpack_require__.e("common"), __webpack_require__.e("src_app_pages_order_summary_order-summary_module_ts-src_app_pipes_pipes_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/order/summary/order-summary.module */ 62798)).then(m => m.OrderSummaryPageModule)
    },
    {
        path: 'settings',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_models_watchlist_index_ts"), __webpack_require__.e("default-src_app_common-ui-components_symbols-search-dragable-modal_symbols-search-dragable-mo-b72097"), __webpack_require__.e("default-src_app_common-ui-components_tadawul-common-ui_module_ts"), __webpack_require__.e("src_app_pages_settings_settings_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/settings/settings.module */ 94932)).then(m => m.SettingsPageModule)
    },
    {
        path: 'order/confirm',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_models_watchlist_index_ts"), __webpack_require__.e("default-src_app_common-ui-components_symbols-search-dragable-modal_symbols-search-dragable-mo-b72097"), __webpack_require__.e("default-src_app_common-ui-components_tadawul-common-ui_module_ts"), __webpack_require__.e("default-src_app_pages_order_confirm_order-confirm_page_ts-src_app_pages_order_order_page_ts"), __webpack_require__.e("default-src_app_pages_login_button_index_ts"), __webpack_require__.e("common"), __webpack_require__.e("src_app_pages_order_confirm_order-confirm_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/order/confirm/order-confirm.module */ 62489)).then(m => m.OrderConfirmPageModule)
    },
    // {
    //   path: 'transfer',
    //   loadChildren: () => import('./pages/transfer/transfer.module').then(m => m.TransferPageModule)
    // },
    {
        path: 'markets',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_tradestation_markets-index_markets-index_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/tradestation/markets-index/markets-index.module */ 16031)).then(m => m.MarketsIndexPageModule)
    },
    {
        path: 'token-authentication',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_token-authentication_token-authentication_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./token-authentication/token-authentication.module */ 18999)).then(m => m.TokenAuthenticationPageModule)
    },
    // {
    //   path: 'contact-us',
    //   loadChildren: () => import('./pages/contact-us/contact-us.module').then( m => m.ContactUsPageModule)
    // }
    // {
    //   path: 'products',
    //   loadChildren: () => import('./pages/products/products/products.module').then(m => m.ProductsPageModule)
    // },
    // {
    //   path: 'product-details',
    //   loadChildren: () => import('./pages/products/product-details/product-details.module').then(m => m.ProductDetailsPageModule)
    // },
    // {
    //   path: 'product-subscribe',
    //   loadChildren: () => import('./pages/products/product-subscribe/product-subscribe.module').then(m => m.ProductSubscribePageModule)
    // },
    // {
    //   path: 'product-subscribe-summary',
    //   loadChildren: () => import('./pages/products/product-subscribe-summary/product-subscribe-summary.module').then(m => m.ProductSubscribeSummaryPageModule)
    // },
    {
        path: 'dynamic-authentication',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_dynamic-authentication_dynamic-authentication_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./dynamic-authentication/dynamic-authentication.module */ 80917)).then(m => m.DynamicAuthenticationPageModule)
    },
    {
        path: 'biometric-authentication',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_dynamic-authentication_biometric-authentication_biometric-authentication_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./dynamic-authentication/biometric-authentication/biometric-authentication.module */ 96393)).then(m => m.BiometricAuthenticationPageModule)
    },
    {
        path: 'forget-username-password',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_forget-username-password_forget-username-password_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/forget-username-password/forget-username-password.module */ 41172)).then(m => m.ForgetUsernamePasswordPageModule)
    },
    {
        path: 'disconnection-page',
        loadChildren: () => Promise.resolve(/*! import() */).then(__webpack_require__.bind(__webpack_require__, /*! ./disconnection-page/disconnection-page.module */ 68886)).then(m => m.DisconnectionPagePageModule)
    },
    {
        path: 'session-expired',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_models_watchlist_index_ts"), __webpack_require__.e("default-src_app_common-ui-components_symbols-search-dragable-modal_symbols-search-dragable-mo-b72097"), __webpack_require__.e("default-src_app_common-ui-components_tadawul-common-ui_module_ts"), __webpack_require__.e("src_app_pages_session-expired_session-expired_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/session-expired/session-expired.module */ 10252)).then(m => m.SessionExpiredPageModule)
    },
    {
        path: 'loading',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_models_watchlist_index_ts"), __webpack_require__.e("default-src_app_common-ui-components_symbols-search-dragable-modal_symbols-search-dragable-mo-b72097"), __webpack_require__.e("default-src_app_common-ui-components_tadawul-common-ui_module_ts"), __webpack_require__.e("src_app_loading_loading_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./loading/loading.module */ 8701)).then(m => m.LoadingPageModule)
    },
    {
        path: 'id-expired',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_models_watchlist_index_ts"), __webpack_require__.e("default-src_app_common-ui-components_symbols-search-dragable-modal_symbols-search-dragable-mo-b72097"), __webpack_require__.e("default-src_app_common-ui-components_tadawul-common-ui_module_ts"), __webpack_require__.e("common"), __webpack_require__.e("src_app_pages_id-expired_id-expired_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/id-expired/id-expired.module */ 85984)).then(m => m.IdExpiredPageModule)
    },
    {
        path: 'nav-modal',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_common-ui-components_symbols-search-dragable-modal_symbols-search-dragable-mo-b72097"), __webpack_require__.e("default-src_app_pages_order_confirm_order-confirm_page_ts-src_app_pages_order_order_page_ts"), __webpack_require__.e("src_app_pages_nav-modal_nav-modal_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/nav-modal/nav-modal.module */ 53418)).then(m => m.NavModalPageModule)
    },
    {
        path: 'portfolio-actions',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_models_watchlist_index_ts"), __webpack_require__.e("default-src_app_common-ui-components_symbols-search-dragable-modal_symbols-search-dragable-mo-b72097"), __webpack_require__.e("default-src_app_common-ui-components_tadawul-common-ui_module_ts"), __webpack_require__.e("src_app_pages_portfolio-actions_portfolio-actions_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/portfolio-actions/portfolio-actions.module */ 76739)).then(m => m.PortfolioActionsPageModule)
    },
    {
        path: 'mutual-fund-actions',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_pages_mutual-funds_mutual-fund-actions_mutual-fund-actions_page_ts"), __webpack_require__.e("src_app_pages_mutual-funds_mutual-fund-actions_mutual-fund-actions_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/mutual-funds/mutual-fund-actions/mutual-fund-actions.module */ 11266)).then(m => m.MutualFundActionsPageModule)
    },
    {
        path: 'notifications',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_models_watchlist_index_ts"), __webpack_require__.e("default-src_app_common-ui-components_symbols-search-dragable-modal_symbols-search-dragable-mo-b72097"), __webpack_require__.e("default-src_app_common-ui-components_tadawul-common-ui_module_ts"), __webpack_require__.e("common")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/notifications/notifications.module */ 38617)).then(m => m.NotificationsPageModule)
    },
    // {
    //   path: 'contact-us',
    //   loadChildren: () => import('./pages/contact-us/contact-us.module').then( m => m.ContactUsPageModule)
    // }
    // {
    //   path: 'contact-us',
    //   loadChildren: () => import('./pages/contact-us/contact-us.module').then( m => m.ContactUsPageModule)
    // }
    //#endregion
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgModule)({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule.forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__.PreloadAllModules })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule]
    })
], AppRoutingModule);



/***/ }),

/***/ 20721:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "App": () => (/* binding */ App),
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component.html?ngResource */ 33383);
/* harmony import */ var _app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component.scss?ngResource */ 79259);
/* harmony import */ var _pages_session_expired_session_expired_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pages/session-expired/session-expired.page */ 25905);
/* harmony import */ var _events_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./events.service */ 31782);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ 91714);
/* harmony import */ var _inma_helpers_console__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @inma/helpers/console */ 56031);
/* harmony import */ var _pages_menu__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pages/menu */ 69626);
/* harmony import */ var _inma_helpers_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @inma/helpers/http */ 36802);
/* harmony import */ var _inma_environment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @inma/environment */ 80960);
/* harmony import */ var _models_users__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./🌱models/users */ 17166);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _models_users_authentication__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./🌱models/users/authentication */ 93143);
/* harmony import */ var _token_authentication_token_authentication_page__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./token-authentication/token-authentication.page */ 14522);
/* harmony import */ var _inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @inma/helpers/biometric */ 16406);
/* harmony import */ var _helpers_settings__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../helpers/settings */ 96892);
/* harmony import */ var _dynamic_authentication_dynamic_authentication_page__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./dynamic-authentication/dynamic-authentication.page */ 66631);
/* harmony import */ var src_environments_backends__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/environments/backends */ 23923);
/* harmony import */ var _capacitor_keyboard__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @capacitor/keyboard */ 10523);
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @capacitor/core */ 26549);
/* harmony import */ var _ionic_native_sms_retriever_ngx__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ionic-native/sms-retriever/ngx */ 53615);
/* harmony import */ var _ionic_native_mobile_accessibility_ngx__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ionic-native/mobile-accessibility/ngx */ 15992);
/* harmony import */ var _capacitor_splash_screen__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @capacitor/splash-screen */ 82239);
/* harmony import */ var _capacitor_status_bar__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @capacitor/status-bar */ 19326);
/* harmony import */ var _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @ionic-native/network/ngx */ 99118);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! jquery */ 85139);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var _common_ui_components_internet_disconnected_internet_disconnected_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./common-ui-components/internet-disconnected/internet-disconnected.component */ 41319);
/* harmony import */ var _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @inma/helpers/cached */ 569);
/* harmony import */ var _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @inma/helpers/streaming */ 9199);
/* harmony import */ var _src_helpers_toast__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ../../src/helpers/toast */ 51139);
/* harmony import */ var _inma_helpers_refreshable__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @inma/helpers/refreshable */ 2281);
/* harmony import */ var _models_symbol__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./🌱models/symbol */ 61202);
/* harmony import */ var _models_market__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./🌱models/market */ 1874);
/* harmony import */ var _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @inma/helpers/injector */ 19753);
/* harmony import */ var _models_authentication_authentication_model__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./🌱models/authentication/authentication.model */ 83443);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _helpers_constants__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./helpers/constants */ 31777);
/* harmony import */ var _helpers_helper__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./helpers/helper */ 57022);
var AppComponent_1;








// import { SplashScreen } from '@ionic-native/splash-screen/ngx';






























const { Storage } = _capacitor_core__WEBPACK_IMPORTED_MODULE_17__.Plugins;




let AppComponent = AppComponent_1 = class AppComponent {
    constructor(platform, 
    // private splashScreen: SplashScreen,
    statusBar, router, translate, 
    // private settingsService: SettingsService,
    modalCtrl, navCtrl, 
    // private routerOutlet: IonRouterOutlet
    smsRetriever, mobileAccessibility, zone, network, event, appHelper, toastController, document, routerOutlet) {
        this.platform = platform;
        this.statusBar = statusBar;
        this.router = router;
        this.translate = translate;
        this.modalCtrl = modalCtrl;
        this.navCtrl = navCtrl;
        this.smsRetriever = smsRetriever;
        this.mobileAccessibility = mobileAccessibility;
        this.zone = zone;
        this.network = network;
        this.event = event;
        this.appHelper = appHelper;
        this.toastController = toastController;
        this.document = document;
        this.routerOutlet = routerOutlet;
        this.Users = _models_users__WEBPACK_IMPORTED_MODULE_9__.Users;
        this.JSON = JSON;
        this.Environment = _inma_environment__WEBPACK_IMPORTED_MODULE_8__.Environment;
        this.Backends = src_environments_backends__WEBPACK_IMPORTED_MODULE_15__.Backends;
        this.MenuComponent = _pages_menu__WEBPACK_IMPORTED_MODULE_6__.MenuComponent;
        this.routerDirection = 'rtl';
        this.App = App;
        // this.appHelper.mapLocalized()
        _helpers_settings__WEBPACK_IMPORTED_MODULE_13__.Settings.getUserPreferences(_helpers_constants__WEBPACK_IMPORTED_MODULE_33__.Constants._SETTINGS._PREFERRED_LANG).subscribe((lang) => {
            if (lang) {
                localStorage.setItem(_helpers_constants__WEBPACK_IMPORTED_MODULE_33__.Constants._SETTINGS._PREFERRED_LANG, lang.toString());
                this.handleLanguagePreferences(lang.toString());
            }
        });
        AppComponent_1.navCtrl = navCtrl;
        AppComponent_1.refreshCurrentURL();
        if (_inma_environment__WEBPACK_IMPORTED_MODULE_8__.Environment.isDevelopment && !AppComponent_1.isAnonymousRouteActive()) {
            _helpers_settings__WEBPACK_IMPORTED_MODULE_13__.Settings.getUserPreferences("user").subscribe((user) => {
                if (user && user != "undefined")
                    _models_users__WEBPACK_IMPORTED_MODULE_9__.Users.current = JSON.parse(user);
            });
        }
        // this.routerOutlet.swipeGesture = false;
        _inma_helpers_console__WEBPACK_IMPORTED_MODULE_5__.Console.printImage(window.location.origin + "/assets/console/AlinmaInvestmentConsole2.png", 10);
        this.initializeApp();
        AppComponent_1.instance = this;
        this.router.events.subscribe(this.onRouteChange.bind(this));
        _models_users_authentication__WEBPACK_IMPORTED_MODULE_10__.Authentication2.authenticationGroupsSubject.subscribe((groups) => {
            this.handleDynamicAuthenticationGroups(groups);
        });
        // this.event.subscribe('CHANGE_APP_ROUTER', (lang) => {
        //   if (lang) {
        //     this.routerDirection = lang == 'ar' ? 'rtl' : 'ltr';
        //   }
        // })
    }
    static refreshCurrentURL() {
        var _a;
        AppComponent_1.currentURL =
            AppComponent_1.currentURL || ((_a = window === null || window === void 0 ? void 0 : window.location) === null || _a === void 0 ? void 0 : _a.pathname);
    }
    handleDynamicAuthenticationGroups(groups) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_35__.__awaiter)(this, void 0, void 0, function* () {
            if (groups.length == 1) {
                _token_authentication_token_authentication_page__WEBPACK_IMPORTED_MODULE_11__.TokenAuthenticationPage.group = groups[0];
                const modal = yield this.modalCtrl.create({
                    id: 'TOKEN_MODAL',
                    component: _token_authentication_token_authentication_page__WEBPACK_IMPORTED_MODULE_11__.TokenAuthenticationPage,
                    // presentingElement: this.routerOutlet == null ? await this.modalCtrl.getTop() : this.routerOutlet.nativeEl,
                    cssClass: 'auto-height-modal',
                    swipeToClose: true,
                });
                modal.onDidDismiss()
                    .then((data) => {
                    if (data.data != null) {
                    }
                });
                return yield modal.present();
                this.navCtrl.navigateForward("/token-authentication");
            }
            else {
                // if (Authentication2.touchIdAvailable) {
                //    let authenticationGroup: AuthenticationGroup = groups.find(group => group.groupName == "3")
                //    if (authenticationGroup) {
                //      let biometricAuthenticationModal = await this.modalCtrl.create({
                //       component: 'BiometricAuthenticationPage', componentProps: { group: authenticationGroup, action: this.authenticationService.sourceAction }});
                //      biometricAuthenticationModal.present();
                //    }
                //    else
                //     //  this.nav.push('DynamicAuthenticationPage', { groups: response.result.groups });
                //  }
                //  else
                _dynamic_authentication_dynamic_authentication_page__WEBPACK_IMPORTED_MODULE_14__.DynamicAuthenticationPage.authenticationGroups = groups;
                // UNDO this.navCtrl.navigateForward("/dynamic-authentication");
                _dynamic_authentication_dynamic_authentication_page__WEBPACK_IMPORTED_MODULE_14__.DynamicAuthenticationPage.open();
                // this.nav.push('/token-authentication', { groups: groups });
            }
        });
    }
    initializeApp() {
        var _a, _b;
        if (_capacitor_core__WEBPACK_IMPORTED_MODULE_17__.Capacitor.isNativePlatform()) {
            AppComponent_1.initPushwoosh();
        }
        this.translate.addLangs(['en', 'ar']);
        this.handleLanguagePreferences('en');
        this.handleLanguagePreferences('ar');
        this.changeNGXLanguage();
        // Settings.setLanguage();
        _helpers_settings__WEBPACK_IMPORTED_MODULE_13__.Settings.setTheme();
        this.routerDirection = this.translate.currentLang == 'ar' ? 'rtl' : 'ltr';
        this.currentLang = this.translate.currentLang;
        document.addEventListener("deviceready", () => { }, false);
        this.platform.ready().then(() => {
            var _a, _b;
            _inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_12__.Biometric.initialize();
            setTimeout(() => {
                _capacitor_splash_screen__WEBPACK_IMPORTED_MODULE_20__.SplashScreen.hide();
            }, 1000);
            // To avoid calling Capacitor.isPluginAvailable
            if (_capacitor_core__WEBPACK_IMPORTED_MODULE_17__.Capacitor.isPluginAvailable("StatusBar"))
                _capacitor_status_bar__WEBPACK_IMPORTED_MODULE_21__.StatusBar.setOverlaysWebView({ overlay: true });
            this.statusBar.overlaysWebView(true);
            this.applyStatusbarStyle(true);
            this.statusBar.backgroundColorByHexString("#005157");
            this.mobileAccessibility.usePreferredTextZoom(false);
            if (this.platform.is("capacitor") &&
                (this.platform.is("ios") || this.platform.is("android"))) {
                (_b = (_a = window.screen) === null || _a === void 0 ? void 0 : _a.orientation) === null || _b === void 0 ? void 0 : _b.lock("portrait");
                _capacitor_keyboard__WEBPACK_IMPORTED_MODULE_16__.Keyboard.setAccessoryBarVisible({ isVisible: true });
                _capacitor_keyboard__WEBPACK_IMPORTED_MODULE_16__.Keyboard.addListener("keyboardWillShow", (info) => {
                    console.log("keyboard will show with height", info.keyboardHeight);
                    document.body.classList.add("keyboard-is-open");
                    // this.event.publish('KEYBOARD_SHOW');
                    // alert('keyboard is open app component')
                });
                // Can be wrapped in a class
                _capacitor_keyboard__WEBPACK_IMPORTED_MODULE_16__.Keyboard.addListener("keyboardWillHide", () => {
                    console.log("keyboard will hide");
                    document.body.classList.remove("keyboard-is-open");
                    // this.event.publish('KEYBOARD_HIDE');
                    // alert('keyboard is hidden app component ')
                });
            }
            if (this.platform.is("android")) {
                this.smsRetriever
                    .getAppHash()
                    .then((res) => console.log(res))
                    .catch((error) => console.error(error));
                App.platformType = 'android';
            }
            // SplashScreen.hide();
        });
        this.platform.resume.subscribe(() => (0,tslib__WEBPACK_IMPORTED_MODULE_35__.__awaiter)(this, void 0, void 0, function* () {
            if (_models_users__WEBPACK_IMPORTED_MODULE_9__.Users.current) {
                (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_25__.resetCache)(_models_authentication_authentication_model__WEBPACK_IMPORTED_MODULE_32__.Authentication, "checkLoggedUser");
                _models_authentication_authentication_model__WEBPACK_IMPORTED_MODULE_32__.Authentication.checkLoggedUser.subscribe((result => {
                    if (result == true) {
                        debugger;
                        if (App.isActive("/main/tabs/tradestation")) {
                            const zone = _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_31__.Injector.get(_angular_core__WEBPACK_IMPORTED_MODULE_36__.NgZone);
                            _models_market__WEBPACK_IMPORTED_MODULE_30__.Market.connectToStream().subscribe((marketInfoMessage) => {
                                zone.run(() => {
                                    const streamedMarketInfo = JSON.parse(marketInfoMessage["data"]);
                                    _models_market__WEBPACK_IMPORTED_MODULE_30__.Market._info.next(streamedMarketInfo);
                                });
                            });
                            _models_symbol__WEBPACK_IMPORTED_MODULE_29__.Symbols.connectToStream();
                        }
                        else if (App.isActive("/tadawul-home") || App.isActive("/main/tabs")) {
                            const zone = _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_31__.Injector.get(_angular_core__WEBPACK_IMPORTED_MODULE_36__.NgZone);
                            _models_market__WEBPACK_IMPORTED_MODULE_30__.Market.connectToStream().subscribe((marketInfoMessage) => {
                                zone.run(() => {
                                    const streamedMarketInfo = JSON.parse(marketInfoMessage["data"]);
                                    _models_market__WEBPACK_IMPORTED_MODULE_30__.Market._info.next(streamedMarketInfo);
                                });
                            });
                        }
                    }
                    else if (result == false) {
                        debugger;
                        this.goToLogoutPage();
                    }
                }));
                // resetCache(Kyc, "detailsIncomeSourcesList");
                // Kyc.detailsIncomeSourcesList.subscribe(
                //   (incomeSourcesList: any[]) => {
                //     if (App.isActive("/tradestation")) {
                //       const zone = Injector.get(NgZone);
                //       Market.connectToStream().subscribe((marketInfoMessage) => {
                //         zone.run(() => {
                //           const streamedMarketInfo = JSON.parse(marketInfoMessage["data"]);
                //           Market._info.next(streamedMarketInfo);
                //         })
                //       });
                //       Symbols.connectToStream();
                //     } else if (App.isActive("/tadawul-home")) {
                //       const zone = Injector.get(NgZone);
                //       Market.connectToStream().subscribe((marketInfoMessage) => {
                //         zone.run(() => {
                //           const streamedMarketInfo = JSON.parse(marketInfoMessage["data"]);
                //           Market._info.next(streamedMarketInfo);
                //         })
                //       });
                //     }
                //   }
                // );
            }
        }));
        this.platform.pause.subscribe(() => (0,tslib__WEBPACK_IMPORTED_MODULE_35__.__awaiter)(this, void 0, void 0, function* () {
            _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_26__.Streaming.disconnect();
        }));
        // this.changeLanguage(); //init with LTR direction
        //#region sessionExpiry
        _inma_helpers_http__WEBPACK_IMPORTED_MODULE_7__.Http.sessionExpirySubject.subscribe((response) => {
            _models_users__WEBPACK_IMPORTED_MODULE_9__.Users.autoLogin();
        });
        //#endregion
        let tryingToConnect = false;
        let streamingFailureWindow = null;
        _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_26__.Streaming.connectionChangeSubject.subscribe((status) => {
            if (!status) {
                if (streamingFailureWindow)
                    return;
                console.log('setTimeout');
                streamingFailureWindow = setTimeout(() => {
                    AppComponent_1.goToLogoutPage();
                }, 5 * 60 * 1000);
            }
            else {
                console.log('clearTimeout');
                clearTimeout(streamingFailureWindow);
                streamingFailureWindow = null;
            }
        });
        if (((_a = _inma_environment__WEBPACK_IMPORTED_MODULE_8__.Environment.labs) === null || _a === void 0 ? void 0 : _a.enabled) && ((_b = _inma_environment__WEBPACK_IMPORTED_MODULE_8__.Environment.labs) === null || _b === void 0 ? void 0 : _b.streamingInstablity)) {
            _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_26__.Streaming.connectionChangeSubject.subscribe((status) => {
                if (!status) {
                    _src_helpers_toast__WEBPACK_IMPORTED_MODULE_27__.Toast.present("محاولة اعادة الاتصال ", { class: 'server-error-toast', timer: { period: 10, callback: null } });
                    tryingToConnect = true;
                }
                else if (tryingToConnect) {
                    _src_helpers_toast__WEBPACK_IMPORTED_MODULE_27__.Toast.present("اعادة الاتصال بنجاح", { class: 'server-success-toast', duration: 5, icon: 'cloud-done-outline' });
                    (0,_inma_helpers_cached__WEBPACK_IMPORTED_MODULE_25__.resetGlobalCaches)();
                    (0,_inma_helpers_refreshable__WEBPACK_IMPORTED_MODULE_28__.refreshAll)();
                }
            });
        }
        this.trackConnection();
    }
    handleLanguagePreferences(lang) {
        if (lang == 'ar') {
            this.translate.setDefaultLang('ar');
            this.translate.use('ar');
            this.document.documentElement.dir = 'rtl';
        }
        else if (lang == 'en') {
            this.translate.setDefaultLang('en');
            this.translate.use('en');
            this.document.documentElement.dir = 'ltr';
        }
    }
    trackConnection() {
        // watch network for a disconnection
        let disconnectSubscription = this.network.onDisconnect().subscribe(() => {
            //alert('network was disconnected :-(');
            if (!AppComponent_1.currentURL ||
                AppComponent_1.currentURL == "/" ||
                AppComponent_1.currentURL == "/login") {
                AppComponent_1.loggedoutDisconnected = true;
            }
            else {
                AppComponent_1.loggedoutDisconnected = true;
                this.presentInternetDisconnectionModal();
            }
        });
        // stop disconnect watch
        //disconnectSubscription.unsubscribe();
        // watch network for a connection
        let connectSubscription = this.network.onConnect().subscribe(() => {
            // alert('network connected!');
            AppComponent_1.loggedoutDisconnected = false;
        });
    }
    //open force update page
    static openForceUpdatePage() {
        this.navCtrl.navigateRoot('force-update');
    }
    // present internet connection error
    presentInternetDisconnectionModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_35__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _common_ui_components_internet_disconnected_internet_disconnected_component__WEBPACK_IMPORTED_MODULE_24__.InternetDisconnectedComponent,
                cssClass: "disconnect-modal",
            });
            modal.onDidDismiss().then(() => { });
            return yield modal.present();
        });
    }
    // static get menu() {
    //   return this.instance?.menu;
    // }
    //#endregion
    //#region Routing
    onRouteChange(event) {
        if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_37__.NavigationStart) {
            AppComponent_1.currentURL = event.url;
            this.statusBar.styleDefault();
            if (!AppComponent_1.currentURL ||
                AppComponent_1.currentURL == "/" ||
                AppComponent_1.currentURL == "/login")
                this.applyStatusbarStyle(true);
            else {
                if (!this.isThemeDark() &&
                    AppComponent_1.currentURL == "main/tabs")
                    this.applyStatusbarStyle(false);
                else
                    this.applyStatusbarStyle(true);
            }
            // alert(AppComponent.currentURL)
        }
        // NavigationStart
        // NavigationEnd
        // NavigationCancel
        // NavigationError
        // RoutesRecognized
    }
    applyStatusbarStyle(light) {
        // alert(light ? 'light' : 'dark');
        if (_capacitor_core__WEBPACK_IMPORTED_MODULE_17__.Capacitor.isPluginAvailable("StatusBar"))
            _capacitor_status_bar__WEBPACK_IMPORTED_MODULE_21__.StatusBar.setStyle({
                style: light ? _capacitor_status_bar__WEBPACK_IMPORTED_MODULE_21__.StatusBarStyle.Dark : _capacitor_status_bar__WEBPACK_IMPORTED_MODULE_21__.StatusBarStyle.Light,
            });
    }
    static isActive(link = null) {
        var _a;
        const menuIsOpen = _pages_menu__WEBPACK_IMPORTED_MODULE_6__.Menu.isOpen;
        const result = (link == this.currentURL ||
            (!!link && link != "/" && ((_a = this.currentURL) === null || _a === void 0 ? void 0 : _a.startsWith(link)))) &&
            !menuIsOpen;
        return result;
    }
    static isAnonymousRouteActive() {
        return (App.isActive() ||
            App.isActive("/") ||
            App.isActive("/login") ||
            App.isActive("/token-authentication") ||
            App.isActive("/disconnection-page") ||
            App.isActive("/dynamic-authentication") ||
            App.isActive("/biometric-authentication") ||
            App.isActive("/forget-username-password") ||
            App.isActive("/session-expired") ||
            App.isActive("/id-expired"));
    }
    static restart(onRestart, showSpash = true) {
        if (showSpash)
            _capacitor_splash_screen__WEBPACK_IMPORTED_MODULE_20__.SplashScreen.show({ fadeInDuration: 0, fadeOutDuration: 0 });
        if (onRestart)
            onRestart();
        window.location = AppComponent_1.initialHref;
    }
    //#endregion
    //Toggle Dark/light theme
    toggleTheme() {
        document.body.classList.toggle("dark");
        const prefersDark = window.matchMedia("(prefers-color-scheme: dark)");
    }
    isThemeDark() {
        return jquery__WEBPACK_IMPORTED_MODULE_23__(document.body).hasClass("dark");
    }
    //Toggle Rtl/ltr mode
    // changeLanguage() {
    //   if (document.documentElement.getAttribute("dir") == "rtl") {
    //     document.documentElement.setAttribute("dir", "ltr");
    //     Settings.language = Languages.English;
    //   } else {
    //     document.documentElement.setAttribute("dir", "rtl");
    //     Settings.language = Languages.Arabic;
    //   }
    // }
    changeNGXLanguage() {
        this.translate.onLangChange.subscribe((event) => {
            this.event.publish(_helpers_constants__WEBPACK_IMPORTED_MODULE_33__.Constants._EVENT._LANGUAGE_CHANGED, event.lang);
            if (event.lang == 'ar') {
                this.translate.setDefaultLang('ar');
                this.translate.use('ar');
                this.document.documentElement.dir = 'rtl';
            }
            else {
                this.translate.setDefaultLang('en');
                this.translate.use('en');
                this.document.documentElement.dir = 'ltr';
            }
        });
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_35__.__awaiter)(this, void 0, void 0, function* () {
            // this.//  = Network.addListener('networkStatusChange', (status) => {
            //   this.zone.run(() => {
            //     console.log("Network status changed", status);
            //     this.networkStatus = status;
            //     if (status.connected == false) {
            //       if (TabbarComponent.isTabbarVisible) {
            //         this.navCtrl.navigateRoot("/disconnection-page");
            //         // Streaming.disconnect();
            //       }
            //     } else {
            //       if (App.isActive('/disconnection-page')) {
            //         setTimeout(() => {
            //           Streaming.connect().subscribe(connected => {
            //             setTimeout(() => {
            //               resetGlobalCaches();
            //               this.navCtrl.navigateRoot('/tadawul-home/home');
            //             }, 100);
            //           })
            //         }, 100);
            //       }
            //     }
            //   });
            // });
            // this.networkStatus = await Network.getStatus();
        });
    }
    ngOnDestroy() {
        // this.// .remove();
    }
    static initPushwoosh() {
        var pushNotification = window.plugins.pushNotification;
        //initialize Pushwoosh with projectid: "YOUR_FCM_SENDER_ID", appid : "PUSHWOOSH_APP_ID". This will trigger all pending push notifications on start.
        pushNotification.onDeviceReady({
            projectid: "545068156778",
            appid: "0188D-D8B48",
            serviceName: ""
        });
        //register for push notifications
        var app = this;
        if (localStorage.getItem(_helpers_settings__WEBPACK_IMPORTED_MODULE_13__.Settings.enableNotficationKey) == "true" || localStorage.getItem(_helpers_settings__WEBPACK_IMPORTED_MODULE_13__.Settings.enableNotficationKey) == null) {
            pushNotification.registerDevice(function (status) {
                //  alert("registered with token: " + status.pushToken);
            }, function (status) {
                //  alert("failed to register: " + status);
                // alert(JSON.stringify(['failed to register ', status]));
            });
        }
        else if (localStorage.getItem(_helpers_settings__WEBPACK_IMPORTED_MODULE_13__.Settings.enableNotficationKey) == "false") {
            pushNotification.unregisterDevice(function (status) {
                // alert("unregisterDevice with token: ");
            }, function (status) {
                //  alert("failed to unregister: ");
                //console.warn(JSON.stringify(['failed to unregister ', status]));
            });
        }
    }
    //Error Handling Code
    logout(serverSide = true) {
        // this.menu.close('menu');
        _models_users__WEBPACK_IMPORTED_MODULE_9__.Users.logout(serverSide).subscribe(() => {
            AppComponent_1.restart(() => {
                setTimeout(() => {
                    this.navCtrl.navigateRoot('login', { animated: false });
                }, 100);
            });
        });
    }
    //! Horrible place to place code
    static logout(serverSide = true, restartMessage = null) {
        var _a;
        if (restartMessage)
            Storage.set({ key: "RESTART_MESSAGE", value: restartMessage });
        (_a = AppComponent_1.instance) === null || _a === void 0 ? void 0 : _a.logout(serverSide);
    }
    static goToLogoutPage() {
        var _a;
        (_a = AppComponent_1.instance) === null || _a === void 0 ? void 0 : _a.goToLogoutPage();
    }
    goToLogoutPage() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_35__.__awaiter)(this, void 0, void 0, function* () {
            AppComponent_1.refreshCurrentURL();
            const modal = yield this.modalCtrl.create({
                component: _pages_session_expired_session_expired_page__WEBPACK_IMPORTED_MODULE_2__.SessionExpiredPage,
                cssClass: 'auto-height-modal session-expired ipad-full-width-modal',
                swipeToClose: false,
                backdropDismiss: false
            });
            return yield modal.present();
        });
    }
    static showError(message, callback = null) {
        var _a;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_35__.__awaiter)(this, void 0, void 0, function* () {
            if (!message || (message === null || message === void 0 ? void 0 : message.trim()) == 'undefined')
                return;
            // message = message || '';
            if (AppComponent_1.errorsHistory[message]) {
                if (AppComponent_1.errorsHistory[message].opened) {
                    return;
                }
                else {
                    const now = new Date().getTime();
                    const history = AppComponent_1.errorsHistory[message].date.getTime();
                    if ((now - history) < ERROR_MIN_TIME_AMOUNT)
                        return;
                }
            }
            AppComponent_1.errorsHistory[message] = { date: new Date(), opened: true };
            ////
            const toastController = (_a = AppComponent_1.instance) === null || _a === void 0 ? void 0 : _a.toastController;
            const toast = yield toastController.create({
                message: message,
                duration: 4000,
                cssClass: "info-alert"
                // buttons: [
                //   {
                //     text: 'Done',
                //     icon: 'star',
                //     role: 'cancel',
                //     handler: () => {
                //       console.log('Cancel clicked');
                //     }
                //   }
                // ]
            });
            toast.onDidDismiss().then(() => {
                if (AppComponent_1.errorsHistory[message])
                    AppComponent_1.errorsHistory[message].opened = false;
            });
            toast.present().then(callback === null || callback === void 0 ? void 0 : callback());
        });
    }
};
AppComponent.loggedoutDisconnected = false;
// networkListener: PluginListenerHandle;
AppComponent.ExpiredUserID = false;
AppComponent.idExpiryDate = false;
AppComponent.platformType = '';
AppComponent.initialHref = window.location.origin;
//!TODO: refactor this
AppComponent.errorsHistory = {};
AppComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_38__.Platform },
    { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__.StatusBar },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_37__.Router },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_39__.TranslateService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_38__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_38__.NavController },
    { type: _ionic_native_sms_retriever_ngx__WEBPACK_IMPORTED_MODULE_18__.SmsRetriever },
    { type: _ionic_native_mobile_accessibility_ngx__WEBPACK_IMPORTED_MODULE_19__.MobileAccessibility },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_36__.NgZone },
    { type: _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_22__.Network },
    { type: _events_service__WEBPACK_IMPORTED_MODULE_3__.EventsService },
    { type: _helpers_helper__WEBPACK_IMPORTED_MODULE_34__.AppHelper },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_38__.ToastController },
    { type: Document, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_36__.Inject, args: [_angular_common__WEBPACK_IMPORTED_MODULE_40__.DOCUMENT,] }] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_38__.IonRouterOutlet, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_36__.Optional }] }
];
AppComponent.propDecorators = {
    ionRouter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_36__.ViewChild, args: ['router',] }],
    menu: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_36__.ViewChild, args: [_pages_menu__WEBPACK_IMPORTED_MODULE_6__.MenuComponent,] }]
};
AppComponent = AppComponent_1 = (0,tslib__WEBPACK_IMPORTED_MODULE_35__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_36__.Component)({
        selector: "app-root",
        template: _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_35__.__metadata)("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_38__.Platform,
        _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__.StatusBar,
        _angular_router__WEBPACK_IMPORTED_MODULE_37__.Router,
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_39__.TranslateService,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_38__.ModalController,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_38__.NavController,
        _ionic_native_sms_retriever_ngx__WEBPACK_IMPORTED_MODULE_18__.SmsRetriever,
        _ionic_native_mobile_accessibility_ngx__WEBPACK_IMPORTED_MODULE_19__.MobileAccessibility,
        _angular_core__WEBPACK_IMPORTED_MODULE_36__.NgZone,
        _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_22__.Network,
        _events_service__WEBPACK_IMPORTED_MODULE_3__.EventsService,
        _helpers_helper__WEBPACK_IMPORTED_MODULE_34__.AppHelper,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_38__.ToastController,
        Document,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_38__.IonRouterOutlet])
], AppComponent);

const ERROR_MIN_TIME_AMOUNT = 1000 * 4;
const App = AppComponent;


/***/ }),

/***/ 50023:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule),
/* harmony export */   "createTranslateLoader": () => (/* binding */ createTranslateLoader)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _inma_helpers_file__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/helpers/file */ 96245);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @angular/platform-browser */ 50318);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ 37954);
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ 91714);
/* harmony import */ var ngx_navigation_with_data__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ngx-navigation-with-data */ 5430);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app-routing.module */ 70809);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app.component */ 20721);
/* harmony import */ var _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @inma/helpers/injector */ 19753);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @angular/common/http */ 28784);
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @angular/platform-browser/animations */ 73598);
/* harmony import */ var _ionic_native_globalization_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/globalization/ngx */ 90893);
/* harmony import */ var _ionic_native_http_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/http/ngx */ 44719);
/* harmony import */ var _common_ui_components_development_development_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./common-ui-components/development/development.component */ 36523);
/* harmony import */ var _ionic_native_keychain_touch_id_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/keychain-touch-id/ngx */ 11746);
/* harmony import */ var _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/social-sharing/ngx */ 96772);
/* harmony import */ var _ionic_native_sms_retriever_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/sms-retriever/ngx */ 53615);
/* harmony import */ var _ionic_native_mobile_accessibility_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic-native/mobile-accessibility/ngx */ 15992);
/* harmony import */ var _disconnection_page_disconnection_page_module__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./disconnection-page/disconnection-page.module */ 68886);
/* harmony import */ var _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic-native/network/ngx */ 99118);
/* harmony import */ var _ionic_native_vibration_ngx__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic-native/vibration/ngx */ 59076);
/* harmony import */ var _ionic_native_native_page_transitions_ngx__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ionic-native/native-page-transitions/ngx */ 78810);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @ngx-translate/http-loader */ 75347);
/* harmony import */ var ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ion-bottom-drawer */ 74272);
/* harmony import */ var _helpers_localized_string__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./helpers/localized-string */ 41734);
/* harmony import */ var _helpers_helper__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./helpers/helper */ 57022);
/* harmony import */ var _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ionic-native/in-app-browser/ngx */ 49048);
/* harmony import */ var _ionic_native_open_native_settings_ngx__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @ionic-native/open-native-settings/ngx */ 21512);
/* harmony import */ var _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @ionic-native/diagnostic/ngx */ 20593);
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ 23081);
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @ionic-native/file/ngx */ 12358);



































function createTranslateLoader(http) {
    return new _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_24__.TranslateHttpLoader(http, './assets/i18n/', '.json');
}
let AppModule = class AppModule {
    constructor(injector) {
        this.injector = injector;
    }
};
AppModule.ctorParameters = () => [
    { type: _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_5__.Injector }
];
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_26__.NgModule)({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_4__.AppComponent, _common_ui_components_development_development_component__WEBPACK_IMPORTED_MODULE_8__.DevelopmentComponent],
        entryComponents: [],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_27__.BrowserModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_28__.IonicModule.forRoot({
                mode: "ios",
                animated: true,
                rippleEffect: true,
                swipeBackEnabled: true,
                scrollPadding: false,
                scrollAssist: true,
                // platforms: {
                // ios: {
                //   scrollAssist: false,
                //   autoFocusAssist: false,
                //   scrollPadding: false,
                // },
                // android: {
                //   scrollAssist: false,
                //   autoFocusAssist: false,
                //   scrollPadding: true,
                // },
                // },
            }),
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_29__.TranslateModule.forRoot({
                loader: {
                    provide: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_29__.TranslateLoader,
                    useFactory: (createTranslateLoader),
                    deps: [_angular_common_http__WEBPACK_IMPORTED_MODULE_30__.HttpClient]
                }
            }),
            _app_routing_module__WEBPACK_IMPORTED_MODULE_3__.AppRoutingModule,
            _angular_common_http__WEBPACK_IMPORTED_MODULE_30__.HttpClientModule,
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_31__.BrowserAnimationsModule,
            _disconnection_page_disconnection_page_module__WEBPACK_IMPORTED_MODULE_13__.DisconnectionPagePageModule,
            ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_32__.IonBottomDrawerModule
            // TadawulCommonUiModule
        ],
        providers: [
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_2__.StatusBar,
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_1__.SplashScreen,
            { provide: _angular_router__WEBPACK_IMPORTED_MODULE_33__.RouteReuseStrategy, useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_28__.IonicRouteStrategy },
            _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_5__.Injector,
            _ionic_native_globalization_ngx__WEBPACK_IMPORTED_MODULE_6__.Globalization,
            _ionic_native_http_ngx__WEBPACK_IMPORTED_MODULE_7__.HTTP,
            ngx_navigation_with_data__WEBPACK_IMPORTED_MODULE_34__.NgxNavigationWithDataComponent,
            _ionic_native_keychain_touch_id_ngx__WEBPACK_IMPORTED_MODULE_9__.KeychainTouchId,
            _helpers_localized_string__WEBPACK_IMPORTED_MODULE_17__.LocalizedString,
            _helpers_helper__WEBPACK_IMPORTED_MODULE_18__.AppHelper,
            //  HttpRequestService,
            _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_10__.SocialSharing,
            _ionic_native_sms_retriever_ngx__WEBPACK_IMPORTED_MODULE_11__.SmsRetriever,
            _ionic_native_mobile_accessibility_ngx__WEBPACK_IMPORTED_MODULE_12__.MobileAccessibility,
            _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_14__.Network,
            // ChartHelper,
            _ionic_native_vibration_ngx__WEBPACK_IMPORTED_MODULE_15__.Vibration,
            _ionic_native_native_page_transitions_ngx__WEBPACK_IMPORTED_MODULE_16__.NativePageTransitions,
            _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_19__.InAppBrowser,
            _ionic_native_open_native_settings_ngx__WEBPACK_IMPORTED_MODULE_20__.OpenNativeSettings,
            _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_21__.Diagnostic,
            _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_19__.InAppBrowser,
            _ionic_native_native_page_transitions_ngx__WEBPACK_IMPORTED_MODULE_16__.NativePageTransitions,
            _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_22__.FileOpener,
            _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_23__.File,
            _inma_helpers_file__WEBPACK_IMPORTED_MODULE_0__.Files
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_4__.AppComponent]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:paramtypes", [_inma_helpers_injector__WEBPACK_IMPORTED_MODULE_5__.Injector])
], AppModule);



/***/ }),

/***/ 32801:
/*!*************************************!*\
  !*** ./src/app/app.translations.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppTranslations": () => (/* binding */ AppTranslations)
/* harmony export */ });
class AppTranslations {
    constructor() {
        this.SELECT = ['اختر', 'Select'];
        this.OK = ["اختيار", "Ok"];
        this.CANCEL = ["إلغاء", "Cancel"];
        this.CONFIRM = ["تأكيد", "Confirm"];
        this.DONE = ["تم", "Done"];
        this.SLASH = ["\\", "/"];
        this.PLEASE_CHOOSE = ["الرجاء اختيار", "Please choose a valid"];
        this.PLEASE_ENTER = ["الرجاء إدخال", "Please enter a"];
        this.CORRECT_PATTERN = ["بالنمط الصحيح", "in correct pattern"];
        this.alertOK = ["موافق", "Ok"];
        this.alertHeader = ["تنبيه", "Alert"];
        this.REQUIREDFIELDS = ["الرجاء ادخال الحقول المطلوبة", "Please fill Required Fields"];
        this.SHOULD_BE_LESS = ["يجب أن يكون أقل من أو يساوي", "should be less than or equal"];
        this.SHOULD_BE_GREATER = ["يجب أن يكون أكبر من أو يساوي", "should be greater than or equal"];
        this.SHOULD_BE_EQUALS = ["يجب أن يساوي", "should equals"];
        this.CURRENCY = ["ر.س", "SAR"];
        this.SAR = ["ر.س", "SAR"];
        this.units = ["وحدات", "units"];
        this.B = ["شراء", "Buy"];
        this.S = ["بيع", "Sell"];
        this.BUYING_POWER_VALIDATION = ["قيمة أمر الشراء أكبر من القدرة الشرائية", "Order value is more than buying power"];
        this.OWNED_QUANTITY_VALIDATION = ["الكمية المباعة أكبر من الكمية المتاحة", "Order quantity is more than owned quanity"];
        //modal translation
        this.SECTORS_INDEX_PAGE_TITLE = ['مؤشر القطاعات', 'Sectors'];
    }
}


/***/ }),

/***/ 36523:
/*!***************************************************************************!*\
  !*** ./src/app/common-ui-components/development/development.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DevelopmentComponent": () => (/* binding */ DevelopmentComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _development_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./development.component.html?ngResource */ 11453);
/* harmony import */ var _development_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./development.component.scss?ngResource */ 41938);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/environment */ 80960);
/* harmony import */ var _inma_models_users__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/models/users */ 17166);
var DevelopmentComponent_1;






const createReport = null;
var inputElement;
let DevelopmentComponent = DevelopmentComponent_1 = class DevelopmentComponent {
    constructor() {
        this.Users = _inma_models_users__WEBPACK_IMPORTED_MODULE_3__.Users;
        this.Environment = _inma_environment__WEBPACK_IMPORTED_MODULE_2__.Environment;
        this.state = DevelopmentComponent_1.captureStarted;
        DevelopmentComponent_1.instance = this;
    }
    static set captureStarted(cS) {
        DevelopmentComponent_1._captureStarted = this.instance.state = cS;
    }
    static get captureStarted() {
        return DevelopmentComponent_1._captureStarted;
    }
    ngAfterViewInit() {
        // var request = new XMLHttpRequest();
        // request.open('GET', 'assets/templates/template.docx', true);
        // request.responseType = 'blob';
        // request.onload = function () {
        //   var reader = new FileReader();
        //   reader.onload = function (e) {
        //     console.log('[capturing] Template was loaded');
        //     DevelopmentComponent.template = (e.target as any).result;
        //     // onTemplateChosen(e.target.result);
        //   };
        //   reader.readAsArrayBuffer(request.response);
        // };
        // request.send();
    }
    start() {
        DevelopmentComponent_1.captureStarted = this.state = true;
    }
    stop() {
        DevelopmentComponent_1.captureStarted = this.state = false;
    }
};
DevelopmentComponent._captureStarted = false;
DevelopmentComponent.ctorParameters = () => [];
DevelopmentComponent.propDecorators = {
    state: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.HostBinding, args: ['class.started',] }]
};
DevelopmentComponent = DevelopmentComponent_1 = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'development-component',
        template: _development_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_4__.ViewEncapsulation.None
        // styles: [`
        //   display: block;
        //   color: white;
        //   display: block;
        //   position: absolute;
        //   width: 100%;
        //   padding: 16px;
        //   background: #83AFBA;
        //   text-align: center;`]
        ,
        styles: [_development_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:paramtypes", [])
], DevelopmentComponent);

// export async function generateRequestDoc(params: {service, action, subaction, description, parameters, sample: {header, body, response}}) {
//   if (DevelopmentComponent.captureStarted == false) return;
//   if (Environment.requestDocs.filters) {
//     if ((Environment.requestDocs.filters as any).service && !params.service.match((Environment.requestDocs.filters as any).service)) return;
//   }
//   const template = DevelopmentComponent.template;
//   console.log('Creating RequestDoc (can take some time) ...');
//   const report = await createReport({
//     template,
//     data: params
//   });
//   saveDataToFile(
//     report,
//     `${params.service}/${params.action}/${params.subaction}.docx`,
//     'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
//   );
// }
// const saveDataToFile = (data, fileName, mimeType) => {
//   const blob = new Blob([data], { type: mimeType });
//   const url = window.URL.createObjectURL(blob);
//   downloadURL(url, fileName);
// };
// const downloadURL = (url, fileName) => {
//   var a = document.createElement("a");
//   a.href = url;
//   a.setAttribute("download", fileName);
//   a.click();
// };


/***/ }),

/***/ 66169:
/*!***********************************************************************************************!*\
  !*** ./src/app/common-ui-components/internet-disconnected/internet-disconnect.translation.ts ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InternetDisconnectTranslations": () => (/* binding */ InternetDisconnectTranslations)
/* harmony export */ });
/* harmony import */ var src_app_app_translations__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/app.translations */ 32801);

class Translations extends src_app_app_translations__WEBPACK_IMPORTED_MODULE_0__.AppTranslations {
    constructor() {
        super(...arguments);
        this.textOne = ['لايوجد اتصال بالإنترنت', 'No internet connection'];
        this.textTwo = ["الرجاء التأكد من توفر الاتصال بالإنترنت", "Please check your internet availability"];
        this.goToLogin = ['الذهاب إلى صفحة الدخول', 'Go to login page'];
    }
}
const InternetDisconnectTranslations = new Translations();


/***/ }),

/***/ 41319:
/*!***********************************************************************************************!*\
  !*** ./src/app/common-ui-components/internet-disconnected/internet-disconnected.component.ts ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InternetDisconnectedComponent": () => (/* binding */ InternetDisconnectedComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _internet_disconnected_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./internet-disconnected.component.html?ngResource */ 71664);
/* harmony import */ var _internet_disconnected_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./internet-disconnected.component.scss?ngResource */ 52080);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_helpers_translations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/helpers/translations */ 69353);
/* harmony import */ var _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/network/ngx */ 99118);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/app.component */ 20721);
/* harmony import */ var _internet_disconnect_translation__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./internet-disconnect.translation */ 66169);









let InternetDisconnectedComponent = class InternetDisconnectedComponent {
    constructor(modalControl, network, platform, navCtrl) {
        this.modalControl = modalControl;
        this.network = network;
        this.platform = platform;
        this.navCtrl = navCtrl;
        this.t = _internet_disconnect_translation__WEBPACK_IMPORTED_MODULE_5__.InternetDisconnectTranslations;
    }
    ngOnInit() {
        // watch network for a connection
        let connectSubscription = this.network.onConnect().subscribe(() => {
            src_app_app_component__WEBPACK_IMPORTED_MODULE_4__.AppComponent.loggedoutDisconnected = false;
            this.modalControl.dismiss();
        });
    }
    ionViewDidEnter() {
        this.disableBackBtn = this.platform.backButton.subscribeWithPriority(9999, () => {
            // do nothing
        });
    }
    ionViewWillLeave() {
        this.disableBackBtn.unsubscribe();
    }
    goToLoginPage() {
        this.modalControl.dismiss();
        this.navCtrl.navigateRoot('login', { animated: false });
        //MenuComponent.logout(false);
    }
};
InternetDisconnectedComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController },
    { type: _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_3__.Network },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.Platform },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController }
];
(0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_inma_helpers_translations__WEBPACK_IMPORTED_MODULE_2__.Translations)(),
    (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__metadata)("design:type", Object)
], InternetDisconnectedComponent.prototype, "t", void 0);
InternetDisconnectedComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'tadawul-internet-disconnected',
        template: _internet_disconnected_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_internet_disconnected_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__metadata)("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController, _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_3__.Network, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.Platform, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController])
], InternetDisconnectedComponent);



/***/ }),

/***/ 76952:
/*!*************************************************************************!*\
  !*** ./src/app/disconnection-page/disconnection-page-routing.module.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DisconnectionPagePageRoutingModule": () => (/* binding */ DisconnectionPagePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _disconnection_page_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./disconnection-page.page */ 21423);




const routes = [
    {
        path: '',
        component: _disconnection_page_page__WEBPACK_IMPORTED_MODULE_0__.DisconnectionPagePage
    }
];
let DisconnectionPagePageRoutingModule = class DisconnectionPagePageRoutingModule {
};
DisconnectionPagePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], DisconnectionPagePageRoutingModule);



/***/ }),

/***/ 68886:
/*!*****************************************************************!*\
  !*** ./src/app/disconnection-page/disconnection-page.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DisconnectionPagePageModule": () => (/* binding */ DisconnectionPagePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _disconnection_page_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./disconnection-page-routing.module */ 76952);
/* harmony import */ var _disconnection_page_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./disconnection-page.page */ 21423);







let DisconnectionPagePageModule = class DisconnectionPagePageModule {
};
DisconnectionPagePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _disconnection_page_routing_module__WEBPACK_IMPORTED_MODULE_0__.DisconnectionPagePageRoutingModule
        ],
        declarations: [_disconnection_page_page__WEBPACK_IMPORTED_MODULE_1__.DisconnectionPagePage]
    })
], DisconnectionPagePageModule);



/***/ }),

/***/ 21423:
/*!***************************************************************!*\
  !*** ./src/app/disconnection-page/disconnection-page.page.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DisconnectionPagePage": () => (/* binding */ DisconnectionPagePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _disconnection_page_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./disconnection-page.page.html?ngResource */ 94436);
/* harmony import */ var _disconnection_page_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./disconnection-page.page.scss?ngResource */ 49183);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_helpers_background_timer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/helpers/background-timer */ 47435);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../app.component */ 20721);






let DisconnectionPagePage = class DisconnectionPagePage {
    constructor() {
        this.period = 4 * 1000;
    }
    ngOnDestroy() {
        this.retryTimer.cancel();
    }
    ngOnInit() {
        this.retryTimer = new _inma_helpers_background_timer__WEBPACK_IMPORTED_MODULE_2__.BackgroundTimer(this.period, () => {
            _app_component__WEBPACK_IMPORTED_MODULE_3__.AppComponent.logout(false, "Reconnection retries failed !");
        });
        this.timerDisplayValue = this.formatTime(this.period);
        this.retryTimer.enableTicking(1000, (remaining) => {
            this.timerDisplayValue = this.formatTime(remaining);
        });
        this.retryTimer.start();
    }
    formatTime(t) {
        t /= 1000;
        let minutes = parseInt(String(t / 60));
        let minutesText = (minutes < 10) ? "0" + minutes : minutes;
        let seconds = parseInt(String(t % 60));
        let secondsText = (seconds < 10) ? "0" + seconds : seconds;
        return minutesText + ":" + secondsText;
    }
};
DisconnectionPagePage.ctorParameters = () => [];
DisconnectionPagePage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'tadawul-disconnection-page',
        template: _disconnection_page_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_disconnection_page_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__metadata)("design:paramtypes", [])
], DisconnectionPagePage);



/***/ }),

/***/ 66631:
/*!***********************************************************************!*\
  !*** ./src/app/dynamic-authentication/dynamic-authentication.page.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DynamicAuthenticationPage": () => (/* binding */ DynamicAuthenticationPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _dynamic_authentication_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dynamic-authentication.page.html?ngResource */ 62193);
/* harmony import */ var _dynamic_authentication_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dynamic-authentication.page.scss?ngResource */ 41419);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/helpers/biometric */ 16406);
/* harmony import */ var _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/helpers/injector */ 19753);
/* harmony import */ var _inma_helpers_translations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/helpers/translations */ 69353);
/* harmony import */ var _inma_models_authentication_authentication_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @inma/models/authentication/authentication.model */ 83443);
/* harmony import */ var _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @inma/models/users/authentication */ 93143);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _token_authentication_token_authentication_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../token-authentication/token-authentication.page */ 14522);
/* harmony import */ var _dynamic_authentication_translations__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./dynamic-authentication.translations */ 34229);
var DynamicAuthenticationPage_1;













let DynamicAuthenticationPage = DynamicAuthenticationPage_1 = class DynamicAuthenticationPage {
    constructor(navCtrl, modalCtrl, translate) {
        this.navCtrl = navCtrl;
        this.modalCtrl = modalCtrl;
        this.translate = translate;
        this.t = _dynamic_authentication_translations__WEBPACK_IMPORTED_MODULE_8__.DynamicAuthenticationTranslations;
        // if (Authentication2.touchIdAvailable && Biometric.isAvailableSync) {
        //   let authenticationGroup: AuthenticationGroup = this.authenticationGroups.find(group => group.groupName == Authentication2.biometricGroupNumber)
        //   this.goToBiometricPage(authenticationGroup, Authentication2.sourceAction);
        // }
    }
    get authenticationGroups() {
        return DynamicAuthenticationPage_1.authenticationGroups;
    }
    get selectedGroup() {
        return DynamicAuthenticationPage_1.selectedGroup;
    }
    set selectedGroup(value) {
        DynamicAuthenticationPage_1.selectedGroup = value;
    }
    static open() {
        if (_inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_6__.Authentication2.touchIdAvailable && _inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_2__.Biometric.isAvailableSync) {
            let authenticationGroup = this.authenticationGroups.find(group => group.groupName == _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_6__.Authentication2.biometricGroupNumber);
            this.goToBiometricPage(authenticationGroup, _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_6__.Authentication2.sourceAction);
        }
        else {
            const navCtrl = _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_3__.Injector.get(_ionic_angular__WEBPACK_IMPORTED_MODULE_9__.NavController);
            navCtrl.navigateForward("/dynamic-authentication");
        }
    }
    ionViewDidLoad() {
        this.selectedGroup = _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_6__.Authentication2.smsGroupNumber;
    }
    goToTokenPage() {
        DynamicAuthenticationPage_1.goToTokenPage();
    }
    static goToTokenPage() {
        let selectedAuthenticationGroup;
        for (var i = 0; i < this.authenticationGroups.length; i++) {
            if (this.authenticationGroups[i].groupName == this.selectedGroup)
                selectedAuthenticationGroup = this.authenticationGroups[i];
        }
        if (this.selectedGroup == _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_6__.Authentication2.biometricGroupNumber && _inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_2__.Biometric.isAvailableSync) {
            DynamicAuthenticationPage_1.goToBiometricPage(selectedAuthenticationGroup, _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_6__.Authentication2.sourceAction);
        }
        else {
            _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_6__.Authentication2.generateAuthenticationToken(this.selectedGroup)
                .subscribe((result) => (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
                _token_authentication_token_authentication_page__WEBPACK_IMPORTED_MODULE_7__.TokenAuthenticationPage.group = selectedAuthenticationGroup;
                const modalCtrl = _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_3__.Injector.get(_ionic_angular__WEBPACK_IMPORTED_MODULE_9__.ModalController);
                const tokenAuthenticationModal = yield modalCtrl.create({
                    id: 'TOKEN_MODAL',
                    component: _token_authentication_token_authentication_page__WEBPACK_IMPORTED_MODULE_7__.TokenAuthenticationPage,
                    cssClass: 'auto-height-modal',
                    swipeToClose: true
                });
                return yield tokenAuthenticationModal.present();
            }));
        }
    }
    // isStored = false;
    static goToBiometricPage(authenticationGroup, action) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            this.opened = true;
            if (!_inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_2__.Biometric.type) {
                this.handleTokenPage();
            }
            _inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_2__.Biometric.verify("Verify" + (action == "Authenticate" ? action : "Other")).subscribe(result => {
                if (result) {
                    if (result == "NOT_STORED" || result == "NOT_VERIFIED" || result == "CANCELLED" || (result === null || result === void 0 ? void 0 : result.startsWith('Error'))) {
                        this.handleTokenPage();
                    }
                    else {
                        var storedUsername = result.split('#:#')[0];
                        var storedKey = result.split('#:#')[1];
                        this.authenticateBiometric(authenticationGroup, storedUsername, storedKey);
                    }
                }
                else {
                    if (this.opened) {
                        _inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_2__.Biometric["delete"]().subscribe();
                        this.handleTokenPage();
                    }
                }
            });
        });
    }
    static handleTokenPage() {
        this.opened = false;
        this.selectedGroup = _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_6__.Authentication2.smsGroupNumber;
        this.goToTokenPage();
    }
    static authenticateBiometric(authenticationGroup, storedUsername, storedKey) {
        console.log("Login key " + storedKey);
        _inma_models_authentication_authentication_model__WEBPACK_IMPORTED_MODULE_5__.Authentication.encrypt(storedKey).subscribe(encryptedKey => {
            authenticationGroup.methods[0].value = encryptedKey;
            console.log("Login Key encrypted" + encryptedKey);
            _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_6__.Authentication2.authenticateSourceAction(authenticationGroup.groupName, authenticationGroup.methods)
                .subscribe(response => {
                if (response) {
                    _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_6__.Authentication2.dynamicAuthenticationSubject.next(response);
                }
                else {
                    _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_6__.Authentication2.dynamicAuthenticationSubject.error(response);
                }
                _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_6__.Authentication2.dynamicAuthenticationSubject.complete();
            });
        });
    }
};
DynamicAuthenticationPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.ModalController },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__.TranslateService }
];
(0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_inma_helpers_translations__WEBPACK_IMPORTED_MODULE_4__.Translations)(),
    (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__metadata)("design:type", Object)
], DynamicAuthenticationPage.prototype, "t", void 0);
DynamicAuthenticationPage = DynamicAuthenticationPage_1 = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.Component)({
        selector: 'tadawul-dynamic-authentication',
        template: _dynamic_authentication_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_dynamic_authentication_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__metadata)("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_9__.NavController, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.ModalController, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__.TranslateService])
], DynamicAuthenticationPage);



/***/ }),

/***/ 34229:
/*!*******************************************************************************!*\
  !*** ./src/app/dynamic-authentication/dynamic-authentication.translations.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DynamicAuthenticationTranslations": () => (/* binding */ DynamicAuthenticationTranslations)
/* harmony export */ });
/* harmony import */ var _app_translations__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../app.translations */ 32801);

class Translations extends _app_translations__WEBPACK_IMPORTED_MODULE_0__.AppTranslations {
    constructor() {
        super(...arguments);
        this["touchAuthenticate"] = ["دخول بالبصمة", "Login With Fingerprint"];
        this["faceAuthenticate"] = ["دخول ببصمة الوجه", "Login With Face ID"];
        this["touchOther"] = ["تأكيد بالبصمة", "Verify With Fingerprint"];
        this["faceOther"] = ["تأكيد ببصمة الوجه", "Verify With Face ID"];
        this["touchVerifyAuthenticate"] = ["من فضلك سجل بصمتك لتسجيل الدخول للتطبيق", "Please provide your Fingerprint to Login to the App"];
        this["touchVerifyOther"] = ["من فضلك سجل بصمتك من أجل إتمام العملية", "Please provide your Fingerprint to complete the transaction"];
        this["faceVerifyAuthenticate"] = ["من فضلك قم بتأكيد بصمة وجهك لتسجيل الدخول للتطبيق", "Please verfiy your Face to Login to the App"];
        this["faceVerifyOther"] = ["من فضلك قم بتأكيد بصمة وجهك من أجل إتمام العملية", "Please verfiy your Face to complete the transaction"];
        this["touchStoreConfirm"] = ["هل تريد التسجيل بخدمة البصمة لتطبيق تداول الإنماء؟", "Do you want to register in Fingerprint service for Alinma Tadawul application?"];
        this["faceStoreConfirm"] = ["هل تريد التسجيل بخدمة بصمة الوجه لتطبيق تداول الإنماء؟", "Do you want to register in Face Verification service for Alinma Tadawul application?"];
        this["termsFingerPrint"] = [
            "<div class='alert-container'><p>نموذج شروط وأحكام خدمة التحقق بالبصمة</p><p>حيث إنني أرغب بالحصول على خدمة معيار التحقق الثاني باستخدام (البصمة) فقد وافقت على شروط وأحكام الخدمة الآتي بيانها:</p> <ol> <li>تعد هذه الخدمة سارية المفعول وتحت مسئوليتي اعتباراً من تاريخه مالم تتسلم الإنماء للاستثمار طلباً إلكترونياً مني بإلغاء الاشتراك بالخدمة، أو تتسلم إشعارا بوفاتي.</li> <li>لا تلزمني شركة الإنماء للاستثمار بحد أدنى من الرصيد، ولا توجد رسوم اشتراك للخدمة ويمكنني إلغاء الاشتراك في أي وقت، وتعد صلاحية الخدمة مفتوحة ما لم أتقدم للإنماء للاستثمار بطلب خطي يفيد بعدم رغبتي في تجديد الخدمة.</li> <li>سأتولى تنشيط الخدمة من القناة الإلكترونية المخصصة لذلك.</li> <li>يخضع هذا الطلب للشروط والأحكام الواردة في اتفاقية فتح الحساب الجاري.</li> <li>أقر بأن جميع بصمات الأصابع المحفوظة على الجهاز هي بصمات أصابع يدي.</li> </ol></div>",
            "<div class='alert-container'><p>Fingerprint Biometric Authentication Service Terms and Conditions Form</p> <p>Whereas I desire to avail the second-factor fingerprint authentication; now, therefore, I agree to the service terms and conditions below stated:</p> <ol> <li>This service is deemed valid effective immediately and under my sole responsibility unless otherwise is received by Alinma Investment from me through electronic means instructing the cancellation of my subscription to the service, or unless Alinma Investment receives a notice of my death.</li> <li>No minimum balance is required by Alinma Investment for the service. No service subscription fee is charged, and I am entitled to cancel my subscription to the service at any time I desire. The service availability is open-ended, unless I instruct Alinma Investment in writing of my wish to cancel the renewal of my subscription to the service.</li> <li>I will activate the service from the specified electronic channel.</li> <li>This request is subject to the terms and conditions of the Current Account Opening Agreement.</li> <li>I acknowledge that all the fingerprints saved on the device are of my own.</li> </ol></div>"
        ];
        this["termsCancelFingerprint"] = [
            "<div class='alert-container'><p>نموذج طلب إلغاء خدمة التحقق بالبصمة</p> <p>حيث إنني أرغب بإلغاء خدمة معيار التحقق الثاني باستخدام (البصمة) فقد وافقت على الشروط والأحكام الآتية:</p> <ol> <li>تعد جميع الأعمال والتصرفات التي تمت قبل تاريخ&nbsp;هذا الطلب صحيحة وملزمة لي.</li> <li>لا يحق للإنماء للاستثمار أن تخصم من حسابي أي رسوم خاصة بإلغاء الخدمة. .</li> <li>ستقوم شركة الإنماء للاستثمار بإيقاف الخدمة من التطبيق فور تلقيها هذا الطلب.</li> </ol></div>",
            "<div class='alert-container'><p>Fingerprint Authentication Service Cancellation Request Form</p> <p>Whereas I desire to cancel the second-factor fingerprint authentication; now, therefore, I agree to the below-set terms and conditions:</p> <ol> <li>All activities and transactions conducted before the date of this form shall be deemed correct and binding.</li> <li>Alinma Investment is not entitled to deduct any fees from my account as cancellation fees.</li> <li>Alinma Investment will deactivate this service immediately in the application upon the receipt of this request.</li> </ol></div>"
        ];
        this["touchStoreSuccess"] = ["تم التسجيل بخدمة البصمة بنجاح", "You have registered successfully in Fingerprint service"];
        this["faceStoreSuccess"] = ["تم التسجيل بخدمة بصمة الوجه بنجاح", "You have registered successfully in Face Verification service"];
        this["touchStoreError"] = ["لم يتم التسجيل بخدمة البصمة", "You haven't registered in Fingerprint service"];
        this["faceStoreError"] = ["لم يتم التسجيل بخدمة بصمة الوجه", "You haven't registered in Face Verification service"];
        this["touchCancelSuccess"] = ["تم إلغاء التسجيل بخدمة البصمة بنجاح", "You registration in Fingerprint service have been Cancelled"];
        this["faceCancelSuccess"] = ["تم إلغاء التسجيل بخدمة بصمة الوجه بنجاح", "You registration in Face Verification service have been Cancelled"];
        this["touchCancelError"] = ["لم يتم إلغاء التسجيل بخدمة البصمة", "Fingerprint service haven't been cancelled"];
        this["faceCancelError"] = ["لم يتم إلغاء التسجيل بخدمة بصمة الوجه", "Face Verification service haven't been cancelled"];
        this.SELECT_ACTIVATION = ["اختر طريقة التفعيل", "Select Activation Method"];
        this.ACTIVATION = ["التفعيل", "Activation"];
        this.NEXT = ["التالي", "Next"];
        this.SUBMIT = ["إرسال", "Submit"];
    }
}
const DynamicAuthenticationTranslations = new Translations();


/***/ }),

/***/ 31782:
/*!***********************************!*\
  !*** ./src/app/events.service.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EventsService": () => (/* binding */ EventsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let EventsService = class EventsService {
    constructor() {
        this.c = new Map();
    }
    subscribe(topic, ...handlers) {
        let topics = this.c.get(topic);
        if (!topics) {
            this.c.set(topic, topics = []);
        }
        topics.push(...handlers);
    }
    unsubscribe(topic, handler) {
        if (!handler) {
            return this.c.delete(topic);
        }
        const topics = this.c.get(topic);
        if (!topics) {
            return false;
        }
        // We need to find and remove a specific handler
        const index = topics.indexOf(handler);
        if (index < 0) {
            // Wasn't found, wasn't removed
            return false;
        }
        topics.splice(index, 1);
        if (topics.length === 0) {
            this.c.delete(topic);
        }
        return true;
    }
    publish(topic, ...args) {
        const topics = this.c.get(topic);
        if (!topics) {
            return null;
        }
        return topics.map(handler => {
            try {
                return handler(...args);
            }
            catch (e) {
                console.error(e);
                return null;
            }
        });
    }
};
EventsService.ctorParameters = () => [];
EventsService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Injectable)({
        providedIn: 'root'
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__metadata)("design:paramtypes", [])
], EventsService);



/***/ }),

/***/ 31777:
/*!**************************************!*\
  !*** ./src/app/helpers/constants.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Constants": () => (/* binding */ Constants)
/* harmony export */ });
class Constants {
}
Constants._EVENT = {
    _LANGUAGE_CHANGED: 'LANG_CHANGED'
};
Constants._SETTINGS = {
    _ENABLE_NOTIFICATION: "NOTIFICATION_ENABLED",
    _ENABLE_BIOMETRIC: "BIOMETRIC_ENABLED",
    _PREFERRED_LANG: "PREFERED_LANGUAGE",
    _PREFERRED_THEME: "PREFERED_THEME",
};


/***/ }),

/***/ 57022:
/*!***********************************!*\
  !*** ./src/app/helpers/helper.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppHelper": () => (/* binding */ AppHelper)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let AppHelper = class AppHelper {
    constructor() {
        this.mapper = {
            CHANGE_PASSWORD: ['تغيير كلمة المرور', 'Change Password'],
            CURRENT_PASSWORD: ['كلمة المرور الحالية', 'Current Password'],
            FORGOT_PASSWORD: ['نسيت كلمة المرور', 'Forgot Password'],
            NEW_PASSWORD: ['كلمة المرور الجديدة', 'New Password'],
            CONFIRM_NEW_PASSWORD: ['تأكيد كلمة المرور الجديدة', 'Confirm New Password'],
            SAVE_CHANGES: ['حفظ التغييرات', 'Save Changes'],
            PASSWORD_RULES: [
                'كلمة المرور يجب ان لاتقل عن 8 خانات ولا تزيد عن 16\n\rكلمة المرور يجب ان تحتوي على الاقل على حرف واحد او رقم واحد\n\rكلمة المرور يجب ان لا تحتوي على فراغات\n\rكلمة المرور يجب ان لا تكون مطابقة لاسم المستخدم\n\rكلمة المرور حساسة لحالة الحروف الصغيرة والكبيرة\n\rكلمة المرور يجب ان لا تحتوي على رموز',
                'Password should be at least 8 characters and not more than 16 \n\r Password should have at least one charachter or one digit \n\r Password should not have spaces \n\r Password should not be the same as user name \n\r Password is case sensitive \n\r Password should not have symbols'
            ],
            CURRENT_PASSWORD_REQUIRED: ['الرجاء ادخال كلمة المرور الحالية', 'Please enter the current password'],
            NEW_PASSWORD_REQUIRED: ['الرجاء ادخال كلمة المرور الجديدة', 'Please enter the new password'],
            CONFIRM_PASSWORD_REQUIRED: ['الرجاء ادخال تأكيد كلمة المرور الجديدة', 'Please enter the confirm password'],
            PASSWORD_PATTERN: ['كلمة المرور يجب ان لا تحتوي على رموز', 'Password should not have symbols '],
            PASSWORD_MIN: ['كلمة المرور يجب أن لا تقل عن ٨ خانات', 'Password should be at least 8 characters'],
            PASSWORD_MAX: ['كلمة المرور يجب أن لا تكون اكثر من ١٦ خانة', 'Password should not be more than 16 characters'],
            UNMATCHED_PASSWORD: ['تأكيد كلمة المرور يجب ان يكون مطابق لكلمة المرور الجديدة', 'Confirm password must match the new password'],
        };
    }
    mapLocalized() {
        let ar = '', en = '';
        Object.keys(this.mapper).forEach((val) => {
            ar += '"' + val + '":"' + this.mapper[val][0] + '",';
            en += '"' + val + '":"' + this.mapper[val][1] + '",';
        });
        console.log(ar);
        console.log(en);
    }
};
AppHelper.ctorParameters = () => [];
AppHelper = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Injectable)(),
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__metadata)("design:paramtypes", [])
], AppHelper);



/***/ }),

/***/ 41734:
/*!*********************************************!*\
  !*** ./src/app/helpers/localized-string.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LocalizedString": () => (/* binding */ LocalizedString)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ngx-translate/core */ 87514);



let LocalizedString = class LocalizedString {
    constructor(en, ar, trans) {
        this.arabicString = ar ? ar : '--';
        this.englishString = en ? en : '--';
        this.translate = trans;
        // this.translate.onLangChange.subscribe((event: LangChangeEvent) => {
        //   this.toString();
        // });
    }
    toString() {
        if (this.translate.currentLang == 'en') {
            return this.englishString;
        }
        else if (this.translate.currentLang == 'ar') {
            return this.arabicString;
        }
    }
};
LocalizedString.ctorParameters = () => [
    { type: String, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject, args: [String,] }] },
    { type: String, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject, args: [String,] }] },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_1__.TranslateService, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject, args: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_1__.TranslateService,] }] }
];
LocalizedString = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.Injectable)(),
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:paramtypes", [String, String, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_1__.TranslateService])
], LocalizedString);



/***/ }),

/***/ 77089:
/*!*****************************************!*\
  !*** ./src/app/loading/loading.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoadingPage": () => (/* binding */ LoadingPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _loading_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./loading.page.html?ngResource */ 60293);
/* harmony import */ var _loading_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./loading.page.scss?ngResource */ 60304);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let LoadingPage = class LoadingPage {
    constructor() { }
    ngOnInit() {
    }
};
LoadingPage.ctorParameters = () => [];
LoadingPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'tadawul-loading',
        template: _loading_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_3__.ViewEncapsulation.None,
        styles: [_loading_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:paramtypes", [])
], LoadingPage);



/***/ }),

/***/ 69626:
/*!*************************************!*\
  !*** ./src/app/pages/menu/index.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Menu": () => (/* reexport safe */ _menu_component__WEBPACK_IMPORTED_MODULE_0__.Menu),
/* harmony export */   "MenuComponent": () => (/* reexport safe */ _menu_component__WEBPACK_IMPORTED_MODULE_0__.MenuComponent)
/* harmony export */ });
/* harmony import */ var _menu_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./menu.component */ 88020);



/***/ }),

/***/ 88020:
/*!**********************************************!*\
  !*** ./src/app/pages/menu/menu.component.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Menu": () => (/* binding */ Menu),
/* harmony export */   "MenuComponent": () => (/* binding */ MenuComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _menu_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./menu.component.html?ngResource */ 62131);
/* harmony import */ var _menu_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./menu.component.scss?ngResource */ 92165);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _inma_models_users__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/models/users */ 17166);
/* harmony import */ var _inma_helpers_translations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/helpers/translations */ 69353);
/* harmony import */ var _menu_translations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./menu.translations */ 34822);
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @capacitor/core */ 26549);
/* harmony import */ var src_app_app_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/app.component */ 20721);
/* harmony import */ var _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @inma/helpers/settings */ 96892);
var MenuComponent_1;












const { Storage } = _capacitor_core__WEBPACK_IMPORTED_MODULE_5__.Plugins;
let MenuComponent = MenuComponent_1 = class MenuComponent {
    constructor(menu, 
    // private menuEnd: MenuController,
    navCtrl, toastController, platform) {
        this.menu = menu;
        this.navCtrl = navCtrl;
        this.toastController = toastController;
        this.platform = platform;
        this.AppComponent = src_app_app_component__WEBPACK_IMPORTED_MODULE_6__.AppComponent;
        this.t = _menu_translations__WEBPACK_IMPORTED_MODULE_4__.MenuTranslations;
        this.contentId = 'main';
        this.JSON = JSON;
        this.Users = _inma_models_users__WEBPACK_IMPORTED_MODULE_2__.Users;
        this.isOpen = false;
        MenuComponent_1.instance = this;
    }
    ngOnInit() {
    }
    open() {
        this.menu.enable(true, 'menu');
        this.menu.open('menu');
    }
    close() {
        this.menu.close('menu');
        // this.menu.close('start');
    }
    //#region isOpen
    static get isOpen() {
        var _a;
        return (_a = this.instance) === null || _a === void 0 ? void 0 : _a.isOpen;
    }
    onClose() {
        this.isOpen = false;
    }
    onOpen() {
        var _a, _b;
        this.isOpen = true;
        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_7__.Settings.getUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_7__.Settings.preferedThemeKey).subscribe(val => {
            if (val == null || val == "light-theme") {
                this.dark = false;
            }
            else {
                this.dark = true;
            }
        });
        if (_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_7__.Settings.language == _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_7__.Languages.Arabic) {
            this.userName = (_a = _inma_models_users__WEBPACK_IMPORTED_MODULE_2__.Users.current) === null || _a === void 0 ? void 0 : _a.nameAr;
        }
        else {
            this.userName = (_b = _inma_models_users__WEBPACK_IMPORTED_MODULE_2__.Users.current) === null || _b === void 0 ? void 0 : _b.nameEn;
        }
    }
    //#endregion
    logout(serverSide = true) {
        // this.menu.close('menu');
        _inma_models_users__WEBPACK_IMPORTED_MODULE_2__.Users.logout(serverSide).subscribe(() => {
            src_app_app_component__WEBPACK_IMPORTED_MODULE_6__.AppComponent.restart(() => {
                setTimeout(() => {
                    this.navCtrl.navigateRoot('login', { animated: false });
                }, 100);
            });
        });
    }
    //! Horrible place to place code
    static logout(serverSide = true, restartMessage = null) {
        var _a;
        if (restartMessage)
            Storage.set({ key: "RESTART_MESSAGE", value: restartMessage });
        (_a = MenuComponent_1.instance) === null || _a === void 0 ? void 0 : _a.logout(serverSide);
    }
    static goToLogoutPage() {
        var _a;
        (_a = MenuComponent_1.instance) === null || _a === void 0 ? void 0 : _a.goToLogoutPage();
    }
    goToLogoutPage() {
        src_app_app_component__WEBPACK_IMPORTED_MODULE_6__.AppComponent.refreshCurrentURL();
        this.navCtrl.navigateForward('/session-expired', { animated: true });
    }
    static showError(message, callback = null) {
        var _a;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            if (!message || (message === null || message === void 0 ? void 0 : message.trim()) == 'undefined')
                return;
            // message = message || '';
            if (MenuComponent_1.errorsHistory[message]) {
                if (MenuComponent_1.errorsHistory[message].opened) {
                    return;
                }
                else {
                    const now = new Date().getTime();
                    const history = MenuComponent_1.errorsHistory[message].date.getTime();
                    if ((now - history) < ERROR_MIN_TIME_AMOUNT)
                        return;
                }
            }
            MenuComponent_1.errorsHistory[message] = { date: new Date(), opened: true };
            ////
            const toastController = (_a = MenuComponent_1.instance) === null || _a === void 0 ? void 0 : _a.toastController;
            const toast = yield toastController.create({
                message: message,
                duration: 4000,
                cssClass: "info-alert"
                // buttons: [
                //   {
                //     text: 'Done',
                //     icon: 'star',
                //     role: 'cancel',
                //     handler: () => {
                //       console.log('Cancel clicked');
                //     }
                //   }
                // ]
            });
            toast.onDidDismiss().then(() => {
                if (MenuComponent_1.errorsHistory[message])
                    MenuComponent_1.errorsHistory[message].opened = false;
            });
            toast.present().then(callback === null || callback === void 0 ? void 0 : callback());
        });
    }
};
// get menu() {
//   return this.menuStart || this.menuEnd;
// }
MenuComponent.isLanguageToggled = false;
//!TODO: refactor this
MenuComponent.errorsHistory = {};
MenuComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.MenuController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.ToastController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.Platform }
];
(0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_inma_helpers_translations__WEBPACK_IMPORTED_MODULE_3__.Translations)(),
    (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__metadata)("design:type", Object)
], MenuComponent.prototype, "t", void 0);
MenuComponent = MenuComponent_1 = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-menu',
        template: _menu_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_menu_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__metadata)("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_9__.MenuController,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.NavController,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.ToastController,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.Platform])
], MenuComponent);

const ERROR_MIN_TIME_AMOUNT = 1000 * 4;
const Menu = MenuComponent;


/***/ }),

/***/ 34822:
/*!*************************************************!*\
  !*** ./src/app/pages/menu/menu.translations.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MenuTranslations": () => (/* binding */ MenuTranslations)
/* harmony export */ });
class Translations {
    constructor() {
        this.MODIFY_ACCOUNT = ['تعديل الحساب', 'Modify Account'];
        this.PRODUCTS = ['إدارة المنتجات', 'Products'];
        this.PORTFOLIOS = ['المحافظ', 'Portfolios'];
        this.MUTUAL_FUNDS = ['صناديق الاستثمار', 'Mutual Funds'];
        this.REPORTS = ['التقارير ', 'Reports'];
        this.SETTINGS = ['الإعدادات', 'Settings'];
        this.CONTACT = ['تواصل معنا', 'Contact'];
        this.SIGNOUT = ['خروج', 'Sign Out'];
        this.fundTransfer = ['تحويل الأموال', 'Fund Transfer'];
        this.searchOrder = ['بحث الأوامر', 'Orders Search'];
    }
}
const MenuTranslations = new Translations();


/***/ }),

/***/ 25905:
/*!***************************************************************!*\
  !*** ./src/app/pages/session-expired/session-expired.page.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SessionExpiredPage": () => (/* binding */ SessionExpiredPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _session_expired_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./session-expired.page.html?ngResource */ 97156);
/* harmony import */ var _session_expired_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./session-expired.page.scss?ngResource */ 25564);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_app_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/app.component */ 20721);






let SessionExpiredPage = class SessionExpiredPage {
    constructor(navCtrl) {
        this.navCtrl = navCtrl;
    }
    ngOnInit() {
        let noToggled = document.getElementById('not-toggled');
        if (noToggled)
            noToggled.setAttribute("style", "z-index: 100001;");
        let toggled = document.getElementById('toggled');
        if (toggled)
            toggled.setAttribute("style", "z-index: 100001;");
    }
    goToLoginPage() {
        src_app_app_component__WEBPACK_IMPORTED_MODULE_2__.AppComponent.logout(false);
    }
};
SessionExpiredPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController }
];
SessionExpiredPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'tadawul-session-expired',
        template: _session_expired_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_session_expired_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__metadata)("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController])
], SessionExpiredPage);



/***/ }),

/***/ 14522:
/*!*******************************************************************!*\
  !*** ./src/app/token-authentication/token-authentication.page.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TokenAuthenticationPage": () => (/* binding */ TokenAuthenticationPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _token_authentication_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./token-authentication.page.html?ngResource */ 89545);
/* harmony import */ var _token_authentication_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./token-authentication.page.scss?ngResource */ 15211);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_helpers_background_timer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/helpers/background-timer */ 47435);
/* harmony import */ var _inma_models_users__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/models/users */ 17166);
/* harmony import */ var _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/models/users/authentication */ 93143);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ionic_native_sms_retriever_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/sms-retriever/ngx */ 53615);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../app.component */ 20721);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 44661);
var TokenAuthenticationPage_1;











const ACTIVATION_CODE_LENGTH = 4;
const DELAY_TIME = 500;
let TokenAuthenticationPage = TokenAuthenticationPage_1 = class TokenAuthenticationPage {
    constructor(navCtrl, smsRetriever, ngZone, modalCtrl) {
        this.navCtrl = navCtrl;
        this.smsRetriever = smsRetriever;
        this.ngZone = ngZone;
        this.modalCtrl = modalCtrl;
        this.loading = false;
        this.groupNote = "";
        this.timerDisplayValue = 120000;
        this.timerEnded = false;
        this.visible = false;
        // this.initializeSMSCapture();
    }
    get authenticationGroup() {
        return TokenAuthenticationPage_1.group;
    }
    ngOnInit() {
    }
    ionViewDidLoad() {
        // console.log('ionViewDidLoad TokenAuthenticationPage');
        // this.authenticationGroup.methods[0].value = ""
        // this.renderDynamicContent();
    }
    ionViewDidEnter() {
        setTimeout(() => {
            setTimeout(() => {
                this.visible = true;
            }, 100);
            this.renderDynamicContent();
            window.setTimeout(() => {
                this.tokenInputField.setFocus();
            }, 100);
            this.smsRetriever.startWatching()
                .then((res) => console.log(res))
                .catch(() => {
                // console.error(error)
            });
            document.addEventListener('onSMSArrive', function (args) {
                // SMS arrived, get its contents
                console.info(args);
                console.info(args['Message']);
                let otp = args['Message'].match(/\d+/)[0];
                // To Do: Extract the received one-time code and verify it on your server
                this.authenticationGroup.methods[0].value = otp;
                setTimeout(() => {
                    this.submitToken();
                }, DELAY_TIME);
            });
        }, 0);
    }
    ionViewWillUnload() {
        if (this.authenticateTimer)
            this.authenticateTimer.cancel();
        if (this.backendTimer)
            this.backendTimer.cancel();
    }
    renderDynamicContent() {
        if (this.authenticationGroup.note && this.authenticationGroup.note.length > 0) {
            for (var i = 0; i < this.authenticationGroup.note.length; i++) {
                this.groupNote += this.authenticationGroup.note[i];
            }
        }
        if (this.authenticationGroup.timer) {
            this.groupTimer = new _inma_models_users__WEBPACK_IMPORTED_MODULE_3__.GroupTimer({ value: this.authenticationGroup.timer.value * 1000, label: this.authenticationGroup.timer.label });
            this.timerDisplayTime = this.formatTime(this.timerDisplayValue);
            this.backendTimer = new _inma_helpers_background_timer__WEBPACK_IMPORTED_MODULE_2__.BackgroundTimer(this.groupTimer.value, () => {
                //cachedErorr({msg:{msgCode:"",msgText:"Time out"}});
                //alert("timeout");
                _app_component__WEBPACK_IMPORTED_MODULE_6__.AppComponent.logout();
                // this.navCtrl.navigateRoot('login');
            });
            this.authenticateTimer = new _inma_helpers_background_timer__WEBPACK_IMPORTED_MODULE_2__.BackgroundTimer(this.timerDisplayValue, () => {
                this.timerEnded = true;
            });
            this.authenticateTimer.enableTicking(1000, function (remaining) {
                //if(pageIsActive)
                this.ngZone.run(() => {
                    this.timerDisplayTime = this.formatTime(remaining);
                });
                //	else
                //authenticateTimer.cancel();
            }.bind(this));
            this.backendTimer.start();
            this.authenticateTimer.start();
        }
    }
    formatTime(t) {
        t /= 1000;
        let minutes = parseInt(String(t / 60));
        let minutesText = (minutes < 10) ? "0" + minutes : minutes;
        let seconds = parseInt(String(t % 60));
        let secondsText = (seconds < 10) ? "0" + seconds : seconds;
        return minutesText + ":" + secondsText;
    }
    tokenInput(value) {
        if (this.authenticationGroup.groupName == _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_4__.Authentication2.smsGroupNumber) {
            if ((value === null || value === void 0 ? void 0 : value.length) == ACTIVATION_CODE_LENGTH) {
                // this.tokenInputField.setBlur();
                this.submitToken();
            }
        }
    }
    submitToken() {
        // if (!this.settingsService.loading) {
        if (!this.authenticationGroup.methods[0].value) {
            //alert("Please enter security key");
        }
        else {
            _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_4__.Authentication2.authenticateSourceAction(this.authenticationGroup.groupName, this.authenticationGroup.methods)
                .subscribe({
                next: (response) => {
                    if (this.authenticateTimer) {
                        this.authenticateTimer.cancel();
                    }
                    if (this.backendTimer) {
                        this.backendTimer.cancel();
                    }
                    if (this.backendTimer)
                        this.backendTimer.cancel();
                    if (response) {
                        //this.navCtrl.popToRoot();
                        _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_4__.Authentication2.dynamicAuthenticationSubject.next(response);
                        this.modalCtrl.dismiss(null, null, "TOKEN_MODAL");
                    }
                    else {
                        _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_4__.Authentication2.dynamicAuthenticationSubject.error(response);
                    }
                    _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_4__.Authentication2.dynamicAuthenticationSubject.complete();
                }
            });
        }
        //this.modalCtrl.dismiss();
        // }
    }
    onBack() {
        this.ionViewWillUnload();
        this.navCtrl.navigateRoot('/login');
        // MenuComponent.logout(false);
    }
    resendOTP() {
        if (!this.timerEnded) {
            return false;
        }
        this.loading = true;
        if (this.authenticateTimer)
            this.authenticateTimer.cancel();
        if (this.backendTimer)
            this.backendTimer.cancel();
        _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_4__.Authentication2.generateAuthenticationToken(this.authenticationGroup.groupName).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.finalize)(() => {
            this.loading = false;
        })).subscribe(result => {
            this.timerEnded = false;
            this.authenticateTimer.start();
            this.backendTimer.start();
        });
    }
};
TokenAuthenticationPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController },
    { type: _ionic_native_sms_retriever_ngx__WEBPACK_IMPORTED_MODULE_5__.SmsRetriever },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.NgZone },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController }
];
TokenAuthenticationPage.propDecorators = {
    tokenInputField: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ViewChild, args: ['tokenInputField',] }]
};
TokenAuthenticationPage = TokenAuthenticationPage_1 = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'tadawul-token-authentication',
        template: _token_authentication_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_token_authentication_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__metadata)("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController, _ionic_native_sms_retriever_ngx__WEBPACK_IMPORTED_MODULE_5__.SmsRetriever, _angular_core__WEBPACK_IMPORTED_MODULE_9__.NgZone,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController])
], TokenAuthenticationPage);



/***/ }),

/***/ 83443:
/*!*****************************************************************!*\
  !*** ./src/app/🌱models/authentication/authentication.model.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Authentication": () => (/* binding */ Authentication),
/* harmony export */   "AuthenticationModel": () => (/* binding */ AuthenticationModel)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 64139);
/* harmony import */ var _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/helpers/http */ 36802);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var _inma_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @inma/environment */ 80960);
/* harmony import */ var _inma_helpers_encoding__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/helpers/encoding */ 1247);
/* harmony import */ var _inma_helpers_rsa_encryption__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/helpers/rsa-encryption */ 1552);
/* harmony import */ var src_environments_base_environment_base__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/base/environment.base */ 78272);







class AuthenticationModel {
    encrypt(value) {
        if (_inma_environment__WEBPACK_IMPORTED_MODULE_1__.Environment.encryption === false)
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.of)(value);
        else if (_inma_environment__WEBPACK_IMPORTED_MODULE_1__.Environment.encryption === src_environments_base_environment_base__WEBPACK_IMPORTED_MODULE_4__.Encryptions.RSA) {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.of)(new _inma_helpers_rsa_encryption__WEBPACK_IMPORTED_MODULE_3__.RSAEncryptionHelper().encrypt(value));
        }
        else {
            return this.encryptionKey.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(key => {
                return _inma_helpers_encoding__WEBPACK_IMPORTED_MODULE_2__.Encryption.encrypt(value, key);
            }));
        }
    }
    get encryptionKey() {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request('/LoginService/Authenticate/getEncryptionKeys')
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(result => {
            return result;
        }));
    }
    // @cached
    get checkLoggedUser() {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request('/LoginService/Authenticate/checkLoggedUser')
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(result => {
            return result;
        }));
    }
}
const Authentication = new AuthenticationModel();


/***/ }),

/***/ 1874:
/*!******************************************!*\
  !*** ./src/app/🌱models/market/index.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Market": () => (/* reexport safe */ _market__WEBPACK_IMPORTED_MODULE_0__.Market),
/* harmony export */   "MarketInfo": () => (/* reexport safe */ _market_info__WEBPACK_IMPORTED_MODULE_1__.MarketInfo),
/* harmony export */   "MarketModel": () => (/* reexport safe */ _market__WEBPACK_IMPORTED_MODULE_0__.MarketModel),
/* harmony export */   "MarketNamesTranslations": () => (/* reexport safe */ _market__WEBPACK_IMPORTED_MODULE_0__.MarketNamesTranslations),
/* harmony export */   "MarketStatus": () => (/* reexport safe */ _market_status__WEBPACK_IMPORTED_MODULE_2__.MarketStatus),
/* harmony export */   "MarketStatusTranslations": () => (/* reexport safe */ _market__WEBPACK_IMPORTED_MODULE_0__.MarketStatusTranslations),
/* harmony export */   "MarketsNames": () => (/* reexport safe */ _market__WEBPACK_IMPORTED_MODULE_0__.MarketsNames)
/* harmony export */ });
/* harmony import */ var _market__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./market */ 58394);
/* harmony import */ var _market_info__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./market-info */ 97732);
/* harmony import */ var _market_status__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./market-status */ 97451);





/***/ }),

/***/ 97732:
/*!************************************************!*\
  !*** ./src/app/🌱models/market/market-info.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MarketInfo": () => (/* binding */ MarketInfo)
/* harmony export */ });
class MarketInfo {
}


/***/ }),

/***/ 97451:
/*!**************************************************!*\
  !*** ./src/app/🌱models/market/market-status.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MarketStatus": () => (/* binding */ MarketStatus)
/* harmony export */ });
var MarketStatus;
(function (MarketStatus) {
    MarketStatus["MAINTENANCE"] = "Maintenance";
    MarketStatus["PREOPEN"] = "Preopen";
    MarketStatus["OPEN"] = "Open";
    MarketStatus["CLOSING_AUCTION"] = "ClosingAuction";
    MarketStatus["PRECLOSED"] = "PreClosed";
    MarketStatus["CLOSED"] = "Closed";
})(MarketStatus || (MarketStatus = {}));


/***/ }),

/***/ 58394:
/*!*******************************************!*\
  !*** ./src/app/🌱models/market/market.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Market": () => (/* binding */ Market),
/* harmony export */   "MarketModel": () => (/* binding */ MarketModel),
/* harmony export */   "MarketNamesTranslations": () => (/* binding */ MarketNamesTranslations),
/* harmony export */   "MarketStatusTranslations": () => (/* binding */ MarketStatusTranslations),
/* harmony export */   "MarketsNames": () => (/* binding */ MarketsNames)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 61555);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 19193);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 64139);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var _users__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../users */ 17166);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 80522);
/* harmony import */ var _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @inma/helpers/cached */ 569);
/* harmony import */ var _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/helpers/http */ 36802);
/* harmony import */ var _symbol__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../symbol */ 61202);
/* harmony import */ var _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/helpers/streaming */ 9199);
/* harmony import */ var _inma_helpers_numbers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @inma/helpers/numbers */ 50746);
/* harmony import */ var _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @inma/helpers/injector */ 19753);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);











var MarketsNames;
(function (MarketsNames) {
    MarketsNames["TASI"] = "TASI";
    MarketsNames["NOMUC"] = "NOMUC";
    MarketsNames["TSBI"] = "TSBI";
})(MarketsNames || (MarketsNames = {}));
const MarketNamesTranslations = new (class Translations {
    constructor() {
        this.MARKETS = ["الأسواق", "Markets"];
        this.TASI = [" الرئيسي (تاسي)", "Main (TASI)"];
        this.NOMUC = [" الموازي (نمو)", "Secondary (NOMU)"];
        this.TSBI = ["سوق الصكوك", "Sukuk Market (TSBI)"];
        this.TASIHeader = ["السوق الرئيسي", "Main Market"];
        this.NOMUCHeader = ["السوق الموازي", "Tadawul Secondary Market"];
        this.TSBIHeader = ["سوق الصكوك", "Tadawul Sukuk Market"];
    }
})();
const MarketStatusTranslations = new (class {
    constructor() {
        this.MAINTENANCE = ["مغلق-صيانة", "Maintenance"];
        this.PREOPEN = ["مفتوح-صيانة الأوامر", "Open - Orders"];
        this.OPEN = ["مفتوح-تنفيذ", "Open - Trading"];
        this.CLOSING_AUCTION = ["إغلاق المزاد", "Closing Auction"];
        this.PRECLOSED = ["تداول بعد الإغلاق", "Post Trade"];
        this.CLOSED = ["مغلق", "Closed"];
        this.TRADE_AT_LAST = ["تنفيذ بسعر الإغلاق", "Trade At Last"];
    }
})();
class MarketModel {
    constructor(marketName = MarketsNames.TASI) {
        this.marketName = marketName;
    }
    get name() {
        return this.marketName;
    }
    get channelURL() {
        return _users__WEBPACK_IMPORTED_MODULE_0__.User.isLive.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)((isLive) => {
            return `/alinma/marketInfo/TDWL/${this.marketName}`;
        }));
    }
    get topdownChannelURL() {
        return _users__WEBPACK_IMPORTED_MODULE_0__.User.isLive.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)((isLive) => {
            return `/alinma/topDown10/TDWL${isLive ? '' : '*'}/${this.marketName}`;
        }));
    }
    get info() {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request("/stockMarket/MarketData/getMarketInfo", {
            marketSymbol: this.marketName,
        })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)((result) => {
            let marketInfo = result;
            const zone = _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_6__.Injector.get(_angular_core__WEBPACK_IMPORTED_MODULE_8__.NgZone);
            this.connectToStream().subscribe((marketInfoMessage) => {
                zone.run(() => {
                    // https://stackoverflow.com/questions/60467423/async-function-not-updating-view
                    const streamedMarketInfo = JSON.parse(marketInfoMessage["data"]);
                    let streamingMarketName = marketInfoMessage["channel"].split('/')[4];
                    //console.log("🚀 ~ file: market.ts ~ line 78 ~ MarketModel ~ zone.run ~ streamingMarketName", streamingMarketName + '    ' + this.marketName)
                    if (this.marketName == streamingMarketName) {
                        //  console.log("🚀 ~ file: market.ts ~ line 77 ~ MarketModel ~ zone.run ~ streamedMarketInfo", streamedMarketInfo.indexValue)
                        this._info.next(streamedMarketInfo);
                        // console.log(Streaming.subscriptionsReferences);
                    }
                    else {
                        _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_4__.Streaming.unsubscribe(marketInfoMessage["channel"]);
                    }
                });
                // console.log('load cached market')
            });
            // setInterval(() => {
            //   zone.run(() => {
            //   marketInfo = Object.assign({}, marketInfo);
            //   marketInfo.indexValue = Math.random();
            //   console.log(marketInfo.indexValue);
            //   this._info.next(marketInfo);
            //   });
            // }, 15000);
            return marketInfo;
        }));
    }
    changeMarkets(name) {
        this.disconnectToStream();
        this.marketName = name;
        this.info.subscribe();
    }
    get index() {
        return this.info.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)((info) => {
            // console.log(info?.indexValue);
            return info === null || info === void 0 ? void 0 : info.indexValue;
        }));
    }
    get change() {
        return this.info.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)((info) => info === null || info === void 0 ? void 0 : info.netChange));
    }
    get changePercentage() {
        return this.info.pipe(
        // Math.round(num * 100) / 100
        (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)((info) => {
            // console.log(info?.priceChange);
            return _inma_helpers_numbers__WEBPACK_IMPORTED_MODULE_5__.Numbers.round(info === null || info === void 0 ? void 0 : info.priceChange, 2);
            // return ((Number(info?.priceChange)))?.toString();
        }));
    }
    get status() {
        return this.info.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)((info) => info === null || info === void 0 ? void 0 : info.marketStatus));
    }
    get exchange() {
        return this.info.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)((info) => info === null || info === void 0 ? void 0 : info.exchange));
    }
    get indexValue() {
        return this.info.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)((info) => info === null || info === void 0 ? void 0 : info.indexValue));
    }
    get netChange() {
        return this.info.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)((info) => info === null || info === void 0 ? void 0 : info.netChange));
    }
    get noOfTrades() {
        return this.info.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)((info) => info === null || info === void 0 ? void 0 : info.noOfTrades));
    }
    get priceChange() {
        return this.info.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)((info) => info === null || info === void 0 ? void 0 : info.priceChange));
    }
    get turnover() {
        return this.info.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)((info) => info === null || info === void 0 ? void 0 : info.turnover));
    }
    get volume() {
        return this.info.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)((info) => info === null || info === void 0 ? void 0 : info.volume));
    }
    // Should be refactored to @cached
    get symbols() {
        // if (this.name == MarketsNames.TASI) {
        // return Symbols.all;
        // } else {
        if (MarketModel.marketsSymbols[this.name])
            return MarketModel.marketsSymbols[this.name];
        else {
            const marketSymbolsSubject = new rxjs__WEBPACK_IMPORTED_MODULE_9__.ReplaySubject(1);
            this.loadMarketSymbols().subscribe(marketSymbols => marketSymbolsSubject.next(marketSymbols));
            MarketModel.marketsSymbols[this.name] = marketSymbolsSubject;
            return marketSymbolsSubject;
        }
        // }
    }
    static reset() {
        this.marketsSymbols = {};
    }
    loadMarketSymbols() {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request('/stockMarket/MarketSectorsService/getMarketSectors', {
            marketSymbol: this.name
        })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.mergeMap)(result => {
            var _a;
            for (const w of result) {
                if ((w === null || w === void 0 ? void 0 : w.listId) === this.name) {
                    const findings = new Array();
                    (_a = w === null || w === void 0 ? void 0 : w.symbols) === null || _a === void 0 ? void 0 : _a.forEach(s => {
                        findings.push(_symbol__WEBPACK_IMPORTED_MODULE_3__.Symbols.findById(s.id));
                    });
                    return (findings === null || findings === void 0 ? void 0 : findings.length) ? (0,rxjs__WEBPACK_IMPORTED_MODULE_11__.combineLatest)(findings).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)(arr => arr.filter(item => item))) : (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.of)(new Array());
                }
            }
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.of)(new Array());
        }));
    }
    filterdSymbols(listId, marketCode) {
        const marketSymbolsSubject = new rxjs__WEBPACK_IMPORTED_MODULE_9__.ReplaySubject(1);
        this.filterSymbols(listId).subscribe(marketSymbols => marketSymbolsSubject.next(marketSymbols));
        // MarketModel.marketsSymbols[this.name] = marketSymbolsSubject;
        return marketSymbolsSubject;
    }
    filterSymbols(listId, marketCode) {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request('/stockMarket/ManageWatchList/getWatchList', {
            listId: listId, marketCode: this.name
        })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.mergeMap)(result => {
            if (listId == 'USER_SHARES' || listId == 'DEFAULT_WL') {
                const findings = new Array();
                result.forEach(w => {
                    findings.push(_symbol__WEBPACK_IMPORTED_MODULE_3__.Symbols.findById(w));
                });
                return (findings === null || findings === void 0 ? void 0 : findings.length) ? (0,rxjs__WEBPACK_IMPORTED_MODULE_11__.combineLatest)(findings).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)(arr => arr.filter(item => item))) : (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.of)(new Array());
                return (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.of)(new Array());
            }
            else {
                const findings = new Array();
                result === null || result === void 0 ? void 0 : result.forEach(s => {
                    findings.push(_symbol__WEBPACK_IMPORTED_MODULE_3__.Symbols.findById(s.id));
                });
                //   if(listId == 'TOP_TEN' || listId == 'DOWN_TEN'){
                //   const zone = Injector.get(NgZone);
                //   this.connectToTopDownStream().subscribe((topDownSymbols) => {
                //     zone.run(() => {
                //       const topDownSymbolsList = JSON.parse(topDownSymbols["data"]);
                //       this._topDownSymbols.next(topDownSymbolsList);
                //     })
                //   });
                // }
                return (findings === null || findings === void 0 ? void 0 : findings.length) ? (0,rxjs__WEBPACK_IMPORTED_MODULE_11__.combineLatest)(findings).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)(arr => arr.filter(item => item))) : (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.of)(new Array());
                return (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.of)(new Array());
            }
        }));
    }
    get getDefaultWatchlist() {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request('/stockMarket/ManageWatchList/getDefaultWLName', {})
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)(result => {
            return result;
        }));
    }
    connectToStream() {
        return new rxjs__WEBPACK_IMPORTED_MODULE_13__.Observable(observer => {
            _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_4__.Streaming.connect().subscribe(() => {
                this.channelURL.subscribe(channelURL => {
                    _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_4__.Streaming.subscribe(channelURL).subscribe(event => {
                        if (event.type === _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_4__.StreamingChannelEventType.Subscribed) {
                            _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_4__.Streaming.log(JSON.stringify(event));
                            // observer.next(this.marketStatus);
                        }
                        else if (event.type === _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_4__.StreamingChannelEventType.MessageReceived) {
                            _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_4__.Streaming.log(JSON.stringify(event));
                            // this.cachedMarketStatus = event.data["data"].replace(/\"/g,"");
                            observer.next(event.data);
                        }
                    });
                });
            });
        });
    }
    disconnectToStream() {
        this.channelURL.subscribe(channelURL => {
            _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_4__.Streaming.unsubscribe(channelURL);
        });
    }
    // updateAppTheme(status) {
    //     let theme;
    //     if (MarketStatus[status] === MarketStatus.CLOSED) {
    //         theme = AppTheme.NIGHT;
    //     } else {
    //         theme = AppTheme.DAY;
    //     }
    //     if (Environment.isProduction) {
    //         let envTheme = (<any>Environment).theme;
    //         if (envTheme && envTheme !== 'auto') {
    //             if (/(day|night)-theme/.test(envTheme) === false) {
    //                 if (/(day|night)/.test(envTheme)) {
    //                     envTheme = envTheme + '-theme';
    //                 } else {
    //                     throw new Error('Unknown Environment theme parameter !');
    //                 }
    //             }
    //             theme = envTheme;
    //         }
    //     }
    //     this.settingsService.setTheme(theme);
    // }
    connectToTopDownStream() {
        return new rxjs__WEBPACK_IMPORTED_MODULE_13__.Observable(observer => {
            _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_4__.Streaming.connect().subscribe(() => {
                this.topdownChannelURL.subscribe(channelURL => {
                    _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_4__.Streaming.subscribe(channelURL).subscribe(event => {
                        if (event.type === _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_4__.StreamingChannelEventType.Subscribed) {
                            _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_4__.Streaming.log(JSON.stringify(event));
                            // observer.next(this.marketStatus);
                        }
                        else if (event.type === _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_4__.StreamingChannelEventType.MessageReceived) {
                            _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_4__.Streaming.log(JSON.stringify(event));
                            // this.cachedMarketStatus = event.data["data"].replace(/\"/g,"");
                            observer.next(event.data);
                        }
                    });
                });
            });
        });
    }
    disconnectToTopDownStream() {
        this.topdownChannelURL.subscribe(channelURL => {
            _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_4__.Streaming.unsubscribe(channelURL);
        });
    }
}
MarketModel.marketsSymbols = {};
(0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([
    _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_1__.cached,
    (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:type", rxjs__WEBPACK_IMPORTED_MODULE_13__.Observable),
    (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:paramtypes", [])
], MarketModel.prototype, "info", null);
const Market = new MarketModel();


/***/ }),

/***/ 14645:
/*!************************************************!*\
  !*** ./src/app/🌱models/mutual-funds/index.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFund": () => (/* reexport safe */ _mutual_fund_model__WEBPACK_IMPORTED_MODULE_0__.MutualFund),
/* harmony export */   "MutualFundDetails": () => (/* reexport safe */ _mutual_fund_model__WEBPACK_IMPORTED_MODULE_0__.MutualFundDetails),
/* harmony export */   "MutualFundRedemptionTypes": () => (/* reexport safe */ _mutual_fund_model__WEBPACK_IMPORTED_MODULE_0__.MutualFundRedemptionTypes),
/* harmony export */   "MutualFunds": () => (/* reexport safe */ _mutual_funds_model__WEBPACK_IMPORTED_MODULE_1__.MutualFunds),
/* harmony export */   "MutualFundsModel": () => (/* reexport safe */ _mutual_funds_model__WEBPACK_IMPORTED_MODULE_1__.MutualFundsModel),
/* harmony export */   "UnitTypes": () => (/* reexport safe */ _mutual_fund_model__WEBPACK_IMPORTED_MODULE_0__.UnitTypes)
/* harmony export */ });
/* harmony import */ var _mutual_fund_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-fund.model */ 51530);
/* harmony import */ var _mutual_funds_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mutual-funds.model */ 64501);




/***/ }),

/***/ 51530:
/*!************************************************************!*\
  !*** ./src/app/🌱models/mutual-funds/mutual-fund.model.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFund": () => (/* binding */ MutualFund),
/* harmony export */   "MutualFundDetails": () => (/* binding */ MutualFundDetails),
/* harmony export */   "MutualFundRedemptionTypes": () => (/* binding */ MutualFundRedemptionTypes),
/* harmony export */   "UnitTypes": () => (/* binding */ UnitTypes)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/helpers/cached */ 569);
/* harmony import */ var _inma_helpers_date__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @inma/helpers/date */ 70314);
/* harmony import */ var _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/helpers/http */ 36802);
/* harmony import */ var _inma_helpers_localize__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/helpers/localize */ 38924);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 19193);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 64139);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 80522);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var _portfolio__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../portfolio */ 65082);








var MutualFundRedemptionTypes;
(function (MutualFundRedemptionTypes) {
    MutualFundRedemptionTypes["AllUnits"] = "ALL";
    MutualFundRedemptionTypes["NumberOfUnits"] = "PART";
    MutualFundRedemptionTypes["Amount"] = "AMT";
})(MutualFundRedemptionTypes || (MutualFundRedemptionTypes = {}));
var UnitTypes;
(function (UnitTypes) {
    UnitTypes[UnitTypes["Currency"] = 0] = "Currency";
    UnitTypes[UnitTypes["Units"] = 1] = "Units";
})(UnitTypes || (UnitTypes = {}));
class MutualFundDetails {
    constructor(mutualFund) {
        this.mutualFund = mutualFund;
    }
}
class MutualFund {
    constructor(options) {
        this.gainLossUnrealized = 0;
        this.gainLossUnrealizedPercentage = 0;
        this.totalCommission = 0;
        this.vat = 0;
        this.totalAmount = 0;
        this.id = options === null || options === void 0 ? void 0 : options.id;
        this.name = options === null || options === void 0 ? void 0 : options.name;
        this.localizedName = options === null || options === void 0 ? void 0 : options.localizedName;
        this.type = options === null || options === void 0 ? void 0 : options.type;
        this.portfolio = options === null || options === void 0 ? void 0 : options.portfolio;
        this.unitPrice = options === null || options === void 0 ? void 0 : options.unitPrice;
        this.changeRate = options === null || options === void 0 ? void 0 : options.changeRate;
        this.ownedUnits = options === null || options === void 0 ? void 0 : options.ownedUnits;
        this.lastPrice = options === null || options === void 0 ? void 0 : options.lastPrice;
        this.lastValuationPrice = options === null || options === void 0 ? void 0 : options.lastValuationPrice;
        this.gainLossUnrealized = options === null || options === void 0 ? void 0 : options.gainLossUnrealized;
        this.gainLossUnrealizedPercentage = options === null || options === void 0 ? void 0 : options.gainLossUnrealizedPercentage;
        this.marketValue = options === null || options === void 0 ? void 0 : options.marketValue;
        this.closedFund = options === null || options === void 0 ? void 0 : options.closedFund;
        this.totalCost = options === null || options === void 0 ? void 0 : options.totalCost;
        this.mutualFundPercentage = options === null || options === void 0 ? void 0 : options.mutualFundPercentage;
    }
    get isStandard() {
        return this.type === 'MF';
    }
    get isCharity() {
        return this.type === 'CF';
    }
    get isClosed() {
        return this.type === 'CLF';
    }
    get portfolios() {
        return _portfolio__WEBPACK_IMPORTED_MODULE_4__.Portfolios.all.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.mergeMap)(portfolios => {
            const findings = [];
            for (let p = 0; p < portfolios.length; p++) {
                const portfolio = portfolios[p];
                const subscriptions = portfolio.allMutualFunds.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(mutualFunds => mutualFunds.filter(mf => mf.id == this.id)));
                findings.push(subscriptions.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(mutualFunds => mutualFunds.length > 0 ? portfolio : null)));
            }
            return (findings === null || findings === void 0 ? void 0 : findings.length) ? (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.combineLatest)(findings).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(arr => arr.filter(item => item))) : (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.of)(new Array());
        }));
    }
    get isSubscribed() {
        return this.portfolios.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(portfolios => (portfolios === null || portfolios === void 0 ? void 0 : portfolios.length) > 0));
    }
    get termsAndConditions() {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request('/MutualFunds/MutualFundsService/showTermsAndConditions', {
            mutualFundId: this.id,
        }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)((result) => {
            return result;
        }));
    }
    get details() {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request('/MutualFunds/MutualFundsService/getMutualFundDetails', { mutualFundId: this.id })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)((result = []) => {
            var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q;
            const details = new MutualFundDetails(this);
            const d = result === null || result === void 0 ? void 0 : result[0];
            if (!d)
                return details;
            details.investmentStrategy = (0,_inma_helpers_localize__WEBPACK_IMPORTED_MODULE_3__.localize)(d, 'strategy');
            details.objective = (0,_inma_helpers_localize__WEBPACK_IMPORTED_MODULE_3__.localize)(d, 'objective');
            details.currency = (_a = d.currency) === null || _a === void 0 ? void 0 : _a.code;
            // details.evaluationDays = localize(details, 'actualEvaluationDays') || "";
            // details.evaluationDaysTime = details.lastDateForReceiptOrders ? formatTime(details.lastDateForReceiptOrders.time) : "";
            details.evaluationDays = (0,_inma_helpers_localize__WEBPACK_IMPORTED_MODULE_3__.localize)(d, 'actualEvaluationDays');
            details.evaluationDaysTime = ''; // details.lastDateForReceiptOrders ? formatTime(details.lastDateForReceiptOrders.time) : "";
            details.lastDateForReceiptTheOrders = {
                days: (0,_inma_helpers_localize__WEBPACK_IMPORTED_MODULE_3__.localize)(d, 'evaluationDays'),
                time: (0,_inma_helpers_date__WEBPACK_IMPORTED_MODULE_1__.formatTime)((_b = d.lastDateForReceiptOrders) === null || _b === void 0 ? void 0 : _b.time)
            };
            details.inceptionDate = (0,_inma_helpers_date__WEBPACK_IMPORTED_MODULE_1__.formatDate)((_c = d.inceptionDate) === null || _c === void 0 ? void 0 : _c.gregorianDate);
            details.inceptionPrice = `${((_d = d.inceptionPrice) === null || _d === void 0 ? void 0 : _d.amount) || ''} ${details.currency}`;
            details.investingMarkets = (0,_inma_helpers_localize__WEBPACK_IMPORTED_MODULE_3__.localize)(d, 'markets');
            details.unitPrice = details.lastPrice = (_e = d.unitPrice) === null || _e === void 0 ? void 0 : _e.amount;
            details.unitPriceType = details.lastPriceType = details.currency;
            details.lastPriceDate = (0,_inma_helpers_date__WEBPACK_IMPORTED_MODULE_1__.formatDate)((_f = d.valuationDate) === null || _f === void 0 ? void 0 : _f.gregorianDate);
            details.yearToDayChange = (_g = d.change) === null || _g === void 0 ? void 0 : _g.amount;
            details.minimumInitialSubscription = ((_h = d.minSubscriptionLimit) === null || _h === void 0 ? void 0 : _h.amount) || '0';
            details.minimumInitialSubscriptionType = details.currency;
            details.minimumHolding = ((_j = d.minHoldingLimit) === null || _j === void 0 ? void 0 : _j.amount) || '0';
            details.minimumHoldingType = details.currency;
            details.minAdditionalSubscription = ((_k = d.minAdditionalSbscrptnLimit) === null || _k === void 0 ? void 0 : _k.amount) || '0';
            details.minAdditionalSubscriptionType = details.currency;
            const isCurrency = (d.minRdmptnInd === 'VALUE');
            details.minimumRedemption = isCurrency ? d.minRdmptnAmountLimit.amount : d.minRdmptnUnitsLimit.amount;
            details.minimumRedemptionUnitType = isCurrency ? UnitTypes.Currency : UnitTypes.Units;
            details.minimumRedemptionUnit = isCurrency ? details.currency :
                (details.minimumRedemption <= 2 ? 'unit' :
                    details.minimumRedemption <= 10 ? 'twoUnits' :
                        'unit');
            details.subscriptionFees = (_l = d.subscriptionFees) === null || _l === void 0 ? void 0 : _l.amount;
            details.subscriptionFeesType = (d.subscriptionFeesType === 'PERCENTAGE') ? '%' : details.currency;
            details.custodyFees = (_m = d.custodyFees) === null || _m === void 0 ? void 0 : _m.amount;
            details.custodyFeesType = (d.custodyFeesType === 'PERCENTAGE') ? '%' : details.currency;
            details.redemptionFees = (_o = d.redemptionFees) === null || _o === void 0 ? void 0 : _o.amount;
            details.redemptionFeesType = (d.redemptionFeesType === 'PERCENTAGE') ? '%' : details.currency;
            details.earlyRedemptionFees = (_p = d.earlyRedemptionFees) === null || _p === void 0 ? void 0 : _p.amount;
            details.earlyRedemptionFeesType = (d.earlyRedemptionFeesType === 'PERCENTAGE') ? '%' : details.currency;
            details.earlyRedemptionFeesPolicy = d.earlyRedemptionFeesPolicy;
            details.otherFees = (_q = d.otherFees) === null || _q === void 0 ? void 0 : _q.amount;
            details.otherFeesType = (d.otherFeesType === 'PERCENTAGE') ? '%' : details.currency;
            return details;
        }));
    }
    get suitability() {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request('/ProductEligibility/ProductEligibilityService/checkEligibility', {
            productId: this.id,
            productType: this.type,
            productName: this.name
        }, { fullResponse: true }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(([result, message]) => {
            let suitable = {
                msg: message === null || message === void 0 ? void 0 : message.msgText,
                isSuitabile: result === null || result === void 0 ? void 0 : result.eligibilityFlag,
                eligiblityCheckApplicable: result === null || result === void 0 ? void 0 : result.eligiblityCheckApplicable,
                report: result === null || result === void 0 ? void 0 : result.eligibilityReport
            };
            return suitable;
        }));
        // let suitable = {
        //     msg: "ssssss",
        //     isSuitabile: false,
        //     eligiblityCheckApplicable: true,
        //     report: ""
        // };
        // return of(suitable);
    }
    redeem(redemptionType, amount) {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request('/MutualFunds/MutualFundsService/redeemUnits', {
            mutualFundId: this.id,
            portfolioId: this.portfolio.id,
            mutualFundType: this.type,
            redemptionType: redemptionType.toString(),
            numberOfUnits: redemptionType !== MutualFundRedemptionTypes.Amount ? amount : null,
            redemptionAmount: redemptionType === MutualFundRedemptionTypes.Amount ? amount : null
        });
    }
    subscribe(amount) {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request('/MutualFunds/MutualFundsService/subscribe', {
            mutualFundId: this.id,
            portfolioId: this.portfolio.id,
            mutualFundType: this.type,
            subscriptionAmount: amount
        });
    }
    refuseSubscription() {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request('/MutualFunds/MutualFundsService/refuseSubscription', {
            mutualFundId: this.id,
            portfolioId: this.portfolio.id,
            // productType: this.type
        });
    }
    addUnits(amount) {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request('/MutualFunds/MutualFundsService/addUnits', {
            mutualFundId: this.id,
            portfolioId: this.portfolio.id,
            mutualFundType: this.type,
            subscriptionAmount: amount
        });
    }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_0__.cached,
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", Object),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", [])
], MutualFund.prototype, "isSubscribed", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_0__.cached,
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", rxjs__WEBPACK_IMPORTED_MODULE_10__.Observable),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", [])
], MutualFund.prototype, "termsAndConditions", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_0__.cached,
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", rxjs__WEBPACK_IMPORTED_MODULE_10__.Observable),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", [])
], MutualFund.prototype, "details", null);


/***/ }),

/***/ 64501:
/*!*************************************************************!*\
  !*** ./src/app/🌱models/mutual-funds/mutual-funds.model.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFunds": () => (/* binding */ MutualFunds),
/* harmony export */   "MutualFundsModel": () => (/* binding */ MutualFundsModel)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _mutual_fund_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mutual-fund.model */ 51530);
/* harmony import */ var _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @inma/helpers/cached */ 569);
/* harmony import */ var _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/helpers/http */ 36802);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var _inma_helpers_localize__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/helpers/localize */ 38924);
/* harmony import */ var src_app_helpers_localized_string__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/helpers/localized-string */ 41734);
/* harmony import */ var _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @inma/helpers/injector */ 19753);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ 87514);









class MutualFundsModel {
    get all() {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request('/MutualFunds/MutualFundsService/getAlinmaMutualFunds')
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(result => {
            var _a, _b, _c;
            this.mutualFunds = new Array();
            for (const mf of result || []) {
                const unitPrice = (_a = mf === null || mf === void 0 ? void 0 : mf.unitPrice) === null || _a === void 0 ? void 0 : _a.amount;
                const changeRate = (_b = mf === null || mf === void 0 ? void 0 : mf.change) === null || _b === void 0 ? void 0 : _b.amount;
                const ownedUnits = (_c = mf === null || mf === void 0 ? void 0 : mf.units) === null || _c === void 0 ? void 0 : _c.amount;
                const type = ((mf === null || mf === void 0 ? void 0 : mf.type) || 'mf').toUpperCase();
                const mfModel = new _mutual_fund_model__WEBPACK_IMPORTED_MODULE_0__.MutualFund({
                    id: mf === null || mf === void 0 ? void 0 : mf.id,
                    name: (0,_inma_helpers_localize__WEBPACK_IMPORTED_MODULE_3__.localize)(mf, 'name'),
                    localizedName: new src_app_helpers_localized_string__WEBPACK_IMPORTED_MODULE_4__.LocalizedString(mf.nameEn, mf.nameAr, _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_5__.Injector.get(_ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__.TranslateService)),
                    type,
                    unitPrice,
                    changeRate,
                    ownedUnits,
                    closedFund: mf === null || mf === void 0 ? void 0 : mf.closedFund
                });
                if (mfModel.type === 'MF' && mfModel.closedFund) // convert it to closedFund
                    mfModel.type = 'CLF';
                this.mutualFunds.push(mfModel);
            }
            return this.mutualFunds;
        }));
    }
    get allHashed() {
        return this.all.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(mutualFunds => {
            const cachedHashedMutualFunds = {};
            mutualFunds.forEach((mf) => cachedHashedMutualFunds[mf.id] = mf);
            return cachedHashedMutualFunds;
        }));
    }
    findById(id, defaultValue) {
        return this.allHashed.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(mutualFundsHash => mutualFundsHash[id] || defaultValue));
    }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_1__.cached,
    (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__metadata)("design:type", Object),
    (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__metadata)("design:paramtypes", [])
], MutualFundsModel.prototype, "all", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_1__.cached,
    (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__metadata)("design:type", Object),
    (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__metadata)("design:paramtypes", [])
], MutualFundsModel.prototype, "allHashed", null);
const MutualFunds = new MutualFundsModel();


/***/ }),

/***/ 65082:
/*!*********************************************!*\
  !*** ./src/app/🌱models/portfolio/index.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Portfolio": () => (/* reexport safe */ _portfolio_model__WEBPACK_IMPORTED_MODULE_1__.Portfolio),
/* harmony export */   "PortfolioType": () => (/* reexport safe */ _portfolio_model__WEBPACK_IMPORTED_MODULE_1__.PortfolioType),
/* harmony export */   "Portfolios": () => (/* reexport safe */ _portfolios_model__WEBPACK_IMPORTED_MODULE_0__.Portfolios)
/* harmony export */ });
/* harmony import */ var _portfolios_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./portfolios.model */ 39620);
/* harmony import */ var _portfolio_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./portfolio.model */ 46138);




/***/ }),

/***/ 46138:
/*!*******************************************************!*\
  !*** ./src/app/🌱models/portfolio/portfolio.model.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Portfolio": () => (/* binding */ Portfolio),
/* harmony export */   "PortfolioType": () => (/* binding */ PortfolioType)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 64139);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 61555);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 19193);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/helpers/http */ 36802);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 80522);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var _mutual_funds__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../mutual-funds */ 14645);
/* harmony import */ var _inma_helpers_localize__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/helpers/localize */ 38924);
/* harmony import */ var _inma_models_symbol__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/models/symbol */ 61202);
/* harmony import */ var _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/helpers/streaming */ 9199);
/* harmony import */ var _users__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../users */ 17166);








var PortfolioType;
(function (PortfolioType) {
    PortfolioType["ALL"] = "";
    PortfolioType["STANDARD_PORTFOLIO"] = "IP";
    PortfolioType["MUTUAL_FUND"] = "MP";
})(PortfolioType || (PortfolioType = {}));
class Portfolio {
    constructor(data) {
        this.data = data;
        // udid = Math.random() * 16 | 0;
        this.facilities = 0;
        this.portfolioValue = 0;
        this.currency = 0;
        this.accountType = 0;
        this.moneyBalance = 0;
        this.profitLoss = 0;
        this.marketValue = 0;
        this.portfolioCost = 0;
        this.blockedAmount = 0;
        this.samaAccount = '';
        this.actualBalance = 0;
        //#region buyingPower
        //TODO: use @cached decorator instead
        this._cachedBuyingPower = undefined;
        this.buyingPowerLoaded = false;
        this.id = (data === null || data === void 0 ? void 0 : data.id) || (data === null || data === void 0 ? void 0 : data.value);
        this.name = data === null || data === void 0 ? void 0 : data.title;
        this.type = data === null || data === void 0 ? void 0 : data.type;
        this.accountType = data === null || data === void 0 ? void 0 : data.accountType;
        this.accountNumber = data === null || data === void 0 ? void 0 : data.accountNumber;
        this.samaAccount = data === null || data === void 0 ? void 0 : data.samaAccount;
        this.defaultPortfolio = data === null || data === void 0 ? void 0 : data.defaultPortfolio;
    }
    loadSymbols() {
        if (this.type === PortfolioType.STANDARD_PORTFOLIO) {
            return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request('/Portfolio/MyPortfolios/loadPortfolioDetails', { portfolioId: this.id })
                .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.mergeMap)(result => {
                var _a;
                this.actualBalance = (_a = result === null || result === void 0 ? void 0 : result.actualBalance) === null || _a === void 0 ? void 0 : _a.replace(/,/g, '');
                return this.updateSymbolsFromTradeSecurities(result === null || result === void 0 ? void 0 : result.tradeSecurties);
            }));
        }
        else
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.of)([]);
    }
    get symbols() {
        if (!this.symbolsSubject) {
            this.symbolsSubject = new rxjs__WEBPACK_IMPORTED_MODULE_8__.ReplaySubject(1);
            this.loadSymbols().subscribe(symbols => this.symbolsSubject.next(symbols));
        }
        return this.symbolsSubject;
    }
    get sellOrderSymbols() {
        this.orderSymbolsSubject = new rxjs__WEBPACK_IMPORTED_MODULE_8__.ReplaySubject(1);
        this.loadSymbols().subscribe(symbols => this.orderSymbolsSubject.next(symbols));
        return this.orderSymbolsSubject;
    }
    updateSymbolsFromTradeSecurities(tradeSecurties = []) {
        var _a;
        const findings = [];
        for (const tradeSecurity of tradeSecurties) {
            findings.push(_inma_models_symbol__WEBPACK_IMPORTED_MODULE_3__.Symbols.findById((_a = tradeSecurity.symbol) === null || _a === void 0 ? void 0 : _a.code).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.map)(symbol => {
                if (!symbol) { // to handle return sukuk value 
                    symbol = new _inma_models_symbol__WEBPACK_IMPORTED_MODULE_3__.Symbol();
                }
                this.updateSymbolFromBackendTradeSecurity(symbol, tradeSecurity);
                return symbol;
            })));
        }
        return (findings === null || findings === void 0 ? void 0 : findings.length) ? (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.combineLatest)(findings).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.map)(arr => arr.filter(item => item))) : (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.of)(new Array());
    }
    updateSymbolFromBackendTradeSecurity(symbol, tradeSecurity) {
        var _a, _b, _c, _d, _e;
        if (symbol && tradeSecurity) {
            symbol.portfolioID = this.id;
            symbol.symbolName = tradeSecurity.symbolName;
            symbol.securityType = tradeSecurity.securityType;
            symbol.availableQuantity = tradeSecurity.availQuantity;
            symbol.ownedQuantity = tradeSecurity.ownedQuantity;
            symbol.costTotal = (_a = tradeSecurity.totalCost) === null || _a === void 0 ? void 0 : _a.amount;
            symbol.costAverage = (_b = tradeSecurity.avgCostPrice) === null || _b === void 0 ? void 0 : _b.amount;
            symbol.gainLossRealized = (_c = tradeSecurity.realizedProfitLoss) === null || _c === void 0 ? void 0 : _c.amount;
            symbol.gainLossPercentageRealized = tradeSecurity.realizedProfitLossPercen;
            symbol.gainLossUnrealized = (_d = tradeSecurity.unrealizedProfitLoss) === null || _d === void 0 ? void 0 : _d.amount;
            symbol.gainLossPercentageUnrealized = tradeSecurity.unrealizedProfitLossPercen;
            symbol.marketValue = (_e = tradeSecurity.totalMrktValue) === null || _e === void 0 ? void 0 : _e.amount;
            symbol.symbolPrice = tradeSecurity.mrktPrice.amount;
        }
    }
    get cachedBuyingPower() {
        return this._cachedBuyingPower;
    }
    set cachedBuyingPower(cachedBuyingPower) {
        this._cachedBuyingPower = cachedBuyingPower;
    }
    get buyingPower() {
        // return this.cachedBuyingPowerSubject = new ReplaySubject<number>(1);
        // if (this.cachedBuyingPower !== undefined)
        //     return of(this.cachedBuyingPower);
        // else
        if (!this.cachedBuyingPowerSubject) {
            this.cachedBuyingPowerSubject = new rxjs__WEBPACK_IMPORTED_MODULE_8__.ReplaySubject(1);
            this.loadPortfolioBuyingPower().subscribe(bP => {
                // setInterval(() => {
                //     this.cachedBuyingPowerSubject.next(Math.floor((Number(this.id?.split('-')[1]) + Math.random()) * 100) / 100);
                // }, 2000);
                this.connectToStream().subscribe(bp => {
                    var _a;
                    const bpData = JSON.parse(bp.data);
                    if ((bpData === null || bpData === void 0 ? void 0 : bpData.portfolioNumber) == this.id) {
                        this.cachedBuyingPowerSubject.next(Number(((_a = bpData === null || bpData === void 0 ? void 0 : bpData.amount) === null || _a === void 0 ? void 0 : _a.toString()).replace(/,/g, '')));
                    }
                });
                return this.cachedBuyingPowerSubject.next(Number((bP === null || bP === void 0 ? void 0 : bP.toString()).replace(/,/g, '')));
            });
        }
        return this.cachedBuyingPowerSubject;
    }
    loadPortfolioBuyingPower() {
        if (!this.id)
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.of)(0);
        if (this.type === PortfolioType.STANDARD_PORTFOLIO) {
            // Http.request('/Portfolio/MyPortfolios/loadAdvancedTradeSecurityList', { portfolioId: this.id })
            //     .pipe(map(result => {
            //         this.profitLoss = result?.totalProfitLoss?.replace(/,/g, '');
            //         this.portfolioCost = result?.totalCost?.replace(/,/g, '');
            //         this.actualBalance = result?.actualBalance?.replace(/,/g, '');
            //         this.updateSymbolsFromTradeSecurities(result?.tradeSecurties).subscribe();
            //     })).subscribe();
        }
        // const url = (this.type === PortfolioType.MUTUAL_FUND) ? '/Portfolio/BuyingPower/loadMFCustBuyingPwr' : '/Portfolio/ManageOrders/loadCustBuyingPwr';
        const url = '/Portfolio/MyPortfolios/loadCustBuyingPwr';
        console.log('/Portfolio/MyPortfolios/loadCustBuyingPwr', this.type);
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request(url, { portfolioId: this.id, portfolioType: this.type })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.map)(result => {
            var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;
            console.log('/Portfolio/MyPortfolios/loadCustBuyingPwr', result);
            // debugger
            this.cachedBuyingPower = (_b = (_a = result === null || result === void 0 ? void 0 : result.buyingPwr) === null || _a === void 0 ? void 0 : _a.buyingPwrAmt) === null || _b === void 0 ? void 0 : _b.amount;
            this.facilities = (_d = (_c = result === null || result === void 0 ? void 0 : result.buyingPwr) === null || _c === void 0 ? void 0 : _c.overdraftAmt) === null || _d === void 0 ? void 0 : _d.amount;
            this.portfolioValue = (_f = (_e = result === null || result === void 0 ? void 0 : result.buyingPwr) === null || _e === void 0 ? void 0 : _e.portfolioPostionAmt) === null || _f === void 0 ? void 0 : _f.amount;
            this.currency = result === null || result === void 0 ? void 0 : result.currency;
            // this.accountType = response.result["documentType"];
            this.moneyBalance = (_h = (_g = result === null || result === void 0 ? void 0 : result.buyingPwr) === null || _g === void 0 ? void 0 : _g.closingBalAmt) === null || _h === void 0 ? void 0 : _h.amount;
            this.marketValue = (_k = (_j = result === null || result === void 0 ? void 0 : result.buyingPwr) === null || _j === void 0 ? void 0 : _j.netSecurityAmt) === null || _k === void 0 ? void 0 : _k.amount;
            this.blockedAmount = (_m = (_l = result === null || result === void 0 ? void 0 : result.buyingPwr) === null || _l === void 0 ? void 0 : _l.blockedAmt) === null || _m === void 0 ? void 0 : _m.amount;
            // this.accountNumber = response.result['buyingPwr']['account']['accountNumber'];
            return this.cachedBuyingPower;
        }));
    }
    getLiveBuyingPower(id, type) {
        const url = '/Portfolio/MyPortfolios/loadCustBuyingPwr';
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request(url, { portfolioId: id, portfolioType: type })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.map)(result => {
            var _a, _b;
            this.cachedBuyingPower = (_b = (_a = result === null || result === void 0 ? void 0 : result.buyingPwr) === null || _a === void 0 ? void 0 : _a.buyingPwrAmt) === null || _b === void 0 ? void 0 : _b.amount;
            return this.cachedBuyingPower;
        }));
    }
    //#endregion
    get allMutualFunds() {
        if (this.type !== PortfolioType.MUTUAL_FUND)
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.of)([]);
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request('/portfolio/MyPortfolios/getMFPortfolioPosition', { portfolioId: this.id })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.mergeMap)(result => {
            var _a, _b, _c, _d, _e, _f, _g;
            const findings = new Array();
            if (result) {
                this.portfolioCost = (_b = (_a = result === null || result === void 0 ? void 0 : result.totalCost) === null || _a === void 0 ? void 0 : _a.amount) === null || _b === void 0 ? void 0 : _b.replace(/,/g, '');
                this.actualBalance = (_d = (_c = result === null || result === void 0 ? void 0 : result.actualBalance) === null || _c === void 0 ? void 0 : _c.amount) === null || _d === void 0 ? void 0 : _d.replace(/,/g, '');
                this.profitLoss = (_f = (_e = result === null || result === void 0 ? void 0 : result.totalUnrealizedprofitLossAmt) === null || _e === void 0 ? void 0 : _e.amount) === null || _f === void 0 ? void 0 : _f.replace(/,/g, '');
                this.marketValue = (_g = result === null || result === void 0 ? void 0 : result.totalMarketValue) === null || _g === void 0 ? void 0 : _g.amount;
                if (result.mutualFundPositionList) {
                    for (let mf of result.mutualFundPositionList) {
                        findings.push(_mutual_funds__WEBPACK_IMPORTED_MODULE_1__.MutualFunds.findById(mf.id, new _mutual_funds__WEBPACK_IMPORTED_MODULE_1__.MutualFund()).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.map)(resultMF => {
                            var _a, _b, _c, _d, _e, _f, _g, _h;
                            Object.assign(resultMF, {
                                id: mf.id,
                                name: (0,_inma_helpers_localize__WEBPACK_IMPORTED_MODULE_2__.localize)(mf, 'name'),
                                type: mf.type || 'MF',
                                portfolio: this,
                                ownedUnits: (_a = mf.units) === null || _a === void 0 ? void 0 : _a.amount,
                                lastPrice: (_b = mf.avgPrice) === null || _b === void 0 ? void 0 : _b.amount,
                                lastValuationPrice: (_c = mf.lastValuationPrice) === null || _c === void 0 ? void 0 : _c.amount,
                                gainLossUnrealized: (_d = mf.unrealizedGainLoss) === null || _d === void 0 ? void 0 : _d.amount,
                                gainLossUnrealizedPercentage: (_e = mf.unrealizedGainLossPer) === null || _e === void 0 ? void 0 : _e.amount,
                                marketValue: (_f = mf.marketValue) === null || _f === void 0 ? void 0 : _f.amount,
                                closedFund: mf.closedFund || resultMF.closedFund,
                                totalCost: (_g = mf.totalCost) === null || _g === void 0 ? void 0 : _g.amount,
                                mutualFundPercentage: (_h = mf.mutualFundPer) === null || _h === void 0 ? void 0 : _h.amount
                            });
                            if (resultMF.type === 'MF' && resultMF.closedFund) // convert it to closedFund
                                resultMF.type = 'CLF';
                            return resultMF;
                        })));
                    }
                }
            }
            if (findings.length)
                return (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.combineLatest)(findings);
            else
                return (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.of)([]);
        }));
    }
    get standardMutualFunds() {
        return this.allMutualFunds.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.map)(mutualFunds => (mutualFunds === null || mutualFunds === void 0 ? void 0 : mutualFunds.filter(mf => mf.type === 'MF')) || []));
    }
    get charitiesMutualFunds() {
        return this.allMutualFunds.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.map)(mutualFunds => (mutualFunds === null || mutualFunds === void 0 ? void 0 : mutualFunds.filter(mf => mf.type === 'CF')) || []));
    }
    get closedMutualFunds() {
        return this.allMutualFunds.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.map)(mutualFunds => (mutualFunds === null || mutualFunds === void 0 ? void 0 : mutualFunds.filter(mf => mf.type === 'CLF')) || []));
    }
    ownsSymbol(s) {
        return this.symbols.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.map)(symbols => {
            var _a;
            for (let i = 0; i < symbols.length; i++) {
                if ((s === null || s === void 0 ? void 0 : s.id) === ((_a = symbols[i]) === null || _a === void 0 ? void 0 : _a.id))
                    return true;
            }
            return false;
        }));
    }
    refresh() {
        //! TODO: Change how this is works !
        this.loadPortfolioBuyingPower().subscribe(bP => { var _a; return (_a = this.cachedBuyingPowerSubject) === null || _a === void 0 ? void 0 : _a.next(bP); });
        this.loadSymbols().subscribe(symbols => { var _a; return (_a = this.symbolsSubject) === null || _a === void 0 ? void 0 : _a.next(symbols); });
        // setInterval(() => {
        //     Symbols.all.subscribe(symbols => {
        //         const sa = [symbols[Math.floor(Math.random() * symbols.length)]];
        //         console.log(sa);
        //         return this.symbolsSubject?.next(sa);
        //     });
        // }, 2000);
    }
    connectToStream() {
        if (this.buyingPowersStreamRequest) {
            if (!this.buyingPowerLoaded) {
                _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request('/portfolio/MyPortfolios/loadBuyingPwrForUserPortfolios')
                    .subscribe();
                this.buyingPowerLoaded = true;
            }
            return this.buyingPowersStreamRequest;
        }
        else {
            return this.buyingPowersStreamRequest = new rxjs__WEBPACK_IMPORTED_MODULE_11__.Observable(observer => {
                _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_4__.Streaming.connect().subscribe(isConnected => {
                    _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_4__.Streaming.subscribe(this.channelID).subscribe(event => {
                        if (event.type == _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_4__.StreamingChannelEventType.Subscribed) {
                            // console.log("buyingPowerSubscribed 1");
                            _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_4__.Streaming.log(JSON.stringify(event));
                            _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request('/portfolio/MyPortfolios/loadBuyingPwrForUserPortfolios')
                                .subscribe((x) => { });
                        }
                        else if (event.type == _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_4__.StreamingChannelEventType.MessageReceived) {
                            _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_4__.Streaming.log(JSON.stringify(event));
                            // TODO: There is something wrong with the Observable creation strategy ! this one is called many times more than necessary
                            observer.next(event.data);
                        }
                    });
                });
            });
        }
    }
    get channelID() {
        let alinmaID;
        if (_users__WEBPACK_IMPORTED_MODULE_5__.Users.current)
            alinmaID = _users__WEBPACK_IMPORTED_MODULE_5__.Users.current.alinmaID;
        return '/alinma/userChannel/' + (alinmaID);
    }
}


/***/ }),

/***/ 39620:
/*!********************************************************!*\
  !*** ./src/app/🌱models/portfolio/portfolios.model.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Portfolios": () => (/* binding */ Portfolios)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/helpers/http */ 36802);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! . */ 65082);
/* harmony import */ var _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/helpers/cached */ 569);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 86942);






class PortfoliosModel {
    constructor() {
        //#region current
        this.onCurrentPortfolioChange = new rxjs__WEBPACK_IMPORTED_MODULE_3__.Subject();
    }
    get allStandardPortfolios() {
        return this.all.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)(portfolios => portfolios.filter(p => p.type === ___WEBPACK_IMPORTED_MODULE_1__.PortfolioType.STANDARD_PORTFOLIO)));
    }
    get allMutualFundPortfolios() {
        return this.all.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)(portfolios => portfolios.filter(p => p.type === ___WEBPACK_IMPORTED_MODULE_1__.PortfolioType.MUTUAL_FUND)));
    }
    manageDefaultPortfolio(portfolioNumber, portfolioType, actionType) {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request('/Portfolio/MyPortfolios/manageDefaultPortfolio', { portfolioNumber: portfolioNumber, portfolioType: portfolioType, actionType: actionType }, { presentMessage: true });
    }
    get all() {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request('/Portfolio/MyPortfolios/loadPortfolios', { portfolioType: '' }) // ! Shouldn't receive any parameter
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((result = []) => {
            var _a;
            const portfolios = new Array();
            for (const p of result) {
                portfolios.push(new ___WEBPACK_IMPORTED_MODULE_1__.Portfolio({
                    id: p.number,
                    value: p.number,
                    title: p.name,
                    samaAccount: (_a = p.samaAccount) === null || _a === void 0 ? void 0 : _a.accountNumber,
                    type: p.portfolioType.code,
                    accountType: p.account && p.account.accountType ? p.account.accountType.code : null,
                    accountNumber: p.account ? p.account.accountNumber : null,
                    defaultPortfolio: p.defaultPortfolio
                }));
            }
            return portfolios;
        }));
    }
    get getOrderPagePortfolios() {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request('/Portfolio/MyPortfolios/loadPortfolios', { portfolioType: '' }) // ! Shouldn't receive any parameter
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((result = []) => {
            var _a;
            const portfolios = new Array();
            for (const p of result) {
                portfolios.push(new ___WEBPACK_IMPORTED_MODULE_1__.Portfolio({
                    id: p.number,
                    value: p.number,
                    title: p.name,
                    samaAccount: (_a = p.samaAccount) === null || _a === void 0 ? void 0 : _a.accountNumber,
                    type: p.portfolioType.code,
                    accountType: p.account && p.account.accountType ? p.account.accountType.code : null,
                    accountNumber: p.account ? p.account.accountNumber : null,
                    defaultPortfolio: p.defaultPortfolio
                }));
            }
            return portfolios.filter((p) => p.type == ___WEBPACK_IMPORTED_MODULE_1__.PortfolioType.STANDARD_PORTFOLIO);
        }));
    }
    get loadPortfolios() {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request('/Portfolio/MyPortfolios/loadPortfolios', { portfolioType: '' }) // ! Shouldn't receive any parameter
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((result) => {
            return result;
        }));
    }
    get current() {
        return this._current;
    }
    set current(portfolio) {
        if (portfolio)
            this.onCurrentPortfolioChange.next(this._current = portfolio);
    }
    //#endregion
    //#region Streaming
    // buyingPowerLoaded = false;
    // get channelID() {
    //     let userService = Injector.get(UserService);
    //     let alinmaID;
    //     if (userService.currentUser)
    //         alinmaID = userService.currentUser.alinmaID;
    //     return '/alinma/userChannel/' + (alinmaID);
    // }
    // buyingPowersStreamRequest: Observable<any>;
    // connectToStream(): Observable<any> {
    //     if (this.buyingPowersStreamRequest) {
    //         if (!this.buyingPowerLoaded) {
    //             Http.request<any>('/portfolio/MyPortfolios/loadBuyingPwrForUserPortfolios')
    //                 .catch((err) => {
    //                     return new ErrorObservable("");
    //                 }).subscribe()
    //             this.buyingPowerLoaded = true;
    //         }
    //         return this.buyingPowersStreamRequest;
    //     } else {
    //         return this.buyingPowersStreamRequest = new Observable<any>(observer => {
    //             let streamingService = Injector.get(StreamingService);
    //             let http = Injector.get(HttpClient);
    //             streamingService.connect().subscribe(isConnected => {
    //                 streamingService.subscribe(this.channelID).subscribe(event => {
    //                     if (event.type == StreamingService.ChannelEventType.Subscribed) {
    //                         console.log("buyingPowerSubscribed 1");
    //                         StreamingService.log(JSON.stringify(event));
    //                         http.request<any>('/portfolio/MyPortfolios/loadBuyingPwrForUserPortfolios')
    //                             .catch((err) => {
    //                                 return new ErrorObservable("");
    //                             }).subscribe()
    //                     } else if (event.type == StreamingService.ChannelEventType.MessageReceived) {
    //                         StreamingService.log(JSON.stringify(event));
    //                         console.log("buyingPowerSubscribed");
    //                         // TODO: There is something wrong with the Observable creation strategy ! this one is called many times more than necessary
    //                         observer.next(event.data);
    //                     }
    //                 })
    //             })
    //         })
    //     }
    // }
    // disconnectToStream() {
    //     // Injector.get(StreamingService).unsubscribe(this.channelID);
    // }
    //#endregion
    //#region Refreshable
    refresh() {
        // this.all.subscribe((portfolios) => {
        //     portfolios?.forEach((p) => {
        //         p.refreshBuyingPower();
        //         p.refreshBuyingPower();
        //     }
        //     );
        // });
    }
    //#endregion
    findById(id) {
        // return of(new Symbol());
        return this.all.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)(portfolios => {
            // console.log(symbolsHash[id] || defaultValue);
            return portfolios === null || portfolios === void 0 ? void 0 : portfolios.find(p => {
                return p.id == id;
            });
        }));
    }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_2__.cached,
    (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:type", Object),
    (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:paramtypes", [])
], PortfoliosModel.prototype, "allStandardPortfolios", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_2__.cached,
    (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:type", Object),
    (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:paramtypes", [])
], PortfoliosModel.prototype, "allMutualFundPortfolios", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_2__.cached,
    (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:type", Object),
    (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:paramtypes", [])
], PortfoliosModel.prototype, "all", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_2__.cached,
    (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:type", Object),
    (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:paramtypes", [])
], PortfoliosModel.prototype, "getOrderPagePortfolios", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_2__.cached,
    (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:type", Object),
    (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:paramtypes", [])
], PortfoliosModel.prototype, "loadPortfolios", null);
const Portfolios = new PortfoliosModel();


/***/ }),

/***/ 61202:
/*!******************************************!*\
  !*** ./src/app/🌱models/symbol/index.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Symbol": () => (/* reexport safe */ _symbol_model__WEBPACK_IMPORTED_MODULE_1__.Symbol),
/* harmony export */   "SymbolState": () => (/* reexport safe */ _symbol_state__WEBPACK_IMPORTED_MODULE_2__.SymbolState),
/* harmony export */   "Symbols": () => (/* reexport safe */ _symbols_model__WEBPACK_IMPORTED_MODULE_0__.Symbols),
/* harmony export */   "SymbolsModel": () => (/* reexport safe */ _symbols_model__WEBPACK_IMPORTED_MODULE_0__.SymbolsModel)
/* harmony export */ });
/* harmony import */ var _symbols_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./symbols.model */ 41998);
/* harmony import */ var _symbol_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./symbol.model */ 77334);
/* harmony import */ var _symbol_state__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./symbol-state */ 90552);





/***/ }),

/***/ 58705:
/*!*******************************************************!*\
  !*** ./src/app/🌱models/symbol/symbol-depth.model.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ask": () => (/* binding */ Ask),
/* harmony export */   "AskAndBid": () => (/* binding */ AskAndBid),
/* harmony export */   "Bid": () => (/* binding */ Bid),
/* harmony export */   "MarketDepth": () => (/* binding */ MarketDepth),
/* harmony export */   "MarketDepthAndTradesList": () => (/* binding */ MarketDepthAndTradesList),
/* harmony export */   "SymbolMarketDepthAndTradesList": () => (/* binding */ SymbolMarketDepthAndTradesList),
/* harmony export */   "Trade": () => (/* binding */ Trade),
/* harmony export */   "symbolDepth": () => (/* binding */ symbolDepth)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 61555);
/* harmony import */ var _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/helpers/http */ 36802);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @inma/helpers/streaming */ 9199);




class Trade {
}
class MarketDepth {
}
class Bid {
    constructor() {
        this.price = 0;
        this.quantity = 0;
        this.split = 0;
    }
}
class Ask {
    constructor() {
        this.price = 0;
        this.quantity = 0;
        this.split = 0;
    }
}
class AskAndBid {
    constructor() {
        this.bidPrice = 0;
        this.bidQuantity = 0;
        this.bidSplit = 0;
        this.askPrice = 0;
        this.askQuantity = 0;
        this.askSplit = 0;
    }
}
class MarketDepthAndTradesList {
}
class SymbolMarketDepthAndTradesList {
    loadMarketDepthAndTradesList() {
        if (!this.marketDepthAndTradesListSubject) {
            // debugger;
            this.marketDepthAndTradesListSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__.ReplaySubject(1);
            _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request('/Market/MarketDepthService/getMarketDepth', { symbol: this === null || this === void 0 ? void 0 : this.id })
                .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)(result => {
                this.connectToDepthStream(this);
                return this.cachedMarketDepthAndTradesList = result || {};
            })).subscribe((x) => this.marketDepthAndTradesListSubject.next(x));
        }
        return this.marketDepthAndTradesListSubject;
    }
    get marketDepthAndTradesList() {
        return this.loadMarketDepthAndTradesList();
    }
    get depth() {
        return this.marketDepthAndTradesList.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)(marketDepthAndTradesList => {
            return marketDepthAndTradesList.marketDepth || {};
        }));
    }
    get bid() {
        return this.bids.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)(bids => (bids === null || bids === void 0 ? void 0 : bids[0]) || new Bid()));
    }
    //! reversed due to error of backend
    get asks() {
        return this.depth.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)(depth => {
            // if ((this as any).id == '3050')
            // debugger
            const bids = new Array();
            for (let i = 1; i <= 20; i++) {
                if (parseInt(depth[`bidQty${i}`]) != null) {
                    const bid = new Bid();
                    bid.price = depth[`bidPrice${i}`];
                    bid.quantity = depth[`bidQty${i}`];
                    bid.split = depth[`bidSplit${i}`];
                    bids.push(bid);
                }
            }
            return bids;
        }));
    }
    get asksAndBids() {
        return this.depth.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)(depth => {
            const asksAndBids = new Array();
            for (let i = 1; i <= 20; i++) {
                if (parseInt(depth[`bidQty${i}`]) != null) {
                    const askAndBid = new AskAndBid();
                    askAndBid.askPrice = depth[`bidPrice${i}`];
                    askAndBid.askQuantity = depth[`bidQty${i}`];
                    askAndBid.askSplit = depth[`bidSplit${i}`];
                    askAndBid.bidPrice = depth[`askPrice${i}`];
                    askAndBid.bidQuantity = depth[`askQty${i}`];
                    askAndBid.bidSplit = depth[`askSplit${i}`];
                    asksAndBids.push(askAndBid);
                }
            }
            return asksAndBids;
        }));
    }
    get ask() {
        return this.asks.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)(asks => (asks === null || asks === void 0 ? void 0 : asks[0]) || new Ask()));
    }
    get bids() {
        return this.depth.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)(depth => {
            const asks = new Array();
            for (let i = 1; i <= 20; i++) {
                if (parseInt(depth[`askQty${i}`]) != null) {
                    const ask = new Ask();
                    ask.price = depth[`askPrice${i}`];
                    ask.quantity = depth[`askQty${i}`];
                    ask.split = depth[`askSplit${i}`];
                    asks.push(ask);
                }
            }
            return asks;
        }));
    }
    get trades() {
        return this.marketDepthAndTradesList.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)(marketDepthAndTradesList => {
            return marketDepthAndTradesList.tradesList;
        }));
    }
    get trade() {
        return this.trades.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)(trades => trades === null || trades === void 0 ? void 0 : trades[0]));
    }
    connectToDepthStream(symbol) {
        _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_1__.Streaming.connect().subscribe(isConnected => {
            _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_1__.Streaming.subscribe(`/alinma/marketDepth/${symbol.id}`).subscribe(event => {
                if (event.type === _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_1__.StreamingChannelEventType.Subscribed) {
                    _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_1__.Streaming.log(JSON.stringify(event));
                }
                else if (event.type === _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_1__.StreamingChannelEventType.MessageReceived) {
                    this.cachedMarketDepthAndTradesList = JSON.parse(event.data.data);
                    if (this.marketDepthAndTradesListSubject)
                        this.marketDepthAndTradesListSubject.next(this.cachedMarketDepthAndTradesList);
                }
            });
        });
        // if (!this.randomInterval) {
        //     this.randomInterval = setInterval(() => {
        //         if (!this.cachedMarketDepthAndTradesList) this.cachedMarketDepthAndTradesList = { marketDepth: { bidPrice1: "", bidQty1: "1" } };
        //         this.cachedMarketDepthAndTradesList["marketDepth"]["bidPrice1"] = Math.random();
        //         this.cachedMarketDepthAndTradesList["marketDepth"]["bidQty1"] = "1";
        //         if (this.marketDepthAndTradesListSubject)
        //             this.marketDepthAndTradesListSubject.next(this.cachedMarketDepthAndTradesList);
        //     }, 1000);
        // }
    }
    disconnectFromDepthStream() {
        _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_1__.Streaming.unsubscribe(`/alinma/marketDepth/${this.id}`);
    }
}
const symbolDepth = new SymbolMarketDepthAndTradesList();


/***/ }),

/***/ 91447:
/*!******************************************************!*\
  !*** ./src/app/🌱models/symbol/symbol-parameters.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SymbolParameters": () => (/* binding */ SymbolParameters)
/* harmony export */ });
class SymbolParameters {
    constructor(options) {
        var _a;
        if (!options)
            return;
        this.lastUpdatedTime = options.lastUpdatedTime;
        this.openPrice = options.open;
        this.change = options.change;
        this.changePercentage = (_a = Number(options.percentChanged)) === null || _a === void 0 ? void 0 : _a.toString();
        this.liquidityPercentage = Math.floor(options.cachePercent * 100 * 100) / 100;
        this.liquidityFlow = (options === null || options === void 0 ? void 0 : options.cashInTurnover) / (options === null || options === void 0 ? void 0 : options.cashOutTurnover);
        this.liquidityNet = (options === null || options === void 0 ? void 0 : options.cashInTurnover) - (options === null || options === void 0 ? void 0 : options.cashOutTurnover);
        // تدفق
        this.cashInTurnover = options.cashInTurnover; //: "5611752.41" تدفق
        // حجم السيولة الداخلة
        this.cashInVolume = options.cashInVolume; //: "75277" حجم السيولة الداخلة
        // تغير السيولة الخارجة
        this.cashOutTurnover = options.cashOutTurnover; //: "5959933.32"
        // حجم السيولة الخارجة
        this.cashOutVolume = options.cashOutVolume; //: "79937" حجم السيولة الخارجة
        this.noOfTrades = options.noOfTrades;
        // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        // Values here are switched due to webservice mistake !
        this.biddingQuantity = options.askQty;
        this.biddingPrice = options.askPrice;
        this.askQuantity = options.bidQty;
        this.askPrice = options.bidPrice;
        // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        this.minimumPrice = options.minPrice;
        this.lowestPrice = options.lowPrice;
        this.maximumPrice = options.maxPrice;
        this.highestPrice = options.highPrice;
        this.tradingVolume = options.volumn;
        this.tradingValue = options.turnOver;
        this.lastTradedPrice = options.lastTradedPrice;
        this.numberOfTrades = options.noOfTrades;
        this.lastTradeTime = options.lastTradeTime;
        this.previousClosed = options.previousClosed;
        this.includedIntoWatchList = options.includedIntoWatchList;
        this.watchListsIds = options.watchListsIds;
        this.marketCode = options.marketCode;
    }
}


/***/ }),

/***/ 90552:
/*!*************************************************!*\
  !*** ./src/app/🌱models/symbol/symbol-state.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SymbolState": () => (/* binding */ SymbolState)
/* harmony export */ });
var SymbolState;
(function (SymbolState) {
    SymbolState["Up"] = "up";
    SymbolState["Down"] = "down";
    SymbolState["Unknown"] = "unknown";
})(SymbolState || (SymbolState = {}));


/***/ }),

/***/ 77334:
/*!*************************************************!*\
  !*** ./src/app/🌱models/symbol/symbol.model.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Symbol": () => (/* binding */ Symbol)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 64139);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 84505);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs */ 19193);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var _symbol_state__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./symbol-state */ 90552);
/* harmony import */ var _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @inma/helpers/cached */ 569);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs/operators */ 80522);
/* harmony import */ var _symbols_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./symbols.model */ 41998);
/* harmony import */ var _inma_helpers_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/helpers/http */ 36802);
/* harmony import */ var _symbol_parameters__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./symbol-parameters */ 91447);
/* harmony import */ var _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @inma/helpers/streaming */ 9199);
/* harmony import */ var _symbol_depth_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./symbol-depth.model */ 58705);
/* harmony import */ var _portfolio__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../portfolio */ 65082);
/* harmony import */ var _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @inma/helpers/injector */ 19753);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 3184);













class Symbol extends _symbol_depth_model__WEBPACK_IMPORTED_MODULE_6__.SymbolMarketDepthAndTradesList {
    constructor(data) {
        super();
        this.availableQuantity = 0;
        this.ownedQuantity = 0;
        this.gainLossRealized = 0;
        this.gainLossPercentageRealized = 0;
        this.gainLossUnrealized = 0;
        this.gainLossPercentageUnrealized = 0;
        this.costTotal = 0;
        this.costAverage = 0;
        this.marketValue = 0;
        this.annualMax = 0;
        this.annualMin = 0;
        this.symbolPrice = 0;
        this.checked = false;
        // static lastObjectID = 1;
        // _objectID;
        // get objectID() {
        //     if (!this._objectID) {
        //         this._objectID = Symbol.lastObjectID;
        //         Symbol.lastObjectID += 1;
        //     }
        //     return this._objectID;
        // }
        this._changing = 0;
        this.state = _symbol_state__WEBPACK_IMPORTED_MODULE_0__.SymbolState.Unknown;
        this.symbolData = data;
        this.id = data === null || data === void 0 ? void 0 : data.id;
        this.sortAbbreviation = data === null || data === void 0 ? void 0 : data.shortDescription;
        this.sortPercentChanged = data === null || data === void 0 ? void 0 : data.percentChanged;
        if (data === null || data === void 0 ? void 0 : data.description)
            this.name = (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.of)(data === null || data === void 0 ? void 0 : data.description);
        if (data === null || data === void 0 ? void 0 : data.name)
            this.name = (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.of)(data === null || data === void 0 ? void 0 : data.name);
        if (data === null || data === void 0 ? void 0 : data.shortDescription)
            this.abbreviation = (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.of)(data === null || data === void 0 ? void 0 : data.shortDescription);
        this.portfolioID = data === null || data === void 0 ? void 0 : data.portfolioID;
        this.availableQuantity = parseInt((data === null || data === void 0 ? void 0 : data.availQuantity) || "0");
        this.ownedQuantity = data === null || data === void 0 ? void 0 : data.ownedQuantity;
        this.costTotal = data === null || data === void 0 ? void 0 : data.costTotal;
        this.costAverage = data === null || data === void 0 ? void 0 : data.costAverage;
        this.gainLossRealized = data === null || data === void 0 ? void 0 : data.gainLossRealized;
        this.gainLossPercentageRealized = data === null || data === void 0 ? void 0 : data.gainLossPercentageRealized;
        this.gainLossUnrealized = data === null || data === void 0 ? void 0 : data.gainLossUnrealized;
        this.gainLossPercentageUnrealized = data === null || data === void 0 ? void 0 : data.gainLossPercentageUnrealized;
        this.marketValue = data === null || data === void 0 ? void 0 : data.marketValue;
        this.symbolPrice = data === null || data === void 0 ? void 0 : data.symbolPrice;
        this.watchListsIds = data === null || data === void 0 ? void 0 : data.watchListsIds;
        this.includedIntoWatchList = data === null || data === void 0 ? void 0 : data.includedIntoWatchList;
        this.marketCode = data === null || data === void 0 ? void 0 : data.marketCode;
        Symbol.zone = _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_8__.Injector.get(_angular_core__WEBPACK_IMPORTED_MODULE_10__.NgZone);
        // setTimeout(() => {
        // if (this.id == '1020'){
        // this.connectToStream();
        // }
        // if (this.id == '1150')
        //     setInterval(() => {
        //         Symbol.theOneCallback({ type: StreamingChannelEventType.MessageReceived, data: { data: JSON.stringify({ symbol: 1150, lastTradedPrice: Math.floor(Math.random() * 100) }) } });
        //     }, 5000)
        // setInterval(
        //     () => {
        //         const params = this['cachedParameters'];
        //         // if (params) {
        //         //     params.lastTradedPrice = Math.floor(Math.random() * 1000).toString();
        //         //     this.parameters = of(params);
        //         // }
        //         ///////
        //         if (params) {
        //             params.lastTradedPrice = Math.floor(Math.random() * 1000).toString();
        //             Symbols.findById(this.id).subscribe(symbol => {
        //                 if (!symbol) return;
        //                 symbol.parameters = of(params);
        //                 setTimeout(() => {
        //                     symbol.updateSymbolState();
        //                 }, 0);
        //             });
        //         }
        //     }
        //     , 1000
        // )
        // }, 0);
    }
    get change() {
        return this.parameters.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.map)(params => params === null || params === void 0 ? void 0 : params.changePercentage));
    }
    get changing() {
        return this._changing;
    }
    toSearchable() {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.of)(this);
    }
    //#region name
    get name() {
        return _symbols_model__WEBPACK_IMPORTED_MODULE_2__.Symbols.findById(this.id).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.mergeMap)(symbol => {
            return symbol === null || symbol === void 0 ? void 0 : symbol.name;
        }));
    }
    set name(name) {
        this._name = name;
    }
    //#endregion
    //#region abbreviation
    get abbreviation() {
        return _symbols_model__WEBPACK_IMPORTED_MODULE_2__.Symbols.findById(this.id).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.mergeMap)(symbol => {
            // Console.logObservable(symbol?.abbreviation);
            return symbol === null || symbol === void 0 ? void 0 : symbol.abbreviation;
        }));
    }
    set abbreviation(abbreviation) {
        this._abbreviation = abbreviation;
    }
    //#endregion
    //#region change
    get symbolChange() {
        return _symbols_model__WEBPACK_IMPORTED_MODULE_2__.Symbols.findById(this.id).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.map)(symbol => {
            //  debugger;
            return symbol.symbolData.percentChanged;
        }));
    }
    set symbolChange(symbolChange) {
        this._symbolChange = symbolChange;
    }
    //#endregion
    //#region price
    get price() {
        return this.parameters.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.map)(params => {
            return params === null || params === void 0 ? void 0 : params.lastTradedPrice;
        }));
    }
    set price(price) {
        price.subscribe(p => {
            this.parameters.subscribe((params) => {
                params.lastTradedPrice = p;
            });
        });
    }
    get infoParameters() {
        // console.log('chunky parameters = ' + this.id)
        if (!this.symbolParametersSubject) {
            this.symbolParametersSubject = new rxjs__WEBPACK_IMPORTED_MODULE_13__.BehaviorSubject(new _symbol_parameters__WEBPACK_IMPORTED_MODULE_4__.SymbolParameters());
            this.id && _inma_helpers_http__WEBPACK_IMPORTED_MODULE_3__.Http.request('/Symbol/SymbolInquiry/getSymbolCurrentInfo', { symbolCode: this.id })
                .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.map)((result) => {
                //         // if (Number(result?.lastTradedPrice))
                //         //     this.dayHistory.push(new SymbolHistoryPoint(result));
                const params = new _symbol_parameters__WEBPACK_IMPORTED_MODULE_4__.SymbolParameters(result);
                // setTimeout(() => {
                this.updateSymbolState(params);
                // }, 0);
                return params;
            })).subscribe(params => this.symbolParametersSubject.next(params));
        }
        return this.symbolParametersSubject;
    }
    get parameters() {
        // console.log('chunky parameters = ' + this.id)
        if (!this.symbolParametersSubject) {
            this.symbolParametersSubject = new rxjs__WEBPACK_IMPORTED_MODULE_13__.BehaviorSubject(new _symbol_parameters__WEBPACK_IMPORTED_MODULE_4__.SymbolParameters());
            const params = new _symbol_parameters__WEBPACK_IMPORTED_MODULE_4__.SymbolParameters(this.symbolData);
            this.updateSymbolState(params);
            this.symbolParametersSubject.next(params);
        }
        return this.symbolParametersSubject;
    }
    set parameters(parameters) {
        // this.parameters.subscribe(oldParams => {
        parameters.subscribe(newParams => {
            var _a;
            // if (this._cachedParams?.lastTradedPrice  && this._cachedParams?.lastTradedPrice != newParams?.lastTradedPrice)
            //     console.log(this.id, 'changed', newParams?.lastTradedPrice);
            this.cachedParams = newParams;
            (_a = this.symbolParametersSubject) === null || _a === void 0 ? void 0 : _a.next(newParams);
            this.updateSymbolState(newParams);
        });
        // });
    }
    setParameters(newParams) {
        // this.parameters.subscribe(oldParams => {
        var _a;
        // if (this._cachedParams?.lastTradedPrice  && this._cachedParams?.lastTradedPrice != newParams?.lastTradedPrice)
        //     console.log(this.id, 'changed', newParams?.lastTradedPrice);
        this.cachedParams = newParams;
        (_a = this.symbolParametersSubject) === null || _a === void 0 ? void 0 : _a.next(newParams);
        this.updateSymbolState(newParams);
        // });
    }
    static theOneCallback(event) {
        //console.log(">>>>>>>>>>>>>>>>>>>>", event);
        if (event.type === _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_5__.StreamingChannelEventType.Subscribed) {
            _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_5__.Streaming.log(JSON.stringify(event));
        }
        else if (event.type === _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_5__.StreamingChannelEventType.MessageReceived) {
            let message = JSON.parse(event.data.data);
            _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_5__.Streaming.log(JSON.stringify(event));
            //console.log(message);
            // Symbols.all.subscribe(symbols => {
            //     symbols.forEach((s, i) => {
            //         if (i < 10) {
            //             newParams.lastTradedPrice = (Math.random() * 1000).toString();
            //             s.parameters = of(newParams);
            //         }
            //     });
            // });
            if (message === null || message === void 0 ? void 0 : message.symbol) { // this to append symbol subscribe cometd to be listed in array and continue execution 
                message = [].concat(message);
            }
            let messageCount = 0;
            for (let i = 0; i < message.length; i++) {
                const newParams = new _symbol_parameters__WEBPACK_IMPORTED_MODULE_4__.SymbolParameters(message[i]);
                _symbols_model__WEBPACK_IMPORTED_MODULE_2__.Symbols.findById(message[i].symbol).subscribe(symbol => {
                    if (!symbol)
                        return;
                    if (symbol === null || symbol === void 0 ? void 0 : symbol.cachedParams) {
                        if (symbol['blinkingTimeout'])
                            clearTimeout(symbol['blinkingTimeout']);
                        if (newParams.lastTradedPrice > symbol.cachedParams.lastTradedPrice) {
                            symbol._changing = 1;
                            // console.log(symbol.cachedParams.lastTradedPrice, newParams.lastTradedPrice, 'up');
                        }
                        else if (newParams.lastTradedPrice < symbol.cachedParams.lastTradedPrice) {
                            symbol._changing = -1;
                            // console.log(symbol.cachedParams.lastTradedPrice, newParams.lastTradedPrice, 'down');
                        }
                        else {
                            symbol._changing = 0;
                            // console.log(symbol.cachedParams.lastTradedPrice, newParams.lastTradedPrice, 'still');
                        }
                        symbol['blinkingTimeout'] = setTimeout(() => {
                            symbol._changing = 0;
                        }, 3000);
                    }
                    // if (symbol?.id == '2020')
                    // console.log(symbol?.id, newParams?.lastTradedPrice);
                    // const modified = (Number(symbol.price)).toString();
                    // symbol.price = of(modified);
                    // symbol.dayHistory.push(new SymbolHistoryPoint({ price: Number(modified), time: newParams.lastTradeTime }));
                    // setTimeout(() => {
                    // Symbol.zone.run(() => {
                    symbol.setParameters(newParams);
                    symbol.updateSymbolState(newParams);
                    messageCount++;
                    if (messageCount == message.length) {
                        this.patchChange.next();
                    }
                    // })
                    // }, 0);
                });
            }
        }
    }
    updateSymbolState(params = null) {
        if (params) {
            this.state = Number(params.change) < 0 ? _symbol_state__WEBPACK_IMPORTED_MODULE_0__.SymbolState.Down : _symbol_state__WEBPACK_IMPORTED_MODULE_0__.SymbolState.Up;
        }
        else {
            this.parameters.subscribe((params) => {
                this.state = Number(params.change) < 0 ? _symbol_state__WEBPACK_IMPORTED_MODULE_0__.SymbolState.Down : _symbol_state__WEBPACK_IMPORTED_MODULE_0__.SymbolState.Up;
            });
        }
    }
    toString() {
        var _a, _b;
        if (typeof (this.name.pipe) != 'function') {
            //! why its type being changed
            return this.name;
        }
        else {
            //console.log(`${this.abbreviation}- ${this.name?.toString()}`)
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.of)(`${this.id} - ${(_a = this.symbolData) === null || _a === void 0 ? void 0 : _a.shortDescription} - ${(_b = this.symbolData) === null || _b === void 0 ? void 0 : _b.description}`);
            // return (this.name?.pipe(flatMap(name => {
            //     return this.abbreviation.pipe(map(abbr => {
            //         if (this.id)
            //             return `${this.id} - ${abbr?.toString()} - ${name?.toString()}`;
            //         else
            //             return null;
            //     }));
            // }))) || of("");
        }
    }
    get porfolios() {
        return _portfolio__WEBPACK_IMPORTED_MODULE_7__.Portfolios.all.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.mergeMap)(portfolios => {
            const findings = [];
            for (let p = 0; p < portfolios.length; p++) {
                const portfolio = portfolios[p];
                const ownedSymbols = portfolio.symbols.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.map)(symbols => {
                    // console.log("portfolio symbols = ", symbols);
                    return symbols.filter(s => s.id == this.id);
                }));
                findings.push(ownedSymbols.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.map)(ownedSymbols => {
                    // console.log('*****' + ownedSymbols.length);
                    return ownedSymbols.length > 0 ? portfolio : null;
                })));
            }
            return (findings === null || findings === void 0 ? void 0 : findings.length) ? (0,rxjs__WEBPACK_IMPORTED_MODULE_14__.combineLatest)(findings).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.map)(arr => arr.filter(item => item))) : (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.of)(new Array());
        }));
    }
    get isOwned() {
        return this.porfolios.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.map)(portfolios => (portfolios === null || portfolios === void 0 ? void 0 : portfolios.length) > 0));
    }
}
//#endregion
//#region dayHistory
// private _dayHistory: SymbolHistoryPoint[] = [];
// set dayHistory(dayHistory) {
//     this._dayHistory = dayHistory;
// }
// get dayHistory() {
//     return this._dayHistory;
// }
//#endregion
// @cached
// get day() {
//     return Http.request('/Symbol/SymbolInquiry/getPriceChangeInPeriod', { symbolCode: this.id, period: SymbolHistoryFilter.Day })
//         .pipe(map((result) => {
//             const prices: SymbolHistoryPoint[] = result?.map(p => new SymbolHistoryPoint(p)) || [];
//             // check if cached day is empty then assign prices history to it else add the prices history to the start of the cached day array
//             if (!this.dayHistory || !this.dayHistory.length)
//                 this.dayHistory = prices;
//             else
//                 this.dayHistory = prices.concat(this.dayHistory);
//             // return this.cachedDay = Arrays.uniqueBy(this.cachedDay, 'time');
//             return this.dayHistory;
//         }));
// }
// // TODO: this need to be strongly typed
// cachedHistories = {};
// getHistory(period: SymbolHistoryFilter = SymbolHistoryFilter.Week): Observable<SymbolHistory> {
//     if (this.cachedHistories[period]) {
//         return Observable.of(this.cachedHistories[period]);
//     } else {
//         let http = Injector.get(HttpClient);
//         return http.request<[{ 'volumn', 'price', 'lastTradeddTime' }]>('/Symbol/SymbolInquiry/getPriceChangeInPeriod',
//             {
//                 symbolCode: this.id,
//                 period: period
//             }).map((response) => {
//                 return new SymbolHistory(response.result.map(p => new SymbolHistoryPoint(p)));
//             }).catch((err) => {
//                 return new ErrorObservable("");
//             })
//     }
// }
// get channelURL(): Observable<string> {
//     return User.isLive.pipe(map(isLive => {
//         return `/alinma/quotes/all`
//     }));
// }
Symbol.patchChange = new rxjs__WEBPACK_IMPORTED_MODULE_15__.Subject();
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([
    _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_1__.cached,
    (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", rxjs__WEBPACK_IMPORTED_MODULE_17__.Observable),
    (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:paramtypes", [rxjs__WEBPACK_IMPORTED_MODULE_17__.Observable])
], Symbol.prototype, "name", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([
    _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_1__.cached,
    (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", rxjs__WEBPACK_IMPORTED_MODULE_17__.Observable),
    (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:paramtypes", [rxjs__WEBPACK_IMPORTED_MODULE_17__.Observable])
], Symbol.prototype, "abbreviation", null);


/***/ }),

/***/ 41998:
/*!**************************************************!*\
  !*** ./src/app/🌱models/symbol/symbols.model.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Symbols": () => (/* binding */ Symbols),
/* harmony export */   "SymbolsModel": () => (/* binding */ SymbolsModel)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 80522);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var _inma_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/http */ 36802);
/* harmony import */ var _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @inma/helpers/cached */ 569);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 19193);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 64139);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var _symbol_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./symbol.model */ 77334);
/* harmony import */ var _inma_helpers_strings__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/helpers/strings */ 36782);
/* harmony import */ var fast_sort__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! fast-sort */ 63559);
/* harmony import */ var _market__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../market */ 1874);
/* harmony import */ var _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @inma/helpers/streaming */ 9199);
/* harmony import */ var _users__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../users */ 17166);











class SymbolsModel {
    constructor() {
        // constructor(private platform: Platform){
        //     this.platform.pause.subscribe(async () => {
        //         Streaming.disconnect();
        //       });
        // }
        this.onAnyPriceChange = new rxjs__WEBPACK_IMPORTED_MODULE_8__.Subject();
        this.preloaded = false;
    }
    filter(queryText, symbols) {
        return (symbols || this.all).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.mergeMap)(symbols => {
            queryText = queryText === null || queryText === void 0 ? void 0 : queryText.trimStart();
            let filtered;
            if (queryText) {
                queryText = _inma_helpers_strings__WEBPACK_IMPORTED_MODULE_3__.Strings.normalizeAll(queryText);
                const digitsRegex = /\d+/m;
                // Do extraction of the query text
                let queryNumbers = queryText.match(digitsRegex);
                let queryNumber = queryNumbers && queryNumbers.length > 0 ? queryNumbers[0].trim() : null;
                let queryWords = queryText.replace(digitsRegex, '').trim().toLowerCase();
                const findings = [];
                symbols.forEach((symbol) => {
                    findings.push(symbol.toString().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.map)(toS => { return { symbol: symbol, toString: toS }; })));
                });
                const symbolsToStrings = (findings === null || findings === void 0 ? void 0 : findings.length) ? (0,rxjs__WEBPACK_IMPORTED_MODULE_11__.combineLatest)(findings) : (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.of)([]);
                filtered = symbolsToStrings.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.map)(data => {
                    let firstFilteredSearchables = [];
                    let secondFilteredSearchables = [];
                    data.forEach((dataItem) => {
                        let symbol = dataItem.symbol;
                        var matchValue = _inma_helpers_strings__WEBPACK_IMPORTED_MODULE_3__.Strings.normalizeAll(dataItem.toString);
                        let numberIndex = null, wordsIndex = null;
                        if (queryNumber)
                            numberIndex = matchValue.indexOf(queryNumber);
                        if (queryWords)
                            wordsIndex = matchValue.indexOf(queryWords);
                        if (numberIndex != null && numberIndex != -1) {
                            if (wordsIndex == null || (wordsIndex != null && wordsIndex != -1)) {
                                if (numberIndex == 0)
                                    firstFilteredSearchables.push(symbol);
                                else
                                    secondFilteredSearchables.push(symbol);
                            }
                        }
                        else if (numberIndex == null && wordsIndex && wordsIndex != -1) {
                            firstFilteredSearchables.push(symbol);
                        }
                    });
                    firstFilteredSearchables.push(...secondFilteredSearchables);
                    return firstFilteredSearchables;
                }));
            }
            else
                filtered = (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.of)(symbols);
            return filtered;
        }));
    }
    get all() {
        return _inma_http__WEBPACK_IMPORTED_MODULE_0__.Http.request('/Symbol/SymbolInquiry/getAllSymbolsCurrentInfo')
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.map)(result => {
            //console.log("symbols>>>>>",result);
            const symbols = [];
            for (let s of result /*?.splice(0, 3)*/ || []) {
                s.id = s.symbol;
                symbols.push(new _symbol_model__WEBPACK_IMPORTED_MODULE_2__.Symbol(s));
            }
            return symbols;
        }));
    }
    allSymbolsInfo() {
        return _inma_http__WEBPACK_IMPORTED_MODULE_0__.Http.request('/Symbol/SymbolInquiry/getAllSymbolsCurrentInfo')
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.map)(result => {
        }));
    }
    //******************************stream */
    connectToStream() {
        // this.parameters.subscribe(() => {
        _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_6__.Streaming.connect().subscribe(() => {
            this.channelURL.subscribe(channelURL => {
                _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_6__.Streaming.subscribe(channelURL).subscribe((event) => {
                    // Symbol.zone.runOutsideAngular(() => {
                    _symbol_model__WEBPACK_IMPORTED_MODULE_2__.Symbol.theOneCallback(event);
                    // })
                });
            });
        });
        // });
        return this;
    }
    disconnectToStream() {
        this.channelURL.subscribe(channelURL => {
            _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_6__.Streaming.unsubscribe(channelURL);
        });
    }
    get channelURL() {
        return _users__WEBPACK_IMPORTED_MODULE_7__.User.isLive.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.map)(isLive => {
            return `/alinma/quotes${isLive ? '' : '/d'}/all`;
        }));
    }
    //******************************stream for specific symbol */
    connectToStreamOfSymbol(symbolId) {
        // this.parameters.subscribe(() => {
        _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_6__.Streaming.connect().subscribe(() => {
            this.channelSymbolURL(symbolId).subscribe(channelURL => {
                _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_6__.Streaming.subscribe(channelURL).subscribe((event) => {
                    // Symbol.zone.runOutsideAngular(() => {
                    _symbol_model__WEBPACK_IMPORTED_MODULE_2__.Symbol.theOneCallback(event);
                    // })
                });
            });
        });
        // });
        return this;
    }
    disconnectToStreamSymbol(symbol) {
        this.channelSymbolURL(symbol).subscribe(channelURL => {
            _inma_helpers_streaming__WEBPACK_IMPORTED_MODULE_6__.Streaming.unsubscribe(channelURL);
        });
    }
    channelSymbolURL(symbol) {
        return _users__WEBPACK_IMPORTED_MODULE_7__.User.isLive.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.map)(isLive => {
            return `/alinma/quotes${isLive ? '' : '/d'}/${symbol}`;
        }));
    }
    get allHashed() {
        return this.all
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.map)(symbols => {
            const hashedSymbols = {};
            symbols.forEach((symbol) => hashedSymbols[symbol.id] = symbol);
            this.myCachedHashed = hashedSymbols;
            return hashedSymbols;
        }));
    }
    findById(id, defaultValue) {
        // return of(new Symbol());
        return this.allHashed.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.map)(symbolsHash => {
            // console.log(symbolsHash[id] || defaultValue);
            return symbolsHash[id] || defaultValue;
        }));
    }
    preload() {
        new _market__WEBPACK_IMPORTED_MODULE_5__.MarketModel(_market__WEBPACK_IMPORTED_MODULE_5__.MarketsNames.TASI).symbols.subscribe(symbols => { });
        return;
        if (this.preloaded)
            return;
        else
            this.preloaded = true;
        const CHUNK_SIZE = 3;
        this.all.subscribe(symbols => {
            symbols = (0,fast_sort__WEBPACK_IMPORTED_MODULE_4__["default"])(symbols).asc(u => u.id);
            debugger;
            const CHUNKS_LENGTH = symbols.length / CHUNK_SIZE;
            for (let c = 0; c < CHUNKS_LENGTH + 1; c += 1) {
                setTimeout(() => {
                    for (let s = c * CHUNK_SIZE; s < (c + 1) * CHUNK_SIZE && s < symbols.length; s++) {
                        const symbol = symbols[s];
                        symbol.parameters.subscribe();
                        symbol.depth.subscribe();
                    }
                }, c * 1000);
            }
        });
    }
    priceChangeInPeriod(symbolCode, period) {
        return _inma_http__WEBPACK_IMPORTED_MODULE_0__.Http.request("/Symbol/SymbolInquiry/getPriceChangeInPeriod", { symbolCode: symbolCode, period: period }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.map)((result) => {
            return result;
        }));
    }
    loadSymbolDataInAllPortfolios(symbol) {
        return _inma_http__WEBPACK_IMPORTED_MODULE_0__.Http.request("/Portfolio/MyPortfolios/loadSymbolPortfolios", { symbol: symbol }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.map)((result) => {
            return result;
        }));
    }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([
    _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_1__.cached,
    (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:type", Object),
    (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:paramtypes", [])
], SymbolsModel.prototype, "all", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([
    _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_1__.cached,
    (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:type", rxjs__WEBPACK_IMPORTED_MODULE_14__.Observable),
    (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:paramtypes", [])
], SymbolsModel.prototype, "allHashed", null);
const Symbols = new SymbolsModel();


/***/ }),

/***/ 43857:
/*!*********************************************************!*\
  !*** ./src/app/🌱models/users/authentication-method.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthenticationMethod": () => (/* binding */ AuthenticationMethod)
/* harmony export */ });
class AuthenticationMethod {
    constructor(options) {
        this.methodName = options === null || options === void 0 ? void 0 : options.methodName;
        this.type = options === null || options === void 0 ? void 0 : options.type;
        this.value = options === null || options === void 0 ? void 0 : options.value;
        this.order = options === null || options === void 0 ? void 0 : options.order;
        this.methodLabel = options === null || options === void 0 ? void 0 : options.methodLabel;
    }
}


/***/ }),

/***/ 93143:
/*!**************************************************!*\
  !*** ./src/app/🌱models/users/authentication.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Authentication2": () => (/* binding */ Authentication2)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 61555);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/helpers/http */ 36802);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 80522);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/operators */ 25843);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs/operators */ 47418);
/* harmony import */ var _authentication_method__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./authentication-method */ 43857);
/* harmony import */ var src_environments__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments */ 92020);
/* harmony import */ var src_app_loading_loading_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/loading/loading.page */ 77089);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/helpers/injector */ 19753);
/* harmony import */ var src_app_animations_fade_enter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/animations/fade-enter */ 32892);










const CONFIRM_SUB_ACTION = "confirm";
const AUHTENTICATE_SUB_ACTION = "authenticate";
class AuthenticationHelper {
    constructor() {
        this.authenticationGroupsSubject = new rxjs__WEBPACK_IMPORTED_MODULE_6__.ReplaySubject();
        this.smsGroupNumber = "1";
        this.biometricGroupNumber = "3";
        // encrypt(value): Observable<string> {
        //     let encryption = (<any>Environment).encryption;
        //     if(Environment.name.toLowerCase() != 'production' && encryption && encryption.enabled == false)
        //         return Observable.of(value);
        //     else
        //         return this.getEncryptionKey().pipe(map(key => {
        //             return this.encodingProvider.getEncryptedValue(value, key);
        //         }))
        // }
        // private getEncryptionKey(): Observable<string> {
        //     //if (!this.encryptionKey) {
        //         return this.http.request<string>("/LoginService/Authenticate/getEncryptionKeys")
        //             .map(response => {
        //                 this.encryptionKey = response.result;
        //                 console.log("Encryption Key"+this.encryptionKey);
        //                 return this.encryptionKey;
        //             }).catch((err) => {
        //                     return new ErrorObservable("");
        //             });
        // }
        // onReset() {
        //     this.encryptionKey = null;
        // }
    }
    // encryptionKey: string;
    // loadingModal:Modal;
    start(service, action, touchIdAvailable, loadingText) {
        this.sourceService = service;
        this.sourceAction = action;
        this.touchIdAvailable = touchIdAvailable ? touchIdAvailable : false;
        if (src_environments__WEBPACK_IMPORTED_MODULE_2__.Environment.isBiometricMockingEnabled) {
            this.touchIdAvailable = true;
        }
        this.loadingText = loadingText;
        return this.confirmAction();
    }
    confirmAction() {
        if (this.sourceAction == "FundTransfers") {
            return this.authenticateAction("", [new _authentication_method__WEBPACK_IMPORTED_MODULE_1__.AuthenticationMethod()]);
        }
        else {
            return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request(`/${this.sourceService}/${this.sourceAction}/${CONFIRM_SUB_ACTION}${this.sourceAction}`).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.mergeMap)((result) => {
                if (!(result === null || result === void 0 ? void 0 : result.numOfGrps)) {
                    return this.authenticateAction("", [new _authentication_method__WEBPACK_IMPORTED_MODULE_1__.AuthenticationMethod()]);
                }
                else {
                    return this.handleAuthenticationGroups(result);
                }
            }));
        }
    }
    handleAuthenticationGroups(result) {
        if (result.numOfGrps == 1) {
            var groupName = result.groupName;
            //cachedIndex=0;
            // TODO - rewrite the below section
            if (groupName == this.biometricGroupNumber) {
                var methods = new Array();
                methods.push(new _authentication_method__WEBPACK_IMPORTED_MODULE_1__.AuthenticationMethod({ methodName: "", type: "", value: "", order: 0, methodLabel: "" }));
                return this.authenticateSourceAction("", methods);
            }
            else {
                this.authenticationGroupsSubject.next(result.groups);
                //if (this.dynamicAuthenticationSubject)
                //    this.dynamicAuthenticationSubject.complete();
                this.dynamicAuthenticationSubject = new rxjs__WEBPACK_IMPORTED_MODULE_8__.Subject();
                return this.dynamicAuthenticationSubject;
            }
        }
        else {
            let authenticationGroups = result.groups;
            if (!this.touchIdAvailable) {
                authenticationGroups = authenticationGroups.filter((group) => {
                    return group.groupName != this.biometricGroupNumber;
                });
                if (authenticationGroups.length == 1) {
                    this.generateAuthenticationToken(authenticationGroups[0].groupName).subscribe();
                }
            }
            this.authenticationGroupsSubject.next(authenticationGroups);
            //if (this.dynamicAuthenticationSubject)
            //    this.dynamicAuthenticationSubject.complete();
            this.dynamicAuthenticationSubject = new rxjs__WEBPACK_IMPORTED_MODULE_8__.Subject();
            return this.dynamicAuthenticationSubject;
        }
    }
    authenticateSourceAction(groupName, methods) {
        if (this.loadingText) {
            // const loadingModal = modalCtrl.create('LoadingPage', { text: this.loadingText });
            // loadingModal.present();
        }
        let loadingModal;
        let hasError = false;
        setTimeout(() => (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            if (!hasError) {
                const modalCtrl = _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_4__.Injector.get(_ionic_angular__WEBPACK_IMPORTED_MODULE_10__.ModalController);
                loadingModal = yield modalCtrl.create({
                    component: src_app_loading_loading_page__WEBPACK_IMPORTED_MODULE_3__.LoadingPage,
                    cssClass: '',
                    enterAnimation: src_app_animations_fade_enter__WEBPACK_IMPORTED_MODULE_5__.fadeEnterAnimation,
                    leaveAnimation: src_app_animations_fade_enter__WEBPACK_IMPORTED_MODULE_5__.fadeLeaveAnimation
                });
                yield loadingModal.present();
            }
        }), 0);
        var params = {};
        if (groupName != null && groupName != '')
            params = { groupName: groupName, authMethods: methods };
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request('/' + this.sourceService + '/' + this.sourceAction + '/' + AUHTENTICATE_SUB_ACTION + this.sourceAction, params).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.delay)(1000), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.map)(response => {
            if (this.loadingText) {
                // this.loadingModal.dismiss();
            }
            setTimeout(() => (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
                yield (loadingModal === null || loadingModal === void 0 ? void 0 : loadingModal.dismiss());
            }), 3000);
            return response;
        })).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.catchError)((err) => {
            hasError = true;
            setTimeout(() => (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
                yield (loadingModal === null || loadingModal === void 0 ? void 0 : loadingModal.dismiss());
            }), 0);
            return err;
        }));
        // , catchError((err, e) => {
        //     // if (err)
        //     //     throw Observable.throw(err);
        //     // else
        //     if(this.loadingText){
        //         setTimeout(()=> {
        //             // this.loadingModal.dismiss();
        //         }, 1000)
        //     }
        //     // return new ErrorObservable("");
        // })
    }
    authenticateAction(groupName, methods) {
        if (this.loadingText) {
            // this.loadingModal = this.modalCtrl.create('LoadingPage', { text: this.loadingText });
            // this.loadingModal.present();
        }
        let params = {};
        if (groupName)
            params = { groupName, authMethods: methods };
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request(`/${this.sourceService}/${this.sourceAction}/${AUHTENTICATE_SUB_ACTION}${this.sourceAction}`, params).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.map)((response) => {
            if (this.loadingText) {
                // this.loadingModal.dismiss();
            }
            return response;
        }));
    }
    generateAuthenticationToken(groupName) {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request('/' + this.sourceService + '/' + this.sourceAction + '/' + "generateTokens", { groupName: groupName });
    }
}
const Authentication2 = new AuthenticationHelper();


/***/ }),

/***/ 93221:
/*!***********************************************!*\
  !*** ./src/app/🌱models/users/group-timer.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GroupTimer": () => (/* binding */ GroupTimer)
/* harmony export */ });
class GroupTimer {
    constructor(options) { this.value = options.value; this.label = options.label; }
}


/***/ }),

/***/ 17166:
/*!*****************************************!*\
  !*** ./src/app/🌱models/users/index.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Errors": () => (/* reexport safe */ _users_model__WEBPACK_IMPORTED_MODULE_1__.Errors),
/* harmony export */   "GroupTimer": () => (/* reexport safe */ _group_timer__WEBPACK_IMPORTED_MODULE_2__.GroupTimer),
/* harmony export */   "User": () => (/* reexport safe */ _user_model__WEBPACK_IMPORTED_MODULE_0__.User),
/* harmony export */   "Users": () => (/* reexport safe */ _users_model__WEBPACK_IMPORTED_MODULE_1__.Users),
/* harmony export */   "UsersModel": () => (/* reexport safe */ _users_model__WEBPACK_IMPORTED_MODULE_1__.UsersModel)
/* harmony export */ });
/* harmony import */ var _user_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user.model */ 29065);
/* harmony import */ var _users_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./users.model */ 122);
/* harmony import */ var _group_timer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./group-timer */ 93221);





/***/ }),

/***/ 29065:
/*!**********************************************!*\
  !*** ./src/app/🌱models/users/user.model.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "User": () => (/* binding */ User)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 64139);
/* harmony import */ var _authentication__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./authentication */ 93143);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 80522);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 47418);
/* harmony import */ var _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @inma/helpers/cached */ 569);
/* harmony import */ var _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/helpers/http */ 36802);
/* harmony import */ var _inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/helpers/biometric */ 16406);
/* harmony import */ var _inma_helpers_dialogs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/helpers/dialogs */ 66695);
/* harmony import */ var _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @inma/helpers/settings */ 96892);









class User {
    constructor(data) {
        var _a;
        this.data = data;
        this.Settings = _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_5__.Settings;
        this.isIDExpired = !!((_a = this.data.customerIDExpiry) === null || _a === void 0 ? void 0 : _a.trim());
        this.isTouchIdAvailable = !!this.data.touchIdAvailable;
        this.name = this.data.userName;
        this.nameAr = this.data.userNameAr;
        this.nameEn = this.data.userNameEn;
        this.alinmaID = this.data.alinmaId;
        this.idExpiryDate = this.data.idExpiryDate;
        this.idExpiryDateHijri = this.data.idExpiryDateHijri;
        this.gender = this.data.gender;
    }
    static get isLive() {
        // TODO: this need to be chached or the DI tree to be emptied when the user logout
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request('/User/UserSubscriptions/isLiveSubscription');
    }
    biometricAuthenticate() {
        return _inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_3__.Biometric.checkBiometricUsage().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.mergeMap)(accepted => {
            if (accepted) {
                return _inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_3__.Biometric.getDeviceInfo().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.mergeMap)(deviceInfo => {
                    return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request("/TouchId/TouchIdRegistration/checkTouchIdRegistration", deviceInfo)
                        .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.mergeMap)(response => {
                        // if (response.isSuccess()) {
                        return _authentication__WEBPACK_IMPORTED_MODULE_0__.Authentication2.start("TouchId", "TouchIdRegistration", false)
                            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.mergeMap)(authenticationResponse => {
                            return _inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_3__.Biometric.save(this.username)
                                .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.mergeMap)(result => {
                                if (result)
                                    return new rxjs__WEBPACK_IMPORTED_MODULE_7__.Observable(observer => {
                                        _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_5__.Settings.setUserPreferences(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_5__.Settings.enableBiometricKey, "true");
                                        _inma_helpers_dialogs__WEBPACK_IMPORTED_MODULE_4__.Dialogs.alert(_inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_3__.Biometric.t[_inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_3__.Biometric.type + "StoreSuccess"]).subscribe(deleteOrders => {
                                        });
                                        observer.next(true);
                                    });
                            }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.catchError)(() => this.storeUserBiomentricError()));
                        }
                        // else
                        //     return this.storeUserBiomentricError();
                        ), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.catchError)(() => this.storeUserBiomentricError()));
                    }));
                }));
            }
            else
                return (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.of)(null);
        }));
    }
    storeUserBiomentricError() {
        return new rxjs__WEBPACK_IMPORTED_MODULE_7__.Observable(observer => {
            alert(_inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_3__.Biometric.t[_inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_3__.Biometric.type + "StoreError"]);
            observer.next(true);
        });
    }
    cancelUserBiometric() {
        return _inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_3__.Biometric.verify("VerifyOther").pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.mergeMap)(accepted => {
            if (accepted) {
                return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request("/TouchId/TouchIdRegistration/unregisterChannelTouchId", _inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_3__.Biometric.getDeviceUUID())
                    .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.mergeMap)(response => {
                    return _inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_3__.Biometric["delete"]()
                        .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.mergeMap)(result => {
                        if (result)
                            return new rxjs__WEBPACK_IMPORTED_MODULE_7__.Observable(observer => {
                                alert(_inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_3__.Biometric.t[_inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_3__.Biometric.type + "CancelSuccess"]);
                                observer.next(true);
                                observer.complete();
                            });
                    }));
                }));
            }
            else {
                return new rxjs__WEBPACK_IMPORTED_MODULE_7__.Observable(observer => {
                    alert(_inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_3__.Biometric.t[_inma_helpers_biometric__WEBPACK_IMPORTED_MODULE_3__.Biometric.type + "CancelError"]);
                    observer.next(false);
                    observer.complete();
                });
            }
        }));
    }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_1__.cached,
    (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__metadata)("design:type", Object),
    (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__metadata)("design:paramtypes", [])
], User, "isLive", null);


/***/ }),

/***/ 122:
/*!***********************************************!*\
  !*** ./src/app/🌱models/users/users.model.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Errors": () => (/* binding */ Errors),
/* harmony export */   "Users": () => (/* binding */ Users),
/* harmony export */   "UsersModel": () => (/* binding */ UsersModel)
/* harmony export */ });
/* harmony import */ var _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/helpers/http */ 36802);
/* harmony import */ var _authentication_authentication_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../authentication/authentication.model */ 83443);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 80522);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var _user_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./user.model */ 29065);
/* harmony import */ var _inma_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/environment */ 80960);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 66587);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var logrocket__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! logrocket */ 59923);
/* harmony import */ var logrocket__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(logrocket__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _authentication__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./authentication */ 93143);
/* harmony import */ var _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @inma/helpers/settings */ 96892);
/* harmony import */ var src_app_app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/app.component */ 20721);










class UsersModel {
    autoLogin() {
        if (_inma_environment__WEBPACK_IMPORTED_MODULE_3__.Environment.isDevelopment) {
            const credential = _inma_environment__WEBPACK_IMPORTED_MODULE_3__.Environment.autoFillCredential;
            this.login(credential === null || credential === void 0 ? void 0 : credential.username, credential === null || credential === void 0 ? void 0 : credential.password).subscribe(() => {
                console.log('Auto Login ...');
            });
        }
    }
    /**
     * @throws {Errors}
     */
    login(username, password, beforeDynamicAuth = null) {
        if (_inma_environment__WEBPACK_IMPORTED_MODULE_3__.Environment.isDevelopment && _inma_environment__WEBPACK_IMPORTED_MODULE_3__.Environment.developerComponent.remoteLogs)
            this.logRocket(username);
        return _authentication_authentication_model__WEBPACK_IMPORTED_MODULE_1__.Authentication.encrypt(password).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.mergeMap)(encryptedPassword => {
            return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request('/LoginService/Authenticate', {
                loginName: username, password: encryptedPassword
            }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.mergeMap)(result => {
                beforeDynamicAuth();
                if (!result)
                    return (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.throwError)(Errors.WrongUsernameOrPassword);
                const notFullyAuthenticatedUser = new _user_model__WEBPACK_IMPORTED_MODULE_2__.User(result);
                //! UNDO
                // notFullyAuthenticatedUser.isIDExpired = true;
                if (notFullyAuthenticatedUser.isIDExpired) {
                    src_app_app_component__WEBPACK_IMPORTED_MODULE_7__.AppComponent.ExpiredUserID = true;
                    // return throwError(Errors.ExpiredUserID);
                }
                return _authentication__WEBPACK_IMPORTED_MODULE_5__.Authentication2.start('LoginService', 'Authenticate', notFullyAuthenticatedUser.isTouchIdAvailable).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.map)(result => {
                    return new _user_model__WEBPACK_IMPORTED_MODULE_2__.User(result);
                }));
                // return unauthenticatedUser.authenticate();
            }));
        })).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.mergeMap)((user) => {
            // this.user = user;
            _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_6__.Settings.setUserPreferences('user', JSON.stringify(user)).then(() => {
                // debugger
            });
            user.username = username;
            return user.biometricAuthenticate().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.map)(() => this.user = user));
        }));
    }
    set current(user) {
        this.user = user;
    }
    get current() {
        return this.user;
    }
    logRocket(userName) {
        console.log("*** Remote logging enabled");
        logrocket__WEBPACK_IMPORTED_MODULE_4__.init('am6k3f/tadawul');
        logrocket__WEBPACK_IMPORTED_MODULE_4__.identify(userName, {
            name: userName,
            email: `${userName}@alinma.com`,
            // Add your own custom user variables here, ie:
            subscriptionType: 'pro'
        });
    }
    logout(serverSide = true) {
        this.user = null;
        if (serverSide)
            return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request('/LoginService/Logout/Logout');
        else
            return new rxjs__WEBPACK_IMPORTED_MODULE_11__.Observable((observer) => {
                observer.next(true);
                observer.complete();
            });
    }
}
var Errors;
(function (Errors) {
    Errors[Errors["WrongUsernameOrPassword"] = 0] = "WrongUsernameOrPassword";
    Errors[Errors["ExpiredUserID"] = 1] = "ExpiredUserID";
})(Errors || (Errors = {}));
const Users = new UsersModel();


/***/ }),

/***/ 66219:
/*!***********************************************!*\
  !*** ./src/environments/backends/backends.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Backends": () => (/* binding */ Backends),
/* harmony export */   "EnvironmentURLs": () => (/* binding */ EnvironmentURLs)
/* harmony export */ });
var Backends;
(function (Backends) {
    Backends[Backends["production"] = 0] = "production";
    Backends[Backends["softLaunch"] = 1] = "softLaunch";
    Backends[Backends["softLaunchDev"] = 2] = "softLaunchDev";
    Backends[Backends["preprod"] = 3] = "preprod";
    Backends[Backends["uat"] = 4] = "uat";
    Backends[Backends["sami"] = 5] = "sami";
    Backends[Backends["ahmad"] = 6] = "ahmad";
    Backends[Backends["hesham"] = 7] = "hesham";
    Backends[Backends["direct"] = 8] = "direct";
    Backends[Backends["moataz"] = 9] = "moataz";
})(Backends || (Backends = {}));
const EnvironmentURLs = {
    [Backends.production]: 'https://www.alinmatadawul.com/tadawul-smart-lite',
    [Backends.softLaunch]: 'https://www.alinmatadawul.com/alinmaTadawulSmart-V3',
    [Backends.softLaunchDev]: 'http://10.0.2.144/tadawul-smart/SmartServlet',
    //[Backends.preprod]:     'https://www.alinmatadawuluat.com/tadawulSmart-Preprod_2022_02_15/SmartServlet',
    [Backends.preprod]: 'https://www.alinmatadawuluat.com/tadawulSmart-Preprod_2022_11_17/SmartServlet',
    // [Backends.uat]:         'http://10.0.2.147/tadawul-smart-lite',
    //[Backends.uat]:         'http://10.0.2.147/tadawulSmart-96788',
    //[Backends.uat]:         'https://10.0.2.147/tadawulSmart-96788',
    //  [Backends.uat]:         'https://www.alinmatadawuluat.com/tadawulSmart',
    //[Backends.uat]:        'https://10.0.2.147/tadawulSmart-96070',
    // [Backends.uat]:          'https://www.alinmatadawuluat.com/tadawulSmart',
    [Backends.uat]: "https://www.alinmatadawuluat.com/tadawulSmart-132341/SmartServlet",
    //[Backends.uat]: "https://www.alinmatadawuluat.com/tadawulSmart-136446/SmartServlet",
    // [Backends.uat]: "https://10.0.2.147/tadawulSmart-149319/SmartServlet",
    //[Backends.uat]:        'https://10.0.2.147/tadawulSmart-102209',
    [Backends.sami]: 'https://10.0.144.121:443/tadawul-smart/SmartServlet',
    [Backends.ahmad]: 'https://10.0.144.155/tadawul-smart-127220/SmartServlet',
    [Backends.hesham]: 'http://10.0.144.60:9081/tadawul-smart',
    [Backends.direct]: 'http://10.0.2.180:9116/tadawul-smart-93166',
    [Backends.moataz]: 'https://www.alinmatadawuluat.com/tadawul-smart-93166'
};


/***/ }),

/***/ 54151:
/*!**************************************************!*\
  !*** ./src/environments/backends/credentials.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Credential": () => (/* binding */ Credential),
/* harmony export */   "Credentials": () => (/* binding */ Credentials)
/* harmony export */ });
/* harmony import */ var _backends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./backends */ 66219);

class Credential {
}
const Credentials = {
    [_backends__WEBPACK_IMPORTED_MODULE_0__.Backends.uat]: [
        {
            label: "rich",
            username: "00001279504",
            password: "Aa123456",
        },
        {
            username: "user1062",
            password: "Qq123456",
        },
        {
            username: "alolah",
            password: "Aa123456",
        },
        {
            username: "user1053",
            password: "Aa123456",
        },
        {
            username: "user1076",
            password: "Aa123456",
        },
        {
            username: "user1031",
            password: "Aa123456",
        },
        {
            username: "user1051",
            password: "Qq123456",
        },
        {
            username: "SHREEM",
            password: "ipo654321",
        },
        {
            username: "aoshaikh01",
            password: "Aa123456",
        },
        {
            username: "user1039",
            password: "Aa123456",
        },
        {
            username: "alJardan",
            password: "Aa123456",
        },
        {
            username: "maaly01",
            password: "Aa123456",
        },
        {
            username: "omar10",
            password: "Aa123456",
        }
    ],
    [_backends__WEBPACK_IMPORTED_MODULE_0__.Backends.production]: [
        // Production user credentials should never be published in the source code, but this dev environment
        {
            label: "saleh",
            username: "00000135834",
            password: "Saleh1234",
        },
        {
            username: "mustafah",
            password: "Test1234",
        },
        {
            label: "meka",
            username: "mekawy",
            password: "Meka1234",
        }
    ],
    [_backends__WEBPACK_IMPORTED_MODULE_0__.Backends.sami]: [
        {
            username: "aoshaikh01",
            password: "Aa123456",
        },
    ],
    [_backends__WEBPACK_IMPORTED_MODULE_0__.Backends.hesham]: [
        {
            username: "00001279498",
            password: "Aa123456",
        },
        {
            username: "omar10",
            password: "Aa123456",
        }
    ],
    [_backends__WEBPACK_IMPORTED_MODULE_0__.Backends.preprod]: [
        // {
        //   username: 'aoshaikh01',
        //   password: 'Aa123456'
        // },
        {
            username: "user1031",
            password: "Aa123456",
        },
        // {
        //   username: '10002474',
        //   password: 'Aa123456'
        // }
        {
            username: "SHREEM",
            password: "ipo654321",
        },
        {
            username: "maaly01",
            password: "Aa123456",
        },
        // {
        //   username: 'Huda01',
        //   password: 'Aa123456'
        // },
        // {
        //   username: 'user65792',
        //   password: 'Aa123456'
        // },
        {
            username: "user1039",
            password: "Aa123456",
        },
        // {
        //   username: '1279724',
        //   password: 'Aa123456'
        // },
        {
            username: "user1031",
            password: "Aa123456",
        },
        {
            username: "00001279504",
            password: "Aa123456",
        },
    ],
    [_backends__WEBPACK_IMPORTED_MODULE_0__.Backends.direct]: [
        {
            username: "user1039",
            password: "Aa123456",
        },
    ]
};


/***/ }),

/***/ 23923:
/*!********************************************!*\
  !*** ./src/environments/backends/index.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Backends": () => (/* reexport safe */ _backends__WEBPACK_IMPORTED_MODULE_0__.Backends),
/* harmony export */   "EnvironmentURLs": () => (/* reexport safe */ _backends__WEBPACK_IMPORTED_MODULE_0__.EnvironmentURLs)
/* harmony export */ });
/* harmony import */ var _backends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./backends */ 66219);



/***/ }),

/***/ 78272:
/*!***************************************************!*\
  !*** ./src/environments/base/environment.base.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Encryptions": () => (/* binding */ Encryptions),
/* harmony export */   "Environment": () => (/* binding */ Environment),
/* harmony export */   "EnvironmentConfigBase": () => (/* binding */ EnvironmentConfigBase),
/* harmony export */   "Environments": () => (/* binding */ Environments)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _inma_helpers_strings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/helpers/strings */ 36782);
/* harmony import */ var _backends_backends__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../backends/backends */ 66219);
/* harmony import */ var _package_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../package.json */ 4147);
/* harmony import */ var _backends_credentials__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../backends/credentials */ 54151);



// @ts-ignore


var Environments;
(function (Environments) {
    Environments[Environments["development"] = 0] = "development";
    Environments[Environments["production"] = 1] = "production";
    Environments[Environments["testing"] = 2] = "testing";
})(Environments || (Environments = {}));
var Encryptions;
(function (Encryptions) {
    Encryptions[Encryptions["Standard"] = 0] = "Standard";
    Encryptions[Encryptions["RSA"] = 1] = "RSA";
})(Encryptions || (Encryptions = {}));
class EnvironmentConfigBase {
    constructor() {
        this.http = {
            timeout: 120000,
            native: false,
            presentErrors: false
        };
        this.streaming = {
            enabled: true
        };
        this.developerComponent = {
            enabled: true,
            remoteLogs: false
        };
        this.watermark = {
            enabled: true,
            buildVersion: ''
        };
        this.mocking = {
            // latency: { min: 200, max: 300 },
            enabled: false,
            mocks: [],
            biometric: {
                enabled: false,
                verifyPeriod: 10 * 1000
            }
        };
        this.translations = {
            showMissing: false
        };
        this.logging = {
            ajax: false,
            streaming: {
                server: false,
                channels: false
            }
        };
    }
}
class Environment extends EnvironmentConfigBase {
    constructor(env, options) {
        super();
        this.logging = {
            ajax: true,
            streaming: {
                server: false,
                channels: false
            }
        };
        this.type = env;
        this.name = Environments[env].toString();
        const { type } = options, safeOptions = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__rest)(options, ["type"]); // exclude type if by mistake were sent
        // Set appVersion
        safeOptions.appVersion = safeOptions.appVersion || (_package_json__WEBPACK_IMPORTED_MODULE_2__ === null || _package_json__WEBPACK_IMPORTED_MODULE_2__ === void 0 ? void 0 : _package_json__WEBPACK_IMPORTED_MODULE_2__.version);
        Object.assign(this, safeOptions);
    }
    get isDevelopment() {
        return this.type === Environments.development;
    }
    get isProduction() {
        return this.type === Environments.production;
    }
    get isTest() {
        return this.type === Environments.testing;
    }
    // This is different as it checks for the value, and raise meaningful exceptions
    getBackend() {
        if (this.backend == null)
            console.error('No backend parameter is provided in the environment !');
        if (typeof this.backend === 'string')
            return _backends_backends__WEBPACK_IMPORTED_MODULE_1__.Backends.uat;
        else
            return this.backend;
    }
    get isBiometricMockingEnabled() {
        var _a, _b, _c;
        return this.isDevelopment && ((_a = this.mocking) === null || _a === void 0 ? void 0 : _a.enabled) && ((_c = (_b = this.mocking) === null || _b === void 0 ? void 0 : _b.biometric) === null || _c === void 0 ? void 0 : _c.enabled);
    }
    get isLoggingEnabled() {
        if (typeof this.logging == 'boolean') {
            return this.logging;
        }
        else {
            return true;
        }
    }
    get isLoggingAjaxEnabled() {
        var _a;
        if (this.isLoggingEnabled)
            return (_a = this.logging) === null || _a === void 0 ? void 0 : _a.ajax;
        return false;
    }
    get isLoggingStreamingEnabled() {
        var _a, _b;
        if (this.isLoggingEnabled) {
            if (typeof ((_a = this.logging) === null || _a === void 0 ? void 0 : _a.streaming) == 'boolean')
                return (_b = this.logging) === null || _b === void 0 ? void 0 : _b.streaming;
            else
                return true;
        }
        return false;
    }
    get isLoggingStreamingServerEnabled() {
        var _a, _b;
        if (this.isLoggingStreamingEnabled) {
            return (_b = (_a = this.logging) === null || _a === void 0 ? void 0 : _a.streaming) === null || _b === void 0 ? void 0 : _b.server;
        }
        return false;
    }
    get isLoggingStreamingChannelsEnabled() {
        var _a, _b;
        if (this.isLoggingStreamingEnabled) {
            return (_b = (_a = this.logging) === null || _a === void 0 ? void 0 : _a.streaming) === null || _b === void 0 ? void 0 : _b.channels;
        }
        return false;
    }
    get biometricMockingPeriod() {
        var _a, _b, _c;
        return this.isDevelopment && ((_a = this.mocking) === null || _a === void 0 ? void 0 : _a.enabled) && ((_c = (_b = this.mocking) === null || _b === void 0 ? void 0 : _b.biometric) === null || _c === void 0 ? void 0 : _c.verifyPeriod);
    }
    getSiblingBackend() {
        const backend = this.getBackend();
        if (backend == _backends_backends__WEBPACK_IMPORTED_MODULE_1__.Backends.softLaunch)
            return _backends_backends__WEBPACK_IMPORTED_MODULE_1__.Backends.production;
        else if (backend == _backends_backends__WEBPACK_IMPORTED_MODULE_1__.Backends.production)
            return _backends_backends__WEBPACK_IMPORTED_MODULE_1__.Backends.softLaunch;
        else
            return _backends_backends__WEBPACK_IMPORTED_MODULE_1__.Backends.uat;
    }
    get autoFillCredential() {
        var _a, _b;
        try {
            if (this.autoFill === true) {
                let backendCredentials = _backends_credentials__WEBPACK_IMPORTED_MODULE_3__.Credentials[this.getBackend()];
                debugger;
                if (!backendCredentials)
                    backendCredentials = _backends_credentials__WEBPACK_IMPORTED_MODULE_3__.Credentials[_backends_backends__WEBPACK_IMPORTED_MODULE_1__.Backends.uat];
                // Math.random() return a random number between 0 (inclusive) and 1 (exclusive)
                const i = Math.floor(Math.random() * backendCredentials.length);
                const credential = backendCredentials[i];
                return credential;
            }
            else if (this.autoFill['enabled'] !== false) {
                const autoFill = this.autoFill;
                if (typeof this.autoFill === 'object') {
                    this.autoFill = (_a = (autoFill[_backends_backends__WEBPACK_IMPORTED_MODULE_1__.Backends[this.getBackend()]] || autoFill[_backends_backends__WEBPACK_IMPORTED_MODULE_1__.Backends[this.getSiblingBackend()]] || autoFill['any'])) === null || _a === void 0 ? void 0 : _a.trim();
                }
                if (this.autoFill && typeof this.autoFill === 'string') {
                    const credentials = _backends_credentials__WEBPACK_IMPORTED_MODULE_3__.Credentials[this.getBackend()];
                    // Search credentials for that backend and UAT
                    for (const userCredentials of [...(_backends_credentials__WEBPACK_IMPORTED_MODULE_3__.Credentials[this.getBackend()] || []), ..._backends_credentials__WEBPACK_IMPORTED_MODULE_3__.Credentials[_backends_backends__WEBPACK_IMPORTED_MODULE_1__.Backends.uat], ..._backends_credentials__WEBPACK_IMPORTED_MODULE_3__.Credentials[_backends_backends__WEBPACK_IMPORTED_MODULE_1__.Backends.production]]) {
                        if (_inma_helpers_strings__WEBPACK_IMPORTED_MODULE_0__.Strings.indexOf(userCredentials.username.toLowerCase(), this.autoFill.toLowerCase()) >= 0) {
                            return userCredentials;
                        }
                        if (userCredentials.label && _inma_helpers_strings__WEBPACK_IMPORTED_MODULE_0__.Strings.indexOf((_b = userCredentials.label) === null || _b === void 0 ? void 0 : _b.toLowerCase(), this.autoFill.toLowerCase()) >= 0) {
                            return userCredentials;
                        }
                    }
                    console.error(`No matched username found in the Credentials[${this.getBackend()}] contains '${this.autoFill}'`);
                }
            }
        }
        catch (_c) { }
        return null;
    }
    get baseURL() {
        let URL;
        if (this.isDevelopment) {
            if (typeof this.backend === 'string')
                URL = this.backend;
            else
                URL = _backends_backends__WEBPACK_IMPORTED_MODULE_1__.EnvironmentURLs[this.getBackend()];
        }
        else if (this.isProduction)
            URL = _backends_backends__WEBPACK_IMPORTED_MODULE_1__.EnvironmentURLs[_backends_backends__WEBPACK_IMPORTED_MODULE_1__.Backends.production];
        else
            URL = _backends_backends__WEBPACK_IMPORTED_MODULE_1__.EnvironmentURLs[this.getBackend()];
        const regex = /(.*)\/SmartServlet$/gi;
        const result = regex.exec(URL.trim());
        if (result)
            URL = result[1];
        return URL;
    }
    get webserviceURL() {
        return `${this.baseURL}/SmartServlet`;
    }
    get streamingURL() {
        return `${this.baseURL}/cometd`;
    }
    get hostURL() {
        var matches = this.baseURL.match(/^((https?\:\/\/)?[^\/?#]+)(?:[\/?#]|$)/i);
        var domain = matches && matches[1]; // domain will be null if no match is found
        return domain;
    }
}


/***/ }),

/***/ 80960:
/*!*********************************************!*\
  !*** ./src/environments/dev.environment.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Environment": () => (/* binding */ Environment)
/* harmony export */ });
/* harmony import */ var _base_environment_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base/environment.base */ 78272);
/* harmony import */ var _environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environment */ 24766);


const Environment = new _base_environment_base__WEBPACK_IMPORTED_MODULE_0__.Environment(_base_environment_base__WEBPACK_IMPORTED_MODULE_0__.Environments.development, new _environment__WEBPACK_IMPORTED_MODULE_1__.EnvironmentConfig());


/***/ }),

/***/ 24766:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EnvironmentConfig": () => (/* binding */ EnvironmentConfig)
/* harmony export */ });
/* harmony import */ var _base_environment_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base/environment.base */ 78272);
/* harmony import */ var _backends__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./backends */ 23923);


class EnvironmentConfig extends _base_environment_base__WEBPACK_IMPORTED_MODULE_0__.EnvironmentConfigBase {
    constructor() {
        super(...arguments);
        // *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        this.name = 'Development';
        // *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        this.appVersion = '3.0.4';
        // * If not set it will use version from package.json
        // *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        this.backend = _backends__WEBPACK_IMPORTED_MODULE_1__.Backends.softLaunch;
        // * use values of `enum Backends` or put directly backend URL
        // *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        this.autoFill = { production: 'meka', uat: 'alolah', enabled: false };
        // * use { production: 'saleh', uat: 'rich' } , production & softLaunch are sibling environments, all other environments are sibling to uat environment
        // * use `true`, it will randomly select username and password
        // * use `string` and it will use the first credentail that contains that string in its username or label
        // * use `false`, auto fill will be disabled
        // *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        this.http = {
            native: true,
            timeout: 2 * 60 * 1000,
            presentErrors: false
        };
        // * timeout in milliseconds
        // * use `string` and it will use the first credentail that contains that string
        // * use `false`, auto fill will be disabled
        // *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        this.encryption = _base_environment_base__WEBPACK_IMPORTED_MODULE_0__.Encryptions.Standard;
        // * encrypting password or not ?
        // *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        this.streaming = {
            enabled: true
        };
        // *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        this.developerComponent = {
            enabled: false,
            remoteLogs: false
        };
        // *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        this.watermark = {
            enabled: false,
            buildVersion: '10Mar2021, 4:30PM'
        };
        // *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        this.logging = {
            ajax: false,
            streaming: {
                server: false,
                channels: false
            }
        };
        // *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        this.mocking = {
            enabled: false,
            biometric: {
                enabled: true,
                // * enable to see dynamic biometric/authentication page on Chrome
                verifyPeriod: 1000 * 1000
                // * artificial time to close biometric page after, like it was successfully verified by face/fingerprint
            },
            mocks: [
            // '/customerSupport/CustomerSupport/loadAICContactSubjects',
            // '/customerSupport/CustomerSupport/contactAlinmaInvestment',
            // '/Portfolio/OutstandingOrders/loadOrders',
            // '/Portfolio/ManageOrders/buy',
            // '/Portfolio/ManageOrders/sell',
            // '/portfolio/MyPortfolios/getMFPortfolioPosition',       // Get Portfolio MutualFunds
            // '/Portfolio/MyPortfolios/loadAdvancedTradeSecurityList',
            // '/Portfolio/MyPortfolios/loadPortfolios',
            // '/MutualFunds/MutualFundsService/getAlinmaMutualFunds',
            // '/Market/MarketDepthService/getMarketDepth',
            // '/accounts/FundTransfers/checkFundTransfer',
            // '/ForgetPassword/ForgetPassword/changePassword'
            ]
        };
        // *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        this.translations = {
            showMissing: false
        };
        // *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        // startPage = 'dynamic-authentication';
        // * help to redirect you after login (in development mode only) to the page you are developing to save time
        // *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        this.labs = {
            enabled: false,
            streamingInstablity: false
        };
        // Add any experimental features in here
        // *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    }
}
// To disable native SSL checks https://stackoverflow.com/a/57811110


/***/ }),

/***/ 92020:
/*!***********************************!*\
  !*** ./src/environments/index.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Environment": () => (/* reexport safe */ _dev_environment__WEBPACK_IMPORTED_MODULE_0__.Environment)
/* harmony export */ });
/* harmony import */ var _dev_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dev.environment */ 80960);



/***/ }),

/***/ 84110:
/*!********************************************************!*\
  !*** ./src/environments/mocks/authentication.mocks.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthenticationMocks": () => (/* binding */ AuthenticationMocks)
/* harmony export */ });
const AuthenticationMocks = {
    '/LoginService/Authenticate': {
        "status": "1",
        "msg": {
            "msgCode": "I000000",
            "msgType": "I",
            "msgText": ""
        },
        "result": {
            "tokenAuth": true, "customerIDExpiry": "", "userName": null, "touchIdAvailable": true, "alinmaId": null
        }
    },
    '/LoginService/Authenticate/confirmAuthenticate': { "status": "1", "msg": { "msgCode": "I000000", "msgType": "I", "msgText": "" }, "result": { "numOfGrps": 2, "groups": [{ "groupName": "1", "methods": [{ "methodName": "MOBILE_TOKEN", "order": 0, "type": null, "value": null, "methodLabel": "رمز التفعيل" }], "note": ["شريكنا العزيز: للدخول على تطبيق تداول الإنماء, فضلا أدخل رمز التفعيل الذي سيصلك برسالة على جوالك المسجل لدى شركة الإنماء للإستثمار ", "xxxxxxxx6112"], "timer": { "label": "الوقت المتبقي لانتهاء المدة المسموحه لإدخال رمز التفعيل:", "value": 300 }, "numOfTrials": 3, "groupDescription": "عبر رسالة نصية" }, { "groupName": "3", "methods": [{ "methodName": "TOUCH_ID_HASH_KEY", "order": 0, "type": null, "value": null, "methodLabel": "البصمة" }], "note": ["شريكنا العزيز: للدخول على تطبيق تداول الإنماء, فضلا أدخل رمز التفعيل الذي سيصلك برسالة على جوالك المسجل لدى شركة الإنماء للإستثمار ", "xxxxxxxx6112"], "timer": { "label": "الوقت المتبقي لانتهاء المدة المسموحه لإدخال رمز التفعيل:", "value": 300 }, "numOfTrials": 3, "groupDescription": "البصمة" }] } },
    '/LoginService/Authenticate/generateTokens': { "status": "1", "msg": { "msgCode": "I000000", "msgType": "I", "msgText": "" }, "result": { "numOfGrps": 2, "groups": [{ "groupName": "1", "methods": [{ "methodName": "MOBILE_TOKEN", "order": 0, "type": null, "value": null, "methodLabel": "رمز التفعيل" }], "note": ["شريكنا العزيز: للدخول على تطبيق تداول الإنماء, فضلا أدخل رمز التفعيل الذي سيصلك برسالة على جوالك المسجل لدى شركة الإنماء للإستثمار ", "xxxxxxxx6112"], "timer": { "label": "الوقت المتبقي لانتهاء المدة المسموحه لإدخال رمز التفعيل:", "value": 300 }, "numOfTrials": 3, "groupDescription": "عبر رسالة نصية" }, { "groupName": "3", "methods": [{ "methodName": "TOUCH_ID_HASH_KEY", "order": 0, "type": null, "value": null, "methodLabel": "البصمة" }], "note": ["شريكنا العزيز: للدخول على تطبيق تداول الإنماء, فضلا أدخل رمز التفعيل الذي سيصلك برسالة على جوالك المسجل لدى شركة الإنماء للإستثمار ", "xxxxxxxx6112"], "timer": { "label": "الوقت المتبقي لانتهاء المدة المسموحه لإدخال رمز التفعيل:", "value": 300 }, "numOfTrials": 3, "groupDescription": "البصمة" }] } },
    '/LoginService/Authenticate/authenticateAuthenticate': { "status": "1", "msg": { "msgCode": "I000000", "msgType": "I", "msgText": "" }, "result": { "tokenAuth": null, "customerIDExpiry": null, "userName": "مصطفى البنا", "touchIdAvailable": true, "alinmaId": "00000222933" } }
};


/***/ }),

/***/ 74625:
/*!*********************************************************!*\
  !*** ./src/environments/mocks/change-password.mocks.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChangePasswordMockedWebService": () => (/* binding */ ChangePasswordMockedWebService)
/* harmony export */ });
const ChangePasswordMockedWebService = {
    '/ForgetPassword/ForgetPassword/changePassword': {
        'status': "1",
        'msg': {
            'msgCode': 'I000000',
            'msgText': 'Success',
            'msgType': 'I'
        },
        'result': {}
    }
};


/***/ }),

/***/ 25760:
/*!*************************************************!*\
  !*** ./src/environments/mocks/contact.mocks.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ContactMockedWebService": () => (/* binding */ ContactMockedWebService)
/* harmony export */ });
const ContactMockedWebService = {
    '/customerSupport/CustomerSupport/loadAICContactSubjects': {
        'status': "1",
        'msg': null,
        'result': [{ "id": "COMPLAIN", "value": "شكوى" }, { "id": "SUGGESTION", "value": "اقتراح" }, { "id": "OTHER", "value": "أخرى" }]
    },
    '/customerSupport/CustomerSupport/contactAlinmaInvestment': {
        "status": "1",
        "msg": {
            "msgCode": null,
            "msgType": null,
            "msgText": "شكرا لتواصلك معنا، يسرنا في الإنماء للإستثمار متابعة مقترحات وشكاوى عملائنا."
        },
        "result": null
    }
};


/***/ }),

/***/ 94474:
/*!*****************************************!*\
  !*** ./src/environments/mocks/mocks.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MockedWebService": () => (/* binding */ MockedWebService)
/* harmony export */ });
/* harmony import */ var _portfolios_mocks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./portfolios.mocks */ 15122);
/* harmony import */ var _mutual_funds_mocks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mutual-funds.mocks */ 12136);
/* harmony import */ var _orders_mocks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./orders.mocks */ 52475);
/* harmony import */ var _symbols_mocks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./symbols.mocks */ 73442);
/* harmony import */ var _transfers_mocks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./transfers.mocks */ 63093);
/* harmony import */ var _contact_mocks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./contact.mocks */ 25760);
/* harmony import */ var _change_password_mocks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./change-password.mocks */ 74625);
/* harmony import */ var _authentication_mocks__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./authentication.mocks */ 84110);
// import { LoginMockedWebService } from "./mocked/login.mocked.environment";
// import { WatchlistsMockedWebService } from "./mocked/watchlists.mocked.environment";
// import { OrdersMockedWebService } from "./mocked/orders.mocked.environment";
// import { TransfersMockedWebService } from "./mocked/transfers.mocked.environment";
// import { SymbolsMockedWebService } from "./mocked/symbols.mocked.environment";
// import { ForgetUsernamePassword } from "./mocked/forget-user-pass.mocked.environment"
// import { MarketMockedWebService } from "./mocked/market.mocked.environment";
// import { UserMockedWebService } from "./mocked/user.mocked.environment";
// import { PortfoliosMockedWebService } from "./mocked/portfolios.mocked.environment";
// import { MutualFundsMockedWebService } from "./mocked/mutual-funds.mocked.environment";








const MockedWebService = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, _authentication_mocks__WEBPACK_IMPORTED_MODULE_7__.AuthenticationMocks), _symbols_mocks__WEBPACK_IMPORTED_MODULE_3__.SymbolsMockedWebService), _orders_mocks__WEBPACK_IMPORTED_MODULE_2__.OrdersMockedWebService), _transfers_mocks__WEBPACK_IMPORTED_MODULE_4__.TransfersMockedWebService), _portfolios_mocks__WEBPACK_IMPORTED_MODULE_0__.PortfoliosMockedWebService), _mutual_funds_mocks__WEBPACK_IMPORTED_MODULE_1__.MutualFundsMockedWebService), _contact_mocks__WEBPACK_IMPORTED_MODULE_5__.ContactMockedWebService), _change_password_mocks__WEBPACK_IMPORTED_MODULE_6__.ChangePasswordMockedWebService);


/***/ }),

/***/ 12136:
/*!******************************************************!*\
  !*** ./src/environments/mocks/mutual-funds.mocks.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MutualFundsMockedWebService": () => (/* binding */ MutualFundsMockedWebService)
/* harmony export */ });
var MutualFundsMockedWebService = {
    // Get mutual funds
    '/MutualFunds/MutualFundsService/getAlinmaMutualFunds': {
        "status": "1", "msg": null, "result": [{
                "id": "222222-000", "type": "MF", "nameEn": "ALINMA SAR LIQUIDITY FUND", "nameAr": "الإنماء للسيولة بالريال السعودي",
                "units": {
                    "currencyCode": null,
                    "currencyRate": null,
                    "amount": "566.431753",
                    "formatedAmount": null,
                    "localAmount": null
                },
                "minSubscriptionLimit": { "currencyCode": null, "currencyRate": null, "amount": "5000", "formatedAmount": null, "localAmount": null }, "unitPrice": { "currencyCode": null, "currencyRate": null, "amount": "53.579073", "formatedAmount": null, "localAmount": null }, "change": { "currencyCode": null, "currencyRate": null, "amount": "2.074845", "formatedAmount": null, "localAmount": null }, "shortName": null, "objectiveEn": null, "objectiveAr": null, "amount": null, "percentage": null, "evaluationDaysEn": null, "evaluationDaysAr": null, "category": null, "classification": null, "inceptionPrice": null, "subCategory": null, "benchmarkEn": null, "benchmarkAr": null, "subscriptionFees": null, "subscriptionFeesType": null, "manageFees": null, "manageFeesType": null, "custodyFees": null, "custodyFeesType": null, "redemptionFees": null, "redemptionFeesType": null, "earlyRedemptionFees": null, "earlyRedemptionFeesType": null, "earlyRedemptionFeesPolicy": null, "otherFees": null, "otherFeesType": null, "riskLevel": null, "marketsEn": null, "marketsAr": null, "minAdditionalSbscrptnLimit": null, "minHoldingLimit": null, "minRdmptnInd": null, "minRdmptnAmountLimit": null, "minRdmptnUnitsLimit": null, "settlementDays": null, "strategyEn": null, "strategyAr": null, "currency": { "code": "SAR" }, "valuationDate": { "gregorianDate": "Dec 24, 2017 12:00:00 AM", "hijriDate": null, "time": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "inceptionDate": null, "lastDateForReceiptOrders": null, "lastUpdateDate": null, "amountMinRedemptionInd": false
            }, { "id": "444444-000", "type": "MF", "nameEn": "Alinma Multi Assets Balanced Fund", "nameAr": "صندوق الإنماء المتوازن متعدد الأصول", "minSubscriptionLimit": { "currencyCode": null, "currencyRate": null, "amount": "5000", "formatedAmount": null, "localAmount": null }, "unitPrice": { "currencyCode": null, "currencyRate": null, "amount": "1.260099", "formatedAmount": null, "localAmount": null }, "change": { "currencyCode": null, "currencyRate": null, "amount": "-88.793385", "formatedAmount": null, "localAmount": null }, "shortName": null, "objectiveEn": null, "objectiveAr": null, "amount": null, "percentage": null, "evaluationDaysEn": null, "evaluationDaysAr": null, "category": null, "classification": null, "inceptionPrice": null, "subCategory": null, "benchmarkEn": null, "benchmarkAr": null, "subscriptionFees": null, "subscriptionFeesType": null, "manageFees": null, "manageFeesType": null, "custodyFees": null, "custodyFeesType": null, "redemptionFees": null, "redemptionFeesType": null, "earlyRedemptionFees": null, "earlyRedemptionFeesType": null, "earlyRedemptionFeesPolicy": null, "otherFees": null, "otherFeesType": null, "riskLevel": null, "marketsEn": null, "marketsAr": null, "minAdditionalSbscrptnLimit": null, "minHoldingLimit": null, "minRdmptnInd": null, "minRdmptnAmountLimit": null, "minRdmptnUnitsLimit": null, "settlementDays": null, "strategyEn": null, "strategyAr": null, "currency": { "code": "SAR" }, "valuationDate": { "gregorianDate": "Feb 12, 2014 12:00:00 AM", "hijriDate": null, "time": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "inceptionDate": null, "lastDateForReceiptOrders": null, "lastUpdateDate": null, "amountMinRedemptionInd": false }, { "id": "555555-000", "type": "MF", "nameEn": "Alinma multi Assets Defensive Fund", "nameAr": "صندوق الإنماء المتحفظ متعدد الأصول", "minSubscriptionLimit": { "currencyCode": null, "currencyRate": null, "amount": "1000", "formatedAmount": null, "localAmount": null }, "unitPrice": { "currencyCode": null, "currencyRate": null, "amount": "10.757342", "formatedAmount": null, "localAmount": null }, "change": { "currencyCode": null, "currencyRate": null, "amount": "1.450564", "formatedAmount": null, "localAmount": null }, "shortName": null, "objectiveEn": null, "objectiveAr": null, "amount": null, "percentage": null, "evaluationDaysEn": null, "evaluationDaysAr": null, "category": null, "classification": null, "inceptionPrice": null, "subCategory": null, "benchmarkEn": null, "benchmarkAr": null, "subscriptionFees": null, "subscriptionFeesType": null, "manageFees": null, "manageFeesType": null, "custodyFees": null, "custodyFeesType": null, "redemptionFees": null, "redemptionFeesType": null, "earlyRedemptionFees": null, "earlyRedemptionFeesType": null, "earlyRedemptionFeesPolicy": null, "otherFees": null, "otherFeesType": null, "riskLevel": null, "marketsEn": null, "marketsAr": null, "minAdditionalSbscrptnLimit": null, "minHoldingLimit": null, "minRdmptnInd": null, "minRdmptnAmountLimit": null, "minRdmptnUnitsLimit": null, "settlementDays": null, "strategyEn": null, "strategyAr": null, "currency": { "code": "SAR" }, "valuationDate": { "gregorianDate": "Feb 12, 2014 12:00:00 AM", "hijriDate": null, "time": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "inceptionDate": null, "lastDateForReceiptOrders": null, "lastUpdateDate": null, "amountMinRedemptionInd": false }, { "id": "777777-000", "type": "MF", "nameEn": "Alinma IPO FUND", "nameAr": "صندوق الإنماء للإصدارات الأولية", "minSubscriptionLimit": { "currencyCode": null, "currencyRate": null, "amount": "5000", "formatedAmount": null, "localAmount": null }, "unitPrice": { "currencyCode": null, "currencyRate": null, "amount": "10.481635", "formatedAmount": null, "localAmount": null }, "change": { "currencyCode": null, "currencyRate": null, "amount": "0.000000", "formatedAmount": null, "localAmount": null }, "shortName": null, "objectiveEn": null, "objectiveAr": null, "amount": null, "percentage": null, "evaluationDaysEn": null, "evaluationDaysAr": null, "category": null, "classification": null, "inceptionPrice": null, "subCategory": null, "benchmarkEn": null, "benchmarkAr": null, "subscriptionFees": null, "subscriptionFeesType": null, "manageFees": null, "manageFeesType": null, "custodyFees": null, "custodyFeesType": null, "redemptionFees": null, "redemptionFeesType": null, "earlyRedemptionFees": null, "earlyRedemptionFeesType": null, "earlyRedemptionFeesPolicy": null, "otherFees": null, "otherFeesType": null, "riskLevel": null, "marketsEn": null, "marketsAr": null, "minAdditionalSbscrptnLimit": null, "minHoldingLimit": null, "minRdmptnInd": null, "minRdmptnAmountLimit": null, "minRdmptnUnitsLimit": null, "settlementDays": null, "strategyEn": null, "strategyAr": null, "currency": { "code": "SAR" }, "valuationDate": { "gregorianDate": "Jul 5, 2015 12:00:00 AM", "hijriDate": null, "time": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "inceptionDate": null, "lastDateForReceiptOrders": null, "lastUpdateDate": null, "amountMinRedemptionInd": false }, { "id": "999916-000", "type": "CF", "nameEn": "Alinma Wareef Endowment Fund", "nameAr": "صندوق الإنماء وريف الوقفي", "minSubscriptionLimit": { "currencyCode": null, "currencyRate": null, "amount": "100", "formatedAmount": null, "localAmount": null }, "unitPrice": { "currencyCode": null, "currencyRate": null, "amount": "15", "formatedAmount": null, "localAmount": null }, "change": { "currencyCode": null, "currencyRate": null, "amount": "-100.000000", "formatedAmount": null, "localAmount": null }, "shortName": null, "objectiveEn": null, "objectiveAr": null, "amount": null, "percentage": null, "evaluationDaysEn": null, "evaluationDaysAr": null, "category": null, "classification": null, "inceptionPrice": null, "subCategory": null, "benchmarkEn": null, "benchmarkAr": null, "subscriptionFees": null, "subscriptionFeesType": null, "manageFees": null, "manageFeesType": null, "custodyFees": null, "custodyFeesType": null, "redemptionFees": null, "redemptionFeesType": null, "earlyRedemptionFees": null, "earlyRedemptionFeesType": null, "earlyRedemptionFeesPolicy": null, "otherFees": null, "otherFeesType": null, "riskLevel": null, "marketsEn": null, "marketsAr": null, "minAdditionalSbscrptnLimit": null, "minHoldingLimit": null, "minRdmptnInd": null, "minRdmptnAmountLimit": null, "minRdmptnUnitsLimit": null, "settlementDays": null, "strategyEn": null, "strategyAr": null, "currency": { "code": "SAR" }, "valuationDate": { "gregorianDate": "Aug 14, 2018 12:00:00 AM", "hijriDate": null, "time": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "inceptionDate": null, "lastDateForReceiptOrders": null, "lastUpdateDate": null, "amountMinRedemptionInd": false }]
    },
    '/MutualFunds/MutualFundsService/getMutualFundDetails': { "status": "1", "msg": null, "result": [{ "id": "111111-000", "type": "CHF", "nameEn": "ALINMA SAUDI EQUITY FUND", "nameAr": "صندوق الانماء للاسهم السعوديه", "minSubscriptionLimit": { "currencyCode": null, "currencyRate": null, "amount": "5000", "formatedAmount": null, "localAmount": null }, "unitPrice": { "currencyCode": null, "currencyRate": null, "amount": "15.308533", "formatedAmount": null, "localAmount": null }, "change": { "currencyCode": null, "currencyRate": null, "amount": "4.212274", "formatedAmount": null, "localAmount": null }, "shortName": null, "objectiveEn": "Long-term investment, in the Saudi stock", "objectiveAr": "استثمار طويل المدى بغرض تنمية رأس المال", "amount": null, "percentage": null, "evaluationDaysEn": "Monday and wednesday", "evaluationDaysAr": "يوم الاثنين ويوم الاربعاء", "category": null, "classification": null, "inceptionPrice": { "currencyCode": null, "currencyRate": null, "amount": "10", "formatedAmount": null, "localAmount": null }, "subCategory": null, "benchmarkEn": "Alinma Saudi Islamic Index, by Ideal Ratings", "benchmarkAr": "???? ??????? ?????? ???????? ????? ?????", "subscriptionFees": { "currencyCode": null, "currencyRate": null, "amount": "1.5", "formatedAmount": null, "localAmount": null }, "subscriptionFeesType": "PERCENTAGE", "manageFees": "1.75", "manageFeesType": "PERCENTAGE", "custodyFees": { "currencyCode": null, "currencyRate": null, "amount": "0.03", "formatedAmount": null, "localAmount": null }, "custodyFeesType": "PERCENTAGE", "redemptionFees": { "currencyCode": null, "currencyRate": null, "amount": "0", "formatedAmount": null, "localAmount": null }, "redemptionFeesType": null, "earlyRedemptionFees": { "currencyCode": null, "currencyRate": null, "amount": "0", "formatedAmount": null, "localAmount": null }, "earlyRedemptionFeesType": null, "earlyRedemptionFeesPolicy": "0D", "otherFees": { "currencyCode": null, "currencyRate": null, "amount": "104875.00", "formatedAmount": null, "localAmount": null }, "otherFeesType": "VALUE", "riskLevel": null, "marketsEn": "Saudi Market", "marketsAr": "السوق السعودي", "minAdditionalSbscrptnLimit": { "currencyCode": null, "currencyRate": null, "amount": "1000", "formatedAmount": null, "localAmount": null }, "minHoldingLimit": { "currencyCode": null, "currencyRate": null, "amount": "500", "formatedAmount": null, "localAmount": null }, "minRdmptnInd": "UNITS", "minRdmptnAmountLimit": null, "minRdmptnUnitsLimit": { "currencyCode": null, "currencyRate": null, "amount": "100", "formatedAmount": null, "localAmount": null }, "settlementDays": "3", "strategyEn": "Capital growth through long term", "strategyAr": "نمو رأس المال على المدى الطويل", "currency": { "code": "SAR" }, "valuationDate": { "gregorianDate": "Dec 26, 2018 12:00:00 AM", "hijriDate": null, "time": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "inceptionDate": { "gregorianDate": "Dec 15, 2010 12:00:00 AM", "hijriDate": null, "time": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "lastDateForReceiptOrders": { "gregorianDate": null, "hijriDate": null, "time": "04:00:00 PM", "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "lastUpdateDate": null, "amountMinRedemptionInd": false }] }
};


/***/ }),

/***/ 52475:
/*!************************************************!*\
  !*** ./src/environments/mocks/orders.mocks.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrdersMockedWebService": () => (/* binding */ OrdersMockedWebService)
/* harmony export */ });
const OrdersMockedWebService = {
    // Make a buy order
    '/Portfolio/ManageOrders/buy': 
    // params: {
    //  'symbolId': "1010",       // Use '/Portfolio/ManageOrders/loadSecurities'
    //  'portfolioId': "65301-1", // Use '/Portfolio/BuyingPower/loadPortfolioNumbers'
    //  'orderTypeId': "1",       // Use '/Portfolio/ManageOrders/loadOrderTypes'
    //  'tifTypeId': "2",
    //  'price': "",
    //  'quantity': "10",
    //  'disclosedQuantity':"",
    //  'endDate': ""             // Send any date format
    // }
    {
        'status': "1",
        'msg': {
            'msgCode': null,
            'msgType': null,
            'msgText': "Operation Done successfully , order Id 18087Q5N5P"
        },
        'result': "18087Q5N5P"
    },
    // Make a sell order
    '/Portfolio/ManageOrders/sell': 
    // params: {
    //  'symbolId': "1010",       // Use '/Portfolio/ManageOrders/loadSecurities'
    //  'portfolioId': "65301-1", // Use '/Portfolio/BuyingPower/loadPortfolioNumbers'
    //  'orderTypeId': "1",       // Use '/Portfolio/ManageOrders/loadOrderTypes'
    //  'tifTypeId': "2",
    //  'price': "",
    //  'quantity': "10",
    //  'disclosedQuantity':"",
    //  'endDate': ""             // Send any date format
    // }
    {
        'status': "1",
        'msg': {
            'msgCode': null,
            'msgType': null,
            'msgText': "Operation Done successfully , order Id 18087Q5N5P"
        },
        'result': "18087Q5N5P"
    },
    // Get Symbol min & max price
    '/Portfolio/ManageOrders/loadPriceRange': 
    // params: {
    //  'symbolId': "0002"
    // }
    {
        'status': "1",
        'msg': null,
        'result': {
            'minPrice': 1.0,
            'maxPrice': 2.0,
            'closedPrice': 1.5
        }
    },
    // Load symbols (they call symbols that you can buy from or sell to securities !)
    '/Portfolio/ManageOrders/loadSecurities': {
        'status': "1",
        'msg': {
            'msgCode': "I000000",
            'msgType': "I",
            'msgText': ""
        },
        'result': [
            {
                'code': "",
                'value': "Select",
                'additionDisplayData': null,
                'note': null
            },
            {
                'code': "1111",
                'value': "1111 - Yellow Media",
                'additionDisplayData': "false - false - null - 2 - false - false - false -  -  -  - ",
                'note': null
            },
            {
                'code': "2222",
                'value': "2222 - Thunder Systems",
                'additionDisplayData': "false - false - null - 2 - false - false - false -  -  -  - ",
                'note': null
            },
            {
                'code': "3333",
                'value': "3333 - Oceanpoint",
                'additionDisplayData': "false - false - null - 2 - false - false - false -  -  -  - ",
                'note': null
            },
            {
                'code': "4444",
                'value': "4444 - Spheretales",
                'additionDisplayData': "false - false - null - 2 - false - false - false -  -  -  - ",
                'note': null
            }
        ]
    },
    // Returns all symbols related to a specific
    // TODO: Optimization: it can be significantly more compact
    '/Portfolio/MyPortfolios/loadAdvancedTradeSecurityList': 
    // Body: {"portfolioId":"65301-1"}
    {
        'status': "1",
        'msg': null,
        'result': {
            'totalCost': "54,155,329.70", 'totalMrktValue': "1,901,202,323.55", "totalProfitLoss": "1,847,046,999.85",
            "tradeSecurties": [{ "portfolioNumber": "65301-1", "symbol": { "code": "1020" }, "ownedQuantity": "1,075,717", "outstandSellQuantity": "1", "outstandBuyQuantity": "0", "pledgedQuantity": "0", "availQuantity": "1075716", "avgCostPrice": { "currencyCode": null, "currencyRate": null, "amount": "3.39", "formatedAmount": null, "localAmount": null }, "mrktPrice": { "currencyCode": null, "currencyRate": null, "amount": "128.00", "formatedAmount": null, "localAmount": null }, "totalCost": { "currencyCode": null, "currencyRate": null, "amount": "3650479.69", "formatedAmount": null, "localAmount": null }, "totalMrktValue": { "currencyCode": null, "currencyRate": null, "amount": "137691776", "formatedAmount": null, "localAmount": null }, "unrealizedProfitLoss": { "currencyCode": null, "currencyRate": null, "amount": "134041296.31", "formatedAmount": null, "localAmount": null }, "realizedProfitLoss": { "currencyCode": null, "currencyRate": null, "amount": "591281.03", "formatedAmount": null, "localAmount": null }, "unrealizedProfitLossPercen": "3671.88", "realizedProfitLossPercen": "16.19735158696", "symbolName": "1020 - Bank AlJazira", "portfolioPer": 7.24, "additionDisplayData": "true - false - null - 2 - false - false - false -  -  -  - ", "productType": null, "productQuantity": 0 }, { "portfolioNumber": "65301-1", "symbol": { "code": "2222" }, "ownedQuantity": "9,117", "outstandSellQuantity": "0", "outstandBuyQuantity": "0", "pledgedQuantity": "0", "availQuantity": "9117", "avgCostPrice": { "currencyCode": null, "currencyRate": null, "amount": "232.87", "formatedAmount": null, "localAmount": null }, "mrktPrice": { "currencyCode": null, "currencyRate": null, "amount": "330.00", "formatedAmount": null, "localAmount": null }, "totalCost": { "currencyCode": null, "currencyRate": null, "amount": "2123073.38", "formatedAmount": null, "localAmount": null }, "totalMrktValue": { "currencyCode": null, "currencyRate": null, "amount": "3008610", "formatedAmount": null, "localAmount": null }, "unrealizedProfitLoss": { "currencyCode": null, "currencyRate": null, "amount": "885536.62", "formatedAmount": null, "localAmount": null }, "realizedProfitLoss": { "currencyCode": null, "currencyRate": null, "amount": "709597.06", "formatedAmount": null, "localAmount": null }, "unrealizedProfitLossPercen": "41.71", "realizedProfitLossPercen": "33.42310570537", "symbolName": "2010 - Saudi Basic Industries Corp", "portfolioPer": 0.16, "additionDisplayData": "true - true - 35 - 2 - true - false - false -  -  -  - ", "productType": null, "productQuantity": 0 }, { "portfolioNumber": "65301-1", "symbol": { "code": "3030" }, "ownedQuantity": "3,620", "outstandSellQuantity": "0", "outstandBuyQuantity": "0", "pledgedQuantity": "0", "availQuantity": "3620", "avgCostPrice": { "currencyCode": null, "currencyRate": null, "amount": "31.76", "formatedAmount": null, "localAmount": null }, "mrktPrice": { "currencyCode": null, "currencyRate": null, "amount": "50.00", "formatedAmount": null, "localAmount": null }, "totalCost": { "currencyCode": null, "currencyRate": null, "amount": "114980.76", "formatedAmount": null, "localAmount": null }, "totalMrktValue": { "currencyCode": null, "currencyRate": null, "amount": "181000", "formatedAmount": null, "localAmount": null }, "unrealizedProfitLoss": { "currencyCode": null, "currencyRate": null, "amount": "66019.24", "formatedAmount": null, "localAmount": null }, "realizedProfitLoss": { "currencyCode": null, "currencyRate": null, "amount": "-1053.25", "formatedAmount": null, "localAmount": null }, "unrealizedProfitLossPercen": "57.42", "realizedProfitLossPercen": "-0.91602281981", "symbolName": "3030 - Saudi Cement Company", "portfolioPer": 0.01, "additionDisplayData": "true - false - null - 2 - false - false - false -  -  -  - ", "productType": null, "productQuantity": 0 }, { "portfolioNumber": "65301-1", "symbol": { "code": "1120" }, "ownedQuantity": "1,146,409", "outstandSellQuantity": "0", "outstandBuyQuantity": "0", "pledgedQuantity": "0", "availQuantity": "1146409", "avgCostPrice": { "currencyCode": null, "currencyRate": null, "amount": "39.29", "formatedAmount": null, "localAmount": null }, "mrktPrice": { "currencyCode": null, "currencyRate": null, "amount": "400.00", "formatedAmount": null, "localAmount": null }, "totalCost": { "currencyCode": null, "currencyRate": null, "amount": "45044377.65", "formatedAmount": null, "localAmount": null }, "totalMrktValue": { "currencyCode": null, "currencyRate": null, "amount": "458563600", "formatedAmount": null, "localAmount": null }, "unrealizedProfitLoss": { "currencyCode": null, "currencyRate": null, "amount": "413519222.35", "formatedAmount": null, "localAmount": null }, "realizedProfitLoss": { "currencyCode": null, "currencyRate": null, "amount": "32362869.96", "formatedAmount": null, "localAmount": null }, "unrealizedProfitLossPercen": "918.03", "realizedProfitLossPercen": "71.84663580316", "symbolName": "1120 - Al Rajhi Bank", "portfolioPer": 24.12, "additionDisplayData": "true - false - null - 2 - false - false - false -  -  -  - ", "productType": null, "productQuantity": 0 }]
        }
    },
    // get OrderTypes
    '/Portfolio/ManageOrders/loadOrderTypes': {
        'status': "1",
        'msg': null,
        'result': [
            {
                'id': "1",
                'value': "Market Price"
            },
            {
                'id': "2",
                'value': "Limited price"
            }
        ]
    },
    // Get TimeInForce types for a specific order type      
    '/Portfolio/ManageOrders/loadTIFTypes': 
    // params: {'orderTypeId':  "1"}
    {
        'status': "1",
        'msg': null,
        'result': [
            { 'id': "2", 'value': "At Opening" },
            { 'id': "4", 'value': "Fill or Kill" },
            { 'id': "3", 'value': "Fill and Kill" },
            { 'id': "0", 'value': "Day" }
        ]
    },
    // get Order Commission
    '/Portfolio/ManageOrders/getOrderCommission': {
        'status': "1",
        'msg': null,
        'result': { "bankCommission": "15", "bankCommissionVAT": "0.001", "bankCommissionVATPercent": "5", "exchangeFees": "3.5", "totalCommission": "20", "totalTradeAmount": "75.23" }
    },
    // Standing Orders
    // params: {
    //  'portfolioId': "65301-1" // TODO: The UI has no input for PortfolioID
    // }
    '/Portfolio/OutstandingOrders/loadOrders': {
        'status': "1",
        'msg': null,
        'result': [
            {
                'symbolName': "0002 - Motoon Real Estate",
                'symbolId': "0002",
                'symbol': null,
                'product': "LOCAL_EQUITY",
                'portfolioNumber': "65301-1",
                'omsRefNumber': "180018JHQZ",
                'orderSide': "BUY",
                'orderSideId': "Buy",
                'orderStartDate': { "gregorianDate": "Jan 1, 2018 13:00:10", "hijriDate": "2018-01-01", "time": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "updated": true, "recordStatus": null, "validated": false, "context": null },
                'orderEndDate': { "gregorianDate": "Jan 13, 2018 12:00:00", "hijriDate": null, "time": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "updated": true, "recordStatus": null, "validated": false, "context": null },
                'orderType': "MARKET",
                'orderTypeId': "Market Price",
                'mrktAuthorized': "YES",
                'orderQuantity': "100",
                'fillQuantityMin': "",
                'disclosedQuantityMin': "0",
                'executedTotalAmount': "1300",
                'executedQuantity': "0",
                'numberOfDays': null,
                'tifType': "GOOD_TILL_DATE",
                'tifTypeId': "Good till date",
                'orderStatus': "NEW",
                'orderStatusId': "New",
                'remainigQuantity': "100",
                'orderCommission': "20",
                'avaragePrice': 11,
                'taxInfo': null
            }, { "symbolName": "1020 - Bank AlJazira", "symbolId": "1020", "symbol": null, "product": "LOCAL_EQUITY", "portfolioNumber": "65301-1", "omsRefNumber": "172996LLFN", "orderSide": "SELL", "orderSideId": "Sell", "orderStartDate": { "gregorianDate": "Oct 26, 2017 01:00:00", "hijriDate": "2017-10-26", "time": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "updated": true, "recordStatus": null, "validated": false, "context": null }, "orderEndDate": { "gregorianDate": "Oct 26, 2017 12:00:00", "hijriDate": null, "time": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "updated": true, "recordStatus": null, "validated": false, "context": null }, "orderType": "LIMIT", "orderTypeId": "Limited price", "mrktAuthorized": "YES", "orderQuantity": "1", "fillQuantityMin": "", "disclosedQuantityMin": "", "executedTotalAmount": "72", "executedQuantity": "0", "numberOfDays": null, "tifType": "GOOD_TILL_DATE", "tifTypeId": "Good till date", "orderStatus": "ORDER_ACKNOLEDGED", "orderStatusId": "Queued", "remainigQuantity": "1", "orderCommission": null, "avaragePrice": 22, "taxInfo": null }, { "symbolName": "2220 - National Metal Manufacturing and Ca", "symbolId": "2220", "symbol": null, "product": "LOCAL_EQUITY", "portfolioNumber": "65301-1", "omsRefNumber": "18004N2V3Q", "orderSide": "BUY", "orderSideId": "Buy", "orderStartDate": { "gregorianDate": "Jan 4, 2018 13:00:20", "hijriDate": "2018-01-04", "time": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "updated": true, "recordStatus": null, "validated": false, "context": null }, "orderEndDate": { "gregorianDate": "Jan 4, 2018 12:00:00", "hijriDate": null, "time": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "updated": true, "recordStatus": null, "validated": false, "context": null }, "orderType": "LIMIT", "orderTypeId": "Limited price", "mrktAuthorized": "YES", "orderQuantity": "3", "fillQuantityMin": "", "disclosedQuantityMin": "", "executedTotalAmount": "19.3", "executedQuantity": "0", "numberOfDays": null, "tifType": "DAY", "tifTypeId": "Day", "orderStatus": "REJECTED", "orderStatusId": "Rejected", "remainigQuantity": "3", "orderCommission": null, "avaragePrice": 33, "taxInfo": null }, { "symbolName": "2220 - National Metal Manufacturing and Ca", "symbolId": "2220", "symbol": null, "product": "LOCAL_EQUITY", "portfolioNumber": "65301-1", "omsRefNumber": "18004GBN51", "orderSide": "BUY", "orderSideId": "Buy", "orderStartDate": { "gregorianDate": "Jan 4, 2018 18:00:00", "hijriDate": "2018-01-04", "time": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "updated": true, "recordStatus": null, "validated": false, "context": null }, "orderEndDate": { "gregorianDate": "Jan 4, 2018 12:00:00", "hijriDate": null, "time": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "updated": true, "recordStatus": null, "validated": false, "context": null }, "orderType": "LIMIT", "orderTypeId": "Limited price", "mrktAuthorized": "NO", "orderQuantity": "10", "fillQuantityMin": "", "disclosedQuantityMin": "", "executedTotalAmount": "19.3", "executedQuantity": "0", "numberOfDays": null, "tifType": "DAY", "tifTypeId": "Day", "orderStatus": "NEW", "orderStatusId": "New", "remainigQuantity": "10", "orderCommission": null, "avaragePrice": 44, "taxInfo": null }, { "symbolName": "3010 - Arabian Cement Co", "symbolId": "3010", "symbol": null, "product": "LOCAL_EQUITY", "portfolioNumber": "65301-1", "omsRefNumber": "18001STCZV", "orderSide": "BUY", "orderSideId": "Buy", "orderStartDate": { "gregorianDate": "Jan 1, 2018 14:00:00", "hijriDate": "2018-01-01", "time": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "updated": true, "recordStatus": null, "validated": false, "context": null }, "orderEndDate": { "gregorianDate": "Jan 1, 2018 12:00:00", "hijriDate": null, "time": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "updated": true, "recordStatus": null, "validated": false, "context": null }, "orderType": "LIMIT", "orderTypeId": "Limited price", "mrktAuthorized": "YES", "orderQuantity": "100", "fillQuantityMin": "", "disclosedQuantityMin": "", "executedTotalAmount": "47.8", "executedQuantity": "0", "numberOfDays": null, "tifType": "GOOD_TILL_DATE", "tifTypeId": "Good till date", "orderStatus": "NEW", "orderStatusId": "New", "remainigQuantity": "100", "orderCommission": null, "avaragePrice": 55, "taxInfo": null }, { "symbolName": "3010 - Arabian Cement Co", "symbolId": "3010", "symbol": null, "product": "LOCAL_EQUITY", "portfolioNumber": "65301-1", "omsRefNumber": "18001LTJ59", "orderSide": "BUY", "orderSideId": "Buy", "orderStartDate": { "gregorianDate": "Jan 1, 2018 13:00:20", "hijriDate": "2018-01-01", "time": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "updated": true, "recordStatus": null, "validated": false, "context": null }, "orderEndDate": { "gregorianDate": "Jan 1, 2018 12:00:00", "hijriDate": null, "time": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "updated": true, "recordStatus": null, "validated": false, "context": null }, "orderType": "LIMIT", "orderTypeId": "Limited price", "mrktAuthorized": "YES", "orderQuantity": "100", "fillQuantityMin": "", "disclosedQuantityMin": "", "executedTotalAmount": "47.8", "executedQuantity": "0", "numberOfDays": null, "tifType": "GOOD_TILL_DATE", "tifTypeId": "Good till date", "orderStatus": "CANCELLED", "orderStatusId": "Cancelled", "remainigQuantity": "100", "orderCommission": null, "avaragePrice": 66, "taxInfo": null }, { "symbolName": "3010 - Arabian Cement Co", "symbolId": "3010", "symbol": null, "product": "LOCAL_EQUITY", "portfolioNumber": "65301-1", "omsRefNumber": "18001C3R09", "orderSide": "BUY", "orderSideId": "Buy", "orderStartDate": { "gregorianDate": "Jan 1, 2018 05:00:00", "hijriDate": "2018-01-01", "time": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "updated": true, "recordStatus": null, "validated": false, "context": null }, "orderEndDate": { "gregorianDate": "Jan 1, 2018 12:00:00", "hijriDate": null, "time": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "updated": true, "recordStatus": null, "validated": false, "context": null }, "orderType": "LIMIT", "orderTypeId": "Limited price", "mrktAuthorized": "YES", "orderQuantity": "100", "fillQuantityMin": "", "disclosedQuantityMin": "", "executedTotalAmount": "47.8", "executedQuantity": "0", "numberOfDays": null, "tifType": "GOOD_TILL_DATE", "tifTypeId": "Good till date", "orderStatus": "NEW", "orderStatusId": "New", "remainigQuantity": "100", "orderCommission": null, "avaragePrice": 77, "taxInfo": null }
        ]
    },
    // UpdatesOrder, like buy and sell
    // TODO: this generates an error
    '/Portfolio/OutstandingOrders/updateOrder': 
    // params: {
    //  'orderId': "1010"
    // }
    // Actual params for updateOrder {
    // 'orderTrade': {
    //   'symbolName': "2220 - National Metal Manufacturing and Ca",
    //   'symbolId': "2220",
    //   'symbol': null,
    //   'product': "LOCAL_EQUITY",
    //   'portfolioNumber': "65301-1",
    //   'omsRefNumber': "18004GBN51",
    //   'orderSide': "BUY",
    //   'orderSideId': "Buy",
    //   'orderStartDate': {
    //     'gregorianDate': "Jan 4, 2018 12:00:00 AM",
    //     'hijriDate': "2018-01-04",
    //     'time': null,
    //     'updatesMap': [],
    //     'parentsBO': {},
    //     'parentLists':[],
    //     'parentMaps': [],
    //     "isFetched":true,"updated":true,"recordStatus":null,"validated":false,"context":null},"orderEndDate":{"gregorianDate":"Jan 04, 2018 03:00:00 AM","hijriDate":null,"time":null,"updatesMap":[],"parentsBO":{},"parentLists":[],"parentMaps":[],"isFetched":true,"updated":true,"recordStatus":null,"validated":false,"context":null},"orderType":"LIMIT","orderTypeId":"Limited price","mrktAuthorized":"YES","orderQuantity":"10","fillQuantityMin":"","disclosedQuantityMin":"","executedTotalAmount":"19.3","executedQuantity":"0","numberOfDays":null,"tifType":"DAY","tifTypeId":null,"orderStatus":"NEW","orderStatusId":"New","remainigQuantity":"15","orderCommission":null,"avaragePrice":null,"taxInfo":null
    //   }
    // }
    // ,
    {
        'status': "1",
        'msg': {
            'msgCode': null,
            'msgType': null,
            'msgText': "Operation Done successfully , order Id 18087Q5N5P"
        }
    },
    // Deletes A StandingOrder
    '/Portfolio/OutstandingOrders/deleteOrder': 
    // params: {
    //   'referenceNumber': "18004N2V3Q", 'portfolioId': "65301-1"
    // }
    {
        // This generates an error, so the response may chanage later
        'status': "1",
        'msg': null
    },
    '/Portfolio/OrdersSearch/loadMFOrderStatus': {
        "status": "1",
        "msg": null,
        "result": [
            {
                "id": "All",
                "value": "All"
            },
            {
                "id": "Executed",
                "value": "Executed"
            },
            {
                "id": "New",
                "value": "New"
            }
        ]
    },
    '/Portfolio/OrdersSearch/loadMFOrderTypes': {
        "status": "1",
        "msg": null,
        "result": [
            {
                "id": "All",
                "value": "All"
            },
            {
                "id": "FSB",
                "value": "Subscription"
            },
            {
                "id": "FRD",
                "value": "Redemption"
            },
            {
                "id": "FSA",
                "value": "Addition"
            }
        ]
    },
    "/Portfolio/ManageOrders/loadCustBuyingPwr": {
        "status": "1",
        "msg": null,
        "result": { "buyingPwr": { "account": { "accountNumber": "100065519041", "accountType": null, "iban": null, "accountName": null, "shortDesc": null, "accountNickName": null, "accountStatus": null, "accountCurrency": null, "availableBalance": null, "ledgerBalance": null, "currentBalance": null, "subUsrEnabled": null, "acctFuncsAccess": null, "deliveryOption": null, "deliveryLocation": null, "stmtPreferredLang": null, "branchId": null, "atmCardExist": null, "signId": null, "countryCode": null, "bankCode": null, "mnemonicName": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "buyingPwrAmt": { "currencyCode": null, "currencyRate": null, "amount": "1487134.64", "formatedAmount": null, "localAmount": null }, "closingBalAmt": { "currencyCode": null, "currencyRate": null, "amount": "1487134.64", "formatedAmount": null, "localAmount": null }, "netSecurityAmt": { "currencyCode": null, "currencyRate": null, "amount": "123992.5", "formatedAmount": null, "localAmount": null }, "overdraftAmt": { "currencyCode": null, "currencyRate": null, "amount": "0.00", "formatedAmount": null, "localAmount": null }, "blockedAmt": { "currencyCode": null, "currencyRate": null, "amount": "0", "formatedAmount": null, "localAmount": null }, "usageAmt": { "currencyCode": null, "currencyRate": null, "amount": "0.00", "formatedAmount": null, "localAmount": null }, "avilLimitAmt": { "currencyCode": null, "currencyRate": null, "amount": "0.00", "formatedAmount": null, "localAmount": null }, "portfolioPostionAmt": { "currencyCode": null, "currencyRate": null, "amount": "1611127.14", "formatedAmount": null, "localAmount": null } }, "currency": "SAR", "documentType": "LOCAL" }
    },
    "/Portfolio/BuyingPower/loadMFCustBuyingPwr": {
        "status": "1",
        "msg": null,
        "result": { "buyingPwr": { "account": { "accountNumber": "200065519058", "accountType": null, "iban": null, "accountName": null, "shortDesc": null, "accountNickName": null, "accountStatus": null, "accountCurrency": null, "availableBalance": null, "ledgerBalance": null, "currentBalance": null, "subUsrEnabled": null, "acctFuncsAccess": null, "deliveryOption": null, "deliveryLocation": null, "stmtPreferredLang": null, "branchId": null, "atmCardExist": null, "signId": null, "countryCode": null, "bankCode": null, "mnemonicName": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "buyingPwrAmt": { "currencyCode": null, "currencyRate": null, "amount": "577546.15", "formatedAmount": null, "localAmount": null }, "closingBalAmt": { "currencyCode": null, "currencyRate": null, "amount": "577546.15", "formatedAmount": null, "localAmount": null }, "netSecurityAmt": { "currencyCode": null, "currencyRate": null, "amount": "0", "formatedAmount": null, "localAmount": null }, "overdraftAmt": { "currencyCode": null, "currencyRate": null, "amount": "0", "formatedAmount": null, "localAmount": null }, "blockedAmt": { "currencyCode": null, "currencyRate": null, "amount": "0", "formatedAmount": null, "localAmount": null }, "usageAmt": null, "avilLimitAmt": null, "portfolioPostionAmt": { "currencyCode": null, "currencyRate": null, "amount": "577546.15", "formatedAmount": null, "localAmount": null } }, "currency": "SAR", "documentType": "LOCAL" }
    }
};


/***/ }),

/***/ 15122:
/*!****************************************************!*\
  !*** ./src/environments/mocks/portfolios.mocks.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PortfoliosMockedWebService": () => (/* binding */ PortfoliosMockedWebService)
/* harmony export */ });
var PortfoliosMockedWebService = {
    // Get portfolios
    '/Portfolio/BuyingPower/loadPortfolioNumbers': {
        "status": "1", "result": [
            {
                "id": "162202-1", "value": "162202-1", "typeCode": "IP"
            },
            {
                "id": "162202-1", "value": "162202-1", "typeCode": "MP"
            }
        ], "msg": null
    }
    // {
    //     'status': "1", 'msg': null,
    //     'result': [
    //         {
    //             "id": "123874-1",
    //             "value": "123874-1",
    //             "typeCode": "IP"
    //         },
    //         {
    //             "id": "123874-1",
    //             "value": "123874-1",
    //             "typeCode": "MP"
    //         }
    //     ]
    // }
    ,
    // {"status":"1","msg":null,"result":[{"id":"Test Portfolio 1","value":"Test Portfolio 1","typeCode":"IP"},{"id":"Test Portfolio 2","value":"Test Portfolio 2","typeCode":"MP"},{"id":"Test Portfolio 3","value":"Test Portfolio 3","typeCode":"IP"},{"id":"Test Portfolio 4","value":"Test Portfolio 4","typeCode":"MP"}]}
    // Backend asked to call this after we subscribe to the channel
    '/portfolio/MyPortfolios/loadBuyingPwrForUserPortfolios': {
        'status': "1",
        'result': {}
    },
    // Backend asked to call this after we subscribe to the channel
    '/portfolio/MyPortfolios/getMFPortfolioPosition': 
    // params: portfolioId
    // { "status": "1", "msg": null, "result": [{ "id": "111111-000", "type": "MF", "arName": "صندوق الإنماء للأسهم السعودية", "enName": "ALINMA SAUDI EQUITY FUND", "units": { "currencyCode": null, "currencyRate": null, "amount": "16404.337107", "formatedAmount": null, "localAmount": null }, "avgPrice": { "currencyCode": null, "currencyRate": null, "amount": "25.485756", "formatedAmount": null, "localAmount": null }, "totalCost": { "currencyCode": null, "currencyRate": null, "amount": "418076.930000", "formatedAmount": null, "localAmount": null }, "lastValuationPrice": { "currencyCode": null, "currencyRate": null, "amount": "3.244604", "formatedAmount": null, "localAmount": null }, "marketValue": { "currencyCode": null, "currencyRate": null, "amount": "53225.577795", "formatedAmount": null, "localAmount": null }, "unrealizedGainLoss": { "currencyCode": null, "currencyRate": null, "amount": "-364851.352205", "formatedAmount": null, "localAmount": null }, "unrealizedGainLossPer": { "currencyCode": null, "currencyRate": null, "amount": "-87.268951", "formatedAmount": null, "localAmount": null }, "mutualFundPer": { "currencyCode": null, "currencyRate": null, "amount": "13.964628", "formatedAmount": null, "localAmount": null } }, { "id": "555555-000", "type": "MF", "arName": "صندوق الإنماء المتحفظ متعدد الأصول", "enName": "Alinma multi Assets Defensive Fund", "units": { "currencyCode": null, "currencyRate": null, "amount": "24137.655383", "formatedAmount": null, "localAmount": null }, "avgPrice": { "currencyCode": null, "currencyRate": null, "amount": "10.892006", "formatedAmount": null, "localAmount": null }, "totalCost": { "currencyCode": null, "currencyRate": null, "amount": "262907.490000", "formatedAmount": null, "localAmount": null }, "lastValuationPrice": { "currencyCode": null, "currencyRate": null, "amount": "10.757342", "formatedAmount": null, "localAmount": null }, "marketValue": { "currencyCode": null, "currencyRate": null, "amount": "259657.014033", "formatedAmount": null, "localAmount": null }, "unrealizedGainLoss": { "currencyCode": null, "currencyRate": null, "amount": "-3250.475967", "formatedAmount": null, "localAmount": null }, "unrealizedGainLossPer": { "currencyCode": null, "currencyRate": null, "amount": "-1.236357", "formatedAmount": null, "localAmount": null }, "mutualFundPer": { "currencyCode": null, "currencyRate": null, "amount": "68.125394", "formatedAmount": null, "localAmount": null } }, { "id": "999916-000", "type": "CF", "arName": "صندوق الإنماء وريف الوقفي", "enName": "Alinma Wareef Endowment Fund", "units": { "currencyCode": null, "currencyRate": null, "amount": "10.000000", "formatedAmount": null, "localAmount": null }, "avgPrice": { "currencyCode": null, "currencyRate": null, "amount": "10.000000", "formatedAmount": null, "localAmount": null }, "totalCost": { "currencyCode": null, "currencyRate": null, "amount": "100.000000", "formatedAmount": null, "localAmount": null }, "lastValuationPrice": { "currencyCode": null, "currencyRate": null, "amount": "0.000000", "formatedAmount": null, "localAmount": null }, "marketValue": { "currencyCode": null, "currencyRate": null, "amount": "0.000000", "formatedAmount": null, "localAmount": null }, "unrealizedGainLoss": { "currencyCode": null, "currencyRate": null, "amount": "-100.000000", "formatedAmount": null, "localAmount": null }, "unrealizedGainLossPer": { "currencyCode": null, "currencyRate": null, "amount": "-100.000000", "formatedAmount": null, "localAmount": null }, "mutualFundPer": { "currencyCode": null, "currencyRate": null, "amount": "0.000000", "formatedAmount": null, "localAmount": null } }, { "id": "999914-000", "type": "MF", "arName": "صندوق الانماء مكة العقاري", "enName": "Alinma Makkah Real Estate Fund", "units": { "currencyCode": null, "currencyRate": null, "amount": "34881.162000", "formatedAmount": null, "localAmount": null }, "avgPrice": { "currencyCode": null, "currencyRate": null, "amount": "10.000000", "formatedAmount": null, "localAmount": null }, "totalCost": { "currencyCode": null, "currencyRate": null, "amount": "348811.620000", "formatedAmount": null, "localAmount": null }, "lastValuationPrice": { "currencyCode": null, "currencyRate": null, "amount": "9.981600", "formatedAmount": null, "localAmount": null }, "marketValue": { "currencyCode": null, "currencyRate": null, "amount": "348169.806619", "formatedAmount": null, "localAmount": null }, "unrealizedGainLoss": { "currencyCode": null, "currencyRate": null, "amount": "-641.813381", "formatedAmount": null, "localAmount": null }, "unrealizedGainLossPer": { "currencyCode": null, "currencyRate": null, "amount": "-0.184000", "formatedAmount": null, "localAmount": null }, "mutualFundPer": { "currencyCode": null, "currencyRate": null, "amount": "100.000000", "formatedAmount": null, "localAmount": null } }] }
    {
        "status": "1",
        "msg": null,
        "result": {
            "paginationInfo": {
                "wholeResultSetSize": 4,
                "currentResultSetSize": 4
            },
            "mutualFundPositionList": [
                {
                    "id": "111111-000",
                    "type": "MF",
                    "arName": "????? ??????? ?????? ????????",
                    "enName": "ALINMA SAUDI EQUITY FUND",
                    "units": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "16404.337107",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "avgPrice": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "25.485756",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "totalCost": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "418076.930000",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "lastValuationPrice": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "3.244604",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "marketValue": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "53225.577795",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "unrealizedGainLoss": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "-364851.352205",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "unrealizedGainLossPer": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "-87.268951",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "mutualFundPer": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "13.964628",
                        "formatedAmount": null,
                        "localAmount": null
                    }
                },
                {
                    "id": "555555-000",
                    "type": "MF",
                    "arName": "????? ??????? ??????? ????? ??????",
                    "enName": "Alinma multi Assets Defensive Fund",
                    "units": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "24137.655383",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "avgPrice": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "10.892006",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "totalCost": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "262907.490000",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "lastValuationPrice": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "10.757342",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "marketValue": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "259657.014033",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "unrealizedGainLoss": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "-3250.475967",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "unrealizedGainLossPer": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "-1.236357",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "mutualFundPer": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "68.125394",
                        "formatedAmount": null,
                        "localAmount": null
                    }
                },
                {
                    "id": "999916-000",
                    "type": "CF",
                    "arName": "????? ??????? ???? ??????",
                    "enName": "Alinma Wareef Endowment Fund",
                    "units": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "10.000000",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "avgPrice": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "10.000000",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "totalCost": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "100.000000",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "lastValuationPrice": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "0.000000",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "marketValue": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "0.000000",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "unrealizedGainLoss": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "-100.000000",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "unrealizedGainLossPer": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "-100.000000",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "mutualFundPer": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "0.000000",
                        "formatedAmount": null,
                        "localAmount": null
                    }
                },
                {
                    "id": "999914-000",
                    "type": "MF",
                    "arName": "????? ??????? ??? ???????",
                    "enName": "Alinma Makkah Real Estate Fund",
                    "units": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "34881.162000",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "avgPrice": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "10.000000",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "totalCost": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "348811.620000",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "lastValuationPrice": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "9.981600",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "marketValue": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "348169.806619",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "unrealizedGainLoss": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "-641.813381",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "unrealizedGainLossPer": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "-0.184000",
                        "formatedAmount": null,
                        "localAmount": null
                    },
                    "mutualFundPer": {
                        "currencyCode": null,
                        "currencyRate": null,
                        "amount": "100.000000",
                        "formatedAmount": null,
                        "localAmount": null
                    }
                }
            ],
            "totalMarketValue": {
                "currencyCode": null,
                "currencyRate": null,
                "amount": "381145.703902",
                "formatedAmount": null,
                "localAmount": null
            },
            "totalUnrealizedprofitLossAmt": {
                "currencyCode": null,
                "currencyRate": null,
                "amount": "-490744.706098",
                "formatedAmount": null,
                "localAmount": null
            },
            "totalCost": {
                "currencyCode": null,
                "currencyRate": null,
                "amount": "871890.410000",
                "formatedAmount": null,
                "localAmount": null
            }
        }
    },
    '/Portfolio/MyPortfolios/loadPortfolios': { "status": "1", "msg": null, "result": [{ "number": "65519-1", "year": null, "quarter": null, "portfolioType": { "code": "IP" }, "name": "ALFAHAD,SALEHN", "samaAccount": { "accountNumber": null, "accountType": null, "iban": null, "accountName": null, "shortDesc": null, "accountNickName": null, "accountStatus": null, "accountCurrency": null, "availableBalance": null, "ledgerBalance": null, "currentBalance": null, "subUsrEnabled": null, "acctFuncsAccess": null, "deliveryOption": null, "deliveryLocation": null, "stmtPreferredLang": null, "branchId": null, "atmCardExist": null, "signId": null, "countryCode": null, "bankCode": null, "mnemonicName": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "account": { "accountNumber": "100065519017", "accountType": { "code": "IN" }, "iban": null, "accountName": null, "shortDesc": "LOCAL", "accountNickName": null, "accountStatus": null, "accountCurrency": null, "availableBalance": null, "ledgerBalance": null, "currentBalance": null, "subUsrEnabled": null, "acctFuncsAccess": null, "deliveryOption": null, "deliveryLocation": null, "stmtPreferredLang": null, "branchId": null, "atmCardExist": null, "signId": null, "countryCode": null, "bankCode": null, "mnemonicName": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "positionAmt": null, "totalUnrealizedprofitLossAmt": null, "totalRealizedprofitLossAmt": null, "totalCost": null, "totalMarketValue": null, "tradeSecList": null }, { "number": "65519-2", "year": null, "quarter": null, "portfolioType": { "code": "MP" }, "name": "ALFAHAD,SALEHN", "samaAccount": { "accountNumber": null, "accountType": null, "iban": null, "accountName": null, "shortDesc": null, "accountNickName": null, "accountStatus": null, "accountCurrency": null, "availableBalance": null, "ledgerBalance": null, "currentBalance": null, "subUsrEnabled": null, "acctFuncsAccess": null, "deliveryOption": null, "deliveryLocation": null, "stmtPreferredLang": null, "branchId": null, "atmCardExist": null, "signId": null, "countryCode": null, "bankCode": null, "mnemonicName": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "account": { "accountNumber": "200065519023", "accountType": { "code": "MF" }, "iban": null, "accountName": null, "shortDesc": "LOCAL", "accountNickName": null, "accountStatus": null, "accountCurrency": null, "availableBalance": null, "ledgerBalance": null, "currentBalance": null, "subUsrEnabled": null, "acctFuncsAccess": null, "deliveryOption": null, "deliveryLocation": null, "stmtPreferredLang": null, "branchId": null, "atmCardExist": null, "signId": null, "countryCode": null, "bankCode": null, "mnemonicName": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "positionAmt": null, "totalUnrealizedprofitLossAmt": null, "totalRealizedprofitLossAmt": null, "totalCost": null, "totalMarketValue": null, "tradeSecList": null }, { "number": "65519-3", "year": null, "quarter": null, "portfolioType": { "code": "IP" }, "name": "ALFAHAD,SALEHN", "samaAccount": { "accountNumber": null, "accountType": null, "iban": null, "accountName": null, "shortDesc": null, "accountNickName": null, "accountStatus": null, "accountCurrency": null, "availableBalance": null, "ledgerBalance": null, "currentBalance": null, "subUsrEnabled": null, "acctFuncsAccess": null, "deliveryOption": null, "deliveryLocation": null, "stmtPreferredLang": null, "branchId": null, "atmCardExist": null, "signId": null, "countryCode": null, "bankCode": null, "mnemonicName": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "account": { "accountNumber": "100065519041", "accountType": { "code": "IN" }, "iban": null, "accountName": null, "shortDesc": "LOCAL", "accountNickName": null, "accountStatus": null, "accountCurrency": null, "availableBalance": null, "ledgerBalance": null, "currentBalance": null, "subUsrEnabled": null, "acctFuncsAccess": null, "deliveryOption": null, "deliveryLocation": null, "stmtPreferredLang": null, "branchId": null, "atmCardExist": null, "signId": null, "countryCode": null, "bankCode": null, "mnemonicName": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "positionAmt": null, "totalUnrealizedprofitLossAmt": null, "totalRealizedprofitLossAmt": null, "totalCost": null, "totalMarketValue": null, "tradeSecList": null }, { "number": "65519-4", "year": null, "quarter": null, "portfolioType": { "code": "MP" }, "name": "ALFAHAD,SALEHN", "samaAccount": { "accountNumber": null, "accountType": null, "iban": null, "accountName": null, "shortDesc": null, "accountNickName": null, "accountStatus": null, "accountCurrency": null, "availableBalance": null, "ledgerBalance": null, "currentBalance": null, "subUsrEnabled": null, "acctFuncsAccess": null, "deliveryOption": null, "deliveryLocation": null, "stmtPreferredLang": null, "branchId": null, "atmCardExist": null, "signId": null, "countryCode": null, "bankCode": null, "mnemonicName": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "account": { "accountNumber": "200065519058", "accountType": { "code": "MF" }, "iban": null, "accountName": null, "shortDesc": "LOCAL", "accountNickName": null, "accountStatus": null, "accountCurrency": null, "availableBalance": null, "ledgerBalance": null, "currentBalance": null, "subUsrEnabled": null, "acctFuncsAccess": null, "deliveryOption": null, "deliveryLocation": null, "stmtPreferredLang": null, "branchId": null, "atmCardExist": null, "signId": null, "countryCode": null, "bankCode": null, "mnemonicName": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "positionAmt": null, "totalUnrealizedprofitLossAmt": null, "totalRealizedprofitLossAmt": null, "totalCost": null, "totalMarketValue": null, "tradeSecList": null }, { "number": "65519-5", "year": null, "quarter": null, "portfolioType": { "code": "IP" }, "name": "ALFAHAD,SALEHN", "samaAccount": { "accountNumber": "4500014883", "accountType": null, "iban": null, "accountName": null, "shortDesc": null, "accountNickName": null, "accountStatus": null, "accountCurrency": null, "availableBalance": null, "ledgerBalance": null, "currentBalance": null, "subUsrEnabled": null, "acctFuncsAccess": null, "deliveryOption": null, "deliveryLocation": null, "stmtPreferredLang": null, "branchId": null, "atmCardExist": null, "signId": null, "countryCode": null, "bankCode": null, "mnemonicName": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "account": { "accountNumber": "100065519262", "accountType": { "code": "IN" }, "iban": null, "accountName": null, "shortDesc": "LOCAL", "accountNickName": null, "accountStatus": null, "accountCurrency": null, "availableBalance": null, "ledgerBalance": null, "currentBalance": null, "subUsrEnabled": null, "acctFuncsAccess": null, "deliveryOption": null, "deliveryLocation": null, "stmtPreferredLang": null, "branchId": null, "atmCardExist": null, "signId": null, "countryCode": null, "bankCode": null, "mnemonicName": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "positionAmt": null, "totalUnrealizedprofitLossAmt": null, "totalRealizedprofitLossAmt": null, "totalCost": null, "totalMarketValue": null, "tradeSecList": null }, { "number": "65519-6", "year": null, "quarter": null, "portfolioType": { "code": "IP" }, "name": "ALFAHAD,SALEHN", "samaAccount": { "accountNumber": "4500014891", "accountType": null, "iban": null, "accountName": null, "shortDesc": null, "accountNickName": null, "accountStatus": null, "accountCurrency": null, "availableBalance": null, "ledgerBalance": null, "currentBalance": null, "subUsrEnabled": null, "acctFuncsAccess": null, "deliveryOption": null, "deliveryLocation": null, "stmtPreferredLang": null, "branchId": null, "atmCardExist": null, "signId": null, "countryCode": null, "bankCode": null, "mnemonicName": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "account": { "accountNumber": "100065519270", "accountType": { "code": "IN" }, "iban": null, "accountName": null, "shortDesc": "LOCAL", "accountNickName": null, "accountStatus": null, "accountCurrency": null, "availableBalance": null, "ledgerBalance": null, "currentBalance": null, "subUsrEnabled": null, "acctFuncsAccess": null, "deliveryOption": null, "deliveryLocation": null, "stmtPreferredLang": null, "branchId": null, "atmCardExist": null, "signId": null, "countryCode": null, "bankCode": null, "mnemonicName": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "positionAmt": null, "totalUnrealizedprofitLossAmt": null, "totalRealizedprofitLossAmt": null, "totalCost": null, "totalMarketValue": null, "tradeSecList": null }, { "number": "65519-7", "year": null, "quarter": null, "portfolioType": { "code": "IP" }, "name": "ALFAHAD,SALEHN", "samaAccount": { "accountNumber": "4500015088", "accountType": null, "iban": null, "accountName": null, "shortDesc": null, "accountNickName": null, "accountStatus": null, "accountCurrency": null, "availableBalance": null, "ledgerBalance": null, "currentBalance": null, "subUsrEnabled": null, "acctFuncsAccess": null, "deliveryOption": null, "deliveryLocation": null, "stmtPreferredLang": null, "branchId": null, "atmCardExist": null, "signId": null, "countryCode": null, "bankCode": null, "mnemonicName": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "account": { "accountNumber": "100065519297", "accountType": { "code": "IN" }, "iban": null, "accountName": null, "shortDesc": "LOCAL", "accountNickName": null, "accountStatus": null, "accountCurrency": null, "availableBalance": null, "ledgerBalance": null, "currentBalance": null, "subUsrEnabled": null, "acctFuncsAccess": null, "deliveryOption": null, "deliveryLocation": null, "stmtPreferredLang": null, "branchId": null, "atmCardExist": null, "signId": null, "countryCode": null, "bankCode": null, "mnemonicName": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "positionAmt": null, "totalUnrealizedprofitLossAmt": null, "totalRealizedprofitLossAmt": null, "totalCost": null, "totalMarketValue": null, "tradeSecList": null }, { "number": "65519-8", "year": null, "quarter": null, "portfolioType": { "code": "IP" }, "name": "ALFAHAD,SALEHN", "samaAccount": { "accountNumber": null, "accountType": null, "iban": null, "accountName": null, "shortDesc": null, "accountNickName": null, "accountStatus": null, "accountCurrency": null, "availableBalance": null, "ledgerBalance": null, "currentBalance": null, "subUsrEnabled": null, "acctFuncsAccess": null, "deliveryOption": null, "deliveryLocation": null, "stmtPreferredLang": null, "branchId": null, "atmCardExist": null, "signId": null, "countryCode": null, "bankCode": null, "mnemonicName": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "account": { "accountNumber": "100065519300", "accountType": { "code": "IN" }, "iban": null, "accountName": null, "shortDesc": "LOCAL", "accountNickName": null, "accountStatus": null, "accountCurrency": null, "availableBalance": null, "ledgerBalance": null, "currentBalance": null, "subUsrEnabled": null, "acctFuncsAccess": null, "deliveryOption": null, "deliveryLocation": null, "stmtPreferredLang": null, "branchId": null, "atmCardExist": null, "signId": null, "countryCode": null, "bankCode": null, "mnemonicName": null, "updatesMap": [], "parentsBO": {}, "parentLists": [], "parentMaps": [], "isFetched": true, "exists": null, "updated": true, "recordStatus": null, "previousRecordStatus": null, "validated": false, "context": null }, "positionAmt": null, "totalUnrealizedprofitLossAmt": null, "totalRealizedprofitLossAmt": null, "totalCost": null, "totalMarketValue": null, "tradeSecList": null }] }
};


/***/ }),

/***/ 73442:
/*!*************************************************!*\
  !*** ./src/environments/mocks/symbols.mocks.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SymbolsMockedWebService": () => (/* binding */ SymbolsMockedWebService)
/* harmony export */ });
const SymbolsMockedWebService = {
    // Get all Symbols 
    '/StockMarket/ManageWatchList/loadAllSymbols': {
        'status': "1",
        'result': [
            { "id": "1111", "market": "~TWL", "shortDescription": 'Yellow', "description": 'Yellow Media' },
            { "id": "2222", "market": "~TWL", "shortDescription": 'Thunder', "description": 'Thunder Systems' },
            { "id": "3333", "market": "~TWL", "shortDescription": 'Ocean', "description": 'Oceanpoint' },
            { "id": "4444", "market": "~TWL", "shortDescription": 'Sphere', "description": 'Spheretales' },
            { "id": "5555", "market": "~TWL", "shortDescription": 'Pink', "description": 'Pinkorps' },
            { "id": "6666", "market": "~TWL", "shortDescription": 'Mountainet', "description": 'Mountainetworks' },
            { "id": "7777", "market": "~TWL", "shortDescription": 'Bet', "description": 'Betarts' },
            { "id": "8888", "market": "~TWL", "shortDescription": 'Feline', "description": 'Feline Aviation' },
            // { "id": "9999", "market": "~TWL", "shortDescriptionEn": 'Luckytronics', "shortDescriptionAr": 'Luckytronics', "descriptionEn": 'Luckytronics', "descriptionAr": 'Luckytronics', "sector": null, "previousClosed": 0.0, "open": 0.0, "lastTradePrice": 0.0, "change": 0.0, "perce_change": 0.0, "mbp_bid1": 0.0, "mbp_bid1_qty": 0.0, "mbp_ask1": 0.0, "mbp_ask1_qty": 0.0, "noOfTrades": 0.0, "volume": 0.0, "turnOver": 0.0, "vwap": 0.0, "high": 0.0, "low": 0.0, "lastTradeTime": null, "tradable": false, "loser": false, "losePercentage": null, "settlementDays": 0, "loserAlert": false, "tradableRight": false, "tradableRightAlert": false, "tradableRightStartDate": null, "tradableRightEndDate": null, "tradableRightsSubPrice": 0.0 },
        ]
    },
    // Get Porfolio full details // MayDO: Optimization: ask about if it can be more compact
    '/Portfolio/BuyingPower/loadCustBuyingPwr': 
    // @params {'portfolioId': "65301-1"}
    {
        'status': "1",
        'msg': null,
        'result': {
            'buyingPwr': {
                'account': {
                    "accountNumber": "100065301011",
                    "accountType": null,
                    "iban": null,
                    "accountName": null,
                    "shortDesc": null,
                    "accountNickName": null,
                    "accountStatus": null,
                    "accountCurrency": null,
                    "availableBalance": null,
                    "ledgerBalance": null,
                    "currentBalance": null,
                    "subUsrEnabled": null,
                    "acctFuncsAccess": null,
                    "deliveryOption": null,
                    "deliveryLocation": null,
                    "stmtPreferredLang": null,
                    "branchId": null,
                    "atmCardExist": null,
                    "signId": null,
                    "countryCode": null,
                    "bankCode": null,
                    "mnemonicName": null,
                    "updatesMap": [],
                    "parentsBO": {},
                    "parentLists": [],
                    "parentMaps": [],
                    "isFetched": true,
                    "updated": true, "recordStatus": null, "validated": false, "context": null
                },
                "buyingPwrAmt": {
                    "currencyCode": null,
                    "currencyRate": null,
                    "amount": "561979.123456",
                    "formatedAmount": null,
                    "localAmount": null
                },
                "closingBalAmt": {
                    "currencyCode": null,
                    "currencyRate": null,
                    "amount": "428008.91",
                    "formatedAmount": null,
                    "localAmount": null
                },
                "netSecurityAmt": {
                    "currencyCode": null,
                    "currencyRate": null,
                    "amount": "1901202323.55",
                    "formatedAmount": null,
                    "localAmount": null
                },
                "overdraftAmt": {
                    "currencyCode": null,
                    "currencyRate": null,
                    "amount": "0.00",
                    "formatedAmount": null, "localAmount": null
                },
                "blockedAmt": {
                    "currencyCode": null, "currencyRate": null, "amount": "20108.924", "formatedAmount": null, "localAmount": null
                },
                "usageAmt": {
                    "currencyCode": null, "currencyRate": null, "amount": "0.00", "formatedAmount": null, "localAmount": null
                },
                "avilLimitAmt": {
                    "currencyCode": null, "currencyRate": null, "amount": "0.00", "formatedAmount": null, "localAmount": null
                },
                "portfolioPostionAmt": {
                    "currencyCode": null, "currencyRate": null, "amount": "1901784412.41", "formatedAmount": null, "localAmount": null
                }
            },
            "currency": "SAR",
            "documentType": "LOCAL"
        }
    },
    '/Symbol/SymbolInquiry/getTodayPriceChange': 
    // params: {
    //  'symbolCode': "65301-1"
    // }
    {
        'status': "1",
        'result': [
            { "volumn": 32513, "lastTradeddTime": "10:00:00", "price": 6500 },
            { "volumn": 3536, "lastTradeddTime": "10:01:00", "price": 5900 },
            { "volumn": 67755, "lastTradeddTime": "10:02:00", "price": 8000 },
            { "volumn": 9460, "lastTradeddTime": "10:03:00", "price": 8100 },
            { "volumn": 15892, "lastTradeddTime": "10:04:00", "price": 2600 },
            { "volumn": 54708, "lastTradeddTime": "10:05:00", "price": 5500 },
            { "volumn": 39735, "lastTradeddTime": "10:06:00", "price": 4000 },
            { "volumn": 70220, "lastTradeddTime": "10:07:00", "price": 6005 },
            { "volumn": 48250, "lastTradeddTime": "10:08:00", "price": 5900 },
            { "volumn": 60604, "lastTradeddTime": "10:09:00", "price": 8000 },
            { "volumn": 8197, "lastTradeddTime": "10:10:00", "price": 5500 },
            { "volumn": 87177, "lastTradeddTime": "10:11:00", "price": 8000 },
            { "volumn": 41768, "lastTradeddTime": "10:12:00", "price": 5500 },
            { "volumn": 34900, "lastTradeddTime": "10:13:00", "price": 4000 },
            { "volumn": 93412, "lastTradeddTime": "10:14:00", "price": 6005 },
            { "volumn": 15627, "lastTradeddTime": "10:15:00", "price": 5900 },
            { "volumn": 166591, "lastTradeddTime": "10:17:00", "price": 8013 }
        ],
        _parameterized: [
            {
                params: {
                    'symbolID': 1111
                },
                response: {
                    'status': "1",
                    'result': {
                        'prices': [5500, 4000, 6005, 5900, 8000, 5500, 4000, 6005, 5900, 8013]
                    }
                }
            },
            {
                params: {
                    'symbolID': 2222
                },
                response: {
                    'status': "1",
                    'result': {
                        'prices': [4500, 8800, 1100, 1700, 2000, 8800, 4000, 6600, 5900, 8000, 1300, 40000, 9900, 7500, 1153]
                    }
                }
            },
            {
                params: {
                    'symbolID': 3333
                },
                response: {
                    'status': "1",
                    'result': {
                        'prices': [6500, 5900, 9500, 2700, 2600, 1100, 4000, 6500, 3200, 8000, 8700, 4000, 7700, 3400, 2822]
                    }
                }
            },
            {
                params: {
                    'symbolID': 4444
                },
                response: {
                    'status': "1",
                    'result': {
                        'prices': [2537, 4845, 9240, 1971, 6947, 2957, 4410, 2815, 6992, 1833, 7484, 5233, 6151, 4238, 8460]
                    }
                }
            },
            {
                params: {
                    'symbolID': 5555
                },
                response: {
                    'status': "1",
                    'result': {
                        'prices': [1308, 7765, 3188, 7256, 8478, 9032, 8373, 7612, 2522, 3329, 7931, 3772, 5704, 1696, 2723]
                    }
                }
            },
            {
                params: {
                    'symbolID': 6666
                },
                response: {
                    'status': "1",
                    'result': {
                        'prices': [8050, 6830, 3264, 5439, 2181, 5093, 9093, 3010, 5432, 3605, 2509, 7944, 8863, 5645, 4610]
                    }
                }
            },
            {
                params: {
                    'symbolID': 7777
                },
                response: {
                    'status': "1",
                    'result': {
                        'prices': [3925, 2346, 5466, 4389, 3700, 7711, 8421, 8004, 1775, 3598, 1291, 4266, 1773, 3211, 6700]
                    }
                }
            }
        ]
    },
    '/Symbol/SymbolInquiry/getSymbolCurrentInfo': 
    // params: {
    //  'symbolCode': "1150"
    // }
    {
        'status': "1",
        'msg': null,
        'result': {
            'lastUpdatedTime': "10-05-2018 12 36 32",
            'open': "10",
            'change': ".24",
            'percentChanged': "1.81",
            'cachePercent': "5.76691117345335946167713117063564498559E-01",
            'bidQty': "7578",
            'bidPrice': "13.46",
            'minPrice': "11.94",
            'lowPrice': "13.2",
            'maxPrice': "14.58",
            'highPrice': "13.56",
            'volumn': "5675019",
            'lastTradedPrice': "10",
            'noOfTrades': "1113",
            'askQty': "27234",
            'askPrice': "13.5",
            'lastTradeTime': "12:34:44"
        }
    },
    '/Symbol/SymbolInquiry/getPriceChangeInPeriod': 
    // {"symbolCode":"1150","period":"week"}
    {
        "status": "1",
        "msg": null,
        "result2": [
            { "volumn": 20, "lastTradeddTime": "10:09:00", "price": 128.4 },
            { "volumn": 70, "lastTradeddTime": "10:55:00", "price": 102.52 },
            { "volumn": 70, "lastTradeddTime": "11:23:00", "price": 141.48 }
        ],
        "result": [
            { "volumn": 32513, "lastTradeddTime": "10:00:00", "price": 10 },
            { "volumn": 3536, "lastTradeddTime": "10:01:00", "price": 9.8 },
            { "volumn": 67755, "lastTradeddTime": "10:02:00", "price": 9.2 },
            { "volumn": 9460, "lastTradeddTime": "10:03:00", "price": 10 },
            { "volumn": 15892, "lastTradeddTime": "10:04:00", "price": 10.3 },
            { "volumn": 54708, "lastTradeddTime": "10:05:00", "price": 9.5 },
            { "volumn": 39735, "lastTradeddTime": "10:06:00", "price": 10.5 },
            { "volumn": 70220, "lastTradeddTime": "10:07:00", "price": 10.8 },
            { "volumn": 48250, "lastTradeddTime": "10:08:00", "price": 10.9 },
            { "volumn": 60604, "lastTradeddTime": "10:09:00", "price": 11 },
            { "volumn": 8197, "lastTradeddTime": "10:10:00", "price": 10.1 },
            { "volumn": 87177, "lastTradeddTime": "10:11:00", "price": 9.3 },
            { "volumn": 41768, "lastTradeddTime": "10:12:00", "price": 9.3 },
            { "volumn": 34900, "lastTradeddTime": "10:13:00", "price": 9.6 },
            { "volumn": 93412, "lastTradeddTime": "10:14:00", "price": 10 },
            { "volumn": 15627, "lastTradeddTime": "10:15:00", "price": 10.2 },
            { "volumn": 166591, "lastTradeddTime": "10:17:00", "price": 9.0 }
        ]
    },
    '/Market/MarketDepthService/getMarketDepth': {
        "status": "1",
        "result": { "marketDepth": { "symbol": "4333", "bidPrice1": "12.14", "bidQty1": "1007", "bidSplit1": "2", "bidPrice2": "12.12", "bidQty2": "9447", "bidSplit2": "1", "bidPrice3": "12.1", "bidQty3": "824", "bidSplit3": "1", "bidPrice4": "12.08", "bidQty4": "864", "bidSplit4": "3", "bidPrice5": "12.06", "bidQty5": "1714", "bidSplit5": "7", "askPrice1": "12.18", "askQty1": "1801", "askSplit1": "1", "askPrice2": "12.2", "askQty2": "2860", "askSplit2": "4", "askPrice3": "12.22", "askQty3": "2745", "askSplit3": "2", "askPrice4": "12.24", "askQty4": "1582", "askSplit4": "3", "askPrice5": "12.26", "askQty5": "7939", "askSplit5": "3" }, "marketDepthDetails": null, "tradesList": [{ "symbol": "4333", "sequenceNo": "160909", "tradeTime": "14:59:38", "price": "12.14", "quantity": "1350", "change": ".04", "type": "S", "splits": "1", "exchangeCode": null }, { "symbol": "4333", "sequenceNo": "153046", "tradeTime": "14:47:56", "price": "12.14", "quantity": "2602", "change": ".04", "type": "S", "splits": "1", "exchangeCode": null }, { "symbol": "4333", "sequenceNo": "153045", "tradeTime": "14:47:56", "price": "12.16", "quantity": "300", "change": ".06", "type": "S", "splits": "1", "exchangeCode": null }, { "symbol": "4333", "sequenceNo": "153044", "tradeTime": "14:47:56", "price": "12.18", "quantity": "98", "change": ".08", "type": "S", "splits": "1", "exchangeCode": null }, { "symbol": "4333", "sequenceNo": "150138", "tradeTime": "14:42:39", "price": "12.18", "quantity": "1", "change": ".08", "type": "S", "splits": "1", "exchangeCode": null }, { "symbol": "4333", "sequenceNo": "148481", "tradeTime": "14:39:17", "price": "12.2", "quantity": "2", "change": ".1", "type": "B", "splits": "1", "exchangeCode": null }, { "symbol": "4333", "sequenceNo": "138868", "tradeTime": "14:18:47", "price": "12.18", "quantity": "1", "change": ".08", "type": "S", "splits": "1", "exchangeCode": null }, { "symbol": "4333", "sequenceNo": "135564", "tradeTime": "14:10:36", "price": "12.2", "quantity": "889", "change": ".1", "type": "S", "splits": "1", "exchangeCode": null }, { "symbol": "4333", "sequenceNo": "133090", "tradeTime": "14:04:37", "price": "12.2", "quantity": "111", "change": ".1", "type": "S", "splits": "1", "exchangeCode": null }, { "symbol": "4333", "sequenceNo": "131723", "tradeTime": "14:01:23", "price": "12.2", "quantity": "500", "change": ".1", "type": "S", "splits": "1", "exchangeCode": null }, { "symbol": "4333", "sequenceNo": "129968", "tradeTime": "13:57:49", "price": "12.2", "quantity": "1", "change": ".1", "type": "B", "splits": "1", "exchangeCode": null }, { "symbol": "4333", "sequenceNo": "129600", "tradeTime": "13:57:08", "price": "12.2", "quantity": "72", "change": ".1", "type": "B", "splits": "2", "exchangeCode": null }, { "symbol": "4333", "sequenceNo": "127080", "tradeTime": "13:52:13", "price": "12.2", "quantity": "700", "change": ".1", "type": "B", "splits": "1", "exchangeCode": null }, { "symbol": "4333", "sequenceNo": "126941", "tradeTime": "13:51:55", "price": "12.2", "quantity": "278", "change": ".1", "type": "S", "splits": "1", "exchangeCode": null }, { "symbol": "4333", "sequenceNo": "126576", "tradeTime": "13:51:11", "price": "12.2", "quantity": "11000", "change": ".1", "type": "S", "splits": "1", "exchangeCode": null }, { "symbol": "4333", "sequenceNo": "124514", "tradeTime": "13:46:57", "price": "12.2", "quantity": "250", "change": ".1", "type": "S", "splits": "1", "exchangeCode": null }, { "symbol": "4333", "sequenceNo": "123898", "tradeTime": "13:45:51", "price": "12.2", "quantity": "3", "change": ".1", "type": "S", "splits": "1", "exchangeCode": null }, { "symbol": "4333", "sequenceNo": "120440", "tradeTime": "13:39:03", "price": "12.2", "quantity": "224", "change": ".1", "type": "S", "splits": "1", "exchangeCode": null }, { "symbol": "4333", "sequenceNo": "119690", "tradeTime": "13:37:20", "price": "12.2", "quantity": "3245", "change": ".1", "type": "B", "splits": "5", "exchangeCode": null }, { "symbol": "4333", "sequenceNo": "119003", "tradeTime": "13:36:01", "price": "12.14", "quantity": "42", "change": ".04", "type": "B", "splits": "1", "exchangeCode": null }] },
        "msg": null
    }
};


/***/ }),

/***/ 63093:
/*!***************************************************!*\
  !*** ./src/environments/mocks/transfers.mocks.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TransfersMockedWebService": () => (/* binding */ TransfersMockedWebService)
/* harmony export */ });
var TransfersMockedWebService = {
    // Get Fund Types
    '/accounts/FundTransfers/loadFundTypes': {
        'status': "1",
        'msg': null,
        'result': [
            { id: "1", value: "To Partner Investment Account" },
            { id: "2", value: "To Partner Current Account" }
        ]
    },
    // Get All Accounts
    '/accounts/FundTransfers/getAccounts': {
        'status': "1",
        'result': [{ "accountLabel": "100001898017 - SAR - 5492098.39", "accountValue": "100001898017", "additionDisplayData": null, "currencyCode": "SAR", "currencyValue": "Saudi Arabia Riyals" },
            { "accountLabel": "100001898025 - SAR - 1010419.5", "accountValue": "100001898025", "additionDisplayData": null, "currencyCode": "SAR", "currencyValue": "Saudi Arabia Riyals" },
            { "accountLabel": "100001898033 - SAR - 100.0", "accountValue": "100001898033", "additionDisplayData": null, "currencyCode": "SAR", "currencyValue": "Saudi Arabia Riyals" },
            { "accountLabel": "100001898041 - SAR - 200.0", "accountValue": "100001898041", "additionDisplayData": null, "currencyCode": "SAR", "currencyValue": "Saudi Arabia Riyals" },
            { "accountLabel": "100001898068 - SAR - 300.0", "accountValue": "100001898068", "additionDisplayData": null, "currencyCode": "SAR", "currencyValue": "Saudi Arabia Riyals" },
            { "accountLabel": "100001898076 - SAR - 500.5", "accountValue": "100001898076", "additionDisplayData": null, "currencyCode": "SAR", "currencyValue": "Saudi Arabia Riyals" },
            { "accountLabel": "100001898084 - SAR - 500.5", "accountValue": "100001898084", "additionDisplayData": null, "currencyCode": "SAR", "currencyValue": "Saudi Arabia Riyals" },
            { "accountLabel": "100001898106 - SAR - 500.5", "accountValue": "100001898106", "additionDisplayData": null, "currencyCode": "SAR", "currencyValue": "Saudi Arabia Riyals" },
            { "accountLabel": "100001898114 - SAR - 500.5", "accountValue": "100001898114", "additionDisplayData": null, "currencyCode": "SAR", "currencyValue": "Saudi Arabia Riyals" },
            { "accountLabel": "100001898122 - SAR - 500.5", "accountValue": "100001898122", "additionDisplayData": null, "currencyCode": "SAR", "currencyValue": "Saudi Arabia Riyals" },
            { "accountLabel": "100001898130 - SAR - 500.5", "accountValue": "100001898130", "additionDisplayData": null, "currencyCode": "SAR", "currencyValue": "Saudi Arabia Riyals" },
            { "accountLabel": "100001898173 - SAR - 500.5", "accountValue": "100001898173", "additionDisplayData": null, "currencyCode": "SAR", "currencyValue": "Saudi Arabia Riyals" },
            { "accountLabel": "200001898058 - SAR - 500.5", "accountValue": "200001898058", "additionDisplayData": null, "currencyCode": "SAR", "currencyValue": "Saudi Arabia Riyals" },
            { "accountLabel": "200001898090 - SAR - 500.5", "accountValue": "200001898090", "additionDisplayData": null, "currencyCode": "SAR", "currencyValue": "Saudi Arabia Riyals" },
            { "accountLabel": "200001898163 - SAR - 500.5", "accountValue": "200001898163", "additionDisplayData": null, "currencyCode": "SAR", "currencyValue": "Saudi Arabia Riyals" }]
    },
    // Get All Beneficiary
    '/accounts/FundTransfers/getBeneficiaries': {
        'status': "1",
        'result': [{ "beneficiaryLabel": "Shadi Abdulrahman Khogahbkah", "beneficiaryValue": "11", "additionDisplayData": "SA3005000068200009899000", "currencyCode": "SAR", "currencyValue": "Saudi Arabia Riyals" },
            { "beneficiaryLabel": "aalsaikhTest", "beneficiaryValue": "7", "additionDisplayData": "SA5655000000085458200181", "currencyCode": "SAR", "currencyValue": "Saudi Arabia Riyals" },
            { "beneficiaryLabel": "ibrahem mohamed alrashed", "beneficiaryValue": "10", "additionDisplayData": "SA8905000068200002802000", "currencyCode": "SAR", "currencyValue": "Saudi Arabia Riyals" },
            { "beneficiaryLabel": "testNTest", "beneficiaryValue": "8", "additionDisplayData": "SA5655000000095626900107", "currencyCode": "SAR", "currencyValue": "Saudi Arabia Riyals" }]
    },
    // Get All Beneficiary
    '/accounts/FundTransfers/checkFundTransfer': {
        'status': "1",
        'result': {
            "fromAccount": { "accountNumber": "100001898033", "currentBalance": null, "currencyCode": "SAR", "currencyValue": null },
            "targetAccount": { "accountNumber": "100001898017", "currentBalance": null, "currencyCode": "SAR", "currencyValue": "Saudi Arabia Riyals" },
            "sourceAmount": { "amountValue": "111", "curCode": "SAR" },
            "convertedAmount": { "amountValue": null, "curCode": "SAR" },
            "fee": {
                "categoryCode": "2", "code": "W", "type": "ADSTFS",
                "feeAmount": { "amountValue": "8", "curCode": "Saudi Arabia Riyals" }
            },
            "memo": "", "reference": null, "transactionDate": "2018-05-12 19:06:59",
            "beneficiaryBank": "Al Rajhi Bank", "beneficiaryFullName": ""
        }
    },
    '/accounts/FundTransfers/confirmFundTransfers': {
        "status": "1",
        "msg": { "msgCode": "I000000", "msgType": "I", "msgText": "" },
        // Zero Groups
        'result': {
            'numOfGrps': 0,
            'groups': null
        }
    },
    // One Group
    // 'result': {
    //     "numOfGrps":1,
    //     "groups":[{"groupName":"2","methods":[{"methodName":"MOBILE_TOKEN","order":0,"methodLabel":"Activation code"}],"note":["Dear Partner: to login to Alinma App, please enter activation code that will be sent via SMS to your mobile number registered with alinma bank ","xxxxxxxx3538"],"timer":{"label":"Remaining to expiration of period allowed to enter the activation code:","value":300},"numOfTrials":3,"groupDescription":"SMS"}]}    
    // },
    // Two Groups
    // 'result': {
    //     "numOfGrps":2,
    //     "groups":[{"groupName":"1","methods":[{"methodName":"TOKEN","order":0,"methodLabel":"Activation Code"}],"note":["Please enter the generated activation code shown on your token device or application screen to complete your login",""],"numOfTrials":3,"groupDescription":"Alinma Token"},{"groupName":"2","methods":[{"methodName":"MOBILE_TOKEN","order":0,"methodLabel":"Activation code"}],"note":["Dear Partner: to login to Alinma App, please enter activation code that will be sent via SMS to your mobile number registered with alinma bank ","xxxxxxxx3538"],"timer":{"label":"Remaining to expiration of period allowed to enter the activation code:","value":300},"numOfTrials":3,"groupDescription":"SMS"}]}    
    // },
    // Generate 2nd level of authentication Token
    '/accounts/FundTransfers/generateTokens': {
        "status": "1", "msg": { "msgCode": "I000000", "msgType": "I", "msgText": "" }, "result": { "numOfGrps": 2, "groups": [{ "groupName": "1", "methods": [{ "methodName": "TOKEN", "order": 0, "methodLabel": "Activation Code" }], "note": ["Please enter the generated activation code shown on your token device or application screen to complete your login", ""], "numOfTrials": 3, "groupDescription": "Alinma Token" }, { "groupName": "2", "methods": [{ "methodName": "MOBILE_TOKEN", "order": 0, "methodLabel": "Activation code" }], "note": ["Dear Partner: to login to Alinma App, please enter activation code that will be sent via SMS to your mobile number registered with alinma bank ", "xxxxxxxx3538"], "timer": { "label": "Remaining to expiration of period allowed to enter the activation code:", "value": 300 }, "numOfTrials": 3, "groupDescription": "SMS" }] }
    },
    // Do the 2nd (final) level of authentication
    '/accounts/FundTransfers/authenticateFundTransfers': {
        "status": "1", "msg": { "msgCode": "I000000", "msgType": "I", "msgText": "" },
        "result": "FT1232SDKFNU",
        "result2": {
            "fromAccount": { "accountNumber": "100001898033", "currentBalance": "1054684", "currencyCode": "SAR", "currencyValue": null },
            "targetAccount": { "accountNumber": "100001898017", "currentBalance": "54651.25", "currencyCode": "SAR", "currencyValue": "Saudi Arabia Riyals" },
            "sourceAmount": { "amountValue": "111", "curCode": "SAR" },
            "convertedAmount": { "amountValue": null, "curCode": "SAR" },
            "fee": {
                "categoryCode": "2", "code": "W", "type": "ADSTFS",
                "feeAmount": { "amountValue": "0", "curCode": "Saudi Arabia Riyals" }
            },
            "memo": "", "reference": null, "transactionDate": "2018-05-12 19:06:59",
            "beneficiaryBank": "", "beneficiaryFullName": "",
            "referenceNumber": "FT1232SDKFNU"
        }
    }
};


/***/ }),

/***/ 47435:
/*!*****************************************!*\
  !*** ./src/helpers/background-timer.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BackgroundTimer": () => (/* binding */ BackgroundTimer)
/* harmony export */ });
class BackgroundTimer {
    constructor(interval, callback) {
        this.interval = interval;
        this.callback = callback;
    }
    start() {
        if (this.tickingEnabled) {
            this.startTicking();
        }
        this.timerID = setTimeout((function (_this) {
            return function () {
                _this.cancel();
                return _this.callback();
            };
        })(this), this.interval);
        document.addEventListener('resume', (function (_this) {
            return function () {
                return _this.wakeup();
            };
        })(this), false);
        this.expirationDate = Date.now() + this.interval;
        return this.running = true;
    }
    ;
    getRemaining() {
        return this.expirationDate - Date.now();
    }
    ;
    wakeup() {
        var remaining;
        if (this.running) {
            remaining = this.getRemaining();
            this.cancel();
            if (remaining > 0) {
                this.interval = remaining;
                const result = this.start();
                this.startTicking();
                return result;
            }
            else {
                this.callback();
                return this.cancel;
            }
        }
    }
    ;
    enableTicking(tickInterval, tickCallback) {
        this.tickInterval = tickInterval;
        this.tickCallback = tickCallback;
        return this.tickingEnabled = true;
    }
    ;
    pauseTicking() {
        if (this.tickerID) {
            clearInterval(this.tickerID);
            return this.tickerID = null;
        }
    }
    ;
    resumeTicking() {
        return this.startTicking();
    }
    ;
    roundTime(time) {
        return Math.floor((time + 100) / 1000) * 1000;
    }
    ;
    startTicking() {
        if (this.tickingEnabled) {
            return this.tickerID = setInterval((function (_this) {
                return function () {
                    return _this.tickCallback(_this.roundTime(_this.getRemaining()));
                };
            })(this), this.tickInterval);
        }
    }
    ;
    disableTicking() {
        if (this.tickerID) {
            this.tickingEnabled = false;
            clearInterval(this.tickerID);
            return this.tickerID = null;
        }
    }
    ;
    cancel() {
        if (this.running) {
            this.running = false;
            this.pauseTicking();
            clearTimeout(this.timerID);
            return this.timerID = null;
        }
    }
    ;
}


/***/ }),

/***/ 16406:
/*!**********************************!*\
  !*** ./src/helpers/biometric.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Biometric": () => (/* binding */ Biometric),
/* harmony export */   "BiometricHelper": () => (/* binding */ BiometricHelper)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var _ionic_native_keychain_touch_id_ngx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic-native/keychain-touch-id/ngx */ 11746);
/* harmony import */ var _injector__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./injector */ 19753);
/* harmony import */ var _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/models/users/authentication */ 93143);
/* harmony import */ var _dialogs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./dialogs */ 66695);
/* harmony import */ var _inma_models_authentication_authentication_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/models/authentication/authentication.model */ 83443);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @capacitor/core */ 26549);
/* harmony import */ var _translations__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./translations */ 69353);
/* harmony import */ var src_app_dynamic_authentication_dynamic_authentication_translations__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/dynamic-authentication/dynamic-authentication.translations */ 34229);
/* harmony import */ var _inma_environment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @inma/environment */ 80960);
/* harmony import */ var _capacitor_device__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @capacitor/device */ 4744);













class BiometricHelper {
    constructor() {
        this.t = src_app_dynamic_authentication_dynamic_authentication_translations__WEBPACK_IMPORTED_MODULE_7__.DynamicAuthenticationTranslations;
        this.biometricID = "AlinmaTadawulTouchID";
        this.enabled = false;
        this._supported = null;
    }
    get supported() {
        return this._supported;
    }
    set supported(s) {
        this._supported = s;
    }
    get isAvailableSync() {
        return this.supported;
    }
    get keychainTouchId() {
        return _injector__WEBPACK_IMPORTED_MODULE_1__.Injector.get(_ionic_native_keychain_touch_id_ngx__WEBPACK_IMPORTED_MODULE_0__.KeychainTouchId);
    }
    isEnabled() {
        return this.enabled;
    }
    initialize() {
        _capacitor_device__WEBPACK_IMPORTED_MODULE_9__.Device.getId().then(uuid => {
            this.deviceUUID = uuid;
            _capacitor_device__WEBPACK_IMPORTED_MODULE_9__.Device.getInfo().then(info => {
                this.device = info;
                if (_capacitor_core__WEBPACK_IMPORTED_MODULE_5__.Capacitor.platform == 'ios') {
                    this.setEnabled(true);
                }
                else if (_capacitor_core__WEBPACK_IMPORTED_MODULE_5__.Capacitor.platform == 'android') {
                    //!TODO needs revision
                    if (this.device.osVersion) {
                        var versionNumber = this.device.osVersion.substr(0, 3);
                        if (parseFloat(versionNumber) && parseFloat(versionNumber) != NaN && parseFloat(versionNumber) >= 6.0)
                            this.setEnabled(true);
                    }
                }
                else if (_inma_environment__WEBPACK_IMPORTED_MODULE_8__.Environment.isBiometricMockingEnabled) {
                    this.setEnabled(true);
                }
            });
        });
    }
    setEnabled(enabled) {
        this.enabled = enabled;
        if (enabled)
            this.initDeviceKey();
    }
    isAvailable() {
        return new rxjs__WEBPACK_IMPORTED_MODULE_10__.Observable(observer => {
            if (this.supported === null) {
                if (this.enabled) {
                    this.keychainTouchId.isAvailable().then(biometryType => {
                        this.type = (biometryType === "face") ? biometryType : "touch";
                        this.supported = true;
                        observer.next(true);
                        observer.complete();
                    }, err => {
                        if (_inma_environment__WEBPACK_IMPORTED_MODULE_8__.Environment.isBiometricMockingEnabled) {
                            this.type = 'face';
                            this.supported = true;
                            observer.next(true);
                            observer.complete();
                        }
                        else {
                            console.log(err);
                            this.supported = false;
                            observer.next(false);
                            observer.complete();
                        }
                    });
                }
                else {
                    // alert(`isAvailable() is not available !`)
                    this.supported = false;
                    observer.next(false);
                    observer.complete();
                }
            }
            else {
                if (this.supported)
                    observer.next(true);
                else
                    observer.next(false);
                observer.complete();
            }
        });
    }
    save(username) {
        return new rxjs__WEBPACK_IMPORTED_MODULE_10__.Observable(observer => {
            this.keychainTouchId.save(this.biometricID, username + '#:#' + this.deviceBiometricKey, true).then(result => {
                observer.next(true);
                observer.complete();
            }, err => {
                console.log(err);
                observer.next(false);
                observer.complete();
            });
        });
    }
    verify(messageKey) {
        return new rxjs__WEBPACK_IMPORTED_MODULE_10__.Observable(observer => {
            if (_inma_environment__WEBPACK_IMPORTED_MODULE_8__.Environment.isBiometricMockingEnabled) {
                setTimeout(() => {
                    // NOT_VERIFIED
                    // NOT_STORED
                    observer.next("keychainVerify = mustafah#:#ios30DAF12F-717B-4A45-8211-F479EB59759DiPhoneApple");
                    observer.complete();
                }, _inma_environment__WEBPACK_IMPORTED_MODULE_8__.Environment.biometricMockingPeriod);
                return;
            }
            this.isAvailable().subscribe(available => {
                if (available) {
                    this.isStored().subscribe(stored => {
                        if (stored) {
                            // this.translate.get("authentication." + this.type + messageKey).subscribe(value => {
                            this.keychainTouchId.verify(this.biometricID, this.t[this.type + messageKey]).then(result => {
                                //var storedUsername = result.split('#:#')[0];
                                //var storedKey = result.split('#:#')[1];
                                // console.log(`keychainVerify = ${result}`);
                                if (result)
                                    observer.next(result);
                                else
                                    observer.next("NOT_VERIFIED");
                                observer.complete();
                            }, err => {
                                var _a;
                                console.log(err);
                                observer.next(`Error: ${(err === null || err === void 0 ? void 0 : err.ErrorMessage) || ((_a = err === null || err === void 0 ? void 0 : err.toUpperCase) === null || _a === void 0 ? void 0 : _a.call(err))}`);
                                observer.complete();
                            });
                            // });
                        }
                        else {
                            observer.next("NOT_STORED");
                            observer.complete();
                        }
                    });
                }
                else {
                    observer.next("");
                    observer.complete();
                }
            });
        });
    }
    isStored() {
        return new rxjs__WEBPACK_IMPORTED_MODULE_10__.Observable(observer => {
            this.keychainTouchId.has(this.biometricID).then(() => {
                observer.next(true);
                observer.complete();
            }, () => {
                observer.next(false);
                observer.complete();
            });
        });
    }
    checkBiometricUsage() {
        return new rxjs__WEBPACK_IMPORTED_MODULE_10__.Observable(observer => {
            if (this.enabled) {
                this.isAvailable().subscribe(available => {
                    if (available) {
                        this.isStored().subscribe(stored => {
                            // Stored Password & User has touchIdAvailable
                            if (stored && _inma_models_users_authentication__WEBPACK_IMPORTED_MODULE_2__.Authentication2.touchIdAvailable) {
                                observer.next(false);
                                observer.complete();
                            }
                            else {
                                _dialogs__WEBPACK_IMPORTED_MODULE_3__.Dialogs.confirm(this.t[this.type + "StoreConfirm"]).subscribe(confirmed => {
                                    if (confirmed) {
                                        _dialogs__WEBPACK_IMPORTED_MODULE_3__.Dialogs.confirm(this.t.termsFingerPrint).subscribe(termsConfirmed => {
                                            if (termsConfirmed) {
                                                observer.next(true);
                                                observer.complete();
                                            }
                                            else {
                                                observer.next(false);
                                                observer.complete();
                                            }
                                        });
                                    }
                                    else {
                                        observer.next(false);
                                        observer.complete();
                                    }
                                });
                            }
                        });
                    }
                    else {
                        observer.next(false);
                        observer.complete();
                    }
                });
            }
            else {
                observer.next(false);
                observer.complete();
            }
        });
    }
    ;
    delete() {
        console.log('this.keychainTouchId.delete1');
        return new rxjs__WEBPACK_IMPORTED_MODULE_10__.Observable(observer => {
            console.log('this.keychainTouchId.delete2');
            this.keychainTouchId.delete(this.biometricID).then(() => {
                observer.next(true);
                observer.complete();
            }, () => {
                observer.next(false);
                observer.complete();
            });
        });
    }
    initDeviceKey() {
        if (this.device) {
            this.isAvailable().subscribe(available => {
                if (available) {
                    let touchKey = '';
                    touchKey = this.device.platform + this.deviceUUID.uuid + this.device.model + this.device.manufacturer;
                    if (_capacitor_core__WEBPACK_IMPORTED_MODULE_5__.Capacitor.platform == 'android') {
                        // TODO: Can not get it
                        // touchKey += this.device.serial;
                    }
                    this.deviceBiometricKey = touchKey.replace(/\s|,/g, '');
                }
            });
        }
    }
    ;
    encryptBiometricKey() {
        console.log("Regestration " + this.deviceBiometricKey);
        return _inma_models_authentication_authentication_model__WEBPACK_IMPORTED_MODULE_4__.Authentication.encrypt(this.deviceBiometricKey).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.map)(encryptedKey => {
            this.encryptedKey = encryptedKey;
            console.log("Regestration encrypted " + encryptedKey);
            return encryptedKey;
        }));
    }
    getDeviceInfo() {
        return this.encryptBiometricKey().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.map)(encryptedKey => {
            return { touchIdKey: encryptedKey, uuid: this.deviceUUID.uuid, platform: this.device.platform, manufacturer: this.device.manufacturer, model: this.device.model };
        }));
    }
    getDeviceUUID() {
        return { uuid: this.deviceUUID.uuid };
    }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([
    (0,_translations__WEBPACK_IMPORTED_MODULE_6__.Translations)(),
    (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Object)
], BiometricHelper.prototype, "t", void 0);
const Biometric = new BiometricHelper();


/***/ }),

/***/ 569:
/*!*******************************!*\
  !*** ./src/helpers/cached.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "cached": () => (/* binding */ cached),
/* harmony export */   "resetCache": () => (/* binding */ resetCache),
/* harmony export */   "resetGlobalCaches": () => (/* binding */ resetGlobalCaches)
/* harmony export */ });
/* harmony import */ var _inma_models_market__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/models/market */ 1874);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 61555);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 64139);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 47418);
/* harmony import */ var _strings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./strings */ 36782);




function cached(target, name, descriptor) {
    const getter = descriptor.get;
    if (!getter) {
        throw new TypeError('Getter property descriptor expected 😊');
    }
    descriptor.get = function () {
        const storeValue = this[`_${name.toString()}`];
        if (storeValue) {
            return storeValue;
        }
        else {
            let value = getter.call(this);
            if (value instanceof rxjs__WEBPACK_IMPORTED_MODULE_2__.Observable) {
                const valueSubject = new rxjs__WEBPACK_IMPORTED_MODULE_3__.ReplaySubject(1);
                value.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)(v => {
                    this[`cached${_strings__WEBPACK_IMPORTED_MODULE_1__.Strings.camelToPascalCase(name.toString())}`] = v;
                    return v;
                })).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(err => {
                    return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.of)('');
                })).subscribe(v => {
                    valueSubject.next(v);
                });
                value = valueSubject;
            }
            this[`_${name.toString()}`] = value;
            // Initialize
            if (!this[`_caches`])
                this[`_caches`] = new Set();
            // Add
            this[`_caches`].add(`_${name.toString()}`);
            cachedObjects.push(this);
            // define resetCaches
            if (!this[`resetCaches`]) {
                this[`resetCaches`] = () => {
                    for (const cacheName of this[`_caches`].values()) {
                        this[cacheName] = null;
                    }
                };
            }
            return value;
        }
    };
}
function resetCache(object, cacheName) {
    if (cacheName) {
        object[`_${cacheName}`] = null;
    }
    else {
        object === null || object === void 0 ? void 0 : object.resetCaches();
    }
}
var cachedObjects = [];
function resetGlobalCaches() {
    // console.log(`resetGlobalCaches()`);
    cachedObjects.forEach((cachedO) => {
        cachedO.resetCaches();
    });
    cachedObjects = [];
    //
    _inma_models_market__WEBPACK_IMPORTED_MODULE_0__.MarketModel.reset();
}


/***/ }),

/***/ 71286:
/*!**********************************!*\
  !*** ./src/helpers/clipboard.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Clipboard": () => (/* binding */ Clipboard)
/* harmony export */ });
class Clipboard {
    static copy(str, consoleLog = false) {
        const el = document.createElement('textarea'); // Create a <textarea> element
        el.value = str; // Set its value to the string that you want copied
        el.setAttribute('readonly', ''); // Make it readonly to be tamper-proof
        el.style.position = 'absolute';
        el.style.left = '-9999px'; // Move outside the screen to make it invisible
        document.body.appendChild(el); // Append the <textarea> element to the HTML document
        const selected = document.getSelection().rangeCount > 0 // Check if there is any content selected previously
            ? document.getSelection().getRangeAt(0) // Store selection if found
            : false; // Mark as false to know no selection existed before
        el.select(); // Select the <textarea> content
        document.execCommand('copy'); // Copy - only works as a result of a user action (e.g. click events)
        document.body.removeChild(el); // Remove the <textarea> element
        if (selected) { // If a selection existed before copying
            document.getSelection().removeAllRanges(); // Unselect everything on the HTML document
            document.getSelection().addRange(selected); // Restore the original selection
        }
        if (consoleLog) {
            console.log(str);
            console.log('🌽 Copied to clipboard !');
        }
    }
    ;
}


/***/ }),

/***/ 56031:
/*!********************************!*\
  !*** ./src/helpers/console.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Console": () => (/* binding */ Console)
/* harmony export */ });
/* harmony import */ var _inma_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/environment */ 80960);
/* harmony import */ var _strings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./strings */ 36782);
/* harmony import */ var tinygradient__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tinygradient */ 48655);
/* harmony import */ var tinygradient__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(tinygradient__WEBPACK_IMPORTED_MODULE_2__);



class Console {
    static separator(options) {
        Console.print(Object.assign({ message: '                                                                                                    ' }, options));
    }
    static logObservable(o, format) {
        o.subscribe((value) => {
            if (format)
                console.log(format, value);
            else
                console.log(value);
        });
    }
    static print(...printables) {
        let message = '';
        const styles = [];
        for (const printable of printables) {
            message += `%c${printable.message}`;
            if (!printable.color)
                printable.color = Console.defaultColor;
            if (!printable.background)
                printable.background = Console.defaultBackground;
            if (!printable.bold)
                printable.bold = Console.defaultBold;
            styles.push(`color: ${printable.color}; background: ${printable.background}; font-weight: ${printable.bold ? 'bold' : 'normal'}`);
        }
        console.log(message, ...styles);
    }
    static gradientSeparator(gradient) {
        if (_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.isProduction)
            return;
        Console.printGradient('                                                                                                    ', gradient);
    }
    //! Not yet refactored
    static default(options) {
        if (_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.isProduction)
            return;
        Console.defaultColor = options.color || '#00ABEC';
        Console.defaultBackground = options.background || 'white';
        Console.defaultBold = options.bold || false;
    }
    static printGradient(message, gradient) {
        if (_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.isProduction || !_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.isLoggingEnabled)
            return;
        const g = tinygradient__WEBPACK_IMPORTED_MODULE_2__(gradient);
        let output = '';
        const styles = [];
        for (let i = 0; i < message.length; i++) {
            output += `%c${message[i]}`;
            styles.push(`background: ${g.rgbAt(i / message.length).toHexString()};`);
            // background: ${printable.background}; font-weight: ${printable.bold ? 'bold' : 'normal'}`);
        }
        console.log(output, ...styles);
    }
    static printWithObject(object, options, ...printables) {
        var _a;
        if (_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.isProduction || !_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.isLoggingEnabled)
            return;
        let message = '';
        const parameters = [];
        for (const printable of printables) {
            if (printable.object && printable.message) {
                console.error('You should either provide a message or object in any IPrintable !');
            }
            if (printable.object)
                message += `%c%o`;
            else
                message += `%c${printable.message}`;
            if (!printable.color)
                printable.color = Console.defaultColor;
            if (!printable.background)
                printable.background = Console.defaultBackground;
            if (!printable.bold)
                printable.bold = Console.defaultBold;
            parameters.push(`color: ${printable.color}; background: ${printable.background}; font-weight: ${printable.bold ? 'bold' : 'normal'}`);
            if (printable.object)
                parameters.push(printable.object);
        }
        if (object) {
            console.groupCollapsed(message, ...parameters);
            for (const i in object) {
                if (object.hasOwnProperty(i) && i != 'trace') {
                    if (!options.highlight)
                        options.highlight = [];
                    let propertyStyle = '';
                    if (options.highlight.includes(i))
                        propertyStyle += 'font-weight: bold;';
                    else
                        propertyStyle += 'font-weight: normal;';
                    if ((_a = object[i]) === null || _a === void 0 ? void 0 : _a.collapsed) {
                        console.log(`%c ${_strings__WEBPACK_IMPORTED_MODULE_1__.Strings.padding(i, 16)}: %O`, propertyStyle, object[i].object);
                    }
                    else {
                        console.log(`%c ${_strings__WEBPACK_IMPORTED_MODULE_1__.Strings.padding(i, 16)}: %o`, propertyStyle, object[i]);
                    }
                }
            }
            if (object.trace) {
                console.groupCollapsed(' trace');
                console.log(object.trace);
                console.groupEnd();
            }
            else {
                console.groupCollapsed(' trace');
                console.trace(''); // hidden in collapsed group
                console.groupEnd();
            }
            console.groupEnd();
        }
        else {
            console.log(message, ...parameters);
        }
    }
    static printImage(url, size = 10) {
        if (_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.isProduction || !_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.isLoggingEnabled)
            return;
        const image = new Image();
        image.onload = function () {
            const style = [
                'font-size: 1px;',
                'padding: ' + this.height / 100 * size + 'px ' + this.width / 100 * size + 'px;',
                'background: url(' + url + ') no-repeat;',
                'background-size: contain;',
                'fill: green;'
            ].join(' ');
            console.log('%c ', style);
        };
        image.src = url;
    }
}
Console.Colors = {
    LightPink: '#FAD8D6',
    BlueCerulean: '#0077A5',
    GreenMalachite: '#14ce14',
    YellowParisDaisy: '#F9F047',
    BlueDeepSky: '#00ABEC',
    Yellow: '#f6d365'
};
Console.Gradients = {
    Lush: ['#56ab2f', '#a8e063'],
    SpringWarmth: ['#fad0c4', '#ffd1ff'],
    RareWind: ['#a8edea', '#fed6e3'],
    SkyGlider: ['#88d3ce', '#6e45e2'],
    HiddenJaguar: ['#0fd850', '#f9f047'],
    MagicRay: ['#FF3CAC', '#562B7C', '#2B86C5'],
    SeashoreGet: ['#209cff', '#68e0cf'],
    MarbleWallGet: ['#bdc2e8', '#e6dee9'],
    ColorfulPeachGet: ['#ed6ea0', '#ec8c69'],
    GentleCare: ['#ffc3a0', '#ffafbd'],
    SeaLord: ['#2CD8D5', '#C5C1FF', '#FFBAC3'],
    SleeplessNight: ['#5271C4', '#B19FFF', '#ECA1FE'],
    LandingAircraft: ['#5D9FFF', '#B8DCFF', '#6BBBFF'],
    Blessing: ['#fddb92', '#d1fdff'],
    NewYork: ['#fff1eb', '#ace0f9'],
    DeepBlue: ['#e0c3fc', '#8ec5fc'],
    SunnyMorning: ['#f6d365', '#fda085']
};
Console.defaultColor = '#00ABEC';
Console.defaultBackground = 'white';
Console.defaultBold = false;


/***/ }),

/***/ 1430:
/*!*****************************!*\
  !*** ./src/helpers/copy.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "deepCopy": () => (/* binding */ deepCopy)
/* harmony export */ });
function deepCopy(obj) {
    var copy;
    // Handle the 3 simple types, and null or undefined
    if (null == obj || "object" != typeof obj)
        return obj;
    // Handle Date
    if (obj instanceof Date) {
        copy = new Date();
        copy.setTime(obj.getTime());
        return copy;
    }
    // Handle Array
    if (obj instanceof Array) {
        copy = [];
        for (var i = 0, len = obj.length; i < len; i++) {
            copy[i] = deepCopy(obj[i]);
        }
        return copy;
    }
    // Handle Object
    if (obj instanceof Object) {
        copy = {};
        for (var attr in obj) {
            if (obj.hasOwnProperty(attr))
                copy[attr] = deepCopy(obj[attr]);
        }
        return copy;
    }
    throw new Error("Unable to copy obj! Its type isn't supported.");
}


/***/ }),

/***/ 70314:
/*!*****************************!*\
  !*** ./src/helpers/date.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "formatDate": () => (/* binding */ formatDate),
/* harmony export */   "formatTime": () => (/* binding */ formatTime)
/* harmony export */ });
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! moment */ 56908);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_0__);

function formatDate(date, format = 'YYYY-MM-DD') {
    return moment__WEBPACK_IMPORTED_MODULE_0__(date).format(format);
}
function formatTime(time, sourceFormat = 'hh:mm:ss a', targetFormat = 'HH:mm:ss') {
    if (time)
        return moment__WEBPACK_IMPORTED_MODULE_0__.utc(time, sourceFormat).format(targetFormat);
    else
        return '';
}


/***/ }),

/***/ 85367:
/*!****************************************!*\
  !*** ./src/helpers/dialogs/dialogs.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Dialogs": () => (/* binding */ Dialogs),
/* harmony export */   "DialogsHelper": () => (/* binding */ DialogsHelper)
/* harmony export */ });
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var _injector__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../injector */ 19753);




const ERROR_MIN_TIME_AMOUNT = 1000 * 10; // 60 seconds
class DialogsHelper {
    constructor() {
        this.mode = "ios";
        //   presentInfo(messageOptions: (String | { message: string })): Observable<boolean> {
        //     let messageKey = '', message;
        //     if (typeof messageOptions == 'string')
        //       messageKey = messageOptions;
        //     else
        //       message = (<any>messageOptions).message;
        //     return new Observable<boolean>(observer => {
        //       this.translate.get(["app.notification", "app.close", messageKey]).subscribe(
        //         value => {
        //           let shownMessage = message || value[messageKey];
        //           let autoAlignClass = Strings.isArabic(shownMessage) ? 'rtl' : 'ltr';
        //           let alert = this.alertCtrl.create({
        //             title: value["app.notification"],
        //             message: shownMessage,
        //             enableBackdropDismiss: false,
        //             cssClass: `info-alert ${autoAlignClass}`,
        //             buttons: [
        //               {
        //                 text: value["app.close"],
        //                 handler: () => {
        //                   observer.next(true);
        //                   observer.complete();
        //                   return;
        //                 }
        //               }
        //             ]
        //           });
        //           alert.present();
        //         });
        //     });
        //   }
        //   presentConfirmDelete(messageKey: string): Observable<boolean> {
        //     return new Observable<boolean>(observer => {
        //       this.translate.get(["app.confirmDelete", "app.yes", "app.no", messageKey]).subscribe(
        //         value => {
        //           let alert = this.alertCtrl.create({
        //             title: value["app.confirmDelete"],
        //             message: value[messageKey],
        //             buttons: [
        //               {
        //                 text: value["app.yes"],
        //                 handler: () => {
        //                   observer.next(true);
        //                   observer.complete();
        //                   return;
        //                 }
        //               },
        //               {
        //                 text: value["app.no"],
        //                 role: 'cancel',
        //                 handler: () => {
        //                   observer.next(false);
        //                   observer.complete();
        //                   return;
        //                 }
        //               }
        //             ]
        //           });
        //           alert.present();
        //         });
        //     });
        //   }
    }
    //  constructor(public platform: Platform) { }
    //   static errorsHistory: IErrorsHistory = {};
    //   presentError(messageKey: string, showCloseButton?: boolean, showWithDuration?: boolean, options?) {
    //     options = options || {};
    //     if (AlertHandlerProvider.errorsHistory[messageKey]) {
    //       if (AlertHandlerProvider.errorsHistory[messageKey].opened) {
    //         return;
    //       } else if (!options.minTimeDisabled) {
    //         const now = new Date().getTime();
    //         const history = AlertHandlerProvider.errorsHistory[messageKey].date.getTime();
    //         if ((now - history) < ERROR_MIN_TIME_AMOUNT)
    //           return;
    //       }
    //     }
    //     AlertHandlerProvider.errorsHistory[messageKey] = { date: new Date(), opened: true };
    //     this.presentToast(messageKey, showCloseButton, showWithDuration, options);
    //   }
    //   presentToast(messageKey: string, showCloseButton?: boolean, showWithDuration?: boolean, options?) {
    //     options = options || {};
    //     if (options['dismissOnPageChange'] === undefined)
    //       options['dismissOnPageChange'] = true;
    //     this.translate.get([messageKey, "app.close"]).subscribe(
    //       value => {
    //         let toast = this.toastCtrl.create({
    //           message: value[messageKey],
    //           duration: showWithDuration ? 300000 : 10000,
    //           position: 'bottom',
    //           showCloseButton: true /*showCloseButton*/,
    //           closeButtonText: value["app.close"],
    //           dismissOnPageChange: options['dismissOnPageChange'],
    //           cssClass: "opacity:0.6;",
    //         });
    //         toast.onDidDismiss(() => {
    //           if (AlertHandlerProvider.errorsHistory[messageKey])
    //             AlertHandlerProvider.errorsHistory[messageKey].opened = false;
    //         });
    //         toast.present().then(options['callback']);
    //       });
    //   }
    get translateService() {
        return _injector__WEBPACK_IMPORTED_MODULE_0__.Injector.get(_ngx_translate_core__WEBPACK_IMPORTED_MODULE_1__.TranslateService);
    }
    get alertController() {
        return _injector__WEBPACK_IMPORTED_MODULE_0__.Injector.get(_ionic_angular__WEBPACK_IMPORTED_MODULE_2__.AlertController);
    }
    get platform() {
        return _injector__WEBPACK_IMPORTED_MODULE_0__.Injector.get(_ionic_angular__WEBPACK_IMPORTED_MODULE_2__.Platform);
    }
    confirm(messageKey, confirmMessage, ignore) {
        if (this.platform.is("ios")) {
            this.mode = "ios";
        }
        else {
            this.mode = "md";
        }
        ;
        return new rxjs__WEBPACK_IMPORTED_MODULE_3__.Observable(observer => {
            this.alertController.create({
                header: confirmMessage || this.translateService.instant('app.CONFIRM'),
                message: messageKey || 'Are you sure ?',
                buttons: [
                    {
                        text: this.translateService.instant('app.CANCEL'),
                        role: 'cancel',
                        handler: () => {
                            observer.next(false);
                            observer.complete();
                            return;
                        }
                    },
                    {
                        text: ignore ? this.translateService.instant('app.IGNORE') : this.translateService.instant('app.OK'),
                        handler: () => {
                            observer.next(true);
                            observer.complete();
                            return;
                        }
                    }
                ],
                mode: this.mode
            }).then(alert => alert.present());
        });
    }
    alert(messageKey) {
        if (this.platform.is("ios")) {
            this.mode = "ios";
        }
        else {
            this.mode = "md";
        }
        ;
        return new rxjs__WEBPACK_IMPORTED_MODULE_3__.Observable(observer => {
            this.alertController.create({
                header: this.translateService.instant('app.alertHeader'),
                message: messageKey || 'Alert ?',
                buttons: [
                    {
                        text: this.translateService.instant('app.alertOK'),
                        role: 'cancel',
                        handler: () => {
                            observer.next(false);
                            observer.complete();
                            return;
                        }
                    }
                ],
                mode: this.mode
            }).then(alert => alert.present());
        });
    }
}
const Dialogs = new DialogsHelper();


/***/ }),

/***/ 66695:
/*!**************************************!*\
  !*** ./src/helpers/dialogs/index.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Dialogs": () => (/* reexport safe */ _dialogs__WEBPACK_IMPORTED_MODULE_0__.Dialogs),
/* harmony export */   "DialogsHelper": () => (/* reexport safe */ _dialogs__WEBPACK_IMPORTED_MODULE_0__.DialogsHelper)
/* harmony export */ });
/* harmony import */ var _dialogs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dialogs */ 85367);



/***/ }),

/***/ 79461:
/*!*******************************!*\
  !*** ./src/helpers/emojis.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Emoji": () => (/* binding */ Emoji)
/* harmony export */ });
var Emoji;
(function (Emoji) {
    Emoji["InboxTray"] = "\uD83D\uDCE5";
    Emoji["OutboxTray"] = "\uD83D\uDCE4";
    Emoji["Honeybee"] = "\uD83D\uDC1D";
    Emoji["Seedling"] = "\uD83C\uDF31";
    Emoji["Satellite"] = "\uD83D\uDCE1";
    Emoji["Bank"] = "\uD83C\uDFE6";
})(Emoji || (Emoji = {}));


/***/ }),

/***/ 1247:
/*!*********************************!*\
  !*** ./src/helpers/encoding.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Encryption": () => (/* binding */ Encryption)
/* harmony export */ });
/* harmony import */ var big_integer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! big-integer */ 95188);
/* harmony import */ var big_integer__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(big_integer__WEBPACK_IMPORTED_MODULE_0__);

class Encryption {
    /**
     * keys:
     *	- 0: enabled
     * 	- 1: public key
     * 	- 2: modules key
     *  - 3: tokens separator
     *	- 4: encoded value prefix
     * @param value
     * @param keys
     * @returns
     */
    static encrypt(value, keys) {
        try {
            if (value == null || value.trim().length == 0) {
                return value;
            }
            keys = this.Base64.decode(keys);
            keys = keys.replace("[", "").replace("]", "").split(",");
            var enabled = keys[0].trim();
            if (enabled == "true") {
                var publicKey = big_integer__WEBPACK_IMPORTED_MODULE_0__(keys[1].trim());
                var modulus = big_integer__WEBPACK_IMPORTED_MODULE_0__(keys[2].trim());
                var separator = keys[3].trim();
                var prefix = keys[4].trim();
                var encryptor;
                var encryptorVal;
                var pass = prefix + "";
                for (var _index_char_password = 0; _index_char_password < value.length; _index_char_password++) {
                    encryptor = big_integer__WEBPACK_IMPORTED_MODULE_0__(value.charCodeAt(_index_char_password));
                    encryptorVal = encryptor.modPow(publicKey, modulus);
                    pass = pass + encryptorVal + separator;
                }
                pass = pass.substring(0, pass.length - 1);
                return this.Base64.encode(pass);
            }
        }
        catch (err) {
            console.log(err);
        }
        return value;
    }
}
Encryption.Base64 = {
    _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
    encode: function (input) {
        var output = "";
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
        var i = 0;
        input = this._utf8_encode(input);
        while (i < input.length) {
            chr1 = input.charCodeAt(i++);
            chr2 = input.charCodeAt(i++);
            chr3 = input.charCodeAt(i++);
            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;
            if (isNaN(chr2)) {
                enc3 = enc4 = 64;
            }
            else if (isNaN(chr3)) {
                enc4 = 64;
            }
            output = output + this._keyStr.charAt(enc1)
                + this._keyStr.charAt(enc2) + this._keyStr.charAt(enc3)
                + this._keyStr.charAt(enc4);
        }
        return output;
    },
    decode: function (input) {
        var output = "";
        var chr1, chr2, chr3;
        var enc1, enc2, enc3, enc4;
        var i = 0;
        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
        while (i < input.length) {
            enc1 = this._keyStr.indexOf(input.charAt(i++));
            enc2 = this._keyStr.indexOf(input.charAt(i++));
            enc3 = this._keyStr.indexOf(input.charAt(i++));
            enc4 = this._keyStr.indexOf(input.charAt(i++));
            chr1 = (enc1 << 2) | (enc2 >> 4);
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
            chr3 = ((enc3 & 3) << 6) | enc4;
            output = output + String.fromCharCode(chr1);
            if (enc3 != 64) {
                output = output + String.fromCharCode(chr2);
            }
            if (enc4 != 64) {
                output = output + String.fromCharCode(chr3);
            }
        }
        output = this._utf8_decode(output);
        return output;
    },
    _utf8_encode: function (string) {
        string = string.replace(/\r\n/g, "\n");
        var utftext = "";
        for (var n = 0; n < string.length; n++) {
            var c = string.charCodeAt(n);
            if (c < 128) {
                utftext += String.fromCharCode(c);
            }
            else if ((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            }
            else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }
        }
        return utftext;
    },
    _utf8_decode: function (utftext) {
        var string = "";
        var i = 0;
        var c = 0, c1 = 0, c2 = 0, c3;
        while (i < utftext.length) {
            c = utftext.charCodeAt(i);
            if (c < 128) {
                string += String.fromCharCode(c);
                i++;
            }
            else if ((c > 191) && (c < 224)) {
                c2 = utftext.charCodeAt(i + 1);
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                i += 2;
            }
            else {
                c2 = utftext.charCodeAt(i + 1);
                c3 = utftext.charCodeAt(i + 2);
                string += String.fromCharCode(((c & 15) << 12)
                    | ((c2 & 63) << 6) | (c3 & 63));
                i += 3;
            }
        }
        return string;
    },
    //Convert a base64 string in a Blob according to the data and contentType.
    toBlob: function (b64Data, contentType) {
        contentType = contentType || '';
        var sliceSize = 512;
        //decode base64 data
        var byteCharacters = atob(b64Data);
        var byteArrays = [];
        for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
            var slice = byteCharacters.slice(offset, offset + sliceSize);
            var byteNumbers = new Array(slice.length);
            for (var i = 0; i < slice.length; i++) {
                byteNumbers[i] = slice.charCodeAt(i);
            }
            var byteArray = new Uint8Array(byteNumbers);
            byteArrays.push(byteArray);
        }
        var blob = new Blob(byteArrays, { type: contentType });
        return blob;
    }
};


/***/ }),

/***/ 96245:
/*!*****************************!*\
  !*** ./src/helpers/file.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Files": () => (/* binding */ Files)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic-native/file/ngx */ 12358);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _encoding__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./encoding */ 1247);
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ 23081);
/* harmony import */ var _capacitor_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @capacitor/browser */ 18313);
/* harmony import */ var _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/in-app-browser/ngx */ 49048);








let Files = class Files {
    constructor(iab, plt, file, fileOpener) {
        this.iab = iab;
        this.plt = plt;
        this.file = file;
        this.fileOpener = fileOpener;
    }
    openBase64File(value) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            if (value && value != null && value != '') {
                var dataBlob = _encoding__WEBPACK_IMPORTED_MODULE_1__.Encryption.Base64.toBlob(value, "application/pdf");
                var downloadURL = (window.webkitURL || window.URL).createObjectURL(dataBlob);
                if (this.plt.is('ios')) {
                    const a = this.iab.create(downloadURL, "_blank", "usewkwebview=yes,location=no,enableViewportScale=yes,clearcache=yes");
                    yield a.show();
                }
                else if (this.plt.is('android')) {
                    let path = this.file.externalDataDirectory;
                    this.file.checkFile(path, 'file.pdf').then((check) => {
                        if (check) {
                            this.file.removeFile(path, 'file.pdf');
                        }
                    }).finally(() => {
                        this.file.writeFile(path, 'file.pdf', dataBlob).then(() => {
                            this.fileOpener.open(path + 'file.pdf', "application/pdf");
                        });
                    });
                }
                else {
                    var downloadURL = (window.webkitURL || window.URL).createObjectURL(dataBlob);
                    _capacitor_browser__WEBPACK_IMPORTED_MODULE_3__.Browser.open({
                        url: downloadURL
                    });
                }
            }
        });
    }
};
Files.ctorParameters = () => [
    { type: _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_4__.InAppBrowser },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.Platform },
    { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_0__.File },
    { type: _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_2__.FileOpener }
];
Files = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Injectable)({
        providedIn: 'root'
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:paramtypes", [_ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_4__.InAppBrowser,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.Platform,
        _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_0__.File,
        _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_2__.FileOpener])
], Files);



/***/ }),

/***/ 70802:
/*!**********************************************!*\
  !*** ./src/helpers/http/http-device-info.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HttpDeviceInfo": () => (/* binding */ HttpDeviceInfo)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _partial__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../partial */ 45769);
/* harmony import */ var _capacitor_device__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @capacitor/device */ 4744);



let HttpDeviceInfo = class HttpDeviceInfo {
    onInit() {
        this.uuid = '0000000000';
        this.device = navigator.platform.replace(/\s/g, '') + '*' + navigator.product.replace(/\s/g, '') + '*' + navigator.vendor.replace(/\s/g, '');
        this.platform = navigator.platform;
        _capacitor_device__WEBPACK_IMPORTED_MODULE_1__.Device.getId().then(deviceId => {
            _capacitor_device__WEBPACK_IMPORTED_MODULE_1__.Device.getInfo().then(device => {
                this.device = device.platform + '*' + device.osVersion + '*' + device.model;
                this.platform = device.platform;
                if (this.platform == 'ios') {
                    this.uuid =
                        device.platform + device.osVersion + deviceId.uuid + device.model + device.manufacturer;
                }
                else if (this.platform == 'android') {
                    this.uuid =
                        device.platform + device.osVersion + deviceId.uuid + device.model + device.manufacturer + deviceId.uuid;
                }
            });
        });
        //!TODO this need to be checked
        // if ((window as any).cordova) {
        //   Device.getInfo().then(device => {
        //     this.device = device.platform + '*' + device.version + '*' + device.model;
        //     this.platform = device.platform;
        //     if (platform.is('ios')) {
        //       this.uuid =
        //         device.platform + device.version + device.uuid + device.model + device.manufacturer;
        //     }
        //     else if (platform.is('android')) {
        //       this.uuid =
        //         device.platform + device.version + device.uuid + device.model + device.manufacturer + device.uuid;
        //     }
        //   });
        // } else {
        // this.uuid = '0000000000';
        // this.device = navigator.platform.replace(/\s/g, '') + '*' + navigator.product.replace(/\s/g, '') + '*' + navigator.vendor.replace(/\s/g, '');
        // this.platform = navigator.platform;
        // }
    }
};
HttpDeviceInfo = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    _partial__WEBPACK_IMPORTED_MODULE_0__.partial
], HttpDeviceInfo);



/***/ }),

/***/ 30081:
/*!****************************************!*\
  !*** ./src/helpers/http/http-error.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HttpError": () => (/* binding */ HttpError)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _partial__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../partial */ 45769);


let HttpError = class HttpError {
    //! Should be done in enumberations
    handle(error) {
        let message = '';
        if (error.error instanceof ErrorEvent) {
            // A client-side or network error occurred. Handle it accordingly.
            message = 'networkError';
        }
        else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong,
        }
        if (error.status === 0 && error.statusText === 'error') {
            message = 'networkError';
        }
        else if (error.status === 404) {
            message = 'serviceNotAvailable';
        }
        else if (error.status === 500) {
            message = 'serverError';
        }
        else if (error.statusText === 'parsererror') {
            message = 'Requested JSON parse failed.';
        }
        else if (error.statusText === 'timeout') {
            message = 'timeoutError';
        }
        else if (error.statusText === 'abort') {
            message = 'networkError';
        }
        else if (error.status === 0) {
            message = 'networkError';
        }
        else {
            message = 'Uncaught Error.\n' + error.message;
        }
        return message;
    }
};
HttpError = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    _partial__WEBPACK_IMPORTED_MODULE_0__.partial
], HttpError);



/***/ }),

/***/ 55401:
/*!*************************************************!*\
  !*** ./src/helpers/http/http-request-header.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HttpRequestHeader": () => (/* binding */ HttpRequestHeader),
/* harmony export */   "RequestHeader": () => (/* binding */ RequestHeader)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _inma_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/environment */ 80960);
/* harmony import */ var _partial__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../partial */ 45769);
/* harmony import */ var _http_device_info__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./http-device-info */ 70802);
/* harmony import */ var _settings__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../settings */ 96892);





class RequestHeader {
    constructor() {
        this.lang = 'ar';
        this.stamp = new Date();
    }
}
let HttpRequestHeader = class HttpRequestHeader {
    constructor(deviceInfo) {
        this.deviceInfo = deviceInfo;
    }
    get(endPoint) {
        const requestHeader = new RequestHeader();
        const deviceInfo = this.deviceInfo;
        requestHeader.service = endPoint.split('/')[1];
        requestHeader.action = endPoint.split('/')[2];
        if (endPoint.split('/').length > 3)
            requestHeader.subaction = endPoint.split('/')[3];
        requestHeader.lang = localStorage.getItem(_settings__WEBPACK_IMPORTED_MODULE_3__.Settings.preferedLanguageKey) ? localStorage.getItem(_settings__WEBPACK_IMPORTED_MODULE_3__.Settings.preferedLanguageKey) : 'ar';
        requestHeader.uuid = deviceInfo.uuid;
        requestHeader.device = deviceInfo.device;
        requestHeader.platform = deviceInfo.platform;
        requestHeader.appVersion = _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.appVersion;
        requestHeader.codeVersion = '';
        requestHeader.csrfToken = '';
        requestHeader.appVersion = _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.appVersion;
        return requestHeader;
    }
};
HttpRequestHeader = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    _partial__WEBPACK_IMPORTED_MODULE_1__.partial,
    (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__metadata)("design:paramtypes", [_http_device_info__WEBPACK_IMPORTED_MODULE_2__.HttpDeviceInfo])
], HttpRequestHeader);



/***/ }),

/***/ 99128:
/*!*****************************************!*\
  !*** ./src/helpers/http/http.module.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InHttpModule": () => (/* binding */ InHttpModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 28784);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);



let InHttpModule = class InHttpModule {
};
InHttpModule = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgModule)({
        declarations: [],
        imports: [
            _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClientModule
        ],
        providers: [],
        exports: [],
        bootstrap: []
    })
], InHttpModule);



/***/ }),

/***/ 38474:
/*!**********************************!*\
  !*** ./src/helpers/http/http.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Http": () => (/* binding */ Http)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _inma_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/environment */ 80960);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs */ 61555);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs */ 64139);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs */ 24383);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! rxjs */ 9906);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! rxjs */ 66587);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! rxjs/operators */ 19019);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! rxjs/operators */ 47418);
/* harmony import */ var _response__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./response */ 30109);
/* harmony import */ var _partial__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../partial */ 45769);
/* harmony import */ var _http_device_info__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./http-device-info */ 70802);
/* harmony import */ var _http_request_header__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./http-request-header */ 55401);
/* harmony import */ var _http_error__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./http-error */ 30081);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/common/http */ 28784);
/* harmony import */ var _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @inma/helpers/injector */ 19753);
/* harmony import */ var _console__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../console */ 56031);
/* harmony import */ var _emojis__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../emojis */ 79461);
/* harmony import */ var _environments_mocks_mocks__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../environments/mocks/mocks */ 94474);
/* harmony import */ var _ionic_native_http_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/http/ngx */ 44719);
/* harmony import */ var _ionic_native_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/core */ 68751);
/* harmony import */ var src_environments_mocks_authentication_mocks__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/environments/mocks/authentication.mocks */ 84110);
/* harmony import */ var _settings__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../settings */ 96892);
/* harmony import */ var src_app_app_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/app.component */ 20721);



















// Resolution for the buyingPower come as undefined
// Resolution for Portfolios come as emptyArray
// Adding mocks for mutualFunds for portfolios that does not have them
let HttpHelper = class HttpHelper {
    constructor() {
        this.sessionExpirySubject = new rxjs__WEBPACK_IMPORTED_MODULE_15__.ReplaySubject();
        this.requestsSubjects = new Map();
        this.httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_16__.HttpHeaders({
                "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
                "Accept-Charset": "UTF-8",
                responseType: "json",
            }),
            withCredentials: true,
        };
        this.ـisNativeHttpAvailable = null;
        this.deviceInfo = new _http_device_info__WEBPACK_IMPORTED_MODULE_3__.HttpDeviceInfo();
        this.requestHeader = new _http_request_header__WEBPACK_IMPORTED_MODULE_4__.HttpRequestHeader(this.deviceInfo);
        this.httpError = new _http_error__WEBPACK_IMPORTED_MODULE_5__.HttpError();
    }
    get httpClient() {
        return _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_6__.Injector.get(_angular_common_http__WEBPACK_IMPORTED_MODULE_16__.HttpClient);
    }
    get httpNative() {
        return _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_6__.Injector.get(_ionic_native_http_ngx__WEBPACK_IMPORTED_MODULE_10__.HTTP);
    }
    request(endPoint, params = {}, options) {
        var _a, _b, _c, _d;
        var calleeStack;
        if (_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.isDevelopment)
            calleeStack = new Error().stack;
        const requestKey = endPoint + JSON.stringify(params);
        if (this.requestsSubjects.has(requestKey))
            return this.requestsSubjects.get(requestKey);
        else {
            const requestHeader = this.requestHeader.get(endPoint);
            const headerParam = JSON.stringify(requestHeader);
            const bodyParam = JSON.stringify(params);
            const requestSubject = new rxjs__WEBPACK_IMPORTED_MODULE_15__.ReplaySubject(1);
            this.requestsSubjects.set(requestKey, requestSubject);
            //# region Logging [request]
            if (_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.isLoggingAjaxEnabled) {
                _console__WEBPACK_IMPORTED_MODULE_7__.Console.gradientSeparator(_console__WEBPACK_IMPORTED_MODULE_7__.Console.Gradients.DeepBlue);
                _console__WEBPACK_IMPORTED_MODULE_7__.Console["default"]({ color: _console__WEBPACK_IMPORTED_MODULE_7__.Console.Colors.BlueDeepSky });
                _console__WEBPACK_IMPORTED_MODULE_7__.Console.printWithObject({
                    params,
                    baseURL: _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.webserviceURL,
                    timestamp: Date.now(),
                    header: { object: requestHeader, collapsed: true },
                    trace: calleeStack,
                }, {}, { message: `${_emojis__WEBPACK_IMPORTED_MODULE_8__.Emoji.Honeybee} [request](` }, { message: endPoint, bold: true }, { message: `)` });
            }
            //#endregion
            let httpRequestObservable = null;
            let mockedRequestObservable = null;
            if (_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.isDevelopment && ((_a = _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment === null || _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment === void 0 ? void 0 : _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.mocking) === null || _a === void 0 ? void 0 : _a.enabled))
                if (_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.isBiometricMockingEnabled &&
                    !_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.mocking._biometricMockingInjected) {
                    _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.mocking._biometricMockingInjected = true;
                    (_c = (_b = _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.mocking) === null || _b === void 0 ? void 0 : _b.mocks) === null || _c === void 0 ? void 0 : _c.push(...Object.keys(src_environments_mocks_authentication_mocks__WEBPACK_IMPORTED_MODULE_12__.AuthenticationMocks));
                }
            if ((_d = _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.mocking.mocks) === null || _d === void 0 ? void 0 : _d.find((mock) => mock.toLowerCase().trim() === endPoint.toLowerCase())) {
                const normalizedEndPoint = Object.keys(_environments_mocks_mocks__WEBPACK_IMPORTED_MODULE_9__.MockedWebService).find((key) => key.toLowerCase() === endPoint.toLowerCase());
                const mockedResponse = _environments_mocks_mocks__WEBPACK_IMPORTED_MODULE_9__.MockedWebService === null || _environments_mocks_mocks__WEBPACK_IMPORTED_MODULE_9__.MockedWebService === void 0 ? void 0 : _environments_mocks_mocks__WEBPACK_IMPORTED_MODULE_9__.MockedWebService[normalizedEndPoint];
                if (mockedResponse)
                    mockedRequestObservable = (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.of)(mockedResponse);
                else
                    console.error(`${_emojis__WEBPACK_IMPORTED_MODULE_8__.Emoji.Bank} Mock was not found, fallback to HTTP call !`);
            }
            // if (!mockedRequestObservable)
            //   httpRequestObservable = this.httpClient.post<Response<T>>(Environment.webserviceURL, requestParams, this.httpOptions);
            if (!mockedRequestObservable) {
                if (!this.isNativeHttpAvailable()) {
                    const requestParams = "Header=" +
                        encodeURIComponent(headerParam) +
                        "&Body=" +
                        encodeURIComponent(bodyParam);
                    httpRequestObservable = this.httpClient.post(_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.webserviceURL, requestParams, this.httpOptions);
                }
                else {
                    const requestParamsNative = {
                        Header: headerParam,
                        Body: bodyParam,
                    };
                    window.httpNative = this.httpNative;
                    this.httpNative.setDataSerializer("urlencoded");
                    httpRequestObservable = (0,rxjs__WEBPACK_IMPORTED_MODULE_18__.from)(this.httpNative.post(_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.webserviceURL, requestParamsNative, {
                        responseType: "json",
                        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
                        "Accept-Charset": "UTF-8"
                    })).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.map)((res) => JSON.parse(res === null || res === void 0 ? void 0 : res.data)));
                }
            }
            const languageIndex = _settings__WEBPACK_IMPORTED_MODULE_13__.Settings.languageAsString == "ar" ? 0 : 1;
            (mockedRequestObservable || httpRequestObservable)
                .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_20__.timeout)(_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.http.timeout), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.map)((httpResponse) => {
                var _a, _b, _c;
                this.requestsSubjects.delete(requestKey);
                const response = new _response__WEBPACK_IMPORTED_MODULE_1__.Response();
                response.status = httpResponse === null || httpResponse === void 0 ? void 0 : httpResponse.status;
                response.result = httpResponse === null || httpResponse === void 0 ? void 0 : httpResponse.result;
                response.msg = httpResponse === null || httpResponse === void 0 ? void 0 : httpResponse.msg;
                // if (response?.result && typeof response.result == "object") (<any>response.result)._message = httpResponse?.msg;
                //# region Logging [response]
                if (_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.isLoggingAjaxEnabled) {
                    if (mockedRequestObservable) {
                        _console__WEBPACK_IMPORTED_MODULE_7__.Console.gradientSeparator(_console__WEBPACK_IMPORTED_MODULE_7__.Console.Gradients.SunnyMorning);
                        _console__WEBPACK_IMPORTED_MODULE_7__.Console["default"]({ color: _console__WEBPACK_IMPORTED_MODULE_7__.Console.Colors.Yellow });
                        _console__WEBPACK_IMPORTED_MODULE_7__.Console.printWithObject({
                            response: response === null || response === void 0 ? void 0 : response.result,
                            params,
                            baseURL: _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.webserviceURL,
                            timestamp: Date.now(),
                            header: { object: requestHeader, collapsed: true },
                            trace: calleeStack,
                        }, {}, { message: `${_emojis__WEBPACK_IMPORTED_MODULE_8__.Emoji.Bank} [mocked](` }, { message: endPoint, bold: true }, { message: `)` });
                    }
                    else {
                        // console.log(endPoint);
                        _console__WEBPACK_IMPORTED_MODULE_7__.Console.gradientSeparator(_console__WEBPACK_IMPORTED_MODULE_7__.Console.Gradients.Lush);
                        _console__WEBPACK_IMPORTED_MODULE_7__.Console["default"]({ color: _console__WEBPACK_IMPORTED_MODULE_7__.Console.Colors.GreenMalachite });
                        const timestamp = new Date().toTimeString().split(" ")[0];
                        _console__WEBPACK_IMPORTED_MODULE_7__.Console.printWithObject({
                            result: response === null || response === void 0 ? void 0 : response.result,
                            response: JSON.stringify(httpResponse),
                            params,
                            baseURL: _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.webserviceURL,
                            timestamp: timestamp,
                            header: { object: requestHeader, collapsed: true },
                            trace: calleeStack,
                        }, {}, { message: `${_emojis__WEBPACK_IMPORTED_MODULE_8__.Emoji.Seedling} [response](` }, { message: endPoint, bold: true }, { message: `)` });
                    }
                }
                //#endregion
                if ((options === null || options === void 0 ? void 0 : options.presentMessage) && ((_a = response === null || response === void 0 ? void 0 : response.msg) === null || _a === void 0 ? void 0 : _a.msgText)) {
                    src_app_app_component__WEBPACK_IMPORTED_MODULE_14__.AppComponent.showError((_b = response === null || response === void 0 ? void 0 : response.msg) === null || _b === void 0 ? void 0 : _b.msgText);
                }
                if (response.isSuccess()) {
                    if (options === null || options === void 0 ? void 0 : options.fullResponse)
                        return [response === null || response === void 0 ? void 0 : response.result, response === null || response === void 0 ? void 0 : response.msg];
                    else
                        return response === null || response === void 0 ? void 0 : response.result;
                }
                else {
                    if (((_c = response === null || response === void 0 ? void 0 : response.msg) === null || _c === void 0 ? void 0 : _c.msgCode) === "SMRT0001") {
                        // MenuComponent.logout(
                        //   false,
                        //   HttpTranslations.errors.sessionExpiry[languageIndex] ||
                        //     response?.msg?.msgText
                        // );
                        src_app_app_component__WEBPACK_IMPORTED_MODULE_14__.AppComponent.goToLogoutPage();
                    }
                    else
                        throw response;
                }
            }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.catchError)((err) => {
                var _a, _b, _c, _d;
                if ((_a = err === null || err === void 0 ? void 0 : err.msg) === null || _a === void 0 ? void 0 : _a.msgText) {
                    if (((_b = err === null || err === void 0 ? void 0 : err.msg) === null || _b === void 0 ? void 0 : _b.msgSubCode) == "SMRT99") {
                        src_app_app_component__WEBPACK_IMPORTED_MODULE_14__.AppComponent.openForceUpdatePage();
                    }
                    else {
                        src_app_app_component__WEBPACK_IMPORTED_MODULE_14__.AppComponent.showError((_c = err === null || err === void 0 ? void 0 : err.msg) === null || _c === void 0 ? void 0 : _c.msgText);
                    }
                }
                if (calleeStack) {
                    err.request = {
                        url: endPoint,
                        baseURL: _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.webserviceURL,
                        params,
                        headerParams: headerParam,
                    };
                    _console__WEBPACK_IMPORTED_MODULE_7__.Console.separator({ background: "#007b00" });
                    _console__WEBPACK_IMPORTED_MODULE_7__.Console.separator({ background: "#24e0b8" });
                    _console__WEBPACK_IMPORTED_MODULE_7__.Console.separator({ background: "#ffcc51" });
                    console.log(err.message);
                    console.dir(err);
                    console.log(calleeStack);
                    _console__WEBPACK_IMPORTED_MODULE_7__.Console.separator({ background: "#ffcc51" });
                    _console__WEBPACK_IMPORTED_MODULE_7__.Console.separator({ background: "#ff8b76" });
                    _console__WEBPACK_IMPORTED_MODULE_7__.Console.separator({ background: "#ff3031" });
                }
                let errorMessage = "";
                if (err instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_16__.HttpErrorResponse) {
                    errorMessage = this.httpError.handle(err);
                    if (errorMessage === "networkError") {
                        src_app_app_component__WEBPACK_IMPORTED_MODULE_14__.AppComponent.showError(HttpTranslations.errors[errorMessage][languageIndex]);
                    }
                }
                else if (err instanceof rxjs__WEBPACK_IMPORTED_MODULE_22__.TimeoutError) {
                    src_app_app_component__WEBPACK_IMPORTED_MODULE_14__.AppComponent.showError(errorMessage);
                }
                else {
                    // this.alertHandler.presentError(err.error);
                }
                if (_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.isDevelopment && ((_d = _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.http) === null || _d === void 0 ? void 0 : _d.presentErrors))
                    src_app_app_component__WEBPACK_IMPORTED_MODULE_14__.AppComponent.showError(`${errorMessage ? errorMessage + " " + err.statusText + " " : ""}${err.message}`);
                this.requestsSubjects.delete(requestKey);
                return (0,rxjs__WEBPACK_IMPORTED_MODULE_23__.throwError)(err);
                // return of(undefined);
            }))
                .subscribe(requestSubject);
            return requestSubject;
        }
    }
    isNativeHttpAvailable() {
        var _a;
        if (this.ـisNativeHttpAvailable === null) {
            this.ـisNativeHttpAvailable =
                ((_a = _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.http) === null || _a === void 0 ? void 0 : _a.native) &&
                    ((0,_ionic_native_core__WEBPACK_IMPORTED_MODULE_11__.checkAvailability)("cordova.plugin.http") === true ||
                        (0,_ionic_native_core__WEBPACK_IMPORTED_MODULE_11__.checkAvailability)("cordovaHTTP") === true);
            if (this.ـisNativeHttpAvailable) {
                this.httpNative.setRequestTimeout(_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.http.timeout);
                // disable SSL cert checking, only meant for testing purposes, do NOT use in production!
                this.httpNative.setServerTrustMode("nocheck").catch(function () {
                    console.log("error :(");
                });
            }
        }
        return this.ـisNativeHttpAvailable;
    }
};
HttpHelper = (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__decorate)([
    _partial__WEBPACK_IMPORTED_MODULE_2__.partial,
    (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__metadata)("design:paramtypes", [])
], HttpHelper);
const Http = new HttpHelper();
class HttpTranslations {
}
HttpTranslations.errors = {
    sessionExpiry: ["انتهت صلاحية الجلسة", "Session expired"],
    networkError: [
        "خطأ في الاتصال، تأكد من إعدادات الشبكة",
        "Network Error, check your connection",
    ],
    serviceNotAvailable: [
        "الخدمة المطلوبة غير موجودة",
        "The requested service could not be found",
    ],
    timeoutError: [
        "الطلب استغرق وقتا طويلا ولا يوجد استجابة",
        "The request took a long time and no response",
    ],
    serverError: [
        "الخادم غير متاح حالياَ الرجاء المحاولة لاحقا",
        "The server is down please try again later",
    ],
};


/***/ }),

/***/ 36802:
/*!***********************************!*\
  !*** ./src/helpers/http/index.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Http": () => (/* reexport safe */ _http__WEBPACK_IMPORTED_MODULE_0__.Http),
/* harmony export */   "InHttpModule": () => (/* reexport safe */ _http_module__WEBPACK_IMPORTED_MODULE_1__.InHttpModule)
/* harmony export */ });
/* harmony import */ var _http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./http */ 38474);
/* harmony import */ var _http_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./http.module */ 99128);




/***/ }),

/***/ 30109:
/*!**************************************!*\
  !*** ./src/helpers/http/response.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Response": () => (/* binding */ Response)
/* harmony export */ });
class Response {
    isSuccess() {
        return this.status === '1';
    }
    get message() {
        var _a;
        return (_a = this.msg) === null || _a === void 0 ? void 0 : _a.msgText;
    }
}


/***/ }),

/***/ 19753:
/*!*********************************!*\
  !*** ./src/helpers/injector.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Injector": () => (/* binding */ Injector)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 3184);
var Injector_1;


let Injector = Injector_1 = class Injector {
    constructor(injector) {
        Injector_1.injector = injector;
    }
    static get(token, notFoundValue) {
        return Injector_1.injector.get(token, notFoundValue);
    }
};
Injector.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Injector }
];
Injector = Injector_1 = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.Injectable)(),
    (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__metadata)("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_0__.Injector])
], Injector);



/***/ }),

/***/ 38924:
/*!*********************************!*\
  !*** ./src/helpers/localize.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "localize": () => (/* binding */ localize)
/* harmony export */ });
/* harmony import */ var _strings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./strings */ 36782);
/* harmony import */ var _settings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./settings */ 96892);


function localize(object, fieldName) {
    let result = object[`${fieldName}En`] || object[`en${_strings__WEBPACK_IMPORTED_MODULE_0__.Strings.toPascalCase(fieldName)}`] || object[fieldName];
    if (_settings__WEBPACK_IMPORTED_MODULE_1__.Settings.language === _settings__WEBPACK_IMPORTED_MODULE_1__.Languages.Arabic)
        result = object[`${fieldName}Ar`] || object[`ar${_strings__WEBPACK_IMPORTED_MODULE_0__.Strings.toPascalCase(fieldName)}`] || result;
    return result;
}


/***/ }),

/***/ 50746:
/*!********************************!*\
  !*** ./src/helpers/numbers.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Numbers": () => (/* binding */ Numbers)
/* harmony export */ });
class Numbers {
    static round(v, fractionsCount) {
        var _a;
        const base = Math.pow(10, fractionsCount);
        return (parseInt((_a = (Number(v) * base)) === null || _a === void 0 ? void 0 : _a.toString()) / base).toString();
    }
}


/***/ }),

/***/ 45769:
/*!********************************!*\
  !*** ./src/helpers/partial.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "partial": () => (/* binding */ partial),
/* harmony export */   "partialDebug": () => (/* binding */ partialDebug)
/* harmony export */ });
/* harmony import */ var reflect_metadata__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! reflect-metadata */ 85649);
/* harmony import */ var reflect_metadata__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(reflect_metadata__WEBPACK_IMPORTED_MODULE_0__);

window.partialsClasses = {};
function partialDebug(target, propertyName, propertyType) {
    debugger;
    return partial(target, propertyName, propertyType);
}
function partial(target, propertyName, propertyType) {
    if (propertyType && typeof (propertyType === null || propertyType === void 0 ? void 0 : propertyType.value) === 'function') {
        return propertyType;
    }
    else if (target && propertyName) {
        return partialPropertyDecorator(target, propertyName, propertyType);
    }
    else if (target) {
        if (target.prototype) {
            return partialClassDecorator(target);
        }
        else {
            return (target2, propertyName2) => {
                return partialPropertyDecorator(target2, propertyName2, target);
            };
        }
    }
    else {
        throw new Error(`You probably calling decorator with (), call it bare like @partial not @partial() 😄`);
    }
}
function throwPartialError(target, propertyName) {
    throw new Error(`class ${target.name} { ${propertyName}: ?; }, Can not Reflect partial type probably due to CircularDependencies, try to name it like instance name \`(className: ClassName)\` or with \`@partial(() => ClassName)\` 😕`);
}
function partialPropertyDecorator(target, propertyName, propertyType) {
    const t = propertyType || Reflect.getMetadata('design:type', target, propertyName) || propertyName;
    if (t) {
        let lateType;
        if (typeof t === 'string')
            lateType = t;
        else
            lateType = t.name ? (() => t) : t;
        target.constructor.__partials = target.constructor.__partials || {};
        target.constructor.__partials[propertyName] = { name: propertyName, lateType };
    }
    else {
        throwPartialError(target.constructor, propertyName);
    }
}
class PartialLateRef {
    constructor(target) {
        this.target = target;
        this.properties = {};
        this.name = target.name;
    }
    setProperty(name, obj) {
        this.properties[name] = this.properties[name] || [];
        this.properties[name].push(obj);
    }
    realizeRef() {
        // tslint:disable-next-line: forin
        for (const property in this.properties) {
            // tslint:disable-next-line: forin
            for (const obj of this.properties[property]) {
                if (obj instanceof PartialLateRef)
                    this.realizedRef[property] = obj.realizedRef;
                else
                    this.realizedRef[property] = obj;
            }
        }
        this.properties = null;
        return this.realizedRef;
    }
}
function getTypeName(t) {
    if (t.name !== 'f')
        return t.name;
    else
        return t.prototype.constructor.name;
}
function getTypeProperty(t, propertyName) {
    if (t.name !== 'f')
        return t[propertyName];
    else
        return t.prototype.constructor[propertyName];
}
function setTypeProperty(t, propertyName, propertyValue) {
    if (t.name === 'f')
        t = t.prototype.constructor;
    t[propertyName] = propertyValue;
}
function partialClassDecorator(target) {
    const original = target;
    const f = function (...args) {
        var _a, _b;
        const partialsReferences = target.__partials;
        const partialsInstances = target.__partialsInstances || { __lateRefs: [] };
        const isRootObject = Object.keys(partialsInstances).length > 1 ? false : true;
        const startPartialMaybeLateRef = partialsInstances[getTypeName(target)] = partialsInstances[getTypeName(target)] || new PartialLateRef(target);
        for (const partialReference in partialsReferences) {
            const pRef = partialsReferences[partialReference];
            // Trying to resolve type if it's late or unknown, assume typeName from property name 😄
            if (!pRef.type) {
                if (typeof pRef.lateType === 'string') {
                    if (window.partialsClasses[pRef.lateType])
                        pRef.type = window.partialsClasses[pRef.lateType];
                    else
                        throwPartialError(target, pRef.name);
                }
                else
                    pRef.type = pRef.lateType();
            }
            if (!pRef.type)
                throwPartialError(target, pRef.name);
            if (window.partialDebugTarget && target.name === window.partialDebugTarget)
                debugger;
            setTypeProperty(pRef.type, '__partialsInstances', partialsInstances);
            {
                const partObject = partialsInstances[getTypeName(pRef.type)] = partialsInstances[getTypeName(pRef.type)] || new pRef.type();
                if (startPartialMaybeLateRef instanceof PartialLateRef)
                    startPartialMaybeLateRef.setProperty(pRef.name, partObject);
                else
                    startPartialMaybeLateRef[pRef.name] = partObject;
            }
            if (((_a = pRef.type) === null || _a === void 0 ? void 0 : _a.name) && ((_b = pRef.type) === null || _b === void 0 ? void 0 : _b.name) !== 'f') {
                console.error('Probably you forgot add @partial to ' + pRef.type.name + ' 🌝');
            }
            setTypeProperty(pRef.type, '__partialsInstances', null);
        }
        const o = new original(...args);
        if (window.addID)
            o.id = Math.floor(Math.random() * 100);
        if (startPartialMaybeLateRef instanceof PartialLateRef) {
            startPartialMaybeLateRef.realizedRef = o;
            partialsInstances.__lateRefs.push(startPartialMaybeLateRef);
            // If used in the future just put O
            partialsInstances[target.name] = o;
        }
        if (isRootObject) {
            for (const lateRef of partialsInstances.__lateRefs) {
                lateRef.realizeRef();
            }
            delete partialsInstances.__lateRefs;
            for (const k of Object.keys(partialsInstances)) {
                const ref = partialsInstances[k];
                if (ref === null || ref === void 0 ? void 0 : ref.onInit)
                    ref.onInit();
                delete partialsInstances[k];
            }
        }
        target.__partialsInstances = null;
        return o;
    };
    // copy prototype so intanceof operator still works
    f.prototype = original.prototype;
    // Move static properties and methods
    const props = Object.getOwnPropertyDescriptors(target);
    for (const prop in props) {
        if (!['name', 'prototype', 'length', '__partials'].includes(prop)) {
            const propValue = props[prop];
            Object.defineProperty(f, prop, propValue);
        }
    }
    window.partialsClasses[target.name.charAt(0).toLowerCase() + target.name.slice(1)] = f;
    return f;
}


/***/ }),

/***/ 2281:
/*!************************************!*\
  !*** ./src/helpers/refreshable.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "onRefresh": () => (/* binding */ onRefresh),
/* harmony export */   "refreshAll": () => (/* binding */ refreshAll)
/* harmony export */ });
const onRefreshables = [];
function refreshAll() {
    onRefreshables.forEach((r) => {
        if (r.object && r.method) {
            r.method.call(r.object, ...r.args);
        }
    });
}
function onRefresh(target, name, descriptor) {
    const func = descriptor.value;
    if (!func) {
        throw new TypeError("Function property descriptor expected 😊");
    }
    descriptor.value = function (...args) {
        onRefreshables.push({ object: this, method: func, args: args });
        return func.call(this, ...args);
    };
}


/***/ }),

/***/ 1552:
/*!***************************************!*\
  !*** ./src/helpers/rsa-encryption.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RSAEncryption": () => (/* binding */ RSAEncryption),
/* harmony export */   "RSAEncryptionHelper": () => (/* binding */ RSAEncryptionHelper)
/* harmony export */ });
/* harmony import */ var jsencrypt__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jsencrypt */ 57095);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 66587);


const PUBLIC_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCJ3rqiAsQkyEV4yaTE/s4qZOO8H6fdIyD+i081gemc1JeeomGg1Crqu5+Yuje2d32HDWt3yFWY3ahYx7wfacRu8YunykjFQ636yyYfCeAq3fPbO7kCHfv/QjRz/g44QHXqfBZSmw/oa28r9dhR25rwYxoSxN+UvQp0zD8j7Ap1cwIDAQAB";
class RSAEncryptionHelper {
    constructor() {
        this.$encrypt = new jsencrypt__WEBPACK_IMPORTED_MODULE_0__.JSEncrypt({});
        this.$encrypt.setPublicKey(`-----BEGIN PUBLIC KEY-----` + PUBLIC_KEY + `-----END PUBLIC KEY-----`);
    }
    /**
     * Encrypt text should be less than 117 length
     * @param plainText
     */
    encrypt(plainText) {
        const text = `${plainText}`.trim();
        // The 1024-bit key supports a maximum plaintext length of 127
        if (text.length > 117) {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.throwError)("The content is too long, please re-enter");
        }
        else {
            return this.$encrypt.encrypt(text);
        }
    }
}
const RSAEncryption = new RSAEncryptionHelper();


/***/ }),

/***/ 96892:
/*!*********************************!*\
  !*** ./src/helpers/settings.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Languages": () => (/* binding */ Languages),
/* harmony export */   "Settings": () => (/* binding */ Settings),
/* harmony export */   "Theme": () => (/* binding */ Theme)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 24383);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var src_app_app_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/app.component */ 20721);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var src_app_pages_menu__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/pages/menu */ 69626);
/* harmony import */ var _translations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./translations */ 69353);
/* harmony import */ var _capacitor_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @capacitor/storage */ 460);






var Languages;
(function (Languages) {
    Languages[Languages["Arabic"] = 0] = "Arabic";
    Languages[Languages["English"] = 1] = "English";
})(Languages || (Languages = {}));
var Theme;
(function (Theme) {
    Theme[Theme["Light"] = 0] = "Light";
    Theme[Theme["Dark"] = 1] = "Dark";
})(Theme || (Theme = {}));

class SettingsHelper {
    constructor() {
        this.enableNotficationKey = "NOTIFICATION_ENABLED";
        this.enableBiometricKey = "BIOMETRIC_ENABLED";
        this.preferedLanguageKey = "PREFERED_LANGUAGE";
        this.preferedThemeKey = "PREFERED_THEME";
        this.selectedLang = Languages.Arabic;
        this._isLanguageApplied = false;
        this.selectedTheme = Theme.Light;
    }
    get isLanguageApplied() {
        return this._isLanguageApplied;
    }
    get language() {
        // return Languages.Arabic;
        return this.selectedLang;
    }
    get languageAsString() {
        return this.fromLanguagesEnumToString(this.selectedLang);
    }
    //! this awufully needs to be refactored
    get languageAsync() {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.from)(_capacitor_storage__WEBPACK_IMPORTED_MODULE_3__.Storage.get({ key: "PREFERED_LANGUAGE" })).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.map)((result) => this.fromStringToLanguagesEnum(result === null || result === void 0 ? void 0 : result.value)));
    }
    fromStringToLanguagesEnum(str) {
        return str == "en" ? Languages.English : Languages.Arabic;
    }
    fromLanguagesEnumToString(lang) {
        return lang == Languages.Arabic ? "ar" : "en";
    }
    set language(lang) {
        this.selectedLang = lang;
    }
    toggleLang() {
        // This needs to be refactored ...
        const selectedLang = this.selectedLang == Languages.Arabic
            ? Languages.English
            : Languages.Arabic;
        _capacitor_storage__WEBPACK_IMPORTED_MODULE_3__.Storage.set({
            key: "PREFERED_LANGUAGE",
            value: this.fromLanguagesEnumToString(selectedLang),
        });
        // setTimeout(() => {
        //   debugger
        Settings.setLanguage();
        (0,_translations__WEBPACK_IMPORTED_MODULE_2__.localizeApp)(selectedLang);
        setTimeout(() => {
            src_app_pages_menu__WEBPACK_IMPORTED_MODULE_1__.MenuComponent.isLanguageToggled = !src_app_pages_menu__WEBPACK_IMPORTED_MODULE_1__.MenuComponent.isLanguageToggled;
        }, 100);
        // AppComponent.restart(null, false);
        // }, 1000);
    }
    setLanguage() {
        new rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable((observer) => {
            _capacitor_storage__WEBPACK_IMPORTED_MODULE_3__.Storage.get({ key: "PREFERED_LANGUAGE" }).then((val) => {
                this.selectedLang = this.fromStringToLanguagesEnum(val.value);
                if (this.language == Languages.English) {
                    document.documentElement.setAttribute("dir", "ltr");
                    // Settings.language = Languages.English;
                }
                else {
                    document.documentElement.setAttribute("dir", "rtl");
                    // Settings.language = Languages.Arabic;
                }
                if (src_app_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent.isActive("/settings"))
                    src_app_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent.navCtrl.navigateRoot("/settings");
                // observer.next(val.value)
                // observer.next(JSON.parse(val.value))
                this._isLanguageApplied = true;
            });
        }).subscribe();
    }
    get theme() {
        return this.selectedTheme;
    }
    set theme(theme) {
        this.selectedTheme = theme;
    }
    setTheme() {
        new rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable((observer) => {
            _capacitor_storage__WEBPACK_IMPORTED_MODULE_3__.Storage.get({ key: this.preferedThemeKey }).then((val) => {
                this.selectedTheme =
                    val.value == "dark-theme" ? Theme.Dark : Theme.Light;
                observer.next(val.value);
                if (this.theme == Theme.Dark) {
                    document.body.classList.add("dark");
                }
                else {
                    document.body.classList.remove("dark");
                }
            });
        }).subscribe();
    }
    setUserPreferences(key, value) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            yield _capacitor_storage__WEBPACK_IMPORTED_MODULE_3__.Storage.set({ key: key, value: value });
        });
    }
    getUserPreferences(key) {
        return new rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable((observer) => {
            _capacitor_storage__WEBPACK_IMPORTED_MODULE_3__.Storage.get({ key }).then((val) => {
                observer.next(val.value);
                // observer.next(JSON.parse(val.value))
            });
        });
    }
}
const Settings = new SettingsHelper();


/***/ }),

/***/ 9199:
/*!**********************************!*\
  !*** ./src/helpers/streaming.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Streaming": () => (/* binding */ Streaming),
/* harmony export */   "StreamingChannelEvent": () => (/* binding */ StreamingChannelEvent),
/* harmony export */   "StreamingChannelEventType": () => (/* binding */ StreamingChannelEventType),
/* harmony export */   "StreamingHelper": () => (/* binding */ StreamingHelper)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 61555);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 64139);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var _inma_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/environment */ 80960);
/* harmony import */ var _console__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./console */ 56031);
/* harmony import */ var _emojis__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./emojis */ 79461);
/* harmony import */ var libs_cometd_cometd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! libs/cometd/cometd */ 1722);
/* harmony import */ var libs_cometd_cometd__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(libs_cometd_cometd__WEBPACK_IMPORTED_MODULE_3__);





class StreamingHelper {
    constructor() {
        this.subscriptionsObservables = [];
        this.isConnected = false;
        this.isHandshaken = false; // CometD refuses to handshake more than once !
        this.subscriptionsReferences = {};
        this.connectionChangeSubject = new rxjs__WEBPACK_IMPORTED_MODULE_4__.ReplaySubject();
        this.connectionCounter = 1;
        this.cometD = new libs_cometd_cometd__WEBPACK_IMPORTED_MODULE_3__.CometD();
        this.cometD.websocketEnabled = false;
        this.url = _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.streamingURL;
        this.cometD.configure({
            url: this.url,
            logLevel: "info",
            maxNetworkDelay: _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.http.timeout,
        });
        // this.isMocked = Environment.isMocked;
    }
    connect() {
        var _a;
        if (!((_a = _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.streaming) === null || _a === void 0 ? void 0 : _a.enabled)) {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.of)(false);
        }
        return new rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable((observer) => {
            if (this.isConnected) {
                observer.next(true);
                observer.complete();
            }
            else {
                this.subscriptionsReferences = [];
                this.subscriptionsObservables = [];
                this.cometD.addListener("/meta/connect", (message) => {
                    var _a, _b;
                    if (this.cometD.isDisconnected())
                        return;
                    const wasConnected = this.isConnected;
                    this.isConnected = message.successful;
                    if (wasConnected === false && this.isConnected) {
                        this.log(`Connected successfully, ${this.connectionCounter++}`, "server");
                        Streaming.connectionChangeSubject.next(true);
                        this.resubscribeAll();
                        if ((((_a = _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.labs) === null || _a === void 0 ? void 0 : _a.enabled) &&
                            ((_b = _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.labs) === null || _b === void 0 ? void 0 : _b.streamingInstablity))) {
                            const disconnectConnect = function () {
                                setTimeout(() => {
                                    Streaming.connectionChangeSubject.next(false);
                                }, 0);
                                setTimeout(() => {
                                    Streaming.connectionChangeSubject.next(true);
                                }, 5000);
                            };
                            disconnectConnect();
                            setInterval(() => {
                                disconnectConnect();
                            }, 10 * 1000);
                        }
                    }
                    else if (wasConnected && this.isConnected === false) {
                        this.log("Disconnected !", "server");
                        Streaming.connectionChangeSubject.next(false);
                        this.connectionRetries = 0;
                    }
                    if (this.isConnected === false) {
                        this.connectionRetries++;
                        console.log(`this.connectionRetries = ${this.connectionRetries}`);
                        // if (this.connectionRetries >= 3) {
                        // this.onReset();
                        // User.logout();
                        // return;
                        // }
                        this.log(`Connection retry, ${this.connectionRetries}`, "server");
                    }
                });
                this.cometD.addListener("/meta/disconnect", (message) => {
                    if (message.successful)
                        this.isConnected = false;
                });
                if (this.isHandshaken === false) {
                    this.handshakeHandlers = new Array();
                    this.cometD.handshake((handshakeReply) => {
                        // if (Environment.streaming.logEnabled) {
                        // if (handshakeReply.successful) {
                        //     Console.gradientSeparator(Console.Gradients.ColorfulPeachGet);
                        //     Console.default({ color: Console.Colors.BlueDeepSky });
                        //     Console.print(
                        //         { message: `${Emoji.Honeybee} [string](` },
                        //         { message: this.url, bold: true },
                        //         { message: `) was succesful` }
                        //     );
                        // }
                        // else {
                        //     StreamingService.log(
                        //         `~ StreamingService.connect('${this.url}')`,
                        //         `= Connection failed !`
                        //     )
                        // }
                        // }
                        this.handshakeHandlers.forEach((handler) => {
                            handler(handshakeReply.successful);
                        });
                        this.handshakeHandlers = new Array();
                    });
                    this.isHandshaken = true;
                }
                this.handshakeHandlers.push((isConnected) => {
                    observer.next(isConnected);
                });
            }
        });
    }
    subscribe(channel) {
        if (this.subscriptionsObservables && this.subscriptionsObservables[channel])
            return this.subscriptionsObservables[channel];
        else
            return (this.subscriptionsObservables[channel] = new rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable((observer) => {
                try {
                    // setInterval(() => {
                    //     if (channel == '/alinma/marketInfo/TDWL/TASI') {
                    //         const mi = new MarketInfo();
                    //         mi.indexValue = Math.floor(Math.random() * 100);
                    //         console.log(mi.indexValue);
                    //         observer.next({type: StreamingChannelEventType.MessageReceived, data: {data: JSON.stringify(mi)}});
                    //     }
                    // }, 6000)
                    // try {
                    //     if (channel.startsWith("/alinma/quotes")) {
                    //         const id = channel.replace("/alinma/quotes/", "");//"/alinma/marketDepth/7030";
                    //         setTimeout(() => {
                    //             setInterval(() => {
                    //                 // Symbol.zone.run(() => {
                    //                     // console.log(1000);
                    //                     observer.next(new StreamingChannelEvent(
                    //                         StreamingChannelEventType.MessageReceived,
                    //                         { data: JSON.stringify({ symbol: id, lastTradedPrice: Math.floor(Math.random() * 100) }) }));
                    //         //             // Symbol.theOneCallback({ type: StreamingChannelEventType.MessageReceived, data: { data: JSON.stringify({ symbol: id, lastTradedPrice: Math.floor(Math.random() * 100) }) } });
                    //                 // });
                    //             }, 1000)
                    //         }, 1000);
                    //     }
                    // } catch (c) { }
                    this.subscriptionsReferences[channel] = this.cometD.subscribe(channel, (message) => {
                        // debugger
                        if (_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.streaming.enabled)
                            observer.next(new StreamingChannelEvent(StreamingChannelEventType.MessageReceived, message));
                    }, (reply) => {
                        if (reply.successful) {
                            if (_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.streaming.enabled)
                                observer.next(new StreamingChannelEvent(StreamingChannelEventType.Subscribed, reply));
                        }
                        else
                            observer.error(reply);
                    });
                }
                catch (e) {
                    console.log(e);
                }
            }));
    }
    unsubscribe(channel) {
        var _a;
        if ((_a = this.subscriptionsReferences) === null || _a === void 0 ? void 0 : _a[channel]) {
            this.cometD.unsubscribe(this.subscriptionsReferences[channel]);
            delete this.subscriptionsReferences[channel];
            delete this.subscriptionsObservables[channel];
        }
    }
    unsubscribeAll() {
        for (const channel in this.subscriptionsReferences || {})
            this.unsubscribe(channel);
    }
    disconnect() {
        this.cometD.disconnect();
        this.isConnected = false;
        this.isHandshaken = false;
        this.unsubscribeAll();
    }
    resubscribeAll() {
        for (const channel in this.subscriptionsReferences || {}) {
            this.cometD.resubscribe(this.subscriptionsReferences[channel]);
        }
    }
    log(message, type = "channels") {
        if (_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.isLoggingStreamingEnabled) {
            if (!((type == "server" && _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.isLoggingStreamingServerEnabled) ||
                (type == "channels" && _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.isLoggingStreamingChannelsEnabled))) {
                return;
            }
            _console__WEBPACK_IMPORTED_MODULE_1__.Console.gradientSeparator(_console__WEBPACK_IMPORTED_MODULE_1__.Console.Gradients.Lush);
            _console__WEBPACK_IMPORTED_MODULE_1__.Console["default"]({ color: _console__WEBPACK_IMPORTED_MODULE_1__.Console.Colors.GreenMalachite });
            _console__WEBPACK_IMPORTED_MODULE_1__.Console.print({ message: `${_emojis__WEBPACK_IMPORTED_MODULE_2__.Emoji.Satellite} [streaming](` }, { message, bold: true }, { message: `)` });
        }
    }
}
var StreamingChannelEventType;
(function (StreamingChannelEventType) {
    StreamingChannelEventType["Subscribed"] = "Subscribed";
    StreamingChannelEventType["MessageReceived"] = "MessageReceived";
})(StreamingChannelEventType || (StreamingChannelEventType = {}));
class StreamingChannelEvent {
    constructor(type, data) {
        this.type = type;
        this.data = data;
    }
}
const Streaming = new StreamingHelper();


/***/ }),

/***/ 36782:
/*!********************************!*\
  !*** ./src/helpers/strings.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EqualityCheckType": () => (/* binding */ EqualityCheckType),
/* harmony export */   "Strings": () => (/* binding */ Strings)
/* harmony export */ });
var EqualityCheckType;
(function (EqualityCheckType) {
    EqualityCheckType[EqualityCheckType["CaseInsensitive"] = 0] = "CaseInsensitive";
    EqualityCheckType[EqualityCheckType["CaseSensitive"] = 1] = "CaseSensitive";
})(EqualityCheckType || (EqualityCheckType = {}));
class Strings {
    static normalizeArabicNumbers(value) {
        if (value) {
            value = '' + value;
            return value.replace(/[\u0660-\u0669]/g, function (d) { return d.charCodeAt(0) - 1632; });
        }
    }
    static normalizeArabicLetters(value) {
        if (value) {
            value = '' + value;
            return value.replace(/(أ|إ)/g, 'ا');
        }
    }
    static normalizeWhitespaces(value) {
        if (value) {
            value = '' + value;
            return value.replace(/\s+/g, ' ');
        }
    }
    static normalizeAll(value) {
        if (value) {
            value = '' + value;
            value = Strings.normalizeArabicNumbers(value.toLowerCase());
            value = Strings.normalizeArabicLetters(value);
            value = Strings.normalizeWhitespaces(value);
            return value;
        }
    }
    static normalizeNumberInput(event) {
        if (event.key.match(/[\u0660-\u0669]/g)) {
            event.target.value += Strings.normalizeArabicNumbers(event.key);
            event.preventDefault();
        }
        return event.target.value;
    }
    static toPascalCase(string) {
        return `${string}`
            .replace(new RegExp(/[-_]+/, 'g'), ' ')
            .replace(new RegExp(/[^\w\s]/, 'g'), '')
            .replace(new RegExp(/\s+(.)(\w+)/, 'g'), ($1, $2, $3) => `${$2.toUpperCase() + $3.toLowerCase()}`)
            .replace(new RegExp(/\s/, 'g'), '')
            .replace(new RegExp(/\w/), s => s.toUpperCase());
    }
    static camelToPascalCase(string) {
        return string[0].toUpperCase() + string.substring(1);
    }
    static camelize(str) {
        return str.replace(/(?:^\w|[A-Z]|\b\w)/g, function (letter, index) {
            return index == 0 ? letter.toLowerCase() : letter.toUpperCase();
        }).replace(/\s+/g, '');
    }
    static isNullOrEmpty(string) {
        return string == null || string.length === 0;
    }
    static equal(string1, string2, checkType = EqualityCheckType.CaseInsensitive) {
        if (checkType === EqualityCheckType.CaseInsensitive) {
            return string1.toLowerCase() === string2.toLowerCase();
        }
        else {
            return string1 === string2;
        }
    }
    static indexOf(string1, string2, checkType = EqualityCheckType.CaseInsensitive) {
        if (checkType === EqualityCheckType.CaseInsensitive) {
            return string1.toLowerCase().indexOf(string2.toLowerCase());
        }
        else {
            return string1.indexOf(string2);
        }
    }
    static titleize(str) {
        if (!str.split)
            return str;
        str = str.replace(/([A-Z])/g, (c) => { return ' ' + c.toUpperCase(); });
        const _titleizeWord = (string) => {
            return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
        };
        const result = [];
        str.split(' ').forEach(function (w) {
            result.push(_titleizeWord(w));
        });
        return result.join(' ');
    }
    static fromPascalToKebab(str) {
        let result = str[0].toLowerCase();
        for (let i = 1; i < str.length; i++) {
            const c = str[i];
            if ('A' <= c && c <= 'Z') {
                result += '-' + c.toLowerCase();
            }
            else
                result += c;
        }
        ;
        return result;
    }
}
/**
* object.padding(number, string)
* Transform the string object to string of the actual width filling by the padding character (by default ' ')
* Negative value of width means left padding, and positive value means right one
*
* @param       number  Width of string
* @param       string  Padding chacracter (by default, ' ')
*/
Strings.padding = function (str, n, c = ' ') {
    const val = str.valueOf();
    if (Math.abs(n) <= val.length) {
        return val;
    }
    const m = Math.max((Math.abs(n) - str.length) || 0, 0);
    const pad = Array(m + 1).join(String(c).charAt(0));
    return (n < 0) ? pad + val : val + pad;
};


/***/ }),

/***/ 51139:
/*!******************************!*\
  !*** ./src/helpers/toast.ts ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Toast": () => (/* binding */ Toast)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _injector__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./injector */ 19753);



const ERROR_MIN_TIME_AMOUNT = 1000 * 2;
class ToastHelper {
    constructor() {
        //!TODO: refactor this
        this.messagesHistory = {};
        this.toasts = [];
        this.intervals = [];
    }
    present(message, options) {
        var _a;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
            if (!message || (message === null || message === void 0 ? void 0 : message.trim()) == "undefined")
                return;
            this.closeAll();
            // message = message || '';
            if (this.messagesHistory[message]) {
                if (this.messagesHistory[message].opened) {
                    return;
                }
                else {
                    const now = new Date().getTime();
                    const history = this.messagesHistory[message].date.getTime();
                    if (now - history < ERROR_MIN_TIME_AMOUNT)
                        return;
                }
            }
            this.messagesHistory[message] = { date: new Date(), opened: true };
            ////
            const toastController = _injector__WEBPACK_IMPORTED_MODULE_0__.Injector.get(_ionic_angular__WEBPACK_IMPORTED_MODULE_2__.ToastController);
            const toast = yield toastController.create({
                message: message,
                duration: (options === null || options === void 0 ? void 0 : options.duration) * 1000,
                cssClass: `info-alert ${options === null || options === void 0 ? void 0 : options.class}`,
                buttons: [
                    {
                        side: "start",
                        icon: (options === null || options === void 0 ? void 0 : options.icon) || "cloud-offline-outline",
                        role: "",
                        handler: () => {
                            console.log("");
                        },
                    },
                    // {
                    //   text: "",
                    //   icon: "close",
                    //   role: "cancel",
                    //   handler: () => {
                    //     console.log("Cancel clicked");
                    //   },
                    // },
                ],
            });
            toast.onDidDismiss().then(() => {
                if (this.messagesHistory[message])
                    this.messagesHistory[message].opened = false;
            });
            let setMessage = (time) => {
                if (time)
                    toast.message = `${message} (${time} ثانية) `;
                else
                    toast.message = message;
            };
            let timer = (_a = options === null || options === void 0 ? void 0 : options.timer) === null || _a === void 0 ? void 0 : _a.period;
            setMessage(timer);
            if (timer) {
                let interval = setInterval(() => {
                    var _a, _b;
                    timer--;
                    if (timer) {
                        setMessage(timer);
                    }
                    else {
                        clearInterval(interval);
                        (_b = (_a = options === null || options === void 0 ? void 0 : options.timer) === null || _a === void 0 ? void 0 : _a.callback) === null || _b === void 0 ? void 0 : _b.call(_a);
                        toast.dismiss();
                    }
                }, 1000);
                this.intervals.push(interval);
            }
            toast.present();
            this.toasts.push(toast);
        });
    }
    closeAll() {
        this.toasts.forEach((t) => {
            t.dismiss();
        });
        this.intervals.forEach((interval) => {
            clearInterval(interval);
        });
    }
}
const Toast = new ToastHelper();


/***/ }),

/***/ 69353:
/*!*************************************!*\
  !*** ./src/helpers/translations.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Translations": () => (/* binding */ Translations),
/* harmony export */   "appBaseTranslations": () => (/* binding */ appBaseTranslations),
/* harmony export */   "appTranslations": () => (/* binding */ appTranslations),
/* harmony export */   "localizeApp": () => (/* binding */ localizeApp)
/* harmony export */ });
/* harmony import */ var _inma_helpers_clipboard__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/helpers/clipboard */ 71286);
/* harmony import */ var _strings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./strings */ 36782);
/* harmony import */ var _inma_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/environment */ 80960);
/* harmony import */ var _settings__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./settings */ 96892);
/* harmony import */ var _copy__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./copy */ 1430);





const appBaseTranslations = {};
const appTranslations = {};
const localizeTranslationArray = (propertyName, langIndex) => {
    let baseValue = appBaseTranslations[propertyName];
    let value = appTranslations[propertyName];
    const props = Object.getOwnPropertyNames(baseValue);
    for (const prop of props) {
        if (typeof value[prop] === "function") {
            try {
                baseValue[prop] = baseValue[prop]();
            }
            catch (c) { }
        }
        if (baseValue[prop] && baseValue[prop].length == 2)
            value[prop] = baseValue[prop][langIndex];
    }
};
function localizeApp(langIndex) {
    const prototypes = Object.getOwnPropertyNames(appTranslations);
    for (const prototype of prototypes) {
        localizeTranslationArray(prototype, langIndex);
    }
}
// TODO: find solution for merged T
function Translations() {
    const missingTranslations = {};
    let missingTranslationsTimeout;
    return (prototype, key) => {
        Object.defineProperty(prototype, key, {
            set(value) {
                var _a;
                let baseValue = value;
                // let i = 0;
                // setInterval(() => {
                //   i += 1;
                //   localizeApp(i % 2)
                // }, 2000)
                if (!baseValue._translated) {
                    appTranslations[prototype.constructor] = value;
                    // console.log(prototype.constructor, value);
                    appBaseTranslations[prototype.constructor] = (0,_copy__WEBPACK_IMPORTED_MODULE_4__.deepCopy)(value);
                    // console.log('appBaseTranslations[' + prototype.constructor.name + ']', appBaseTranslations[prototype.constructor.name]);
                    // console.log(appTranslations);
                    if (_settings__WEBPACK_IMPORTED_MODULE_3__.Settings.isLanguageApplied) {
                        localizeTranslationArray(prototype.constructor, _settings__WEBPACK_IMPORTED_MODULE_3__.Settings.language);
                    }
                    else {
                        _settings__WEBPACK_IMPORTED_MODULE_3__.Settings.languageAsync.subscribe(langIndex => localizeTranslationArray(prototype.constructor, langIndex));
                    }
                }
                if (_inma_environment__WEBPACK_IMPORTED_MODULE_2__.Environment.isDevelopment && ((_a = _inma_environment__WEBPACK_IMPORTED_MODULE_2__.Environment.translations) === null || _a === void 0 ? void 0 : _a.showMissing)) {
                    value = new Proxy(value, {
                        get: (target, propName) => {
                            if (baseValue[propName])
                                return baseValue[propName];
                            else {
                                const suggested = _strings__WEBPACK_IMPORTED_MODULE_1__.Strings.titleize(propName.toString().toLowerCase().replace("_", " "));
                                missingTranslations[propName.toString()] = ["", suggested];
                                if (missingTranslationsTimeout)
                                    clearTimeout(missingTranslationsTimeout);
                                missingTranslationsTimeout = setTimeout(() => {
                                    let output = "export const Translations = {\n";
                                    console.warn("Missing Translations");
                                    // tslint:disable-next-line:forin
                                    const missingKeys = Object.getOwnPropertyNames(missingTranslations);
                                    for (let i = 0; i < missingKeys.length; i++) {
                                        const missingKey = missingKeys[i];
                                        const missingValue = missingTranslations[missingKey];
                                        output += `\t${missingKey} = ['${missingValue[0]}', '${missingValue[1]}']`;
                                        // if (i < missingKeys.length - 1)
                                        output += `;`;
                                        output += `\n`;
                                    }
                                    output += "};\n";
                                    console.log(output);
                                    _inma_helpers_clipboard__WEBPACK_IMPORTED_MODULE_0__.Clipboard.copy(output);
                                }, 1000);
                                return (baseValue[propName] = `🎃 missingTranslation (${propName.toString()}) 🎃`);
                            }
                        },
                    });
                }
                baseValue._translated = true;
                Object.defineProperty(this, key, {
                    value,
                    enumerable: true,
                });
            },
            enumerable: true,
            configurable: true,
        });
    };
}


/***/ }),

/***/ 8835:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 68150);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 50023);
/* harmony import */ var _inma_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @inma/environment */ 80960);




if (_inma_environment__WEBPACK_IMPORTED_MODULE_1__.Environment.isProduction) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
    // console.log = function(){} ;
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.log(err));
// setTimeout(() => {
//   window.onerror = function(message, url, line) {
//     alert(message + ', ' + url + ', ' + line);
//   };  
// }, 1000);


/***/ }),

/***/ 1722:
/*!*******************************!*\
  !*** ./libs/cometd/cometd.js ***!
  \*******************************/
/***/ (function(module) {

/*
 * Copyright (c) 2008-2020 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* CometD Version 3.1.14 */
(function (root, factory) {
  if (true) {
    // CommonJS.
    module.exports = factory();
  } else {}
})(this, function () {
  /**
   * Browsers may throttle the Window scheduler,
   * so we may replace it with a Worker scheduler.
   */
  var Scheduler = function () {
    var _ids = 0;
    var _tasks = {};

    this.register = function (funktion) {
      var id = ++_ids;
      _tasks[id] = funktion;
      return id;
    };

    this.unregister = function (id) {
      var funktion = _tasks[id];
      delete _tasks[id];
      return funktion;
    };

    this.setTimeout = function (funktion, delay) {
      return window.setTimeout(funktion, delay);
    };

    this.clearTimeout = function (id) {
      window.clearTimeout(id);
    };
  };
  /**
   * The scheduler code that will run in the Worker.
   * Workers have a built-in `self` variable similar to `window`.
   */


  function WorkerScheduler() {
    var _tasks = {};

    self.onmessage = function (e) {
      var cmd = e.data;
      var id = _tasks[cmd.id];

      switch (cmd.type) {
        case 'setTimeout':
          _tasks[cmd.id] = self.setTimeout(function () {
            delete _tasks[cmd.id];
            self.postMessage({
              id: cmd.id
            });
          }, cmd.delay);
          break;

        case 'clearTimeout':
          delete _tasks[cmd.id];

          if (id) {
            self.clearTimeout(id);
          }

          break;

        default:
          throw 'Unknown command ' + cmd.type;
      }
    };
  }
  /**
   * Utility functions.
   */


  var Utils = {
    isString: function (value) {
      if (value === undefined || value === null) {
        return false;
      }

      return typeof value === 'string' || value instanceof String;
    },
    isArray: function (value) {
      if (value === undefined || value === null) {
        return false;
      }

      return value instanceof Array;
    },

    /**
     * Returns whether the given element is contained into the given array.
     * @param element the element to check presence for
     * @param array the array to check for the element presence
     * @return the index of the element, if present, or a negative index if the element is not present
     */
    inArray: function (element, array) {
      for (var i = 0; i < array.length; ++i) {
        if (element === array[i]) {
          return i;
        }
      }

      return -1;
    }
  };
  /**
   * A registry for transports used by the CometD object.
   */

  var TransportRegistry = function () {
    var _types = [];
    var _transports = {};

    this.getTransportTypes = function () {
      return _types.slice(0);
    };

    this.findTransportTypes = function (version, crossDomain, url) {
      var result = [];

      for (var i = 0; i < _types.length; ++i) {
        var type = _types[i];

        if (_transports[type].accept(version, crossDomain, url) === true) {
          result.push(type);
        }
      }

      return result;
    };

    this.negotiateTransport = function (types, version, crossDomain, url) {
      for (var i = 0; i < _types.length; ++i) {
        var type = _types[i];

        for (var j = 0; j < types.length; ++j) {
          if (type === types[j]) {
            var transport = _transports[type];

            if (transport.accept(version, crossDomain, url) === true) {
              return transport;
            }
          }
        }
      }

      return null;
    };

    this.add = function (type, transport, index) {
      var existing = false;

      for (var i = 0; i < _types.length; ++i) {
        if (_types[i] === type) {
          existing = true;
          break;
        }
      }

      if (!existing) {
        if (typeof index !== 'number') {
          _types.push(type);
        } else {
          _types.splice(index, 0, type);
        }

        _transports[type] = transport;
      }

      return !existing;
    };

    this.find = function (type) {
      for (var i = 0; i < _types.length; ++i) {
        if (_types[i] === type) {
          return _transports[type];
        }
      }

      return null;
    };

    this.remove = function (type) {
      for (var i = 0; i < _types.length; ++i) {
        if (_types[i] === type) {
          _types.splice(i, 1);

          var transport = _transports[type];
          delete _transports[type];
          return transport;
        }
      }

      return null;
    };

    this.clear = function () {
      _types = [];
      _transports = {};
    };

    this.reset = function (init) {
      for (var i = 0; i < _types.length; ++i) {
        _transports[_types[i]].reset(init);
      }
    };
  };
  /**
   * Base object with the common functionality for transports.
   */


  var Transport = function () {
    var _type;

    var _cometd;

    var _url;
    /**
     * Function invoked just after a transport has been successfully registered.
     * @param type the type of transport (for example 'long-polling')
     * @param cometd the cometd object this transport has been registered to
     * @see #unregistered()
     */


    this.registered = function (type, cometd) {
      _type = type;
      _cometd = cometd;
    };
    /**
     * Function invoked just after a transport has been successfully unregistered.
     * @see #registered(type, cometd)
     */


    this.unregistered = function () {
      _type = null;
      _cometd = null;
    };

    this._debug = function () {
      _cometd._debug.apply(_cometd, arguments);
    };

    this._mixin = function () {
      return _cometd._mixin.apply(_cometd, arguments);
    };

    this.getConfiguration = function () {
      return _cometd.getConfiguration();
    };

    this.getAdvice = function () {
      return _cometd.getAdvice();
    };

    this.setTimeout = function (funktion, delay) {
      return _cometd.setTimeout(funktion, delay);
    };

    this.clearTimeout = function (id) {
      _cometd.clearTimeout(id);
    };
    /**
     * Converts the given response into an array of bayeux messages
     * @param response the response to convert
     * @return an array of bayeux messages obtained by converting the response
     */


    this.convertToMessages = function (response) {
      if (Utils.isString(response)) {
        try {
          return JSON.parse(response);
        } catch (x) {
          this._debug('Could not convert to JSON the following string', '"' + response + '"');

          throw x;
        }
      }

      if (Utils.isArray(response)) {
        return response;
      }

      if (response === undefined || response === null) {
        return [];
      }

      if (response instanceof Object) {
        return [response];
      }

      throw 'Conversion Error ' + response + ', typeof ' + typeof response;
    };
    /**
     * Returns whether this transport can work for the given version and cross domain communication case.
     * @param version a string indicating the transport version
     * @param crossDomain a boolean indicating whether the communication is cross domain
     * @param url the URL to connect to
     * @return true if this transport can work for the given version and cross domain communication case,
     * false otherwise
     */


    this.accept = function (version, crossDomain, url) {
      throw 'Abstract';
    };
    /**
     * Returns the type of this transport.
     * @see #registered(type, cometd)
     */


    this.getType = function () {
      return _type;
    };

    this.getURL = function () {
      return _url;
    };

    this.setURL = function (url) {
      _url = url;
    };

    this.send = function (envelope, metaConnect) {
      throw 'Abstract';
    };

    this.reset = function (init) {
      this._debug('Transport', _type, 'reset', init ? 'initial' : 'retry');
    };

    this.abort = function () {
      this._debug('Transport', _type, 'aborted');
    };

    this.toString = function () {
      return this.getType();
    };
  };

  Transport.derive = function (baseObject) {
    function F() {}

    F.prototype = baseObject;
    return new F();
  };
  /**
   * Base object with the common functionality for transports based on requests.
   * The key responsibility is to allow at most 2 outstanding requests to the server,
   * to avoid that requests are sent behind a long poll.
   * To achieve this, we have one reserved request for the long poll, and all other
   * requests are serialized one after the other.
   */


  var RequestTransport = function () {
    var _super = new Transport();

    var _self = Transport.derive(_super);

    var _requestIds = 0;
    var _metaConnectRequest = null;
    var _requests = [];
    var _envelopes = [];

    function _coalesceEnvelopes(envelope) {
      while (_envelopes.length > 0) {
        var envelopeAndRequest = _envelopes[0];
        var newEnvelope = envelopeAndRequest[0];
        var newRequest = envelopeAndRequest[1];

        if (newEnvelope.url === envelope.url && newEnvelope.sync === envelope.sync) {
          _envelopes.shift();

          envelope.messages = envelope.messages.concat(newEnvelope.messages);

          this._debug('Coalesced', newEnvelope.messages.length, 'messages from request', newRequest.id);

          continue;
        }

        break;
      }
    }

    function _transportSend(envelope, request) {
      this.transportSend(envelope, request);
      request.expired = false;

      if (!envelope.sync) {
        var maxDelay = this.getConfiguration().maxNetworkDelay;
        var delay = maxDelay;

        if (request.metaConnect === true) {
          delay += this.getAdvice().timeout;
        }

        this._debug('Transport', this.getType(), 'waiting at most', delay, 'ms for the response, maxNetworkDelay', maxDelay);

        var self = this;
        request.timeout = this.setTimeout(function () {
          request.expired = true;
          var errorMessage = 'Request ' + request.id + ' of transport ' + self.getType() + ' exceeded ' + delay + ' ms max network delay';
          var failure = {
            reason: errorMessage
          };
          var xhr = request.xhr;
          failure.httpCode = self.xhrStatus(xhr);
          self.abortXHR(xhr);

          self._debug(errorMessage);

          self.complete(request, false, request.metaConnect);
          envelope.onFailure(xhr, envelope.messages, failure);
        }, delay);
      }
    }

    function _queueSend(envelope) {
      var requestId = ++_requestIds;
      var request = {
        id: requestId,
        metaConnect: false,
        envelope: envelope
      }; // Consider the /meta/connect requests which should always be present.

      if (_requests.length < this.getConfiguration().maxConnections - 1) {
        _requests.push(request);

        _transportSend.call(this, envelope, request);
      } else {
        this._debug('Transport', this.getType(), 'queueing request', requestId, 'envelope', envelope);

        _envelopes.push([envelope, request]);
      }
    }

    function _metaConnectComplete(request) {
      var requestId = request.id;

      this._debug('Transport', this.getType(), '/meta/connect complete, request', requestId);

      if (_metaConnectRequest !== null && _metaConnectRequest.id !== requestId) {
        throw '/meta/connect request mismatch, completing request ' + requestId;
      }

      _metaConnectRequest = null;
    }

    function _complete(request, success) {
      var index = Utils.inArray(request, _requests); // The index can be negative if the request has been aborted

      if (index >= 0) {
        _requests.splice(index, 1);
      }

      if (_envelopes.length > 0) {
        var envelopeAndRequest = _envelopes.shift();

        var nextEnvelope = envelopeAndRequest[0];
        var nextRequest = envelopeAndRequest[1];

        this._debug('Transport dequeued request', nextRequest.id);

        if (success) {
          if (this.getConfiguration().autoBatch) {
            _coalesceEnvelopes.call(this, nextEnvelope);
          }

          _queueSend.call(this, nextEnvelope);

          this._debug('Transport completed request', request.id, nextEnvelope);
        } else {
          // Keep the semantic of calling response callbacks asynchronously after the request
          var self = this;
          this.setTimeout(function () {
            self.complete(nextRequest, false, nextRequest.metaConnect);
            var failure = {
              reason: 'Previous request failed'
            };
            var xhr = nextRequest.xhr;
            failure.httpCode = self.xhrStatus(xhr);
            nextEnvelope.onFailure(xhr, nextEnvelope.messages, failure);
          }, 0);
        }
      }
    }

    _self.complete = function (request, success, metaConnect) {
      if (metaConnect) {
        _metaConnectComplete.call(this, request);
      } else {
        _complete.call(this, request, success);
      }
    };
    /**
     * Performs the actual send depending on the transport type details.
     * @param envelope the envelope to send
     * @param request the request information
     */


    _self.transportSend = function (envelope, request) {
      throw 'Abstract';
    };

    _self.transportSuccess = function (envelope, request, responses) {
      if (!request.expired) {
        this.clearTimeout(request.timeout);
        this.complete(request, true, request.metaConnect);

        if (responses && responses.length > 0) {
          envelope.onSuccess(responses);
        } else {
          envelope.onFailure(request.xhr, envelope.messages, {
            httpCode: 204
          });
        }
      }
    };

    _self.transportFailure = function (envelope, request, failure) {
      if (!request.expired) {
        this.clearTimeout(request.timeout);
        this.complete(request, false, request.metaConnect);
        envelope.onFailure(request.xhr, envelope.messages, failure);
      }
    };

    function _metaConnectSend(envelope) {
      if (_metaConnectRequest !== null) {
        throw 'Concurrent /meta/connect requests not allowed, request id=' + _metaConnectRequest.id + ' not yet completed';
      }

      var requestId = ++_requestIds;

      this._debug('Transport', this.getType(), '/meta/connect send, request', requestId, 'envelope', envelope);

      var request = {
        id: requestId,
        metaConnect: true,
        envelope: envelope
      };

      _transportSend.call(this, envelope, request);

      _metaConnectRequest = request;
    }

    _self.send = function (envelope, metaConnect) {
      if (metaConnect) {
        _metaConnectSend.call(this, envelope);
      } else {
        _queueSend.call(this, envelope);
      }
    };

    _self.abort = function () {
      _super.abort();

      for (var i = 0; i < _requests.length; ++i) {
        var request = _requests[i];

        if (request) {
          this._debug('Aborting request', request);

          if (!this.abortXHR(request.xhr)) {
            this.transportFailure(request.envelope, request, {
              reason: 'abort'
            });
          }
        }
      }

      var metaConnectRequest = _metaConnectRequest;

      if (metaConnectRequest) {
        this._debug('Aborting /meta/connect request', metaConnectRequest);

        if (!this.abortXHR(metaConnectRequest.xhr)) {
          this.transportFailure(metaConnectRequest.envelope, metaConnectRequest, {
            reason: 'abort'
          });
        }
      }

      this.reset(true);
    };

    _self.reset = function (init) {
      _super.reset(init);

      _metaConnectRequest = null;
      _requests = [];
      _envelopes = [];
    };

    _self.abortXHR = function (xhr) {
      if (xhr) {
        try {
          var state = xhr.readyState;
          xhr.abort();
          return state !== window.XMLHttpRequest.UNSENT;
        } catch (x) {
          this._debug(x);
        }
      }

      return false;
    };

    _self.xhrStatus = function (xhr) {
      if (xhr) {
        try {
          return xhr.status;
        } catch (x) {
          this._debug(x);
        }
      }

      return -1;
    };

    return _self;
  };

  var LongPollingTransport = function () {
    var _super = new RequestTransport();

    var _self = Transport.derive(_super); // By default, support cross domain


    var _supportsCrossDomain = true;

    _self.accept = function (version, crossDomain, url) {
      return _supportsCrossDomain || !crossDomain;
    };

    _self.newXMLHttpRequest = function () {
      return new window.XMLHttpRequest();
    };

    function _copyContext(xhr) {
      try {
        // Copy external context, to be used in other environments.
        xhr.context = _self.context;
      } catch (e) {
        // May happen if XHR is wrapped by Object.seal(),
        // Object.freeze(), or Object.preventExtensions().
        this._debug('Could not copy transport context into XHR', e);
      }
    }

    _self.xhrSend = function (packet) {
      var xhr = _self.newXMLHttpRequest();

      const httpNative = window.httpNative; // console.log(`xhrSend`, packet);

      if (!httpNative) {
        ///////
        _copyContext(xhr);

        xhr.withCredentials = true;
        xhr.open('POST', packet.url, packet.sync !== true);
        var headers = packet.headers;

        if (headers) {
          for (var headerName in headers) {
            if (headers.hasOwnProperty(headerName)) {
              xhr.setRequestHeader(headerName, headers[headerName]);
            }
          }
        }

        xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');

        xhr.onload = function () {
          if (xhr.status === 200) {
            packet.onSuccess(xhr.responseText);
          } else {
            packet.onError(xhr.statusText);
          }
        };

        xhr.onabort = xhr.onerror = function () {
          packet.onError(xhr.statusText);
        };

        xhr.send(packet.body); ///////
      } else {
        /////// HERE
        const httpNative = window.httpNative;
        httpNative.setDataSerializer("json"); // httpNative.setDataSerializer('json');

        var headers = packet.headers;

        if (headers) {
          for (var headerName in headers) {
            if (headers.hasOwnProperty(headerName)) {
              // xhr.setRequestHeader(headerName, headers[headerName]);
              httpNative.setHeader(headerName, headers[headerName]);
            }
          }
        }

        httpNative.post(packet.url, JSON.parse(packet.body), packet.headers, function (response) {
          const data = JSON.parse(response.data);
          packet.onSuccess(data); // console.dir(data);
        }, function (response) {
          const data = JSON.parse(response.data);
          packet.onError(data); // console.dir(data);
        }); ///////
      }

      return xhr;
    };

    _self.transportSend = function (envelope, request) {
      this._debug('Transport', this.getType(), 'sending request', request.id, 'envelope', envelope);

      var self = this;

      try {
        var sameStack = true;
        request.xhr = this.xhrSend({
          transport: this,
          url: envelope.url,
          sync: envelope.sync,
          headers: this.getConfiguration().requestHeaders,
          body: JSON.stringify(envelope.messages),
          onSuccess: function (response) {
            self._debug('Transport', self.getType(), 'received response', response);

            var success = false;

            try {
              var received = self.convertToMessages(response);

              if (received.length === 0) {
                _supportsCrossDomain = false;
                self.transportFailure(envelope, request, {
                  httpCode: 204
                });
              } else {
                success = true;
                self.transportSuccess(envelope, request, received);
              }
            } catch (x) {
              self._debug(x);

              if (!success) {
                _supportsCrossDomain = false;
                var failure = {
                  exception: x
                };
                failure.httpCode = self.xhrStatus(request.xhr);
                self.transportFailure(envelope, request, failure);
              }
            }
          },
          onError: function (reason, exception) {
            self._debug('Transport', self.getType(), 'received error', reason, exception);

            _supportsCrossDomain = false;
            var failure = {
              reason: reason,
              exception: exception
            };
            failure.httpCode = self.xhrStatus(request.xhr);

            if (sameStack) {
              // Keep the semantic of calling response callbacks asynchronously after the request
              self.setTimeout(function () {
                self.transportFailure(envelope, request, failure);
              }, 0);
            } else {
              self.transportFailure(envelope, request, failure);
            }
          }
        });
        sameStack = false;
      } catch (x) {
        _supportsCrossDomain = false; // Keep the semantic of calling response callbacks asynchronously after the request

        this.setTimeout(function () {
          self.transportFailure(envelope, request, {
            exception: x
          });
        }, 0);
      }
    };

    _self.reset = function (init) {
      _super.reset(init);

      _supportsCrossDomain = true;
    };

    return _self;
  };

  var CallbackPollingTransport = function () {
    var _super = new RequestTransport();

    var _self = Transport.derive(_super);

    var jsonp = 0;

    _self.accept = function (version, crossDomain, url) {
      return true;
    };

    _self.jsonpSend = function (packet) {
      var head = document.getElementsByTagName('head')[0];
      var script = document.createElement('script');
      var callbackName = '_cometd_jsonp_' + jsonp++;

      window[callbackName] = function (responseText) {
        head.removeChild(script);
        delete window[callbackName];
        packet.onSuccess(responseText);
      };

      var url = packet.url;
      url += url.indexOf('?') < 0 ? '?' : '&';
      url += 'jsonp=' + callbackName;
      url += '&message=' + encodeURIComponent(packet.body);
      script.src = url;
      script.async = packet.sync !== true;
      script.type = 'application/javascript';

      script.onerror = function (e) {
        packet.onError('jsonp ' + e.type);
      };

      head.appendChild(script);
    };

    function _failTransportFn(envelope, request, x) {
      var self = this;
      return function () {
        self.transportFailure(envelope, request, 'error', x);
      };
    }

    _self.transportSend = function (envelope, request) {
      var self = this; // Microsoft Internet Explorer has a 2083 URL max length
      // We must ensure that we stay within that length

      var start = 0;
      var length = envelope.messages.length;
      var lengths = [];

      while (length > 0) {
        // Encode the messages because all brackets, quotes, commas, colons, etc
        // present in the JSON will be URL encoded, taking many more characters
        var json = JSON.stringify(envelope.messages.slice(start, start + length));
        var urlLength = envelope.url.length + encodeURI(json).length;
        var maxLength = this.getConfiguration().maxURILength;

        if (urlLength > maxLength) {
          if (length === 1) {
            var x = 'Bayeux message too big (' + urlLength + ' bytes, max is ' + maxLength + ') ' + 'for transport ' + this.getType(); // Keep the semantic of calling response callbacks asynchronously after the request

            this.setTimeout(_failTransportFn.call(this, envelope, request, x), 0);
            return;
          }

          --length;
          continue;
        }

        lengths.push(length);
        start += length;
        length = envelope.messages.length - start;
      } // Here we are sure that the messages can be sent within the URL limit


      var envelopeToSend = envelope;

      if (lengths.length > 1) {
        var begin = 0;
        var end = lengths[0];

        this._debug('Transport', this.getType(), 'split', envelope.messages.length, 'messages into', lengths.join(' + '));

        envelopeToSend = this._mixin(false, {}, envelope);
        envelopeToSend.messages = envelope.messages.slice(begin, end);
        envelopeToSend.onSuccess = envelope.onSuccess;
        envelopeToSend.onFailure = envelope.onFailure;

        for (var i = 1; i < lengths.length; ++i) {
          var nextEnvelope = this._mixin(false, {}, envelope);

          begin = end;
          end += lengths[i];
          nextEnvelope.messages = envelope.messages.slice(begin, end);
          nextEnvelope.onSuccess = envelope.onSuccess;
          nextEnvelope.onFailure = envelope.onFailure;
          this.send(nextEnvelope, request.metaConnect);
        }
      }

      this._debug('Transport', this.getType(), 'sending request', request.id, 'envelope', envelopeToSend);

      try {
        var sameStack = true;
        this.jsonpSend({
          transport: this,
          url: envelopeToSend.url,
          sync: envelopeToSend.sync,
          headers: this.getConfiguration().requestHeaders,
          body: JSON.stringify(envelopeToSend.messages),
          onSuccess: function (responses) {
            var success = false;

            try {
              var received = self.convertToMessages(responses);

              if (received.length === 0) {
                self.transportFailure(envelopeToSend, request, {
                  httpCode: 204
                });
              } else {
                success = true;
                self.transportSuccess(envelopeToSend, request, received);
              }
            } catch (x) {
              self._debug(x);

              if (!success) {
                self.transportFailure(envelopeToSend, request, {
                  exception: x
                });
              }
            }
          },
          onError: function (reason, exception) {
            var failure = {
              reason: reason,
              exception: exception
            };

            if (sameStack) {
              // Keep the semantic of calling response callbacks asynchronously after the request
              self.setTimeout(function () {
                self.transportFailure(envelopeToSend, request, failure);
              }, 0);
            } else {
              self.transportFailure(envelopeToSend, request, failure);
            }
          }
        });
        sameStack = false;
      } catch (xx) {
        // Keep the semantic of calling response callbacks asynchronously after the request
        this.setTimeout(function () {
          self.transportFailure(envelopeToSend, request, {
            exception: xx
          });
        }, 0);
      }
    };

    return _self;
  };

  var WebSocketTransport = function () {
    var _super = new Transport();

    var _self = Transport.derive(_super);

    var _cometd; // By default WebSocket is supported


    var _webSocketSupported = true; // Whether we were able to establish a WebSocket connection

    var _webSocketConnected = false;
    var _stickyReconnect = true; // The context contains the envelopes that have been sent
    // and the timeouts for the messages that have been sent.

    var _context = null;
    var _connecting = null;
    var _connected = false;
    var _successCallback = null;

    _self.reset = function (init) {
      _super.reset(init);

      _webSocketSupported = true;

      if (init) {
        _webSocketConnected = false;
      }

      _stickyReconnect = true;
      _context = null;
      _connecting = null;
      _connected = false;
    };

    function _forceClose(context, event) {
      if (context) {
        this.webSocketClose(context, event.code, event.reason); // Force immediate failure of pending messages to trigger reconnect.
        // This is needed because the server may not reply to our close()
        // and therefore the onclose function is never called.

        this.onClose(context, event);
      }
    }

    function _sameContext(context) {
      return context === _connecting || context === _context;
    }

    function _storeEnvelope(context, envelope, metaConnect) {
      var messageIds = [];

      for (var i = 0; i < envelope.messages.length; ++i) {
        var message = envelope.messages[i];

        if (message.id) {
          messageIds.push(message.id);
        }
      }

      context.envelopes[messageIds.join(',')] = [envelope, metaConnect];

      this._debug('Transport', this.getType(), 'stored envelope, envelopes', context.envelopes);
    }

    function _websocketConnect(context) {
      // We may have multiple attempts to open a WebSocket
      // connection, for example a /meta/connect request that
      // may take time, along with a user-triggered publish.
      // Early return if we are already connecting.
      if (_connecting) {
        return;
      } // Mangle the URL, changing the scheme from 'http' to 'ws'.


      var url = _cometd.getURL().replace(/^http/, 'ws');

      this._debug('Transport', this.getType(), 'connecting to URL', url);

      try {
        var protocol = _cometd.getConfiguration().protocol;

        context.webSocket = protocol ? new window.WebSocket(url, protocol) : new window.WebSocket(url);
        _connecting = context;
      } catch (x) {
        _webSocketSupported = false;

        this._debug('Exception while creating WebSocket object', x);

        throw x;
      } // By default use sticky reconnects.


      _stickyReconnect = _cometd.getConfiguration().stickyReconnect !== false;
      var self = this;

      var connectTimeout = _cometd.getConfiguration().connectTimeout;

      if (connectTimeout > 0) {
        context.connectTimer = this.setTimeout(function () {
          _cometd._debug('Transport', self.getType(), 'timed out while connecting to URL', url, ':', connectTimeout, 'ms'); // The connection was not opened, close anyway.


          _forceClose.call(self, context, {
            code: 1000,
            reason: 'Connect Timeout'
          });
        }, connectTimeout);
      }

      var onopen = function () {
        _cometd._debug('WebSocket onopen', context);

        if (context.connectTimer) {
          self.clearTimeout(context.connectTimer);
        }

        if (_sameContext(context)) {
          _connecting = null;
          _context = context;
          _webSocketConnected = true;
          self.onOpen(context);
        } else {
          // We have a valid connection already, close this one.
          _cometd._warn('Closing extra WebSocket connection', this, 'active connection', _context);

          _forceClose.call(self, context, {
            code: 1000,
            reason: 'Extra Connection'
          });
        }
      }; // This callback is invoked when the server sends the close frame.
      // The close frame for a connection may arrive *after* another
      // connection has been opened, so we must make sure that actions
      // are performed only if it's the same connection.


      var onclose = function (event) {
        event = event || {
          code: 1000
        };

        _cometd._debug('WebSocket onclose', context, event, 'connecting', _connecting, 'current', _context);

        if (context.connectTimer) {
          self.clearTimeout(context.connectTimer);
        }

        self.onClose(context, event);
      };

      var onmessage = function (wsMessage) {
        _cometd._debug('WebSocket onmessage', wsMessage, context);

        self.onMessage(context, wsMessage);
      };

      context.webSocket.onopen = onopen;
      context.webSocket.onclose = onclose;

      context.webSocket.onerror = function () {
        // Clients should call onclose(), but if they do not we do it here for safety.
        onclose({
          code: 1000,
          reason: 'Error'
        });
      };

      context.webSocket.onmessage = onmessage;

      this._debug('Transport', this.getType(), 'configured callbacks on', context);
    }

    function _webSocketSend(context, envelope, metaConnect) {
      var json = JSON.stringify(envelope.messages);
      context.webSocket.send(json);

      this._debug('Transport', this.getType(), 'sent', envelope, '/meta/connect =', metaConnect); // Manage the timeout waiting for the response.


      var maxDelay = this.getConfiguration().maxNetworkDelay;
      var delay = maxDelay;

      if (metaConnect) {
        delay += this.getAdvice().timeout;
        _connected = true;
      }

      var self = this;
      var messageIds = [];

      for (var i = 0; i < envelope.messages.length; ++i) {
        (function () {
          var message = envelope.messages[i];

          if (message.id) {
            messageIds.push(message.id);
            context.timeouts[message.id] = self.setTimeout(function () {
              _cometd._debug('Transport', self.getType(), 'timing out message', message.id, 'after', delay, 'on', context);

              _forceClose.call(self, context, {
                code: 1000,
                reason: 'Message Timeout'
              });
            }, delay);
          }
        })();
      }

      this._debug('Transport', this.getType(), 'waiting at most', delay, 'ms for messages', messageIds, 'maxNetworkDelay', maxDelay, ', timeouts:', context.timeouts);
    }

    _self._notifySuccess = function (fn, messages) {
      fn.call(this, messages);
    };

    _self._notifyFailure = function (fn, context, messages, failure) {
      fn.call(this, context, messages, failure);
    };

    function _send(context, envelope, metaConnect) {
      try {
        if (context === null) {
          context = _connecting || {
            envelopes: {},
            timeouts: {}
          };

          _storeEnvelope.call(this, context, envelope, metaConnect);

          _websocketConnect.call(this, context);
        } else {
          _storeEnvelope.call(this, context, envelope, metaConnect);

          _webSocketSend.call(this, context, envelope, metaConnect);
        }
      } catch (x) {
        // Keep the semantic of calling response callbacks asynchronously after the request.
        var self = this;
        this.setTimeout(function () {
          _forceClose.call(self, context, {
            code: 1000,
            reason: 'Exception',
            exception: x
          });
        }, 0);
      }
    }

    _self.onOpen = function (context) {
      var envelopes = context.envelopes;

      this._debug('Transport', this.getType(), 'opened', context, 'pending messages', envelopes);

      for (var key in envelopes) {
        if (envelopes.hasOwnProperty(key)) {
          var element = envelopes[key];
          var envelope = element[0];
          var metaConnect = element[1]; // Store the success callback, which is independent from the envelope,
          // so that it can be used to notify arrival of messages.

          _successCallback = envelope.onSuccess;

          _webSocketSend.call(this, context, envelope, metaConnect);
        }
      }
    };

    _self.onMessage = function (context, wsMessage) {
      this._debug('Transport', this.getType(), 'received websocket message', wsMessage, context);

      var close = false;
      var messages = this.convertToMessages(wsMessage.data);
      var messageIds = [];

      for (var i = 0; i < messages.length; ++i) {
        var message = messages[i]; // Detect if the message is a response to a request we made.
        // If it's a meta message, for sure it's a response; otherwise it's
        // a publish message and publish responses don't have the data field.

        if (/^\/meta\//.test(message.channel) || message.data === undefined) {
          if (message.id) {
            messageIds.push(message.id);
            var timeout = context.timeouts[message.id];

            if (timeout) {
              this.clearTimeout(timeout);
              delete context.timeouts[message.id];

              this._debug('Transport', this.getType(), 'removed timeout for message', message.id, ', timeouts', context.timeouts);
            }
          }
        }

        if ('/meta/connect' === message.channel) {
          _connected = false;
        }

        if ('/meta/disconnect' === message.channel && !_connected) {
          close = true;
        }
      } // Remove the envelope corresponding to the messages.


      var removed = false;
      var envelopes = context.envelopes;

      for (var j = 0; j < messageIds.length; ++j) {
        var id = messageIds[j];

        for (var key in envelopes) {
          if (envelopes.hasOwnProperty(key)) {
            var ids = key.split(',');
            var index = Utils.inArray(id, ids);

            if (index >= 0) {
              removed = true;
              ids.splice(index, 1);
              var envelope = envelopes[key][0];
              var metaConnect = envelopes[key][1];
              delete envelopes[key];

              if (ids.length > 0) {
                envelopes[ids.join(',')] = [envelope, metaConnect];
              }

              break;
            }
          }
        }
      }

      if (removed) {
        this._debug('Transport', this.getType(), 'removed envelope, envelopes', envelopes);
      }

      this._notifySuccess(_successCallback, messages);

      if (close) {
        this.webSocketClose(context, 1000, 'Disconnect');
      }
    };

    _self.onClose = function (context, event) {
      this._debug('Transport', this.getType(), 'closed', context, event);

      if (_sameContext(context)) {
        // Remember if we were able to connect.
        // This close event could be due to server shutdown,
        // and if it restarts we want to try websocket again.
        _webSocketSupported = _stickyReconnect && _webSocketConnected;
        _connecting = null;
        _context = null;
      }

      var timeouts = context.timeouts;
      context.timeouts = {};

      for (var id in timeouts) {
        if (timeouts.hasOwnProperty(id)) {
          this.clearTimeout(timeouts[id]);
        }
      }

      var envelopes = context.envelopes;
      context.envelopes = {};

      for (var key in envelopes) {
        if (envelopes.hasOwnProperty(key)) {
          var envelope = envelopes[key][0];
          var metaConnect = envelopes[key][1];

          if (metaConnect) {
            _connected = false;
          }

          var failure = {
            websocketCode: event.code,
            reason: event.reason
          };

          if (event.exception) {
            failure.exception = event.exception;
          }

          this._notifyFailure(envelope.onFailure, context, envelope.messages, failure);
        }
      }
    };

    _self.registered = function (type, cometd) {
      _super.registered(type, cometd);

      _cometd = cometd;
    };

    _self.accept = function (version, crossDomain, url) {
      this._debug('Transport', this.getType(), 'accept, supported:', _webSocketSupported); // Using !! to return a boolean (and not the WebSocket object).


      return _webSocketSupported && !!window.WebSocket && _cometd.websocketEnabled !== false;
    };

    _self.send = function (envelope, metaConnect) {
      this._debug('Transport', this.getType(), 'sending', envelope, '/meta/connect =', metaConnect);

      _send.call(this, _context, envelope, metaConnect);
    };

    _self.webSocketClose = function (context, code, reason) {
      try {
        if (context.webSocket) {
          context.webSocket.close(code, reason);
        }
      } catch (x) {
        this._debug(x);
      }
    };

    _self.abort = function () {
      _super.abort();

      _forceClose.call(this, _context, {
        code: 1000,
        reason: 'Abort'
      });

      this.reset(true);
    };

    return _self;
  };
  /**
   * The constructor for a CometD object, identified by an optional name.
   * The default name is the string 'default'.
   * @param name the optional name of this cometd object
   */


  var CometD = function (name) {
    var _scheduler = new Scheduler();

    var _cometd = this;

    var _name = name || 'default';

    var _crossDomain = false;

    var _transports = new TransportRegistry();

    var _transport;

    var _status = 'disconnected';
    var _messageId = 0;
    var _clientId = null;
    var _batch = 0;
    var _messageQueue = [];
    var _internalBatch = false;
    var _listenerId = 0;
    var _listeners = {};
    var _backoff = 0;
    var _scheduledSend = null;
    var _extensions = [];
    var _advice = {};

    var _handshakeProps;

    var _handshakeCallback;

    var _callbacks = {};
    var _remoteCalls = {};
    var _reestablish = false;
    var _connected = false;
    var _unconnectTime = 0;
    var _handshakeMessages = 0;
    var _metaConnect = null;
    var _config = {
      useWorkerScheduler: true,
      protocol: null,
      stickyReconnect: true,
      connectTimeout: 0,
      maxConnections: 2,
      backoffIncrement: 1000,
      maxBackoff: 60000,
      logLevel: 'info',
      maxNetworkDelay: 10000,
      requestHeaders: {},
      appendMessageTypeToURL: true,
      autoBatch: false,
      urls: {},
      maxURILength: 2000,
      advice: {
        timeout: 60000,
        interval: 0,
        reconnect: undefined,
        maxInterval: 0
      }
    };

    function _fieldValue(object, name) {
      try {
        return object[name];
      } catch (x) {
        return undefined;
      }
    }
    /**
     * Mixes in the given objects into the target object by copying the properties.
     * @param deep if the copy must be deep
     * @param target the target object
     * @param objects the objects whose properties are copied into the target
     */


    this._mixin = function (deep, target, objects) {
      var result = target || {}; // Skip first 2 parameters (deep and target), and loop over the others

      for (var i = 2; i < arguments.length; ++i) {
        var object = arguments[i];

        if (object === undefined || object === null) {
          continue;
        }

        for (var propName in object) {
          if (object.hasOwnProperty(propName)) {
            var prop = _fieldValue(object, propName);

            var targ = _fieldValue(result, propName); // Avoid infinite loops


            if (prop === target) {
              continue;
            } // Do not mixin undefined values


            if (prop === undefined) {
              continue;
            }

            if (deep && typeof prop === 'object' && prop !== null) {
              if (prop instanceof Array) {
                result[propName] = this._mixin(deep, targ instanceof Array ? targ : [], prop);
              } else {
                var source = typeof targ === 'object' && !(targ instanceof Array) ? targ : {};
                result[propName] = this._mixin(deep, source, prop);
              }
            } else {
              result[propName] = prop;
            }
          }
        }
      }

      return result;
    };

    function _isString(value) {
      return Utils.isString(value);
    }

    function _isFunction(value) {
      if (value === undefined || value === null) {
        return false;
      }

      return typeof value === 'function';
    }

    function _zeroPad(value, length) {
      var result = '';

      while (--length > 0) {
        if (value >= Math.pow(10, length)) {
          break;
        }

        result += '0';
      }

      result += value;
      return result;
    }

    function _log(level, args) {
      if (window.console) {
        var logger = window.console[level];

        if (_isFunction(logger)) {
          var now = new Date();
          [].splice.call(args, 0, 0, _zeroPad(now.getHours(), 2) + ':' + _zeroPad(now.getMinutes(), 2) + ':' + _zeroPad(now.getSeconds(), 2) + '.' + _zeroPad(now.getMilliseconds(), 3));
          logger.apply(window.console, args);
        }
      }
    }

    this._warn = function () {
      _log('warn', arguments);
    };

    this._info = function () {
      if (_config.logLevel !== 'warn') {
        _log('info', arguments);
      }
    };

    this._debug = function () {
      if (_config.logLevel === 'debug') {
        _log('debug', arguments);
      }
    };

    function _splitURL(url) {
      // [1] = protocol://,
      // [2] = host:port,
      // [3] = host,
      // [4] = IPv6_host,
      // [5] = IPv4_host,
      // [6] = :port,
      // [7] = port,
      // [8] = uri,
      // [9] = rest (query / fragment)
      return new RegExp('(^https?://)?(((\\[[^\\]]+])|([^:/?#]+))(:(\\d+))?)?([^?#]*)(.*)?').exec(url);
    }
    /**
     * Returns whether the given hostAndPort is cross domain.
     * The default implementation checks against window.location.host
     * but this function can be overridden to make it work in non-browser
     * environments.
     *
     * @param hostAndPort the host and port in format host:port
     * @return whether the given hostAndPort is cross domain
     */


    this._isCrossDomain = function (hostAndPort) {
      if (window.location && window.location.host) {
        if (hostAndPort) {
          return hostAndPort !== window.location.host;
        }
      }

      return false;
    };

    function _configure(configuration) {
      _cometd._debug('Configuring cometd object with', configuration); // Support old style param, where only the Bayeux server URL was passed.


      if (_isString(configuration)) {
        configuration = {
          url: configuration
        };
      }

      if (!configuration) {
        configuration = {};
      }

      _config = _cometd._mixin(false, _config, configuration);

      var url = _cometd.getURL();

      if (!url) {
        throw 'Missing required configuration parameter \'url\' specifying the Bayeux server URL';
      } // Check if we're cross domain.


      var urlParts = _splitURL(url);

      var hostAndPort = urlParts[2];
      var uri = urlParts[8];
      var afterURI = urlParts[9];
      _crossDomain = _cometd._isCrossDomain(hostAndPort); // Check if appending extra path is supported.

      if (_config.appendMessageTypeToURL) {
        if (afterURI !== undefined && afterURI.length > 0) {
          _cometd._info('Appending message type to URI ' + uri + afterURI + ' is not supported, disabling \'appendMessageTypeToURL\' configuration');

          _config.appendMessageTypeToURL = false;
        } else {
          var uriSegments = uri.split('/');
          var lastSegmentIndex = uriSegments.length - 1;

          if (uri.match(/\/$/)) {
            lastSegmentIndex -= 1;
          }

          if (uriSegments[lastSegmentIndex].indexOf('.') >= 0) {
            // Very likely the CometD servlet's URL pattern is mapped to an extension, such as *.cometd
            // It will be difficult to add the extra path in this case
            _cometd._info('Appending message type to URI ' + uri + ' is not supported, disabling \'appendMessageTypeToURL\' configuration');

            _config.appendMessageTypeToURL = false;
          }
        }
      }

      if (window.Worker && window.Blob && window.URL && _config.useWorkerScheduler) {
        var code = WorkerScheduler.toString(); // Remove the function declaration, the opening brace and the closing brace.

        code = code.substring(code.indexOf('{') + 1, code.lastIndexOf('}'));
        var blob = new window.Blob([code], {
          type: 'application/json'
        });
        var blobURL = window.URL.createObjectURL(blob);
        var worker = new window.Worker(blobURL);

        _scheduler.setTimeout = function (funktion, delay) {
          var id = _scheduler.register(funktion);

          worker.postMessage({
            id: id,
            type: 'setTimeout',
            delay: delay
          });
          return id;
        };

        _scheduler.clearTimeout = function (id) {
          _scheduler.unregister(id);

          worker.postMessage({
            id: id,
            type: 'clearTimeout'
          });
        };

        worker.onmessage = function (e) {
          var id = e.data.id;

          var funktion = _scheduler.unregister(id);

          if (funktion) {
            funktion();
          }
        };
      }
    }

    function _removeListener(subscription) {
      if (subscription) {
        var subscriptions = _listeners[subscription.channel];

        if (subscriptions && subscriptions[subscription.id]) {
          delete subscriptions[subscription.id];

          _cometd._debug('Removed', subscription.listener ? 'listener' : 'subscription', subscription);
        }
      }
    }

    function _removeSubscription(subscription) {
      if (subscription && !subscription.listener) {
        _removeListener(subscription);
      }
    }

    function _clearSubscriptions() {
      for (var channel in _listeners) {
        if (_listeners.hasOwnProperty(channel)) {
          var subscriptions = _listeners[channel];

          if (subscriptions) {
            for (var id in subscriptions) {
              if (subscriptions.hasOwnProperty(id)) {
                _removeSubscription(subscriptions[id]);
              }
            }
          }
        }
      }
    }

    function _setStatus(newStatus) {
      if (_status !== newStatus) {
        _cometd._debug('Status', _status, '->', newStatus);

        _status = newStatus;
      }
    }

    function _isDisconnected() {
      return _status === 'disconnecting' || _status === 'disconnected';
    }

    function _nextMessageId() {
      var result = ++_messageId;
      return '' + result;
    }

    function _applyExtension(scope, callback, name, message, outgoing) {
      try {
        return callback.call(scope, message);
      } catch (x) {
        var handler = _cometd.onExtensionException;

        if (_isFunction(handler)) {
          _cometd._debug('Invoking extension exception handler', name, x);

          try {
            handler.call(_cometd, x, name, outgoing, message);
          } catch (xx) {
            _cometd._info('Exception during execution of extension exception handler', name, xx);
          }
        } else {
          _cometd._info('Exception during execution of extension', name, x);
        }

        return message;
      }
    }

    function _applyIncomingExtensions(message) {
      for (var i = 0; i < _extensions.length; ++i) {
        if (message === undefined || message === null) {
          break;
        }

        var extension = _extensions[i];
        var callback = extension.extension.incoming;

        if (_isFunction(callback)) {
          var result = _applyExtension(extension.extension, callback, extension.name, message, false);

          message = result === undefined ? message : result;
        }
      }

      return message;
    }

    function _applyOutgoingExtensions(message) {
      for (var i = _extensions.length - 1; i >= 0; --i) {
        if (message === undefined || message === null) {
          break;
        }

        var extension = _extensions[i];
        var callback = extension.extension.outgoing;

        if (_isFunction(callback)) {
          var result = _applyExtension(extension.extension, callback, extension.name, message, true);

          message = result === undefined ? message : result;
        }
      }

      return message;
    }

    function _notify(channel, message) {
      var subscriptions = _listeners[channel];

      if (subscriptions) {
        for (var id in subscriptions) {
          if (subscriptions.hasOwnProperty(id)) {
            var subscription = subscriptions[id]; // Subscriptions may come and go, so the array may have 'holes'

            if (subscription) {
              try {
                subscription.callback.call(subscription.scope, message);
              } catch (x) {
                var handler = _cometd.onListenerException;

                if (_isFunction(handler)) {
                  _cometd._debug('Invoking listener exception handler', subscription, x);

                  try {
                    handler.call(_cometd, x, subscription, subscription.listener, message);
                  } catch (xx) {
                    _cometd._info('Exception during execution of listener exception handler', subscription, xx);
                  }
                } else {
                  _cometd._info('Exception during execution of listener', subscription, message, x);
                }
              }
            }
          }
        }
      }
    }

    function _notifyListeners(channel, message) {
      // Notify direct listeners
      _notify(channel, message); // Notify the globbing listeners


      var channelParts = channel.split('/');
      var last = channelParts.length - 1;

      for (var i = last; i > 0; --i) {
        var channelPart = channelParts.slice(0, i).join('/') + '/*'; // We don't want to notify /foo/* if the channel is /foo/bar/baz,
        // so we stop at the first non recursive globbing

        if (i === last) {
          _notify(channelPart, message);
        } // Add the recursive globber and notify


        channelPart += '*';

        _notify(channelPart, message);
      }
    }

    function _cancelDelayedSend() {
      if (_scheduledSend !== null) {
        _cometd.clearTimeout(_scheduledSend);
      }

      _scheduledSend = null;
    }

    function _delayedSend(operation, delay) {
      _cancelDelayedSend();

      var time = _advice.interval + delay;

      _cometd._debug('Function scheduled in', time, 'ms, interval =', _advice.interval, 'backoff =', _backoff, operation);

      _scheduledSend = _cometd.setTimeout(operation, time);
    } // Needed to break cyclic dependencies between function definitions


    var _handleMessages;

    var _handleFailure;
    /**
     * Delivers the messages to the CometD server
     * @param sync whether the send is synchronous
     * @param messages the array of messages to send
     * @param metaConnect true if this send is on /meta/connect
     * @param extraPath an extra path to append to the Bayeux server URL
     */


    function _send(sync, messages, metaConnect, extraPath) {
      // We must be sure that the messages have a clientId.
      // This is not guaranteed since the handshake may take time to return
      // (and hence the clientId is not known yet) and the application
      // may create other messages.
      for (var i = 0; i < messages.length; ++i) {
        var message = messages[i];
        var messageId = message.id;

        if (_clientId) {
          message.clientId = _clientId;
        }

        message = _applyOutgoingExtensions(message);

        if (message !== undefined && message !== null) {
          // Extensions may have modified the message id, but we need to own it.
          message.id = messageId;
          messages[i] = message;
        } else {
          delete _callbacks[messageId];
          messages.splice(i--, 1);
        }
      }

      if (messages.length === 0) {
        return;
      }

      if (metaConnect) {
        _metaConnect = messages[0];
      }

      var url = _cometd.getURL();

      if (_config.appendMessageTypeToURL) {
        // If url does not end with '/', then append it
        if (!url.match(/\/$/)) {
          url = url + '/';
        }

        if (extraPath) {
          url = url + extraPath;
        }
      }

      var envelope = {
        url: url,
        sync: sync,
        messages: messages,
        onSuccess: function (rcvdMessages) {
          try {
            _handleMessages.call(_cometd, rcvdMessages);
          } catch (x) {
            _cometd._info('Exception during handling of messages', x);
          }
        },
        onFailure: function (conduit, messages, failure) {
          try {
            var transport = _cometd.getTransport();

            failure.connectionType = transport ? transport.getType() : "unknown";

            _handleFailure.call(_cometd, conduit, messages, failure);
          } catch (x) {
            _cometd._info('Exception during handling of failure', x);
          }
        }
      };

      _cometd._debug('Send', envelope);

      _transport.send(envelope, metaConnect);
    }

    function _queueSend(message) {
      if (_batch > 0 || _internalBatch === true) {
        _messageQueue.push(message);
      } else {
        _send(false, [message], false);
      }
    }
    /**
     * Sends a complete bayeux message.
     * This method is exposed as a public so that extensions may use it
     * to send bayeux message directly, for example in case of re-sending
     * messages that have already been sent but that for some reason must
     * be resent.
     */


    this.send = _queueSend;

    function _resetBackoff() {
      _backoff = 0;
    }

    function _increaseBackoff() {
      if (_backoff < _config.maxBackoff) {
        _backoff += _config.backoffIncrement;
      }

      return _backoff;
    }
    /**
     * Starts a the batch of messages to be sent in a single request.
     * @see #_endBatch(sendMessages)
     */


    function _startBatch() {
      ++_batch;

      _cometd._debug('Starting batch, depth', _batch);
    }

    function _flushBatch() {
      var messages = _messageQueue;
      _messageQueue = [];

      if (messages.length > 0) {
        _send(false, messages, false);
      }
    }
    /**
     * Ends the batch of messages to be sent in a single request,
     * optionally sending messages present in the message queue depending
     * on the given argument.
     * @see #_startBatch()
     */


    function _endBatch() {
      --_batch;

      _cometd._debug('Ending batch, depth', _batch);

      if (_batch < 0) {
        throw 'Calls to startBatch() and endBatch() are not paired';
      }

      if (_batch === 0 && !_isDisconnected() && !_internalBatch) {
        _flushBatch();
      }
    }
    /**
     * Sends the connect message
     */


    function _connect() {
      if (!_isDisconnected()) {
        var bayeuxMessage = {
          id: _nextMessageId(),
          channel: '/meta/connect',
          connectionType: _transport.getType()
        }; // In case of reload or temporary loss of connection
        // we want the next successful connect to return immediately
        // instead of being held by the server, so that connect listeners
        // can be notified that the connection has been re-established

        if (!_connected) {
          bayeuxMessage.advice = {
            timeout: 0
          };
        }

        _setStatus('connecting');

        _cometd._debug('Connect sent', bayeuxMessage);

        _send(false, [bayeuxMessage], true, 'connect');

        _setStatus('connected');
      }
    }

    function _delayedConnect(delay) {
      _setStatus('connecting');

      _delayedSend(function () {
        _connect();
      }, delay);
    }

    function _updateAdvice(newAdvice) {
      if (newAdvice) {
        _advice = _cometd._mixin(false, {}, _config.advice, newAdvice);

        _cometd._debug('New advice', _advice);
      }
    }

    function _disconnect(abort) {
      _cancelDelayedSend();

      if (abort && _transport) {
        _transport.abort();
      }

      _crossDomain = false;
      _transport = null;

      _setStatus('disconnected');

      _clientId = null;
      _batch = 0;

      _resetBackoff();

      _reestablish = false;
      _connected = false;
      _unconnectTime = 0;
      _metaConnect = null; // Fail any existing queued message

      if (_messageQueue.length > 0) {
        var messages = _messageQueue;
        _messageQueue = [];

        _handleFailure.call(_cometd, undefined, messages, {
          reason: 'Disconnected'
        });
      }
    }

    function _notifyTransportException(oldTransport, newTransport, failure) {
      var handler = _cometd.onTransportException;

      if (_isFunction(handler)) {
        _cometd._debug('Invoking transport exception handler', oldTransport, newTransport, failure);

        try {
          handler.call(_cometd, failure, oldTransport, newTransport);
        } catch (x) {
          _cometd._info('Exception during execution of transport exception handler', x);
        }
      }
    }
    /**
     * Sends the initial handshake message
     */


    function _handshake(handshakeProps, handshakeCallback) {
      if (_isFunction(handshakeProps)) {
        handshakeCallback = handshakeProps;
        handshakeProps = undefined;
      }

      _clientId = null;

      _clearSubscriptions(); // Reset the transports if we're not retrying the handshake


      if (_isDisconnected()) {
        _transports.reset(true);
      } // Reset the advice.


      _updateAdvice({});

      _batch = 0; // Mark the start of an internal batch.
      // This is needed because handshake and connect are async.
      // It may happen that the application calls init() then subscribe()
      // and the subscribe message is sent before the connect message, if
      // the subscribe message is not held until the connect message is sent.
      // So here we start a batch to hold temporarily any message until
      // the connection is fully established.

      _internalBatch = true; // Save the properties provided by the user, so that
      // we can reuse them during automatic re-handshake

      _handshakeProps = handshakeProps;
      _handshakeCallback = handshakeCallback;
      var version = '1.0'; // Figure out the transports to send to the server

      var url = _cometd.getURL();

      var transportTypes = _transports.findTransportTypes(version, _crossDomain, url);

      var bayeuxMessage = {
        id: _nextMessageId(),
        version: version,
        minimumVersion: version,
        channel: '/meta/handshake',
        supportedConnectionTypes: transportTypes,
        advice: {
          timeout: _advice.timeout,
          interval: _advice.interval
        }
      }; // Do not allow the user to override important fields.

      var message = _cometd._mixin(false, {}, _handshakeProps, bayeuxMessage); // Save the callback.


      _cometd._putCallback(message.id, handshakeCallback); // Pick up the first available transport as initial transport
      // since we don't know if the server supports it


      if (!_transport) {
        _transport = _transports.negotiateTransport(transportTypes, version, _crossDomain, url);

        if (!_transport) {
          var failure = 'Could not find initial transport among: ' + _transports.getTransportTypes();

          _cometd._warn(failure);

          throw failure;
        }
      }

      _cometd._debug('Initial transport is', _transport.getType()); // We started a batch to hold the application messages,
      // so here we must bypass it and send immediately.


      _setStatus('handshaking');

      _cometd._debug('Handshake sent', message);

      _send(false, [message], false, 'handshake');
    }

    function _delayedHandshake(delay) {
      _setStatus('handshaking'); // We will call _handshake() which will reset _clientId, but we want to avoid
      // that between the end of this method and the call to _handshake() someone may
      // call publish() (or other methods that call _queueSend()).


      _internalBatch = true;

      _delayedSend(function () {
        _handshake(_handshakeProps, _handshakeCallback);
      }, delay);
    }

    function _notifyCallback(callback, message) {
      try {
        callback.call(_cometd, message);
      } catch (x) {
        var handler = _cometd.onCallbackException;

        if (_isFunction(handler)) {
          _cometd._debug('Invoking callback exception handler', x);

          try {
            handler.call(_cometd, x, message);
          } catch (xx) {
            _cometd._info('Exception during execution of callback exception handler', xx);
          }
        } else {
          _cometd._info('Exception during execution of message callback', x);
        }
      }
    }

    this._getCallback = function (messageId) {
      return _callbacks[messageId];
    };

    this._putCallback = function (messageId, callback) {
      var result = this._getCallback(messageId);

      if (_isFunction(callback)) {
        _callbacks[messageId] = callback;
      }

      return result;
    };

    function _handleCallback(message) {
      var callback = _cometd._getCallback([message.id]);

      if (_isFunction(callback)) {
        delete _callbacks[message.id];

        _notifyCallback(callback, message);
      }
    }

    function _handleRemoteCall(message) {
      var context = _remoteCalls[message.id];
      delete _remoteCalls[message.id];

      if (context) {
        _cometd._debug('Handling remote call response for', message, 'with context', context); // Clear the timeout, if present.


        var timeout = context.timeout;

        if (timeout) {
          _cometd.clearTimeout(timeout);
        }

        var callback = context.callback;

        if (_isFunction(callback)) {
          _notifyCallback(callback, message);

          return true;
        }
      }

      return false;
    }

    this.onTransportFailure = function (message, failureInfo, failureHandler) {
      this._debug('Transport failure', failureInfo, 'for', message);

      var transports = this.getTransportRegistry();
      var url = this.getURL();

      var crossDomain = this._isCrossDomain(_splitURL(url)[2]);

      var version = '1.0';
      var transportTypes = transports.findTransportTypes(version, crossDomain, url);

      if (failureInfo.action === 'none') {
        if (message.channel === '/meta/handshake') {
          if (!failureInfo.transport) {
            var failure = 'Could not negotiate transport, client=[' + transportTypes + '], server=[' + message.supportedConnectionTypes + ']';

            this._warn(failure);

            _notifyTransportException(_transport.getType(), null, {
              reason: failure,
              connectionType: _transport.getType(),
              transport: _transport
            });
          }
        }
      } else {
        failureInfo.delay = this.getBackoffPeriod(); // Different logic depending on whether we are handshaking or connecting.

        if (message.channel === '/meta/handshake') {
          if (!failureInfo.transport) {
            // The transport is invalid, try to negotiate again.
            var oldTransportType = _transport ? _transport.getType() : null;
            var newTransport = transports.negotiateTransport(transportTypes, version, crossDomain, url);

            if (!newTransport) {
              this._warn('Could not negotiate transport, client=[' + transportTypes + ']');

              _notifyTransportException(oldTransportType, null, message.failure);

              failureInfo.action = 'none';
            } else {
              var newTransportType = newTransport.getType();

              this._debug('Transport', oldTransportType, '->', newTransportType);

              _notifyTransportException(oldTransportType, newTransportType, message.failure);

              failureInfo.action = 'handshake';
              failureInfo.transport = newTransport;
            }
          }

          if (failureInfo.action !== 'none') {
            this.increaseBackoffPeriod();
          }
        } else {
          var now = new Date().getTime();

          if (_unconnectTime === 0) {
            _unconnectTime = now;
          }

          if (failureInfo.action === 'retry') {
            failureInfo.delay = this.increaseBackoffPeriod(); // Check whether we may switch to handshaking.

            var maxInterval = _advice.maxInterval;

            if (maxInterval > 0) {
              var expiration = _advice.timeout + _advice.interval + maxInterval;
              var unconnected = now - _unconnectTime;

              if (unconnected + _backoff > expiration) {
                failureInfo.action = 'handshake';
              }
            }
          }

          if (failureInfo.action === 'handshake') {
            failureInfo.delay = 0;
            transports.reset(false);
            this.resetBackoffPeriod();
          }
        }
      }

      failureHandler.call(_cometd, failureInfo);
    };

    function _handleTransportFailure(failureInfo) {
      _cometd._debug('Transport failure handling', failureInfo);

      if (failureInfo.transport) {
        _transport = failureInfo.transport;
      }

      if (failureInfo.url) {
        _transport.setURL(failureInfo.url);
      }

      var action = failureInfo.action;
      var delay = failureInfo.delay || 0;

      switch (action) {
        case 'handshake':
          _delayedHandshake(delay);

          break;

        case 'retry':
          _delayedConnect(delay);

          break;

        case 'none':
          _disconnect(true);

          break;

        default:
          throw 'Unknown action ' + action;
      }
    }

    function _failHandshake(message, failureInfo) {
      _handleCallback(message);

      _notifyListeners('/meta/handshake', message);

      _notifyListeners('/meta/unsuccessful', message); // The listeners may have disconnected.


      if (_isDisconnected()) {
        failureInfo.action = 'none';
      }

      _cometd.onTransportFailure.call(_cometd, message, failureInfo, _handleTransportFailure);
    }

    function _handshakeResponse(message) {
      var url = _cometd.getURL();

      if (message.successful) {
        var crossDomain = _cometd._isCrossDomain(_splitURL(url)[2]);

        var newTransport = _transports.negotiateTransport(message.supportedConnectionTypes, message.version, crossDomain, url);

        if (newTransport === null) {
          message.successful = false;

          _failHandshake(message, {
            cause: 'negotiation',
            action: 'none',
            transport: null
          });

          return;
        } else if (_transport !== newTransport) {
          _cometd._debug('Transport', _transport.getType(), '->', newTransport.getType());

          _transport = newTransport;
        }

        _clientId = message.clientId; // End the internal batch and allow held messages from the application
        // to go to the server (see _handshake() where we start the internal batch).

        _internalBatch = false;

        _flushBatch(); // Here the new transport is in place, as well as the clientId, so
        // the listeners can perform a publish() if they want.
        // Notify the listeners before the connect below.


        message.reestablish = _reestablish;
        _reestablish = true;

        _handleCallback(message);

        _notifyListeners('/meta/handshake', message);

        _handshakeMessages = message['x-messages'] || 0;
        var action = _isDisconnected() ? 'none' : _advice.reconnect || 'retry';

        switch (action) {
          case 'retry':
            _resetBackoff();

            if (_handshakeMessages === 0) {
              _delayedConnect(0);
            } else {
              _cometd._debug('Processing', _handshakeMessages, 'handshake-delivered messages');
            }

            break;

          case 'none':
            _disconnect(true);

            break;

          default:
            throw 'Unrecognized advice action ' + action;
        }
      } else {
        _failHandshake(message, {
          cause: 'unsuccessful',
          action: _advice.reconnect || 'handshake',
          transport: _transport
        });
      }
    }

    function _handshakeFailure(message) {
      _failHandshake(message, {
        cause: 'failure',
        action: 'handshake',
        transport: null
      });
    }

    function _matchMetaConnect(connect) {
      if (_status === 'disconnected') {
        return true;
      }

      if (_metaConnect && _metaConnect.id === connect.id) {
        _metaConnect = null;
        return true;
      }

      return false;
    }

    function _failConnect(message, failureInfo) {
      // Notify the listeners after the status change but before the next action.
      _notifyListeners('/meta/connect', message);

      _notifyListeners('/meta/unsuccessful', message); // The listeners may have disconnected.


      if (_isDisconnected()) {
        failureInfo.action = 'none';
      }

      _cometd.onTransportFailure.call(_cometd, message, failureInfo, _handleTransportFailure);
    }

    function _connectResponse(message) {
      if (_matchMetaConnect(message)) {
        _connected = message.successful;

        if (_connected) {
          _notifyListeners('/meta/connect', message); // Normally, the advice will say "reconnect: 'retry', interval: 0"
          // and the server will hold the request, so when a response returns
          // we immediately call the server again (long polling).
          // Listeners can call disconnect(), so check the state after they run.


          var action = _isDisconnected() ? 'none' : _advice.reconnect || 'retry';

          switch (action) {
            case 'retry':
              _resetBackoff();

              _delayedConnect(_backoff);

              break;

            case 'none':
              _disconnect(false);

              break;

            default:
              throw 'Unrecognized advice action ' + action;
          }
        } else {
          _failConnect(message, {
            cause: 'unsuccessful',
            action: _advice.reconnect || 'retry',
            transport: _transport
          });
        }
      } else {
        _cometd._debug('Mismatched /meta/connect reply', message);
      }
    }

    function _connectFailure(message) {
      if (_matchMetaConnect(message)) {
        _connected = false;

        _failConnect(message, {
          cause: 'failure',
          action: 'retry',
          transport: null
        });
      } else {
        _cometd._debug('Mismatched /meta/connect failure', message);
      }
    }

    function _failDisconnect(message) {
      _disconnect(true);

      _handleCallback(message);

      _notifyListeners('/meta/disconnect', message);

      _notifyListeners('/meta/unsuccessful', message);
    }

    function _disconnectResponse(message) {
      if (message.successful) {
        // Wait for the /meta/connect to arrive.
        _disconnect(false);

        _handleCallback(message);

        _notifyListeners('/meta/disconnect', message);
      } else {
        _failDisconnect(message);
      }
    }

    function _disconnectFailure(message) {
      _failDisconnect(message);
    }

    function _failSubscribe(message) {
      var subscriptions = _listeners[message.subscription];

      if (subscriptions) {
        for (var id in subscriptions) {
          if (subscriptions.hasOwnProperty(id)) {
            var subscription = subscriptions[id];

            if (subscription && !subscription.listener) {
              delete subscriptions[id];

              _cometd._debug('Removed failed subscription', subscription);
            }
          }
        }
      }

      _handleCallback(message);

      _notifyListeners('/meta/subscribe', message);

      _notifyListeners('/meta/unsuccessful', message);
    }

    function _subscribeResponse(message) {
      if (message.successful) {
        _handleCallback(message);

        _notifyListeners('/meta/subscribe', message);
      } else {
        _failSubscribe(message);
      }
    }

    function _subscribeFailure(message) {
      _failSubscribe(message);
    }

    function _failUnsubscribe(message) {
      _handleCallback(message);

      _notifyListeners('/meta/unsubscribe', message);

      _notifyListeners('/meta/unsuccessful', message);
    }

    function _unsubscribeResponse(message) {
      if (message.successful) {
        _handleCallback(message);

        _notifyListeners('/meta/unsubscribe', message);
      } else {
        _failUnsubscribe(message);
      }
    }

    function _unsubscribeFailure(message) {
      _failUnsubscribe(message);
    }

    function _failMessage(message) {
      if (!_handleRemoteCall(message)) {
        _handleCallback(message);

        _notifyListeners('/meta/publish', message);

        _notifyListeners('/meta/unsuccessful', message);
      }
    }

    function _messageResponse(message) {
      if (message.data !== undefined) {
        if (!_handleRemoteCall(message)) {
          _notifyListeners(message.channel, message);

          if (_handshakeMessages > 0) {
            --_handshakeMessages;

            if (_handshakeMessages === 0) {
              _cometd._debug('Processed last handshake-delivered message');

              _delayedConnect(0);
            }
          }
        }
      } else {
        if (message.successful === undefined) {
          _cometd._warn('Unknown Bayeux Message', message);
        } else {
          if (message.successful) {
            _handleCallback(message);

            _notifyListeners('/meta/publish', message);
          } else {
            _failMessage(message);
          }
        }
      }
    }

    function _messageFailure(failure) {
      _failMessage(failure);
    }

    function _receive(message) {
      _unconnectTime = 0;
      message = _applyIncomingExtensions(message);

      if (message === undefined || message === null) {
        return;
      }

      _updateAdvice(message.advice);

      var channel = message.channel;

      switch (channel) {
        case '/meta/handshake':
          _handshakeResponse(message);

          break;

        case '/meta/connect':
          _connectResponse(message);

          break;

        case '/meta/disconnect':
          _disconnectResponse(message);

          break;

        case '/meta/subscribe':
          _subscribeResponse(message);

          break;

        case '/meta/unsubscribe':
          _unsubscribeResponse(message);

          break;

        default:
          _messageResponse(message);

          break;
      }
    }
    /**
     * Receives a message.
     * This method is exposed as a public so that extensions may inject
     * messages simulating that they had been received.
     */


    this.receive = _receive;

    _handleMessages = function (rcvdMessages) {
      _cometd._debug('Received', rcvdMessages);

      for (var i = 0; i < rcvdMessages.length; ++i) {
        var message = rcvdMessages[i];

        _receive(message);
      }
    };

    _handleFailure = function (conduit, messages, failure) {
      _cometd._debug('handleFailure', conduit, messages, failure);

      failure.transport = conduit;

      for (var i = 0; i < messages.length; ++i) {
        var message = messages[i];
        var failureMessage = {
          id: message.id,
          successful: false,
          channel: message.channel,
          failure: failure
        };
        failure.message = message;

        switch (message.channel) {
          case '/meta/handshake':
            _handshakeFailure(failureMessage);

            break;

          case '/meta/connect':
            _connectFailure(failureMessage);

            break;

          case '/meta/disconnect':
            _disconnectFailure(failureMessage);

            break;

          case '/meta/subscribe':
            failureMessage.subscription = message.subscription;

            _subscribeFailure(failureMessage);

            break;

          case '/meta/unsubscribe':
            failureMessage.subscription = message.subscription;

            _unsubscribeFailure(failureMessage);

            break;

          default:
            _messageFailure(failureMessage);

            break;
        }
      }
    };

    function _hasSubscriptions(channel) {
      var subscriptions = _listeners[channel];

      if (subscriptions) {
        for (var id in subscriptions) {
          if (subscriptions.hasOwnProperty(id)) {
            if (subscriptions[id]) {
              return true;
            }
          }
        }
      }

      return false;
    }

    function _resolveScopedCallback(scope, callback) {
      var delegate = {
        scope: scope,
        method: callback
      };

      if (_isFunction(scope)) {
        delegate.scope = undefined;
        delegate.method = scope;
      } else {
        if (_isString(callback)) {
          if (!scope) {
            throw 'Invalid scope ' + scope;
          }

          delegate.method = scope[callback];

          if (!_isFunction(delegate.method)) {
            throw 'Invalid callback ' + callback + ' for scope ' + scope;
          }
        } else if (!_isFunction(callback)) {
          throw 'Invalid callback ' + callback;
        }
      }

      return delegate;
    }

    function _addListener(channel, scope, callback, isListener) {
      // The data structure is a map<channel, subscription[]>, where each subscription
      // holds the callback to be called and its scope.
      var delegate = _resolveScopedCallback(scope, callback);

      _cometd._debug('Adding', isListener ? 'listener' : 'subscription', 'on', channel, 'with scope', delegate.scope, 'and callback', delegate.method);

      var id = ++_listenerId;
      var subscription = {
        id: id,
        channel: channel,
        scope: delegate.scope,
        callback: delegate.method,
        listener: isListener
      };
      var subscriptions = _listeners[channel];

      if (!subscriptions) {
        subscriptions = {};
        _listeners[channel] = subscriptions;
      }

      subscriptions[id] = subscription;

      _cometd._debug('Added', isListener ? 'listener' : 'subscription', subscription);

      return subscription;
    } //
    // PUBLIC API
    //

    /**
     * Registers the given transport under the given transport type.
     * The optional index parameter specifies the "priority" at which the
     * transport is registered (where 0 is the max priority).
     * If a transport with the same type is already registered, this function
     * does nothing and returns false.
     * @param type the transport type
     * @param transport the transport object
     * @param index the index at which this transport is to be registered
     * @return true if the transport has been registered, false otherwise
     * @see #unregisterTransport(type)
     */


    this.registerTransport = function (type, transport, index) {
      var result = _transports.add(type, transport, index);

      if (result) {
        this._debug('Registered transport', type);

        if (_isFunction(transport.registered)) {
          transport.registered(type, this);
        }
      }

      return result;
    };
    /**
     * Unregisters the transport with the given transport type.
     * @param type the transport type to unregister
     * @return the transport that has been unregistered,
     * or null if no transport was previously registered under the given transport type
     */


    this.unregisterTransport = function (type) {
      var transport = _transports.remove(type);

      if (transport !== null) {
        this._debug('Unregistered transport', type);

        if (_isFunction(transport.unregistered)) {
          transport.unregistered();
        }
      }

      return transport;
    };

    this.unregisterTransports = function () {
      _transports.clear();
    };
    /**
     * @return an array of all registered transport types
     */


    this.getTransportTypes = function () {
      return _transports.getTransportTypes();
    };

    this.findTransport = function (name) {
      return _transports.find(name);
    };
    /**
     * @returns the TransportRegistry object
     */


    this.getTransportRegistry = function () {
      return _transports;
    };
    /**
     * Configures the initial Bayeux communication with the Bayeux server.
     * Configuration is passed via an object that must contain a mandatory field <code>url</code>
     * of type string containing the URL of the Bayeux server.
     * @param configuration the configuration object
     */


    this.configure = function (configuration) {
      _configure.call(this, configuration);
    };
    /**
     * Configures and establishes the Bayeux communication with the Bayeux server
     * via a handshake and a subsequent connect.
     * @param configuration the configuration object
     * @param handshakeProps an object to be merged with the handshake message
     * @see #configure(configuration)
     * @see #handshake(handshakeProps)
     */


    this.init = function (configuration, handshakeProps) {
      this.configure(configuration);
      this.handshake(handshakeProps);
    };
    /**
     * Establishes the Bayeux communication with the Bayeux server
     * via a handshake and a subsequent connect.
     * @param handshakeProps an object to be merged with the handshake message
     * @param handshakeCallback a function to be invoked when the handshake is acknowledged
     */


    this.handshake = function (handshakeProps, handshakeCallback) {
      if (_status !== 'disconnected') {
        throw 'Illegal state: handshaken';
      }

      _handshake(handshakeProps, handshakeCallback);
    };
    /**
     * Disconnects from the Bayeux server.
     * It is possible to suggest to attempt a synchronous disconnect, but this feature
     * may only be available in certain transports (for example, long-polling may support
     * it, callback-polling certainly does not).
     * @param sync whether attempt to perform a synchronous disconnect
     * @param disconnectProps an object to be merged with the disconnect message
     * @param disconnectCallback a function to be invoked when the disconnect is acknowledged
     */


    this.disconnect = function (sync, disconnectProps, disconnectCallback) {
      if (_isDisconnected()) {
        return;
      }

      if (typeof sync !== 'boolean') {
        disconnectCallback = disconnectProps;
        disconnectProps = sync;
        sync = false;
      }

      if (_isFunction(disconnectProps)) {
        disconnectCallback = disconnectProps;
        disconnectProps = undefined;
      }

      var bayeuxMessage = {
        id: _nextMessageId(),
        channel: '/meta/disconnect'
      }; // Do not allow the user to override important fields.

      var message = this._mixin(false, {}, disconnectProps, bayeuxMessage); // Save the callback.


      _cometd._putCallback(message.id, disconnectCallback);

      _setStatus('disconnecting');

      _send(sync === true, [message], false, 'disconnect');
    };
    /**
     * Marks the start of a batch of application messages to be sent to the server
     * in a single request, obtaining a single response containing (possibly) many
     * application reply messages.
     * Messages are held in a queue and not sent until {@link #endBatch()} is called.
     * If startBatch() is called multiple times, then an equal number of endBatch()
     * calls must be made to close and send the batch of messages.
     * @see #endBatch()
     */


    this.startBatch = function () {
      _startBatch();
    };
    /**
     * Marks the end of a batch of application messages to be sent to the server
     * in a single request.
     * @see #startBatch()
     */


    this.endBatch = function () {
      _endBatch();
    };
    /**
     * Executes the given callback in the given scope, surrounded by a {@link #startBatch()}
     * and {@link #endBatch()} calls.
     * @param scope the scope of the callback, may be omitted
     * @param callback the callback to be executed within {@link #startBatch()} and {@link #endBatch()} calls
     */


    this.batch = function (scope, callback) {
      var delegate = _resolveScopedCallback(scope, callback);

      this.startBatch();

      try {
        delegate.method.call(delegate.scope);
        this.endBatch();
      } catch (x) {
        this._info('Exception during execution of batch', x);

        this.endBatch();
        throw x;
      }
    };
    /**
     * Adds a listener for bayeux messages, performing the given callback in the given scope
     * when a message for the given channel arrives.
     * @param channel the channel the listener is interested to
     * @param scope the scope of the callback, may be omitted
     * @param callback the callback to call when a message is sent to the channel
     * @returns the subscription handle to be passed to {@link #removeListener(object)}
     * @see #removeListener(subscription)
     */


    this.addListener = function (channel, scope, callback) {
      if (arguments.length < 2) {
        throw 'Illegal arguments number: required 2, got ' + arguments.length;
      }

      if (!_isString(channel)) {
        throw 'Illegal argument type: channel must be a string';
      }

      return _addListener(channel, scope, callback, true);
    };
    /**
     * Removes the subscription obtained with a call to {@link #addListener(string, object, function)}.
     * @param subscription the subscription to unsubscribe.
     * @see #addListener(channel, scope, callback)
     */


    this.removeListener = function (subscription) {
      // Beware of subscription.id == 0, which is falsy => cannot use !subscription.id
      if (!subscription || !subscription.channel || !("id" in subscription)) {
        throw 'Invalid argument: expected subscription, not ' + subscription;
      }

      _removeListener(subscription);
    };
    /**
     * Removes all listeners registered with {@link #addListener(channel, scope, callback)} or
     * {@link #subscribe(channel, scope, callback)}.
     */


    this.clearListeners = function () {
      _listeners = {};
    };
    /**
     * Subscribes to the given channel, performing the given callback in the given scope
     * when a message for the channel arrives.
     * @param channel the channel to subscribe to
     * @param scope the scope of the callback, may be omitted
     * @param callback the callback to call when a message is sent to the channel
     * @param subscribeProps an object to be merged with the subscribe message
     * @param subscribeCallback a function to be invoked when the subscription is acknowledged
     * @return the subscription handle to be passed to {@link #unsubscribe(object)}
     */


    this.subscribe = function (channel, scope, callback, subscribeProps, subscribeCallback) {
      if (arguments.length < 2) {
        throw 'Illegal arguments number: required 2, got ' + arguments.length;
      }

      if (!_isString(channel)) {
        throw 'Illegal argument type: channel must be a string';
      }

      if (_isDisconnected()) {
        throw 'Illegal state: disconnected';
      } // Normalize arguments


      if (_isFunction(scope)) {
        subscribeCallback = subscribeProps;
        subscribeProps = callback;
        callback = scope;
        scope = undefined;
      }

      if (_isFunction(subscribeProps)) {
        subscribeCallback = subscribeProps;
        subscribeProps = undefined;
      } // Only send the message to the server if this client has not yet subscribed to the channel


      var send = !_hasSubscriptions(channel);

      var subscription = _addListener(channel, scope, callback, false);

      if (send) {
        // Send the subscription message after the subscription registration to avoid
        // races where the server would send a message to the subscribers, but here
        // on the client the subscription has not been added yet to the data structures
        var bayeuxMessage = {
          id: _nextMessageId(),
          channel: '/meta/subscribe',
          subscription: channel
        }; // Do not allow the user to override important fields.

        var message = this._mixin(false, {}, subscribeProps, bayeuxMessage); // Save the callback.


        _cometd._putCallback(message.id, subscribeCallback);

        _queueSend(message);
      }

      return subscription;
    };
    /**
     * Unsubscribes the subscription obtained with a call to {@link #subscribe(string, object, function)}.
     * @param subscription the subscription to unsubscribe.
     * @param unsubscribeProps an object to be merged with the unsubscribe message
     * @param unsubscribeCallback a function to be invoked when the unsubscription is acknowledged
     */


    this.unsubscribe = function (subscription, unsubscribeProps, unsubscribeCallback) {
      if (arguments.length < 1) {
        throw 'Illegal arguments number: required 1, got ' + arguments.length;
      }

      if (_isDisconnected()) {
        throw 'Illegal state: disconnected';
      }

      if (_isFunction(unsubscribeProps)) {
        unsubscribeCallback = unsubscribeProps;
        unsubscribeProps = undefined;
      } // Remove the local listener before sending the message
      // This ensures that if the server fails, this client does not get notifications


      this.removeListener(subscription);
      var channel = subscription.channel; // Only send the message to the server if this client unsubscribes the last subscription

      if (!_hasSubscriptions(channel)) {
        var bayeuxMessage = {
          id: _nextMessageId(),
          channel: '/meta/unsubscribe',
          subscription: channel
        }; // Do not allow the user to override important fields.

        var message = this._mixin(false, {}, unsubscribeProps, bayeuxMessage); // Save the callback.


        _cometd._putCallback(message.id, unsubscribeCallback);

        _queueSend(message);
      }
    };

    this.resubscribe = function (subscription, subscribeProps) {
      _removeSubscription(subscription);

      if (subscription) {
        return this.subscribe(subscription.channel, subscription.scope, subscription.callback, subscribeProps);
      }

      return undefined;
    };
    /**
     * Removes all subscriptions added via {@link #subscribe(channel, scope, callback, subscribeProps)},
     * but does not remove the listeners added via {@link addListener(channel, scope, callback)}.
     */


    this.clearSubscriptions = function () {
      _clearSubscriptions();
    };
    /**
     * Publishes a message on the given channel, containing the given content.
     * @param channel the channel to publish the message to
     * @param content the content of the message
     * @param publishProps an object to be merged with the publish message
     * @param publishCallback a function to be invoked when the publish is acknowledged by the server
     */


    this.publish = function (channel, content, publishProps, publishCallback) {
      if (arguments.length < 1) {
        throw 'Illegal arguments number: required 1, got ' + arguments.length;
      }

      if (!_isString(channel)) {
        throw 'Illegal argument type: channel must be a string';
      }

      if (/^\/meta\//.test(channel)) {
        throw 'Illegal argument: cannot publish to meta channels';
      }

      if (_isDisconnected()) {
        throw 'Illegal state: disconnected';
      }

      if (_isFunction(content)) {
        publishCallback = content;
        content = {};
        publishProps = undefined;
      } else if (_isFunction(publishProps)) {
        publishCallback = publishProps;
        publishProps = undefined;
      }

      var bayeuxMessage = {
        id: _nextMessageId(),
        channel: channel,
        data: content
      }; // Do not allow the user to override important fields.

      var message = this._mixin(false, {}, publishProps, bayeuxMessage); // Save the callback.


      _cometd._putCallback(message.id, publishCallback);

      _queueSend(message);
    };
    /**
     * Publishes a message with binary data on the given channel.
     * The binary data chunk may be an ArrayBuffer, a DataView, a TypedArray
     * (such as Uint8Array) or a plain integer array.
     * The meta data object may contain additional application data such as
     * a file name, a mime type, etc.
     * @param channel the channel to publish the message to
     * @param data the binary data to publish
     * @param last whether the binary data chunk is the last
     * @param meta an object containing meta data associated to the binary chunk
     * @param callback a function to be invoked when the publish is acknowledged by the server
     */


    this.publishBinary = function (channel, data, last, meta, callback) {
      if (_isFunction(data)) {
        callback = data;
        data = new ArrayBuffer(0);
        last = true;
        meta = undefined;
      } else if (_isFunction(last)) {
        callback = last;
        last = true;
        meta = undefined;
      } else if (_isFunction(meta)) {
        callback = meta;
        meta = undefined;
      }

      var content = {
        meta: meta,
        data: data,
        last: last
      };
      var ext = {
        ext: {
          binary: {}
        }
      };
      this.publish(channel, content, ext, callback);
    };

    this.remoteCall = function (target, content, timeout, callProps, callback) {
      if (arguments.length < 1) {
        throw 'Illegal arguments number: required 1, got ' + arguments.length;
      }

      if (!_isString(target)) {
        throw 'Illegal argument type: target must be a string';
      }

      if (_isDisconnected()) {
        throw 'Illegal state: disconnected';
      }

      if (_isFunction(content)) {
        callback = content;
        content = {};
        timeout = _config.maxNetworkDelay;
        callProps = undefined;
      } else if (_isFunction(timeout)) {
        callback = timeout;
        timeout = _config.maxNetworkDelay;
        callProps = undefined;
      } else if (_isFunction(callProps)) {
        callback = callProps;
        callProps = undefined;
      }

      if (typeof timeout !== 'number') {
        throw 'Illegal argument type: timeout must be a number';
      }

      if (!target.match(/^\//)) {
        target = '/' + target;
      }

      var channel = '/service' + target;
      var bayeuxMessage = {
        id: _nextMessageId(),
        channel: channel,
        data: content
      };

      var message = this._mixin(false, {}, callProps, bayeuxMessage);

      var context = {
        callback: callback
      };

      if (timeout > 0) {
        context.timeout = _cometd.setTimeout(function () {
          _cometd._debug('Timing out remote call', message, 'after', timeout, 'ms');

          _failMessage({
            id: message.id,
            error: '406::timeout',
            successful: false,
            failure: {
              message: message,
              reason: 'Remote Call Timeout'
            }
          });
        }, timeout);

        _cometd._debug('Scheduled remote call timeout', message, 'in', timeout, 'ms');
      }

      _remoteCalls[message.id] = context;

      _queueSend(message);
    };

    this.remoteCallBinary = function (target, data, last, meta, timeout, callback) {
      if (_isFunction(data)) {
        callback = data;
        data = new ArrayBuffer(0);
        last = true;
        meta = undefined;
        timeout = _config.maxNetworkDelay;
      } else if (_isFunction(last)) {
        callback = last;
        last = true;
        meta = undefined;
        timeout = _config.maxNetworkDelay;
      } else if (_isFunction(meta)) {
        callback = meta;
        meta = undefined;
        timeout = _config.maxNetworkDelay;
      } else if (_isFunction(timeout)) {
        callback = timeout;
        timeout = _config.maxNetworkDelay;
      }

      var content = {
        meta: meta,
        data: data,
        last: last
      };
      var ext = {
        ext: {
          binary: {}
        }
      };
      this.remoteCall(target, content, timeout, ext, callback);
    };
    /**
     * Returns a string representing the status of the bayeux communication with the Bayeux server.
     */


    this.getStatus = function () {
      return _status;
    };
    /**
     * Returns whether this instance has been disconnected.
     */


    this.isDisconnected = _isDisconnected;
    /**
     * Sets the backoff period used to increase the backoff time when retrying an unsuccessful or failed message.
     * Default value is 1 second, which means if there is a persistent failure the retries will happen
     * after 1 second, then after 2 seconds, then after 3 seconds, etc. So for example with 15 seconds of
     * elapsed time, there will be 5 retries (at 1, 3, 6, 10 and 15 seconds elapsed).
     * @param period the backoff period to set
     * @see #getBackoffIncrement()
     */

    this.setBackoffIncrement = function (period) {
      _config.backoffIncrement = period;
    };
    /**
     * Returns the backoff period used to increase the backoff time when retrying an unsuccessful or failed message.
     * @see #setBackoffIncrement(period)
     */


    this.getBackoffIncrement = function () {
      return _config.backoffIncrement;
    };
    /**
     * Returns the backoff period to wait before retrying an unsuccessful or failed message.
     */


    this.getBackoffPeriod = function () {
      return _backoff;
    };
    /**
     * Increases the backoff period up to the maximum value configured.
     * @returns the backoff period after increment
     * @see getBackoffIncrement
     */


    this.increaseBackoffPeriod = function () {
      return _increaseBackoff();
    };
    /**
     * Resets the backoff period to zero.
     */


    this.resetBackoffPeriod = function () {
      _resetBackoff();
    };
    /**
     * Sets the log level for console logging.
     * Valid values are the strings 'error', 'warn', 'info' and 'debug', from
     * less verbose to more verbose.
     * @param level the log level string
     */


    this.setLogLevel = function (level) {
      _config.logLevel = level;
    };
    /**
     * Registers an extension whose callbacks are called for every incoming message
     * (that comes from the server to this client implementation) and for every
     * outgoing message (that originates from this client implementation for the
     * server).
     * The format of the extension object is the following:
     * <pre>
     * {
     *     incoming: function(message) { ... },
     *     outgoing: function(message) { ... }
     * }
     * </pre>
     * Both properties are optional, but if they are present they will be called
     * respectively for each incoming message and for each outgoing message.
     * @param name the name of the extension
     * @param extension the extension to register
     * @return true if the extension was registered, false otherwise
     * @see #unregisterExtension(name)
     */


    this.registerExtension = function (name, extension) {
      if (arguments.length < 2) {
        throw 'Illegal arguments number: required 2, got ' + arguments.length;
      }

      if (!_isString(name)) {
        throw 'Illegal argument type: extension name must be a string';
      }

      var existing = false;

      for (var i = 0; i < _extensions.length; ++i) {
        var existingExtension = _extensions[i];

        if (existingExtension.name === name) {
          existing = true;
          break;
        }
      }

      if (!existing) {
        _extensions.push({
          name: name,
          extension: extension
        });

        this._debug('Registered extension', name); // Callback for extensions


        if (_isFunction(extension.registered)) {
          extension.registered(name, this);
        }

        return true;
      } else {
        this._info('Could not register extension with name', name, 'since another extension with the same name already exists');

        return false;
      }
    };
    /**
     * Unregister an extension previously registered with
     * {@link #registerExtension(name, extension)}.
     * @param name the name of the extension to unregister.
     * @return true if the extension was unregistered, false otherwise
     */


    this.unregisterExtension = function (name) {
      if (!_isString(name)) {
        throw 'Illegal argument type: extension name must be a string';
      }

      var unregistered = false;

      for (var i = 0; i < _extensions.length; ++i) {
        var extension = _extensions[i];

        if (extension.name === name) {
          _extensions.splice(i, 1);

          unregistered = true;

          this._debug('Unregistered extension', name); // Callback for extensions


          var ext = extension.extension;

          if (_isFunction(ext.unregistered)) {
            ext.unregistered();
          }

          break;
        }
      }

      return unregistered;
    };
    /**
     * Find the extension registered with the given name.
     * @param name the name of the extension to find
     * @return the extension found or null if no extension with the given name has been registered
     */


    this.getExtension = function (name) {
      for (var i = 0; i < _extensions.length; ++i) {
        var extension = _extensions[i];

        if (extension.name === name) {
          return extension.extension;
        }
      }

      return null;
    };
    /**
     * Returns the name assigned to this CometD object, or the string 'default'
     * if no name has been explicitly passed as parameter to the constructor.
     */


    this.getName = function () {
      return _name;
    };
    /**
     * Returns the clientId assigned by the Bayeux server during handshake.
     */


    this.getClientId = function () {
      return _clientId;
    };
    /**
     * Returns the URL of the Bayeux server.
     */


    this.getURL = function () {
      if (_transport) {
        var url = _transport.getURL();

        if (url) {
          return url;
        }

        url = _config.urls[_transport.getType()];

        if (url) {
          return url;
        }
      }

      return _config.url;
    };

    this.getTransport = function () {
      return _transport;
    };

    this.getConfiguration = function () {
      return this._mixin(true, {}, _config);
    };

    this.getAdvice = function () {
      return this._mixin(true, {}, _advice);
    };

    this.setTimeout = function (funktion, delay) {
      return _scheduler.setTimeout(function () {
        try {
          _cometd._debug('Invoking timed function', funktion);

          funktion();
        } catch (x) {
          _cometd._debug('Exception invoking timed function', funktion, x);
        }
      }, delay);
    };

    this.clearTimeout = function (id) {
      _scheduler.clearTimeout(id);
    }; // Initialize transports.


    if (window.WebSocket) {
      this.registerTransport('websocket', new WebSocketTransport());
    }

    this.registerTransport('long-polling', new LongPollingTransport());
    this.registerTransport('callback-polling', new CallbackPollingTransport());
  };

  var _z85EncodeTable = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '.', '-', ':', '+', '=', '^', '!', '/', '*', '?', '&', '<', '>', '(', ')', '[', ']', '{', '}', '@', '%', '$', '#'];
  var _z85DecodeTable = [0x00, 0x44, 0x00, 0x54, 0x53, 0x52, 0x48, 0x00, 0x4B, 0x4C, 0x46, 0x41, 0x00, 0x3F, 0x3E, 0x45, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x40, 0x00, 0x49, 0x42, 0x4A, 0x47, 0x51, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F, 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x4D, 0x00, 0x4E, 0x43, 0x00, 0x00, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x20, 0x21, 0x22, 0x23, 0x4F, 0x00, 0x50, 0x00, 0x00];
  var Z85 = {
    encode: function (bytes) {
      var buffer = null;

      if (bytes instanceof ArrayBuffer) {
        buffer = bytes;
      } else if (bytes.buffer instanceof ArrayBuffer) {
        buffer = bytes.buffer;
      } else if (Array.isArray(bytes)) {
        buffer = new Uint8Array(bytes).buffer;
      }

      if (buffer == null) {
        throw 'Cannot Z85 encode ' + bytes;
      }

      var length = buffer.byteLength;
      var remainder = length % 4;
      var padding = 4 - (remainder === 0 ? 4 : remainder);
      var view = new DataView(buffer);
      var result = '';
      var value = 0;

      for (var i = 0; i < length + padding; ++i) {
        var isPadding = i >= length;
        value = value * 256 + (isPadding ? 0 : view.getUint8(i));

        if ((i + 1) % 4 === 0) {
          var divisor = 85 * 85 * 85 * 85;

          for (var j = 5; j > 0; --j) {
            if (!isPadding || j > padding) {
              var code = Math.floor(value / divisor) % 85;
              result += _z85EncodeTable[code];
            }

            divisor /= 85;
          }

          value = 0;
        }
      }

      return result;
    },
    decode: function (string) {
      var remainder = string.length % 5;
      var padding = 5 - (remainder === 0 ? 5 : remainder);

      for (var p = 0; p < padding; ++p) {
        string += _z85EncodeTable[_z85EncodeTable.length - 1];
      }

      var length = string.length;
      var buffer = new ArrayBuffer(length * 4 / 5 - padding);
      var view = new DataView(buffer);
      var value = 0;
      var charIdx = 0;
      var byteIdx = 0;

      for (var i = 0; i < length; ++i) {
        var code = string.charCodeAt(charIdx++) - 32;
        value = value * 85 + _z85DecodeTable[code];

        if (charIdx % 5 === 0) {
          var divisor = 256 * 256 * 256;

          while (divisor >= 1) {
            if (byteIdx < view.byteLength) {
              view.setUint8(byteIdx++, Math.floor(value / divisor) % 256);
            }

            divisor /= 256;
          }

          value = 0;
        }
      }

      return buffer;
    }
  };
  return {
    CometD: CometD,
    Transport: Transport,
    RequestTransport: RequestTransport,
    LongPollingTransport: LongPollingTransport,
    CallbackPollingTransport: CallbackPollingTransport,
    WebSocketTransport: WebSocketTransport,
    Utils: Utils,
    Z85: Z85
  };
});

/***/ }),

/***/ 50863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-accordion_2.entry.js": [
		70079,
		"common",
		"node_modules_ionic_core_dist_esm_ion-accordion_2_entry_js"
	],
	"./ion-action-sheet.entry.js": [
		25593,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		13225,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		4812,
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		86655,
		"common",
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		44856,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		13059,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-breadcrumb_2.entry.js": [
		58648,
		"common",
		"node_modules_ionic_core_dist_esm_ion-breadcrumb_2_entry_js"
	],
	"./ion-button_2.entry.js": [
		98308,
		"common",
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		44690,
		"common",
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		64090,
		"common",
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		36214,
		"common",
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		69447,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		79689,
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		18840,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		40749,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		69667,
		"common",
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		83288,
		"common",
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		35473,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		53634,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		22855,
		"common",
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		495,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		58737,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		99632,
		"common",
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-picker-column-internal.entry.js": [
		54446,
		"common",
		"node_modules_ionic_core_dist_esm_ion-picker-column-internal_entry_js"
	],
	"./ion-picker-internal.entry.js": [
		32275,
		"node_modules_ionic_core_dist_esm_ion-picker-internal_entry_js"
	],
	"./ion-popover.entry.js": [
		48050,
		"common",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		18994,
		"common",
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		23592,
		"common",
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		35454,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		290,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		92666,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		64816,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		45534,
		"common",
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		94902,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		91938,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		78179,
		"common",
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		90668,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		61624,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		19989,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		28902,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		70199,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		48395,
		"common",
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		96357,
		"common",
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		38268,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		15269,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		32875,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 50863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 46700:
/*!***************************************************!*\
  !*** ./node_modules/moment/locale/ sync ^\.\/.*$ ***!
  \***************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./af": 58685,
	"./af.js": 58685,
	"./ar": 254,
	"./ar-dz": 4312,
	"./ar-dz.js": 4312,
	"./ar-kw": 32614,
	"./ar-kw.js": 32614,
	"./ar-ly": 18630,
	"./ar-ly.js": 18630,
	"./ar-ma": 28674,
	"./ar-ma.js": 28674,
	"./ar-sa": 49032,
	"./ar-sa.js": 49032,
	"./ar-tn": 24730,
	"./ar-tn.js": 24730,
	"./ar.js": 254,
	"./az": 53052,
	"./az.js": 53052,
	"./be": 60150,
	"./be.js": 60150,
	"./bg": 63069,
	"./bg.js": 63069,
	"./bm": 13466,
	"./bm.js": 13466,
	"./bn": 18516,
	"./bn-bd": 90557,
	"./bn-bd.js": 90557,
	"./bn.js": 18516,
	"./bo": 26273,
	"./bo.js": 26273,
	"./br": 9588,
	"./br.js": 9588,
	"./bs": 19815,
	"./bs.js": 19815,
	"./ca": 83331,
	"./ca.js": 83331,
	"./cs": 21320,
	"./cs.js": 21320,
	"./cv": 72219,
	"./cv.js": 72219,
	"./cy": 68266,
	"./cy.js": 68266,
	"./da": 66427,
	"./da.js": 66427,
	"./de": 67435,
	"./de-at": 52871,
	"./de-at.js": 52871,
	"./de-ch": 12994,
	"./de-ch.js": 12994,
	"./de.js": 67435,
	"./dv": 82357,
	"./dv.js": 82357,
	"./el": 95649,
	"./el.js": 95649,
	"./en-au": 59961,
	"./en-au.js": 59961,
	"./en-ca": 19878,
	"./en-ca.js": 19878,
	"./en-gb": 3924,
	"./en-gb.js": 3924,
	"./en-ie": 70864,
	"./en-ie.js": 70864,
	"./en-il": 91579,
	"./en-il.js": 91579,
	"./en-in": 30940,
	"./en-in.js": 30940,
	"./en-nz": 16181,
	"./en-nz.js": 16181,
	"./en-sg": 44301,
	"./en-sg.js": 44301,
	"./eo": 85291,
	"./eo.js": 85291,
	"./es": 54529,
	"./es-do": 53764,
	"./es-do.js": 53764,
	"./es-mx": 12584,
	"./es-mx.js": 12584,
	"./es-us": 63425,
	"./es-us.js": 63425,
	"./es.js": 54529,
	"./et": 35203,
	"./et.js": 35203,
	"./eu": 70678,
	"./eu.js": 70678,
	"./fa": 83483,
	"./fa.js": 83483,
	"./fi": 96262,
	"./fi.js": 96262,
	"./fil": 52521,
	"./fil.js": 52521,
	"./fo": 34555,
	"./fo.js": 34555,
	"./fr": 63131,
	"./fr-ca": 88239,
	"./fr-ca.js": 88239,
	"./fr-ch": 21702,
	"./fr-ch.js": 21702,
	"./fr.js": 63131,
	"./fy": 267,
	"./fy.js": 267,
	"./ga": 23821,
	"./ga.js": 23821,
	"./gd": 71753,
	"./gd.js": 71753,
	"./gl": 4074,
	"./gl.js": 4074,
	"./gom-deva": 92762,
	"./gom-deva.js": 92762,
	"./gom-latn": 5969,
	"./gom-latn.js": 5969,
	"./gu": 82809,
	"./gu.js": 82809,
	"./he": 45402,
	"./he.js": 45402,
	"./hi": 315,
	"./hi.js": 315,
	"./hr": 10410,
	"./hr.js": 10410,
	"./hu": 38288,
	"./hu.js": 38288,
	"./hy-am": 67928,
	"./hy-am.js": 67928,
	"./id": 71334,
	"./id.js": 71334,
	"./is": 86959,
	"./is.js": 86959,
	"./it": 34864,
	"./it-ch": 51124,
	"./it-ch.js": 51124,
	"./it.js": 34864,
	"./ja": 36141,
	"./ja.js": 36141,
	"./jv": 29187,
	"./jv.js": 29187,
	"./ka": 42136,
	"./ka.js": 42136,
	"./kk": 94332,
	"./kk.js": 94332,
	"./km": 18607,
	"./km.js": 18607,
	"./kn": 84305,
	"./kn.js": 84305,
	"./ko": 70234,
	"./ko.js": 70234,
	"./ku": 16003,
	"./ku.js": 16003,
	"./ky": 75061,
	"./ky.js": 75061,
	"./lb": 32786,
	"./lb.js": 32786,
	"./lo": 66183,
	"./lo.js": 66183,
	"./lt": 50029,
	"./lt.js": 50029,
	"./lv": 24169,
	"./lv.js": 24169,
	"./me": 68577,
	"./me.js": 68577,
	"./mi": 68177,
	"./mi.js": 68177,
	"./mk": 50337,
	"./mk.js": 50337,
	"./ml": 65260,
	"./ml.js": 65260,
	"./mn": 52325,
	"./mn.js": 52325,
	"./mr": 14695,
	"./mr.js": 14695,
	"./ms": 75334,
	"./ms-my": 37151,
	"./ms-my.js": 37151,
	"./ms.js": 75334,
	"./mt": 63570,
	"./mt.js": 63570,
	"./my": 97963,
	"./my.js": 97963,
	"./nb": 88028,
	"./nb.js": 88028,
	"./ne": 86638,
	"./ne.js": 86638,
	"./nl": 50302,
	"./nl-be": 66782,
	"./nl-be.js": 66782,
	"./nl.js": 50302,
	"./nn": 33501,
	"./nn.js": 33501,
	"./oc-lnc": 50563,
	"./oc-lnc.js": 50563,
	"./pa-in": 50869,
	"./pa-in.js": 50869,
	"./pl": 65302,
	"./pl.js": 65302,
	"./pt": 49687,
	"./pt-br": 74884,
	"./pt-br.js": 74884,
	"./pt.js": 49687,
	"./ro": 79107,
	"./ro.js": 79107,
	"./ru": 33627,
	"./ru.js": 33627,
	"./sd": 30355,
	"./sd.js": 30355,
	"./se": 83427,
	"./se.js": 83427,
	"./si": 11848,
	"./si.js": 11848,
	"./sk": 54590,
	"./sk.js": 54590,
	"./sl": 20184,
	"./sl.js": 20184,
	"./sq": 56361,
	"./sq.js": 56361,
	"./sr": 78965,
	"./sr-cyrl": 81287,
	"./sr-cyrl.js": 81287,
	"./sr.js": 78965,
	"./ss": 25456,
	"./ss.js": 25456,
	"./sv": 70451,
	"./sv.js": 70451,
	"./sw": 77558,
	"./sw.js": 77558,
	"./ta": 51356,
	"./ta.js": 51356,
	"./te": 73693,
	"./te.js": 73693,
	"./tet": 21243,
	"./tet.js": 21243,
	"./tg": 42500,
	"./tg.js": 42500,
	"./th": 55768,
	"./th.js": 55768,
	"./tk": 77761,
	"./tk.js": 77761,
	"./tl-ph": 35780,
	"./tl-ph.js": 35780,
	"./tlh": 29590,
	"./tlh.js": 29590,
	"./tr": 33807,
	"./tr.js": 33807,
	"./tzl": 93857,
	"./tzl.js": 93857,
	"./tzm": 60654,
	"./tzm-latn": 8806,
	"./tzm-latn.js": 8806,
	"./tzm.js": 60654,
	"./ug-cn": 30845,
	"./ug-cn.js": 30845,
	"./uk": 19232,
	"./uk.js": 19232,
	"./ur": 47052,
	"./ur.js": 47052,
	"./uz": 77967,
	"./uz-latn": 32233,
	"./uz-latn.js": 32233,
	"./uz.js": 77967,
	"./vi": 98615,
	"./vi.js": 98615,
	"./x-pseudo": 12320,
	"./x-pseudo.js": 12320,
	"./yo": 31313,
	"./yo.js": 31313,
	"./zh-cn": 64490,
	"./zh-cn.js": 64490,
	"./zh-hk": 55910,
	"./zh-hk.js": 55910,
	"./zh-mo": 98262,
	"./zh-mo.js": 98262,
	"./zh-tw": 44223,
	"./zh-tw.js": 44223
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = 46700;

/***/ }),

/***/ 79259:
/*!***********************************************!*\
  !*** ./src/app/app.component.scss?ngResource ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = "ion-app,\nion-split-pane {\n  display: flex;\n  flex-direction: column;\n  width: 100%;\n  height: 100%;\n  left: auto;\n  right: auto;\n  top: auto;\n  bottom: auto;\n  position: relative;\n  background: white;\n}\n\nion-router-outlet {\n  flex-grow: 1;\n  width: 100%;\n  position: relative;\n  background: #fff;\n  background: var(--ion-background-color, #fff);\n  transform: translateY(0px) scale(1) !important;\n  transform-origin: center top;\n  overflow: inherit;\n  border-radius: 0px !important;\n  z-index: 999;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7RUFFRSxhQUFBO0VBQ0Esc0JBQUE7RUFFQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0FBQUY7O0FBR0E7RUFDRSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFBQSw2Q0FBQTtFQUNBLDhDQUFBO0VBQ0EsNEJBQUE7RUFDQSxpQkFBQTtFQUNBLDZCQUFBO0VBQ0EsWUFBQTtBQUFGIiwiZmlsZSI6ImFwcC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1hcHAsXG5pb24tc3BsaXQtcGFuZSB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG5cbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgbGVmdDogYXV0bztcbiAgcmlnaHQ6IGF1dG87XG4gIHRvcDogYXV0bztcbiAgYm90dG9tOiBhdXRvO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xufVxuXG5pb24tcm91dGVyLW91dGxldCB7XG4gIGZsZXgtZ3JvdzogMTtcbiAgd2lkdGg6IDEwMCU7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgYmFja2dyb3VuZDogdmFyKC0taW9uLWJhY2tncm91bmQtY29sb3IsICNmZmYpO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMHB4KSBzY2FsZSgxKSAhaW1wb3J0YW50O1xuICB0cmFuc2Zvcm0tb3JpZ2luOiBjZW50ZXIgdG9wO1xuICBvdmVyZmxvdzogaW5oZXJpdDtcbiAgYm9yZGVyLXJhZGl1czogMHB4ICFpbXBvcnRhbnQ7XG4gIHotaW5kZXg6IDk5OTtcbn1cblxuIl19 */";

/***/ }),

/***/ 41938:
/*!****************************************************************************************!*\
  !*** ./src/app/common-ui-components/development/development.component.scss?ngResource ***!
  \****************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "development-component {\n  position: fixed;\n  top: 0;\n  direction: ltr;\n  display: block;\n  pointer-events: none;\n  color: white;\n  display: block;\n  position: absolute;\n  width: 100%;\n  height: 50;\n  padding-top: 0px;\n  padding-top: clac(constant(safe-area-inset-top));\n  padding-top: calc(env(safe-area-inset-top));\n  padding-bottom: 26px;\n  line-height: 12px;\n  font-size: 12px;\n  background: linear-gradient(to bottom, #2ebd85 0%, #00515700 100%);\n  text-align: center;\n}\ndevelopment-component a {\n  color: white;\n  text-decoration: underline;\n  display: none;\n  text-shadow: 1px 1px 1px rgba(180, 131, 175, 0.5);\n  pointer-events: all;\n}\ndevelopment-component.started #stop {\n  display: inline-block;\n  color: #ff008c;\n}\ndevelopment-component:not(.started) #start {\n  display: inline-block;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldmVsb3BtZW50LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZUFBQTtFQUNBLE1BQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLG9CQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnREFBQTtFQUNBLDJDQUFBO0VBQ0Esb0JBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFJQSxrRUFBQTtFQUNBLGtCQUFBO0FBRko7QUFJSTtFQUNJLFlBQUE7RUFDQSwwQkFBQTtFQUNBLGFBQUE7RUFDQSxpREFBQTtFQUNBLG1CQUFBO0FBRlI7QUFNUTtFQUNJLHFCQUFBO0VBQ0EsY0FBQTtBQUpaO0FBU1E7RUFDSSxxQkFBQTtBQVBaIiwiZmlsZSI6ImRldmVsb3BtZW50LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiZGV2ZWxvcG1lbnQtY29tcG9uZW50IHtcbiAgICBwb3NpdGlvbjogZml4ZWQ7XG4gICAgdG9wOiAwO1xuICAgIGRpcmVjdGlvbjogbHRyO1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiA1MDtcbiAgICBwYWRkaW5nLXRvcDogMHB4O1xuICAgIHBhZGRpbmctdG9wOiBjbGFjKGNvbnN0YW50KHNhZmUtYXJlYS1pbnNldC10b3ApKTtcbiAgICBwYWRkaW5nLXRvcDogY2FsYyhlbnYoc2FmZS1hcmVhLWluc2V0LXRvcCkpO1xuICAgIHBhZGRpbmctYm90dG9tOiAyNnB4O1xuICAgIGxpbmUtaGVpZ2h0OiAxMnB4O1xuICAgIGZvbnQtc2l6ZTogMTJweDtcblxuICAgIC8vIGJhY2tncm91bmQ6ICNiNDgzYWY7XG4gICAgLy8gYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDE4MGRlZywgI2I0ODNhZiwgdHJhbnNwYXJlbnQpO1xuICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICMyZWJkODUgMCUsICMwMDUxNTcwMCAxMDAlKTtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG5cbiAgICBhIHtcbiAgICAgICAgY29sb3I6IHdoaXRlO1xuICAgICAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgICAgICAgZGlzcGxheTogbm9uZTtcbiAgICAgICAgdGV4dC1zaGFkb3c6IDFweCAxcHggMXB4IHJnYmEoMTgwLCAxMzEsIDE3NSwgMC41KTtcbiAgICAgICAgcG9pbnRlci1ldmVudHM6IGFsbDtcbiAgICB9XG5cbiAgICAmLnN0YXJ0ZWQge1xuICAgICAgICAjc3RvcCB7XG4gICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgICAgICAgICBjb2xvcjogcmdiKDI1NSwgMCwgMTQwKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgICY6bm90KC5zdGFydGVkKSB7XG4gICAgICAgICNzdGFydCB7XG4gICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgICAgIH1cbiAgICB9XG59Il19 */";

/***/ }),

/***/ 52080:
/*!************************************************************************************************************!*\
  !*** ./src/app/common-ui-components/internet-disconnected/internet-disconnected.component.scss?ngResource ***!
  \************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".txtClass {\n  color: white;\n  line-height: 0.7;\n}\n\nbody.dark :host .txtClass {\n  color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImludGVybmV0LWRpc2Nvbm5lY3RlZC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFlBQUE7RUFDQSxnQkFBQTtBQUNKOztBQUdFO0VBQ0UsWUFBQTtBQUFKIiwiZmlsZSI6ImludGVybmV0LWRpc2Nvbm5lY3RlZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50eHRDbGFzc3tcbiAgICBjb2xvcjp3aGl0ZTtcbiAgICBsaW5lLWhlaWdodDogLjc7XG4gIH1cblxuXG4gIGJvZHkuZGFyayA6aG9zdCAudHh0Q2xhc3N7XG4gICAgY29sb3I6IHdoaXRlO1xufSJdfQ== */";

/***/ }),

/***/ 49183:
/*!****************************************************************************!*\
  !*** ./src/app/disconnection-page/disconnection-page.page.scss?ngResource ***!
  \****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ":host ion-toolbar {\n  --background: #f5455a;\n  --color: white;\n}\n\n:host #content {\n  -webkit-animation: fadein 0.5s ease-in-out;\n          animation: fadein 0.5s ease-in-out;\n  -webkit-animation-delay: 0.5s;\n          animation-delay: 0.5s;\n  -webkit-animation-fill-mode: backwards;\n          animation-fill-mode: backwards;\n  color: #f5455a;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  height: 100%;\n  flex-direction: column;\n}\n\n:host #content ion-icon {\n  font-size: 128px;\n}\n\n:host #content ion-spinner {\n  color: #f5455a;\n}\n\n@-webkit-keyframes fadein {\n  from {\n    opacity: 0;\n  }\n  to {\n    opacity: 1;\n  }\n}\n\n@keyframes fadein {\n  from {\n    opacity: 0;\n  }\n  to {\n    opacity: 1;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRpc2Nvbm5lY3Rpb24tcGFnZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxxQkFBQTtFQUNBLGNBQUE7QUFDSjs7QUFHSTtFQUVJLDBDQUFBO1VBQUEsa0NBQUE7RUFDQSw2QkFBQTtVQUFBLHFCQUFBO0VBQ0Esc0NBQUE7VUFBQSw4QkFBQTtFQUVBLGNBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxzQkFBQTtBQUZSOztBQUlRO0VBQ0ksZ0JBQUE7QUFGWjs7QUFLUTtFQUNJLGNBQUE7QUFIWjs7QUFRQTtFQUNBO0lBQU8sVUFBQTtFQUpMO0VBS0Y7SUFBTyxVQUFBO0VBRkw7QUFDRjs7QUFEQTtFQUNBO0lBQU8sVUFBQTtFQUpMO0VBS0Y7SUFBTyxVQUFBO0VBRkw7QUFDRiIsImZpbGUiOiJkaXNjb25uZWN0aW9uLXBhZ2UucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3QgaW9uLXRvb2xiYXIge1xuICAgIC0tYmFja2dyb3VuZDogI2Y1NDU1YTtcbiAgICAtLWNvbG9yOiB3aGl0ZTtcbn1cblxuOmhvc3Qge1xuICAgICNjb250ZW50IHtcblxuICAgICAgICBhbmltYXRpb246IGZhZGVpbiAwLjVzIGVhc2UtaW4tb3V0O1xuICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNXM7XG4gICAgICAgIGFuaW1hdGlvbi1maWxsLW1vZGU6IGJhY2t3YXJkcztcblxuICAgICAgICBjb2xvcjogI2Y1NDU1YTtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgIGhlaWdodDogMTAwJTtcbiAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcblxuICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICBmb250LXNpemU6IDEyOHB4O1xuICAgICAgICB9XG5cbiAgICAgICAgaW9uLXNwaW5uZXIge1xuICAgICAgICAgICAgY29sb3I6ICNmNTQ1NWE7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbkBrZXlmcmFtZXMgZmFkZWluIHtcbmZyb20geyBvcGFjaXR5OiAwOyB9XG50byAgIHsgb3BhY2l0eTogMTsgfVxufSJdfQ== */";

/***/ }),

/***/ 41419:
/*!************************************************************************************!*\
  !*** ./src/app/dynamic-authentication/dynamic-authentication.page.scss?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ":host ion-toolbar {\n  --background: #005157;\n  --color: white;\n}\n\n#sumit-button {\n  --background: #005157;\n}\n\n:host ion-button {\n  margin: 15px;\n}\n\nion-list-header, ion-item {\n  --color: #005157;\n}\n\nbody.dark :host ion-list-header, body.dark :host ion-item {\n  --color: #ffffff !important;\n}\n\n#list-header {\n  padding: 15px;\n  text-align: center;\n  font-size: 150%;\n  font-weight: bold;\n  color: #005157;\n}\n\nbody.dark :host #list-header {\n  color: white !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImR5bmFtaWMtYXV0aGVudGljYXRpb24ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kscUJBQUE7RUFDQSxjQUFBO0FBQ0o7O0FBRUE7RUFDSSxxQkFBQTtBQUNKOztBQUNBO0VBQ0ksWUFBQTtBQUVKOztBQUNBO0VBQ0ksZ0JBQUE7QUFFSjs7QUFESTtFQUNJLDJCQUFBO0FBR1I7O0FBQ0E7RUFDSSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0FBRUo7O0FBQ0E7RUFDSSx1QkFBQTtBQUVKIiwiZmlsZSI6ImR5bmFtaWMtYXV0aGVudGljYXRpb24ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3QgaW9uLXRvb2xiYXIge1xuICAgIC0tYmFja2dyb3VuZDogIzAwNTE1NztcbiAgICAtLWNvbG9yOiB3aGl0ZTtcbn1cblxuI3N1bWl0LWJ1dHRvbiB7XG4gICAgLS1iYWNrZ3JvdW5kOiAjMDA1MTU3O1xufVxuOmhvc3QgaW9uLWJ1dHRvbiB7XG4gICAgbWFyZ2luOiAxNXB4O1xufVxuXG5pb24tbGlzdC1oZWFkZXIsIGlvbi1pdGVtIHtcbiAgICAtLWNvbG9yOiAjMDA1MTU3O1xuICAgIGJvZHkuZGFyayA6aG9zdCAmIHtcbiAgICAgICAgLS1jb2xvcjogI2ZmZmZmZiAhaW1wb3J0YW50O1xuICAgIH1cbn1cblxuI2xpc3QtaGVhZGVyIHtcbiAgICBwYWRkaW5nOiAxNXB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXNpemU6IDE1MCU7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgY29sb3I6ICMwMDUxNTc7XG59XG5cbmJvZHkuZGFyayA6aG9zdCAjbGlzdC1oZWFkZXIge1xuICAgIGNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufSJdfQ== */";

/***/ }),

/***/ 60304:
/*!******************************************************!*\
  !*** ./src/app/loading/loading.page.scss?ngResource ***!
  \******************************************************/
/***/ ((module) => {

"use strict";
module.exports = "tadawul-loading tadawul-loader {\n  --loader-background: transparent !important;\n}\n.fade-enter-animation-container .modal-wrapper {\n  background: #ffffff40 !important;\n  -webkit-backdrop-filter: blur(64px);\n          backdrop-filter: blur(64px);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvYWRpbmcucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNJO0VBR0ksMkNBQUE7QUFGUjtBQWtCSTtFQUNJLGdDQUFBO0VBQ0EsbUNBQUE7VUFBQSwyQkFBQTtBQWhCUiIsImZpbGUiOiJsb2FkaW5nLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbInRhZGF3dWwtbG9hZGluZyB7XG4gICAgdGFkYXd1bC1sb2FkZXIge1xuICAgICAgICAvLyAtLWxvYWRlci1iYWNrZ3JvdW5kOiAjMDA1MzU5N2E7XG4gICAgICAgIC8vIC0tbG9hZGVyLWJhY2tncm91bmQ6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC41KVxuICAgICAgICAtLWxvYWRlci1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuICAgIH1cblxuICAgIGlvbi1tb2RhbCB7XG5cbiAgICAgICAgLy8gYmFja2Ryb3AtZmlsdGVyOiBibHVyKDEwcHgpO1xuICAgIH1cbn1cblxuLm1vZGFsLXdyYXBwZXIge1xuICAgIC8vIHRyYW5zaXRpb246IGJhY2tkcm9wLWZpbHRlciAxcztcbiAgICAvLyBvdmVyZmxvdzogaGlkZGVuO1xuICAgIC8vIGJhY2tkcm9wLWZpbHRlcjogYmx1cigwcHgpO1xufVxuXG4uZmFkZS1lbnRlci1hbmltYXRpb24tY29udGFpbmVyIHtcbiAgICAubW9kYWwtd3JhcHBlciB7XG4gICAgICAgIGJhY2tncm91bmQ6ICNmZmZmZmY0MCAhaW1wb3J0YW50O1xuICAgICAgICBiYWNrZHJvcC1maWx0ZXI6IGJsdXIoNjRweCk7XG4gICAgfVxufSJdfQ== */";

/***/ }),

/***/ 92165:
/*!***********************************************************!*\
  !*** ./src/app/pages/menu/menu.component.scss?ngResource ***!
  \***********************************************************/
/***/ ((module) => {

"use strict";
module.exports = ":host {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  display: block;\n  pointer-events: none;\n}\nbody.dark :host {\n  --ion-color-primary-txt: #d2d2d2;\n}\n:host ion-menu {\n  pointer-events: all;\n}\n:host #header {\n  height: 160px;\n  background: #005157;\n  color: white;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\nbody.dark :host #header {\n  background: #1e1e1e !important;\n}\n:host #profile-photo {\n  width: 48px;\n  height: 48px;\n  -o-object-fit: contain;\n     object-fit: contain;\n}\n:host #profile-photo svg {\n  transform: scale(0.9);\n}\n:host #name {\n  width: 224px;\n  height: 32px;\n  font-family: AlinmaTheSans;\n  font-size: 18px;\n  font-weight: bold;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: normal;\n  letter-spacing: normal;\n  text-align: start;\n  color: var(--white);\n}\n:host #icon-container {\n  display: flex;\n  align-items: center;\n  margin: 0;\n}\n:host ion-item {\n  --transition: none;\n  --color: var(--ion-color-primary-txt);\n  --border-color: rgba(205, 223, 225, 0.5);\n}\n:host .no-outline {\n  outline: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1lbnUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtFQUNBLG9CQUFBO0FBQ0o7QUFDSTtFQUNJLGdDQUFBO0FBQ1I7QUFFSTtFQUNJLG1CQUFBO0FBQVI7QUFFSTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFFQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQURSO0FBR1E7RUFDSSw4QkFBQTtBQURaO0FBS0k7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHNCQUFBO0tBQUEsbUJBQUE7QUFIUjtBQUtRO0VBQ0kscUJBQUE7QUFIWjtBQU9JO0VBQ0ksWUFBQTtFQUNBLFlBQUE7RUFDQSwwQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtBQUxSO0FBUUk7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxTQUFBO0FBTlI7QUFTSTtFQUNJLGtCQUFBO0VBRUEscUNBQUE7RUFDQSx3Q0FBQTtBQVJSO0FBV0k7RUFDSSxhQUFBO0FBVFIiLCJmaWxlIjoibWVudS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICAgIFxuICAgIGJvZHkuZGFyayAmIHtcbiAgICAgICAgLS1pb24tY29sb3ItcHJpbWFyeS10eHQ6ICNkMmQyZDI7XG4gICAgfVxuICAgIFxuICAgIGlvbi1tZW51IHtcbiAgICAgICAgcG9pbnRlci1ldmVudHM6IGFsbDtcbiAgICB9XG4gICAgI2hlYWRlciB7XG4gICAgICAgIGhlaWdodCAgICA6IDE2MHB4O1xuICAgICAgICBiYWNrZ3JvdW5kOiAjMDA1MTU3O1xuICAgICAgICBjb2xvciAgICAgOiB3aGl0ZTtcblxuICAgICAgICBkaXNwbGF5ICAgICAgICA6IGZsZXg7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgICBhbGlnbi1pdGVtcyAgICA6IGNlbnRlcjtcblxuICAgICAgICBib2R5LmRhcmsgJntcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICMxZTFlMWUgIWltcG9ydGFudDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgICNwcm9maWxlLXBob3RvIHtcbiAgICAgICAgd2lkdGggICAgIDogNDhweDtcbiAgICAgICAgaGVpZ2h0ICAgIDogNDhweDtcbiAgICAgICAgb2JqZWN0LWZpdDogY29udGFpbjtcblxuICAgICAgICBzdmcge1xuICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgwLjkpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgI25hbWUge1xuICAgICAgICB3aWR0aCAgICAgICAgIDogMjI0cHg7XG4gICAgICAgIGhlaWdodCAgICAgICAgOiAzMnB4O1xuICAgICAgICBmb250LWZhbWlseSAgIDogQWxpbm1hVGhlU2FucztcbiAgICAgICAgZm9udC1zaXplICAgICA6IDE4cHg7XG4gICAgICAgIGZvbnQtd2VpZ2h0ICAgOiBib2xkO1xuICAgICAgICBmb250LXN0cmV0Y2ggIDogbm9ybWFsO1xuICAgICAgICBmb250LXN0eWxlICAgIDogbm9ybWFsO1xuICAgICAgICBsaW5lLWhlaWdodCAgIDogbm9ybWFsO1xuICAgICAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgICAgICB0ZXh0LWFsaWduICAgIDogc3RhcnQ7XG4gICAgICAgIGNvbG9yICAgICAgICAgOiB2YXIoLS13aGl0ZSk7XG4gICAgfVxuXG4gICAgI2ljb24tY29udGFpbmVyIHtcbiAgICAgICAgZGlzcGxheSAgICA6IGZsZXg7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgIG1hcmdpbiAgICAgOiAwO1xuICAgIH1cblxuICAgIGlvbi1pdGVtIHtcbiAgICAgICAgLS10cmFuc2l0aW9uICA6IG5vbmU7XG4gICAgICAgIC8vIC0tY29sb3IgICAgICAgOiAjMDA1MTU3O1xuICAgICAgICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS10eHQpO1xuICAgICAgICAtLWJvcmRlci1jb2xvcjogcmdiYSgyMDUsIDIyMywgMjI1LCAwLjUpO1xuICAgIH1cblxuICAgIC5uby1vdXRsaW5lIHtcbiAgICAgICAgb3V0bGluZTpub25lO1xuICAgIH1cbn1cblxuIl19 */";

/***/ }),

/***/ 25564:
/*!****************************************************************************!*\
  !*** ./src/app/pages/session-expired/session-expired.page.scss?ngResource ***!
  \****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".state-img {\n  width: 150px;\n  height: 150px;\n  margin: 10px 0;\n}\n\n.state-title {\n  font-size: 20px;\n  font-weight: bold;\n  color: #005157;\n  margin-top: 10px;\n}\n\n.state-message {\n  font-size: 16px;\n  color: #347478;\n  margin: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlc3Npb24tZXhwaXJlZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBaUJBO0VBQ0UsWUFBQTtFQUNBLGFBQUE7RUFDQSxjQUFBO0FBaEJGOztBQW1CQTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQWhCRjs7QUFrQkE7RUFDRSxlQUFBO0VBQ0EsY0FBQTtFQUNBLFNBQUE7QUFmRiIsImZpbGUiOiJzZXNzaW9uLWV4cGlyZWQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gaW9uLWhlYWRlciB7XG4vLyAgICAgaW9uLXRvb2xiYXIge1xuLy8gICAgICAgLS1iYWNrZ3JvdW5kOiAjMDA1MTU3O1xuLy8gICAgICAgY29sb3I6ICNmZmY7XG4vLyAgICAgfVxuLy8gICB9XG5cbi8vICAgLnR4dENsYXNze1xuLy8gICAgIGNvbG9yOiMwMDUxNTc7XG4vLyAgICAgbGluZS1oZWlnaHQ6IC43O1xuLy8gICB9XG5cblxuLy8gICBib2R5LmRhcmsgOmhvc3QgLnR4dENsYXNze1xuLy8gICAgIGNvbG9yOiB3aGl0ZTtcbi8vIH1cblxuLnN0YXRlLWltZyB7XG4gIHdpZHRoOiAxNTBweDtcbiAgaGVpZ2h0OiAxNTBweDtcbiAgbWFyZ2luOiAxMHB4IDA7XG59XG5cbi5zdGF0ZS10aXRsZSB7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGNvbG9yOiMwMDUxNTc7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG4uc3RhdGUtbWVzc2FnZSB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgY29sb3I6ICMzNDc0Nzg7XG4gIG1hcmdpbjogMDtcbn0iXX0= */";

/***/ }),

/***/ 15211:
/*!********************************************************************************!*\
  !*** ./src/app/token-authentication/token-authentication.page.scss?ngResource ***!
  \********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "#sumit-button {\n  --background: #005157;\n}\n\n:host ion-button {\n  margin: 16px;\n  --border-radius: 5px;\n}\n\n.resend-link.examble, .resend-link.resend {\n  color: #da2d2d;\n  font-size: 12px;\n}\n\n.resend-link.disabled {\n  color: #999999;\n  font-size: 12px;\n}\n\nion-label {\n  display: block;\n}\n\n.resend-link.examble, .resend-link.resend {\n  color: #da2d2d;\n  font-size: 12px;\n}\n\n.resend-link.disabled {\n  color: #999999;\n  font-size: 12px;\n}\n\n.timer {\n  font-size: 18px;\n  font-weight: bold;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.timer .value {\n  width: 55px;\n  text-align: end;\n}\n\n#dynamicAuthenticationContentDiv {\n  padding: 15px;\n  padding-bottom: 0;\n}\n\n.description,\nion-label {\n  color: #005457;\n  text-align: justify;\n}\n\nbody.dark :host(.description, ion-label) {\n  color: white;\n}\n\nion-item {\n  color: #005457;\n  --inner-padding-end: 0;\n  --inner-padding-start: 0;\n  --padding-start: 0;\n  --padding-end: 0;\n  --inner-border-width: 0;\n  padding: 16px 0;\n  font-weight: bold;\n}\n\nion-item ion-input {\n  text-align: center;\n  dir: ltr;\n}\n\nbody.dark :host ion-item {\n  color: white;\n}\n\n.otp-input {\n  font-size: 16px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRva2VuLWF1dGhlbnRpY2F0aW9uLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFLQTtFQUNJLHFCQUFBO0FBSko7O0FBT0E7RUFDSSxZQUFBO0VBQ0Esb0JBQUE7QUFKSjs7QUFRSTtFQUNJLGNBQUE7RUFDQSxlQUFBO0FBTFI7O0FBT0k7RUFDSSxjQUFBO0VBQ0EsZUFBQTtBQUxSOztBQVdBO0VBQ0ksY0FBQTtBQVJKOztBQVlJO0VBQ0ksY0FBQTtFQUNBLGVBQUE7QUFUUjs7QUFXSTtFQUNJLGNBQUE7RUFDQSxlQUFBO0FBVFI7O0FBYUE7RUFFSSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQVhKOztBQWdCSTtFQUNJLFdBQUE7RUFDQSxlQUFBO0FBZFI7O0FBdUJBO0VBQ0ksYUFBQTtFQUNBLGlCQUFBO0FBcEJKOztBQXVCQTs7RUFFSSxjQUFBO0VBQ0EsbUJBQUE7QUFwQko7O0FBdUJBO0VBQ0ksWUFBQTtBQXBCSjs7QUF5QkE7RUFDSSxjQUFBO0VBQ0Esc0JBQUE7RUFDQSx3QkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQXRCSjs7QUF3Qkk7RUFDSSxrQkFBQTtFQUNBLFFBQUE7QUF0QlI7O0FBeUJJO0VBQ0ksWUFBQTtBQXZCUjs7QUE4QkE7RUFDSSxlQUFBO0FBM0JKIiwiZmlsZSI6InRva2VuLWF1dGhlbnRpY2F0aW9uLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIDpob3N0IGlvbi10b29sYmFyIHtcbi8vICAgICAtLWJhY2tncm91bmQ6ICMwMDUxNTc7XG4vLyAgICAgLS1jb2xvcjogd2hpdGU7XG4vLyB9XG5cbiNzdW1pdC1idXR0b24ge1xuICAgIC0tYmFja2dyb3VuZDogIzAwNTE1Nztcbn1cblxuOmhvc3QgaW9uLWJ1dHRvbiB7XG4gICAgbWFyZ2luOiAxNnB4O1xuICAgIC0tYm9yZGVyLXJhZGl1czogNXB4O1xufVxuXG4ucmVzZW5kLWxpbmsge1xuICAgICYuZXhhbWJsZSwgJi5yZXNlbmQge1xuICAgICAgICBjb2xvcjogI2RhMmQyZDtcbiAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgIH1cbiAgICAmLmRpc2FibGVke1xuICAgICAgICBjb2xvcjogIzk5OTk5OTtcbiAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgIH1cbn1cblxuXG5cbmlvbi1sYWJlbCB7XG4gICAgZGlzcGxheTogYmxvY2s7XG59XG5cbi5yZXNlbmQtbGluayB7XG4gICAgJi5leGFtYmxlLCAmLnJlc2VuZCB7XG4gICAgICAgIGNvbG9yOiAjZGEyZDJkO1xuICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgfVxuICAgICYuZGlzYWJsZWR7XG4gICAgICAgIGNvbG9yOiAjOTk5OTk5O1xuICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgfVxufVxuXG4udGltZXIge1xuICAgIC8vIHRleHQtYWxpZ246IGVuZDtcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuXG4gICAgLy8gLmljb24ge1xuICAgIC8vICAgICBtYXJnaW4taW5saW5lLWVuZDogMTBweDtcbiAgICAvLyB9XG4gICAgLnZhbHVlIHtcbiAgICAgICAgd2lkdGg6IDU1cHg7XG4gICAgICAgIHRleHQtYWxpZ246IGVuZDtcbiAgICB9XG59XG4vLyAudGltZXJWYWx1ZSB7XG4gICAgXG5cbi8vICAgICAvLyBjb2xvcjogI0Y5M0YwMyAhaW1wb3J0YW50O1xuLy8gfVxuXG4jZHluYW1pY0F1dGhlbnRpY2F0aW9uQ29udGVudERpdiB7XG4gICAgcGFkZGluZzogMTVweDtcbiAgICBwYWRkaW5nLWJvdHRvbTogMDtcbn1cblxuLmRlc2NyaXB0aW9uLFxuaW9uLWxhYmVsIHtcbiAgICBjb2xvcjogIzAwNTQ1NztcbiAgICB0ZXh0LWFsaWduOiBqdXN0aWZ5O1xufVxuXG5ib2R5LmRhcmsgOmhvc3QoLmRlc2NyaXB0aW9uLCBpb24tbGFiZWwpIHtcbiAgICBjb2xvcjogd2hpdGU7XG59XG5cblxuXG5pb24taXRlbSB7XG4gICAgY29sb3I6ICMwMDU0NTc7XG4gICAgLS1pbm5lci1wYWRkaW5nLWVuZDogMDtcbiAgICAtLWlubmVyLXBhZGRpbmctc3RhcnQ6IDA7XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xuICAgIC0tcGFkZGluZy1lbmQ6IDA7XG4gICAgLS1pbm5lci1ib3JkZXItd2lkdGg6IDA7XG4gICAgcGFkZGluZzogMTZweCAwO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuXG4gICAgaW9uLWlucHV0IHtcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICBkaXI6IGx0cjtcbiAgICB9XG5cbiAgICBib2R5LmRhcmsgOmhvc3QgJiB7XG4gICAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICB9XG59XG5cblxuXG5cbi5vdHAtaW5wdXQge1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbn0iXX0= */";

/***/ }),

/***/ 33383:
/*!***********************************************!*\
  !*** ./src/app/app.component.html?ngResource ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-app>\n  <!-- {{ JSON.stringify(Users.current) }} -->\n  <!-- {{ networkStatus?.connected ? \"Online\" : \"Offline\"}} -->\n  <!-- <ion-split-pane *ngIf=\"!MenuComponent.isLanguageToggled\" id=\"not-toggled\" contentId=\"main\">\n    <ion-router-outlet id=\"main\"></ion-router-outlet>\n    <app-menu></app-menu>\n    <app-tabbar class=\"hide-on-keyboard-open\"></app-tabbar>\n  </ion-split-pane>\n\n  <ion-split-pane *ngIf=\"MenuComponent.isLanguageToggled\" id=\"toggled\" contentId=\"main\">\n    <ion-router-outlet id=\"main\"></ion-router-outlet>\n    <app-menu></app-menu>\n    <app-tabbar class=\"hide-on-keyboard-open\"></app-tabbar>\n  </ion-split-pane> -->\n\n  <!-- <app-menu [visible]=\"false\"></app-menu> -->\n\n\n  <!-- Development Settings -->\n  <!-- <ion-fab *ngIf=\"Environment.isDevelopment && Environment.developerComponent?.enabled\" vertical=\"center\"\n    horizontal=\"start\" slot=\"fixed\">\n    <ion-fab-button>\n      <ion-icon name=\"settings-outline\"></ion-icon>\n    </ion-fab-button>\n    <ion-fab-list side=\"top\">\n      <ion-fab-button (click)=\"toggleTheme()\">\n        <ion-icon name=\"moon\"></ion-icon>\n      </ion-fab-button>\n    </ion-fab-list>\n    <ion-fab-list side=\"bottom\">\n      <ion-fab-button (click)=\"changeLanguage()\">\n        <ion-icon name=\"language-outline\"></ion-icon>\n      </ion-fab-button>\n    </ion-fab-list>\n  </ion-fab> -->\n\n  <ion-router-outlet></ion-router-outlet>\n  <!-- <ng-container *ngIf=\"App.isActive('/')\"> -->\n    <!-- <ion-router-outlet ></ion-router-outlet> -->\n  <!-- </ng-container>\n  <ng-container *ngIf=\"!App.isActive('/')\" >\n  </ng-container> -->\n  <!-- <ng-container *ngIf=\"routerDirection == 'rtl'\" >\n    <ion-router-outlet  dir=\"rtl\"></ion-router-outlet>\n  </ng-container>\n  <ng-container *ngIf=\"routerDirection == 'ltr'\" >\n    <ion-router-outlet  dir=\"ltr\"></ion-router-outlet>\n  </ng-container> -->\n</ion-app>\n\n<div *ngIf=\"Environment.watermark?.enabled\">\n  <development-component></development-component>\n</div>";

/***/ }),

/***/ 11453:
/*!****************************************************************************************!*\
  !*** ./src/app/common-ui-components/development/development.component.html?ngResource ***!
  \****************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "watermark({{ Environment.watermark?.buildVersion }}, {{ Users.current?.username || '*' }}<br />, {{Environment.webserviceURL}})\n";

/***/ }),

/***/ 71664:
/*!************************************************************************************************************!*\
  !*** ./src/app/common-ui-components/internet-disconnected/internet-disconnected.component.html?ngResource ***!
  \************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n  <div style=\"text-align: center;margin-top: 90%;\">\n    <h2 class=\"txtClass\"  style=\"font-weight: bold;\">{{'internetDisconnect.textOne' | translate}}</h2>\n    <h4 class=\"txtClass\">{{'internetDisconnect.textTwo' | translate}}</h4>\n  </div>\n\n    <ion-col size=\"12\" style=\"margin-top: 60%;\">\n    <ion-button (click)=\"goToLoginPage()\"  style=\"--border-radius: 0px;border: 1px solid white;\"  color=\"primary\" fill=\"solid\" expand=\"block\">{{'internetDisconnect.goToLogin' | translate}}\n    </ion-button>\n  </ion-col>\n\n\n<tadawul-loader addClass=\"disconnect-class\"></tadawul-loader>\n";

/***/ }),

/***/ 94436:
/*!****************************************************************************!*\
  !*** ./src/app/disconnection-page/disconnection-page.page.html?ngResource ***!
  \****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>Disconnection</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <div id='content'>\n    <ion-icon name=\"cloud-offline-outline\"></ion-icon>\n\n    <div>\n      Trying to connect\n    </div>\n\n    <div>\n      <ion-label  class=\"timerValue\">{{timerDisplayValue}}</ion-label>\n    </div>\n    <ion-spinner name=\"crescent\"></ion-spinner>\n  </div>\n\n\n</ion-content>\n";

/***/ }),

/***/ 62193:
/*!************************************************************************************!*\
  !*** ./src/app/dynamic-authentication/dynamic-authentication.page.html?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>\n      {{ 'dynamicAuthenticate.ACTIVATION' | translate }}\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-list radio-group *ngIf=\"authenticationGroups\" class=\"panel\">\n\n    <ion-radio-group [(ngModel)]=\"selectedGroup\">\n\n      <div id=\"list-header\" no-lines>\n        {{ 'dynamicAuthenticate.SELECT_ACTIVATION' | translate }}\n      </div>\n\n      <ion-item *ngFor=\"let group of authenticationGroups\">\n        <ion-radio style=\"margin : 5px;\" item-start [value]=\"group.groupName\"></ion-radio>\n        <ion-label>{{group.groupDescription}}</ion-label>\n      </ion-item>\n\n    </ion-radio-group>\n  </ion-list>\n\n\n  <ion-button id='submit-button' expand=\"full\" (click)=\"goToTokenPage()\" [disabled]=\"!selectedGroup || selectedGroup == ''\">\n    {{ 'dynamicAuthenticate.NEXT' | translate }}\n  </ion-button>\n\n</ion-content>";

/***/ }),

/***/ 60293:
/*!******************************************************!*\
  !*** ./src/app/loading/loading.page.html?ngResource ***!
  \******************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-content style=\"--background: transparent;\">\n\n  <div style=\"width: 100%; height: 100%;    display: flex;\n  justify-content: center;\n  align-items: center;\">\n    <!-- <ion-spinner name=\"crescent\" style=\"    color: white;\n    width: 128px;\n    height: 128px;\"></ion-spinner> -->\n    <tadawul-loader></tadawul-loader>\n  </div>\n  \n\n</ion-content>\n";

/***/ }),

/***/ 62131:
/*!***********************************************************!*\
  !*** ./src/app/pages/menu/menu.component.html?ngResource ***!
  \***********************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<!-- <ion-menu menuId=\"menu\" [disabled]=\"AppComponent.isAnonymousRouteActive()\" type=\"overlay\" contentId=\"{{contentId}}\"\n  (ionWillClose)=\"onClose()\" (ionWillOpen)=\"onOpen()\"> -->\n  <div id='header'>\n    <!-- MenuHeader -->\n    <!--this line responsable for direct to kyc pages [routerLink]=\"!AppComponent.ExpiredUserID ? ['/kyc/home'] : []\" (click)=\"close()\" -->\n    <ion-grid class=\"no-outline\"  >\n      <ion-row>\n        <ion-col id='icon-container'>\n          <img src='assets/icon/profile-photo.svg' id=\"profile-photo\">\n          <!-- <ion-icon src='assets/icon/profile-photo.svg' class=\"profile-photo\"></ion-icon> -->\n        </ion-col>\n        <ion-col>\n          <div id='name'>\n            {{userName}}\n          </div>\n          <!-- <div id='modify'>\n            {{ t.MODIFY_ACCOUNT }}\n          </div> -->\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n\n\n\n    <!--// -->\n  </div>\n<!-- \n  <ion-content> -->\n    <ion-list>\n\n      <ion-item button routerLink=\"/products\" (click)=\"close()\" >\n        <ion-icon *ngIf=\"!dark\" color=\"txt\" slot=\"start\" src=\"assets/icon/products.svg\"></ion-icon>\n        <ion-icon *ngIf=\"dark\" color=\"txt\" slot=\"start\" src=\"assets/icon/products-dark.svg\"></ion-icon>\n        <ion-label color=\"txt\">\n          {{ t.PRODUCTS }}\n        </ion-label>\n      </ion-item>\n\n      <ion-item button routerLink=\"/portfolios/home\" (click)=\"close()\" >\n        <ion-icon *ngIf=\"!dark\" color=\"txt\" slot=\"start\" src=\"assets/icon/portfolios.svg\"></ion-icon>\n        <ion-icon *ngIf=\"dark\" color=\"txt\" slot=\"start\" src=\"assets/icon/portfolios-dark.svg\"></ion-icon>\n        <ion-label color=\"txt\">\n          {{ t.PORTFOLIOS }}\n        </ion-label>\n      </ion-item>\n\n      <ion-item button routerLink=\"/transfer/transfer-home\" (click)=\"close()\" >\n        <ion-icon *ngIf=\"!dark\" color=\"txt\" slot=\"start\" src=\"assets/icon/moneytransfer.svg\"></ion-icon>\n        <ion-icon *ngIf=\"dark\" color=\"txt\" slot=\"start\" src=\"assets/icon/moneytransfer-dark.svg\"></ion-icon>\n        <ion-label color=\"txt\">\n          {{ t.fundTransfer }}\n        </ion-label>\n      </ion-item>\n\n      <ion-item button routerLink=\"/standing-orders/filter-order\" (click)=\"close()\" >\n        <ion-icon *ngIf=\"!dark\" color=\"txt\" slot=\"start\" src=\"assets/icon/order-search-icon.svg\"></ion-icon>\n        <ion-icon *ngIf=\"dark\" color=\"txt\" slot=\"start\" src=\"assets/icon/order-search-icon-dark.svg\"></ion-icon>\n        <ion-label color=\"txt\">\n          {{ t.searchOrder }}\n        </ion-label>\n      </ion-item>\n\n      <ion-item button routerLink=\"/mutual-funds\" (click)=\"close()\" >\n        <ion-icon *ngIf=\"!dark\" color=\"txt\" slot=\"start\" src=\"assets/icon/mutualfunds.svg\"></ion-icon>\n        <ion-icon *ngIf=\"dark\" color=\"txt\" slot=\"start\" src=\"assets/icon/mutualfunds-dark.svg\"></ion-icon>\n        <ion-label color=\"txt\">\n          {{ t.MUTUAL_FUNDS }}\n        </ion-label>\n      </ion-item>\n\n      <!-- <ion-item button routerLink=\"/transfer/home\">\n          <ion-label>\n            {{ t.fundTransfer }}\n          </ion-label>\n        </ion-item> -->\n\n      <ion-item button routerLink=\"/reports-mutual-funds\" (click)=\"close()\" >\n        <ion-icon *ngIf=\"!dark\" color=\"txt\" slot=\"start\" src=\"assets/icon/reports.svg\"></ion-icon>\n        <ion-icon *ngIf=\"dark\" color=\"txt\" slot=\"start\" src=\"assets/icon/reports-dark.svg\"></ion-icon>\n        <ion-label color=\"txt\">\n          {{ t.REPORTS }}\n        </ion-label>\n      </ion-item>\n      <ion-item button routerLink=\"/settings\" (click)=\"close()\" >\n        <ion-icon *ngIf=\"!dark\" slot=\"start\" src=\"assets/icon/settings.svg\"></ion-icon>\n        <ion-icon *ngIf=\"dark\" slot=\"start\" src=\"assets/icon/settings-dark.svg\"></ion-icon>\n        <ion-label color=\"txt\">\n          {{ t.SETTINGS }}\n        </ion-label>\n      </ion-item>\n      <ion-item button routerLink=\"/contact-us\" (click)=\"close()\" >\n        <ion-icon *ngIf=\"!dark\" color=\"txt\" slot=\"start\" src=\"assets/icon/contact.svg\"></ion-icon>\n        <ion-icon *ngIf=\"dark\" color=\"txt\" slot=\"start\" src=\"assets/icon/contact-dark.svg\"></ion-icon>\n        <ion-label color=\"txt\">\n          {{ t.CONTACT }}\n        </ion-label>\n      </ion-item>\n      <ion-item button color='danger' (click)=\"logout()\">\n        <ion-icon *ngIf=\"!dark\" slot=\"start\" src=\"assets/icon/signout.svg\"></ion-icon>\n        <ion-icon *ngIf=\"dark\" slot=\"start\" src=\"assets/icon/signout-dark.svg\"></ion-icon>\n        <ion-label>\n          {{ t.SIGNOUT }}\n        </ion-label>\n      </ion-item>\n    </ion-list>\n  <!-- </ion-content>\n</ion-menu> -->";

/***/ }),

/***/ 97156:
/*!****************************************************************************!*\
  !*** ./src/app/pages/session-expired/session-expired.page.html?ngResource ***!
  \****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n<ion-header>\n  <ion-toolbar>\n    <ion-title>{{'logout.logout' | translate}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"ion-text-center ion-padding\">\n    <img src=\"assets/icon/sessionExpired.svg\" class=\"state-img\">\n    <h1 class=\"state-title\">{{'logout.textOne' | translate}}</h1>\n    <p class=\"state-message\">{{'logout.textTwo' | translate}}</p>\n    <p class=\"state-message\">{{'logout.textThree' | translate}}</p>\n  </div>\n</ion-content>\n\n<ion-footer>\n  <ion-grid class=\"ion-padding\">\n      <app-button\n      (clickAction)=\"goToLoginPage()\"\n      expand=\"block\" \n      size=\"\"\n      color=\"primary\"\n      fill=\"solid\"\n      strong=\"false\"\n      target=\"_blank\"\n      >\n      {{'logout.goToLogin' | translate}}\n    </app-button>\n    \n  </ion-grid>\n</ion-footer>";

/***/ }),

/***/ 89545:
/*!********************************************************************************!*\
  !*** ./src/app/token-authentication/token-authentication.page.html?ngResource ***!
  \********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button [text]=\"''\" (click)=\"onBack()\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>\n      {{ 'loginPage.ACTIVATION_TOKEN' | translate }}\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div id=\"overlay\" [ngClass]=\"{fadeable: true, visible: loading}\"></div>\n      <div [ngClass]='{fadeable: true, visible: visible}'>\n        <div id=\"dynamicAuthenticationContentDiv\" class=\"panel\">\n          <div class=\"description\">{{groupNote}}</div>\n\n          <ion-item *ngFor=\"let groupMethod of authenticationGroup.methods\" class=\"otp-input\">\n            <ion-label position=\"stacked\">{{groupMethod.methodLabel}}</ion-label>\n            <ion-input maxLength=\"4\" type=\"tel\" [disabled]=\"timerEnded\" [id]=\"groupMethod.methodName\" [(ngModel)]=\"groupMethod.value\"\n              (ngModelChange)=\"tokenInput(groupMethod.value)\" #tokenInputField></ion-input>\n          </ion-item>\n\n          <div *ngIf=\"!timerEnded\">\n            <ion-label stacked *ngIf=\"groupTimer\">{{groupTimer.label}}</ion-label>\n            <ion-label class=\"timer\"><span class=\"icon icon-clock\"></span><span class=\"value\">{{timerDisplayTime}}</span></ion-label>\n          </div>\n          <div (click)=\"resendOTP()\" class=\"ion-text-center resend-link\" [ngClass]=\"timerEnded ? 'resend'  : 'disabled' \">  {{ 'loginPage.RESEND_OTP' | translate }}</div>\n        </div>\n\n        <ion-button id='submit-button' expand=\"block\" (click)=\"submitToken()\"\n          [disabled]=\"!authenticationGroup.methods[0].value\">\n          {{ 'loginPage.SUBMIT' | translate }}\n        </ion-button>\n      </div>\n</ion-content>";

/***/ }),

/***/ 4147:
/*!**********************!*\
  !*** ./package.json ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"name":"tadawul-mobile","version":"3.0.0","author":"Alinma Investment","homepage":"https://www.alinmainvestment.com","scripts":{"serve":"env=${env:-dev} ng serve --host 0.0.0.0 --port 4204 --configuration=$env","build":"env=${env:-dev} ng build --configuration=$env","canary":"killall \\"Google Chrome Canary\\"; sleep 1; open -a Google\\\\ Chrome\\\\ Canary http://localhost:4203 --args --disable-web-security  -–allow-file-access-from-files --user-data-dir=\\"/tmp\\"","chrome":"killall \\"Google Chrome\\"; sleep 4; open -a Google\\\\ Chrome http://localhost:4203 --args --disable-web-security  -–allow-file-access-from-files --user-data-dir=\\"/tmp\\"","ios":"ionic build && ionic capacitor sync ios","serve:prod":"ionic serve --prod","ios:prod":"ionic build --prod && ionic capacitor sync ios","android":"ionic build && ionic capacitor sync android","android:prod":"ionic build --prod && ionic capacitor sync android","resources":"cordova-res ios && cordova-res android && node scripts/resources.js","all":"nr ios && nr android"},"private":true,"dependencies":{"@angular/animations":"^10.1.1","@angular/common":"~13.3.0","@angular/core":"~13.3.0","@angular/forms":"~13.3.0","@angular/platform-browser":"~13.3.0","@angular/platform-browser-dynamic":"~13.3.0","@angular/router":"~13.3.0","@capacitor/android":"3.5.0","@capacitor/app":"1.1.1","@capacitor/browser":"^1.0.7","@capacitor/core":"3.5.0","@capacitor/device":"^1.1.2","@capacitor/haptics":"1.1.4","@capacitor/ios":"3.5.1","@capacitor/keyboard":"1.2.2","@capacitor/network":"^1.0.7","@capacitor/push-notifications":"^1.0.9","@capacitor/splash-screen":"^1.2.2","@capacitor/status-bar":"1.0.8","@capacitor/storage":"^1.2.5","@iconfu/svg-inject":"^1.2.3","@ionic-native/core":"^5.28.0","@ionic-native/diagnostic":"^5.36.0","@ionic-native/document-viewer":"^5.36.0","@ionic-native/file":"^5.36.0","@ionic-native/file-opener":"^5.36.0","@ionic-native/globalization":"^5.28.0","@ionic-native/http":"^5.29.0","@ionic-native/in-app-browser":"^5.32.1","@ionic-native/keychain-touch-id":"^5.28.0","@ionic-native/mobile-accessibility":"^5.30.0","@ionic-native/native-page-transitions":"^5.34.0","@ionic-native/network":"^5.30.0","@ionic-native/open-native-settings":"^5.36.0","@ionic-native/sms-retriever":"^5.30.0","@ionic-native/social-sharing":"^5.29.0","@ionic-native/splash-screen":"^5.28.0","@ionic-native/status-bar":"^5.28.0","@ionic-native/vibration":"^5.30.0","@ionic/angular":"^6.1.8","@ngx-translate/core":"^14.0.0","@ngx-translate/http-loader":"^7.0.0","@types/hammerjs":"^2.0.36","apexcharts":"^3.35.0","big-integer":"^1.6.36","chart.js":"^3.7.1","com.telerik.plugins.nativepagetransitions":"^0.7.0","cordova-open-native-settings":"^1.5.5","cordova-plugin-advanced-http":"^3.0.1","cordova-plugin-device":"git+https://github.com/apache/cordova-plugin-device.git","cordova-plugin-document-viewer":"^1.0.0","cordova-plugin-file":"^6.0.2","cordova-plugin-file-opener2":"^3.0.5","cordova-plugin-globalization":"^1.11.0","cordova-plugin-inappbrowser":"^4.1.0","cordova-plugin-keychain-touch-id":"git+https://github.com/sjhoeksma/cordova-plugin-keychain-touch-id.git","cordova-plugin-network-information":"git+https://github.com/apache/cordova-plugin-network-information.git","cordova-plugin-screen-orientation":"^3.0.2","cordova-plugin-sms-retriever-manager":"^1.0.2","cordova-plugin-vibration":"^3.1.1","cordova-plugin-whitelist":"^1.3.5","cordova-plugin-x-socialsharing":"^6.0.2","cordova.plugins.diagnostic":"^7.1.1","cupertino-pane":"^1.3.13","dom-to-image":"^2.6.0","dom-to-image-more":"^2.8.0","es6-promise-plugin":"^4.2.2","fast-sort":"^2.2.0","fitty":"^2.3.3","hammerjs":"^2.0.8","ion-bottom-drawer":"^2.0.0","ios":"^0.0.1","jetifier":"^1.6.6","jquery":"^3.5.1","jsencrypt":"^3.0.0-rc.1","moment":"^2.28.0","ngx-navigation-with-data":"^2.0.0","phonegap-plugin-mobile-accessibility":"^1.0.5","pushwoosh-cordova-plugin":"^8.3.3","quick":"0.0.6","run":"^1.4.0","rxjs":"~6.5.1","tslib":"^1.10.0","zone.js":"~0.10.2"},"devDependencies":{"@angular-devkit/build-angular":"^13.3.0","@angular/cli":"^13.3.0","@angular/compiler":"~13.3.0","@angular/compiler-cli":"~13.3.0","@angular/language-service":"~13.3.0","@capacitor/cli":"^3.4.3","@ionic/angular-toolkit":"^6.1.0","@types/jasmine":"^3.5.14","@types/jasminewd2":"~2.0.3","@types/node":"^12.12.58","codelyzer":"^5.1.2","cordova-res":"^0.15.2","deep-object-diff":"^1.1.0","jasmine-core":"~3.5.0","jasmine-spec-reporter":"~4.2.1","karma":"^6.3.17","karma-chrome-launcher":"~3.1.0","karma-coverage-istanbul-reporter":"~2.1.0","karma-jasmine":"~3.0.1","karma-jasmine-html-reporter":"^1.4.2","logrocket":"^1.0.13","npm-quick-run":"^1.16.0","protractor":"~5.4.3","tinygradient":"^1.1.2","ts-node":"~8.3.0","tslint":"^6.1.3","typescript":"~4.6.2"},"description":""}');

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(8835)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map