import { Component, OnInit, Input } from '@angular/core';
import { SkeletonType } from 'src/app/enum/skeleton-type.enum';

@Component({
  selector: 'tadawul-skeleton-loader',
  templateUrl: './skeleton-loader.component.html',
  styleUrls: ['./skeleton-loader.component.scss'],
})
export class SkeletonLoaderComponent implements OnInit {
  @Input('type') type: number;
  @Input('id') id?: number;
  SkeletonType = SkeletonType;
  constructor() { }

  ngOnInit() {}

}
