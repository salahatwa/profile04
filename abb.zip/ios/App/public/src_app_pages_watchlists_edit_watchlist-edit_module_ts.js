"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_watchlists_edit_watchlist-edit_module_ts"],{

/***/ 5535:
/*!************************************************************!*\
  !*** ./src/app/common-ui-components/search/search.page.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchPage": () => (/* binding */ SearchPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _search_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./search.page.html?ngResource */ 47494);
/* harmony import */ var _search_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./search.page.scss?ngResource */ 49802);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _inma_helpers_translations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/helpers/translations */ 69353);
/* harmony import */ var _search_translations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./search.translations */ 34238);
/* harmony import */ var _inma_helpers_strings__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/helpers/strings */ 36782);
/* harmony import */ var _inma_models_symbol__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @inma/models/symbol */ 61202);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 64139);










let SearchPage = class SearchPage {
    constructor(navCtrl, modalCtrl) {
        this.navCtrl = navCtrl;
        this.modalCtrl = modalCtrl;
        this.t = _search_translations__WEBPACK_IMPORTED_MODULE_3__.SearchTranslations;
        this.allSearchables = [];
        this.searchables = [];
    }
    ngOnInit() {
        _inma_models_symbol__WEBPACK_IMPORTED_MODULE_5__.Symbols.all.subscribe(symbols => {
            let s = this.symbols || symbols;
            this.allSearchables = s;
            this.searchables = this.allSearchables;
        });
    }
    filter() {
        console.log(this.queryText);
        _inma_models_symbol__WEBPACK_IMPORTED_MODULE_5__.Symbols.filter(this.queryText, (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.of)(this.allSearchables)).subscribe(symbols => {
            this.searchables = symbols;
        });
    }
    filter2() {
        console.log(this.queryText);
        let filteredSearchables = [];
        this.queryText = (this.queryText || '').trimStart();
        if (this.queryText != '') {
            this.queryText = _inma_helpers_strings__WEBPACK_IMPORTED_MODULE_4__.Strings.normalizeArabicNumbers(this.queryText.toLowerCase());
            const digitsRegex = /\d+/m;
            // Do extraction of the query text
            let queryNumbers = this.queryText.match(digitsRegex);
            let queryNumber = queryNumbers && queryNumbers.length > 0 ? queryNumbers[0].trim() : null;
            let queryWords = this.queryText.replace(digitsRegex, '').trim().toLowerCase();
            let secondFilteredSearchables = [];
            this.allSearchables.forEach((searchable) => {
                var _a;
                var matchValue = (_a = searchable === null || searchable === void 0 ? void 0 : searchable.toString()) === null || _a === void 0 ? void 0 : _a.toLocaleLowerCase();
                if (!matchValue)
                    return;
                let numberIndex = null, wordsIndex = null;
                if (queryNumber)
                    numberIndex = matchValue.indexOf(queryNumber);
                if (queryWords)
                    wordsIndex = matchValue.indexOf(queryWords);
                if (numberIndex != null && numberIndex != -1) {
                    if (wordsIndex == null || (wordsIndex != null && wordsIndex != -1)) {
                        if (numberIndex == 0)
                            filteredSearchables.push(searchable);
                        else
                            secondFilteredSearchables.push(searchable);
                    }
                }
                else if (numberIndex == null && wordsIndex && wordsIndex != -1) {
                    filteredSearchables.push(searchable);
                }
            });
            filteredSearchables.push(...secondFilteredSearchables);
        }
        else
            filteredSearchables = this.allSearchables;
        this.searchables = filteredSearchables;
    }
    select(searchable) {
        this.closeModal(searchable);
    }
    dismiss() {
        this.modalCtrl.dismiss();
    }
    closeModal(selectedSearchable) {
        this.modalCtrl.dismiss(selectedSearchable);
    }
};
SearchPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController }
];
SearchPage.propDecorators = {
    title: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input }],
    symbols: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input }],
    color: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input }]
};
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_inma_helpers_translations__WEBPACK_IMPORTED_MODULE_2__.Translations)(),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", Object)
], SearchPage.prototype, "t", void 0);
SearchPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'tadawul-search',
        template: _search_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_search_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController])
], SearchPage);



/***/ }),

/***/ 34238:
/*!********************************************************************!*\
  !*** ./src/app/common-ui-components/search/search.translations.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchTranslations": () => (/* binding */ SearchTranslations)
/* harmony export */ });
class Translations {
    constructor() {
        this.CLOSE = ['إغلاق', 'Close'];
        this.PAGE_TITLE = ['بحث', 'Search'];
    }
}
const SearchTranslations = new Translations();


/***/ }),

/***/ 51929:
/*!************************************************************************!*\
  !*** ./src/app/pages/watchlists/edit/watchlist-edit-routing.module.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchlistEditPageRoutingModule": () => (/* binding */ WatchlistEditPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _watchlist_edit_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlist-edit.page */ 4990);




const routes = [
    {
        path: '',
        component: _watchlist_edit_page__WEBPACK_IMPORTED_MODULE_0__.WatchlistEditPage
    }
];
let WatchlistEditPageRoutingModule = class WatchlistEditPageRoutingModule {
};
WatchlistEditPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], WatchlistEditPageRoutingModule);



/***/ }),

/***/ 7792:
/*!****************************************************************!*\
  !*** ./src/app/pages/watchlists/edit/watchlist-edit.module.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchlistEditPageModule": () => (/* binding */ WatchlistEditPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _watchlist_edit_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlist-edit-routing.module */ 51929);
/* harmony import */ var _watchlist_edit_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./watchlist-edit.page */ 4990);








let WatchlistEditPageModule = class WatchlistEditPageModule {
};
WatchlistEditPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _watchlist_edit_routing_module__WEBPACK_IMPORTED_MODULE_0__.WatchlistEditPageRoutingModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__.TranslateModule.forChild(),
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule
        ],
        declarations: [_watchlist_edit_page__WEBPACK_IMPORTED_MODULE_1__.WatchlistEditPage]
    })
], WatchlistEditPageModule);



/***/ }),

/***/ 4990:
/*!**************************************************************!*\
  !*** ./src/app/pages/watchlists/edit/watchlist-edit.page.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchlistEditPage": () => (/* binding */ WatchlistEditPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _watchlist_edit_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlist-edit.page.html?ngResource */ 23958);
/* harmony import */ var _watchlist_edit_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./watchlist-edit.page.scss?ngResource */ 4788);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/animations */ 17329);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _inma_models_watchlist__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/models/watchlist */ 12059);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _common_ui_components_search_search_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../common-ui-components/search/search.page */ 5535);










let WatchlistEditPage = class WatchlistEditPage {
    constructor(formBuilder, route, modalCtrl) {
        this.formBuilder = formBuilder;
        this.route = route;
        this.modalCtrl = modalCtrl;
        this.savedSuccessfully = false;
        this.buildForm();
    }
    ngOnInit() {
        this.route.params.subscribe(params => {
            if (params === null || params === void 0 ? void 0 : params.id) {
                _inma_models_watchlist__WEBPACK_IMPORTED_MODULE_2__.Watchlists.findByID(params === null || params === void 0 ? void 0 : params.id).subscribe(watchlist => {
                    this.watchlist = watchlist;
                });
            }
            else {
                this.watchlist = new _inma_models_watchlist__WEBPACK_IMPORTED_MODULE_2__.Watchlist();
            }
        });
    }
    add() {
        this.openModal();
    }
    delete(symbol) {
        this.watchlist.delete(symbol);
    }
    save() {
        var _a;
        if (this.form.valid) {
            if ((_a = this.watchlist) === null || _a === void 0 ? void 0 : _a.id) {
                this.watchlist.update().subscribe(() => {
                    this.savedSuccessfully = true;
                });
            }
            else {
                this.watchlist.create().subscribe(() => {
                    this.savedSuccessfully = true;
                });
            }
        }
    }
    buildForm() {
        this.form = this.formBuilder.group({
            name: [
                '', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required
                ])
            ]
        });
    }
    //#endregion
    openModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _common_ui_components_search_search_page__WEBPACK_IMPORTED_MODULE_3__.SearchPage
            });
            modal.present();
            const { data } = yield modal.onWillDismiss();
            if (data)
                this.watchlist.addSymbol(data);
        });
    }
};
WatchlistEditPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.ActivatedRoute },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController }
];
WatchlistEditPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-watchlist',
        template: _watchlist_edit_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        animations: [
            // nice stagger effect when showing existing elements
            (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.trigger)('list', [
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.transition)(':enter', [
                    // child animation selector + stagger
                    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.query)('@items', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.stagger)(50, (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.animateChild)()), { optional: true })
                ]),
            ]),
            (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.trigger)('items', [
                // cubic-bezier for a tiny bouncing feel
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.transition)(':enter', [
                    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({ opacity: 0 }),
                    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.animate)('1s ease-in-out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({ opacity: 1 }))
                ]),
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.transition)(':leave', [
                    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({ opacity: 1, height: '*' }),
                    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.animate)('0.5s ease-in-out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({ opacity: 0, height: '0px', margin: '0px' }))
                ])
            ])
        ],
        styles: [_watchlist_edit_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder, _angular_router__WEBPACK_IMPORTED_MODULE_6__.ActivatedRoute, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController])
], WatchlistEditPage);



/***/ }),

/***/ 49802:
/*!*************************************************************************!*\
  !*** ./src/app/common-ui-components/search/search.page.scss?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "ion-toolbar {\n  --color: white;\n  --background: #005157;\n}\nion-toolbar ion-searchbar {\n  --color: #65979a;\n  --icon-color: #65979a;\n  --background: #e6eff0;\n  --border-radius: 0;\n}\nbody.dark :host ion-toolbar ion-searchbar {\n  --color: white;\n  --icon-color: white;\n  border: 1px solid white;\n  height: 36px;\n  padding-top: 10px;\n}\nion-toolbar #close-button {\n  --color: #e6eff0;\n  font-size: 100%;\n}\n.searchbar-input {\n  border: 1px solid white;\n}\n.symbol-id {\n  font-weight: normal;\n  border: 1px solid #e6eff0;\n  padding: 0 2px;\n  width: 36px;\n  font-weight: bold;\n  text-align: center;\n}\n:host ion-item {\n  --color: #005457;\n  font-size: 12px;\n  --border-color: transparent;\n}\nbody.dark :host ion-item {\n  --color: #a5a5a5;\n}\n.search-name {\n  -webkit-margin-start: 8px;\n          margin-inline-start: 8px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlYXJjaC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFBO0VBQ0EscUJBQUE7QUFDSjtBQUNJO0VBQ0ksZ0JBQUE7RUFDQSxxQkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7QUFDUjtBQUFRO0VBQ0ksY0FBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7QUFFWjtBQUVJO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0FBQVI7QUFHQTtFQUNJLHVCQUFBO0FBQUo7QUFJQTtFQUNJLG1CQUFBO0VBQ0EseUJBQUE7RUFDQSxjQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUFESjtBQUtJO0VBQ0ksZ0JBQUE7RUFNQSxlQUFBO0VBQ0EsMkJBQUE7QUFQUjtBQUVRO0VBQ0ksZ0JBQUE7QUFBWjtBQVFBO0VBQ0kseUJBQUE7VUFBQSx3QkFBQTtBQUxKIiwiZmlsZSI6InNlYXJjaC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhciB7XG4gICAgLS1jb2xvcjogd2hpdGU7XG4gICAgLS1iYWNrZ3JvdW5kOiAjMDA1MTU3O1xuXG4gICAgaW9uLXNlYXJjaGJhciB7XG4gICAgICAgIC0tY29sb3I6ICM2NTk3OWE7XG4gICAgICAgIC0taWNvbi1jb2xvcjogIzY1OTc5YTtcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjZTZlZmYwO1xuICAgICAgICAtLWJvcmRlci1yYWRpdXM6IDA7XG4gICAgICAgIGJvZHkuZGFyayA6aG9zdCAmIHtcbiAgICAgICAgICAgIC0tY29sb3I6IHdoaXRlO1xuICAgICAgICAgICAgLS1pY29uLWNvbG9yOiB3aGl0ZTtcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHdoaXRlO1xuICAgICAgICAgICAgaGVpZ2h0OiAzNnB4O1xuICAgICAgICAgICAgcGFkZGluZy10b3A6IDEwcHg7XG4gICAgICAgICAgfVxuICAgIH1cblxuICAgICNjbG9zZS1idXR0b24ge1xuICAgICAgICAtLWNvbG9yOiAjZTZlZmYwO1xuICAgICAgICBmb250LXNpemU6IDEwMCU7XG4gICAgfVxufVxuLnNlYXJjaGJhci1pbnB1dHtcbiAgICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcbn1cblxuXG4uc3ltYm9sLWlkIHtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICNlNmVmZjA7XG4gICAgcGFkZGluZzogMCAycHg7XG4gICAgd2lkdGg6IDM2cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG46aG9zdCB7XG4gICAgaW9uLWl0ZW0ge1xuICAgICAgICAtLWNvbG9yOiAjMDA1NDU3O1xuXG4gICAgICAgIGJvZHkuZGFyayAmIHtcbiAgICAgICAgICAgIC0tY29sb3I6ICNhNWE1YTU7XG4gICAgICAgIH1cblxuICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICAgIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgICB9XG59XG5cbi5zZWFyY2gtbmFtZSB7XG4gICAgbWFyZ2luLWlubGluZS1zdGFydDogOHB4O1xufSJdfQ== */";

/***/ }),

/***/ 4788:
/*!***************************************************************************!*\
  !*** ./src/app/pages/watchlists/edit/watchlist-edit.page.scss?ngResource ***!
  \***************************************************************************/
/***/ ((module) => {

module.exports = ":host {\n  height: 100%;\n}\n:host ion-row#header {\n  background: var(--ion-color-tertiary);\n  color: var(--ion-color-primary-txt);\n}\n:host ion-button {\n  --background: #2ebd85;\n  --border-radius: 0;\n}\n:host ion-checkbox {\n  --border-color: 1px solid #91babd;\n}\n:host #list {\n  margin-top: 9px;\n}\n:host #saved-successfully {\n  color: #2ebd85;\n  height: 40px;\n  border: solid 1px #2ebd85;\n  background-color: #deffef;\n  vertical-align: middle;\n  display: flex;\n  align-items: center;\n  margin: 16px;\n  padding: 16px;\n}\n:host #symbol-id {\n  border: 1px solid #e6eff0;\n  min-width: 42px;\n  padding: 2px;\n  min-width: 48px;\n  display: inline-block;\n  text-align: center;\n  margin-top: 2px;\n}\n:host #empty {\n  text-align: center;\n}\n:host #delete {\n  padding-left: 0;\n  padding-right: 0;\n  display: flex;\n  justify-content: flex-end;\n  align-items: center;\n}\n:host #delete ion-button {\n  padding: 0;\n  margin: 0;\n  --padding-start: 0;\n  --padding-end: 0;\n  --padding-top: 0;\n  width: 26px;\n  height: 26px;\n  --border-radius: 0px;\n  --background: #f5455a;\n}\n:host #delete ion-button ion-icon {\n  padding: 6px;\n}\n:host ion-footer {\n  padding: 8px;\n}\n:host .save-row {\n  position: -webkit-sticky;\n  position: sticky;\n  bottom: 0;\n}\n:host #save-button {\n  --background: #005157;\n}\n:host ion-toolbar {\n  --background: #005157;\n  --color: white;\n}\n:host ion-back-button {\n  color: white;\n}\n:host ion-item {\n  --color: var(--ion-color-primary-txt);\n  --border-color: transparent;\n}\n:host #symbols-header {\n  margin-top: 24px;\n  margin-right: 16px;\n  color: var(--ion-color-primary-txt);\n  font-weight: bold;\n  font-size: 14px;\n}\n:host ion-grid {\n  --color: var(--ion-color-primary-txt);\n  padding: 4px 16px;\n  font-size: 10px;\n}\n:host ion-grid ion-row #symbol-id-container {\n  margin: 0;\n  padding: 0;\n}\n:host .abbreviation {\n  font-weight: bold;\n}\n:host .name {\n  color: #83afb4;\n}\n:host #save-container {\n  margin: 0;\n  padding: 0;\n}\n:host #save-container ion-button {\n  margin: 0;\n  padding: 0;\n  margin-top: 9px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndhdGNobGlzdC1lZGl0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQUE7QUFDRjtBQUFFO0VBRUUscUNBQUE7RUFFQSxtQ0FBQTtBQUFKO0FBRUU7RUFDRSxxQkFBQTtFQUNBLGtCQUFBO0FBQUo7QUFHRTtFQUNFLGlDQUFBO0FBREo7QUFJRTtFQUNFLGVBQUE7QUFGSjtBQUtFO0VBQ0UsY0FBQTtFQUNBLFlBQUE7RUFDQSx5QkFBQTtFQUNBLHlCQUFBO0VBQ0Esc0JBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtBQUhKO0FBTUU7RUFDRSx5QkFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBSko7QUFPRTtFQUNFLGtCQUFBO0FBTEo7QUFRRTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUVBLGFBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0FBUEo7QUFRSTtFQUVFLFVBQUE7RUFDQSxTQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtFQUNBLHFCQUFBO0FBUE47QUFTTTtFQUNFLFlBQUE7QUFQUjtBQVlFO0VBR0UsWUFBQTtBQVpKO0FBZUU7RUFDRSx3QkFBQTtFQUFBLGdCQUFBO0VBQ0EsU0FBQTtBQWJKO0FBZ0JFO0VBQ0UscUJBQUE7QUFkSjtBQWlCRTtFQUNFLHFCQUFBO0VBQ0EsY0FBQTtBQWZKO0FBa0JFO0VBQ0UsWUFBQTtBQWhCSjtBQW1CRTtFQUVFLHFDQUFBO0VBQ0EsMkJBQUE7QUFsQko7QUFxQkU7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0VBRUEsbUNBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7QUFwQko7QUF1QkU7RUFFRSxxQ0FBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtBQXRCSjtBQXdCTTtFQUNFLFNBQUE7RUFDQSxVQUFBO0FBdEJSO0FBMkJFO0VBQ0UsaUJBQUE7QUF6Qko7QUE0QkU7RUFDRSxjQUFBO0FBMUJKO0FBNkJFO0VBQ0UsU0FBQTtFQUNBLFVBQUE7QUEzQko7QUE0Qkk7RUFDRSxTQUFBO0VBQ0EsVUFBQTtFQUNBLGVBQUE7QUExQk4iLCJmaWxlIjoid2F0Y2hsaXN0LWVkaXQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xuICBoZWlnaHQ6IDEwMCU7XG4gIGlvbi1yb3cjaGVhZGVyIHtcbiAgICAvLyBiYWNrZ3JvdW5kOiAjZTZlZmYwO1xuICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci10ZXJ0aWFyeSk7XG4gICAgLy8gY29sb3I6ICM4M2FmYjQ7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXR4dCk7XG4gIH1cbiAgaW9uLWJ1dHRvbiB7XG4gICAgLS1iYWNrZ3JvdW5kOiAjMmViZDg1O1xuICAgIC0tYm9yZGVyLXJhZGl1czogMDtcbiAgfVxuXG4gIGlvbi1jaGVja2JveCB7XG4gICAgLS1ib3JkZXItY29sb3I6IDFweCBzb2xpZCAjOTFiYWJkO1xuICB9XG5cbiAgI2xpc3Qge1xuICAgIG1hcmdpbi10b3A6IDlweDtcbiAgfVxuXG4gICNzYXZlZC1zdWNjZXNzZnVsbHkge1xuICAgIGNvbG9yOiAjMmViZDg1O1xuICAgIGhlaWdodDogNDBweDtcbiAgICBib3JkZXI6IHNvbGlkIDFweCAjMmViZDg1O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNkZWZmZWY7XG4gICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgbWFyZ2luOiAxNnB4O1xuICAgIHBhZGRpbmc6IDE2cHg7XG4gIH1cblxuICAjc3ltYm9sLWlkIHtcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZTZlZmYwO1xuICAgIG1pbi13aWR0aDogNDJweDtcbiAgICBwYWRkaW5nOiAycHg7XG4gICAgbWluLXdpZHRoOiA0OHB4O1xuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgbWFyZ2luLXRvcDogMnB4O1xuICB9XG5cbiAgI2VtcHR5IHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIH1cblxuICAjZGVsZXRlIHtcbiAgICBwYWRkaW5nLWxlZnQ6IDA7XG4gICAgcGFkZGluZy1yaWdodDogMDtcblxuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGlvbi1idXR0b24ge1xuICAgICAgLy8gQGluY2x1ZGUgZmxvYXQoZW5kKTtcbiAgICAgIHBhZGRpbmc6IDA7XG4gICAgICBtYXJnaW46IDA7XG4gICAgICAtLXBhZGRpbmctc3RhcnQ6IDA7XG4gICAgICAtLXBhZGRpbmctZW5kOiAwO1xuICAgICAgLS1wYWRkaW5nLXRvcDogMDtcbiAgICAgIHdpZHRoOiAyNnB4O1xuICAgICAgaGVpZ2h0OiAyNnB4O1xuICAgICAgLS1ib3JkZXItcmFkaXVzOiAwcHg7XG4gICAgICAtLWJhY2tncm91bmQ6ICNmNTQ1NWE7XG5cbiAgICAgIGlvbi1pY29uIHtcbiAgICAgICAgcGFkZGluZzogNnB4O1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGlvbi1mb290ZXIge1xuICAgIC8vIGJvdHRvbTogMDtcbiAgICAvLyBwb3NpdGlvbjogZml4ZWQ7XG4gICAgcGFkZGluZzogOHB4O1xuICB9XG5cbiAgLnNhdmUtcm93IHtcbiAgICBwb3NpdGlvbjogc3RpY2t5O1xuICAgIGJvdHRvbTogMDtcbiAgfVxuXG4gICNzYXZlLWJ1dHRvbiB7XG4gICAgLS1iYWNrZ3JvdW5kOiAjMDA1MTU3O1xuICB9XG5cbiAgaW9uLXRvb2xiYXIge1xuICAgIC0tYmFja2dyb3VuZDogIzAwNTE1NztcbiAgICAtLWNvbG9yOiB3aGl0ZTtcbiAgfVxuXG4gIGlvbi1iYWNrLWJ1dHRvbiB7XG4gICAgY29sb3I6IHdoaXRlO1xuICB9XG5cbiAgaW9uLWl0ZW0ge1xuICAgIC8vIC0tY29sb3I6ICMwMDU0NTc7XG4gICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktdHh0KTtcbiAgICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gIH1cblxuICAjc3ltYm9scy1oZWFkZXIge1xuICAgIG1hcmdpbi10b3A6IDI0cHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAxNnB4O1xuICAgIC8vIGNvbG9yOiAjMDA1NDU3O1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS10eHQpO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgfVxuXG4gIGlvbi1ncmlkIHtcbiAgICAvLyBjb2xvcjogIzAwNTQ1NztcbiAgICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS10eHQpO1xuICAgIHBhZGRpbmc6IDRweCAxNnB4O1xuICAgIGZvbnQtc2l6ZTogMTBweDtcbiAgICBpb24tcm93IHtcbiAgICAgICNzeW1ib2wtaWQtY29udGFpbmVyIHtcbiAgICAgICAgbWFyZ2luOiAwO1xuICAgICAgICBwYWRkaW5nOiAwO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC5hYmJyZXZpYXRpb24ge1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICB9XG5cbiAgLm5hbWUge1xuICAgIGNvbG9yOiAjODNhZmI0O1xuICB9XG5cbiAgI3NhdmUtY29udGFpbmVyIHtcbiAgICBtYXJnaW46IDA7XG4gICAgcGFkZGluZzogMDtcbiAgICBpb24tYnV0dG9uIHtcbiAgICAgIG1hcmdpbjogMDtcbiAgICAgIHBhZGRpbmc6IDA7XG4gICAgICBtYXJnaW4tdG9wOiA5cHg7XG4gICAgfVxuICB9XG59XG4iXX0= */";

/***/ }),

/***/ 47494:
/*!*************************************************************************!*\
  !*** ./src/app/common-ui-components/search/search.page.html?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "<!-- <ion-header>\n  <ion-toolbar>\n    <ion-title>search</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n</ion-content> -->\n\n\n<ion-header>\n  <ion-toolbar [style.--background]=\"color\">\n    <ion-grid>\n      <ion-row>\n        <ion-col>\n          <ion-title>{{ title || t.PAGE_TITLE }}</ion-title>\n          <ion-buttons end>\n            <!-- <button ion-button class=\"close\" (click)=\"dismiss()\">{{ t.CLOSE }}</button> -->\n            <ion-button (click)=\"dismiss()\" id='close-button'>{{ t.CLOSE }}</ion-button>\n          </ion-buttons>\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col>\n        <ion-searchbar [(ngModel)]=\"queryText\" (ngModelChange)=\"filter()\" [placeholder]=\" t.PAGE_TITLE \">\n        </ion-searchbar>\n      </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n\n  <ion-list>\n    <ion-item (click)=\"select(searchable)\" *ngFor=\"let searchable of searchables\">\n      <span class=\"symbol-id\"> {{ searchable?.id }} </span>\n      <span class=\"search-name\">\n        {{ searchable?.name | async }}\n      </span>\n    </ion-item>\n  </ion-list>\n</ion-content>";

/***/ }),

/***/ 23958:
/*!***************************************************************************!*\
  !*** ./src/app/pages/watchlists/edit/watchlist-edit.page.html?ngResource ***!
  \***************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button [text]=\"''\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{ 'watchlist.PAGE_TITLE' | translate }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n\n  <div *ngIf=\"savedSuccessfully\" id='saved-successfully'>\n    {{ 'watchlist.SAVED_SUCCESSFULLY' | translate }}\n  </div>\n\n  <ion-item>\n    <ion-label position='stacked'>{{ 'watchlist.NAME' | translate }}</ion-label>\n    <ion-input type=\"text\" maxlength=\"25\" [formControl]=\"form.controls.name\" [(ngModel)]=\"watchlist.name\"></ion-input>\n    <!-- TODO: VALIDATION -->\n  </ion-item>\n\n  <ion-item mode='md'>\n    <ion-label>{{ 'watchlist.IS_DEFAULT' | translate }}</ion-label>\n    <ion-checkbox [(ngModel)]=\"watchlist.isDefault\"></ion-checkbox>\n  </ion-item>\n\n  <div id='symbols-header'>\n    {{ 'watchlist.SYMBOLS' | translate }}\n  </div>\n\n  <!-- symbols -->\n  <ion-grid>\n    <!-- header -->\n    <ion-row id='header'>\n      <ion-col size=\"2\">\n        {{ 'watchlist.SYMBOL_ID' | translate }}\n      </ion-col>\n      <ion-col>\n        {{ 'watchlist.SYMBOL_NAME' | translate }}\n      </ion-col>\n      <ion-col size='2'>\n\n      </ion-col>\n    </ion-row>\n    <!--// -->\n\n    <!-- symbols -->\n    <div id='list' @list>\n      <ion-row @items *ngFor=\"let s of watchlist?.symbols | async\">\n        <ion-col size='2' id='symbol-id-container'>\n          <span id='symbol-id'>\n            {{s.id}}\n          </span>\n        </ion-col>\n        <ion-col>\n          <span class='abbreviation'>\n            {{ s.abbreviation | async }}\n          </span>\n          <div class='name' *ngIf=\"(s.name | async) != (s.abbreviation | async)\">\n            {{ s.name | async }}\n          </div>\n        </ion-col>\n        <ion-col id='delete' size='2' (click)='delete(s)'>\n\n          <ion-button>\n            <ion-icon src='assets/icon/delete.svg'></ion-icon>\n          </ion-button>\n\n        </ion-col>\n      </ion-row>\n\n      <!-- ifEmpty -->\n      <ion-row id='empty' @items *ngIf=\"!(watchlist?.symbols | async)?.length\">\n        <ion-col>\n\n          {{ 'watchlist.EMPTY_SYMBOLS_EDIT' | translate }}\n\n        </ion-col>\n      </ion-row>\n      <!--// -->\n    </div>\n    <!--// -->\n\n\n    \n\n\n  </ion-grid>\n\n  <!--// -->\n\n\n  \n</ion-content>\n<!-- For a reason, ion-footer does not work ! -->\n<ion-footer>\n  <!-- Add Symbols -->\n  <!-- <ion-row class=\"save-row\"> -->\n      <!-- <ion-col id='save-container'> -->\n        <ion-button expand=\"block\" (click)=\"add()\">\n          {{ 'watchlist.ADD_SYMBOLS' | translate }}\n        </ion-button>\n      <!-- </ion-col>\n    </ion-row> -->\n    <!--// -->\n\n  <ion-button id='save-button' expand=\"block\" (click)=\"save()\">\n    {{ 'watchlist.SAVE' | translate }}\n  </ion-button>\n\n</ion-footer>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_watchlists_edit_watchlist-edit_module_ts.js.map