import { createAnimation } from "@ionic/angular";

export const fadeEnterAnimation = (baseEl: any) => {
    const backdropAnimation = createAnimation()
      .addElement(baseEl.querySelector('ion-backdrop')!)
      .fromTo('opacity', '0', '0');

    const wrapperAnimation = createAnimation()
      .addElement(baseEl.querySelector('.modal-wrapper')!)
      .keyframes([
        { offset: 0, opacity: '0', transform: 'scale(1)' },
        { offset: 1, opacity: '1', transform: 'scale(1)' }
      ]);

        baseEl.classList.add('fade-enter-animation-container')    
      


    //   const backgroundAnimation = createAnimation()
    //   .addElement(baseEl.querySelector('ion-modal')!)
    //   .keyframes([
    //     { offset: 0, opacity: '1', transform: 'scale(0)', 'backdrop-filter': 'blur(10px)' },
    //     { offset: 1, opacity: '1', transform: 'scale(1)', 'backdrop-filter': 'blur(10px)' }
    //   ]);
      
    return createAnimation()
      .addElement(baseEl)
      .easing('ease-in-out')
      .duration(500)
      .addAnimation([backdropAnimation, wrapperAnimation]);
  }

  export const fadeLeaveAnimation = (baseEl: any) => {
    return fadeEnterAnimation(baseEl).direction('reverse');
  }