class Translations {
  PORTFOLIO_COST = ["تكلفة المحفظة", "Portfolio Cost"];
}

export const ChartTranslations = new Translations();
