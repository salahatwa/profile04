import { OpenAccountStepHeaderComponent } from './open-account-step-header/open-account-step-header.component';
import { TranslateModule } from '@ngx-translate/core';
import { PortfolioInfoCardComponent } from 'src/app/pages/portfolios/portfolio-info-card/portfolio-info-card.component';
import { SkeletonLoaderComponent } from './skeleton-loader/skeleton-loader.component';
import { SymbolCardComponent } from './symbol-card/symbol-card.component';
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { MarketValueComponent } from './market-value/market-value.component';
import { ExpandableComponent } from './expandable/expandable.component';
import { ChangableValueBoxComponent } from './changable-value-box/changable-value-box.component';
import { CommonSegmentGroupComponent } from './common-segment-group/common-segment-group.component';
import { SliderPagerComponent } from './slider-pager/slider-pager.component';
import { PortfolioComponent } from './portfolio/portfolio.component';
import { CollapsibleListComponent } from './collapsible-list/collapsible-list.component';
import { StockQuickViewComponent } from './stok-quick-view/stock-quick-view.component';
import { GridHeaderComponent } from './grid-header/grid-header.component';
import { ButtonComponent } from './button/button.component';
import { InputComponent } from './input/input.component';
import { EmptyStateComponent } from './empty-state/empty-state.component';
import { ProductBoxComponent } from './product-box/product-box.component'
import { CustomeSelectComponent } from './custome-select/custome-select.component';
import { ShareModalComponent } from './share-modal/share-modal.component'
import { ChartComponent } from '../chart/chart.component';
import { ChartComponentModule } from '../chart/chart.component.module';
import { LoaderComponent } from './loader/loader.component';
import { SymbolsComponent } from './symbols/symbols.component';
import { PipesModule } from '../pipes/pipes.module';
import { InternetDisconnectedComponent } from './internet-disconnected/internet-disconnected.component';
import { SymbolSwiperComponent } from '../pages/tradestation/symbol-swiper/symbol-swiper.component';
import { SymbolParametersSlideComponent } from '../pages/tradestation/symbol-swiper/symbol-parameters-slide/symbol-parameters-slide.component';
import { SymbolLiquiditySlideComponent } from '../pages/tradestation/symbol-swiper/symbol-liquidity-slide/symbol-liquidity-slide.component';
import { SymbolTradesSlideComponent } from '../pages/tradestation/symbol-swiper/symbol-trades-slide/symbol-trades-slide.component';
import { SymbolBidsAndAsksSlideComponent } from '../pages/tradestation/symbol-swiper/symbol-bids-and-asks-slide/symbol-bids-and-asks-slide.component';
import { SectorsDragableModalComponent } from './sectors-dragable-modal/sectors-dragable-modal.component';
import { MarketsNamesDragableModalComponent } from './markets-names-dragable-modal/markets-names-dragable-modal.component';
import { SymbolsSearchDragableModalComponent } from './symbols-search-dragable-modal/symbols-search-dragable-modal.component';
import { WatchlistDragableModalComponent } from './watchlist-dragable-modal/watchlist-dragable-modal.component';
import { ViewEditWatclistDragableModalComponent } from './view-edit-watclist-dragable-modal/view-edit-watclist-dragable-modal.component';
import { MarketSubHeaderComponent } from '../pages/tradestation/market-sub-header/market-sub-header.component';


// TODO: Importing this everywhere is not good
@NgModule({
  schemas: [NO_ERRORS_SCHEMA],
  declarations: [
    MarketValueComponent,
    ExpandableComponent,
    ChangableValueBoxComponent,
    CommonSegmentGroupComponent,
    SliderPagerComponent,
    PortfolioComponent,
    StockQuickViewComponent,
    CollapsibleListComponent,
    GridHeaderComponent,
    ButtonComponent,
    InputComponent,
    EmptyStateComponent,
    ProductBoxComponent,
    CustomeSelectComponent,
    ShareModalComponent,
    LoaderComponent,
    SymbolsComponent,
    InternetDisconnectedComponent,
    SectorsDragableModalComponent,
    MarketsNamesDragableModalComponent,
    SymbolsSearchDragableModalComponent,
    WatchlistDragableModalComponent,
    ViewEditWatclistDragableModalComponent,
    SymbolCardComponent,
    SkeletonLoaderComponent,
    MarketSubHeaderComponent,
    PortfolioInfoCardComponent,
    OpenAccountStepHeaderComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    IonicModule,
    ChartComponentModule,
    PipesModule,
    TranslateModule.forChild()
  ],
  exports: [
    MarketValueComponent,
    ExpandableComponent,
    ChangableValueBoxComponent,
    CommonSegmentGroupComponent,
    SliderPagerComponent,
    PortfolioComponent,
    StockQuickViewComponent,
    CollapsibleListComponent,
    GridHeaderComponent,
    ButtonComponent,
    InputComponent,
    EmptyStateComponent,
    ProductBoxComponent,
    ShareModalComponent,
    ChartComponent,
    LoaderComponent,
    SymbolsComponent,
    InternetDisconnectedComponent,
    SectorsDragableModalComponent,
    MarketsNamesDragableModalComponent,
    SymbolsSearchDragableModalComponent,
    WatchlistDragableModalComponent,
    ViewEditWatclistDragableModalComponent,
    SymbolCardComponent,
    SkeletonLoaderComponent,
    MarketSubHeaderComponent,
    PortfolioInfoCardComponent,
    OpenAccountStepHeaderComponent
  ]
})
export class TadawulCommonUiModule { }
