"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_forget-username-password_forgot-username_forgot-username_module_ts"],{

/***/ 46274:
/*!**************************************************************************************************!*\
  !*** ./src/app/pages/forget-username-password/forgot-username/forgot-username-routing.module.ts ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgotUsernamePageRoutingModule": () => (/* binding */ ForgotUsernamePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _forgot_username_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forgot-username.page */ 43597);




const routes = [
    {
        path: '',
        component: _forgot_username_page__WEBPACK_IMPORTED_MODULE_0__.ForgotUsernamePage
    }
];
let ForgotUsernamePageRoutingModule = class ForgotUsernamePageRoutingModule {
};
ForgotUsernamePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ForgotUsernamePageRoutingModule);



/***/ }),

/***/ 31922:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/forget-username-password/forgot-username/forgot-username.module.ts ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgotUsernamePageModule": () => (/* binding */ ForgotUsernamePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _forgot_username_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forgot-username-routing.module */ 46274);
/* harmony import */ var _forgot_username_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./forgot-username.page */ 43597);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);









let ForgotUsernamePageModule = class ForgotUsernamePageModule {
};
ForgotUsernamePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _forgot_username_routing_module__WEBPACK_IMPORTED_MODULE_0__.ForgotUsernamePageRoutingModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateModule.forChild()
        ],
        declarations: [_forgot_username_page__WEBPACK_IMPORTED_MODULE_1__.ForgotUsernamePage]
    })
], ForgotUsernamePageModule);



/***/ }),

/***/ 43597:
/*!****************************************************************************************!*\
  !*** ./src/app/pages/forget-username-password/forgot-username/forgot-username.page.ts ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgotUsernamePage": () => (/* binding */ ForgotUsernamePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _forgot_username_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forgot-username.page.html?ngResource */ 17168);
/* harmony import */ var _forgot_username_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./forgot-username.page.scss?ngResource */ 65554);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _inma_models_forget_user_pass__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/models/forget-user-pass */ 90957);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);









let ForgotUsernamePage = class ForgotUsernamePage {
    constructor(formBuilder, translate, alertController, navCtrl) {
        this.formBuilder = formBuilder;
        this.translate = translate;
        this.alertController = alertController;
        this.navCtrl = navCtrl;
        this.formData = {
            idType: '',
            accountNumber: ''
        };
        this.buildForm();
    }
    buildForm() {
        this.form = this.formBuilder.group({
            idType: [
                '', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.minLength(10),
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.maxLength(10)
                ])
            ],
            accountNumber: [
                '', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.minLength(12),
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.maxLength(12)
                ])
            ],
        });
    }
    ngOnInit() {
    }
    retrieve(form) {
        console.log(form);
        if (form.invalid) {
            return;
        }
        _inma_models_forget_user_pass__WEBPACK_IMPORTED_MODULE_2__.forget.forgetUsername(this.formData.idType, this.formData.accountNumber).subscribe(res => {
            console.log(res);
            console.log(res.loginName);
            this.presentUsername(res);
            this.navCtrl.navigateRoot('login', { animated: true });
        });
    }
    presentUsername(res) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: this.translate.instant('forgot.USERNAME'),
                message: res.loginName,
                buttons: [this.translate.instant('forgot.OK')]
            });
            yield alert.present();
        });
    }
};
ForgotUsernamePage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormBuilder },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslateService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController }
];
ForgotUsernamePage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'tadawul-forgot-username',
        template: _forgot_username_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_forgot_username_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__metadata)("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormBuilder, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslateService, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController])
], ForgotUsernamePage);



/***/ }),

/***/ 65554:
/*!*****************************************************************************************************!*\
  !*** ./src/app/pages/forget-username-password/forgot-username/forgot-username.page.scss?ngResource ***!
  \*****************************************************************************************************/
/***/ ((module) => {

module.exports = "ion-toolbar {\n  --background: #005157;\n  color: #fff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZvcmdvdC11c2VybmFtZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxxQkFBQTtFQUNBLFdBQUE7QUFDSiIsImZpbGUiOiJmb3Jnb3QtdXNlcm5hbWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXIge1xuICAgIC0tYmFja2dyb3VuZDogIzAwNTE1NztcbiAgICBjb2xvcjogI2ZmZjtcbiAgfSJdfQ== */";

/***/ }),

/***/ 17168:
/*!*****************************************************************************************************!*\
  !*** ./src/app/pages/forget-username-password/forgot-username/forgot-username.page.html?ngResource ***!
  \*****************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button [text]=\"''\"></ion-back-button>\n    </ion-buttons>\n    <ion-title slot=\"start\">{{'forgot.FORGOT_USERNAME' | translate}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n    <form [formGroup]=\"form\" (ngSubmit)=\"retrieve(form)\">\n      <ion-text>\n          {{'forgot.FORGOT_USERNAME_MESSAGE_NOTICE' | translate}}\n      </ion-text>\n\n      <app-input [form]=\"form\" [label]=\"'forgot.ID_TYPE' | translate\" [formControl]=\"form.controls.idType\" name=\"idType\" type=\"number\" [(model)]=\"formData.idType\" layout=\"2\" ngDefaultControl></app-input>\n      \n      <app-input [form]=\"form\" [label]=\"'forgot.ACCOUNT_NUMBER' | translate\" [formControl]=\"form.controls.accountNumber\" name=\"accountNumber\" type=\"number\" [(model)]=\"formData.accountNumber\" layout=\"2\" ngDefaultControl></app-input>\n    \n    \n      <app-button \n        [disabled]=\"!form.valid\" \n        expand=\"block\" \n        size=\"\"\n        color=\"success\"\n        fill=\"solid\"\n        shape=\"\"\n        type=\"submit\"\n        >\n        {{'forgot.RETRIEVE' | translate}}\n      </app-button>\n    </form>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_forget-username-password_forgot-username_forgot-username_module_ts.js.map