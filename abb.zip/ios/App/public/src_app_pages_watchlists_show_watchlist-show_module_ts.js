"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_watchlists_show_watchlist-show_module_ts"],{

/***/ 87469:
/*!************************************************************************!*\
  !*** ./src/app/pages/watchlists/show/watchlist-show-routing.module.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchlistShowPageRoutingModule": () => (/* binding */ WatchlistShowPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _watchlist_show_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlist-show.page */ 16579);




const routes = [
    {
        path: '',
        component: _watchlist_show_page__WEBPACK_IMPORTED_MODULE_0__.WatchlistShowPage
    }
];
let WatchlistShowPageRoutingModule = class WatchlistShowPageRoutingModule {
};
WatchlistShowPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], WatchlistShowPageRoutingModule);



/***/ }),

/***/ 76004:
/*!****************************************************************!*\
  !*** ./src/app/pages/watchlists/show/watchlist-show.module.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchlistShowPageModule": () => (/* binding */ WatchlistShowPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _watchlist_show_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlist-show-routing.module */ 87469);
/* harmony import */ var _watchlist_show_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./watchlist-show.page */ 16579);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);
/* harmony import */ var _tradestation_symbol_swiper_symbol_swiper_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../tradestation/symbol-swiper/symbol-swiper.module */ 69554);










let WatchlistShowPageModule = class WatchlistShowPageModule {
};
WatchlistShowPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _watchlist_show_routing_module__WEBPACK_IMPORTED_MODULE_0__.WatchlistShowPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.ReactiveFormsModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateModule.forChild(),
            _tradestation_symbol_swiper_symbol_swiper_module__WEBPACK_IMPORTED_MODULE_3__.SymbolSwiperModule
        ],
        declarations: [
            _watchlist_show_page__WEBPACK_IMPORTED_MODULE_1__.WatchlistShowPage
        ]
    })
], WatchlistShowPageModule);



/***/ }),

/***/ 16579:
/*!**************************************************************!*\
  !*** ./src/app/pages/watchlists/show/watchlist-show.page.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SymbolColor": () => (/* binding */ SymbolColor),
/* harmony export */   "WatchlistShowPage": () => (/* binding */ WatchlistShowPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _watchlist_show_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlist-show.page.html?ngResource */ 12607);
/* harmony import */ var _watchlist_show_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./watchlist-show.page.scss?ngResource */ 44425);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_models_watchlist__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/models/watchlist */ 12059);
/* harmony import */ var _inma_models_symbol__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/models/symbol */ 61202);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/animations */ 17329);
/* harmony import */ var _app_app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../app/app.component */ 20721);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _inma_helpers_debounced__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @inma/helpers/debounced */ 23752);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @capacitor/core */ 26549);
/* harmony import */ var _capacitor_keyboard__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @capacitor/keyboard */ 10523);







var SymbolColor;
(function (SymbolColor) {
    SymbolColor["Loading"] = "#B4B0B0";
    SymbolColor["Safe"] = "#C0CE00";
    SymbolColor["Danger"] = "#F93F03";
    SymbolColor["Neutral"] = "#005457";
})(SymbolColor || (SymbolColor = {}));









let WatchlistShowPage = class WatchlistShowPage {
    constructor(formBuilder, route, sharedData, navCtrl, platform) {
        this.formBuilder = formBuilder;
        this.route = route;
        this.sharedData = sharedData;
        this.navCtrl = navCtrl;
        this.platform = platform;
        this.Symbols = _inma_models_symbol__WEBPACK_IMPORTED_MODULE_3__.Symbols;
        this.keyboardVisible = false;
        //#endregion
        this.SymbolColor = SymbolColor;
        this.buildForm();
    }
    onClose() {
        this.symbol = null;
    }
    ngOnInit() {
        this.platform.pause.subscribe(() => (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            this.symbol = null;
        }));
        this.route.params.subscribe(params => {
            if (params === null || params === void 0 ? void 0 : params.id) {
                (this.isSector ? _inma_models_watchlist__WEBPACK_IMPORTED_MODULE_2__.Watchlists.findSectorByID(params === null || params === void 0 ? void 0 : params.id) : _inma_models_watchlist__WEBPACK_IMPORTED_MODULE_2__.Watchlists.findByID(params === null || params === void 0 ? void 0 : params.id)).subscribe(watchlist => {
                    var _a;
                    this.watchlist = watchlist;
                    (_a = this.watchlist) === null || _a === void 0 ? void 0 : _a.symbols.subscribe((symbols) => {
                        this.symbols = symbols;
                    });
                });
            }
            else {
                this.watchlist = new _inma_models_watchlist__WEBPACK_IMPORTED_MODULE_2__.Watchlist();
            }
        });
        if (_capacitor_core__WEBPACK_IMPORTED_MODULE_7__.Capacitor.isPluginAvailable("Keyboard")) {
            _capacitor_keyboard__WEBPACK_IMPORTED_MODULE_8__.Keyboard.addListener("keyboardWillShow", (info) => {
                this.keyboardVisible = true;
                this.symbol = null;
            });
            _capacitor_keyboard__WEBPACK_IMPORTED_MODULE_8__.Keyboard.addListener("keyboardWillHide", () => {
                this.keyboardVisible = false;
                setTimeout(() => {
                    window.dispatchEvent(new Event("resize"));
                }, 250);
            });
        }
    }
    filter(query) {
        _inma_models_symbol__WEBPACK_IMPORTED_MODULE_3__.Symbols.filter(query, this.watchlist.symbols).subscribe(symbols => {
            this.symbols = symbols;
        });
    }
    add() {
        _inma_models_symbol__WEBPACK_IMPORTED_MODULE_3__.Symbols.all.subscribe((symbols) => {
            this.watchlist.addSymbol(symbols[parseInt((Math.random() * symbols.length).toString())].id);
        });
    }
    delete(symbol) {
        this.watchlist.delete(symbol);
    }
    save() {
        if (this.form.valid)
            this.watchlist.update();
    }
    buildForm() {
        this.form = this.formBuilder.group({
            name: [
                '', _angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.required
                ])
            ]
        });
    }
    getColor(s) {
        // TODO: Symbol color update
        return s.state === _inma_models_symbol__WEBPACK_IMPORTED_MODULE_3__.SymbolState.Unknown ? SymbolColor.Loading : (s.state === _inma_models_symbol__WEBPACK_IMPORTED_MODULE_3__.SymbolState.Down) ? SymbolColor.Danger : SymbolColor.Safe;
    }
    get isSector() {
        return _app_app_component__WEBPACK_IMPORTED_MODULE_4__.App.isActive('/sectors/show');
    }
    get isWatchlist() {
        return !this.isSector;
    }
    openSymbol(symbol) {
        this.symbol = symbol;
        // this.sharedData.setSharedData({symbol}, 'sharedSymbol');
        // this.navCtrl.navigateForward('symbol', { animated: true });
    }
};
WatchlistShowPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormBuilder },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_11__.ActivatedRoute },
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_6__.SharedDataService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.Platform }
];
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_inma_helpers_debounced__WEBPACK_IMPORTED_MODULE_5__.debounced)(250),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", Function),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", [Object]),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:returntype", void 0)
], WatchlistShowPage.prototype, "filter", null);
WatchlistShowPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.Component)({
        selector: 'app-watchlist',
        template: _watchlist_show_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        animations: [
            // nice stagger effect when showing existing elements
            (0,_angular_animations__WEBPACK_IMPORTED_MODULE_14__.trigger)('list', [
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_14__.transition)(':enter', [
                    // child animation selector + stagger
                    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_14__.query)('@items', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_14__.stagger)(25, (0,_angular_animations__WEBPACK_IMPORTED_MODULE_14__.animateChild)()), { optional: true })
                ]),
            ]),
            (0,_angular_animations__WEBPACK_IMPORTED_MODULE_14__.trigger)('items', [
                // cubic-bezier for a tiny bouncing feel
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_14__.transition)(':enter', [
                    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_14__.style)({ opacity: 0 }),
                    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_14__.animate)('1s ease-in-out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_14__.style)({ opacity: 1 }))
                ]),
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_14__.transition)(':leave', [
                    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_14__.style)({ opacity: 1, height: '*' }),
                    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_14__.animate)('0.5s ease-in-out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_14__.style)({ opacity: 0, height: '0px', margin: '0px' }))
                ])
            ])
        ],
        styles: [_watchlist_show_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormBuilder, _angular_router__WEBPACK_IMPORTED_MODULE_11__.ActivatedRoute, src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_6__.SharedDataService, _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.NavController, _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.Platform])
], WatchlistShowPage);



/***/ }),

/***/ 44425:
/*!***************************************************************************!*\
  !*** ./src/app/pages/watchlists/show/watchlist-show.page.scss?ngResource ***!
  \***************************************************************************/
/***/ ((module) => {

module.exports = ":host {\n  height: 100%;\n}\n:host ion-row#header {\n  background: #e6eff0;\n  color: #83afb4;\n  height: 28px;\n}\n:host ion-row#header ion-col {\n  font-size: 8px !important;\n  color: #65979a;\n  font-weight: normal;\n}\n:host #symbols-grid {\n  padding: 5px 0;\n}\n:host ion-col {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 10px;\n  text-align: center;\n  flex-direction: column;\n  color: #005457;\n  font-weight: bold;\n}\n:host ion-col .sub {\n  font-size: 80%;\n  direction: ltr;\n  font-weight: normal;\n}\n:host ion-fab {\n  left: 16px;\n  bottom: 16px;\n}\n:host ion-searchbar {\n  --background: var(--ion-color-tertiary);\n  --color: var(--ion-color-primary-txt);\n  --icon-color: var(--ion-color-primary-txt);\n  padding: 0;\n  height: 32px;\n  border: 1px solid #e6eff0;\n  --background: transparent;\n}\n:host ion-button {\n  --border-radius: 0;\n  --background: var(--ion-color-tertiary);\n  --background-activated: var(--ion-color-tertiary-shade);\n  --color: var(--ion-color-primary-txt);\n}\n:host #add {\n  font-size: 100%;\n  font-weight: normal;\n  width: 100%;\n}\n:host ion-toolbar {\n  --background: #005157;\n  --color: white;\n}\n:host #symbol-id {\n  font-weight: normal;\n  border: 1px solid #e6eff0;\n  padding: 0 2px;\n  width: 36px;\n}\n:host ion-back-button {\n  color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndhdGNobGlzdC1zaG93LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQUE7QUFDRjtBQUFFO0VBQ0UsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtBQUVKO0FBREk7RUFDRSx5QkFBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtBQUdOO0FBQ0U7RUFDRSxjQUFBO0FBQ0o7QUFFRTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUFBSjtBQUNJO0VBQ0UsY0FBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtBQUNOO0FBR0U7RUFDRSxVQUFBO0VBQ0EsWUFBQTtBQURKO0FBSUU7RUFFRSx1Q0FBQTtFQUVBLHFDQUFBO0VBRUEsMENBQUE7RUFFQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLHlCQUFBO0VBQ0EseUJBQUE7QUFOSjtBQVNFO0VBQ0Usa0JBQUE7RUFDQSx1Q0FBQTtFQUNBLHVEQUFBO0VBQ0EscUNBQUE7QUFQSjtBQVVFO0VBQ0UsZUFBQTtFQUdBLG1CQUFBO0VBQ0EsV0FBQTtBQVZKO0FBYUU7RUFDRSxxQkFBQTtFQUNBLGNBQUE7QUFYSjtBQWNFO0VBQ0UsbUJBQUE7RUFDQSx5QkFBQTtFQUNBLGNBQUE7RUFDQSxXQUFBO0FBWko7QUFjRTtFQUNFLFlBQUE7QUFaSiIsImZpbGUiOiJ3YXRjaGxpc3Qtc2hvdy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdCB7XG4gIGhlaWdodDogMTAwJTtcbiAgaW9uLXJvdyNoZWFkZXIge1xuICAgIGJhY2tncm91bmQ6ICNlNmVmZjA7XG4gICAgY29sb3I6ICM4M2FmYjQ7XG4gICAgaGVpZ2h0OiAyOHB4O1xuICAgIGlvbi1jb2wge1xuICAgICAgZm9udC1zaXplOiA4cHggIWltcG9ydGFudDtcbiAgICAgIGNvbG9yOiAjNjU5NzlhO1xuICAgICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICB9XG4gIH1cblxuICAjc3ltYm9scy1ncmlkIHtcbiAgICBwYWRkaW5nOiA1cHggMDtcbiAgfVxuXG4gIGlvbi1jb2wge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICBmb250LXNpemU6IDEwcHg7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgY29sb3I6ICMwMDU0NTc7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgLnN1YiB7XG4gICAgICBmb250LXNpemU6IDgwJTtcbiAgICAgIGRpcmVjdGlvbjogbHRyO1xuICAgICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICB9XG4gIH1cblxuICBpb24tZmFiIHtcbiAgICBsZWZ0OiAxNnB4O1xuICAgIGJvdHRvbTogMTZweDtcbiAgfVxuXG4gIGlvbi1zZWFyY2hiYXIge1xuICAgIC8vIC0tYmFja2dyb3VuZDogI2U2ZWZmMDtcbiAgICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci10ZXJ0aWFyeSk7XG4gICAgLy8gLS1jb2xvcjogIzAwNTE1NztcbiAgICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS10eHQpO1xuICAgIC8vIC0taWNvbi1jb2xvcjogIzAwNTE1NztcbiAgICAtLWljb24tY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXR4dCk7XG5cbiAgICBwYWRkaW5nOiAwO1xuICAgIGhlaWdodDogMzJweDtcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZTZlZmYwO1xuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIH1cblxuICBpb24tYnV0dG9uIHtcbiAgICAtLWJvcmRlci1yYWRpdXM6IDA7XG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItdGVydGlhcnkpO1xuICAgIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6IHZhcigtLWlvbi1jb2xvci10ZXJ0aWFyeS1zaGFkZSk7XG4gICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktdHh0KTtcbiAgfVxuXG4gICNhZGQge1xuICAgIGZvbnQtc2l6ZTogMTAwJTtcbiAgICAvLyAtLWJhY2tncm91bmQ6ICNlNmVmZjA7XG4gICAgLy8gLS1jb2xvcjogIzAwNTE1NztcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIHdpZHRoOiAxMDAlO1xuICB9XG4gIFxuICBpb24tdG9vbGJhciB7XG4gICAgLS1iYWNrZ3JvdW5kOiAjMDA1MTU3O1xuICAgIC0tY29sb3I6IHdoaXRlO1xuICB9XG5cbiAgI3N5bWJvbC1pZCB7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZTZlZmYwO1xuICAgIHBhZGRpbmc6IDAgMnB4O1xuICAgIHdpZHRoOiAzNnB4O1xuICB9XG4gIGlvbi1iYWNrLWJ1dHRvbiB7XG4gICAgY29sb3I6IHdoaXRlO1xuICB9XG59XG4iXX0= */";

/***/ }),

/***/ 12607:
/*!***************************************************************************!*\
  !*** ./src/app/pages/watchlists/show/watchlist-show.page.html?ngResource ***!
  \***************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button [text]=\"''\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{ watchlist?.name }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n\n  <tadawul-symbol-swiper class=\"fadeable\" [symbol]=\"symbol\" [ngClass]=\"{visible: !!symbol}\" (close)=\"onClose()\"></tadawul-symbol-swiper>\n  <tadawul-symbols [allSymbols]=\"symbols\" [hidden]=\"true\" (onSymbolChange)=\"openSymbol($event)\">\n    <ion-col size='4'>\n      <ion-button id='add' [routerLink]=\"['/watchlists/add']\">\n        <ion-icon slot=\"start\" name=\"add-circle-outline\"></ion-icon>\n        {{ 'watchlist.NEW_WATCHLIST' | translate }}\n      </ion-button>\n    </ion-col>\n  </tadawul-symbols>\n\n\n  <!-- editWatchlist -->\n  <ion-fab slot=\"fixed\" *ngIf=\"isWatchlist\">\n    <ion-fab-button [routerLink]=\"['/watchlists/edit', watchlist?.id]\">\n      <ion-icon src='assets/icon/edit.svg'></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n  <!--// -->\n\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_watchlists_show_watchlist-show_module_ts.js.map