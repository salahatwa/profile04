import { TranslateService } from '@ngx-translate/core';
import { Component, OnInit } from '@angular/core';
import { Translations } from '@inma/helpers/translations';
import { forgotTranslations } from '../../forget-username-password/forgot.translations';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { forget } from '@inma/models/forget-user-pass';
import { AlertController } from '@ionic/angular';
import { NavController } from "@ionic/angular";

@Component({
  selector: 'tadawul-change-password',
  templateUrl: './change-password.page.html',
  styleUrls: ['./change-password.page.scss'],
})
export class ChangePasswordPage implements OnInit {

  form: FormGroup;
  formData = {
    token: '',
    newPassword: '',
    confirmNewPassword: '',
  };
  customerTypes;
  isIndividual:boolean = true;
  showLoader = false;

  constructor(private formBuilder: FormBuilder,public translate: TranslateService ,public alertController: AlertController, public navCtrl: NavController) {
    this.buildForm();
  }

  buildForm() {
    this.form = this.formBuilder.group({
      token: [
        '',  Validators.compose([
          Validators.required
        ])
      ],
      newPassword: [
        '', Validators.compose([
          Validators.required,
          Validators.minLength(8),
          Validators.maxLength(16),
          Validators.pattern('[a-zA-Z0-9 ]*')
        ])
      ],
      confirmNewPassword: [
        '', Validators.compose([
          Validators.required,
          Validators.minLength(8),
          Validators.maxLength(16),
          Validators.pattern('[a-zA-Z0-9 ]*')
        ])
      ],
    },
    {validator: this.matchingPasswords('newPassword', 'confirmNewPassword')}
    );
  }

  ngOnInit() {
  }

  retrieve(form) {
    console.log(form);
    if (form.invalid) {
      return;
    }
    this.showLoader = true;
    let token = this.formData.token;
    let newPassword = this.formData.newPassword;

    forget.changePassword(token,newPassword).subscribe(res => {
      
    //  this.showMessage(res);
      this.navCtrl.navigateRoot('');
      this.showLoader = false;
    },
    err => {
      this.showLoader = false;
    }
    );

  }

  matchingPasswords(passwordKey: string, confirmPasswordKey: string) {
    return (group: FormGroup): {[key: string]: any} => {
      let password = group.controls[passwordKey];
      let confirmPassword = group.controls[confirmPasswordKey];

      if (password.value !== confirmPassword.value) {
        return {
          mismatchedPasswords: true
        };
      }
    }
  }

  async showMessage(res) {
    const alert = await this.alertController.create({
      // header: String(this.t.USERNAME),
      message: res.msg.msgText,
      buttons: [this.translate.instant('forgot.OK')]
    });

    await alert.present();
  }

}
