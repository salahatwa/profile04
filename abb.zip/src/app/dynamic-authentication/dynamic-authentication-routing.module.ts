import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DynamicAuthenticationPage } from './dynamic-authentication.page';

const routes: Routes = [
  {
    path: '',
    component: DynamicAuthenticationPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DynamicAuthenticationPageRoutingModule {}
