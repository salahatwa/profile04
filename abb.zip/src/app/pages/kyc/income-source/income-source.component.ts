import { Component, OnInit } from '@angular/core';
import { resetCache } from '@inma/helpers/cached';
import { Dialogs } from '@inma/helpers/dialogs';
import { Languages, Settings } from '@inma/helpers/settings';
import { Translations } from '@inma/helpers/translations';
import { Kyc } from '@inma/models/kyc';
import { NavController } from '@ionic/angular';
import { SharedDataService } from 'src/app/providers/shared-data.service';
import { kycTranslations } from '../kyctranslation';

@Component({
  selector: 'tadawul-income-source',
  templateUrl: './income-source.component.html',
  styleUrls: ['./income-source.component.scss'],
})
export class IncomeSourceComponent implements OnInit {

  @Translations()
  t = kycTranslations;

  Number = Number;
  public selectedTab = "";
  public kycDetail: any;
  public incomeReceiveMethodsList = [];
  public incomeFrequenciesList = [];
  public incomeSourcesList = [];
  public customerIncomeDetails = [];
  public incomeSource: any;
  public amount: any;
  public recieveMethod: any;
  public frequency: any;
  public incomeCount = 0;
  public action = "add";
  public actionText = this.t.add;
  public lang = "ar";
  public showLoader = false;

  constructor(public sharedData: SharedDataService, public navCtrl: NavController) { }

  ngOnInit() {
    this.getSourceIncomeData();
    this.kycDetail = this.sharedData.getSharedData("kycDetail", false);
    this.customerIncomeDetails = this.kycDetail?.incomeSourcesList;
    this.incomeSourceCount();
    if (this.incomeCount == 0) {
      this.selectedTab = "1"
    } else {
      this.selectedTab = "2"
    }

    if (Settings.language == Languages.Arabic) {
      this.lang = "ar"
    } else {
      this.lang = "en"
    }
  }

  incomeSourceCount() {
    for (let i = 0; i < this.customerIncomeDetails?.length; i++) {
      if (this.customerIncomeDetails[i].incomeSourceFlag == true) {
        this.incomeCount += 1;
      }
    }
  }
  switchTabs(tab) {
    this.selectedTab = tab;
    this.action = "add";
    this.incomeSource = null;
    this.amount = null;
    this.recieveMethod = null;
    this.frequency = null;
    this.actionText = this.t.add;
    if (this.incomeCount == 0) {
      this.navCtrl.navigateRoot('/kyc/home', { animated: true });
    }
  }


  getSourceIncomeData() {
    Kyc.detailsIncomeSourcesList.subscribe((incomeSourcesList : any[]) => {
      Kyc.detailsIncomeFrequenciesList.subscribe((incomeFrequenciesList : any[]) => {
        Kyc.detailsIncomeReceiveMethodsList.subscribe((incomeReceiveMethodsList: any[]) => {
          if(incomeReceiveMethodsList[0].code == "") {
            console.log(incomeReceiveMethodsList);
            
            incomeReceiveMethodsList.shift();
          }
          if (incomeFrequenciesList[0].code == "") {
            incomeFrequenciesList.shift();
          }
          this.incomeReceiveMethodsList = incomeReceiveMethodsList;
          this.incomeFrequenciesList = incomeFrequenciesList;
          this.incomeSourcesList = incomeSourcesList;

        });
      });
    });
    // const methods = {
    //   "status": "1",
    //   "msg": {
    //     "msgCode": "I000000",
    //     "msgType": "I",
    //     "msgText": ""
    //   },
    //   "result": [
    //     {
    //       "code": "",
    //       "value": "اختر",
    //       "additionDisplayData": null,
    //       "note": null
    //     },
    //     {
    //       "code": "O",
    //       "value": "أخرى",
    //       "additionDisplayData": "Other - null - null - null - null - null - null - null - null",
    //       "note": null
    //     },
    //     {
    //       "code": "CH",
    //       "value": "شيك",
    //       "additionDisplayData": "Cheque - null - null - null - null - null - null - null - null",
    //       "note": null
    //     },
    //     {
    //       "code": "P",
    //       "value": "كشوف المرتبات",
    //       "additionDisplayData": "Payroll - null - null - null - null - null - null - null - null",
    //       "note": null
    //     },
    //     {
    //       "code": "CA",
    //       "value": "نقدي",
    //       "additionDisplayData": "Cash - null - null - null - null - null - null - null - null",
    //       "note": null
    //     },
    //     {
    //       "code": "T",
    //       "value": "نقل",
    //       "additionDisplayData": "Transfer - null - null - null - null - null - null - null - null",
    //       "note": null
    //     }
    //   ]
    // }
    // this.incomeReceiveMethodsList = methods.result;

    // const frequencies = {
    //   "status": "1",
    //   "msg": {
    //     "msgCode": "I000000",
    //     "msgType": "I",
    //     "msgText": ""
    //   },
    //   "result": [
    //     {
    //       "code": "",
    //       "value": "اختر",
    //       "additionDisplayData": null,
    //       "note": null
    //     },
    //     {
    //       "code": "W",
    //       "value": "الأسبوعية",
    //       "additionDisplayData": "Weekly - null - null - null - null - null - null - null - null",
    //       "note": null
    //     },
    //     {
    //       "code": "ANN",
    //       "value": "سنويا",
    //       "additionDisplayData": "Annually - null - null - null - null - null - null - null - null",
    //       "note": null
    //     },
    //     {
    //       "code": "M",
    //       "value": "شهرية",
    //       "additionDisplayData": "Monthly - null - null - null - null - null - null - null - null",
    //       "note": null
    //     },
    //     {
    //       "code": "NU",
    //       "value": "غير مستخدم او غير معروف",
    //       "additionDisplayData": "Not Used or Unknown - null - null - null - null - null - null - null - null",
    //       "note": null
    //     },
    //     {
    //       "code": "BIW",
    //       "value": "كل أسبوعين",
    //       "additionDisplayData": "Biweekly (every two weeks) - null - null - null - null - null - null - null - null",
    //       "note": null
    //     },
    //     {
    //       "code": "SM",
    //       "value": "نصف شهري (مرتين في الشهر)",
    //       "additionDisplayData": "Semimonthly (twice a month) - null - null - null - null - null - null - null - null",
    //       "note": null
    //     }
    //   ]
    // }
    // this.incomeFrequenciesList = frequencies.result;

    // const incomeList = {
    //   "status": "1",
    //   "msg": null,
    //   "result": [
    //     {
    //       "id": "PAYROLL",
    //       "value": "مرتب"
    //     },
    //     {
    //       "id": "INVESTMENT",
    //       "value": "استثمار"
    //     },
    //     {
    //       "id": "RENT",
    //       "value": "إيجار"
    //     },
    //     {
    //       "id": "SAVING",
    //       "value": "إدخار"
    //     },
    //     {
    //       "id": "STOCK_DIVIDENDS",
    //       "value": "أسهم"
    //     },
    //     {
    //       "id": "TRADE",
    //       "value": "تجارة"
    //     },
    //     {
    //       "id": "COMMISSION_BONUS",
    //       "value": "عمولة أو علاوة"
    //     },
    //     {
    //       "id": "ALLOWANCE",
    //       "value": "علاوة"
    //     },
    //     {
    //       "id": "ADDITIONAL_WORK",
    //       "value": "عمل إضافي"
    //     },
    //     {
    //       "id": "END_OF_SERVICE",
    //       "value": "نهاية خدمة"
    //     },
    //     {
    //       "id": "INHERITANCE",
    //       "value": "ورث"
    //     },
    //     {
    //       "id": "OTHER",
    //       "value": "أخرى"
    //     }
    //   ]
    // }

    // this.incomeSourcesList = incomeList.result;
  }

  saveChanges() {
    if(this.kycDetail.nationalAddress.city==null||this.kycDetail.nationalAddress.postalCode==null
      ||this.kycDetail.nationalAddress.street==null||this.kycDetail.nationalAddress.district==null||this.kycDetail.nationalAddress.basicNo==null
      ||this.kycDetail.nationalAddress.unitNumber==null||this.kycDetail.nationalAddress.additionalNo==null){
       // alert("Please fill national address");
       Dialogs.alert(this.t.REQUIREDFIELDS as any).subscribe(ok => {
      });   
        return false;
    }
    this.showLoader = true;
    const kycObj = Object.assign({}, this.kycDetail);
    kycObj.contact = null;
    Kyc.updateDetails(kycObj).subscribe(() => {
      this.showLoader = false;
      resetCache(Kyc, 'details');
      this.navCtrl.navigateRoot('/kyc/home', { animated: true });
    },
    err => {
      console.log('HTTP Error', err);
      this.showLoader = false;
    });
  }

  addIncome() {
    if(this.incomeSource == null || this.frequency == null || this.amount == null || this.recieveMethod == null) {
      // if(this.lang == 'ar') {
      //   alert("يرجى إدخال جميع البيانات");
      // } else {
      //   alert("Please fill all input fields");
      // }
      Dialogs.alert(this.t.REQUIREDFIELDS as any).subscribe(ok => {
      });   
    }

    for (let i = 0; i < this.customerIncomeDetails?.length; i++) {
      if (this.customerIncomeDetails[i].id == this.incomeSource) {
        this.customerIncomeDetails[i].incomeSourceFlag = true;
        this.customerIncomeDetails[i].amount = this.amount;
        this.customerIncomeDetails[i].receivingMethod.code = this.recieveMethod;
        this.customerIncomeDetails[i].frequency.code = this.frequency;
        this.selectedTab = "2";
        if (this.action == "add") {
          this.incomeCount += 1;
        }
        // if (this.action == "edit") {
          for (let j = 0; j < this.incomeFrequenciesList?.length; j++) {
            if (this.incomeFrequenciesList[j].code == this.frequency) {
              if (this.lang == "ar") {
                this.customerIncomeDetails[i].frequency.arDesc = this.incomeFrequenciesList[j].value;
              } else {
                this.customerIncomeDetails[i].frequency.enDesc = this.incomeFrequenciesList[j].value;
              }
              break;
            }
          }
          for (let j = 0; j < this.incomeReceiveMethodsList?.length; j++) {
            if (this.incomeReceiveMethodsList[j].code == this.recieveMethod) {
              if (this.lang == "ar") {
                this.customerIncomeDetails[i].receivingMethod.arDesc = this.incomeReceiveMethodsList[j].value;
              } else {
                this.customerIncomeDetails[i].receivingMethod.enDesc = this.incomeReceiveMethodsList[j].value;
              }
              break;
            }
          }
        // }
        break;
      }
    }
  }

  editIncome(selectedIncome) {
    this.incomeSource = selectedIncome.id;
    this.amount = selectedIncome.amount;
    this.recieveMethod = selectedIncome.receivingMethod.code;
    this.frequency = selectedIncome.frequency.code;
    this.actionText = this.t.edit;
    this.action = "edit";
    this.selectedTab = "1";
  }

  removeIncome(selectedIncome) {
    for (let i = 0; i < this.customerIncomeDetails?.length; i++) {
      if (this.customerIncomeDetails[i].id == selectedIncome.id) {
        this.customerIncomeDetails[i].incomeSourceFlag = false;
        this.incomeCount -= 1;
        if (this.incomeCount == 0) {
          this.selectedTab = "1";
        } else {
          this.selectedTab = "2";
        }
        break;
      }
    }
  }

}
