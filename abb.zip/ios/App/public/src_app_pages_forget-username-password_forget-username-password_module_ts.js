"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_forget-username-password_forget-username-password_module_ts"],{

/***/ 90143:
/*!*******************************************************************************************!*\
  !*** ./src/app/pages/forget-username-password/forget-username-password-routing.module.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgetUsernamePasswordPageRoutingModule": () => (/* binding */ ForgetUsernamePasswordPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _forget_username_password_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forget-username-password.page */ 34571);




const routes = [
    {
        path: '',
        component: _forget_username_password_page__WEBPACK_IMPORTED_MODULE_0__.ForgetUsernamePasswordPage
    },
    {
        path: 'forgot-username',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_models_watchlist_index_ts"), __webpack_require__.e("default-src_app_common-ui-components_symbols-search-dragable-modal_symbols-search-dragable-mo-b72097"), __webpack_require__.e("default-src_app_common-ui-components_tadawul-common-ui_module_ts"), __webpack_require__.e("common"), __webpack_require__.e("src_app_pages_forget-username-password_forgot-username_forgot-username_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./forgot-username/forgot-username.module */ 31922)).then(m => m.ForgotUsernamePageModule)
    },
    {
        path: 'forgot-password',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_models_watchlist_index_ts"), __webpack_require__.e("default-src_app_common-ui-components_symbols-search-dragable-modal_symbols-search-dragable-mo-b72097"), __webpack_require__.e("default-src_app_common-ui-components_tadawul-common-ui_module_ts"), __webpack_require__.e("common"), __webpack_require__.e("src_app_pages_forget-username-password_forgot-password_forgot-password_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./forgot-password/forgot-password.module */ 48517)).then(m => m.ForgotPasswordPageModule)
    },
    {
        path: 'change-password',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_models_watchlist_index_ts"), __webpack_require__.e("default-src_app_common-ui-components_symbols-search-dragable-modal_symbols-search-dragable-mo-b72097"), __webpack_require__.e("default-src_app_common-ui-components_tadawul-common-ui_module_ts"), __webpack_require__.e("common"), __webpack_require__.e("src_app_pages_forget-username-password_change-password_change-password_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./change-password/change-password.module */ 43005)).then(m => m.ChangePasswordPageModule)
    }
];
let ForgetUsernamePasswordPageRoutingModule = class ForgetUsernamePasswordPageRoutingModule {
};
ForgetUsernamePasswordPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ForgetUsernamePasswordPageRoutingModule);



/***/ }),

/***/ 41172:
/*!***********************************************************************************!*\
  !*** ./src/app/pages/forget-username-password/forget-username-password.module.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgetUsernamePasswordPageModule": () => (/* binding */ ForgetUsernamePasswordPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _forget_username_password_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forget-username-password-routing.module */ 90143);
/* harmony import */ var _forget_username_password_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./forget-username-password.page */ 34571);








let ForgetUsernamePasswordPageModule = class ForgetUsernamePasswordPageModule {
};
ForgetUsernamePasswordPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _forget_username_password_routing_module__WEBPACK_IMPORTED_MODULE_0__.ForgetUsernamePasswordPageRoutingModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__.TranslateModule.forChild()
        ],
        declarations: [_forget_username_password_page__WEBPACK_IMPORTED_MODULE_1__.ForgetUsernamePasswordPage]
    })
], ForgetUsernamePasswordPageModule);



/***/ }),

/***/ 34571:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/forget-username-password/forget-username-password.page.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgetUsernamePasswordPage": () => (/* binding */ ForgetUsernamePasswordPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _forget_username_password_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forget-username-password.page.html?ngResource */ 95353);
/* harmony import */ var _forget_username_password_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./forget-username-password.page.scss?ngResource */ 99949);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let ForgetUsernamePasswordPage = class ForgetUsernamePasswordPage {
    constructor() { }
    ngOnInit() {
    }
};
ForgetUsernamePasswordPage.ctorParameters = () => [];
ForgetUsernamePasswordPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'tadawul-forget-username-password',
        template: _forget_username_password_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_forget_username_password_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:paramtypes", [])
], ForgetUsernamePasswordPage);



/***/ }),

/***/ 99949:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/forget-username-password/forget-username-password.page.scss?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

module.exports = "ion-toolbar {\n  --background: #005157;\n  color: #fff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZvcmdldC11c2VybmFtZS1wYXNzd29yZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxxQkFBQTtFQUNBLFdBQUE7QUFDSiIsImZpbGUiOiJmb3JnZXQtdXNlcm5hbWUtcGFzc3dvcmQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXIge1xuICAgIC0tYmFja2dyb3VuZDogIzAwNTE1NztcbiAgICBjb2xvcjogI2ZmZjtcbiAgfSJdfQ== */";

/***/ }),

/***/ 95353:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/forget-username-password/forget-username-password.page.html?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <!-- <ion-back-button [text]=\"''\"></ion-back-button> -->\n      <ion-back-button [text]=\"''\" defaultHref=\"login\"></ion-back-button>\n    </ion-buttons>\n    <ion-title slot=\"start\">{{'forgot.FORGOT_USERNAME_OR_PASSWORD' | translate}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-list>\n    <ion-item routerLink=\"/forget-username-password/forgot-username\">\n      <ion-label>{{'forgot.FORGOT_USERNAME' | translate}}</ion-label>\n    </ion-item>\n    <ion-item routerLink=\"/forget-username-password/forgot-password\">\n      <ion-label>{{'forgot.FORGOT_PASSWORD' | translate}}</ion-label>\n    </ion-item>\n  </ion-list>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_forget-username-password_forget-username-password_module_ts.js.map