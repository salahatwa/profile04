import { Component, OnInit } from '@angular/core';
import { Translations } from '@inma/helpers/translations';
import { kycTranslations } from '../kyctranslation';
import { Kyc } from '@inma/models/kyc';
import { Settings, Languages } from '@inma/helpers/settings';
import { SharedDataService } from 'src/app/providers/shared-data.service';
import { NavController } from '@ionic/angular';
import { resetCache } from '@inma/helpers/cached';
import { Environment } from 'src/environments';

@Component({
  selector: 'tadawul-basic-info',
  templateUrl: './basic-info.component.html',
  styleUrls: ['./basic-info.component.scss'],
})
export class BasicInfoComponent implements OnInit {

  @Translations()
  t = kycTranslations;
  
  public kycDetail :any;
  public personalInfo :any;
  public idInfo : any;
  public lang ="ar";
  public selectedTab="1";
  Number = Number;
  
  // constructor(public sharedData: SharedDataService) { }
  public showLoader = false;
  constructor(public sharedData: SharedDataService, public navCtrl: NavController) { }

  ngOnInit() {
    this.kycDetail = this.sharedData.getSharedData("kycDetail",false);
    this.personalInfo = this.kycDetail?.personalInfo;
    this.idInfo = this.kycDetail?.idInfo;
   if(Settings.language == Languages.Arabic){
     this.lang = "ar"
   }else{
    this.lang = "en"
   }
  }
  renewID(){
  window.open(`${Environment.hostURL}/alinmaTadawul/public/login.jsf`);
}
 

  saveChanges(){
    this.showLoader = true;
    const kycObj = Object.assign({}, this.kycDetail);
    kycObj.contact = null;
    Kyc.updateDetails(kycObj).subscribe(() => {
      resetCache(Kyc, 'details');
      this.showLoader = false;
      this.navCtrl.navigateRoot('/kyc/home', { animated: true });
    },
    err => {
      console.log('HTTP Error', err);
      this.showLoader = false;
    });
  }

  changeTab(tab){
    this.selectedTab = tab;
  }

}
