"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_nav-modal_nav-modal_module_ts"],{

/***/ 60101:
/*!*************************************************************!*\
  !*** ./src/app/pages/nav-modal/nav-modal-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NavModalPageRoutingModule": () => (/* binding */ NavModalPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _nav_modal_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./nav-modal.page */ 86000);




const routes = [
    {
        path: '',
        component: _nav_modal_page__WEBPACK_IMPORTED_MODULE_0__.NavModalPage
    }
];
let NavModalPageRoutingModule = class NavModalPageRoutingModule {
};
NavModalPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], NavModalPageRoutingModule);



/***/ }),

/***/ 53418:
/*!*****************************************************!*\
  !*** ./src/app/pages/nav-modal/nav-modal.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NavModalPageModule": () => (/* binding */ NavModalPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _nav_modal_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./nav-modal-routing.module */ 60101);
/* harmony import */ var _nav_modal_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./nav-modal.page */ 86000);







let NavModalPageModule = class NavModalPageModule {
};
NavModalPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _nav_modal_routing_module__WEBPACK_IMPORTED_MODULE_0__.NavModalPageRoutingModule
        ],
        declarations: [_nav_modal_page__WEBPACK_IMPORTED_MODULE_1__.NavModalPage]
    })
], NavModalPageModule);



/***/ }),

/***/ 86000:
/*!***************************************************!*\
  !*** ./src/app/pages/nav-modal/nav-modal.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NavModalPage": () => (/* binding */ NavModalPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _nav_modal_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./nav-modal.page.html?ngResource */ 70366);
/* harmony import */ var _nav_modal_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./nav-modal.page.scss?ngResource */ 22232);
/* harmony import */ var _order_confirm_order_confirm_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../order/confirm/order-confirm.page */ 60770);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);






let NavModalPage = class NavModalPage {
    constructor() { }
    ngOnInit() {
        setTimeout(() => {
            this.baseNav.setRoot(_order_confirm_order_confirm_page__WEBPACK_IMPORTED_MODULE_2__.OrderConfirmPage);
        }, 10);
    }
};
NavModalPage.ctorParameters = () => [];
NavModalPage.propDecorators = {
    baseNav: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.ViewChild, args: ['baseNav',] }]
};
NavModalPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'tadawul-nav-modal',
        template: _nav_modal_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_nav_modal_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__metadata)("design:paramtypes", [])
], NavModalPage);



/***/ }),

/***/ 22232:
/*!****************************************************************!*\
  !*** ./src/app/pages/nav-modal/nav-modal.page.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJuYXYtbW9kYWwucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 70366:
/*!****************************************************************!*\
  !*** ./src/app/pages/nav-modal/nav-modal.page.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<ion-nav #baseNav></ion-nav>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_nav-modal_nav-modal_module_ts.js.map