import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { IdExpiredPage } from './id-expired.page';

describe('IdExpiredPage', () => {
  let component: IdExpiredPage;
  let fixture: ComponentFixture<IdExpiredPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IdExpiredPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(IdExpiredPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
