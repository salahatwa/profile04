import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { LoadingPageRoutingModule } from './loading-routing.module';

import { LoadingPage } from './loading.page';
import { LoaderComponent } from '../common-ui-components/loader/loader.component';
import { TadawulCommonUiModule } from '../common-ui-components/tadawul-common-ui.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    LoadingPageRoutingModule,
    TadawulCommonUiModule
  ],
  declarations: [LoadingPage]
})
export class LoadingPageModule {}
