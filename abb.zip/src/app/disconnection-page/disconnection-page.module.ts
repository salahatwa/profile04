import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DisconnectionPagePageRoutingModule } from './disconnection-page-routing.module';

import { DisconnectionPagePage } from './disconnection-page.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DisconnectionPagePageRoutingModule
  ],
  declarations: [DisconnectionPagePage]
})
export class DisconnectionPagePageModule {}
