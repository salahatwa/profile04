"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_pages_order_confirm_order-confirm_page_ts-src_app_pages_order_order_page_ts"],{

/***/ 5535:
/*!************************************************************!*\
  !*** ./src/app/common-ui-components/search/search.page.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchPage": () => (/* binding */ SearchPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _search_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./search.page.html?ngResource */ 47494);
/* harmony import */ var _search_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./search.page.scss?ngResource */ 49802);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _inma_helpers_translations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/helpers/translations */ 69353);
/* harmony import */ var _search_translations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./search.translations */ 34238);
/* harmony import */ var _inma_helpers_strings__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/helpers/strings */ 36782);
/* harmony import */ var _inma_models_symbol__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @inma/models/symbol */ 61202);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 64139);










let SearchPage = class SearchPage {
    constructor(navCtrl, modalCtrl) {
        this.navCtrl = navCtrl;
        this.modalCtrl = modalCtrl;
        this.t = _search_translations__WEBPACK_IMPORTED_MODULE_3__.SearchTranslations;
        this.allSearchables = [];
        this.searchables = [];
    }
    ngOnInit() {
        _inma_models_symbol__WEBPACK_IMPORTED_MODULE_5__.Symbols.all.subscribe(symbols => {
            let s = this.symbols || symbols;
            this.allSearchables = s;
            this.searchables = this.allSearchables;
        });
    }
    filter() {
        console.log(this.queryText);
        _inma_models_symbol__WEBPACK_IMPORTED_MODULE_5__.Symbols.filter(this.queryText, (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.of)(this.allSearchables)).subscribe(symbols => {
            this.searchables = symbols;
        });
    }
    filter2() {
        console.log(this.queryText);
        let filteredSearchables = [];
        this.queryText = (this.queryText || '').trimStart();
        if (this.queryText != '') {
            this.queryText = _inma_helpers_strings__WEBPACK_IMPORTED_MODULE_4__.Strings.normalizeArabicNumbers(this.queryText.toLowerCase());
            const digitsRegex = /\d+/m;
            // Do extraction of the query text
            let queryNumbers = this.queryText.match(digitsRegex);
            let queryNumber = queryNumbers && queryNumbers.length > 0 ? queryNumbers[0].trim() : null;
            let queryWords = this.queryText.replace(digitsRegex, '').trim().toLowerCase();
            let secondFilteredSearchables = [];
            this.allSearchables.forEach((searchable) => {
                var _a;
                var matchValue = (_a = searchable === null || searchable === void 0 ? void 0 : searchable.toString()) === null || _a === void 0 ? void 0 : _a.toLocaleLowerCase();
                if (!matchValue)
                    return;
                let numberIndex = null, wordsIndex = null;
                if (queryNumber)
                    numberIndex = matchValue.indexOf(queryNumber);
                if (queryWords)
                    wordsIndex = matchValue.indexOf(queryWords);
                if (numberIndex != null && numberIndex != -1) {
                    if (wordsIndex == null || (wordsIndex != null && wordsIndex != -1)) {
                        if (numberIndex == 0)
                            filteredSearchables.push(searchable);
                        else
                            secondFilteredSearchables.push(searchable);
                    }
                }
                else if (numberIndex == null && wordsIndex && wordsIndex != -1) {
                    filteredSearchables.push(searchable);
                }
            });
            filteredSearchables.push(...secondFilteredSearchables);
        }
        else
            filteredSearchables = this.allSearchables;
        this.searchables = filteredSearchables;
    }
    select(searchable) {
        this.closeModal(searchable);
    }
    dismiss() {
        this.modalCtrl.dismiss();
    }
    closeModal(selectedSearchable) {
        this.modalCtrl.dismiss(selectedSearchable);
    }
};
SearchPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController }
];
SearchPage.propDecorators = {
    title: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input }],
    symbols: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input }],
    color: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input }]
};
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_inma_helpers_translations__WEBPACK_IMPORTED_MODULE_2__.Translations)(),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", Object)
], SearchPage.prototype, "t", void 0);
SearchPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'tadawul-search',
        template: _search_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_search_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController])
], SearchPage);



/***/ }),

/***/ 34238:
/*!********************************************************************!*\
  !*** ./src/app/common-ui-components/search/search.translations.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchTranslations": () => (/* binding */ SearchTranslations)
/* harmony export */ });
class Translations {
    constructor() {
        this.CLOSE = ['إغلاق', 'Close'];
        this.PAGE_TITLE = ['بحث', 'Search'];
    }
}
const SearchTranslations = new Translations();


/***/ }),

/***/ 66332:
/*!**********************************************!*\
  !*** ./src/app/enum/commission.type.enum.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommissionType": () => (/* binding */ CommissionType)
/* harmony export */ });
var CommissionType;
(function (CommissionType) {
    CommissionType[CommissionType["SUBMIT_ORDER"] = 1] = "SUBMIT_ORDER";
    CommissionType[CommissionType["CONFIRM_ORDER"] = 2] = "CONFIRM_ORDER";
})(CommissionType || (CommissionType = {}));


/***/ }),

/***/ 64141:
/*!****************************************************************!*\
  !*** ./src/app/pages/order/commission/commission.component.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommissionComponent": () => (/* binding */ CommissionComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _commission_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./commission.component.html?ngResource */ 65906);
/* harmony import */ var _commission_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./commission.component.scss?ngResource */ 42781);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_models_order__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/models/order */ 39344);
/* harmony import */ var _inma_models_order_order_type__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/models/order/order-type */ 83226);
/* harmony import */ var src_app_enum_commission_type_enum__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/enum/commission.type.enum */ 66332);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);









let CommissionComponent = class CommissionComponent {
    constructor(cdr, sharedData) {
        this.cdr = cdr;
        this.sharedData = sharedData;
        this.commissionType = src_app_enum_commission_type_enum__WEBPACK_IMPORTED_MODULE_4__.CommissionType;
        this.isNaN = isNaN;
        this.JSON = JSON;
        this.onChange = new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter();
        this.loading = false;
    }
    ngOnInit() { }
    getOrderCommission() {
        clearTimeout(this.lastGetOrderCommission);
        this.onChange.next(null);
        this.lastGetOrderCommission = setTimeout(() => {
            var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;
            this.order.commission.bankCommission = '0.00';
            this.order.commission.exchangeFees = '0.00';
            this.order.commission.bankCommissionVAT = '0.00';
            this.order.commission.totalTradeAmount = '0.00';
            if ((!((_a = this.order.symbol) === null || _a === void 0 ? void 0 : _a.id)) || // In case of no selected Symbol
                (!this.order.price && ((_c = (_b = this.order) === null || _b === void 0 ? void 0 : _b.type) === null || _c === void 0 ? void 0 : _c.id) !== _inma_models_order_order_type__WEBPACK_IMPORTED_MODULE_3__.OrderTypesEnum.market) || //
                this.form.controls.price.invalid ||
                !this.order.remainingQuantity ||
                this.form.controls.quantity.invalid)
                return;
            if ((((_e = (_d = this.order) === null || _d === void 0 ? void 0 : _d.type) === null || _e === void 0 ? void 0 : _e.id) === _inma_models_order_order_type__WEBPACK_IMPORTED_MODULE_3__.OrderTypesEnum.market && ((_f = this.order) === null || _f === void 0 ? void 0 : _f.remainingQuantity)) ||
                (((_h = (_g = this.order) === null || _g === void 0 ? void 0 : _g.type) === null || _h === void 0 ? void 0 : _h.id) === _inma_models_order_order_type__WEBPACK_IMPORTED_MODULE_3__.OrderTypesEnum.limit && ((_j = this.order) === null || _j === void 0 ? void 0 : _j.remainingQuantity) && ((_k = this.order) === null || _k === void 0 ? void 0 : _k.price) > 0)) {
                if (this.getOrderCommissionSubscription) // To avoid racing conditions
                    this.getOrderCommissionSubscription.unsubscribe();
                this.loading = true;
                this.sharedData.commisionLoading.next(this.loading);
                this.getOrderCommissionSubscription = _inma_models_order__WEBPACK_IMPORTED_MODULE_2__.Orders.getOrderCommission(this.order).subscribe(order => {
                    this.onChange.next(order.commission);
                    this.loading = false;
                    this.sharedData.commisionLoading.next(this.loading);
                    this.order = order;
                });
            }
            else {
                this.order.commission.bankCommission = '0.00';
                this.order.commission.exchangeFees = '0.00';
                this.order.commission.bankCommissionVAT = '0.00';
                this.order.commission.totalTradeAmount = '0.00';
            }
            this.cdr.detectChanges();
        }, 1000);
    }
};
CommissionComponent.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ChangeDetectorRef },
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_5__.SharedDataService }
];
CommissionComponent.propDecorators = {
    order: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Input }],
    type: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Input }],
    form: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Input }],
    onChange: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Output }]
};
CommissionComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'tadawul-commission',
        template: _commission_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_commission_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__metadata)("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_6__.ChangeDetectorRef,
        src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_5__.SharedDataService])
], CommissionComponent);



/***/ }),

/***/ 60770:
/*!***********************************************************!*\
  !*** ./src/app/pages/order/confirm/order-confirm.page.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderConfirmPage": () => (/* binding */ OrderConfirmPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _order_confirm_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./order-confirm.page.html?ngResource */ 91537);
/* harmony import */ var _order_confirm_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./order-confirm.page.scss?ngResource */ 42297);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _summary_order_summary_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../summary/order-summary.page */ 87674);
/* harmony import */ var _inma_models_order__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/models/order */ 39344);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_models_order_order_side__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/models/order/order-side */ 33926);
/* harmony import */ var _order_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../order.page */ 28798);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var src_app_enum_commission_type_enum__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/enum/commission.type.enum */ 66332);
/* harmony import */ var src_app_app_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/app.component */ 20721);













let OrderConfirmPage = class OrderConfirmPage {
    constructor(translate, navCtrl, modalCtrl, sharedData) {
        this.translate = translate;
        this.navCtrl = navCtrl;
        this.modalCtrl = modalCtrl;
        this.sharedData = sharedData;
        //! End of Refactor
        this.commissionType = src_app_enum_commission_type_enum__WEBPACK_IMPORTED_MODULE_7__.CommissionType;
        this.OrderPageMode = _order_page__WEBPACK_IMPORTED_MODULE_5__.OrderPageMode;
        this.OrderSidesEnum = _inma_models_order_order_side__WEBPACK_IMPORTED_MODULE_4__.OrderSidesEnum;
    }
    //! Refactor
    get buyClass() {
        var _a, _b;
        return ((_b = (_a = this.order) === null || _a === void 0 ? void 0 : _a.side) === null || _b === void 0 ? void 0 : _b.id) == _inma_models_order_order_side__WEBPACK_IMPORTED_MODULE_4__.OrderSidesEnum.buy;
    }
    ;
    get sellClass() {
        var _a, _b;
        return ((_b = (_a = this.order) === null || _a === void 0 ? void 0 : _a.side) === null || _b === void 0 ? void 0 : _b.id) == _inma_models_order_order_side__WEBPACK_IMPORTED_MODULE_4__.OrderSidesEnum.sell;
    }
    ;
    ngOnInit() {
        this.order = _order_page__WEBPACK_IMPORTED_MODULE_5__.OrderPage.order;
        console.log(this.order);
        this.pageMode = _order_page__WEBPACK_IMPORTED_MODULE_5__.OrderPage.pageMode;
    }
    execute() {
        this.loading = true;
        let priceString = this.order.price ? this.order.price.toString() : '';
        if (priceString.slice(-1) == '.') {
            priceString = priceString.slice(0, -1);
            this.order.price = parseFloat(priceString);
        }
        // To be reviwed by mustafa
        if (this.order.type.id == '1') {
            this.order.price = null;
        }
        if (this.pageMode == _order_page__WEBPACK_IMPORTED_MODULE_5__.OrderPageMode.edit) {
            _inma_models_order__WEBPACK_IMPORTED_MODULE_3__.Orders.edit(this.order).subscribe({
                next: result => {
                    // this.order.referenceNumber = referenceNumber;
                    // this.loadingModal.dismiss();
                    this.loading = false;
                    // this.navCtrl.navigateForward('/order/summary');
                    this.summaryOrder();
                    // this.showSummary = true;
                    // console.log(result);
                    // this.loadingModal.dismiss();
                    // MyApp.openPage(this.navCtrl, "OrderSummaryPage", true, { order: this.order, mode: this.pageMode })
                },
                error: result => {
                    // AppComponent.showError(result?.msg?.msgText);
                    this.loading = false;
                }
            });
        }
        else {
            _inma_models_order__WEBPACK_IMPORTED_MODULE_3__.Orders.create(this.order).subscribe({
                next: referenceNumber => {
                    this.order.referenceNumber = referenceNumber;
                    this.loading = false;
                    // this.navCtrl.navigateForward('/order/summary');
                    this.summaryOrder();
                },
                error: result => {
                    var _a;
                    src_app_app_component__WEBPACK_IMPORTED_MODULE_8__.AppComponent.showError((_a = result === null || result === void 0 ? void 0 : result.msg) === null || _a === void 0 ? void 0 : _a.msgText);
                    // alert(result?.msg?.msgText);
                    this.loading = false;
                }
            });
        }
    }
    edit() {
        this.navCtrl.navigateBack('/order');
        this.sharedData.setSharedData(true, 'editOrder');
    }
    cancel() {
        this.navCtrl.navigateBack('/order');
    }
    animate() {
        setTimeout(() => {
            this.summaryOrder();
        }, 3000);
    }
    summaryOrder() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            this.modalCtrl.dismiss({ closeOrderPage: true }).then(() => (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
                const modal = yield this.modalCtrl.create({
                    component: _summary_order_summary_page__WEBPACK_IMPORTED_MODULE_2__.OrderSummaryPage,
                    cssClass: "auto-height-modal ipad-full-width-modal",
                    // initialBreakpoint: 0.5,
                    // breakpoints: [0, 0.5],
                    componentProps: {
                        title: this.translate.instant('order.CONFIRM_ORDER'),
                        order: this.order,
                        prevPage: "order",
                    },
                    swipeToClose: true
                });
                return yield modal.present();
            }));
            // this.navCtrl.navigateForward("/order/confirm");
        });
    }
};
OrderConfirmPage.ctorParameters = () => [
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__.TranslateService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.ModalController },
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_6__.SharedDataService }
];
OrderConfirmPage.propDecorators = {
    buyClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.HostBinding, args: ['class.buy',] }],
    sellClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.HostBinding, args: ['class.sell',] }],
    order: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Input }],
    title: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.Input }]
};
OrderConfirmPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.Component)({
        selector: 'tadawul-order-confirm',
        template: _order_confirm_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_order_confirm_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__.TranslateService,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.NavController,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.ModalController,
        src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_6__.SharedDataService])
], OrderConfirmPage);



/***/ }),

/***/ 28798:
/*!*******************************************!*\
  !*** ./src/app/pages/order/order.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderPage": () => (/* binding */ OrderPage),
/* harmony export */   "OrderPageMode": () => (/* binding */ OrderPageMode)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _order_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./order.page.html?ngResource */ 33431);
/* harmony import */ var _order_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./order.page.scss?ngResource */ 92930);
/* harmony import */ var _symbols_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../symbols.service */ 4757);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _portfolios_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../portfolios.service */ 48587);
/* harmony import */ var _confirm_order_confirm_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./confirm/order-confirm.page */ 60770);
/* harmony import */ var _providers_order_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./../../providers/order.service */ 1098);
/* harmony import */ var _common_ui_components_symbols_search_dragable_modal_symbols_search_dragable_modal_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./../../common-ui-components/symbols-search-dragable-modal/symbols-search-dragable-modal.component */ 75846);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _inma_models_market__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @inma/models/market */ 1874);
/* harmony import */ var _inma_models_order__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @inma/models/order */ 39344);
/* harmony import */ var _inma_models_order_order_side__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @inma/models/order/order-side */ 33926);
/* harmony import */ var _inma_models_order_order_type__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @inma/models/order/order-type */ 83226);
/* harmony import */ var _inma_models_order_order_validity__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @inma/models/order/order-validity */ 13985);
/* harmony import */ var _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @inma/models/portfolio */ 65082);
/* harmony import */ var _inma_models_symbol__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @inma/models/symbol */ 61202);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! jquery */ 85139);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! moment */ 56908);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var src_app_common_ui_components_search_search_page__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/common-ui-components/search/search.page */ 5535);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var _providers_validation__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../providers/validation */ 11852);
/* harmony import */ var _commission_commission_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./commission/commission.component */ 64141);
/* harmony import */ var src_app_enum_commission_type_enum__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! src/app/enum/commission.type.enum */ 66332);
var OrderPage_1;


























let OrderPage = OrderPage_1 = class OrderPage {
    constructor(formBuilder, orderService, portfoliosService, platform, modalCtrl, sharedData, cdr, symbolsService, translate, pickerCtrl) {
        this.formBuilder = formBuilder;
        this.orderService = orderService;
        this.portfoliosService = portfoliosService;
        this.platform = platform;
        this.modalCtrl = modalCtrl;
        this.sharedData = sharedData;
        this.cdr = cdr;
        this.symbolsService = symbolsService;
        this.translate = translate;
        this.pickerCtrl = pickerCtrl;
        //! End of Refactor
        this.Portfolios = _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_12__.Portfolios;
        this.Symbols = _inma_models_symbol__WEBPACK_IMPORTED_MODULE_13__.Symbols;
        this.Orders = _inma_models_order__WEBPACK_IMPORTED_MODULE_8__.Orders;
        this.OrderSidesEnum = _inma_models_order_order_side__WEBPACK_IMPORTED_MODULE_9__.OrderSidesEnum;
        this.OrderTypesEnum = _inma_models_order_order_type__WEBPACK_IMPORTED_MODULE_10__.OrderTypesEnum;
        this.OrderValidity = _inma_models_order_order_validity__WEBPACK_IMPORTED_MODULE_11__.OrderValidity;
        this.JSON = JSON;
        this.validity = _inma_models_order__WEBPACK_IMPORTED_MODULE_8__.Orders.validities[0];
        this.confirmMode = true;
        this.sides = [
            new _inma_models_order_order_side__WEBPACK_IMPORTED_MODULE_9__.OrderSide({ id: _inma_models_order_order_side__WEBPACK_IMPORTED_MODULE_9__.OrderSidesEnum.buy, value: this.translate.instant('order.BUY') }),
            new _inma_models_order_order_side__WEBPACK_IMPORTED_MODULE_9__.OrderSide({ id: _inma_models_order_order_side__WEBPACK_IMPORTED_MODULE_9__.OrderSidesEnum.sell, value: this.translate.instant('order.SELL') }),
        ];
        this.orderSummaryInfo = [];
        this.numberType = "number";
        this.integerPattern = "";
        this.symbols = [];
        this.sellSymbols = [];
        this.pageMode = OrderPageMode.new;
        this.OrderPageMode = OrderPageMode;
        this.commissionType = src_app_enum_commission_type_enum__WEBPACK_IMPORTED_MODULE_20__.CommissionType;
        this.originalOrderEndDate = moment__WEBPACK_IMPORTED_MODULE_15__().format("YYYY-MM-DD");
        this.cachedRestoredBuyingPower = null;
        this.loadingCommision = false;
        this.Math = Math;
        this.Number = Number;
        this.adaptAllQuantity = null;
        this.unlockedBefore = false;
        this.maxValidatorApplied = false;
        this.minValidatorApplied = false;
        this.closedPriceValidatorApplied = false;
        this.isTradeAtLast = false;
        //#region onSymbolChanged
        this.symbolInfoLoaded = false;
        this.symbolMinPrice = 0;
        this.symbolMaxPrice = 0;
        this.symbolClosedPrice = 0;
        this.symbolCurrentPrice = 0;
        OrderPage_1.instance = this;
        this.fillOrderSummaryContent();
        this.buildForm();
        this.order = new _inma_models_order__WEBPACK_IMPORTED_MODULE_8__.Order();
        if (!this.operation) {
            this.loadSymbols();
        }
    }
    //! Refactor
    get buyClass() {
        var _a, _b;
        return ((_b = (_a = this.order) === null || _a === void 0 ? void 0 : _a.side) === null || _b === void 0 ? void 0 : _b.id) == _inma_models_order_order_side__WEBPACK_IMPORTED_MODULE_9__.OrderSidesEnum.buy;
    }
    get sellClass() {
        var _a, _b;
        return ((_b = (_a = this.order) === null || _a === void 0 ? void 0 : _a.side) === null || _b === void 0 ? void 0 : _b.id) == _inma_models_order_order_side__WEBPACK_IMPORTED_MODULE_9__.OrderSidesEnum.sell;
    }
    static get order() {
        return this.instance.order;
    }
    static get pageMode() {
        return this.instance.pageMode;
    }
    static initialize() {
        var _a;
        (_a = this.instance) === null || _a === void 0 ? void 0 : _a.initialize();
    }
    //#endregion
    initialize() {
        this.order.side = null;
        this.order.symbol = null;
        this.order.portfolio = null;
        // this.applyNavParams();
        this.parseNavParams();
    }
    fillOrderSummaryContent() {
        var _a, _b, _c, _d, _e, _f;
        this.orderSummaryInfo = [
            {
                label: "BANK_COMMISSION",
                value: (_b = (_a = this.order) === null || _a === void 0 ? void 0 : _a.commission) === null || _b === void 0 ? void 0 : _b.bankCommission,
            },
            {
                label: "TADAWUL_COMMISSION",
                value: (_d = (_c = this.order) === null || _c === void 0 ? void 0 : _c.commission) === null || _d === void 0 ? void 0 : _d.exchangeFees,
            },
            {
                label: "VAT",
                value: (_f = (_e = this.order) === null || _e === void 0 ? void 0 : _e.commission) === null || _f === void 0 ? void 0 : _f.bankCommissionVAT,
                hasPercentage: true,
            },
        ];
    }
    closePage() {
        this.modalCtrl.dismiss();
    }
    loadOrderTypes() {
        _inma_models_order__WEBPACK_IMPORTED_MODULE_8__.Orders.types.subscribe((types) => {
            this.types = types;
            this.order.type = this.types.find((t) => t.id == _inma_models_order_order_type__WEBPACK_IMPORTED_MODULE_10__.OrderTypesEnum.limit);
            // in case page loaded in edit order mode then we need to select order type
            if (this.sharedOrder && this.operation == 'edit') {
                this.order.type = this.types.find((t) => t.id == this.order.type.id);
            }
        });
    }
    ionViewWillEnter() {
        var _a;
        (_a = this.form) === null || _a === void 0 ? void 0 : _a.reset();
        if (this.platform.is("ios")) {
            this.numberType = "text";
            this.integerPattern = "\\d*";
        }
        this.parseNavParams();
        this.today = moment__WEBPACK_IMPORTED_MODULE_15__().format("YYYY-MM-DD");
        this.maxOrderDate = moment__WEBPACK_IMPORTED_MODULE_15__().add(29, "days").format("YYYY-MM-DD");
        this.loadOrderTypes();
        /// //// this.applyNavParams();
        // Portfolios.getOrderPagePortfolios.subscribe((portfolios) => {
        //   this.portfolios = portfolios;
        //   this.selectedIndex = this.portfolios.findIndex((p) => p.defaultPortfolio == true) >= 0 ? this.portfolios.findIndex((p) => p.defaultPortfolio == true) : 0;
        //   this.order.portfolio = this.portfolios[this.selectedIndex];
        //   this.applyNavParams();
        // });
    }
    parseNavParams() {
        var _a, _b, _c, _d;
        if (!this.operation) {
            // there is no navigation params init page as submit buy or sell
            this.order.side = this.sides[0];
            this.loadSymbols();
            _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_12__.Portfolios.getOrderPagePortfolios.subscribe((portfolios) => {
                this.portfolios = portfolios;
                this.selectedIndex = this.portfolios.findIndex((p) => p.defaultPortfolio == true); // update picker value
                this.selectedIndex = this.selectedIndex >= 0 ? this.selectedIndex : 0;
                this.order.portfolio = this.portfolios[this.selectedIndex];
                this.getLatestBuyingPower();
            });
        }
        else {
            // here will parse inputs operation, symbol, portfolio or order that contains (operation = edit, symbol & portfolio)
            if (this.operation == 'edit') {
                this.pageMode = OrderPageMode.edit;
                this.order = this.sharedOrder;
                this.originalOrderEndDate = (_a = this.order) === null || _a === void 0 ? void 0 : _a.endDate;
                this.handleOrderParams();
                // start to stream on symbol changes there is no disconnect as it fires on modal ionDidLeave 
                _inma_models_symbol__WEBPACK_IMPORTED_MODULE_13__.Symbols.connectToStreamOfSymbol(this.order.symbol.id);
                this.symbolChanged(this.order.symbol);
            }
            else if (this.operation == 'sell' || this.operation == 'buy') {
                this.order.side = this.operation == 'buy' ? this.sides[0] : this.sides[1];
                this.order.symbol = this.sharedSymbol;
                this.order.price = (_d = (_c = (_b = this.order) === null || _b === void 0 ? void 0 : _b.symbol) === null || _c === void 0 ? void 0 : _c.symbolData) === null || _d === void 0 ? void 0 : _d.lastTradedPrice;
                this.symbolChanged(this.order.symbol);
                // load symbols depends on buy or sell  
                this.loadSymbols();
                // load portfolios depends on buy or sell
                this.loadBuySellPortfolios();
            }
        }
        this.sharedData.commisionLoading.subscribe(commisionLoading => {
            this.loadingCommision = commisionLoading;
        });
    }
    handleOrderParams() {
        _inma_models_symbol__WEBPACK_IMPORTED_MODULE_13__.Symbols.all.subscribe((symbols) => {
            this.symbols = symbols;
            this.order.symbol = this.symbols.find((s) => s.id == this.sharedOrder.symbol.id);
            ////// this.sharedSymbol = this.order.symbol;
        });
        _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_12__.Portfolios.getOrderPagePortfolios.subscribe((portfolios) => {
            this.portfolios = portfolios;
            this.selectedIndex = this.portfolios.findIndex((p) => p.id == this.order.portfolio.id); // update picker value
            this.order.portfolio = this.portfolios[this.selectedIndex];
            this.portfolioChanged();
        });
        // need to be checked where to be set 
    }
    loadBuySellPortfolios() {
        this.portfolios = [];
        _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_12__.Portfolios.getOrderPagePortfolios.subscribe((portfolios) => {
            if (this.isBuy) {
                this.portfolios = portfolios;
                if (this.sharedPortfolio) {
                    this.selectedIndex = this.portfolios.findIndex((p) => p.id == this.sharedPortfolio); // select the shared portfolio
                }
                else {
                    this.selectedIndex = this.portfolios.findIndex((p) => p.defaultPortfolio == true); // select the default portfolio
                }
                this.selectedIndex = this.selectedIndex >= 0 ? this.selectedIndex : 0;
                this.order.portfolio = this.portfolios[this.selectedIndex];
                this.getLatestBuyingPower();
            }
            else if (this.isSell) {
                // if (this.order?.symbol?.id) {// user select a symbol then will show only portfolios that have a tradesecurity list that match selected symbol 
                //   this.symbolsService.getAllPortfoliosForASymbol(this.order.symbol.id).subscribe((res: SymbolPortfoliosInfo[]) => {
                //     this.selectedIndex = 0;
                //     res.forEach((val) => {
                //       this.portfolios.push(portfolios.find((p) => p.id == val.portfolioNumber));
                //     });
                //     if (this.sharedPortfolio) {
                //       this.selectedIndex = this.portfolios.findIndex((p) => p.id == this.sharedPortfolio); // select the shared portfolio
                //     }
                //     this.selectedIndex = this.selectedIndex >= 0 ? this.selectedIndex : 0;
                //     this.order.portfolio = this.portfolios[this.selectedIndex];
                //     this.refreshSymbolShares();
                //   });
                // } 
                //else {
                // the  user didn't select a symbol then will show all local portfolios until a symbol is selected 
                // debugger;
                if (this.previousPage == 'tradestation') {
                    this.symbolsService.getAllPortfoliosForASymbol(this.order.symbol.id).subscribe((res) => {
                        res.forEach((val) => {
                            this.portfolios.push(portfolios.find((p) => p.id == val.portfolioNumber));
                        });
                        if (this.sharedPortfolio) {
                            this.selectedIndex = this.portfolios.findIndex((p) => p.id == this.sharedPortfolio); // select the shared portfolio
                            this.order.portfolio = this.portfolios[this.selectedIndex];
                        }
                        else {
                            this.order.portfolio = this.portfolios[0];
                        }
                        this.refreshSymbolShares();
                    });
                }
                else {
                    this.portfolios = portfolios;
                    if (this.sharedPortfolio) {
                        this.selectedIndex = this.portfolios.findIndex((p) => p.id == this.sharedPortfolio); // select the shared portfolio
                    }
                    else {
                        this.selectedIndex = this.portfolios.findIndex((p) => p.defaultPortfolio == true); // select the default portfolio
                    }
                    this.selectedIndex = this.selectedIndex >= 0 ? this.selectedIndex : 0;
                    this.order.portfolio = this.portfolios[this.selectedIndex];
                    this.refreshSymbolShares();
                }
                // }
            }
        });
    }
    applyNavParams() {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l;
        // Remove false if you want to remove object from memory after using it
        const selectedSymbol = this.sharedSymbol;
        const operation = this.operation;
        const symbolPagePortfolioID = this.sharedData.getSharedData("porfolioID", false);
        if (symbolPagePortfolioID && this.portfolios) {
            this.order.portfolio = this.portfolios.find(p => p.id == symbolPagePortfolioID);
            this.selectedIndex = this.portfolios.findIndex(p => p.id == symbolPagePortfolioID);
            this.sharedData.setSharedData(null, "porfolioID");
        }
        const order = this.sharedOrder;
        if (selectedSymbol) {
            _inma_models_symbol__WEBPACK_IMPORTED_MODULE_13__.Symbols.disconnectToStreamSymbol((_b = (_a = this.order) === null || _a === void 0 ? void 0 : _a.symbol) === null || _b === void 0 ? void 0 : _b.id);
            this.order.symbol = selectedSymbol;
            this.applySymbol(this.order);
            _inma_models_symbol__WEBPACK_IMPORTED_MODULE_13__.Symbols.connectToStreamOfSymbol(this.order.symbol.id);
            this.isSharedSymbol = true;
        }
        this.sharedData.commisionLoading.subscribe(commisionLoading => {
            this.loadingCommision = commisionLoading;
        });
        if (this.operation == 'edit' && this.sharedOrder) {
            _inma_models_symbol__WEBPACK_IMPORTED_MODULE_13__.Symbols.all.subscribe((symbols) => {
                this.symbols = symbols;
                this.order.symbol = this.symbols.find((s) => s.id == this.sharedOrder.symbol.id);
                this.sharedSymbol = this.order.symbol;
            });
            this.liveBuyingPower = null;
            if ((_d = (_c = this.order) === null || _c === void 0 ? void 0 : _c.portfolio) === null || _d === void 0 ? void 0 : _d.id) {
                this.orderService.getLiveBuyingPower((_f = (_e = this.order) === null || _e === void 0 ? void 0 : _e.portfolio) === null || _f === void 0 ? void 0 : _f.id, (_h = (_g = this.order) === null || _g === void 0 ? void 0 : _g.portfolio) === null || _h === void 0 ? void 0 : _h.type)
                    .subscribe((bP) => {
                    this.isBuyingPowerLoaded = true;
                    this.cachedBuyingPower = bP;
                    this.liveBuyingPower = bP;
                });
            }
            this.applySymbol(this.order);
            _inma_models_symbol__WEBPACK_IMPORTED_MODULE_13__.Symbols.connectToStreamOfSymbol(this.order.symbol.id);
            this.isSharedSymbol = true;
        }
        if (order) {
            this.pageMode = OrderPageMode.edit;
            setTimeout(() => {
                var _a, _b, _c, _d, _e;
                this.order = order;
                this.originalOrderEndDate = (_a = this.order) === null || _a === void 0 ? void 0 : _a.endDate;
                // {
                //   this.cachedRestoredBuyingPower =
                //     order.price * order.remainingQuantity;
                // }
                //// Setting Side
                const orderSideID = (_b = order === null || order === void 0 ? void 0 : order.side) === null || _b === void 0 ? void 0 : _b.id;
                if (orderSideID) {
                    (_c = this.sides) === null || _c === void 0 ? void 0 : _c.forEach((s) => {
                        if (s.id == orderSideID)
                            this.order.side = s;
                    });
                }
                //// Setting Side
                const orderTypeID = (_d = order === null || order === void 0 ? void 0 : order.type) === null || _d === void 0 ? void 0 : _d.id;
                if (orderTypeID) {
                    (_e = this.types) === null || _e === void 0 ? void 0 : _e.forEach((t) => {
                        if (t.id == orderTypeID)
                            this.order.type = t;
                    });
                }
                setTimeout(() => {
                    this.applyPortfolio(order);
                    this.applySymbol(order);
                }, 100);
                this.cdr.detectChanges();
            }, 0);
        }
        else {
            if (operation && this.order) {
                this.order.side = operation == "buy" ? this.sides[0] : this.sides[1];
            }
            else if (!((_k = (_j = this.order) === null || _j === void 0 ? void 0 : _j.side) === null || _k === void 0 ? void 0 : _k.id))
                this.order.side = this.sides[0];
            // if (!this.order.portfolio?.id) {
            // setTimeout(() => {
            // }, 0);
            // }
            // Setting portfolio
            _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_12__.Portfolios.getOrderPagePortfolios.subscribe((ps) => {
                this.portfolios = ps;
                const current = this.order.portfolio || _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_12__.Portfolios.current;
                ps.forEach((p) => {
                    if ((current === null || current === void 0 ? void 0 : current.id) == p.id)
                        this.order.portfolio = p;
                });
                let defaultPortfolio = ps.findIndex((p) => p.defaultPortfolio == true) >= 0 ? ps.findIndex((p) => p.defaultPortfolio == true) : 0;
                this.selectedIndex = defaultPortfolio;
                this.order.portfolio = this.order.portfolio || (ps === null || ps === void 0 ? void 0 : ps[defaultPortfolio]);
                this.getLatestBuyingPower();
            });
            // setTimeout(() => {
            if (!this.order.symbol && selectedSymbol) {
                (_l = this.symbols) === null || _l === void 0 ? void 0 : _l.forEach((s) => {
                    if (s.id == (selectedSymbol === null || selectedSymbol === void 0 ? void 0 : selectedSymbol.id)) {
                        this.order.symbol = s;
                    }
                });
            }
            // }, 100);
        }
    }
    applyPortfolio(order) {
        var _a;
        order = order || this.order;
        const portfolioId = (_a = order === null || order === void 0 ? void 0 : order.portfolio) === null || _a === void 0 ? void 0 : _a.id;
        if (portfolioId) {
            _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_12__.Portfolios.getOrderPagePortfolios.subscribe((ps) => {
                var _a;
                this.portfolios = ps;
                (_a = this.portfolios) === null || _a === void 0 ? void 0 : _a.forEach((p) => {
                    if (p.id == portfolioId)
                        this.order.portfolio = p;
                });
            });
        }
    }
    applySymbol(order) {
        var _a;
        order = order || this.order;
        const orderSymbolId = (_a = order === null || order === void 0 ? void 0 : order.symbol) === null || _a === void 0 ? void 0 : _a.id;
        if (orderSymbolId) {
            this.order.symbol = this.isBuy ? this.symbols.find((s) => s.id == orderSymbolId) : this.sellSymbols.find((s) => s.id == orderSymbolId);
            this.isSymbolShareLoaded = true;
            this.symbolChanged(this.order.symbol);
        }
    }
    refreshSymbolShares() {
        var _a;
        if ((_a = this.order) === null || _a === void 0 ? void 0 : _a.symbol) {
            this.isSymbolShareLoaded = false;
            this.portfoliosService.getPortfolioDetailsInfo(this.order.portfolio.id).subscribe((res) => {
                let shares = res.tradeSecurties.find((s) => s.symbol.code == this.order.symbol.id).availQuantity;
                this.order.symbol.availableQuantity = Number(shares);
                this.isSymbolShareLoaded = true;
            });
        }
    }
    buildForm() {
        this.form = this.formBuilder.group({
            portfolio: [""],
            symbol: ["", _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.required],
            // isDefaultPortfolio: [false],
            type: ["", _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.required],
            price: [
                "",
                [
                    _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.required,
                    // ValidationProvider.number,
                    // ValidationProvider.priceTick,
                ],
            ],
            quantity: [
                "",
                [
                    _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.required,
                    _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.integer,
                    _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.min(1),
                ],
            ],
            disclosedQuantity: ["", _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.integer],
            endDate: ["", _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.nullValidator],
            tif: [""],
            //  endDateModal:[""]
        });
    }
    //#endregion
    orderTypeChanged() {
        var _a;
        this.loadTifs((_a = this.order) === null || _a === void 0 ? void 0 : _a.type);
        this.getOrderCommission();
        this.updateValidators();
        if (this.unlockedBefore == true) {
            this.unlockedHandler();
        }
    }
    loadTifs(orderType) {
        this.markrtPriceTifTypes = this.sharedData.getSharedData("cashedMarkrtPriceTifTypes", false);
        this.limitedPriceTifTypes = this.sharedData.getSharedData("cashedLimitedPriceTifTypes", false);
        if (orderType.id == 1 && this.markrtPriceTifTypes) {
            this.tifs = this.markrtPriceTifTypes;
            this.handleTifType();
        }
        else if (orderType.id == 2 && this.limitedPriceTifTypes) {
            this.tifs = this.limitedPriceTifTypes;
            this.handleTifType();
        }
        else {
            this.isTifsLoaded = false;
            _inma_models_order__WEBPACK_IMPORTED_MODULE_8__.Orders.loadTifs(orderType).subscribe((orderTifs) => {
                this.tifs = orderTifs;
                this.filterTifs(orderType);
                setTimeout(() => {
                    this.updateValidators();
                    this.isTifsLoaded = true;
                    this.validityChange();
                }, 200);
                if (orderType.id == 1) {
                    this.markrtPriceTifTypes = orderTifs;
                    this.sharedData.setSharedData(this.markrtPriceTifTypes, 'cashedMarkrtPriceTifTypes');
                }
                else if (orderType.id == 2) {
                    this.limitedPriceTifTypes = orderTifs;
                    this.sharedData.setSharedData(this.limitedPriceTifTypes, 'cashedLimitedPriceTifTypes');
                }
                if (this.sharedOrder && this.operation == 'edit') {
                    this.order.tif = this.tifs.find((t) => t.id == this.order.tif.id);
                }
                this.handleTifType();
            });
        }
    }
    handleTifType() {
        var _a, _b;
        if (((_b = (_a = this.order) === null || _a === void 0 ? void 0 : _a.type) === null || _b === void 0 ? void 0 : _b.id) == _inma_models_order_order_type__WEBPACK_IMPORTED_MODULE_10__.OrderTypesEnum.limit)
            this.order.tif = this.tifs[0];
        else {
            this.tifs.forEach((tif) => {
                if (tif.id == "0" || tif.id == "")
                    this.order.tif = tif;
            });
        }
        setTimeout(() => {
            this.updateValidators();
            this.isTifsLoaded = true;
            this.validityChange();
        }, 200);
    }
    filterTifs(orderType) {
        if ((orderType === null || orderType === void 0 ? void 0 : orderType.id) == _inma_models_order_order_type__WEBPACK_IMPORTED_MODULE_10__.OrderTypesEnum.market) {
            _inma_models_market__WEBPACK_IMPORTED_MODULE_7__.Market.status.subscribe(marketStatus => {
                // when market closed,preopen display all tif 
                // when market not-closed & not preopen  display all tif except at opening
                if (marketStatus != "CLOSED" && marketStatus != "PREOPEN") {
                    this.tifs = this.tifs.filter((tif) => _inma_models_order_order_type__WEBPACK_IMPORTED_MODULE_10__.TifType.AtOpenening !== tif.id);
                }
                // //remove [Tif] fill or kill , fill and kill  when status not [open]
                // if (marketStatus != "OPEN") {
                //   this.tifs = this.tifs.filter((tif) => TifType.FillAndKill !== tif.id);
                //   this.tifs = this.tifs.filter((tif) => TifType.FillOrKill !== tif.id);
                // }
            });
            this.tifs.forEach((tif) => {
                if (tif.id == "0" || tif.id == "")
                    this.order.tif = tif;
            });
        }
        else if ((orderType === null || orderType === void 0 ? void 0 : orderType.id) == _inma_models_order_order_type__WEBPACK_IMPORTED_MODULE_10__.OrderTypesEnum.limit)
            this.order.tif = this.tifs[0];
    }
    portfolioChanged() {
        var _a, _b, _c, _d, _e, _f;
        this.unlockedBefore = false;
        if (this.isBuy) {
            this.liveBuyingPower = null;
            if ((_b = (_a = this.order) === null || _a === void 0 ? void 0 : _a.portfolio) === null || _b === void 0 ? void 0 : _b.id) {
                this.orderService.getLiveBuyingPower((_d = (_c = this.order) === null || _c === void 0 ? void 0 : _c.portfolio) === null || _d === void 0 ? void 0 : _d.id, (_f = (_e = this.order) === null || _e === void 0 ? void 0 : _e.portfolio) === null || _f === void 0 ? void 0 : _f.type)
                    .subscribe((bP) => {
                    this.isBuyingPowerLoaded = true;
                    this.cachedBuyingPower = bP;
                    this.liveBuyingPower = bP;
                });
            }
        }
        else if (this.isSell) {
            this.sellSymbols = [];
            if (!this.operation) {
                this.order.symbol = null;
            }
            this.isSymbolShareLoaded = false;
            this.portfoliosService.getPortfolioDetailsInfo(this.order.portfolio.id).subscribe((res) => {
                var _a, _b;
                if ((_b = (_a = this.order) === null || _a === void 0 ? void 0 : _a.symbol) === null || _b === void 0 ? void 0 : _b.id) {
                    let shares = res.tradeSecurties.find((s) => s.symbol.code == this.order.symbol.id).availQuantity;
                    this.order.symbol.availableQuantity = Number(shares);
                    this.isSymbolShareLoaded = true;
                }
                // else {
                //   Symbols.all.subscribe((symbols) => {
                //     res.tradeSecurties.forEach((val) => {
                //       this.sellSymbols.push(symbols.find((s) => s.id == val.symbol.code));
                //     });
                //   });
                // }
            });
        }
    }
    getLatestBuyingPower() {
        var _a, _b, _c, _d, _e, _f;
        this.isBuyingPowerLoaded = false;
        if ((_b = (_a = this.order) === null || _a === void 0 ? void 0 : _a.portfolio) === null || _b === void 0 ? void 0 : _b.id) {
            this.orderService
                .getLiveBuyingPower((_d = (_c = this.order) === null || _c === void 0 ? void 0 : _c.portfolio) === null || _d === void 0 ? void 0 : _d.id, (_f = (_e = this.order) === null || _e === void 0 ? void 0 : _e.portfolio) === null || _f === void 0 ? void 0 : _f.type)
                .subscribe((bP) => {
                this.liveBuyingPower = bP;
                this.cachedBuyingPower = bP;
                this.isBuyingPowerLoaded = true;
            });
        }
    }
    orderSideChanged($event) {
        this.loadSymbols();
        this.loadBuySellPortfolios();
        this.order.disclosedQuantity = null;
        this.order.price = null;
        this.order.symbol = null;
        this.order.remainingQuantity = null;
        this.order.tif.id = "6";
        this.order.type.id = "2";
        this.symbolMinPrice = null;
        this.symbolMaxPrice = null;
        this.adaptAllQuantity = null;
        setTimeout(() => {
            this.updateValidators();
        }, 100);
    }
    // needs to be called in constructor if there is no navigation parameters 
    loadSymbols() {
        var _a;
        this.symbols = []; // symbols array in buy side
        this.sellSymbols = []; // symbols array in sell side
        if (this.isBuy) {
            _inma_models_symbol__WEBPACK_IMPORTED_MODULE_13__.Symbols.all.subscribe((symbols) => {
                if (this.isBuy) {
                    this.symbols = symbols;
                    ////////this.applyNavParams();
                }
            });
        }
        else if (this.isSell) {
            // we need to be sure that there is a selected portfolio 
            if ((_a = this.order) === null || _a === void 0 ? void 0 : _a.portfolio) {
                this.portfoliosService.getPortfolioDetailsInfo(this.order.portfolio.id).subscribe((res) => {
                    var _a;
                    _inma_models_symbol__WEBPACK_IMPORTED_MODULE_13__.Symbols.all.subscribe((symbols) => {
                        res === null || res === void 0 ? void 0 : res.tradeSecurties.forEach((val) => {
                            this.sellSymbols.push(symbols.find((s) => s.id == val.symbol.code));
                        });
                    });
                    //////////this.applyNavParams();
                    if (!((_a = this.order) === null || _a === void 0 ? void 0 : _a.symbol)) {
                    }
                });
            }
        }
    }
    get isSell() {
        var _a, _b;
        return ((_b = (_a = this.order) === null || _a === void 0 ? void 0 : _a.side) === null || _b === void 0 ? void 0 : _b.id) == _inma_models_order_order_side__WEBPACK_IMPORTED_MODULE_9__.OrderSidesEnum.sell;
    }
    get isBuy() {
        var _a, _b;
        return ((_b = (_a = this.order) === null || _a === void 0 ? void 0 : _a.side) === null || _b === void 0 ? void 0 : _b.id) == _inma_models_order_order_side__WEBPACK_IMPORTED_MODULE_9__.OrderSidesEnum.buy;
    }
    quantityChanged() {
        this.getOrderCommission();
    }
    getOrderCommission() {
        var _a, _b, _c, _d, _e, _f, _g, _h;
        if (this.order.price && (this.order.price.toString() != '.' && this.order.price.toString() != ',')) {
            this.order.price = Number(Number(this.order.price).toFixed(2));
        }
        (_a = this.commissionComponent) === null || _a === void 0 ? void 0 : _a.getOrderCommission();
        if (((_c = (_b = this.order) === null || _b === void 0 ? void 0 : _b.side) === null || _c === void 0 ? void 0 : _c.id) == _inma_models_order_order_side__WEBPACK_IMPORTED_MODULE_9__.OrderSidesEnum.buy && this.pageMode != OrderPageMode.edit) {
            this.updateQuantityMaxValidation((Number(this.cachedBuyingPower)) /
                this.order.price);
        }
        else if (((_e = (_d = this.order) === null || _d === void 0 ? void 0 : _d.side) === null || _e === void 0 ? void 0 : _e.id) == _inma_models_order_order_side__WEBPACK_IMPORTED_MODULE_9__.OrderSidesEnum.sell) {
            // if (!this.order.remainingQuantity) { this.order.remainingQuantity = 0; } // soft launch comments Naif to nullify quantity on symbol sell 
            //let availableQuan: number = +this.order?.symbol?.availableQuantity - +this.order?.remainingQuantity;
            let availableQuan = (+((_g = (_f = this.order) === null || _f === void 0 ? void 0 : _f.symbol) === null || _g === void 0 ? void 0 : _g.availableQuantity) - +((_h = this.order) === null || _h === void 0 ? void 0 : _h.remainingQuantity)) < 0 ? -1 : undefined; // develop branch handle
            this.updateQuantityMaxValidation(availableQuan);
        }
    }
    increasePriceAdjustment() {
        if (this.order.symbol == null) {
            return false;
        }
        if (this.order.price || this.order.price >= 0) {
            this.order.price = Number(this.order.price);
            if (this.order.price >= 0 && this.order.price < 10) {
                this.order.price += 0.01;
            }
            else if (this.order.price >= 10 && this.order.price < 25) {
                this.order.price += 0.02;
            }
            else if (this.order.price >= 25 && this.order.price < 50) {
                this.order.price += 0.05;
            }
            else if (this.order.price >= 50 && this.order.price < 100) {
                this.order.price += 0.1;
            }
            else if (this.order.price >= 100) {
                this.order.price += 0.2;
            }
            else {
                this.order.price += 1;
            }
        }
        this.order.price = Number(this.order.price.toFixed(2));
        this.form.markAsDirty();
    }
    decreasePriceAdjustment() {
        if (this.order.symbol == null) {
            return false;
        }
        if (this.order.price || this.order.price >= 0) {
            this.order.price = Number(this.order.price);
            if (this.order.price >= 0 && this.order.price < 10) {
                this.order.price -= 0.01;
            }
            else if (this.order.price >= 10 && this.order.price < 25) {
                this.order.price -= 0.02;
            }
            else if (this.order.price >= 25 && this.order.price < 50) {
                this.order.price -= 0.05;
            }
            else if (this.order.price >= 50 && this.order.price < 100) {
                this.order.price -= 0.1;
            }
            else if (this.order.price >= 100) {
                this.order.price -= 0.2;
            }
            else {
                this.order.price -= 1;
            }
        }
        if (this.order.price < 0) {
            this.order.price = 0;
        }
        this.order.price = Number(this.order.price.toFixed(2));
        this.form.markAsDirty();
    }
    onCommissionLoaded(commission) {
        var _a, _b, _c, _d, _e, _f, _g, _h;
        if (commission) {
            let total = Number((_b = (_a = this.order) === null || _a === void 0 ? void 0 : _a.commission) === null || _b === void 0 ? void 0 : _b.totalTradeAmount);
            // this.showSpinner = this.adaptAllQuantity ? true : false;
            if ((_d = (_c = this.order) === null || _c === void 0 ? void 0 : _c.portfolio) === null || _d === void 0 ? void 0 : _d.id) {
                this.orderService.getLiveBuyingPower((_f = (_e = this.order) === null || _e === void 0 ? void 0 : _e.portfolio) === null || _f === void 0 ? void 0 : _f.id, (_h = (_g = this.order) === null || _g === void 0 ? void 0 : _g.portfolio) === null || _h === void 0 ? void 0 : _h.type)
                    .subscribe((bP) => {
                    bP = Number(bP);
                    let buyingPower = bP;
                    // while (total > buyingPower) {
                    //   this.order.remainingQuantity -= 1;
                    //   total -= this.order.price;
                    // }
                    // this.showSpinner = false;
                });
            }
            this.adaptAllQuantity = null;
        }
        // console.log("commission = ", commission);
    }
    execute() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _confirm_order_confirm_page__WEBPACK_IMPORTED_MODULE_4__.OrderConfirmPage,
                cssClass: "auto-height-modal ipad-full-width-modal",
                // initialBreakpoint: 0.9,
                // breakpoints: [0, 0.9],
                componentProps: {
                    title: this.translate.instant('order.CONFIRM_ORDER'),
                    order: this.order,
                    prevPage: "order",
                },
                swipeToClose: true
            });
            modal.onDidDismiss().then((data) => {
                var _a;
                // close order modal
                if ((_a = data === null || data === void 0 ? void 0 : data.data) === null || _a === void 0 ? void 0 : _a.closeOrderPage) {
                    this.modalCtrl.dismiss();
                }
            });
            return yield modal.present();
            // this.navCtrl.navigateForward("/order/confirm");
        });
    }
    onSelectAllQuantityProgress(progress) {
        // console.log(progress);
        // $(this.selectAllQuantity.nativeElement).css('left', (100 - progress) * 313 / 100 + 'px').css('opacity', Animation.Easings.easeOutCubic(progress/100.0));
        if (progress < 100)
            jquery__WEBPACK_IMPORTED_MODULE_14__(this.selectAllQuantity.nativeElement).fadeOut("fast");
        else
            jquery__WEBPACK_IMPORTED_MODULE_14__(this.selectAllQuantity.nativeElement).fadeIn();
    }
    unlockedHandler() {
        this.form.markAsDirty();
        this.unlockedBefore = true;
        this.adaptAllQuantity = null;
        let currentQuantity;
        jquery__WEBPACK_IMPORTED_MODULE_14__(this.quantity.nativeElement).animate({ opacity: 0 }, () => {
            var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;
            this.showSpinner = true;
            currentQuantity = this.order.remainingQuantity;
            if (((_b = (_a = this.order) === null || _a === void 0 ? void 0 : _a.side) === null || _b === void 0 ? void 0 : _b.id) == _inma_models_order_order_side__WEBPACK_IMPORTED_MODULE_9__.OrderSidesEnum.buy) {
                this.order.remainingQuantity = 0;
                if ((_d = (_c = this.order) === null || _c === void 0 ? void 0 : _c.portfolio) === null || _d === void 0 ? void 0 : _d.id) {
                    this.orderService.getLiveBuyingPower((_f = (_e = this.order) === null || _e === void 0 ? void 0 : _e.portfolio) === null || _f === void 0 ? void 0 : _f.id, (_h = (_g = this.order) === null || _g === void 0 ? void 0 : _g.portfolio) === null || _h === void 0 ? void 0 : _h.type)
                        .subscribe((bP) => {
                        var _a, _b, _c, _d, _e;
                        bP = Number(bP);
                        if (((_b = (_a = this.order) === null || _a === void 0 ? void 0 : _a.type) === null || _b === void 0 ? void 0 : _b.id) == _inma_models_order_order_type__WEBPACK_IMPORTED_MODULE_10__.OrderTypesEnum.limit) {
                            //this.order.remainingQuantity = Math.floor(bP / this.order.price) || 0;
                            let X = bP / this.order.price;
                            let Y = X * 0.0017825;
                            this.order.remainingQuantity = Math.floor(X - Y) || 0;
                            if (currentQuantity != this.order.remainingQuantity) {
                                this.adaptAllQuantity = this.order.remainingQuantity;
                            }
                        }
                        else {
                            (_e = (_d = (_c = this.order) === null || _c === void 0 ? void 0 : _c.symbol) === null || _d === void 0 ? void 0 : _d.price) === null || _e === void 0 ? void 0 : _e.subscribe((price) => {
                                if (Number(this.symbolMaxPrice) != 0) {
                                    // this.order.remainingQuantity =
                                    //   Math.floor(bP / Number(price)) || 0;
                                    let X = bP / Number(this.symbolMaxPrice);
                                    let Y = X * 0.0017825;
                                    this.order.remainingQuantity = Math.floor(X - Y) || 0;
                                    this.order.price = Number(this.symbolMaxPrice);
                                    if (currentQuantity != this.order.remainingQuantity) {
                                        this.adaptAllQuantity = this.order.remainingQuantity;
                                    }
                                }
                            });
                        }
                        this.showSpinner = false;
                    });
                }
            }
            else {
                this.order.remainingQuantity = Number(((_k = (_j = this.order) === null || _j === void 0 ? void 0 : _j.symbol) === null || _k === void 0 ? void 0 : _k.availableQuantity) || 0);
                this.adaptAllQuantity = null;
                this.showSpinner = false;
            }
            jquery__WEBPACK_IMPORTED_MODULE_14__(this.quantity.nativeElement).animate({ opacity: 1 });
        });
    }
    //#region Validators
    updateValidators() {
        var _a, _b, _c, _d, _e, _f;
        // console.log(this.order?.type);
        this.maxValidatorApplied = false;
        this.minValidatorApplied = false;
        this.closedPriceValidatorApplied = false;
        if (this.isTradeAtLast) {
            this.closedPriceValidatorApplied = true;
            this.form.controls["price"].setValidators([
                _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.required,
                _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.number,
                _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.equals((cv) => parseFloat(cv) == this.symbolClosedPrice, true),
            ]);
            this.form.controls["endDate"].setValidators(_providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.required);
            this.form.controls["orderType"].setValidators(_providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.equals((cv) => cv.id == _inma_models_order_order_type__WEBPACK_IMPORTED_MODULE_10__.OrderTypesEnum.limit));
        }
        else {
            if (((_b = (_a = this.order) === null || _a === void 0 ? void 0 : _a.type) === null || _b === void 0 ? void 0 : _b.id) == _inma_models_order_order_type__WEBPACK_IMPORTED_MODULE_10__.OrderTypesEnum.market) {
                this.form.controls["price"].setValidators(_providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.nullValidator);
                this.form.controls["endDate"].setValidators(_providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.nullValidator);
            }
            else {
                // Refer to logic[1]
                if (((_d = (_c = this.order) === null || _c === void 0 ? void 0 : _c.side) === null || _d === void 0 ? void 0 : _d.id) == _inma_models_order_order_side__WEBPACK_IMPORTED_MODULE_9__.OrderSidesEnum.buy && this.pageMode != OrderPageMode.edit) {
                    this.maxValidatorApplied = true;
                    this.form.controls["price"].setValidators([
                        _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.required,
                        _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.number,
                        _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.priceTick,
                        _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.max(this.symbolMaxPrice),
                    ]);
                }
                else if (((_f = (_e = this.order) === null || _e === void 0 ? void 0 : _e.side) === null || _f === void 0 ? void 0 : _f.id) == _inma_models_order_order_side__WEBPACK_IMPORTED_MODULE_9__.OrderSidesEnum.sell) {
                    this.minValidatorApplied = true;
                    this.form.controls["price"].setValidators([
                        _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.required,
                        _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.number,
                        _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.priceTick,
                        _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.min(this.symbolMinPrice),
                    ]);
                }
                this.form.controls["endDate"].setValidators(_providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.required);
            }
            this.form.controls["type"].setValidators(_providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.nullValidator);
        }
        this.form.controls["price"].updateValueAndValidity();
        this.form.controls["endDate"].updateValueAndValidity();
        this.form.controls["type"].updateValueAndValidity();
        this.cdr.detectChanges();
    }
    //#endregion
    updateQuantityMaxValidation(max) {
        let validators = [
            _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.required,
            _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.integer,
            _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.min(1),
        ];
        if (max)
            validators = [
                _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.required,
                _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.integer,
                ,
                _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.min(1),
                _providers_validation__WEBPACK_IMPORTED_MODULE_18__.ValidationProvider.max(max),
            ];
        this.form.controls["quantity"].setValidators(validators);
        this.form.controls["quantity"].updateValueAndValidity();
    }
    symbolChanged(orderSymbol) {
        if (!orderSymbol)
            return;
        _inma_models_order__WEBPACK_IMPORTED_MODULE_8__.Orders.loadPriceRange(orderSymbol === null || orderSymbol === void 0 ? void 0 : orderSymbol.id).subscribe((result) => {
            this.symbolMinPrice = result === null || result === void 0 ? void 0 : result.minPrice;
            this.symbolMaxPrice = result === null || result === void 0 ? void 0 : result.maxPrice;
            this.symbolClosedPrice = (result === null || result === void 0 ? void 0 : result.closedPrice) || 0;
            this.updateValidators();
        });
    }
    //#endregion
    openSearch() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: src_app_common_ui_components_search_search_page__WEBPACK_IMPORTED_MODULE_16__.SearchPage,
                componentProps: {
                    title: this.translate.instant('order.SYMBOL'),
                    symbols: this.isBuy ? this.symbols : this.sellSymbols,
                    color: this.isBuy ? "#21bf73" : "#da2d2d",
                },
            });
            modal.present();
            const { data } = yield modal.onWillDismiss();
            this.order.symbol = data;
            this.applySymbol(this.order);
        });
    }
    openPortfolioPicker() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
            let options = this.portfolios.map(p => ({ text: p.id, value: p.id }));
            let pickerAction;
            let opt = {
                buttons: [
                    {
                        text: this.translate.instant('product.CANCEL'),
                        role: 'cancel',
                        handler: value => {
                            pickerAction = 'cancel';
                        }
                    },
                    {
                        text: this.translate.instant('product.OK'),
                        role: 'done',
                        handler: value => {
                            pickerAction = 'done';
                        }
                    }
                ],
                columns: [
                    {
                        selectedIndex: this.selectedIndex ? this.selectedIndex : 0,
                        name: 'Portfolios',
                        options: options,
                    }
                ]
            };
            if (this.pageMode == OrderPageMode.edit || (this.previousPage == 'symbol' && this.operation == 'sell')) { }
            else {
                let picker = yield this.pickerCtrl.create(opt);
                picker.present();
                picker.onDidDismiss().then((data) => (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
                    if (pickerAction == 'done') {
                        let col = yield picker.getColumn('Portfolios');
                        if (col.selectedIndex != this.selectedIndex) {
                            this.order.tif = this.tifs[0];
                            this.order.type = this.types[this.types.length - 1];
                            this.adaptAllQuantity = null;
                            this.cachedBuyingPower = null;
                            if (this.order.symbol) {
                                this.order.symbol.availableQuantity = 0;
                            }
                            this.order.disclosedQuantity = null;
                            this.order.remainingQuantity = null;
                            if (this.order.side.id == _inma_models_order_order_side__WEBPACK_IMPORTED_MODULE_9__.OrderSidesEnum.sell) {
                                this.order.price = null;
                                // this.order.endDate = null;
                            }
                        }
                        this.selectedIndex = col.selectedIndex;
                        this.selectedValue = col.options[col.selectedIndex].text;
                        this.order.portfolio = this.portfolios.find(p => p.id == this.selectedValue);
                        this.loadSymbols();
                        this.portfolioChanged();
                        console.log("🚀 ~ file: order.page.ts ~ line 725 ~ OrderPage ~ picker.onDidDismiss ~ this.selectedValue", this.selectedValue);
                    }
                }));
            }
        });
    }
    openMarketPicker() {
        var _a, _b, _c, _d;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
            let options = this.tifs.map(t => ({ text: t.name, value: t.id }));
            let pickerAction;
            if ((_b = (_a = this.order) === null || _a === void 0 ? void 0 : _a.tif) === null || _b === void 0 ? void 0 : _b.id) {
                for (let i = 0; i <= this.tifs.length - 1; i++) {
                    if (this.tifs[i].id == ((_d = (_c = this.order) === null || _c === void 0 ? void 0 : _c.tif) === null || _d === void 0 ? void 0 : _d.id)) {
                        this.selectedMarketIndex = i;
                    }
                }
            }
            let opt = {
                buttons: [
                    {
                        text: this.translate.instant('product.CANCEL'),
                        role: 'cancel',
                        handler: value => {
                            pickerAction = 'cancel';
                        }
                    },
                    {
                        text: this.translate.instant('product.OK'),
                        role: 'done',
                        handler: value => {
                            pickerAction = 'done';
                        }
                    }
                ],
                columns: [
                    {
                        selectedIndex: this.selectedMarketIndex ? this.selectedMarketIndex : 0,
                        name: 'Tifs',
                        options: options
                    }
                ]
            };
            let picker = yield this.pickerCtrl.create(opt);
            picker.present();
            picker.onDidDismiss().then((data) => (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
                if (pickerAction == 'done') {
                    let col = yield picker.getColumn('Tifs');
                    this.selectedMarketIndex = col.selectedIndex;
                    this.selectedMarketValue = col.options[col.selectedIndex].text;
                    this.order.tif = this.tifs.find(t => t.name == this.selectedMarketValue);
                    console.log("🚀 ~ file: order.page.ts ~ line 725 ~ OrderPage ~ picker.onDidDismiss ~ this.selectedValue", this.selectedMarketValue);
                }
                this.cdr.detectChanges();
            }));
        });
    }
    openLimitPicker() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
            let options = _inma_models_order__WEBPACK_IMPORTED_MODULE_8__.Orders.validities.map(v => ({ text: this.translate.instant('order.' + v), value: v }));
            let pickerAction;
            let opt = {
                buttons: [
                    {
                        text: this.translate.instant('product.CANCEL'),
                        role: 'cancel',
                        handler: value => {
                            pickerAction = 'cancel';
                        }
                    },
                    {
                        text: this.translate.instant('product.OK'),
                        role: 'done',
                        handler: value => {
                            pickerAction = 'done';
                        }
                    }
                ],
                columns: [
                    {
                        selectedIndex: this.selectedLimitIndex ? this.selectedLimitIndex : 0,
                        name: 'validity',
                        options: options
                    }
                ]
            };
            let picker = yield this.pickerCtrl.create(opt);
            picker.present();
            picker.onDidDismiss().then((data) => (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
                if (pickerAction == 'done') {
                    let col = yield picker.getColumn('validity');
                    this.selectedLimitIndex = col.selectedIndex;
                    this.selectedLimitValue = col.options[col.selectedIndex].value;
                    this.validity = _inma_models_order__WEBPACK_IMPORTED_MODULE_8__.Orders.validities.find(v => v == this.selectedLimitValue);
                    this.validityChange();
                    console.log("🚀 ~ file: order.page.ts ~ line 725 ~ OrderPage ~ picker.onDidDismiss ~ this.selectedValue", this.selectedLimitValue);
                    this.unlockedBefore = false;
                }
                this.cdr.detectChanges();
            }));
        });
    }
    presentSymbolsSearchModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, function* () {
            // this.onClose();
            if (!this.operation) {
                const modal = yield this.modalCtrl.create({
                    component: _common_ui_components_symbols_search_dragable_modal_symbols_search_dragable_modal_component__WEBPACK_IMPORTED_MODULE_6__.SymbolsSearchDragableModalComponent,
                    // initialBreakpoint: 0.96,
                    // breakpoints: [0, 0.96],
                    cssClass: "auto-height-modal ipad-full-width-modal",
                    componentProps: {
                        title: this.translate.instant('order.symabolsSearch'),
                        symbols: this.isBuy ? this.symbols : this.sellSymbols,
                        prevPage: "order",
                    },
                    swipeToClose: true
                });
                modal.onDidDismiss().then((data) => {
                    var _a, _b, _c, _d, _e, _f, _g, _h;
                    // disconnect from the previous one 
                    if (!data.data && this.order.symbol) {
                        return;
                    }
                    else if (((_a = data === null || data === void 0 ? void 0 : data.data) === null || _a === void 0 ? void 0 : _a.id) != ((_c = (_b = this.order) === null || _b === void 0 ? void 0 : _b.symbol) === null || _c === void 0 ? void 0 : _c.id)) {
                        this.unlockedBefore = false;
                        this.order.disclosedQuantity = null;
                        this.order.price = null;
                        this.order.remainingQuantity = null;
                        this.order.tif = this.tifs[0];
                        // this.order.type = this.types[this.types.length - 1];
                        this.symbolMinPrice = null;
                        this.symbolMaxPrice = null;
                        this.adaptAllQuantity = null;
                        // this.order.endDate = null;
                        if ((_d = this.order) === null || _d === void 0 ? void 0 : _d.symbol) {
                            _inma_models_symbol__WEBPACK_IMPORTED_MODULE_13__.Symbols.disconnectToStreamSymbol(this.order.symbol.id);
                        }
                        this.order.symbol = data.data;
                        this.order.price = (_g = (_f = (_e = this.order) === null || _e === void 0 ? void 0 : _e.symbol) === null || _f === void 0 ? void 0 : _f.symbolData) === null || _g === void 0 ? void 0 : _g.lastTradedPrice;
                        if ((_h = this.order) === null || _h === void 0 ? void 0 : _h.symbol) {
                            this.applySymbol(this.order);
                            _inma_models_symbol__WEBPACK_IMPORTED_MODULE_13__.Symbols.connectToStreamOfSymbol(this.order.symbol.id);
                            if (this.isSell) {
                                this.refreshSymbolShares();
                                //this.loadBuySellPortfolios();
                                //this.isSymbolShareLoaded = false;
                                // this.cdr.detectChanges();
                                // this.portfoliosService.getPortfolioDetailsInfo(this.order.portfolio.id).subscribe((res: PortfolioDetailsInfo) => {
                                //   let shares = res.tradeSecurties.find((s) => s.symbol.code == this.order.symbol.id).availQuantity
                                //   this.order.symbol.availableQuantity = Number(shares);
                                //   this.isSymbolShareLoaded = true;
                                // });
                            }
                        }
                        else {
                            if (this.isSell) {
                                this.refreshSymbolShares();
                                //this.loadBuySellPortfolios();
                            }
                        }
                    }
                    else {
                    }
                });
                return yield modal.present();
            }
        });
    }
    // onClose() {
    //   if(this.symbol)  Streaming.unsubscribe(`/alinma/marketDepth/${this.symbol.id}`);
    //   this.symbol = null;
    //   this.symbolDetailsOpened= " ";
    // }
    validityChange() {
        // if (this.operation != 'edit') {
        if (this.validity == "UNTIL_DATE") {
            if (this.order.endDate == this.originalOrderEndDate) {
                this.order.endDate = this.order.endDate ? moment__WEBPACK_IMPORTED_MODULE_15__(this.order.endDate).format("YYYY-MM-DD") : moment__WEBPACK_IMPORTED_MODULE_15__().format("YYYY-MM-DD");
            }
            else {
                this.order.endDate = this.order.endDate ? moment__WEBPACK_IMPORTED_MODULE_15__().format("YYYY-MM-DD") : moment__WEBPACK_IMPORTED_MODULE_15__().format("YYYY-MM-DD");
            }
        }
        else if (this.validity == "WEEK") {
            this.order.endDate = moment__WEBPACK_IMPORTED_MODULE_15__().add(7, "d").format("YYYY-MM-DD");
        }
        else if (this.validity == "MONTH") {
            this.order.endDate = moment__WEBPACK_IMPORTED_MODULE_15__().add(29, "d").format("YYYY-MM-DD");
        }
        //  }
    }
    toggleSummaryInfo() {
        setTimeout(() => {
            this.expand = !this.expand;
        }, 100);
        // setTimeout(() => {
        //   this.visiblityClass = !this.visiblityClass;
        // }, 200);
    }
    ionViewDidLeave() {
        var _a;
        if ((_a = this.order) === null || _a === void 0 ? void 0 : _a.symbol) {
            _inma_models_symbol__WEBPACK_IMPORTED_MODULE_13__.Symbols.disconnectToStreamSymbol(this.order.symbol.id);
        }
        this.isSharedSymbol = false;
    }
    confirm(value) {
        this.order.endDate = moment__WEBPACK_IMPORTED_MODULE_15__(value).format("YYYY-MM-DD");
        this.dateTimeModal.dismiss();
    }
    reset() {
        this.dateTimeModal.dismiss();
    }
    orderDateDidChange() {
        this.order.endDate = this.order.endDate ? moment__WEBPACK_IMPORTED_MODULE_15__(this.order.endDate).format("YYYY-MM-DD") : null;
    }
};
OrderPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_22__.FormBuilder },
    { type: _providers_order_service__WEBPACK_IMPORTED_MODULE_5__.OrderService },
    { type: _portfolios_service__WEBPACK_IMPORTED_MODULE_3__.PortfoliosService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_23__.Platform },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_23__.ModalController },
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_17__.SharedDataService },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_24__.ChangeDetectorRef },
    { type: _symbols_service__WEBPACK_IMPORTED_MODULE_2__.SymbolsService },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_25__.TranslateService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_23__.PickerController }
];
OrderPage.propDecorators = {
    buyClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_24__.HostBinding, args: ["class.buy",] }],
    sellClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_24__.HostBinding, args: ["class.sell",] }],
    operation: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_24__.Input }],
    sharedSymbol: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_24__.Input }],
    sharedPortfolio: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_24__.Input }],
    sharedOrder: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_24__.Input }],
    previousPage: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_24__.Input }],
    commissionComponent: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_24__.ViewChild, args: [_commission_commission_component__WEBPACK_IMPORTED_MODULE_19__.CommissionComponent,] }],
    quantity: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_24__.ViewChild, args: ["quantity", { read: _angular_core__WEBPACK_IMPORTED_MODULE_24__.ElementRef },] }],
    selectAllQuantity: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_24__.ViewChild, args: ["selectAllQuantity", { read: _angular_core__WEBPACK_IMPORTED_MODULE_24__.ElementRef },] }],
    dateTimeModal: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_24__.ViewChild, args: ['dateTimeModal',] }]
};
OrderPage = OrderPage_1 = (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_24__.Component)({
        selector: "app-order",
        template: _order_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_order_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_22__.FormBuilder,
        _providers_order_service__WEBPACK_IMPORTED_MODULE_5__.OrderService,
        _portfolios_service__WEBPACK_IMPORTED_MODULE_3__.PortfoliosService,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_23__.Platform,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_23__.ModalController,
        src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_17__.SharedDataService,
        _angular_core__WEBPACK_IMPORTED_MODULE_24__.ChangeDetectorRef,
        _symbols_service__WEBPACK_IMPORTED_MODULE_2__.SymbolsService,
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_25__.TranslateService,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_23__.PickerController])
], OrderPage);

var OrderPageMode;
(function (OrderPageMode) {
    OrderPageMode[OrderPageMode["new"] = 0] = "new";
    OrderPageMode[OrderPageMode["edit"] = 1] = "edit";
    OrderPageMode[OrderPageMode["preset"] = 2] = "preset";
})(OrderPageMode || (OrderPageMode = {}));


/***/ }),

/***/ 87674:
/*!***********************************************************!*\
  !*** ./src/app/pages/order/summary/order-summary.page.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderSummaryPage": () => (/* binding */ OrderSummaryPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _order_summary_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./order-summary.page.html?ngResource */ 67085);
/* harmony import */ var _order_summary_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./order-summary.page.scss?ngResource */ 64858);
/* harmony import */ var ngx_navigation_with_data__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-navigation-with-data */ 5430);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_models_order__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/models/order */ 39344);
/* harmony import */ var _order_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../order.page */ 28798);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _inma_models_order_order_side__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/models/order/order-side */ 33926);










let OrderSummaryPage = class OrderSummaryPage {
    constructor(modalCtrl, navCtrl, router) {
        this.modalCtrl = modalCtrl;
        this.navCtrl = navCtrl;
        this.router = router;
        //! End of Refactor
        this.OrderSidesEnum = _inma_models_order_order_side__WEBPACK_IMPORTED_MODULE_4__.OrderSidesEnum;
        this.OrderPageMode = _order_page__WEBPACK_IMPORTED_MODULE_3__.OrderPageMode;
    }
    //! Refactor
    get buyClass() {
        var _a, _b;
        return ((_b = (_a = this.order) === null || _a === void 0 ? void 0 : _a.side) === null || _b === void 0 ? void 0 : _b.id) == _inma_models_order_order_side__WEBPACK_IMPORTED_MODULE_4__.OrderSidesEnum.buy;
    }
    ;
    get sellClass() {
        var _a, _b;
        return ((_b = (_a = this.order) === null || _a === void 0 ? void 0 : _a.side) === null || _b === void 0 ? void 0 : _b.id) == _inma_models_order_order_side__WEBPACK_IMPORTED_MODULE_4__.OrderSidesEnum.sell;
    }
    ;
    ngOnInit() {
        this.order = _order_page__WEBPACK_IMPORTED_MODULE_3__.OrderPage.order;
    }
    toHome() {
        this.navCtrl.navigate('main/tabs');
    }
    toOutstandingOrders() {
        this.modalCtrl.dismiss().then(() => {
            this.navCtrl.navigate('main/tabs/standing-orders', { selectedPorNav: this.order.portfolio.id });
        });
        // this.navCtrl.navigateBack(['standing-orders', { selectedPorNav: this.order.symbol.portfolioID }]);
    }
};
OrderSummaryPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ModalController },
    { type: ngx_navigation_with_data__WEBPACK_IMPORTED_MODULE_6__.NgxNavigationWithDataComponent },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router }
];
OrderSummaryPage.propDecorators = {
    buyClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.HostBinding, args: ['class.buy',] }],
    sellClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.HostBinding, args: ['class.sell',] }],
    order: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input }]
};
OrderSummaryPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'tadawul-order-summary',
        template: _order_summary_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_order_summary_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ModalController,
        ngx_navigation_with_data__WEBPACK_IMPORTED_MODULE_6__.NgxNavigationWithDataComponent,
        _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router])
], OrderSummaryPage);



/***/ }),

/***/ 48587:
/*!***************************************!*\
  !*** ./src/app/portfolios.service.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PortfoliosService": () => (/* binding */ PortfoliosService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_helpers_http_http_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/helpers/http/http-request */ 27576);




let PortfoliosService = class PortfoliosService {
    constructor(http) {
        this.http = http;
        this.MFDetails = `{"paginationInfo":{"wholeResultSetSize":2,"currentResultSetSize":2},"mutualFundPositionList":[{"id":"111111-000","type":"MF","arName":"صندوق الانماء للاسهم السعوديه","enName":"ALINMA SAUDI EQUITY FUND","units":{"currencyCode":null,"currencyRate":null,"amount":"5547.672381","formatedAmount":null,"localAmount":null},"avgPrice":{"currencyCode":null,"currencyRate":null,"amount":"3.300573","formatedAmount":null,"localAmount":null},"totalCost":{"currencyCode":null,"currencyRate":null,"amount":"18310.500000","formatedAmount":null,"localAmount":null},"lastValuationPrice":{"currencyCode":null,"currencyRate":null,"amount":"3.244604","formatedAmount":null,"localAmount":null},"marketValue":{"currencyCode":null,"currencyRate":null,"amount":"17999.999998","formatedAmount":null,"localAmount":null},"unrealizedGainLoss":{"currencyCode":null,"currencyRate":null,"amount":"-310.500002","formatedAmount":null,"localAmount":null},"unrealizedGainLossPer":{"currencyCode":null,"currencyRate":null,"amount":"-1.695748","formatedAmount":null,"localAmount":null},"mutualFundPer":{"currencyCode":null,"currencyRate":null,"amount":"99.557522","formatedAmount":null,"localAmount":null}},{"id":"999914-000","type":"MF","arName":"صندوق الإنماء مكة العقاري","enName":"Alinma Makkah Real Estate Fund","units":{"currencyCode":null,"currencyRate":null,"amount":"8.000000","formatedAmount":null,"localAmount":null},"avgPrice":{"currencyCode":null,"currencyRate":null,"amount":"11.375000","formatedAmount":null,"localAmount":null},"totalCost":{"currencyCode":null,"currencyRate":null,"amount":"91.000000","formatedAmount":null,"localAmount":null},"lastValuationPrice":{"currencyCode":null,"currencyRate":null,"amount":"10.000000","formatedAmount":null,"localAmount":null},"marketValue":{"currencyCode":null,"currencyRate":null,"amount":"80.000000","formatedAmount":null,"localAmount":null},"unrealizedGainLoss":{"currencyCode":null,"currencyRate":null,"amount":"-11.000000","formatedAmount":null,"localAmount":null},"unrealizedGainLossPer":{"currencyCode":null,"currencyRate":null,"amount":"-12.087912","formatedAmount":null,"localAmount":null},"mutualFundPer":{"currencyCode":null,"currencyRate":null,"amount":"0.442478","formatedAmount":null,"localAmount":null}}],"totalMarketValue":{"currencyCode":null,"currencyRate":null,"amount":"18079.999998","formatedAmount":null,"localAmount":null},"totalUnrealizedprofitLossAmt":{"currencyCode":null,"currencyRate":null,"amount":"-321.500002","formatedAmount":null,"localAmount":null},"totalCost":{"currencyCode":null,"currencyRate":null,"amount":"18401.500000","formatedAmount":null,"localAmount":null}}`;
    }
    getAllPortfolios() {
        let subject = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
        // if (this.userPortfolios) {
        //   subject.next(this.userPortfolios);
        // } else {
        this.http.request('/Portfolio/MyPortfolios/loadPortfolios', { portfolioType: '' }).subscribe((res) => {
            this.userPortfolios = res;
            subject.next(res);
        }, (err) => {
            subject.error(err);
        }, () => {
            subject.complete();
        });
        // }
        return subject.asObservable();
    }
    getPortfolioDetails(id) {
        let subject = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
        this.http.request('/Portfolio/MyPortfolios/loadAdvancedTradeSecurityList', { portfolioId: id }).subscribe((res) => {
            subject.next(res);
        }, (err) => {
            subject.error(err);
        }, () => {
            subject.complete();
        });
        return subject.asObservable();
    }
    getMFPortfolioDetails(id) {
        let subject = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
        this.http.request('/portfolio/MyPortfolios/getMFPortfolioPosition', { portfolioId: id }).subscribe((res) => {
            var _a, _b, _c, _d, _e;
            res._cashValue = Number(((_a = res === null || res === void 0 ? void 0 : res.availableBalance) === null || _a === void 0 ? void 0 : _a.amount.replace(/,/g, '')) || 0);
            res._unitValue = Number(((_b = res === null || res === void 0 ? void 0 : res.totalMarketValue) === null || _b === void 0 ? void 0 : _b.amount.replace(/,/g, '')) || 0);
            res._portfolioValue = res._cashValue + res._unitValue;
            if (res._cashValue == 0 && res._unitValue == 0) {
                res._cashPercentage = 0;
                res._unitPercentage = 0;
            }
            else {
                res._cashPercentage = (res._cashValue / res._portfolioValue) * 100;
                res._unitPercentage = (res._unitValue / res._portfolioValue) * 100;
            }
            res._buyingPower = ((_d = Number((_c = res.buyingPwrAmt) === null || _c === void 0 ? void 0 : _c.amount)) === null || _d === void 0 ? void 0 : _d.toFixed(2)) || "0.00";
            res._totalLoss = Number((_e = res.totalUnrealizedprofitLossAmt) === null || _e === void 0 ? void 0 : _e.amount.replace(/,/g, ''));
            subject.next(res);
        }, (err) => {
            subject.error(err);
        }, () => {
            subject.complete();
        });
        return subject.asObservable();
    }
    getPortfolioDetailsInfo(id) {
        let subject = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
        this.http.request('/Portfolio/MyPortfolios/loadPortfolioDetails', { portfolioId: id }).subscribe((res) => {
            res._cashValue = Number(res.actualBalance.replace(/,/g, ''));
            res._unitValue = Number(res.totalMrktValue.replace(/,/g, ''));
            res._portfolioValue = res._cashValue + res._unitValue;
            if (res._cashValue == 0 && res._unitValue == 0) {
                res._cashPercentage = 0;
                res._unitPercentage = 0;
            }
            else {
                res._cashPercentage = (res._cashValue / res._portfolioValue) * 100;
                res._unitPercentage = (res._unitValue / res._portfolioValue) * 100;
            }
            res._buyingPower = res.buyingPwrAmt;
            res._totalLoss = Number(res.totalProfitLoss.replace(/,/g, ''));
            subject.next(res);
        }, (err) => {
            subject.error(err);
        }, () => {
            subject.complete();
        });
        return subject.asObservable();
    }
    getPortfolioBuyingPower(id, type) {
        let subject = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
        this.http.request('/Portfolio/MyPortfolios/loadCustBuyingPwr', { portfolioId: id, portfolioType: type }).subscribe((res) => {
            subject.next(res);
        }, (err) => {
            subject.error(err);
        }, () => {
            subject.complete();
        });
        return subject.asObservable();
    }
};
PortfoliosService.ctorParameters = () => [
    { type: _inma_helpers_http_http_request__WEBPACK_IMPORTED_MODULE_0__.HttpRequestService }
];
PortfoliosService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:paramtypes", [_inma_helpers_http_http_request__WEBPACK_IMPORTED_MODULE_0__.HttpRequestService])
], PortfoliosService);



/***/ }),

/***/ 1098:
/*!********************************************!*\
  !*** ./src/app/providers/order.service.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderService": () => (/* binding */ OrderService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/helpers/http */ 36802);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ 86942);




let OrderService = class OrderService {
    constructor() { }
    getLiveBuyingPower(id, type) {
        const url = "/Portfolio/MyPortfolios/loadCustBuyingPwr";
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request(url, { portfolioId: id, portfolioType: type }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.map)((result) => {
            var _a, _b;
            return (_b = (_a = result === null || result === void 0 ? void 0 : result.buyingPwr) === null || _a === void 0 ? void 0 : _a.buyingPwrAmt) === null || _b === void 0 ? void 0 : _b.amount;
        }));
    }
};
OrderService.ctorParameters = () => [];
OrderService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: "root",
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:paramtypes", [])
], OrderService);



/***/ }),

/***/ 11852:
/*!*****************************************!*\
  !*** ./src/app/providers/validation.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ValidationProvider": () => (/* binding */ ValidationProvider)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _inma_strings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/strings */ 36782);




let ValidationProvider = class ValidationProvider extends _angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators {
    static number(control) {
        let value = control.value;
        value = value ? _inma_strings__WEBPACK_IMPORTED_MODULE_0__.Strings.normalizeArabicNumbers(value) : value;
        if (value && !value.match(/^([0-9\u0660-\u0669]*)(\.([0-9\u0660-\u0669]*))?$/)) {
            return {
                'number': value
            };
        }
        else
            return null;
    }
    static integer(control) {
        let value = control.value;
        value = value ? _inma_strings__WEBPACK_IMPORTED_MODULE_0__.Strings.normalizeArabicNumbers(value) : value;
        if (value && !value.match(/^([0-9\u0660-\u0669]+)$/)) {
            return {
                'integer': value
            };
        }
        else
            return null;
    }
    static max(max) {
        return (control) => {
            let value = control.value;
            value = value ? _inma_strings__WEBPACK_IMPORTED_MODULE_0__.Strings.normalizeArabicNumbers(value) : value;
            if (max && (parseFloat(value) > max)) {
                return {
                    'max': {
                        value: value
                    }
                };
            }
            else
                return null;
        };
    }
    static min(min) {
        return (control) => {
            let value = control.value;
            value = value ? _inma_strings__WEBPACK_IMPORTED_MODULE_0__.Strings.normalizeArabicNumbers(value) : value;
            if (min && (parseFloat(value) < min)) {
                return {
                    'min': {
                        value: value
                    }
                };
            }
            else
                return null;
        };
    }
    static equals(equalityFunction, isNumber = false) {
        return (control) => {
            let value = control.value;
            if (isNumber)
                value = value ? _inma_strings__WEBPACK_IMPORTED_MODULE_0__.Strings.normalizeArabicNumbers(value) : value;
            if (equalityFunction(value) == false) {
                return {
                    'equals': {
                        value: value
                    }
                };
            }
            else
                return null;
        };
    }
    static priceTick(control) {
        let value = control.value;
        value = value ? _inma_strings__WEBPACK_IMPORTED_MODULE_0__.Strings.normalizeArabicNumbers(value) : value;
        if (value) {
            var tick = 0;
            if (value.indexOf(".") != "-1") {
                var fractionString = value.slice(value.indexOf(".") + 1, value.length);
                if (fractionString) {
                    var fraction = parseFloat("0." + fractionString);
                    if (value < 10)
                        tick = 0.01;
                    else if (value >= 10 && value < 25)
                        tick = 0.02;
                    else if (value >= 25 && value < 50)
                        tick = 0.05;
                    else if (value >= 50 && value < 100)
                        tick = 0.1;
                    else if (value >= 100)
                        tick = 0.2;
                    if (!(((fraction * 1000) / (tick * 1000)) % 1 === 0))
                        return {
                            'priceTick': tick
                        };
                    else
                        return null;
                }
            }
            else
                return null;
        }
        else
            return null;
    }
};
ValidationProvider = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)()
], ValidationProvider);



/***/ }),

/***/ 4757:
/*!************************************!*\
  !*** ./src/app/symbols.service.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SymbolsService": () => (/* binding */ SymbolsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 92218);
/* harmony import */ var _helpers_http_http_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../helpers/http/http-request */ 27576);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let SymbolsService = class SymbolsService {
    constructor(http) {
        this.http = http;
    }
    getAllPortfoliosForASymbol(symbol) {
        let subject = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
        this.http.request('/Portfolio/MyPortfolios/loadSymbolPortfolios', { symbol: symbol }).subscribe((res) => {
            subject.next(res.symbolPortfoliosInfo);
        }, (err) => {
            subject.error(err);
        }, () => {
            subject.complete();
        });
        return subject.asObservable();
    }
};
SymbolsService.ctorParameters = () => [
    { type: _helpers_http_http_request__WEBPACK_IMPORTED_MODULE_0__.HttpRequestService }
];
SymbolsService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:paramtypes", [_helpers_http_http_request__WEBPACK_IMPORTED_MODULE_0__.HttpRequestService])
], SymbolsService);



/***/ }),

/***/ 39344:
/*!*****************************************!*\
  !*** ./src/app/🌱models/order/index.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Order": () => (/* reexport safe */ _order_model__WEBPACK_IMPORTED_MODULE_1__.Order),
/* harmony export */   "Orders": () => (/* reexport safe */ _orders_model__WEBPACK_IMPORTED_MODULE_0__.Orders),
/* harmony export */   "OrdersModel": () => (/* reexport safe */ _orders_model__WEBPACK_IMPORTED_MODULE_0__.OrdersModel)
/* harmony export */ });
/* harmony import */ var _orders_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./orders.model */ 65721);
/* harmony import */ var _order_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./order.model */ 69239);




/***/ }),

/***/ 18147:
/*!****************************************************!*\
  !*** ./src/app/🌱models/order/order-commission.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderCommission": () => (/* binding */ OrderCommission)
/* harmony export */ });
class OrderCommission {
    constructor(options) {
        if (options) {
            this.bankCommission = options.bankCommission;
            this.bankCommissionVAT = options.bankCommissionVAT;
            this.bankCommissionVATPercent = options.bankCommissionVATPercent;
            this.exchangeFees = options.exchangeFees;
            this.totalCommission = options.totalCommission;
            this.totalTradeAmount = options.totalTradeAmount;
        }
        else {
            this.bankCommission =
                this.bankCommissionVAT =
                    this.bankCommissionVATPercent =
                        this.exchangeFees =
                            this.totalCommission =
                                this.totalTradeAmount = '0';
        }
    }
}


/***/ }),

/***/ 32622:
/*!************************************************!*\
  !*** ./src/app/🌱models/order/order-period.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderPeriod": () => (/* binding */ OrderPeriod)
/* harmony export */ });
class OrderPeriod {
    constructor(options) { if (options) {
        this.id = options.id;
        this.name = options.value;
    } }
}


/***/ }),

/***/ 78710:
/*!************************************************************!*\
  !*** ./src/app/🌱models/order/order-request-parameters.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderRequestParameters": () => (/* binding */ OrderRequestParameters)
/* harmony export */ });
/* harmony import */ var _order_side__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./order-side */ 33926);

class OrderRequestParameters {
    constructor(symbolId, portfolioId, orderTypeId, tifTypeId, price, quantity, disclosedQuantity, endDate, orderSide) {
        this.symbolId = symbolId;
        this.portfolioId = portfolioId;
        this.orderTypeId = orderTypeId;
        this.tifTypeId = tifTypeId;
        this.price = price;
        this.quantity = quantity;
        this.disclosedQuantity = disclosedQuantity;
        this.endDate = endDate;
        if (orderSide == _order_side__WEBPACK_IMPORTED_MODULE_0__.OrderSidesEnum.buy)
            this.orderSide = "SPR";
        else
            this.orderSide = "SSL";
    }
}


/***/ }),

/***/ 33926:
/*!**********************************************!*\
  !*** ./src/app/🌱models/order/order-side.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderSide": () => (/* binding */ OrderSide),
/* harmony export */   "OrderSidesEnum": () => (/* binding */ OrderSidesEnum)
/* harmony export */ });
class OrderSide {
    constructor(options) { if (options) {
        this.id = options.id;
        this.name = options.value;
    } }
}
var OrderSidesEnum;
(function (OrderSidesEnum) {
    OrderSidesEnum["buy"] = "BUY";
    OrderSidesEnum["sell"] = "SELL";
})(OrderSidesEnum || (OrderSidesEnum = {}));


/***/ }),

/***/ 91153:
/*!************************************************!*\
  !*** ./src/app/🌱models/order/order-status.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderStatus": () => (/* binding */ OrderStatus)
/* harmony export */ });
class OrderStatus {
    constructor(options) { if (options) {
        this.id = options.id;
        this.name = options.value;
    } }
}


/***/ }),

/***/ 80380:
/*!*********************************************!*\
  !*** ./src/app/🌱models/order/order-tif.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderTif": () => (/* binding */ OrderTif)
/* harmony export */ });
class OrderTif {
    constructor(options) { if (options) {
        this.id = options.id;
        this.name = options.value;
    } }
}


/***/ }),

/***/ 83226:
/*!**********************************************!*\
  !*** ./src/app/🌱models/order/order-type.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderType": () => (/* binding */ OrderType),
/* harmony export */   "OrderTypesEnum": () => (/* binding */ OrderTypesEnum),
/* harmony export */   "StandingOrderTypesEnum": () => (/* binding */ StandingOrderTypesEnum),
/* harmony export */   "TifType": () => (/* binding */ TifType)
/* harmony export */ });
class OrderType {
    constructor(options) { if (options) {
        this.id = options.id;
        this.name = options.value;
    } }
}
var OrderTypesEnum;
(function (OrderTypesEnum) {
    OrderTypesEnum["market"] = "1";
    OrderTypesEnum["limit"] = "2";
})(OrderTypesEnum || (OrderTypesEnum = {}));
// Not normalized from Backend 
var StandingOrderTypesEnum;
(function (StandingOrderTypesEnum) {
    StandingOrderTypesEnum["market"] = "MARKET";
    StandingOrderTypesEnum["limit"] = "LIMIT";
})(StandingOrderTypesEnum || (StandingOrderTypesEnum = {}));
var TifType;
(function (TifType) {
    TifType["AtOpenening"] = "2";
    TifType["FillOrKill"] = "4";
    TifType["FillAndKill"] = "3";
})(TifType || (TifType = {}));


/***/ }),

/***/ 13985:
/*!**************************************************!*\
  !*** ./src/app/🌱models/order/order-validity.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderValidity": () => (/* binding */ OrderValidity)
/* harmony export */ });
var OrderValidity;
(function (OrderValidity) {
    OrderValidity["UntilDate"] = "UNTIL_DATE";
    OrderValidity["Week"] = "WEEK";
    OrderValidity["Month"] = "MONTH";
})(OrderValidity || (OrderValidity = {}));


/***/ }),

/***/ 69239:
/*!***********************************************!*\
  !*** ./src/app/🌱models/order/order.model.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Order": () => (/* binding */ Order)
/* harmony export */ });
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! moment */ 56908);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _portfolio__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../portfolio */ 65082);
/* harmony import */ var _order_type__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./order-type */ 83226);
/* harmony import */ var _order_commission__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./order-commission */ 18147);
/* harmony import */ var _order_tif__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./order-tif */ 80380);
/* harmony import */ var _order_side__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./order-side */ 33926);
/* harmony import */ var _order_status__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./order-status */ 91153);
/* harmony import */ var _symbol__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../symbol */ 61202);








class Order {
    constructor(options) {
        var _a;
        this.endDate = moment__WEBPACK_IMPORTED_MODULE_0__().format("YYYY-MM-DD");
        if (options) {
            this.side = new _order_side__WEBPACK_IMPORTED_MODULE_5__.OrderSide({ id: options.orderSide, value: options.orderSideId });
            _portfolio__WEBPACK_IMPORTED_MODULE_1__.Portfolios.findById(options.portfolioNumber).subscribe(p => this.portfolio = p);
            // this.portfolio = new Portfolio({ id: options.portfolioNumber, value: options.portfolioNumber })
            this.symbol = new _symbol__WEBPACK_IMPORTED_MODULE_7__.Symbol({ id: options.symbolId || ((_a = options.symbole) === null || _a === void 0 ? void 0 : _a.code), name: options.symbolName, availQuantity: 0 });
            this.type = new _order_type__WEBPACK_IMPORTED_MODULE_2__.OrderType({ id: options.orderType == _order_type__WEBPACK_IMPORTED_MODULE_2__.StandingOrderTypesEnum.market ? _order_type__WEBPACK_IMPORTED_MODULE_2__.OrderTypesEnum.market : _order_type__WEBPACK_IMPORTED_MODULE_2__.OrderTypesEnum.limit, value: options.orderTypeId });
            let averagePrice = parseFloat(options.avaragePrice);
            this.price = averagePrice ? averagePrice : parseFloat(options.orderPrice);
            this.quantity = parseFloat(options.orderQuantity ? options.orderQuantity : "");
            this.originalQuantity = parseFloat(options.remainigQuantity ? options.remainigQuantity : "");
            this.remainingQuantity = parseFloat(options.remainigQuantity ? options.remainigQuantity : "");
            this.disclosedQuantity = options.disclosedQuantityMin ? parseFloat(options.disclosedQuantityMin) : null;
            let endDate = new Date(options.orderEndDate.gregorianDate);
            this.endDate = moment__WEBPACK_IMPORTED_MODULE_0__(endDate).format('YYYY-MM-DD');
            this.referenceNumber = options.omsRefNumber;
            this.tif = new _order_tif__WEBPACK_IMPORTED_MODULE_4__.OrderTif({ id: options.tifType, value: options.tifTypeId });
            let totalCommission = parseFloat(options.orderCommission) || 0;
            let orderAmount = parseFloat(options.executedTotalAmount) || (this.quantity * this.price) || 0;
            let totalAmount = orderAmount + totalCommission;
            this.commission = new _order_commission__WEBPACK_IMPORTED_MODULE_3__.OrderCommission({ bankCommission: options.bankCommission, bankCommissionVAT: options.taxInfo ? options.taxInfo.taxAmt : "", bankCommissionVATPercent: options.taxInfo ? options.taxInfo.taxPercen : "", exchangeFees: options.tadawulCommission, totalCommission: options.orderCommission, totalTradeAmount: totalAmount });
            this.commission.totalTradeAmount = (Math.round(parseFloat(this.commission.totalTradeAmount) * 100) / 100).toString();
            this.status = new _order_status__WEBPACK_IMPORTED_MODULE_6__.OrderStatus({ id: options.orderStatus, value: options.orderStatusId });
            this.executedQuantity = parseFloat(options.executedQuantity ? options.executedQuantity : "0");
            let startDate = new Date(options.orderStartDate.gregorianDate);
            this.date = moment__WEBPACK_IMPORTED_MODULE_0__(startDate).format("YYYY-MM-DD");
            this.time = moment__WEBPACK_IMPORTED_MODULE_0__(startDate).format("hh:mmA");
            this.dateTime = moment__WEBPACK_IMPORTED_MODULE_0__(startDate).format("YYYY-MM-DDTHH:mm:ss");
            this.authorized = options.mrktAuthorized == 'YES' ? true : false;
            this.product = options.product;
        }
        else {
            this.side = new _order_side__WEBPACK_IMPORTED_MODULE_5__.OrderSide();
            this.portfolio = null; //new Portfolio()
            this.symbol = new _symbol__WEBPACK_IMPORTED_MODULE_7__.Symbol();
            this.type = new _order_type__WEBPACK_IMPORTED_MODULE_2__.OrderType();
            this.tif = new _order_tif__WEBPACK_IMPORTED_MODULE_4__.OrderTif();
            this.commission = new _order_commission__WEBPACK_IMPORTED_MODULE_3__.OrderCommission();
            this.status = new _order_status__WEBPACK_IMPORTED_MODULE_6__.OrderStatus();
        }
    }
    get quantity() {
        return this._quantity;
    }
    set quantity(value) {
        this._quantity = value;
    }
}


/***/ }),

/***/ 65721:
/*!************************************************!*\
  !*** ./src/app/🌱models/order/orders.model.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Orders": () => (/* binding */ Orders),
/* harmony export */   "OrdersModel": () => (/* binding */ OrdersModel)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! moment */ 56908);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs */ 64139);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var _order_type__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./order-type */ 83226);
/* harmony import */ var _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/helpers/http */ 36802);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs/operators */ 80522);
/* harmony import */ var _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/helpers/cached */ 569);
/* harmony import */ var _order_status__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./order-status */ 91153);
/* harmony import */ var _order_side__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./order-side */ 33926);
/* harmony import */ var _order_period__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./order-period */ 32622);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! . */ 39344);
/* harmony import */ var _order_tif__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./order-tif */ 80380);
/* harmony import */ var _order_commission__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./order-commission */ 18147);
/* harmony import */ var _order_request_parameters__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./order-request-parameters */ 78710);
/* harmony import */ var _order_validity__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./order-validity */ 13985);
/* harmony import */ var _inma_helpers_date__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @inma/helpers/date */ 70314);
/* harmony import */ var _symbol__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../symbol */ 61202);

















// import { diff, addedDiff, deletedDiff, updatedDiff, detailedDiff } from 'deep-object-diff';
class OrdersModel {
    // @cached
    get types() {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request("/Portfolio/ManageOrders/loadOrderTypes").pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)((result) => {
            const orderTypes = new Array();
            for (const obj of result) {
                if (obj && obj.value == 'Limited price')
                    obj.value = 'Limit price';
                orderTypes.push(new _order_type__WEBPACK_IMPORTED_MODULE_1__.OrderType(obj));
            }
            return orderTypes;
        }));
    }
    get mfTypes() {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request("/Portfolio/ManageOrders/loadMFOrderTypes").pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)((result) => {
            const mfTypes = new Array();
            for (const obj of result)
                mfTypes.push(new _order_type__WEBPACK_IMPORTED_MODULE_1__.OrderType(obj));
            return mfTypes;
        }));
    }
    get statuses() {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request("/Portfolio/OrdersSearch/loadOrderStatus").pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)((result) => {
            const statuses = new Array();
            for (const s of result)
                statuses.push(new _order_status__WEBPACK_IMPORTED_MODULE_4__.OrderStatus(s));
            return statuses;
        }));
    }
    get mfOrderStatuses() {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request("/Portfolio/OrdersSearch/loadMFOrderStatus").pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)((result) => {
            const mfOrderStatuses = new Array();
            for (const s of result)
                mfOrderStatuses.push(new _order_status__WEBPACK_IMPORTED_MODULE_4__.OrderStatus(s));
            return mfOrderStatuses;
        }));
    }
    get sides() {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request("/Portfolio/OrdersSearch/loadOrderSides").pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)((result) => {
            const sides = new Array();
            for (const s of result)
                sides.push(new _order_side__WEBPACK_IMPORTED_MODULE_5__.OrderSide(s));
            return sides;
        }));
    }
    get periods() {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request("/Portfolio/OrdersSearch/loadPeriods").pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)((result) => {
            const periods = new Array();
            for (const p of result)
                periods.push(new _order_period__WEBPACK_IMPORTED_MODULE_6__.OrderPeriod(p));
            return periods;
        }));
    }
    search(options) {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request("/Portfolio/OrdersSearch/searchOrders", options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)((result) => {
            const searchResults = new Array();
            _symbol__WEBPACK_IMPORTED_MODULE_13__.Symbols.all.subscribe((allSymbols) => {
                for (const order of result || []) {
                    const o = new ___WEBPACK_IMPORTED_MODULE_7__.Order(order);
                    o.backendOrder = order;
                    let symbol = allSymbols.find((s) => s.id == o.symbol.id);
                    o._symbolShortName = symbol.id + ' - ' + symbol.sortAbbreviation;
                    searchResults.push(o);
                }
            });
            return searchResults;
        }));
    }
    loadTifs(orderType) {
        return (orderType === null || orderType === void 0 ? void 0 : orderType.id)
            ? _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request("/Portfolio/ManageOrders/loadTIFTypes", { orderTypeId: orderType.id }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)((result) => {
                const orderTifs = new Array();
                for (const obj of result)
                    orderTifs.push(new _order_tif__WEBPACK_IMPORTED_MODULE_8__.OrderTif(obj));
                return orderTifs;
            }))
            : (0,rxjs__WEBPACK_IMPORTED_MODULE_15__.of)([]);
    }
    loadPriceRange(symbol) {
        return symbol
            ? _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request("/Portfolio/ManageOrders/loadPriceRange", { symbolId: symbol })
            : (0,rxjs__WEBPACK_IMPORTED_MODULE_15__.of)(null);
    }
    getOutstandingOrders(portfolioId) {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request("/Portfolio/OutstandingOrders/loadOrders", { portfolioId: portfolioId }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)((result) => {
            const outstandingOrders = new Array();
            for (const obj of result) {
                const o = new ___WEBPACK_IMPORTED_MODULE_7__.Order(obj);
                o.backendOrder = obj;
                outstandingOrders.push(o);
            }
            return outstandingOrders;
        }));
    }
    mutualFundOutstandingOrders(portfolioId) {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request("/mutualFunds/MutualFundsService/getOutstandingOrders", { portfolioId: portfolioId }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)((result) => {
            for (let i = 0; i < result.length; i++) {
                if (result[i].orderStartDate)
                    result[i].orderStartDate.gregorianDate = (0,_inma_helpers_date__WEBPACK_IMPORTED_MODULE_12__.formatDate)(result[i].orderStartDate.gregorianDate);
                if (result[i].valuationDate)
                    result[i].valuationDate.gregorianDate = (0,_inma_helpers_date__WEBPACK_IMPORTED_MODULE_12__.formatDate)(result[i].valuationDate.gregorianDate);
            }
            return result;
        }));
    }
    getOrderCommission(order) {
        const params = this.createOrderRequest(order);
        if (params) {
            return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request("/Portfolio/ManageOrders/getOrderCommission", params).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)((result) => {
                order.commission = new _order_commission__WEBPACK_IMPORTED_MODULE_9__.OrderCommission(result);
                return order;
            }));
        }
        else {
            order.commission = new _order_commission__WEBPACK_IMPORTED_MODULE_9__.OrderCommission();
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_15__.of)(order);
        }
    }
    create(order) {
        const params = this.createOrderRequest(order);
        let subaction;
        if (order.side.id == _order_side__WEBPACK_IMPORTED_MODULE_5__.OrderSidesEnum.buy)
            subaction = "buy";
        else
            subaction = "sell";
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request("/Portfolio/ManageOrders/" + subaction, params).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)((result) => {
            setTimeout(() => {
                var _a;
                (_a = order === null || order === void 0 ? void 0 : order.portfolio) === null || _a === void 0 ? void 0 : _a.refresh();
            }, 0);
            return result;
        }));
    }
    createOrderRequest(order) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j;
        let requestParameters = null;
        if (order.portfolio && order.symbol)
            requestParameters = new _order_request_parameters__WEBPACK_IMPORTED_MODULE_10__.OrderRequestParameters((_a = order.symbol) === null || _a === void 0 ? void 0 : _a.id, (_b = order.portfolio) === null || _b === void 0 ? void 0 : _b.id, (_c = order.type) === null || _c === void 0 ? void 0 : _c.id, ((_d = order.tif) === null || _d === void 0 ? void 0 : _d.id) || "0", (_e = order.price) === null || _e === void 0 ? void 0 : _e.toString(), (_f = order.remainingQuantity) === null || _f === void 0 ? void 0 : _f.toString(), (_g = order.disclosedQuantity) === null || _g === void 0 ? void 0 : _g.toString(), (_h = order.endDate) === null || _h === void 0 ? void 0 : _h.toString(), (_j = order.side) === null || _j === void 0 ? void 0 : _j.id);
        return requestParameters;
    }
    delete(order) {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request("/Portfolio/OutstandingOrders/deleteOrder", {
            referenceNumber: order.referenceNumber,
            portfolioId: order.portfolio.id,
        }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)((result) => {
            setTimeout(() => {
                // this action navigate to symbol details page 
                // order?.portfolio?.refresh();
            }, 0);
            return !!result;
        }));
    }
    edit(order) {
        const orderValidatyDate = new Date(order.endDate);
        const validatyDateString = moment__WEBPACK_IMPORTED_MODULE_0__(orderValidatyDate).format("MMM DD, YYYY h:mm:ss A");
        const orderStartDate = new Date(order.date);
        const startDateString = moment__WEBPACK_IMPORTED_MODULE_0__(orderStartDate).format("MMM DD, YYYY h:mm:ss A");
        let tif;
        let symbolName;
        return this.loadTifs(order.type).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)(tifs => {
            tifs.forEach(t => { var _a; if ((t === null || t === void 0 ? void 0 : t.id) == ((_a = order.tif) === null || _a === void 0 ? void 0 : _a.id))
                tif = t; });
        })).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.mergeMap)(() => {
            return order.symbol.name.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)(name => symbolName = name));
        })).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.mergeMap)(() => {
            var _a, _b, _c, _d, _e, _f, _g, _h;
            // const original =
            //   {
            //       "orderTrade": {
            //           "symbolId": "1150",
            //           "symbolName": "1150 - Alinma Bank",
            //           "portfolioNumber": "190555-1",
            //           "orderType": "LIMIT",
            //           "orderTypeId": "Limited price",
            //           "avaragePrice": "",
            //           "omsRefNumber": "20329C8JMD",
            //           "orderSide": "BUY",
            //           "orderSideId": "Buy",
            //           "disclosedQuantityMin": "",
            //           "executedQuantity": "0",
            //           "orderEndDate": {
            //               "gregorianDate": "Nov 25, 2020 3:00:00 AM"
            //           },
            //           "tifType": "GOOD_TILL_DATE",
            //           "tifTypeId": null,
            //           "orderCommission": "0.00",
            //           "executedTotalAmount": "1",
            //           "orderStatus": "NEW",
            //           "orderStatusId": "New",
            //           "orderStartDate": {
            //               "gregorianDate": "Nov 24, 2020 3:00:00 AM"
            //           },
            //           "mrktAuthorized": "YES",
            //           "product": "LOCAL_EQUITY",
            //           "remainigQuantity": "1"
            //       }
            //   };
            const beOrder = order.backendOrder;
            const updatedObj = {
                orderTrade: {
                    symbolId: beOrder.symbolId || ((_a = beOrder.symbole) === null || _a === void 0 ? void 0 : _a.code),
                    symbolName: beOrder.symbolName,
                    portfolioNumber: beOrder.portfolioNumber,
                    orderType: ((_b = order.type) === null || _b === void 0 ? void 0 : _b.name) == _order_type__WEBPACK_IMPORTED_MODULE_1__.OrderTypesEnum.market
                        ? _order_type__WEBPACK_IMPORTED_MODULE_1__.StandingOrderTypesEnum.market
                        : _order_type__WEBPACK_IMPORTED_MODULE_1__.StandingOrderTypesEnum.limit,
                    orderTypeId: (_c = order.type) === null || _c === void 0 ? void 0 : _c.id,
                    // orderType: "LIMIT",
                    // orderTypeId: "Limited price",
                    avaragePrice: "",
                    omsRefNumber: order.referenceNumber,
                    orderSide: beOrder.orderSide,
                    orderSideId: beOrder.orderSideId,
                    // "orderSide": "BUY",
                    // "orderSideId": "Buy",
                    orderEndDate: { gregorianDate: validatyDateString },
                    tifType: beOrder === null || beOrder === void 0 ? void 0 : beOrder.tifType,
                    tifTypeId: null,
                    // "tifType": "GOOD_TILL_DATE",
                    // "tifTypeId": null,
                    orderCommission: (_d = order.commission) === null || _d === void 0 ? void 0 : _d.bankCommission,
                    executedTotalAmount: (_e = order.price) === null || _e === void 0 ? void 0 : _e.toString(),
                    orderStatus: beOrder === null || beOrder === void 0 ? void 0 : beOrder.orderStatus,
                    orderStatusId: beOrder === null || beOrder === void 0 ? void 0 : beOrder.orderStatusId,
                    // "orderStatus": "NEW",
                    // "orderStatusId": "New",
                    disclosedQuantityMin: (_f = order.disclosedQuantity) === null || _f === void 0 ? void 0 : _f.toString(),
                    executedQuantity: (_g = order.executedQuantity) === null || _g === void 0 ? void 0 : _g.toString(),
                    // "disclosedQuantityMin": "",
                    // "executedQuantity": "0",
                    orderStartDate: { gregorianDate: startDateString },
                    mrktAuthorized: order.authorized ? "YES" : "NO",
                    product: order.product || "LOCAL_EQUITY",
                    remainigQuantity: (order.remainingQuantity != order.originalQuantity) ? order.remainingQuantity + '' : null,
                    //orderQuantity: order.quantity?.toString()
                    quantityBeforeUpdate: (_h = order.originalQuantity) === null || _h === void 0 ? void 0 : _h.toString(),
                    orderQuantity: (order.remainingQuantity != order.originalQuantity) ? order.remainingQuantity + '' : null
                },
            };
            // const x = detailedDiff({orderTrade: beOrder}, updatedObj);
            // console.log((x as any).updated.orderTrade);
            // debugger
            return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_2__.Http.request("/Portfolio/OutstandingOrders/updateOrder", updatedObj).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)((result) => {
                setTimeout(() => {
                    var _a;
                    (_a = order.portfolio) === null || _a === void 0 ? void 0 : _a.refresh();
                }, 0);
                return !!result;
            }));
        }));
    }
    get validities() {
        return [_order_validity__WEBPACK_IMPORTED_MODULE_11__.OrderValidity.UntilDate, _order_validity__WEBPACK_IMPORTED_MODULE_11__.OrderValidity.Week, _order_validity__WEBPACK_IMPORTED_MODULE_11__.OrderValidity.Month];
    }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([
    _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_3__.cached,
    (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", rxjs__WEBPACK_IMPORTED_MODULE_18__.Observable),
    (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:paramtypes", [])
], OrdersModel.prototype, "mfTypes", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([
    _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_3__.cached,
    (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", rxjs__WEBPACK_IMPORTED_MODULE_18__.Observable),
    (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:paramtypes", [])
], OrdersModel.prototype, "statuses", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([
    _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_3__.cached,
    (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", rxjs__WEBPACK_IMPORTED_MODULE_18__.Observable),
    (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:paramtypes", [])
], OrdersModel.prototype, "mfOrderStatuses", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([
    _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_3__.cached,
    (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", rxjs__WEBPACK_IMPORTED_MODULE_18__.Observable),
    (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:paramtypes", [])
], OrdersModel.prototype, "sides", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([
    _inma_helpers_cached__WEBPACK_IMPORTED_MODULE_3__.cached,
    (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", rxjs__WEBPACK_IMPORTED_MODULE_18__.Observable),
    (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:paramtypes", [])
], OrdersModel.prototype, "periods", null);
const Orders = new OrdersModel();


/***/ }),

/***/ 27576:
/*!******************************************!*\
  !*** ./src/helpers/http/http-request.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HttpRequestService": () => (/* binding */ HttpRequestService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/environment */ 80960);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs */ 61555);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs */ 64139);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs */ 24383);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! rxjs */ 9906);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! rxjs */ 66587);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! rxjs/operators */ 19019);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! rxjs/operators */ 47418);
/* harmony import */ var _response__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./response */ 30109);
/* harmony import */ var _http_device_info__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./http-device-info */ 70802);
/* harmony import */ var _http_request_header__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./http-request-header */ 55401);
/* harmony import */ var _http_error__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./http-error */ 30081);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common/http */ 28784);
/* harmony import */ var _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @inma/helpers/injector */ 19753);
/* harmony import */ var _console__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../console */ 56031);
/* harmony import */ var _emojis__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../emojis */ 79461);
/* harmony import */ var _environments_mocks_mocks__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../environments/mocks/mocks */ 94474);
/* harmony import */ var _ionic_native_http_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/http/ngx */ 44719);
/* harmony import */ var _ionic_native_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/core */ 68751);
/* harmony import */ var src_environments_mocks_authentication_mocks__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/environments/mocks/authentication.mocks */ 84110);
/* harmony import */ var _settings__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../settings */ 96892);
/* harmony import */ var src_app_app_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/app.component */ 20721);



















// Resolution for the buyingPower come as undefined
// Resolution for Portfolios come as emptyArray
// Adding mocks for mutualFunds for portfolios that does not have them
let HttpRequestService = class HttpRequestService {
    constructor() {
        this.sessionExpirySubject = new rxjs__WEBPACK_IMPORTED_MODULE_14__.ReplaySubject();
        this.requestsSubjects = new Map();
        this.httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_15__.HttpHeaders({
                "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
                "Accept-Charset": "UTF-8",
                responseType: "json",
            }),
            withCredentials: true,
        };
        this.ـisNativeHttpAvailable = null;
        this.deviceInfo = new _http_device_info__WEBPACK_IMPORTED_MODULE_2__.HttpDeviceInfo();
        this.requestHeader = new _http_request_header__WEBPACK_IMPORTED_MODULE_3__.HttpRequestHeader(this.deviceInfo);
        this.httpError = new _http_error__WEBPACK_IMPORTED_MODULE_4__.HttpError();
    }
    get httpClient() {
        return _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_5__.Injector.get(_angular_common_http__WEBPACK_IMPORTED_MODULE_15__.HttpClient);
    }
    get httpNative() {
        return _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_5__.Injector.get(_ionic_native_http_ngx__WEBPACK_IMPORTED_MODULE_9__.HTTP);
    }
    request(endPoint, params = {}, options) {
        var _a, _b, _c, _d;
        var calleeStack;
        if (_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.isDevelopment)
            calleeStack = new Error().stack;
        const requestKey = endPoint + JSON.stringify(params);
        if (this.requestsSubjects.has(requestKey))
            return this.requestsSubjects.get(requestKey);
        else {
            const requestHeader = this.requestHeader.get(endPoint);
            const headerParam = JSON.stringify(requestHeader);
            const bodyParam = JSON.stringify(params);
            const requestSubject = new rxjs__WEBPACK_IMPORTED_MODULE_14__.ReplaySubject(1);
            this.requestsSubjects.set(requestKey, requestSubject);
            //# region Logging [request]
            if (_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.isLoggingAjaxEnabled) {
                _console__WEBPACK_IMPORTED_MODULE_6__.Console.gradientSeparator(_console__WEBPACK_IMPORTED_MODULE_6__.Console.Gradients.DeepBlue);
                _console__WEBPACK_IMPORTED_MODULE_6__.Console["default"]({ color: _console__WEBPACK_IMPORTED_MODULE_6__.Console.Colors.BlueDeepSky });
                _console__WEBPACK_IMPORTED_MODULE_6__.Console.printWithObject({
                    params,
                    baseURL: _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.webserviceURL,
                    timestamp: Date.now(),
                    header: { object: requestHeader, collapsed: true },
                    trace: calleeStack,
                }, {}, { message: `${_emojis__WEBPACK_IMPORTED_MODULE_7__.Emoji.Honeybee} [request](` }, { message: endPoint, bold: true }, { message: `)` });
            }
            //#endregion
            let httpRequestObservable = null;
            let mockedRequestObservable = null;
            if (_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.isDevelopment && ((_a = _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment === null || _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment === void 0 ? void 0 : _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.mocking) === null || _a === void 0 ? void 0 : _a.enabled))
                if (_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.isBiometricMockingEnabled &&
                    !_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.mocking._biometricMockingInjected) {
                    _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.mocking._biometricMockingInjected = true;
                    (_c = (_b = _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.mocking) === null || _b === void 0 ? void 0 : _b.mocks) === null || _c === void 0 ? void 0 : _c.push(...Object.keys(src_environments_mocks_authentication_mocks__WEBPACK_IMPORTED_MODULE_11__.AuthenticationMocks));
                }
            if ((_d = _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.mocking.mocks) === null || _d === void 0 ? void 0 : _d.find((mock) => mock.toLowerCase().trim() === endPoint.toLowerCase())) {
                const normalizedEndPoint = Object.keys(_environments_mocks_mocks__WEBPACK_IMPORTED_MODULE_8__.MockedWebService).find((key) => key.toLowerCase() === endPoint.toLowerCase());
                const mockedResponse = _environments_mocks_mocks__WEBPACK_IMPORTED_MODULE_8__.MockedWebService === null || _environments_mocks_mocks__WEBPACK_IMPORTED_MODULE_8__.MockedWebService === void 0 ? void 0 : _environments_mocks_mocks__WEBPACK_IMPORTED_MODULE_8__.MockedWebService[normalizedEndPoint];
                if (mockedResponse)
                    mockedRequestObservable = (0,rxjs__WEBPACK_IMPORTED_MODULE_16__.of)(mockedResponse);
                else
                    console.error(`${_emojis__WEBPACK_IMPORTED_MODULE_7__.Emoji.Bank} Mock was not found, fallback to HTTP call !`);
            }
            // if (!mockedRequestObservable)
            //   httpRequestObservable = this.httpClient.post<Response<T>>(Environment.webserviceURL, requestParams, this.httpOptions);
            if (!mockedRequestObservable) {
                if (!this.isNativeHttpAvailable()) {
                    const requestParams = "Header=" +
                        encodeURIComponent(headerParam) +
                        "&Body=" +
                        encodeURIComponent(bodyParam);
                    httpRequestObservable = this.httpClient.post(_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.webserviceURL, requestParams, this.httpOptions);
                }
                else {
                    const requestParamsNative = {
                        Header: headerParam,
                        Body: bodyParam,
                    };
                    window.httpNative = this.httpNative;
                    this.httpNative.setDataSerializer("urlencoded");
                    httpRequestObservable = (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.from)(this.httpNative.post(_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.webserviceURL, requestParamsNative, {
                        responseType: "json",
                        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
                        "Accept-Charset": "UTF-8"
                    })).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.map)((res) => JSON.parse(res === null || res === void 0 ? void 0 : res.data)));
                }
            }
            const languageIndex = _settings__WEBPACK_IMPORTED_MODULE_12__.Settings.languageAsString == "ar" ? 0 : 1;
            (mockedRequestObservable || httpRequestObservable)
                .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.timeout)(_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.http.timeout), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.map)((httpResponse) => {
                var _a, _b, _c;
                this.requestsSubjects.delete(requestKey);
                const response = new _response__WEBPACK_IMPORTED_MODULE_1__.Response();
                response.status = httpResponse === null || httpResponse === void 0 ? void 0 : httpResponse.status;
                response.result = httpResponse === null || httpResponse === void 0 ? void 0 : httpResponse.result;
                response.msg = httpResponse === null || httpResponse === void 0 ? void 0 : httpResponse.msg;
                // if (response?.result && typeof response.result == "object") (<any>response.result)._message = httpResponse?.msg;
                //# region Logging [response]
                if (_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.isLoggingAjaxEnabled) {
                    if (mockedRequestObservable) {
                        _console__WEBPACK_IMPORTED_MODULE_6__.Console.gradientSeparator(_console__WEBPACK_IMPORTED_MODULE_6__.Console.Gradients.SunnyMorning);
                        _console__WEBPACK_IMPORTED_MODULE_6__.Console["default"]({ color: _console__WEBPACK_IMPORTED_MODULE_6__.Console.Colors.Yellow });
                        _console__WEBPACK_IMPORTED_MODULE_6__.Console.printWithObject({
                            response: response === null || response === void 0 ? void 0 : response.result,
                            params,
                            baseURL: _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.webserviceURL,
                            timestamp: Date.now(),
                            header: { object: requestHeader, collapsed: true },
                            trace: calleeStack,
                        }, {}, { message: `${_emojis__WEBPACK_IMPORTED_MODULE_7__.Emoji.Bank} [mocked](` }, { message: endPoint, bold: true }, { message: `)` });
                    }
                    else {
                        // console.log(endPoint);
                        _console__WEBPACK_IMPORTED_MODULE_6__.Console.gradientSeparator(_console__WEBPACK_IMPORTED_MODULE_6__.Console.Gradients.Lush);
                        _console__WEBPACK_IMPORTED_MODULE_6__.Console["default"]({ color: _console__WEBPACK_IMPORTED_MODULE_6__.Console.Colors.GreenMalachite });
                        const timestamp = new Date().toTimeString().split(" ")[0];
                        _console__WEBPACK_IMPORTED_MODULE_6__.Console.printWithObject({
                            result: response === null || response === void 0 ? void 0 : response.result,
                            response: JSON.stringify(httpResponse),
                            params,
                            baseURL: _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.webserviceURL,
                            timestamp: timestamp,
                            header: { object: requestHeader, collapsed: true },
                            trace: calleeStack,
                        }, {}, { message: `${_emojis__WEBPACK_IMPORTED_MODULE_7__.Emoji.Seedling} [response](` }, { message: endPoint, bold: true }, { message: `)` });
                    }
                }
                //#endregion
                if ((options === null || options === void 0 ? void 0 : options.presentMessage) && ((_a = response === null || response === void 0 ? void 0 : response.msg) === null || _a === void 0 ? void 0 : _a.msgText)) {
                    src_app_app_component__WEBPACK_IMPORTED_MODULE_13__.AppComponent.showError((_b = response === null || response === void 0 ? void 0 : response.msg) === null || _b === void 0 ? void 0 : _b.msgText);
                }
                if (response.isSuccess()) {
                    if (options === null || options === void 0 ? void 0 : options.fullResponse)
                        return [response === null || response === void 0 ? void 0 : response.result, response === null || response === void 0 ? void 0 : response.msg];
                    else
                        return response === null || response === void 0 ? void 0 : response.result;
                }
                else {
                    if (((_c = response === null || response === void 0 ? void 0 : response.msg) === null || _c === void 0 ? void 0 : _c.msgCode) === "SMRT0001") {
                        // MenuComponent.logout(
                        //   false,
                        //   HttpTranslations.errors.sessionExpiry[languageIndex] ||
                        //     response?.msg?.msgText
                        // );
                        src_app_app_component__WEBPACK_IMPORTED_MODULE_13__.AppComponent.goToLogoutPage();
                    }
                    else
                        throw response;
                }
            }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_20__.catchError)((err) => {
                var _a, _b, _c;
                if ((_a = err === null || err === void 0 ? void 0 : err.msg) === null || _a === void 0 ? void 0 : _a.msgText)
                    src_app_app_component__WEBPACK_IMPORTED_MODULE_13__.AppComponent.showError((_b = err === null || err === void 0 ? void 0 : err.msg) === null || _b === void 0 ? void 0 : _b.msgText);
                if (calleeStack) {
                    err.request = {
                        url: endPoint,
                        baseURL: _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.webserviceURL,
                        params,
                        headerParams: headerParam,
                    };
                    _console__WEBPACK_IMPORTED_MODULE_6__.Console.separator({ background: "#007b00" });
                    _console__WEBPACK_IMPORTED_MODULE_6__.Console.separator({ background: "#24e0b8" });
                    _console__WEBPACK_IMPORTED_MODULE_6__.Console.separator({ background: "#ffcc51" });
                    console.log(err.message);
                    console.dir(err);
                    console.log(calleeStack);
                    _console__WEBPACK_IMPORTED_MODULE_6__.Console.separator({ background: "#ffcc51" });
                    _console__WEBPACK_IMPORTED_MODULE_6__.Console.separator({ background: "#ff8b76" });
                    _console__WEBPACK_IMPORTED_MODULE_6__.Console.separator({ background: "#ff3031" });
                }
                let errorMessage = "";
                if (err instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_15__.HttpErrorResponse) {
                    errorMessage = this.httpError.handle(err);
                    if (errorMessage === "networkError") {
                        src_app_app_component__WEBPACK_IMPORTED_MODULE_13__.AppComponent.showError(HttpTranslations.errors[errorMessage][languageIndex]);
                    }
                }
                else if (err instanceof rxjs__WEBPACK_IMPORTED_MODULE_21__.TimeoutError) {
                    src_app_app_component__WEBPACK_IMPORTED_MODULE_13__.AppComponent.showError(errorMessage);
                }
                else {
                    // this.alertHandler.presentError(err.error);
                }
                if (_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.isDevelopment && ((_c = _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.http) === null || _c === void 0 ? void 0 : _c.presentErrors))
                    src_app_app_component__WEBPACK_IMPORTED_MODULE_13__.AppComponent.showError(`${errorMessage ? errorMessage + " " + err.statusText + " " : ""}${err.message}`);
                this.requestsSubjects.delete(requestKey);
                return (0,rxjs__WEBPACK_IMPORTED_MODULE_22__.throwError)(err);
                // return of(undefined);
            }))
                .subscribe(requestSubject);
            return requestSubject;
        }
    }
    isNativeHttpAvailable() {
        var _a;
        if (this.ـisNativeHttpAvailable === null) {
            this.ـisNativeHttpAvailable =
                ((_a = _inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.http) === null || _a === void 0 ? void 0 : _a.native) &&
                    ((0,_ionic_native_core__WEBPACK_IMPORTED_MODULE_10__.checkAvailability)("cordova.plugin.http") === true ||
                        (0,_ionic_native_core__WEBPACK_IMPORTED_MODULE_10__.checkAvailability)("cordovaHTTP") === true);
            if (this.ـisNativeHttpAvailable) {
                this.httpNative.setRequestTimeout(_inma_environment__WEBPACK_IMPORTED_MODULE_0__.Environment.http.timeout);
                // disable SSL cert checking, only meant for testing purposes, do NOT use in production!
                this.httpNative.setServerTrustMode("nocheck").catch(function () {
                    console.log("error :(");
                });
            }
        }
        return this.ـisNativeHttpAvailable;
    }
};
HttpRequestService.ctorParameters = () => [];
HttpRequestService = (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_24__.Injectable)({
        providedIn: 'root'
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__metadata)("design:paramtypes", [])
], HttpRequestService);

class HttpTranslations {
}
HttpTranslations.errors = {
    sessionExpiry: ["انتهت صلاحية الجلسة", "Session expired"],
    networkError: [
        "خطأ في الاتصال، تأكد من إعدادات الشبكة",
        "Network Error, check your connection",
    ],
    serviceNotAvailable: [
        "الخدمة المطلوبة غير موجودة",
        "The requested service could not be found",
    ],
    timeoutError: [
        "الطلب استغرق وقتا طويلا ولا يوجد استجابة",
        "The request took a long time and no response",
    ],
    serverError: [
        "الخادم غير متاح حالياَ الرجاء المحاولة لاحقا",
        "The server is down please try again later",
    ],
};


/***/ }),

/***/ 49802:
/*!*************************************************************************!*\
  !*** ./src/app/common-ui-components/search/search.page.scss?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "ion-toolbar {\n  --color: white;\n  --background: #005157;\n}\nion-toolbar ion-searchbar {\n  --color: #65979a;\n  --icon-color: #65979a;\n  --background: #e6eff0;\n  --border-radius: 0;\n}\nbody.dark :host ion-toolbar ion-searchbar {\n  --color: white;\n  --icon-color: white;\n  border: 1px solid white;\n  height: 36px;\n  padding-top: 10px;\n}\nion-toolbar #close-button {\n  --color: #e6eff0;\n  font-size: 100%;\n}\n.searchbar-input {\n  border: 1px solid white;\n}\n.symbol-id {\n  font-weight: normal;\n  border: 1px solid #e6eff0;\n  padding: 0 2px;\n  width: 36px;\n  font-weight: bold;\n  text-align: center;\n}\n:host ion-item {\n  --color: #005457;\n  font-size: 12px;\n  --border-color: transparent;\n}\nbody.dark :host ion-item {\n  --color: #a5a5a5;\n}\n.search-name {\n  -webkit-margin-start: 8px;\n          margin-inline-start: 8px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlYXJjaC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFBO0VBQ0EscUJBQUE7QUFDSjtBQUNJO0VBQ0ksZ0JBQUE7RUFDQSxxQkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7QUFDUjtBQUFRO0VBQ0ksY0FBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7QUFFWjtBQUVJO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0FBQVI7QUFHQTtFQUNJLHVCQUFBO0FBQUo7QUFJQTtFQUNJLG1CQUFBO0VBQ0EseUJBQUE7RUFDQSxjQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUFESjtBQUtJO0VBQ0ksZ0JBQUE7RUFNQSxlQUFBO0VBQ0EsMkJBQUE7QUFQUjtBQUVRO0VBQ0ksZ0JBQUE7QUFBWjtBQVFBO0VBQ0kseUJBQUE7VUFBQSx3QkFBQTtBQUxKIiwiZmlsZSI6InNlYXJjaC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhciB7XG4gICAgLS1jb2xvcjogd2hpdGU7XG4gICAgLS1iYWNrZ3JvdW5kOiAjMDA1MTU3O1xuXG4gICAgaW9uLXNlYXJjaGJhciB7XG4gICAgICAgIC0tY29sb3I6ICM2NTk3OWE7XG4gICAgICAgIC0taWNvbi1jb2xvcjogIzY1OTc5YTtcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjZTZlZmYwO1xuICAgICAgICAtLWJvcmRlci1yYWRpdXM6IDA7XG4gICAgICAgIGJvZHkuZGFyayA6aG9zdCAmIHtcbiAgICAgICAgICAgIC0tY29sb3I6IHdoaXRlO1xuICAgICAgICAgICAgLS1pY29uLWNvbG9yOiB3aGl0ZTtcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHdoaXRlO1xuICAgICAgICAgICAgaGVpZ2h0OiAzNnB4O1xuICAgICAgICAgICAgcGFkZGluZy10b3A6IDEwcHg7XG4gICAgICAgICAgfVxuICAgIH1cblxuICAgICNjbG9zZS1idXR0b24ge1xuICAgICAgICAtLWNvbG9yOiAjZTZlZmYwO1xuICAgICAgICBmb250LXNpemU6IDEwMCU7XG4gICAgfVxufVxuLnNlYXJjaGJhci1pbnB1dHtcbiAgICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcbn1cblxuXG4uc3ltYm9sLWlkIHtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICNlNmVmZjA7XG4gICAgcGFkZGluZzogMCAycHg7XG4gICAgd2lkdGg6IDM2cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG46aG9zdCB7XG4gICAgaW9uLWl0ZW0ge1xuICAgICAgICAtLWNvbG9yOiAjMDA1NDU3O1xuXG4gICAgICAgIGJvZHkuZGFyayAmIHtcbiAgICAgICAgICAgIC0tY29sb3I6ICNhNWE1YTU7XG4gICAgICAgIH1cblxuICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICAgIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgICB9XG59XG5cbi5zZWFyY2gtbmFtZSB7XG4gICAgbWFyZ2luLWlubGluZS1zdGFydDogOHB4O1xufSJdfQ== */";

/***/ }),

/***/ 42781:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/order/commission/commission.component.scss?ngResource ***!
  \*****************************************************************************/
/***/ ((module) => {

module.exports = ":host {\n  display: block;\n  border-radius: 5px;\n  padding: 0 10px;\n  background-color: #e6eff0;\n  color: var(--ion-color-primary-txt);\n}\n:host ion-grid {\n  padding: 0;\n  border: solid 1px #e6eff0;\n}\nbody.dark :host ion-grid {\n  border: solid 1px #787878;\n}\n:host ion-row {\n  border-bottom: solid #cddfe1 1px;\n}\nbody.dark :host ion-row {\n  border-bottom: solid 1px #787878;\n}\n:host ion-row ion-col {\n  color: #34757a;\n  font-size: 12px;\n}\n:host ion-row span {\n  font-size: 12px;\n  font-weight: bold;\n  color: #005157;\n}\n:host ion-row:last-child {\n  border-bottom: 0px;\n}\n:host ion-col:first-child {\n  font-weight: bold;\n  font-size: 80%;\n}\n:host #total-row {\n  height: 45px;\n  display: flex;\n  background: #B5CFD2;\n  justify-content: center;\n  align-items: center;\n  margin-top: 12px;\n  font-weight: bold;\n}\nbody.dark :host #total-row {\n  background: #4b4b4b;\n}\n:host ion-skeleton-text {\n  border-radius: 5px;\n  width: 50%;\n  --background-rgb: 0, 81, 87;\n  width: 50%;\n  position: absolute;\n  top: 10%;\n  height: 18px;\n}\nbody.dark :host ion-skeleton-text {\n  --background-rgb: 255, 255, 255;\n}\n:host {\n  display: inherit;\n  padding: 0 !important;\n}\n:host .confirm-card {\n  padding: 10px 0;\n  border-radius: 5px;\n  background-color: rgba(230, 239, 240, 0.5);\n  margin: 16px;\n  display: flex;\n  flex-direction: column;\n}\n:host .border-divider {\n  width: 100%;\n  border: 0.55px solid #cddfe1;\n  margin: 10px 0;\n}\n:host .confirm-card-label {\n  color: #34757a;\n  font-size: 14px;\n  font-weight: bold;\n}\n:host .confirm-label {\n  color: #65979a;\n  font-size: 12px;\n  font-weight: normal !important;\n}\n:host .confirm-value {\n  color: #34757a;\n  font-size: 12px;\n  font-weight: bold;\n}\n:host .flex-row {\n  display: flex;\n  flex-direction: row;\n  justify-content: space-between;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbW1pc3Npb24uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFBO0VBRUEsa0JBQUE7RUFFQSxlQUFBO0VBQ0EseUJBQUE7RUFlQSxtQ0FBQTtBQWZKO0FBRUk7RUFDSSxVQUFBO0VBQ0EseUJBQUE7QUFBUjtBQUVRO0VBQ0kseUJBQUE7QUFBWjtBQVVJO0VBQ0ksZ0NBQUE7QUFSUjtBQVVRO0VBQ0ksZ0NBQUE7QUFSWjtBQVdRO0VBQ0ksY0FBQTtFQUNBLGVBQUE7QUFUWjtBQVlRO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQVZaO0FBY0k7RUFDSSxrQkFBQTtBQVpSO0FBZUk7RUFDSSxpQkFBQTtFQUNBLGNBQUE7QUFiUjtBQWdCSTtFQUNJLFlBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFNQSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQW5CUjtBQVlRO0VBQ0ksbUJBQUE7QUFWWjtBQW1CSTtFQUNJLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLDJCQUFBO0VBTUEsVUFBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFlBQUE7QUF0QlI7QUFlUTtFQUNJLCtCQUFBO0FBYlo7QUF3QkE7RUFDSSxnQkFBQTtFQUNBLHFCQUFBO0FBckJKO0FBdUJJO0VBQ0ksZUFBQTtFQUNBLGtCQUFBO0VBQ0EsMENBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0FBckJSO0FBd0JJO0VBQ0ksV0FBQTtFQUNBLDRCQUFBO0VBQ0EsY0FBQTtBQXRCUjtBQXlCSTtFQUNJLGNBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUF2QlI7QUEwQkk7RUFDSSxjQUFBO0VBQ0EsZUFBQTtFQUNBLDhCQUFBO0FBeEJSO0FBMkJJO0VBQ0ksY0FBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQXpCUjtBQTRCSTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLDhCQUFBO0FBMUJSIiwiZmlsZSI6ImNvbW1pc3Npb24uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdCB7XG4gICAgZGlzcGxheTogYmxvY2s7XG5cbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XG5cbiAgICBwYWRkaW5nOiAwIDEwcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2U2ZWZmMDtcblxuICAgIGlvbi1ncmlkIHtcbiAgICAgICAgcGFkZGluZzogMDtcbiAgICAgICAgYm9yZGVyOiBzb2xpZCAxcHggI2U2ZWZmMDtcblxuICAgICAgICBib2R5LmRhcmsgJiB7XG4gICAgICAgICAgICBib3JkZXI6IHNvbGlkIDFweCAjNzg3ODc4O1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gYmFja2dyb3VuZC1jb2xvcjogI2U2ZWZmMDtcbiAgICAgICAgLy8gYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5KTtcbiAgICB9XG5cbiAgICAvLyBjb2xvcjogIzAwNTE1NztcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktdHh0KTtcblxuICAgIGlvbi1yb3cge1xuICAgICAgICBib3JkZXItYm90dG9tOiBzb2xpZCAjY2RkZmUxIDFweDtcblxuICAgICAgICBib2R5LmRhcmsgJiB7XG4gICAgICAgICAgICBib3JkZXItYm90dG9tOiBzb2xpZCAxcHggIzc4Nzg3ODtcbiAgICAgICAgfVxuXG4gICAgICAgIGlvbi1jb2wge1xuICAgICAgICAgICAgY29sb3I6ICMzNDc1N2E7XG4gICAgICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICAgIH1cblxuICAgICAgICBzcGFuIHtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICAgICAgY29sb3I6ICMwMDUxNTc7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBpb24tcm93Omxhc3QtY2hpbGQge1xuICAgICAgICBib3JkZXItYm90dG9tOiAwcHg7XG4gICAgfVxuXG4gICAgaW9uLWNvbDpmaXJzdC1jaGlsZCB7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICBmb250LXNpemU6IDgwJTtcbiAgICB9XG5cbiAgICAjdG90YWwtcm93IHtcbiAgICAgICAgaGVpZ2h0OiA0NXB4O1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBiYWNrZ3JvdW5kOiAjQjVDRkQyO1xuXG4gICAgICAgIGJvZHkuZGFyayAmIHtcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICM0YjRiNGI7XG4gICAgICAgIH1cblxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgbWFyZ2luLXRvcDogMTJweDtcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgfVxuXG4gICAgaW9uLXNrZWxldG9uLXRleHQge1xuICAgICAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgICAgIHdpZHRoOiA1MCU7XG4gICAgICAgIC0tYmFja2dyb3VuZC1yZ2I6IDAsIDgxLCA4NztcblxuICAgICAgICBib2R5LmRhcmsgJiB7XG4gICAgICAgICAgICAtLWJhY2tncm91bmQtcmdiOiAyNTUsIDI1NSwgMjU1O1xuICAgICAgICB9XG5cbiAgICAgICAgd2lkdGg6IDUwJTtcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICB0b3A6IDEwJTtcbiAgICAgICAgaGVpZ2h0OiAxOHB4O1xuICAgIH1cblxufVxuXG46aG9zdCB7XG4gICAgZGlzcGxheTogaW5oZXJpdDtcbiAgICBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7XG5cbiAgICAuY29uZmlybS1jYXJkIHtcbiAgICAgICAgcGFkZGluZzogMTBweCAwO1xuICAgICAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHJnYmEoMjMwLCAyMzksIDI0MCwgMC41KTtcbiAgICAgICAgbWFyZ2luOiAxNnB4O1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIH1cblxuICAgIC5ib3JkZXItZGl2aWRlciB7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICBib3JkZXI6IDAuNTVweCBzb2xpZCAjY2RkZmUxO1xuICAgICAgICBtYXJnaW46IDEwcHggMDtcbiAgICB9XG5cbiAgICAuY29uZmlybS1jYXJkLWxhYmVsIHtcbiAgICAgICAgY29sb3I6ICMzNDc1N2E7XG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgfVxuXG4gICAgLmNvbmZpcm0tbGFiZWwge1xuICAgICAgICBjb2xvcjogIzY1OTc5YTtcbiAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgICBmb250LXdlaWdodDogbm9ybWFsICFpbXBvcnRhbnQ7XG4gICAgfVxuXG4gICAgLmNvbmZpcm0tdmFsdWUge1xuICAgICAgICBjb2xvcjogIzM0NzU3YTtcbiAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICB9XG5cbiAgICAuZmxleC1yb3cge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgfVxufSJdfQ== */";

/***/ }),

/***/ 42297:
/*!************************************************************************!*\
  !*** ./src/app/pages/order/confirm/order-confirm.page.scss?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = ":host {\n  height: 100%;\n}\n:host.buy {\n  --side-color: #2ebd85;\n}\n:host.sell {\n  --side-color: #f5455a;\n}\n:host .order-confirmation-content {\n  padding-bottom: 70px;\n}\n:host tadawul-commission {\n  margin: 16px;\n}\n:host ion-toolbar {\n  background: transparent;\n  --background: transparent;\n  --color: var(--ion-color-primary);\n}\n:host form {\n  overflow: hidden;\n  overflow-y: scroll;\n}\n:host .value {\n  width: 100%;\n  height: 45px;\n  border: solid 1px #e6eff0;\n  background-color: var(--ion-color-tertiary);\n  color: var(--ion-color-primary-txt);\n  display: flex;\n  align-items: center;\n  padding: 8px;\n}\nbody.dark :host .value {\n  border: solid 1px #787878;\n}\n:host ion-item {\n  --border-color: transparent;\n  --padding-start: 16px;\n  --padding-end: 8px;\n}\n:host ion-item ion-label {\n  color: var(--ion-color-primary-txt);\n  font-weight: bold;\n}\n:host #edit-button {\n  --background: transparent;\n  --background-activated: transparent;\n  --border-radius: 0;\n  --color: #f5455a;\n  border: 1px solid #f5455a;\n}\n:host #cancel-button {\n  --background: transparent;\n  --background-activated: transparent;\n  --border-radius: 0;\n  --color: var(--ion-color-primary-txt);\n  border: 1px solid var(--ion-color-primary-txt);\n}\n:host #save-button {\n  --background: var(--side-color);\n  margin: 16px;\n  margin-top: 0;\n  --border-radius: 0;\n}\n:host #buttons {\n  margin: 0 4px;\n}\n:host #submit-button-container {\n  position: -webkit-sticky;\n  position: sticky;\n  bottom: 0;\n  opacity: 1;\n  background: white;\n  overflow: auto;\n  background: linear-gradient(0deg, white 0%, white 90%, rgba(255, 255, 255, 0) 100%);\n  z-index: 9999;\n}\nbody.dark :host #submit-button-container {\n  background: linear-gradient(0deg, #1f1f1f 0%, #1f1f1f 80%, #1f1f1f00 100%);\n}\n:host .confirm-card {\n  padding: 10px 0;\n  border-radius: 5px;\n  background-color: #e6eff0;\n  margin: 16px;\n  display: flex;\n  flex-direction: column;\n}\n:host .border-divider {\n  width: 100%;\n  border: 0.55px solid #cddfe1;\n  margin: 10px 0;\n}\n:host .confirm-card-label {\n  color: #34757a;\n  font-size: 14px;\n  font-weight: bold;\n}\n:host .confirm-label {\n  color: #65979a;\n  font-size: 12px;\n}\n:host .confirm-value {\n  color: #34757a;\n  font-size: 12px;\n  font-weight: bold;\n}\n:host .confirm-button {\n  --background: #005157;\n  --border-radius: 5px !important;\n  margin: 16px;\n}\n:host .confirm-button ion-button {\n  margin: 0;\n}\n.symbols-list-wrapper {\n  flex-grow: 1;\n  overflow: auto;\n}\n.modal-content {\n  display: flex;\n  flex-direction: column;\n  height: calc(100% - 140px);\n}\n.custom-footer {\n  position: fixed;\n  bottom: 0;\n  background: white;\n  width: 100%;\n}\n.flex-grow-content {\n  display: flex;\n  flex-grow: 1 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9yZGVyLWNvbmZpcm0ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksWUFBQTtBQUNKO0FBQ0k7RUFDSSxxQkFBQTtBQUNSO0FBRUk7RUFDSSxxQkFBQTtBQUFSO0FBR0k7RUFDSSxvQkFBQTtBQURSO0FBSUk7RUFDSSxZQUFBO0FBRlI7QUFLSTtFQUNJLHVCQUFBO0VBRUEseUJBQUE7RUFFQSxpQ0FBQTtBQUxSO0FBUUk7RUFFSSxnQkFBQTtFQUNBLGtCQUFBO0FBUFI7QUFVSTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EseUJBQUE7RUFPQSwyQ0FBQTtFQUVBLG1DQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtBQWZSO0FBS1E7RUFDSSx5QkFBQTtBQUhaO0FBZUk7RUFDSSwyQkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7QUFiUjtBQWVRO0VBRUksbUNBQUE7RUFDQSxpQkFBQTtBQWRaO0FBK0JJO0VBQ0kseUJBQUE7RUFDQSxtQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSx5QkFBQTtBQTdCUjtBQWdDSTtFQUNJLHlCQUFBO0VBQ0EsbUNBQUE7RUFDQSxrQkFBQTtFQUVBLHFDQUFBO0VBQ0EsOENBQUE7QUEvQlI7QUFrQ0k7RUFDSSwrQkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7QUFoQ1I7QUFtQ0k7RUFDSSxhQUFBO0FBakNSO0FBb0NJO0VBQ0ksd0JBQUE7RUFBQSxnQkFBQTtFQUNBLFNBQUE7RUFDQSxVQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsbUZBQUE7RUFNQSxhQUFBO0FBdkNSO0FBbUNRO0VBQ0ksMEVBQUE7QUFqQ1o7QUF3Q0k7RUFDSSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7QUF0Q1I7QUF5Q0k7RUFDSSxXQUFBO0VBQ0EsNEJBQUE7RUFDQSxjQUFBO0FBdkNSO0FBMENJO0VBQ0ksY0FBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQXhDUjtBQTJDSTtFQUNJLGNBQUE7RUFDQSxlQUFBO0FBekNSO0FBNENJO0VBQ0ksY0FBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQTFDUjtBQTZDSTtFQUNJLHFCQUFBO0VBQ0EsK0JBQUE7RUFDQSxZQUFBO0FBM0NSO0FBNkNRO0VBQ0ksU0FBQTtBQTNDWjtBQWdEQTtFQUNJLFlBQUE7RUFDQSxjQUFBO0FBN0NKO0FBZ0RBO0VBQ0ksYUFBQTtFQUNBLHNCQUFBO0VBQ0EsMEJBQUE7QUE3Q0o7QUFnREE7RUFDSSxlQUFBO0VBQ0EsU0FBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtBQTdDSjtBQW1EQTtFQUNJLGFBQUE7RUFDQSx1QkFBQTtBQWhESiIsImZpbGUiOiJvcmRlci1jb25maXJtLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcbiAgICBoZWlnaHQ6IDEwMCU7XG5cbiAgICAmLmJ1eSB7XG4gICAgICAgIC0tc2lkZS1jb2xvcjogIzJlYmQ4NTtcbiAgICB9XG5cbiAgICAmLnNlbGwge1xuICAgICAgICAtLXNpZGUtY29sb3I6ICNmNTQ1NWE7XG4gICAgfVxuXG4gICAgLm9yZGVyLWNvbmZpcm1hdGlvbi1jb250ZW50IHtcbiAgICAgICAgcGFkZGluZy1ib3R0b206IDcwcHg7XG4gICAgfVxuXG4gICAgdGFkYXd1bC1jb21taXNzaW9uIHtcbiAgICAgICAgbWFyZ2luOiAxNnB4O1xuICAgIH1cblxuICAgIGlvbi10b29sYmFyIHtcbiAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG5cbiAgICAgICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcblxuICAgICAgICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gICAgfVxuXG4gICAgZm9ybSB7XG4gICAgICAgIC8vIGhlaWdodDogY2FsYygxMDAlIC0gOTBweCk7XG4gICAgICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgICAgIG92ZXJmbG93LXk6IHNjcm9sbDtcbiAgICB9XG5cbiAgICAudmFsdWUge1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgaGVpZ2h0OiA0NXB4O1xuICAgICAgICBib3JkZXI6IHNvbGlkIDFweCAjZTZlZmYwO1xuXG4gICAgICAgIGJvZHkuZGFyayAmIHtcbiAgICAgICAgICAgIGJvcmRlcjogc29saWQgMXB4ICM3ODc4Nzg7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBiYWNrZ3JvdW5kLWNvbG9yOiAjZTZlZmYwO1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItdGVydGlhcnkpO1xuICAgICAgICAvLyBjb2xvcjogIzAwNTE1NztcbiAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXR4dCk7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgIHBhZGRpbmc6IDhweDtcbiAgICB9XG5cbiAgICBpb24taXRlbSB7XG4gICAgICAgIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAxNnB4O1xuICAgICAgICAtLXBhZGRpbmctZW5kOiA4cHg7XG5cbiAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgIC8vIGNvbG9yOiAjMDA1NDU3O1xuICAgICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXR4dCk7XG4gICAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgICAgICAgLy8gaW9uLXNlbGVjdCwgaW9uLXNlZ21lbnQsIGlvbi1pbnB1dCB7XG4gICAgICAgIC8vICAgICBiYWNrZ3JvdW5kOiAjZTZlZmYwIWltcG9ydGFudDtcbiAgICAgICAgLy8gICAgIC8vIHBvaW50ZXItZXZlbnRzOiBub25lIWltcG9ydGFudDtcbiAgICAgICAgLy8gICAgIC8vIGJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQhaW1wb3J0YW50O1xuICAgICAgICAvLyAgICAgLS1jb2xvcjogIzAwNTE1NztcbiAgICAgICAgLy8gfVxuICAgIH1cblxuICAgIC8vIHRhZGF3dWwtY29tbWlzc2lvbiB7XG4gICAgLy8gICAgIHdpZHRoOiAxMDAlO1xuICAgIC8vICAgICBtYXJnaW46IDA7XG4gICAgLy8gfVxuXG4gICAgI2VkaXQtYnV0dG9uIHtcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICAgICAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogdHJhbnNwYXJlbnQ7XG4gICAgICAgIC0tYm9yZGVyLXJhZGl1czogMDtcbiAgICAgICAgLS1jb2xvcjogI2Y1NDU1YTtcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2Y1NDU1YTtcbiAgICB9XG5cbiAgICAjY2FuY2VsLWJ1dHRvbiB7XG4gICAgICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gICAgICAgIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6IHRyYW5zcGFyZW50O1xuICAgICAgICAtLWJvcmRlci1yYWRpdXM6IDA7XG4gICAgICAgIC8vIC0tY29sb3I6ICMwMDUxNTc7XG4gICAgICAgIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXR4dCk7XG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXR4dCk7XG4gICAgfVxuXG4gICAgI3NhdmUtYnV0dG9uIHtcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1zaWRlLWNvbG9yKTtcbiAgICAgICAgbWFyZ2luOiAxNnB4O1xuICAgICAgICBtYXJnaW4tdG9wOiAwO1xuICAgICAgICAtLWJvcmRlci1yYWRpdXM6IDA7XG4gICAgfVxuXG4gICAgI2J1dHRvbnMge1xuICAgICAgICBtYXJnaW46IDAgNHB4O1xuICAgIH1cblxuICAgICNzdWJtaXQtYnV0dG9uLWNvbnRhaW5lciB7XG4gICAgICAgIHBvc2l0aW9uOiBzdGlja3k7XG4gICAgICAgIGJvdHRvbTogMDtcbiAgICAgICAgb3BhY2l0eTogMTtcbiAgICAgICAgYmFja2dyb3VuZDogd2hpdGU7XG4gICAgICAgIG92ZXJmbG93OiBhdXRvO1xuICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoMGRlZywgcmdiYSgyNTUsIDI1NSwgMjU1LCAxKSAwJSwgcmdiYSgyNTUsIDI1NSwgMjU1LCAxKSA5MCUsIHJnYmEoMjU1LCAyNTUsIDI1NSwgMCkgMTAwJSk7XG5cbiAgICAgICAgYm9keS5kYXJrICYge1xuICAgICAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDBkZWcsICMxZjFmMWYgMCUsICMxZjFmMWYgODAlLCAjMWYxZjFmMDAgMTAwJSk7XG4gICAgICAgIH1cblxuICAgICAgICB6LWluZGV4OiA5OTk5O1xuXG4gICAgfVxuXG4gICAgLmNvbmZpcm0tY2FyZCB7XG4gICAgICAgIHBhZGRpbmc6IDEwcHggMDtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTZlZmYwO1xuICAgICAgICBtYXJnaW46IDE2cHg7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgfVxuXG4gICAgLmJvcmRlci1kaXZpZGVyIHtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIGJvcmRlcjogMC41NXB4IHNvbGlkICNjZGRmZTE7XG4gICAgICAgIG1hcmdpbjogMTBweCAwO1xuICAgIH1cblxuICAgIC5jb25maXJtLWNhcmQtbGFiZWwge1xuICAgICAgICBjb2xvcjogIzM0NzU3YTtcbiAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICB9XG5cbiAgICAuY29uZmlybS1sYWJlbCB7XG4gICAgICAgIGNvbG9yOiAjNjU5NzlhO1xuICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgfVxuXG4gICAgLmNvbmZpcm0tdmFsdWUge1xuICAgICAgICBjb2xvcjogIzM0NzU3YTtcbiAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICB9XG5cbiAgICAuY29uZmlybS1idXR0b24ge1xuICAgICAgICAtLWJhY2tncm91bmQ6ICMwMDUxNTc7XG4gICAgICAgIC0tYm9yZGVyLXJhZGl1czogNXB4ICFpbXBvcnRhbnQ7XG4gICAgICAgIG1hcmdpbjogMTZweDtcblxuICAgICAgICBpb24tYnV0dG9uIHtcbiAgICAgICAgICAgIG1hcmdpbjogMDtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLnN5bWJvbHMtbGlzdC13cmFwcGVyIHtcbiAgICBmbGV4LWdyb3c6IDE7XG4gICAgb3ZlcmZsb3c6IGF1dG87XG59XG5cbi5tb2RhbC1jb250ZW50e1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICBoZWlnaHQ6IGNhbGMoIDEwMCUgLSAxNDBweCApO1xufVxuXG4uY3VzdG9tLWZvb3RlciB7XG4gICAgcG9zaXRpb246IGZpeGVkO1xuICAgIGJvdHRvbTogMDtcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgICB3aWR0aDogMTAwJTtcbiAgICAvLyBib3gtc2hhZG93OiAwcHggLTEwcHggMzZweCAjZmZmO1xuICAgIC8vIG92ZXJmbG93LXk6IHNjcm9sbDtcbiAgICAvLyBvdmVyZmxvdy14OiBoaWRkZW47XG59XG5cbi5mbGV4LWdyb3ctY29udGVudCB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LWdyb3c6IDEgIWltcG9ydGFudDtcbiAgICBcbn0iXX0= */";

/***/ }),

/***/ 92930:
/*!********************************************************!*\
  !*** ./src/app/pages/order/order.page.scss?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = ":host {\n  height: 100%;\n}\n:host .BUY {\n  -webkit-margin-start: -2px !important;\n          margin-inline-start: -2px !important;\n  border-radius: 0 3px 3px 0 !important;\n}\n:host .SELL {\n  -webkit-margin-end: -2px !important;\n          margin-inline-end: -2px !important;\n  border-radius: 3px 0 0 3px !important;\n}\n:host.buy {\n  --side-color: #2ebd85 !important;\n}\n:host.sell {\n  --side-color: #f5455a !important;\n}\n:host #search-overlay-container {\n  position: relative;\n}\n:host #search-overlay-container #search-overlay {\n  background: transparent;\n  width: 100%;\n  height: 100%;\n  position: absolute;\n  z-index: 9;\n}\n:host ion-toolbar {\n  --background: var(--ion-color-primary);\n  transition: background-color 0.1s ease-in;\n  --color: white;\n}\n:host ion-toolbar ion-segment#segment-header {\n  border-radius: 3px;\n  width: -webkit-fit-content;\n  width: -moz-fit-content;\n  width: fit-content;\n}\n:host ion-toolbar ion-segment#segment-header ion-segment-button {\n  font-size: 13px;\n  padding: 5px 0;\n  min-width: 80px;\n  --border-radius: 0;\n  padding: 0;\n  margin: 0;\n  --background: var(--ion-color-tertiary);\n  color: var(--ion-color-primary);\n}\n:host ion-toolbar ion-segment#segment-header ion-segment-button.segment-button-checked {\n  color: white;\n  --indicator-color: var(--side-color);\n}\n:host ion-toolbar ion-segment#segment-header ion-segment-button::before {\n  border: 0 !important;\n  opacity: 0 !important;\n}\n:host form {\n  overflow: hidden;\n  overflow-y: scroll;\n}\n:host #save-button {\n  --background: var(--side-color);\n  --transition: background-color 0.2s ease-in;\n  --border-radius: 5px;\n}\n:host ion-item {\n  color: var(--ion-color-primary-txt);\n  --padding-start: 16px;\n  --padding-end: 8px;\n}\nbody.dark :host ion-item {\n  color: #a5a5a5;\n  --ion-color-primary-txt: #a5a5a5;\n}\n:host ion-item ion-select {\n  border: 1px solid #91babd;\n  padding: 10px;\n}\nbody.dark :host ion-item ion-select {\n  background: #4b4b4b;\n  border: 1px solid #787878;\n}\n:host ion-item {\n  --border-color: transparent;\n}\n:host ion-label {\n  font-weight: bold;\n}\n:host #buying-power {\n  font-size: 12px;\n  color: var(--ion-color-primary-txt);\n  font-weight: bold;\n}\n:host ion-segment.form-segment {\n  max-width: inherit;\n  margin: 0;\n}\n:host #tif-segment ion-segment-button {\n  font-size: 50%;\n}\n:host #spinner-container {\n  position: absolute;\n  z-index: 99;\n  top: 5px;\n  left: 5px;\n  background: white;\n  width: 75%;\n  height: 30px;\n}\n[dir=rtl] :host #spinner-container {\n  right: 5px;\n  left: inherit;\n}\nbody.dark :host #spinner-container {\n  background: #1e1e1e;\n}\n:host #spinner-container ion-spinner {\n  color: #2ebd85;\n}\n:host #spinner-container ion-spinner.sell {\n  color: #f5455a;\n}\n:host #select-all-quantity {\n  width: 140px;\n  position: absolute;\n  pointer-events: none;\n  line-height: 15px;\n  height: 42px;\n  top: 5px;\n  font-size: 10px;\n  margin-left: 40px;\n  text-align: left;\n  left: 0;\n  color: var(--ion-color-tertiary-light);\n  z-index: 99;\n}\n[dir=ltr] :host #select-all-quantity {\n  right: 0;\n  margin-right: 40px;\n  text-align: right;\n  left: auto;\n}\nbody.dark :host #select-all-quantity {\n  color: white;\n}\n:host #submit-button-container {\n  position: -webkit-sticky;\n  position: sticky;\n  bottom: 0;\n  opacity: 1;\n  background: white;\n  overflow: auto;\n  background: linear-gradient(0deg, white 0%, white 80%, rgba(255, 255, 255, 0) 100%);\n  z-index: 9999;\n}\nbody.dark :host #submit-button-container {\n  background: linear-gradient(0deg, #1f1f1f 0%, #1f1f1f 80%, #1f1f1f00 100%);\n}\n:host #date-input {\n  text-align: center;\n  color: white;\n}\n:host #date-overlay {\n  position: absolute;\n  pointer-events: none;\n  top: 48px;\n  background: white;\n  left: 5%;\n  z-index: 9;\n  width: 93%;\n  text-align: start;\n}\nhtml[dir=ltr] :host #date-overlay {\n  left: auto;\n  right: 5%;\n}\n.dark :host #date-overlay {\n  color: white;\n  background: #1f1f1f;\n}\n:host .calender-div {\n  position: absolute;\n  top: 5px;\n  right: 5px;\n  color: #337479 !important;\n}\n[dir=rtl] :host .calender-div {\n  left: 5px;\n  right: inherit;\n}\n:host .minus-div {\n  position: absolute;\n  left: 5px;\n  color: #337479 !important;\n}\n[dir=rtl] :host .minus-div {\n  right: 5px;\n  left: inherit;\n}\n:host .plus-div {\n  position: absolute;\n  right: 5px;\n  color: #337479 !important;\n}\n[dir=rtl] :host .plus-div {\n  left: 5px;\n  right: inherit;\n}\n:host *.md unlocker {\n  position: absolute;\n  top: 5.5px;\n  left: 5px;\n  right: 5px;\n  z-index: 100;\n}\n:host *.ios unlocker {\n  position: absolute;\n  top: 2.5px;\n  left: 5px;\n  right: 5px;\n  z-index: 100;\n}\n.validator-error {\n  margin: 0 16px;\n  color: #f5455a;\n}\n.col-grid-flex {\n  display: flex;\n  align-items: center;\n  padding: 0 !important;\n}\n.label-form {\n  font-size: 12px;\n  color: var(--ion-color-primary);\n  font-weight: normal;\n}\nion-select.rounded-select,\nion-input.rounded-input {\n  border-radius: 5px;\n  border: solid 1px #cddcdd;\n  background-color: #fff;\n  height: 40px;\n  --padding-start: 10px;\n  --color: #005157 !important;\n  color: #005157 !important;\n  --caret-color: var(--ion-color-tertiary-contrast) !important;\n  --placeholder-color: var(--ion-color-tertiary-contrast) !important;\n}\nion-datetime.rounded-date {\n  display: flex;\n  margin: auto;\n  --color: var(--ion-color-tertiary-contrast) !important;\n  color: var(--ion-color-tertiary-contrast) !important;\n  --caret-color: var(--ion-color-tertiary-contrast) !important;\n  --placeholder-color: var(--ion-color-tertiary-contrast) !important;\n}\n.datetime-text {\n  margin-top: -5px !important;\n}\nion-select::part(icon) {\n  content: \"\\e908\" !important;\n}\n.validator-error {\n  margin: 0 5px !important;\n  font-size: 10px !important;\n}\nion-row {\n  margin: 15px 0;\n}\n.icon-bg {\n  width: 30px;\n  height: 30px;\n  border-radius: 4px;\n  background-color: var(--ion-color-tertiary);\n  z-index: 100;\n  display: grid;\n  place-items: center;\n}\n.spacer {\n  flex: 1 1 auto;\n}\n.not-selected-symbol {\n  color: var(--ion-color-tertiary-light);\n  font-size: 12px;\n  font-weight: normal;\n}\n.selected-symbol {\n  color: var(--ion-color-primary);\n  font-size: 14px;\n  font-weight: bold;\n}\n.search-icon-container {\n  -webkit-border-start: solid 1px #cddcdd;\n          border-inline-start: solid 1px #cddcdd;\n  width: 30px;\n  height: 30px;\n  display: grid;\n  place-items: center;\n  -webkit-padding-start: 8px;\n          padding-inline-start: 8px;\n}\n.primary-color {\n  color: var(--ion-color-primary);\n  width: 17px;\n  height: 17px;\n}\n.main-color {\n  color: var(--ion-color-primary);\n}\n.sticky-content {\n  position: -webkit-sticky;\n  position: sticky;\n  top: 0;\n  left: 0;\n  background: white;\n  z-index: 200;\n}\n.buy-sell-footer {\n  background: #cddfe1;\n  padding-bottom: env(safe-area-inset-bottom);\n}\n.sell-info {\n  display: flex;\n  justify-content: space-around;\n  flex-direction: row;\n  flex-wrap: nowrap;\n}\n.flex-col-info {\n  display: flex;\n  align-items: flex-start;\n  justify-content: flex-start;\n  flex-direction: column;\n}\n.flex-row-info {\n  display: flex;\n  align-items: flex-start;\n  justify-content: space-between;\n}\n.before-border-div {\n  -webkit-border-start: solid 1px #9cbfc3;\n          border-inline-start: solid 1px #9cbfc3;\n  -webkit-padding-start: 10px;\n          padding-inline-start: 10px;\n}\n.sell-info-row {\n  padding: 10px;\n  padding-bottom: 0;\n  margin: 0 !important;\n}\n.sell-info-label {\n  position: relative;\n  color: #34757a !important;\n  font-size: 12px !important;\n}\n.sell-info-value {\n  font-size: 16px !important;\n  font-weight: bold !important;\n  color: var(--ion-color-primary) !important;\n}\n.footer-icons {\n  margin: 5px;\n  color: #34757a !important;\n}\n.up-chevron:before {\n  content: \"\";\n  position: absolute;\n  width: 16px;\n  height: 16px;\n  border-radius: 4px;\n  top: 2px;\n  left: -22px;\n  z-index: -1;\n  background: #34757a url(\"data:image/svg+xml,%3Csvg version='1.0' id='Layer_1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 16 16' enable-background='new 0 0 16 16' xml:space='preserve'%3E%3Cpath fill='%23FFFFFF' d='M10.1,7.7L6.6,4.1C6.4,4,6.1,4,5.9,4.1c-0.2,0.2-0.2,0.5,0,0.7L9.1,8l-3.2,3.2c-0.2,0.2-0.2,0.5,0,0.7 C6,12,6.1,12,6.2,12s0.2,0,0.3-0.1l3.5-3.5C10.3,8.1,10.3,7.9,10.1,7.7z'/%3E%3C/svg%3E\") 0 0 no-repeat;\n  transform: rotate(270deg);\n}\n.down-chevron:before {\n  content: \"\";\n  position: absolute;\n  width: 16px;\n  height: 16px;\n  border-radius: 4px;\n  top: 2px;\n  left: -22px;\n  z-index: -1;\n  background: #34757a url(\"data:image/svg+xml,%3Csvg version='1.0' id='Layer_1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 16 16' enable-background='new 0 0 16 16' xml:space='preserve'%3E%3Cpath fill='%23FFFFFF' d='M10.1,7.7L6.6,4.1C6.4,4,6.1,4,5.9,4.1c-0.2,0.2-0.2,0.5,0,0.7L9.1,8l-3.2,3.2c-0.2,0.2-0.2,0.5,0,0.7 C6,12,6.1,12,6.2,12s0.2,0,0.3-0.1l3.5-3.5C10.3,8.1,10.3,7.9,10.1,7.7z'/%3E%3C/svg%3E\") 0 0 no-repeat;\n  transform: rotate(90deg);\n}\n.hide-commission {\n  transform: scaleY(0);\n  transform-origin: bottom;\n  transition: transform 0.25s ease;\n}\n.show-commission {\n  transform-origin: top;\n  transform: scaleY(1);\n  transition: transform 0.25s ease;\n}\n.hide-row {\n  margin-bottom: 0px;\n  transition: margin-bottom 0.25s ease;\n}\n.show-row {\n  margin-bottom: 125px;\n  transition: margin-bottom 0.25s ease;\n}\n.hidden-div {\n  transform: scaleY(0);\n  transform-origin: top;\n  height: 0;\n  transition-property: height transform;\n  transition-duration: 0.5s;\n}\n.show-div {\n  height: auto;\n}\n.panel {\n  border: 0;\n}\n.default-panel {\n  border-top: 0.55px solid #cddcdd;\n}\n.stat-padding-bottom {\n  padding: 7px 0 0 0;\n  border-bottom: 1px solid #cddcdd;\n}\n.stat-no-padding-bottom {\n  padding: 7px 0 0 0;\n  border-bottom: 0;\n}\n.footer-icon-container {\n  height: 100%;\n  width: auto;\n  display: grid;\n  place-items: center;\n  -webkit-margin-end: 5px;\n          margin-inline-end: 5px;\n}\n.mirror {\n  transform: scaleY(-1);\n}\n.select-picker-placeholder {\n  align-items: center;\n  height: 40px;\n  display: flex;\n  justify-content: space-between;\n  border: solid 1px #cddcdd;\n  border-radius: 5px;\n}\n.picker-select-icon {\n  transform: rotate(90deg);\n}\n.select-color {\n  color: #005157 !important;\n  margin: 0 10px;\n}\n.primary-color .disabled-div {\n  opacity: 0.5;\n}\n.relative-pos {\n  position: relative;\n}\n.showCommission {\n  z-index: 100;\n  height: 125px;\n  opacity: 1;\n  transition: all 0.2s ease-in;\n}\n.hideCommission {\n  z-index: 0;\n  height: 0;\n  opacity: 0;\n  transition: all 0.2s ease-out;\n}\n.show {\n  display: block;\n}\n.hide {\n  display: none;\n}\n.datetime-disabled {\n  opacity: 0.5;\n}\nion-popover.datetime {\n  --width: 300px;\n  --offset-x: 10px;\n}\n.symbols-search-row {\n  display: flex;\n  padding: 0 16px 0 8px;\n}\n.dialog-modal {\n  left: 5% !important;\n  top: 25% !important;\n  right: 5% !important;\n  width: 90% !important;\n  height: 50%;\n  max-width: 400px !important;\n  height: 400px !important;\n  border-radius: 10px;\n  --backdrop-opacity: 0.7;\n}\n.chevron-div {\n  background: var(--ion-color-primary);\n  border-radius: 4px;\n  height: 17px;\n  width: 17px;\n  display: grid;\n  place-content: center;\n}\n.chevron-icon {\n  font-size: 15px;\n  color: #E6EFF0;\n}\n.date-time-modal {\n  --backdrop-opacity: 0.7 !important;\n  --border-radius: 10px !important;\n}\n.date-time-modal::part(backdrop) {\n  background-color: black;\n  opacity: 0.7;\n}\n.date-time-modal::part(content) {\n  width: 90% !important;\n  height: 50%;\n  max-width: 400px !important;\n  max-height: 350px !important;\n}\n.disable-opacity {\n  opacity: 0.5;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9yZGVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQVdFLFlBQUE7QUFURjtBQURFO0VBQ0UscUNBQUE7VUFBQSxvQ0FBQTtFQUNBLHFDQUFBO0FBR0o7QUFBRTtFQUNFLG1DQUFBO1VBQUEsa0NBQUE7RUFDQSxxQ0FBQTtBQUVKO0FBR0U7RUFDRSxnQ0FBQTtBQURKO0FBSUU7RUFDRSxnQ0FBQTtBQUZKO0FBS0U7RUFDRSxrQkFBQTtBQUhKO0FBS0k7RUFDRSx1QkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0FBSE47QUFPRTtFQUNFLHNDQUFBO0VBQ0EseUNBQUE7RUFJQSxjQUFBO0FBUko7QUFVSTtFQUdFLGtCQUFBO0VBQ0EsMEJBQUE7RUFBQSx1QkFBQTtFQUFBLGtCQUFBO0FBVk47QUFhTTtFQUNFLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQVFBLGtCQUFBO0VBQ0EsVUFBQTtFQUVBLFNBQUE7RUFDQSx1Q0FBQTtFQUNBLCtCQUFBO0FBbkJSO0FBU1E7RUFDRSxZQUFBO0VBQ0Esb0NBQUE7QUFQVjtBQXNCTTtFQUNFLG9CQUFBO0VBQ0EscUJBQUE7QUFwQlI7QUE4QkU7RUFFRSxnQkFBQTtFQUNBLGtCQUFBO0FBN0JKO0FBZ0NFO0VBQ0UsK0JBQUE7RUFDQSwyQ0FBQTtFQUVBLG9CQUFBO0FBL0JKO0FBa0NFO0VBRUUsbUNBQUE7RUFPQSxxQkFBQTtFQUNBLGtCQUFBO0FBdkNKO0FBaUNJO0VBQ0UsY0FBQTtFQUNBLGdDQUFBO0FBL0JOO0FBcUNJO0VBQ0UseUJBQUE7RUFDQSxhQUFBO0FBbkNOO0FBcUNNO0VBQ0UsbUJBQUE7RUFDQSx5QkFBQTtBQW5DUjtBQXdDRTtFQUNFLDJCQUFBO0FBdENKO0FBeUNFO0VBQ0UsaUJBQUE7QUF2Q0o7QUEwQ0U7RUFDRSxlQUFBO0VBRUEsbUNBQUE7RUFDQSxpQkFBQTtBQXpDSjtBQTRDRTtFQUNFLGtCQUFBO0VBQ0EsU0FBQTtBQTFDSjtBQThDSTtFQUNFLGNBQUE7QUE1Q047QUFrREU7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQU9BLGlCQUFBO0VBTUEsVUFBQTtFQUNBLFlBQUE7QUEzREo7QUErQ0k7RUFDRSxVQUFBO0VBQ0EsYUFBQTtBQTdDTjtBQWtESTtFQUNFLG1CQUFBO0FBaEROO0FBc0RJO0VBQ0UsY0FBQTtBQXBETjtBQXNETTtFQUNFLGNBQUE7QUFwRFI7QUEyREU7RUFDRSxZQUFBO0VBQ0Esa0JBQUE7RUFFQSxvQkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLFFBQUE7RUFDQSxlQUFBO0VBUUEsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLE9BQUE7RUFXQSxzQ0FBQTtFQUNBLFdBQUE7QUEzRUo7QUFrRUk7RUFDRSxRQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLFVBQUE7QUFoRU47QUF1RUk7RUFDRSxZQUFBO0FBckVOO0FBeUVFO0VBQ0Usd0JBQUE7RUFBQSxnQkFBQTtFQUNBLFNBQUE7RUFDQSxVQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsbUZBQUE7RUFZQSxhQUFBO0FBbEZKO0FBMkVJO0VBQ0UsMEVBQUE7QUF6RU47QUFrRkU7RUFDRSxrQkFBQTtFQUNBLFlBQUE7QUFoRko7QUFtRkU7RUFDRSxrQkFBQTtFQUNBLG9CQUFBO0VBQ0EsU0FBQTtFQUNBLGlCQUFBO0VBQ0EsUUFBQTtFQUNBLFVBQUE7RUFDQSxVQUFBO0VBQ0EsaUJBQUE7QUFqRko7QUFtRkk7RUFDRSxVQUFBO0VBQ0EsU0FBQTtBQWpGTjtBQW9GSTtFQUNFLFlBQUE7RUFDQSxtQkFBQTtBQWxGTjtBQXNGRTtFQUNFLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFVBQUE7RUFDQSx5QkFBQTtBQXBGSjtBQXNGSTtFQUNFLFNBQUE7RUFDQSxjQUFBO0FBcEZOO0FBd0ZFO0VBQ0Usa0JBQUE7RUFDQSxTQUFBO0VBQ0EseUJBQUE7QUF0Rko7QUF3Rkk7RUFDRSxVQUFBO0VBQ0EsYUFBQTtBQXRGTjtBQTBGRTtFQUNFLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLHlCQUFBO0FBeEZKO0FBMEZJO0VBQ0UsU0FBQTtFQUNBLGNBQUE7QUF4Rk47QUE0RkU7RUFDRSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxTQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7QUExRko7QUE2RkU7RUFDRSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxTQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7QUEzRko7QUFnR0E7RUFDRSxjQUFBO0VBQ0EsY0FBQTtBQTdGRjtBQWtHQTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHFCQUFBO0FBL0ZGO0FBa0dBO0VBQ0UsZUFBQTtFQUNBLCtCQUFBO0VBQ0EsbUJBQUE7QUEvRkY7QUFrR0E7O0VBRUUsa0JBQUE7RUFDQSx5QkFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtFQUNBLHFCQUFBO0VBQ0EsMkJBQUE7RUFDQSx5QkFBQTtFQUNBLDREQUFBO0VBQ0Esa0VBQUE7QUEvRkY7QUFtR0E7RUFNRSxhQUFBO0VBQ0EsWUFBQTtFQUNBLHNEQUFBO0VBQ0Esb0RBQUE7RUFDQSw0REFBQTtFQUNBLGtFQUFBO0FBckdGO0FBd0dBO0VBQ0UsMkJBQUE7QUFyR0Y7QUEyR0E7RUFFRSwyQkFBQTtBQXpHRjtBQTRHQTtFQUNFLHdCQUFBO0VBQ0EsMEJBQUE7QUF6R0Y7QUE0R0E7RUFDRSxjQUFBO0FBekdGO0FBNEdBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLDJDQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtBQXpHRjtBQStHQTtFQUNFLGNBQUE7QUE1R0Y7QUErR0E7RUFDRSxzQ0FBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtBQTVHRjtBQStHQTtFQUNFLCtCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FBNUdGO0FBK0dBO0VBQ0UsdUNBQUE7VUFBQSxzQ0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsMEJBQUE7VUFBQSx5QkFBQTtBQTVHRjtBQStHQTtFQUNFLCtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUE1R0Y7QUFnSEE7RUFDRSwrQkFBQTtBQTdHRjtBQWdIQTtFQUNFLHdCQUFBO0VBQUEsZ0JBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtBQTdHRjtBQWdIQTtFQUNFLG1CQUFBO0VBQ0EsMkNBQUE7QUE3R0Y7QUFnSEE7RUFDRSxhQUFBO0VBQ0EsNkJBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0FBN0dGO0FBZ0hBO0VBQ0UsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsMkJBQUE7RUFDQSxzQkFBQTtBQTdHRjtBQWdIQTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtFQUNBLDhCQUFBO0FBN0dGO0FBZ0hBO0VBQ0UsdUNBQUE7VUFBQSxzQ0FBQTtFQUNBLDJCQUFBO1VBQUEsMEJBQUE7QUE3R0Y7QUFnSEE7RUFDRSxhQUFBO0VBQ0EsaUJBQUE7RUFDQSxvQkFBQTtBQTdHRjtBQWdIQTtFQUNFLGtCQUFBO0VBQ0EseUJBQUE7RUFDQSwwQkFBQTtBQTdHRjtBQWdIQTtFQUNFLDBCQUFBO0VBQ0EsNEJBQUE7RUFDQSwwQ0FBQTtBQTdHRjtBQWdIQTtFQUNFLFdBQUE7RUFDQSx5QkFBQTtBQTdHRjtBQWdIQTtFQUNFLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxRQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFDQSw0ZEFBQTtFQUtBLHlCQUFBO0FBN0dGO0FBZ0hBO0VBQ0UsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtFQUNBLDRkQUFBO0VBS0Esd0JBQUE7QUE3R0Y7QUFnSEE7RUFDRSxvQkFBQTtFQUNBLHdCQUFBO0VBQ0EsZ0NBQUE7QUE3R0Y7QUFnSEE7RUFDRSxxQkFBQTtFQUNBLG9CQUFBO0VBQ0EsZ0NBQUE7QUE3R0Y7QUFnSEE7RUFDRSxrQkFBQTtFQUNBLG9DQUFBO0FBN0dGO0FBZ0hBO0VBQ0Usb0JBQUE7RUFDQSxvQ0FBQTtBQTdHRjtBQWlIQTtFQUNFLG9CQUFBO0VBQ0EscUJBQUE7RUFDQSxTQUFBO0VBQ0EscUNBQUE7RUFDQSx5QkFBQTtBQTlHRjtBQWlIQTtFQUNFLFlBQUE7QUE5R0Y7QUFpSEE7RUFDRSxTQUFBO0FBOUdGO0FBaUhBO0VBQ0UsZ0NBQUE7QUE5R0Y7QUFpSEE7RUFDRSxrQkFBQTtFQUNBLGdDQUFBO0FBOUdGO0FBaUhBO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtBQTlHRjtBQWlIQTtFQUNFLFlBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7VUFBQSxzQkFBQTtBQTlHRjtBQWlIQTtFQUNFLHFCQUFBO0FBOUdGO0FBaUhBO0VBQ0UsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtBQTlHRjtBQWlIQTtFQUNFLHdCQUFBO0FBOUdGO0FBa0hBO0VBQ0UseUJBQUE7RUFDQSxjQUFBO0FBL0dGO0FBaUhBO0VBR0UsWUFBQTtBQWhIRjtBQW1IQTtFQUNFLGtCQUFBO0FBaEhGO0FBbUhBO0VBQ0UsWUFBQTtFQUNBLGFBQUE7RUFDQSxVQUFBO0VBRUEsNEJBQUE7QUFqSEY7QUFvSEE7RUFDRSxVQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7RUFDQSw2QkFBQTtBQWpIRjtBQW9IQTtFQUNFLGNBQUE7QUFqSEY7QUFvSEE7RUFDRSxhQUFBO0FBakhGO0FBb0hBO0VBQ0UsWUFBQTtBQWpIRjtBQW9IQTtFQUNFLGNBQUE7RUFDQSxnQkFBQTtBQWpIRjtBQXdIQTtFQUNFLGFBQUE7RUFDQSxxQkFBQTtBQXJIRjtBQXdIQTtFQUNFLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxvQkFBQTtFQUNBLHFCQUFBO0VBQ0EsV0FBQTtFQUNBLDJCQUFBO0VBQ0Esd0JBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0FBckhGO0FBd0hBO0VBQ0Usb0NBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtFQUNBLHFCQUFBO0FBckhGO0FBd0hBO0VBQ0UsZUFBQTtFQUNBLGNBQUE7QUFySEY7QUF3SEE7RUFDRSxrQ0FBQTtFQUNBLGdDQUFBO0FBckhGO0FBc0hFO0VBQ0UsdUJBQUE7RUFDQSxZQUFBO0FBcEhKO0FBdUhFO0VBQ0UscUJBQUE7RUFDQSxXQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtBQXJISjtBQXlIQTtFQUNFLFlBQUE7QUF0SEYiLCJmaWxlIjoib3JkZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xuICAuQlVZIHtcbiAgICBtYXJnaW4taW5saW5lLXN0YXJ0OiAtMnB4ICFpbXBvcnRhbnQ7XG4gICAgYm9yZGVyLXJhZGl1czogMCAzcHggM3B4IDAgIWltcG9ydGFudDtcbiAgfVxuXG4gIC5TRUxMIHtcbiAgICBtYXJnaW4taW5saW5lLWVuZDogLTJweCAhaW1wb3J0YW50O1xuICAgIGJvcmRlci1yYWRpdXM6IDNweCAwIDAgM3B4ICFpbXBvcnRhbnQ7XG4gIH1cblxuICBoZWlnaHQ6IDEwMCU7XG5cbiAgJi5idXkge1xuICAgIC0tc2lkZS1jb2xvcjogIzJlYmQ4NSAhaW1wb3J0YW50O1xuICB9XG5cbiAgJi5zZWxsIHtcbiAgICAtLXNpZGUtY29sb3I6ICNmNTQ1NWEgIWltcG9ydGFudDtcbiAgfVxuXG4gICNzZWFyY2gtb3ZlcmxheS1jb250YWluZXIge1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcblxuICAgICNzZWFyY2gtb3ZlcmxheSB7XG4gICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgei1pbmRleDogOTtcbiAgICB9XG4gIH1cblxuICBpb24tdG9vbGJhciB7XG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gICAgdHJhbnNpdGlvbjogYmFja2dyb3VuZC1jb2xvciAwLjFzIGVhc2UtaW47XG5cbiAgICAvLyAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG5cbiAgICAtLWNvbG9yOiB3aGl0ZTtcblxuICAgIGlvbi1zZWdtZW50I3NlZ21lbnQtaGVhZGVyIHtcbiAgICAgIC8vIHdpZHRoOiAxNjBweDtcbiAgICAgIC8vIGhlaWdodDogMzRweDtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDNweDtcbiAgICAgIHdpZHRoOiBmaXQtY29udGVudDtcbiAgICAgIC8vIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5KTtcblxuICAgICAgaW9uLXNlZ21lbnQtYnV0dG9uIHtcbiAgICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgICAgICBwYWRkaW5nOiA1cHggMDtcbiAgICAgICAgbWluLXdpZHRoOiA4MHB4O1xuICAgICAgICAvLyB3aWR0aDogODBweDtcblxuICAgICAgICAmLnNlZ21lbnQtYnV0dG9uLWNoZWNrZWQge1xuICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAgICAgICAtLWluZGljYXRvci1jb2xvcjogdmFyKC0tc2lkZS1jb2xvcik7XG4gICAgICAgIH1cblxuICAgICAgICAtLWJvcmRlci1yYWRpdXM6IDA7XG4gICAgICAgIHBhZGRpbmc6IDA7XG5cbiAgICAgICAgbWFyZ2luOiAwO1xuICAgICAgICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci10ZXJ0aWFyeSk7XG4gICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gICAgICAgIC8vIGRpdi5zZWdtZW50LWJ1dHRvbi1pbmRpY2F0b3Iuc2VnbWVudC1idXR0b24taW5kaWNhdG9yLWFuaW1hdGVke1xuICAgICAgICAvLyAgIHZpc2liaWxpdHk6IG5vbmUgIWltcG9ydGFudDtcbiAgICAgICAgLy8gfVxuXG4gICAgICB9XG5cbiAgICAgIGlvbi1zZWdtZW50LWJ1dHRvbjo6YmVmb3JlIHtcbiAgICAgICAgYm9yZGVyOiAwICFpbXBvcnRhbnQ7XG4gICAgICAgIG9wYWNpdHk6IDAgIWltcG9ydGFudDtcbiAgICAgICAgLy8gZGlzcGxheTogbm9uZSAhaW1wb3J0YW50O1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIC5zZWdtZW50LWJ1dHRvbi1pbmRpY2F0b3J7XG4gICAgLy8gICAtLXBhZGRpbmctaW5saW5lOiAwICFpbXBvcnRhbnQ7XG4gICAgLy8gfVxuICB9XG5cbiAgZm9ybSB7XG4gICAgLy8gaGVpZ2h0OiBjYWxjKDEwMCUgLSA5MHB4KTtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgIG92ZXJmbG93LXk6IHNjcm9sbDtcbiAgfVxuXG4gICNzYXZlLWJ1dHRvbiB7XG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1zaWRlLWNvbG9yKTtcbiAgICAtLXRyYW5zaXRpb246IGJhY2tncm91bmQtY29sb3IgMC4ycyBlYXNlLWluO1xuICAgIC8vIG1hcmdpbjogMTZweDtcbiAgICAtLWJvcmRlci1yYWRpdXM6IDVweDtcbiAgfVxuXG4gIGlvbi1pdGVtIHtcbiAgICAvLyBjb2xvcjogIzAwNTQ1NztcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktdHh0KTtcblxuICAgIGJvZHkuZGFyayAmIHtcbiAgICAgIGNvbG9yOiAjYTVhNWE1O1xuICAgICAgLS1pb24tY29sb3ItcHJpbWFyeS10eHQ6ICNhNWE1YTU7XG4gICAgfVxuXG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAxNnB4O1xuICAgIC0tcGFkZGluZy1lbmQ6IDhweDtcblxuICAgIGlvbi1zZWxlY3Qge1xuICAgICAgYm9yZGVyOiAxcHggc29saWQgIzkxYmFiZDsgLy8gIzk5YjliYztcbiAgICAgIHBhZGRpbmc6IDEwcHg7XG5cbiAgICAgIGJvZHkuZGFyayAmIHtcbiAgICAgICAgYmFja2dyb3VuZDogIzRiNGI0YjtcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgIzc4Nzg3ODtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBpb24taXRlbSB7XG4gICAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICB9XG5cbiAgaW9uLWxhYmVsIHtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgfVxuXG4gICNidXlpbmctcG93ZXIge1xuICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAvLyBjb2xvcjogIzAwNTE1NztcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktdHh0KTtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgfVxuXG4gIGlvbi1zZWdtZW50LmZvcm0tc2VnbWVudCB7XG4gICAgbWF4LXdpZHRoOiBpbmhlcml0O1xuICAgIG1hcmdpbjogMDtcbiAgfVxuXG4gICN0aWYtc2VnbWVudCB7XG4gICAgaW9uLXNlZ21lbnQtYnV0dG9uIHtcbiAgICAgIGZvbnQtc2l6ZTogNTAlO1xuICAgIH1cbiAgfVxuXG5cblxuICAjc3Bpbm5lci1jb250YWluZXIge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB6LWluZGV4OiA5OTtcbiAgICB0b3A6IDVweDtcbiAgICBsZWZ0OiA1cHg7XG5cbiAgICBbZGlyPVwicnRsXCJdICYge1xuICAgICAgcmlnaHQ6IDVweDtcbiAgICAgIGxlZnQ6IGluaGVyaXQ7XG4gICAgfVxuXG4gICAgYmFja2dyb3VuZDogd2hpdGU7XG5cbiAgICBib2R5LmRhcmsgJiB7XG4gICAgICBiYWNrZ3JvdW5kOiAjMWUxZTFlO1xuICAgIH1cblxuICAgIHdpZHRoOiA3NSU7XG4gICAgaGVpZ2h0OiAzMHB4O1xuXG4gICAgaW9uLXNwaW5uZXIge1xuICAgICAgY29sb3I6ICMyZWJkODU7XG5cbiAgICAgICYuc2VsbCB7XG4gICAgICAgIGNvbG9yOiAjZjU0NTVhO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGJvZHkuZGFyayA6aG9zdCAucXVhbnRpdHktZGFyayB7fVxuXG4gICNzZWxlY3QtYWxsLXF1YW50aXR5IHtcbiAgICB3aWR0aDogMTQwcHg7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIC8vICBib3R0b206IDE0cHg7XG4gICAgcG9pbnRlci1ldmVudHM6IG5vbmU7XG4gICAgbGluZS1oZWlnaHQ6IDE1cHg7XG4gICAgaGVpZ2h0OiA0MnB4O1xuICAgIHRvcDogNXB4O1xuICAgIGZvbnQtc2l6ZTogMTBweDtcblxuICAgIC8vIEBpbmNsdWRlIGx0ciB7XG4gICAgLy8gbWFyZ2luLXJpZ2h0OiA4NXB4O1xuICAgIC8vIHRleHQtYWxpZ246IHJpZ2h0O1xuICAgIC8vIHJpZ2h0OiAwO1xuICAgIC8vIH1cbiAgICAvLyBAaW5jbHVkZSBydGwge1xuICAgIG1hcmdpbi1sZWZ0OiA0MHB4O1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgbGVmdDogMDtcbiAgICAvLyB9XG5cbiAgICBbZGlyPVwibHRyXCJdICYge1xuICAgICAgcmlnaHQ6IDA7XG4gICAgICBtYXJnaW4tcmlnaHQ6IDQwcHg7XG4gICAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgICAgIGxlZnQ6IGF1dG87XG4gICAgfVxuXG4gICAgLy8gY29sb3I6ICMwMDUxNTc7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci10ZXJ0aWFyeS1saWdodCk7XG4gICAgei1pbmRleDogOTk7XG5cbiAgICBib2R5LmRhcmsgJiB7XG4gICAgICBjb2xvcjogd2hpdGU7XG4gICAgfVxuICB9XG5cbiAgI3N1Ym1pdC1idXR0b24tY29udGFpbmVyIHtcbiAgICBwb3NpdGlvbjogc3RpY2t5O1xuICAgIGJvdHRvbTogMDtcbiAgICBvcGFjaXR5OiAxO1xuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xuICAgIG92ZXJmbG93OiBhdXRvO1xuICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgwZGVnLFxuICAgICAgICByZ2JhKDI1NSwgMjU1LCAyNTUsIDEpIDAlLFxuICAgICAgICByZ2JhKDI1NSwgMjU1LCAyNTUsIDEpIDgwJSxcbiAgICAgICAgcmdiYSgyNTUsIDI1NSwgMjU1LCAwKSAxMDAlKTtcblxuICAgIGJvZHkuZGFyayAmIHtcbiAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgwZGVnLFxuICAgICAgICAgICMxZjFmMWYgMCUsXG4gICAgICAgICAgIzFmMWYxZiA4MCUsXG4gICAgICAgICAgIzFmMWYxZjAwIDEwMCUpO1xuICAgIH1cblxuICAgIHotaW5kZXg6IDk5OTk7XG4gIH1cblxuICAjZGF0ZS1pbnB1dCB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgfVxuXG4gICNkYXRlLW92ZXJsYXkge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBwb2ludGVyLWV2ZW50czogbm9uZTtcbiAgICB0b3A6IDQ4cHg7XG4gICAgYmFja2dyb3VuZDogd2hpdGU7XG4gICAgbGVmdDogNSU7XG4gICAgei1pbmRleDogOTtcbiAgICB3aWR0aDogOTMlO1xuICAgIHRleHQtYWxpZ246IHN0YXJ0O1xuXG4gICAgaHRtbFtkaXI9bHRyXSAmIHtcbiAgICAgIGxlZnQ6IGF1dG87XG4gICAgICByaWdodDogNSU7XG4gICAgfVxuXG4gICAgLmRhcmsgJiB7XG4gICAgICBjb2xvcjogd2hpdGU7XG4gICAgICBiYWNrZ3JvdW5kOiAjMWYxZjFmO1xuICAgIH1cbiAgfVxuXG4gIC5jYWxlbmRlci1kaXYge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0b3A6IDVweDtcbiAgICByaWdodDogNXB4O1xuICAgIGNvbG9yOiAjMzM3NDc5ICFpbXBvcnRhbnQ7XG5cbiAgICBbZGlyPVwicnRsXCJdICYge1xuICAgICAgbGVmdDogNXB4O1xuICAgICAgcmlnaHQ6IGluaGVyaXQ7XG4gICAgfVxuICB9XG5cbiAgLm1pbnVzLWRpdiB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGxlZnQ6IDVweDtcbiAgICBjb2xvcjogIzMzNzQ3OSAhaW1wb3J0YW50O1xuXG4gICAgW2Rpcj1cInJ0bFwiXSAmIHtcbiAgICAgIHJpZ2h0OiA1cHg7XG4gICAgICBsZWZ0OiBpbmhlcml0O1xuICAgIH1cbiAgfVxuXG4gIC5wbHVzLWRpdiB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHJpZ2h0OiA1cHg7XG4gICAgY29sb3I6ICMzMzc0NzkgIWltcG9ydGFudDtcblxuICAgIFtkaXI9XCJydGxcIl0gJiB7XG4gICAgICBsZWZ0OiA1cHg7XG4gICAgICByaWdodDogaW5oZXJpdDtcbiAgICB9XG4gIH1cblxuICAqLm1kIHVubG9ja2VyIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOiA1LjVweDtcbiAgICBsZWZ0OiA1cHg7XG4gICAgcmlnaHQ6IDVweDtcbiAgICB6LWluZGV4OiAxMDA7XG4gIH1cblxuICAqLmlvcyB1bmxvY2tlciB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHRvcDogMi41cHg7XG4gICAgbGVmdDogNXB4O1xuICAgIHJpZ2h0OiA1cHg7XG4gICAgei1pbmRleDogMTAwO1xuICB9XG5cbn1cblxuLnZhbGlkYXRvci1lcnJvciB7XG4gIG1hcmdpbjogMCAxNnB4O1xuICBjb2xvcjogI2Y1NDU1YTtcbn1cblxuaW9uLXRvb2xiYXIge31cblxuLmNvbC1ncmlkLWZsZXgge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7XG59XG5cbi5sYWJlbC1mb3JtIHtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICBmb250LXdlaWdodDogbm9ybWFsO1xufVxuXG5pb24tc2VsZWN0LnJvdW5kZWQtc2VsZWN0LFxuaW9uLWlucHV0LnJvdW5kZWQtaW5wdXQge1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIGJvcmRlcjogc29saWQgMXB4ICNjZGRjZGQ7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gIGhlaWdodDogNDBweDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxMHB4O1xuICAtLWNvbG9yOiAjMDA1MTU3ICFpbXBvcnRhbnQ7XG4gIGNvbG9yOiAjMDA1MTU3ICFpbXBvcnRhbnQ7XG4gIC0tY2FyZXQtY29sb3I6IHZhcigtLWlvbi1jb2xvci10ZXJ0aWFyeS1jb250cmFzdCkgIWltcG9ydGFudDtcbiAgLS1wbGFjZWhvbGRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5LWNvbnRyYXN0KSAhaW1wb3J0YW50O1xufVxuXG5cbmlvbi1kYXRldGltZS5yb3VuZGVkLWRhdGUge1xuICAvLyBib3JkZXItcmFkaXVzOiA1cHg7XG4gIC8vIGJvcmRlcjogc29saWQgMXB4ICNjZGRjZGQ7XG4gIC8vIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gIC8vIGhlaWdodDogNDBweDtcbiAgLy8gLS1wYWRkaW5nLXN0YXJ0OiAxMHB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBtYXJnaW46IGF1dG87XG4gIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci10ZXJ0aWFyeS1jb250cmFzdCkgIWltcG9ydGFudDtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci10ZXJ0aWFyeS1jb250cmFzdCkgIWltcG9ydGFudDtcbiAgLS1jYXJldC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5LWNvbnRyYXN0KSAhaW1wb3J0YW50O1xuICAtLXBsYWNlaG9sZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItdGVydGlhcnktY29udHJhc3QpICFpbXBvcnRhbnQ7XG59XG5cbi5kYXRldGltZS10ZXh0IHtcbiAgbWFyZ2luLXRvcDogLTVweCAhaW1wb3J0YW50O1xufVxuXG5cblxuXG5pb24tc2VsZWN0OjpwYXJ0KGljb24pIHtcbiAgLy8gZGlzcGxheTogbm9uZSAhaW1wb3J0YW50O1xuICBjb250ZW50OiAnXFxlOTA4JyAhaW1wb3J0YW50O1xufVxuXG4udmFsaWRhdG9yLWVycm9yIHtcbiAgbWFyZ2luOiAwIDVweCAhaW1wb3J0YW50O1xuICBmb250LXNpemU6IDEwcHggIWltcG9ydGFudDtcbn1cblxuaW9uLXJvdyB7XG4gIG1hcmdpbjogMTVweCAwO1xufVxuXG4uaWNvbi1iZyB7XG4gIHdpZHRoOiAzMHB4O1xuICBoZWlnaHQ6IDMwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5KTtcbiAgei1pbmRleDogMTAwO1xuICBkaXNwbGF5OiBncmlkO1xuICBwbGFjZS1pdGVtczogY2VudGVyO1xufVxuXG5cblxuXG4uc3BhY2VyIHtcbiAgZmxleDogMSAxIGF1dG87XG59XG5cbi5ub3Qtc2VsZWN0ZWQtc3ltYm9sIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci10ZXJ0aWFyeS1saWdodCk7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbn1cblxuLnNlbGVjdGVkLXN5bWJvbCB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG5cbi5zZWFyY2gtaWNvbi1jb250YWluZXIge1xuICBib3JkZXItaW5saW5lLXN0YXJ0OiBzb2xpZCAxcHggI2NkZGNkZDtcbiAgd2lkdGg6IDMwcHg7XG4gIGhlaWdodDogMzBweDtcbiAgZGlzcGxheTogZ3JpZDtcbiAgcGxhY2UtaXRlbXM6IGNlbnRlcjtcbiAgcGFkZGluZy1pbmxpbmUtc3RhcnQ6IDhweDtcbn1cblxuLnByaW1hcnktY29sb3Ige1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICB3aWR0aDogMTdweDtcbiAgaGVpZ2h0OiAxN3B4O1xuXG59XG5cbi5tYWluLWNvbG9ye1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuXG4uc3RpY2t5LWNvbnRlbnQge1xuICBwb3NpdGlvbjogc3RpY2t5O1xuICB0b3A6IDA7XG4gIGxlZnQ6IDA7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICB6LWluZGV4OiAyMDA7XG59XG5cbi5idXktc2VsbC1mb290ZXIge1xuICBiYWNrZ3JvdW5kOiAjY2RkZmUxO1xuICBwYWRkaW5nLWJvdHRvbTogZW52KHNhZmUtYXJlYS1pbnNldC1ib3R0b20pO1xufVxuXG4uc2VsbC1pbmZvIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmQ7XG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gIGZsZXgtd3JhcDogbm93cmFwO1xufVxuXG4uZmxleC1jb2wtaW5mbyB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtc3RhcnQ7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG59XG5cbi5mbGV4LXJvdy1pbmZvIHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2Vlbjtcbn1cblxuLmJlZm9yZS1ib3JkZXItZGl2IHtcbiAgYm9yZGVyLWlubGluZS1zdGFydDogc29saWQgMXB4ICM5Y2JmYzM7XG4gIHBhZGRpbmctaW5saW5lLXN0YXJ0OiAxMHB4O1xufVxuXG4uc2VsbC1pbmZvLXJvdyB7XG4gIHBhZGRpbmc6IDEwcHg7XG4gIHBhZGRpbmctYm90dG9tOiAwO1xuICBtYXJnaW46IDAgIWltcG9ydGFudDtcbn1cblxuLnNlbGwtaW5mby1sYWJlbCB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgY29sb3I6ICMzNDc1N2EgIWltcG9ydGFudDtcbiAgZm9udC1zaXplOiAxMnB4ICFpbXBvcnRhbnQ7XG59XG5cbi5zZWxsLWluZm8tdmFsdWUge1xuICBmb250LXNpemU6IDE2cHggIWltcG9ydGFudDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQgIWltcG9ydGFudDtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSAhaW1wb3J0YW50O1xufVxuXG4uZm9vdGVyLWljb25zIHtcbiAgbWFyZ2luOiA1cHg7XG4gIGNvbG9yOiAjMzQ3NTdhICFpbXBvcnRhbnQ7XG59XG5cbi51cC1jaGV2cm9uOmJlZm9yZSB7XG4gIGNvbnRlbnQ6IFwiXCI7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgd2lkdGg6IDE2cHg7XG4gIGhlaWdodDogMTZweDtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xuICB0b3A6IDJweDtcbiAgbGVmdDogLTIycHg7XG4gIHotaW5kZXg6IC0xO1xuICBiYWNrZ3JvdW5kOiAjMzQ3NTdhIHVybChcImRhdGE6aW1hZ2Uvc3ZnK3htbCwlM0NzdmcgdmVyc2lvbj0nMS4wJyBpZD0nTGF5ZXJfMScgeG1sbnM9J2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJyB4bWxuczp4bGluaz0naHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluaycgeD0nMHB4JyB5PScwcHgnIHZpZXdCb3g9JzAgMCAxNiAxNicgZW5hYmxlLWJhY2tncm91bmQ9J25ldyAwIDAgMTYgMTYnIHhtbDpzcGFjZT0ncHJlc2VydmUnJTNFJTNDcGF0aCBmaWxsPSclMjNGRkZGRkYnIGQ9J00xMC4xLDcuN0w2LjYsNC4xQzYuNCw0LDYuMSw0LDUuOSw0LjFjLTAuMiwwLjItMC4yLDAuNSwwLDAuN0w5LjEsOGwtMy4yLDMuMmMtMC4yLDAuMi0wLjIsMC41LDAsMC43IEM2LDEyLDYuMSwxMiw2LjIsMTJzMC4yLDAsMC4zLTAuMWwzLjUtMy41QzEwLjMsOC4xLDEwLjMsNy45LDEwLjEsNy43eicvJTNFJTNDL3N2ZyUzRVwiKSAwIDAgbm8tcmVwZWF0O1xuICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDI3MGRlZyk7XG4gIC1tb3otdHJhbnNmb3JtOiByb3RhdGUoMjcwZGVnKTtcbiAgLW1zLXRyYW5zZm9ybTogcm90YXRlKDI3MGRlZyk7XG4gIC1vLXRyYW5zZm9ybTogcm90YXRlKDI3MGRlZyk7XG4gIHRyYW5zZm9ybTogcm90YXRlKDI3MGRlZyk7XG59XG5cbi5kb3duLWNoZXZyb246YmVmb3JlIHtcbiAgY29udGVudDogXCJcIjtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB3aWR0aDogMTZweDtcbiAgaGVpZ2h0OiAxNnB4O1xuICBib3JkZXItcmFkaXVzOiA0cHg7XG4gIHRvcDogMnB4O1xuICBsZWZ0OiAtMjJweDtcbiAgei1pbmRleDogLTE7XG4gIGJhY2tncm91bmQ6ICMzNDc1N2EgdXJsKFwiZGF0YTppbWFnZS9zdmcreG1sLCUzQ3N2ZyB2ZXJzaW9uPScxLjAnIGlkPSdMYXllcl8xJyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHhtbG5zOnhsaW5rPSdodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rJyB4PScwcHgnIHk9JzBweCcgdmlld0JveD0nMCAwIDE2IDE2JyBlbmFibGUtYmFja2dyb3VuZD0nbmV3IDAgMCAxNiAxNicgeG1sOnNwYWNlPSdwcmVzZXJ2ZSclM0UlM0NwYXRoIGZpbGw9JyUyM0ZGRkZGRicgZD0nTTEwLjEsNy43TDYuNiw0LjFDNi40LDQsNi4xLDQsNS45LDQuMWMtMC4yLDAuMi0wLjIsMC41LDAsMC43TDkuMSw4bC0zLjIsMy4yYy0wLjIsMC4yLTAuMiwwLjUsMCwwLjcgQzYsMTIsNi4xLDEyLDYuMiwxMnMwLjIsMCwwLjMtMC4xbDMuNS0zLjVDMTAuMyw4LjEsMTAuMyw3LjksMTAuMSw3Ljd6Jy8lM0UlM0Mvc3ZnJTNFXCIpIDAgMCBuby1yZXBlYXQ7XG4gIC13ZWJraXQtdHJhbnNmb3JtOiByb3RhdGUoOTBkZWcpO1xuICAtbW96LXRyYW5zZm9ybTogcm90YXRlKDkwZGVnKTtcbiAgLW1zLXRyYW5zZm9ybTogcm90YXRlKDkwZGVnKTtcbiAgLW8tdHJhbnNmb3JtOiByb3RhdGUoOTBkZWcpO1xuICB0cmFuc2Zvcm06IHJvdGF0ZSg5MGRlZyk7XG59XG5cbi5oaWRlLWNvbW1pc3Npb24ge1xuICB0cmFuc2Zvcm06IHNjYWxlWSgwKTtcbiAgdHJhbnNmb3JtLW9yaWdpbjogYm90dG9tO1xuICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMC4yNXMgZWFzZTtcbn1cblxuLnNob3ctY29tbWlzc2lvbiB7XG4gIHRyYW5zZm9ybS1vcmlnaW46IHRvcDtcbiAgdHJhbnNmb3JtOiBzY2FsZVkoMSk7XG4gIHRyYW5zaXRpb246IHRyYW5zZm9ybSAwLjI1cyBlYXNlO1xufVxuXG4uaGlkZS1yb3cge1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gIHRyYW5zaXRpb246IG1hcmdpbi1ib3R0b20gMC4yNXMgZWFzZTtcbn1cblxuLnNob3ctcm93IHtcbiAgbWFyZ2luLWJvdHRvbTogMTI1cHg7XG4gIHRyYW5zaXRpb246IG1hcmdpbi1ib3R0b20gMC4yNXMgZWFzZTtcbn1cblxuXG4uaGlkZGVuLWRpdiB7XG4gIHRyYW5zZm9ybTogc2NhbGVZKDApO1xuICB0cmFuc2Zvcm0tb3JpZ2luOiB0b3A7XG4gIGhlaWdodDogMDtcbiAgdHJhbnNpdGlvbi1wcm9wZXJ0eTogaGVpZ2h0IHRyYW5zZm9ybTtcbiAgdHJhbnNpdGlvbi1kdXJhdGlvbjogLjVzO1xufVxuXG4uc2hvdy1kaXYge1xuICBoZWlnaHQ6IGF1dG87XG59XG5cbi5wYW5lbCB7XG4gIGJvcmRlcjogMDtcbn1cblxuLmRlZmF1bHQtcGFuZWwge1xuICBib3JkZXItdG9wOiAwLjU1cHggc29saWQgI2NkZGNkZDtcbn1cblxuLnN0YXQtcGFkZGluZy1ib3R0b20ge1xuICBwYWRkaW5nOiA3cHggMCAwIDA7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjY2RkY2RkO1xufVxuXG4uc3RhdC1uby1wYWRkaW5nLWJvdHRvbSB7XG4gIHBhZGRpbmc6IDdweCAwIDAgMDtcbiAgYm9yZGVyLWJvdHRvbTogMDtcbn1cblxuLmZvb3Rlci1pY29uLWNvbnRhaW5lciB7XG4gIGhlaWdodDogMTAwJTtcbiAgd2lkdGg6IGF1dG87XG4gIGRpc3BsYXk6IGdyaWQ7XG4gIHBsYWNlLWl0ZW1zOiBjZW50ZXI7XG4gIG1hcmdpbi1pbmxpbmUtZW5kOiA1cHg7XG59XG5cbi5taXJyb3Ige1xuICB0cmFuc2Zvcm06IHNjYWxlWSgtMSk7XG59XG5cbi5zZWxlY3QtcGlja2VyLXBsYWNlaG9sZGVyIHtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgaGVpZ2h0OiA0MHB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIGJvcmRlcjogc29saWQgMXB4ICNjZGRjZGQ7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbn1cblxuLnBpY2tlci1zZWxlY3QtaWNvbiB7XG4gIHRyYW5zZm9ybTogcm90YXRlKDkwZGVnKTtcblxufVxuXG4uc2VsZWN0LWNvbG9yIHtcbiAgY29sb3I6ICAjMDA1MTU3ICFpbXBvcnRhbnQ7XG4gIG1hcmdpbjogMCAxMHB4O1xufVxuLnByaW1hcnktY29sb3JcblxuLmRpc2FibGVkLWRpdiB7XG4gIG9wYWNpdHk6IDAuNTtcbn1cblxuLnJlbGF0aXZlLXBvcyB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cblxuLnNob3dDb21taXNzaW9uIHtcbiAgei1pbmRleDogMTAwO1xuICBoZWlnaHQ6IDEyNXB4O1xuICBvcGFjaXR5OiAxO1xuXG4gIHRyYW5zaXRpb246IGFsbCAuMnMgZWFzZS1pbjtcbn1cblxuLmhpZGVDb21taXNzaW9uIHtcbiAgei1pbmRleDogMDtcbiAgaGVpZ2h0OiAwO1xuICBvcGFjaXR5OiAwO1xuICB0cmFuc2l0aW9uOiBhbGwgLjJzIGVhc2Utb3V0O1xufVxuXG4uc2hvdyB7XG4gIGRpc3BsYXk6IGJsb2NrO1xufVxuXG4uaGlkZSB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG5cbi5kYXRldGltZS1kaXNhYmxlZCB7XG4gIG9wYWNpdHk6IDAuNTtcbn1cblxuaW9uLXBvcG92ZXIuZGF0ZXRpbWUge1xuICAtLXdpZHRoOiAzMDBweDtcbiAgLS1vZmZzZXQteDogMTBweDtcbiAgLy8gJjo6cGFydChjb250ZW50KXtcbiAgLy8gICB3aWR0aDogMzAwcHggIWltcG9ydGFudDtcbiAgLy8gICBsZWZ0OiAxMHB4ICFpbXBvcnRhbnQ7XG4gIC8vIH1cbn1cblxuLnN5bWJvbHMtc2VhcmNoLXJvdyB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIHBhZGRpbmc6IDAgMTZweCAwIDhweDtcbn1cblxuLmRpYWxvZy1tb2RhbCB7XG4gIGxlZnQ6IDUlICFpbXBvcnRhbnQ7XG4gIHRvcDogMjUlICFpbXBvcnRhbnQ7XG4gIHJpZ2h0OiA1JSAhaW1wb3J0YW50O1xuICB3aWR0aDogOTAlICFpbXBvcnRhbnQ7XG4gIGhlaWdodDogNTAlO1xuICBtYXgtd2lkdGg6IDQwMHB4ICFpbXBvcnRhbnQ7XG4gIGhlaWdodDogNDAwcHggIWltcG9ydGFudDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgLS1iYWNrZHJvcC1vcGFjaXR5OiAwLjc7XG59XG5cbi5jaGV2cm9uLWRpdiB7XG4gIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xuICBoZWlnaHQ6IDE3cHg7XG4gIHdpZHRoOiAxN3B4O1xuICBkaXNwbGF5OiBncmlkO1xuICBwbGFjZS1jb250ZW50OiBjZW50ZXI7XG59XG5cbi5jaGV2cm9uLWljb24ge1xuICBmb250LXNpemU6IDE1cHg7XG4gIGNvbG9yOiAjRTZFRkYwO1xufVxuXG4uZGF0ZS10aW1lLW1vZGFsIHtcbiAgLS1iYWNrZHJvcC1vcGFjaXR5OiAwLjcgIWltcG9ydGFudDtcbiAgLS1ib3JkZXItcmFkaXVzOiAxMHB4ICFpbXBvcnRhbnQ7XG4gICY6OnBhcnQoYmFja2Ryb3ApIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjaztcbiAgICBvcGFjaXR5OiAwLjc7XG4gIH1cblxuICAmOjpwYXJ0KGNvbnRlbnQpIHtcbiAgICB3aWR0aDogOTAlICFpbXBvcnRhbnQ7XG4gICAgaGVpZ2h0OiA1MCU7XG4gICAgbWF4LXdpZHRoOiA0MDBweCAhaW1wb3J0YW50O1xuICAgIG1heC1oZWlnaHQ6IDM1MHB4ICFpbXBvcnRhbnQ7XG4gIH1cbn1cblxuLmRpc2FibGUtb3BhY2l0eXtcbiAgb3BhY2l0eTogMC41O1xufSJdfQ== */";

/***/ }),

/***/ 64858:
/*!************************************************************************!*\
  !*** ./src/app/pages/order/summary/order-summary.page.scss?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = ":host.buy {\n  --side-color: #2ebd85;\n}\n:host.sell {\n  --side-color: #f5455a;\n}\n:host ion-toolbar {\n  background: transparent;\n  --background: transparent;\n  --color: var(--ion-color-primary);\n  border-bottom: 0.55px solid #ccdddd;\n}\n.confirm-button {\n  --background:#005157;\n  --border-radius: 5px !important;\n  margin: 16px;\n}\n.success-check {\n  display: grid;\n  place-items: center;\n  background-color: #2ebd85;\n  width: 75px;\n  height: 75px;\n  border-radius: 50px;\n  margin: 20px auto;\n}\n.success-icon {\n  font-size: 40px;\n  color: white;\n}\n.center-container {\n  width: 100%;\n  max-width: 300px;\n  display: grid;\n  margin: 100px auto;\n  place-items: center;\n}\n.message-txt {\n  font-size: 16px;\n  color: #005157;\n  font-weight: bold;\n  margin: 5px 0;\n}\n.info-txt {\n  font-size: 14px;\n  color: #65979a;\n  margin: 5px 0;\n}\n.success-img {\n  width: 25%;\n}\n.summary-title {\n  color: var(--side-color);\n  display: flex;\n  justify-content: center;\n  flex-direction: column;\n  text-align: center;\n  padding: 32px;\n  align-items: center;\n}\n.success-text {\n  font-size: 120%;\n  font-weight: bold;\n}\n#order-details {\n  display: block;\n  border: solid 1px #e6eff0;\n  background-color: var(--ion-color-tertiary);\n  margin: 16px;\n  margin-top: 8px;\n  color: var(--ion-color-primary-txt);\n}\n#order-details ion-grid {\n  padding: 0;\n}\n#order-details ion-row {\n  padding: 6px;\n  border-bottom: solid #cddfe1 1px;\n}\n#order-details ion-row:last-child {\n  border-bottom: 0px;\n}\n#order-details ion-col:first-child {\n  font-weight: bold;\n  font-size: 80%;\n}\ntadawul-commission {\n  margin-top: 8px;\n}\n.header {\n  color: var(--ion-color-primary-txt);\n  font-size: 14px;\n  font-weight: bold;\n  margin: 0 16px;\n}\n#to-outstanding-orders {\n  --background: #2ebd85;\n  margin: 16px;\n  margin-top: 0;\n  --border-radius: 0;\n}\n#to-home {\n  --background: transparent;\n  --background-activated: transparent;\n  --border-radius: 0;\n  --color: var(--ion-color-primary-txt);\n  border: 1px solid var(--ion-color-primary-txt);\n  margin: 16px;\n}\n:host #submit-button-container {\n  position: -webkit-sticky;\n  position: sticky;\n  bottom: 0;\n  opacity: 1;\n  background: white;\n  overflow: auto;\n  background: linear-gradient(0deg, white 0%, white 90%, rgba(255, 255, 255, 0) 100%);\n  z-index: 99;\n  padding-top: 16px;\n  z-index: 9999;\n}\nbody.dark :host #submit-button-container {\n  background: linear-gradient(0deg, #1f1f1f 0%, #1f1f1f 80%, #1f1f1f00 100%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9yZGVyLXN1bW1hcnkucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdJO0VBQ0kscUJBQUE7QUFGUjtBQUtJO0VBQ0kscUJBQUE7QUFIUjtBQU1JO0VBQ0ksdUJBQUE7RUFDQSx5QkFBQTtFQUNBLGlDQUFBO0VBQ0EsbUNBQUE7QUFKUjtBQU9BO0VBQ0ksb0JBQUE7RUFDQSwrQkFBQTtFQUNBLFlBQUE7QUFKSjtBQU1BO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EseUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7QUFISjtBQU1BO0VBQ0ksZUFBQTtFQUNBLFlBQUE7QUFISjtBQU1BO0VBQ0ksV0FBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUFISjtBQU9BO0VBQ0ksZUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7QUFKSjtBQU9BO0VBQ0ksZUFBQTtFQUNBLGNBQUE7RUFDQSxhQUFBO0FBSko7QUFPQTtFQUNJLFVBQUE7QUFKSjtBQU9BO0VBQ0ksd0JBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FBSko7QUFPQTtFQUNJLGVBQUE7RUFDQSxpQkFBQTtBQUpKO0FBT0E7RUFDSSxjQUFBO0VBQ0EseUJBQUE7RUFFQSwyQ0FBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBT0EsbUNBQUE7QUFYSjtBQU1JO0VBQ0ksVUFBQTtBQUpSO0FBVUk7RUFDSSxZQUFBO0VBQ0EsZ0NBQUE7QUFSUjtBQVdJO0VBQ0ksa0JBQUE7QUFUUjtBQVlJO0VBQ0ksaUJBQUE7RUFDQSxjQUFBO0FBVlI7QUFlQTtFQUNJLGVBQUE7QUFaSjtBQWVBO0VBRUksbUNBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0FBYko7QUFnQkE7RUFDSSxxQkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7QUFiSjtBQWdCQTtFQUNJLHlCQUFBO0VBQ0EsbUNBQUE7RUFDQSxrQkFBQTtFQUVBLHFDQUFBO0VBQ0EsOENBQUE7RUFDQSxZQUFBO0FBZEo7QUFtQkk7RUFDSSx3QkFBQTtFQUFBLGdCQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxtRkFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtFQU1BLGFBQUE7QUFyQlI7QUFpQlE7RUFDSSwwRUFBQTtBQWZaIiwiZmlsZSI6Im9yZGVyLXN1bW1hcnkucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xuXG4gICAgLy8gaGVpZ2h0OiBjYWxjKDEwMCUgLSA5MHB4KTtcbiAgICAmLmJ1eSB7XG4gICAgICAgIC0tc2lkZS1jb2xvcjogIzJlYmQ4NTtcbiAgICB9XG5cbiAgICAmLnNlbGwge1xuICAgICAgICAtLXNpZGUtY29sb3I6ICNmNTQ1NWE7XG4gICAgfVxuXG4gICAgaW9uLXRvb2xiYXIge1xuICAgICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICAgICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICBib3JkZXItYm90dG9tOiAwLjU1cHggc29saWQgI2NjZGRkZDtcbiAgICB9XG59XG4uY29uZmlybS1idXR0b257XG4gICAgLS1iYWNrZ3JvdW5kOiMwMDUxNTc7XG4gICAgLS1ib3JkZXItcmFkaXVzIDogNXB4ICFpbXBvcnRhbnQ7XG4gICAgbWFyZ2luOiAxNnB4O1xufVxuLnN1Y2Nlc3MtY2hlY2sge1xuICAgIGRpc3BsYXk6IGdyaWQ7XG4gICAgcGxhY2UtaXRlbXM6IGNlbnRlcjtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMmViZDg1O1xuICAgIHdpZHRoOiA3NXB4O1xuICAgIGhlaWdodDogNzVweDtcbiAgICBib3JkZXItcmFkaXVzOiA1MHB4O1xuICAgIG1hcmdpbjogMjBweCBhdXRvO1xufVxuXG4uc3VjY2Vzcy1pY29ue1xuICAgIGZvbnQtc2l6ZTogNDBweDtcbiAgICBjb2xvcjogd2hpdGU7XG59XG5cbi5jZW50ZXItY29udGFpbmVyIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBtYXgtd2lkdGg6IDMwMHB4O1xuICAgIGRpc3BsYXk6IGdyaWQ7XG4gICAgbWFyZ2luOiAxMDBweCBhdXRvO1xuICAgIHBsYWNlLWl0ZW1zOiBjZW50ZXI7XG4gICAgXG59XG5cbi5tZXNzYWdlLXR4dCB7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIGNvbG9yOiAjMDA1MTU3O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIG1hcmdpbjogNXB4IDA7XG59XG5cbi5pbmZvLXR4dCB7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICAgIGNvbG9yOiAjNjU5NzlhO1xuICAgIG1hcmdpbjogNXB4IDA7XG59XG5cbi5zdWNjZXNzLWltZyB7XG4gICAgd2lkdGg6IDI1JTtcbn1cblxuLnN1bW1hcnktdGl0bGUge1xuICAgIGNvbG9yOiB2YXIoLS1zaWRlLWNvbG9yKTtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIHBhZGRpbmc6IDMycHg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cblxuLnN1Y2Nlc3MtdGV4dCB7XG4gICAgZm9udC1zaXplOiAxMjAlO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuXG4jb3JkZXItZGV0YWlscyB7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgYm9yZGVyOiBzb2xpZCAxcHggI2U2ZWZmMDtcbiAgICAvLyBiYWNrZ3JvdW5kLWNvbG9yOiAjZTZlZmYwO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci10ZXJ0aWFyeSk7XG4gICAgbWFyZ2luOiAxNnB4O1xuICAgIG1hcmdpbi10b3A6IDhweDtcblxuICAgIGlvbi1ncmlkIHtcbiAgICAgICAgcGFkZGluZzogMDtcbiAgICB9XG5cbiAgICAvLyBjb2xvcjogIzAwNTE1NztcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktdHh0KTtcblxuICAgIGlvbi1yb3cge1xuICAgICAgICBwYWRkaW5nOiA2cHg7XG4gICAgICAgIGJvcmRlci1ib3R0b206IHNvbGlkICNjZGRmZTEgMXB4O1xuICAgIH1cblxuICAgIGlvbi1yb3c6bGFzdC1jaGlsZCB7XG4gICAgICAgIGJvcmRlci1ib3R0b206IDBweDtcbiAgICB9XG5cbiAgICBpb24tY29sOmZpcnN0LWNoaWxkIHtcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICAgIGZvbnQtc2l6ZTogODAlO1xuICAgIH1cbn1cblxuXG50YWRhd3VsLWNvbW1pc3Npb24ge1xuICAgIG1hcmdpbi10b3A6IDhweDtcbn1cblxuLmhlYWRlciB7XG4gICAgLy8gY29sb3I6ICMwMDU0NTc7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXR4dCk7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIG1hcmdpbjogMCAxNnB4O1xufVxuXG4jdG8tb3V0c3RhbmRpbmctb3JkZXJzIHtcbiAgICAtLWJhY2tncm91bmQ6ICMyZWJkODU7XG4gICAgbWFyZ2luOiAxNnB4O1xuICAgIG1hcmdpbi10b3A6IDA7XG4gICAgLS1ib3JkZXItcmFkaXVzOiAwO1xufVxuXG4jdG8taG9tZSB7XG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiB0cmFuc3BhcmVudDtcbiAgICAtLWJvcmRlci1yYWRpdXM6IDA7XG4gICAgLy8gLS1jb2xvcjogIzAwNTE1NztcbiAgICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS10eHQpO1xuICAgIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXR4dCk7XG4gICAgbWFyZ2luOiAxNnB4O1xuICAgIC8vIGJvcmRlcjogMXB4IHNvbGlkICMwMDUxNTc7XG59XG5cbjpob3N0IHtcbiAgICAjc3VibWl0LWJ1dHRvbi1jb250YWluZXIge1xuICAgICAgICBwb3NpdGlvbjogc3RpY2t5O1xuICAgICAgICBib3R0b206IDA7XG4gICAgICAgIG9wYWNpdHk6IDE7XG4gICAgICAgIGJhY2tncm91bmQ6IHdoaXRlO1xuICAgICAgICBvdmVyZmxvdzogYXV0bztcbiAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDBkZWcsIHJnYmEoMjU1LCAyNTUsIDI1NSwgMSkgMCUsIHJnYmEoMjU1LCAyNTUsIDI1NSwgMSkgOTAlLCByZ2JhKDI1NSwgMjU1LCAyNTUsIDApIDEwMCUpO1xuICAgICAgICB6LWluZGV4OiA5OTtcbiAgICAgICAgcGFkZGluZy10b3A6IDE2cHg7XG5cbiAgICAgICAgYm9keS5kYXJrICYge1xuICAgICAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDBkZWcsICMxZjFmMWYgMCUsICMxZjFmMWYgODAlLCAjMWYxZjFmMDAgMTAwJSk7XG4gICAgICAgIH1cblxuICAgICAgICB6LWluZGV4OiA5OTk5O1xuXG4gICAgfVxufSJdfQ== */";

/***/ }),

/***/ 47494:
/*!*************************************************************************!*\
  !*** ./src/app/common-ui-components/search/search.page.html?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "<!-- <ion-header>\n  <ion-toolbar>\n    <ion-title>search</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n</ion-content> -->\n\n\n<ion-header>\n  <ion-toolbar [style.--background]=\"color\">\n    <ion-grid>\n      <ion-row>\n        <ion-col>\n          <ion-title>{{ title || t.PAGE_TITLE }}</ion-title>\n          <ion-buttons end>\n            <!-- <button ion-button class=\"close\" (click)=\"dismiss()\">{{ t.CLOSE }}</button> -->\n            <ion-button (click)=\"dismiss()\" id='close-button'>{{ t.CLOSE }}</ion-button>\n          </ion-buttons>\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col>\n        <ion-searchbar [(ngModel)]=\"queryText\" (ngModelChange)=\"filter()\" [placeholder]=\" t.PAGE_TITLE \">\n        </ion-searchbar>\n      </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n\n  <ion-list>\n    <ion-item (click)=\"select(searchable)\" *ngFor=\"let searchable of searchables\">\n      <span class=\"symbol-id\"> {{ searchable?.id }} </span>\n      <span class=\"search-name\">\n        {{ searchable?.name | async }}\n      </span>\n    </ion-item>\n  </ion-list>\n</ion-content>";

/***/ }),

/***/ 65906:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/order/commission/commission.component.html?ngResource ***!
  \*****************************************************************************/
/***/ ((module) => {

module.exports = "<ion-grid *ngIf=\"type == commissionType.SUBMIT_ORDER\">\n  <ion-row class=\"no-bottom-border-row\">\n    <ion-col size=\"5\">\n      {{ 'order.TOTAL_COST' | translate }}\n    </ion-col>\n    <ion-col size=\"7\">\n      <ion-skeleton-text [ngClass]=\"{fadeable: true, 'fast-fadeable': true, visible: loading}\" animated>\n      </ion-skeleton-text>\n      <span\n        [ngClass]=\"{fadeable: true, 'fast-fadeable': true, visible: !loading}\">{{order?.commission?.totalTradeAmount | commafy }}{{'mutualFund.SAR' | translate}}</span>\n    </ion-col>\n  </ion-row>\n  <ion-row class=\"no-bottom-border-row\">\n    <ion-col size=\"5\">\n      {{ 'order.BANK_COMMISSION'| translate }}\n    </ion-col>\n    <ion-col size=\"7\">\n      <ion-skeleton-text [ngClass]=\"{fadeable: true, 'fast-fadeable': true, visible: loading}\" animated>\n      </ion-skeleton-text>\n      <span\n        [ngClass]=\"{fadeable: true, 'fast-fadeable': true, visible: !loading}\">{{order?.commission?.bankCommission  }}{{'mutualFund.SAR' | translate}}</span>\n    </ion-col>\n  </ion-row>\n  <ion-row class=\"no-bottom-border-row\">\n    <ion-col size=\"5\">\n      {{ 'order.TADAWUL_COMMISSION'| translate }}\n    </ion-col>\n    <ion-col size=\"7\">\n      <ion-skeleton-text [ngClass]=\"{fadeable: true, 'fast-fadeable': true, visible: loading}\" animated>\n      </ion-skeleton-text>\n      <span [ngClass]=\"{fadeable: true, 'fast-fadeable': true, visible: !loading}\">\n        {{order?.commission?.exchangeFees }} {{'mutualFund.SAR' | translate}}\n      </span>\n    </ion-col>\n  </ion-row>\n  <ion-row class=\"no-bottom-border-row\">\n    <ion-col size=\"5\">\n      {{ 'order.VAT'| translate }}\n      <!-- <span\n        *ngIf='!isNaN(order?.commission?.bankCommissionVAT)'>({{order?.commission?.bankCommissionVATPercent}} %)</span> -->\n    </ion-col>\n    <ion-col size=\"7\">\n      <ion-skeleton-text animated [ngClass]=\"{fadeable: true, 'fast-fadeable': true, visible: loading}\">\n      </ion-skeleton-text>\n      <span [ngClass]=\"{fadeable: true, 'fast-fadeable': true, visible: !loading}\">\n        {{order?.commission?.bankCommissionVAT }}\n        ({{ order?.commission?.bankCommissionVATPercent}}%) {{'mutualFund.SAR' | translate}}\n      </span>\n    </ion-col>\n  </ion-row>\n</ion-grid>\n\n<div class=\"confirm-card\" *ngIf=\"type == commissionType.CONFIRM_ORDER\">\n  <div class=\"flex-row\">\n    <ion-text class=\"confirm-card-label \">{{'order.TOTAL_ORDER_COST'| translate}}</ion-text>\n    <ion-text class=\"confirm-card-label \">{{order?.commission?.totalTradeAmount | commafy }} {{'mutualFund.SAR' | translate}}\n    </ion-text>\n  </div>\n  <div class=\"border-divider\"></div>\n  <ion-row>\n    <ion-col class=\"\" size=\"5\">\n      <ion-text class=\"confirm-label\">{{'order.TOTAL_COST'| translate}}</ion-text>\n    </ion-col>\n    <ion-col class=\"ion-text-end \" size=\"7\">\n      <ion-text class=\"confirm-value \">{{order?.commission?.totalTradeAmount | commafy }} {{'mutualFund.SAR' | translate}}</ion-text>\n    </ion-col>\n    <ion-col class=\"\" size=\"5\">\n      <ion-text class=\"confirm-label\">{{'order.BANK_COMMISSION'| translate}}</ion-text>\n    </ion-col>\n    <ion-col class=\"ion-text-end \" size=\"7\">\n      <ion-text class=\"confirm-value \">{{order?.commission?.bankCommission }} {{'mutualFund.SAR' | translate}}</ion-text>\n    </ion-col>\n\n    <ion-col class=\"\" size=\"5\">\n      <ion-text class=\"confirm-label\">{{'order.TADAWUL_COMMISSION'| translate}}</ion-text>\n    </ion-col>\n    <ion-col class=\"ion-text-end \" size=\"7\">\n      <ion-text class=\"confirm-value \">{{order?.commission?.exchangeFees }} {{'mutualFund.SAR' | translate}}</ion-text>\n    </ion-col>\n\n    <ion-col class=\"\" size=\"5\">\n      <ion-text class=\"confirm-label\">{{'order.VAT'| translate}}</ion-text>\n    </ion-col>\n    <ion-col class=\"ion-text-end \" size=\"7\">\n      <ion-text class=\"confirm-value \">{{order?.commission?.bankCommissionVAT }} {{'mutualFund.SAR' | translate}}\n        ({{ order?.commission?.bankCommissionVATPercent}}%)</ion-text>\n    </ion-col>\n  </ion-row>\n</div>";

/***/ }),

/***/ 91537:
/*!************************************************************************!*\
  !*** ./src/app/pages/order/confirm/order-confirm.page.html?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>\n      {{ 'order.CONFIRM_ORDER' | translate }}\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"order-confirmation-content\">\n    <div class=\"confirm-card\">\n      <ion-text class=\"confirm-card-label ion-padding-horizontal\">{{'order.ORDER_INFO' | translate}}</ion-text>\n      <div class=\"border-divider\"></div>\n      <ion-row>\n        <ion-col size=\"4\">\n          <ion-text class=\"confirm-label ion-padding-horizontal\">{{'order.PORTFOLIO' | translate}}</ion-text>\n        </ion-col>\n        <ion-col class=\"ion-text-end\" size=\"8\">\n          <ion-text class=\"confirm-value ion-padding-horizontal\">{{order?.portfolio?.id}}</ion-text>\n        </ion-col>\n\n        <ion-col size=\"4\">\n          <ion-text class=\"confirm-label ion-padding-horizontal\">{{'order.SELECTED_SYMBOL' | translate}}</ion-text>\n        </ion-col>\n        <ion-col class=\"ion-text-end\" size=\"8\">\n          <ion-text class=\"confirm-value ion-padding-horizontal\">{{order?.symbol?.name | async}}</ion-text>\n        </ion-col>\n\n        <ion-col size=\"4\">\n          <ion-text class=\"confirm-label ion-padding-horizontal\">{{'order.TYPE' | translate}}</ion-text>\n        </ion-col>\n        <ion-col class=\"ion-text-end\" size=\"8\">\n          <ion-text class=\"confirm-value ion-padding-horizontal\">{{order?.type?.name}}</ion-text>\n        </ion-col>\n\n        <ion-col size=\"4\" *ngIf=\"order?.type?.id=='2'\">\n          <ion-text class=\"confirm-label ion-padding-horizontal\">{{'order.PRICE' | translate}}</ion-text>\n        </ion-col>\n        <ion-col class=\"ion-text-end\" size=\"8\" *ngIf=\"order?.type?.id=='2'\">\n          <ion-text class=\"confirm-value ion-padding-horizontal\">{{order?.price}}</ion-text>\n        </ion-col>\n\n        <ion-col size=\"4\">\n          <ion-text class=\"confirm-label ion-padding-horizontal\">{{'order.QUANTITY' | translate}}</ion-text>\n        </ion-col>\n        <ion-col class=\"ion-text-end\" size=\"8\">\n          <ion-text class=\"confirm-value ion-padding-horizontal\">{{order?.remainingQuantity}}</ion-text>\n        </ion-col>\n\n        <ion-col size=\"4\" *ngIf=\"order?.tif?.name\">\n          <ion-text class=\"confirm-label ion-padding-horizontal\">{{'order.TIF' | translate}}</ion-text>\n        </ion-col>\n        <ion-col class=\"ion-text-end\" size=\"8\" *ngIf=\"order?.tif?.name\">\n          <ion-text class=\"confirm-value ion-padding-horizontal\">{{order?.endDate}}</ion-text>\n        </ion-col>\n      </ion-row>\n    </div>\n    <tadawul-commission [type]=\"commissionType.CONFIRM_ORDER\" [order]=\"order\"></tadawul-commission>\n  </div>\n  <div class=\"custom-footer\">\n    <in-button [(loading)]=\"loading\" class=\"confirm-button\" expand=\"block\" (click)=\"execute()\">\n      <span>{{'app.CONFIRM' | translate}}</span>\n    </in-button>\n  </div>\n</ion-content>\n<tadawul-loader *ngIf=\"loading\"></tadawul-loader>";

/***/ }),

/***/ 33431:
/*!********************************************************!*\
  !*** ./src/app/pages/order/order.page.html?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title *ngIf=\"pageMode == OrderPageMode.edit\">\n      <span *ngIf=\"order.side?.id == OrderSidesEnum.buy\">{{ 'order.edit_buy_order' | translate }}</span>\n      <span *ngIf=\"order.side?.id == OrderSidesEnum.sell\">{{ 'order.edit_sell_order' | translate }}</span>\n    </ion-title>\n    <ion-title *ngIf=\"operation && !sharedOrder\">\n      <span>{{ translate.instant('order.'+order.side?.id) }}</span>\n    </ion-title>\n    <ion-title>\n      <ion-segment *ngIf=\"pageMode != OrderPageMode.edit && !operation\" id='segment-header' [(ngModel)]=\"order.side\"\n        (ionChange)=\"orderSideChanged($event)\">\n        <ion-segment-button *ngFor=\"let side of sides\" [ngClass]=\"side.id\" [value]=\"side\">\n          {{ side.name }}\n        </ion-segment-button>\n      </ion-segment>\n    </ion-title>\n    <ion-buttons slot=\"start\" (click)=\"closePage()\">\n      <div class=\"icon-link\">\n        <span class=\"icon icon-close\"></span>\n      </div>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n\n\n\n<div class=\"sticky-content\" [class]=\"order?.symbol ?'stat-no-padding-bottom':'stat-padding-bottom'\">\n  <div class=\"symbols-search-row\" (click)=\"presentSymbolsSearchModal()\">\n    <div class=\"col-grid-flex\">\n\n      <ion-text *ngIf=\"!order.symbol\" class='not-selected-symbol'>{{'order.SYMBOL' | translate }}</ion-text>\n      <ion-text *ngIf=\"order?.symbol\" class='selected-symbol' [ngClass]=\"operation ? 'disable-opacity':''\">\n        {{order?.symbol?.sortAbbreviation}}</ion-text>\n    </div>\n    <span class=\"spacer\" *ngIf=\"!operation\"></span>\n    <div class=\"search-icon-container\" *ngIf=\"!operation\">\n      <span class=\"icon icon-search primary-color\"></span>\n    </div>\n  </div>\n  <tadawul-symbol [symbol]=\"order?.symbol\"></tadawul-symbol>\n</div>\n<ion-content>\n  <form [formGroup]=\"form\" class=\"ion-padding-horizontal\">\n    <ion-input hidden formControlName=\"symbol\" [(ngModel)]=\"order.symbol\"></ion-input>\n    <ion-row>\n      <ion-col size=\"4\" class=\"col-grid-flex\">\n        <ion-text class=\"label-form\">{{ 'order.PORTFOLIO' | translate  }}</ion-text>\n      </ion-col>\n      <ion-col size=\"8\" class=\"ion-no-padding\" *ngIf=\"order.portfolio\" >\n        <ion-input hidden formControlName=\"portfolio\" [(ngModel)]=\"order.portfolio.id\"></ion-input>\n        <div class=\"select-picker-placeholder\" [ngClass]=\"pageMode == OrderPageMode.edit || (previousPage == 'symbol' && operation == 'sell') ? 'disable-opacity':''\"\n          (click)=\"openPortfolioPicker()\">\n          <ion-text class=\"select-color\">{{order?.portfolio?.id}}</ion-text>\n          <span class=\"icon icon-chevron-right picker-select-icon select-color\"></span>\n        </div>\n\n      </ion-col>\n      <ion-col size=\"4\" class=\"ion-no-padding\"></ion-col>\n      <ion-col size=\"8\" class=\"col-grid-flex\" class=\"ion-no-padding\">\n        <div *ngIf=\"!form.controls.portfolio.valid\n        && form.controls.portfolio.dirty\" class=\"validator-error\">\n          {{ 'app.PLEASE_CHOOSE' | translate  }} {{ 'order.PORTFOLIO' | translate  }}\n        </div>\n      </ion-col>\n    </ion-row>\n\n\n\n    <!-- Order Type -->\n    <ion-row>\n      <ion-col size=\"4\" class=\"col-grid-flex\">\n        <ion-text class=\"label-form\">{{ 'order.TYPE' | translate  }}</ion-text>\n      </ion-col>\n      <ion-col size=\"8\" class=\"ion-no-padding\">\n        <ion-skeleton-text animated style=\"width: 100%;border-radius: 5px;height: 40px;\" *ngIf=\"!types\">\n        </ion-skeleton-text>\n        <ion-segment *ngIf=\"types?.length > 0\" [disabled]=\"pageMode == OrderPageMode.edit\" class='form-segment'\n          scrollable=\"true\" [(ngModel)]=\"order.type\" formControlName=\"type\" (ngModelChange)=\"orderTypeChanged()\">\n          <ion-segment-button *ngFor=\"let type of types\" [value]=\"type\">\n            <ion-label>{{ type.name }}</ion-label>\n          </ion-segment-button>\n        </ion-segment>\n      </ion-col>\n    </ion-row>\n    <!--// -->\n\n    <!-- Price -->\n    <ion-row *ngIf=\"order?.type?.id == OrderTypesEnum.limit\">\n      <ion-col size=\"4\" class=\"col-grid-flex\">\n        <ion-text class=\"label-form\">{{ 'order.PRICE' | translate  }}</ion-text>\n      </ion-col>\n      <ion-col size=\"8\" class=\"col-grid-flex relative-pos\">\n        <div class='icon-bg plus-div' [class]=\"order.symbol ? '':'disable-opacity'\" (click)=\"increasePriceAdjustment()\">\n          <span class=\"icon icon-plus\"></span>\n        </div>\n        <ion-input lang=\"en\" #orderPrice class=\"rounded-input ion-text-center\" br-data-dependency\n          formControlName=\"price\" inputmode=\"decimal\"  [(ngModel)]=\"order.price\" (ngModelChange)=\"getOrderCommission()\">\n        </ion-input>\n        <!-- <ion-input #orderPrice class=\"rounded-input ion-text-center\" br-data-dependency formControlName=\"price\"\n          [type]=\"numberType\" [(ngModel)]=\"order.price\" (ngModelChange)=\"getOrderCommission()\"></ion-input> -->\n        <div class='icon-bg minus-div' [class]=\"order.symbol ? '':'disable-opacity'\" (click)=\"decreasePriceAdjustment()\">\n          <span class=\"icon icon-minus\"></span>\n        </div>\n      </ion-col>\n      <ion-col size=\"4\" class=\"ion-no-padding\"></ion-col>\n      <ion-col size=\"8\" class=\"col-grid-flex\" class=\"ion-no-padding\">\n        <div *ngIf=\"order.side?.id == OrderSidesEnum.sell && symbolMinPrice\" style=\"font-size: 10px;color: #337479;\">\n          {{ 'order.MIN_PRICE' | translate  }} <span style=\"font-weight: bold;color:#005157;\">{{ symbolMinPrice }}\n            {{'mutualFund.SAR' | translate}}</span>\n        </div>\n\n        <div *ngIf=\"order.side?.id == OrderSidesEnum.buy && symbolMaxPrice\" style=\"font-size: 10px;color: #337479;\">\n          {{ 'order.MAX_PRICE' | translate  }} <span style=\"font-weight: bold;color:#005157;\">{{ symbolMaxPrice }}\n            {{'mutualFund.SAR' | translate}}</span>\n        </div>\n        <div *ngIf=\"form.controls.price.invalid && (form.controls.price.dirty || form.controls.price.touched)\"\n          class=\"validator-error\">\n          <div *ngIf=\"form.controls.price.errors.required\">\n            {{ 'app.PLEASE_ENTER' | translate  }} {{ 'order.PRICE' | translate  }}\n          </div>\n          <div *ngIf=\"form.controls.price.errors.integer\">\n            {{ 'app.PLEASE_ENTER' | translate  }} {{ 'order.PRICE' | translate  }}\n            {{ 'app.CORRECT_PATTERN' | translate  }}\n          </div>\n          <div *ngIf=\"!form.controls.price.errors.integer && form.controls.price.errors.min\">\n            {{ 'order.PRICE' | translate  }} {{ 'app.SHOULD_BE_GREATER' | translate  }} {{symbolMinPrice}}\n          </div>\n          <div *ngIf=\"!form.controls.price.errors.integer && form.controls.price.errors.max\">\n            {{ 'order.PRICE' | translate  }} {{ 'app.SHOULD_BE_LESS' | translate  }} {{symbolMaxPrice}}\n          </div>\n        </div>\n      </ion-col>\n    </ion-row>\n    <!--// -->\n\n    <!-- Quantity -->\n    <ion-row>\n      <ion-col size=\"4\" class=\"col-grid-flex\">\n        <ion-text class=\"label-form\">{{ 'order.QUANTITY' | translate  }}</ion-text>\n      </ion-col>\n      <ion-col size=\"8\" class=\"col-grid-flex\" style=\"position: relative;\">\n        <ion-input class=\"rounded-input\" #quantity formControlName=\"quantity\" [attr.pattern]=\"integerPattern\"\n          [type]=\"numberType\" [(ngModel)]=\"order.remainingQuantity\"\n          [disabled]=\"((!order?.price && order?.type == '2') || (order?.type == '1' && !order.symbol))\"\n          (ngModelChange)=\"getOrderCommission()\">\n        </ion-input>\n\n        <div id='spinner-container' class=\"fadeable fast-fadeable\" [ngClass]=\"{visible: showSpinner}\">\n          <ion-spinner name=\"crescent\" [ngClass]=\"{sell: sellClass}\"></ion-spinner>\n        </div>\n        <div>\n          <!-- *ngIf=\"order.side.id == OrderSidesEnum.sell\"> -->\n          <!-- order.type.id == '2' means limit price -->\n          <unlocker\n            [disabled2]=\"((!order?.price || order?.price == 0) && order.type.id == '2')|| !order?.symbol || Number(liveBuyingPower) <= 0\"\n            (progress)=\"onSelectAllQuantityProgress($event)\" (unlocked)=\"unlockedHandler()\">\n          </unlocker>\n          <div #selectAllQuantity id='select-all-quantity'\n            [innerHTML]=\" (order?.side?.id == OrderSidesEnum.sell ? 'order.SELECT_SELL_ALL_QUANTITY' : 'order.SELECT_BUY_ALL_QUANTITY')  | translate \">\n          </div>\n        </div>\n      </ion-col>\n      <ion-col size=\"4\" class=\"ion-no-padding\"></ion-col>\n      <ion-col size=\"8\" class=\"col-grid-flex\" class=\"ion-no-padding\">\n        <div *ngIf=\"form.controls.quantity.invalid && (form.controls.quantity.dirty || form.controls.quantity.touched)\"\n          class=\"validator-error\">\n          <div *ngIf=\"form.controls.quantity.errors.required\">\n            {{ 'app.PLEASE_ENTER' | translate  }} {{ 'order.QUANTITY' | translate  }}\n          </div>\n          <div *ngIf=\"form.controls.quantity.errors.integer || form.controls.quantity.errors.min\">\n            {{ 'app.PLEASE_ENTER' | translate  }} {{ 'order.QUANTITY' | translate  }}\n            {{ 'app.CORRECT_PATTERN' | translate  }}\n          </div>\n          <div\n            *ngIf=\"order.side?.id == OrderSidesEnum.buy && !form.controls.quantity.errors.integer && form.controls.quantity.errors.max\">\n            {{ 'app.BUYING_POWER_VALIDATION' | translate  }}\n            {{ Number(cachedBuyingPower) + Number(cachedRestoredBuyingPower) }}\n          </div>\n          <div\n            *ngIf=\"order.side?.id == OrderSidesEnum.sell && !form.controls.quantity.errors.integer && form.controls.quantity.errors.max\">\n            {{ 'app.OWNED_QUANTITY_VALIDATION' | translate  }}\n            {{+order.symbol?.availableQuantity || '_' }}\n          </div>\n        </div>\n      </ion-col>\n    </ion-row>\n    <!--// -->\n\n\n    <!-- Disclosed Quantity -->\n    <div *ngIf=\"order?.type?.id == OrderTypesEnum.limit\">\n      <ion-row>\n        <ion-col size=\"4\" class=\"col-grid-flex\">\n          <ion-text class=\"label-form\">{{ 'order.DISCLOSED_QUANTITY' | translate  }}</ion-text>\n        </ion-col>\n        <ion-col size=\"8\" class=\"col-grid-flex\">\n          <ion-input class=\"rounded-input\" formControlName=\"disclosedQuantity\" [attr.pattern]=\"integerPattern\"\n            [type]=\"numberType\" [(ngModel)]=\"order.disclosedQuantity\"></ion-input>\n        </ion-col>\n\n\n        <ion-col size=\"4\" class=\"ion-no-padding\"></ion-col>\n        <ion-col size=\"8\" class=\"col-grid-flex\" class=\"ion-no-padding\">\n          <div *ngIf=\"form.controls.disclosedQuantity.invalid\n    && (form.controls.disclosedQuantity.dirty || form.controls.disclosedQuantity.touched)\" class=\"validator-error\">\n            <div *ngIf=\"form.controls.disclosedQuantity.errors.integer\" class=\"validator-error\">\n              {{ 'app.PLEASE_ENTER' | translate  }} {{ 'order.DISCLOSED_QUANTITY' | translate  }}\n              {{ 'app.CORRECT_PATTERN' | translate  }}\n            </div>\n            <div *ngIf=\"!form.controls.disclosedQuantity.errors.integer && form.controls.disclosedQuantity.errors.max\"\n              class=\"validator-error\">\n              {{ 'order.DISCLOSED_QUANTITY' | translate  }} {{ 'app.SHOULD_BE_LESS' | translate  }}\n              {{ 'order.QUANTITY' | translate  }}\n            </div>\n          </div>\n        </ion-col>\n      </ion-row>\n    </div>\n    <!--// -->\n\n    <!--New Validity -->\n    <ion-row>\n      <ion-col size=\"4\" class=\"col-grid-flex\">\n        <ion-text class=\"label-form\">{{ 'order.TIF' | translate  }}</ion-text>\n      </ion-col>\n      <ion-col size=\"8\" class=\"ion-no-padding\">\n\n        <div *ngIf=\"order?.type?.id == OrderTypesEnum.market && tifs && isTifsLoaded\" class=\"select-picker-placeholder\"\n          (click)=\"openMarketPicker()\">\n          <ion-text class=\"select-color\">{{order?.tif?.name}}</ion-text>\n          <span class=\"icon icon-chevron-right picker-select-icon select-color\"></span>\n        </div>\n        <ion-skeleton-text animated style=\"width: 100%;border-radius: 5px;height: 40px;\" *ngIf=\"!isTifsLoaded\">\n        </ion-skeleton-text>\n\n        <div *ngIf=\"order?.type?.id == OrderTypesEnum.limit && isTifsLoaded\" class=\"select-picker-placeholder\"\n          (click)=\"openLimitPicker()\">\n          <ion-input [(ngModel)]=\"order.tif.id\" hidden formControlName=\"tif\"></ion-input>\n          <ion-text class=\"select-color\">{{ translate.instant('order.'+ validity) }}</ion-text>\n          <span class=\"icon icon-chevron-right picker-select-icon select-color\"></span>\n        </div>\n\n\n      </ion-col>\n      <ion-col size=\"4\" class=\"ion-no-padding\"></ion-col>\n      <ion-col size=\"8\" class=\"col-grid-flex\" class=\"ion-no-padding\">\n        <div *ngIf=\"!form.controls.portfolio.valid\n        && form.controls.portfolio.dirty\" class=\"validator-error\">\n          {{ 'app.PLEASE_CHOOSE' | translate  }} {{ 'order.PORTFOLIO' | translate  }}\n        </div>\n      </ion-col>\n    </ion-row>\n\n\n    <!-- EndDate -->\n    <ion-row *ngIf=\"order?.type?.id == OrderTypesEnum.limit\">\n      <ion-col size=\"4\" class=\"col-grid-flex\">\n        <ion-text class=\"label-form\">{{ 'order.END_DATE' | translate  }}</ion-text>\n      </ion-col>\n      <ion-col size=\"8\" class=\"ion-no-padding\" style=\"position: relative;\">\n\n        <div *ngIf=\"validity == OrderValidity.UntilDate\" id=\"open-modal\" class=\"select-picker-placeholder\">\n          <ion-text class=\"select-color\">{{order?.endDate}}</ion-text>\n          <ion-input [(ngModel)]=\"order.endDate\" hidden [ngModelOptions]=\"{standalone: true}\"\n            (ionChange)=\"orderDateDidChange()\"></ion-input>\n          <div class=\"icon-bg\" style=\"margin-inline-end: 5px;\"><span class=\"icon icon-calendar main-color\"></span></div>\n        </div>\n        <div *ngIf=\"validity != OrderValidity.UntilDate\" id=\"dont-open-modal\"\n          class=\"select-picker-placeholder disable-opacity\">\n          <ion-text class=\"select-color\">{{order?.endDate}}</ion-text>\n          <div class=\"icon-bg\" style=\"margin-inline-end: 5px;\"><span class=\"icon icon-calendar main-color\"></span></div>\n        </div>\n        <ion-input formControlName=\"endDate\" [(ngModel)]=\"order.endDate\" hidden></ion-input>\n        <ion-modal trigger=\"open-modal\" class=\"date-time-modal\" *ngIf=\"validity == OrderValidity.UntilDate\">\n          <ng-template>\n            <ion-content>\n              <ion-datetime #datepicker class=\"rounded-date\" [ngModelOptions]=\"{standalone:true}\"\n                displayFormat=\"YYYY-MM-DD\" [min]=\"today\" presentation=\"date\" [max]=\"maxOrderDate\"\n                showDefaultButtons=\"true\" [(ngModel)]=\"order.endDate\" doneText=\"{{ 'app.OK' | translate  }}\"\n                cancelText=\"{{ 'app.CANCEL' | translate  }}\">\n              </ion-datetime>\n            </ion-content>\n          </ng-template>\n        </ion-modal>\n      </ion-col>\n\n      <ion-col size=\"4\" class=\"ion-no-padding\"></ion-col>\n      <ion-col size=\"8\" class=\"col-grid-flex\" class=\"ion-no-padding\">\n        <div *ngIf=\"!form.controls.endDate.valid\n                  && form.controls.endDate.dirty\" class=\"validator-error\">\n          {{ 'app.PLEASE_ENTER' | translate  }} {{ 'order.END_DATE' | translate  }}\n        </div>\n      </ion-col>\n    </ion-row>\n  </form>\n</ion-content>\n<ion-footer class=\"buy-sell-footer hide-on-keyboard-open\">\n  <ion-row class=\"sell-info-row\">\n    <ion-col size=\"6\" class=\"flex-row-info\" (click)=\"toggleSummaryInfo();\">\n      <div class=\"flex-col-info\">\n        <ion-text class='sell-info-label'>{{'order.TOTAL_COST' | translate }}</ion-text>\n        <ion-text class='sell-info-value' *ngIf=\"!loadingCommision\">\n         {{order?.commission?.totalTradeAmount | commafy }} {{'mutualFund.SAR' | translate}}</ion-text>\n        <ion-skeleton-text animated *ngIf=\"loadingCommision\"\n          style=\"width: 100%;max-width: 100px;height: 20px;border-radius: 5px;\">\n        </ion-skeleton-text>\n      </div>\n      <!-- icon-chevron-down-->\n      <div class=\"footer-icon-container\">\n        <div class=\"mirror chevron-div\" *ngIf=\"!expand\"><span class=\"icon icon-chevron-down chevron-icon\"></span></div>\n        <div *ngIf=\"expand\" class=\"chevron-div\"><span class=\"icon icon-chevron-down chevron-icon\"></span></div>\n        <!-- <span class=\"icon icon-info-o primary-color\"></span> -->\n      </div>\n    </ion-col>\n    <ion-col size=\"6\" class=\"before-border-div flex-row-info\" *ngIf=\"order.side?.id == OrderSidesEnum.buy\"\n      (click)=\"getLatestBuyingPower()\">\n      <div class=\"flex-col-info\">\n        <ion-text class='sell-info-label'>{{'order.BUYING_POWER' | translate }} </ion-text>\n        <ion-text class='sell-info-value' *ngIf=\"isBuyingPowerLoaded\">\n          <!-- <span\n            *ngIf=\"!liveBuyingPower\">{{ ((Number(liveBuyingPower) + Number(cachedRestoredBuyingPower || '0')) ) || '0' }}\n            {{'mutualFund.SAR' | translate}}</span> -->\n          <span *ngIf=\"liveBuyingPower\">{{ liveBuyingPower| number: '1.2-2'}} {{'mutualFund.SAR' | translate}}</span>\n        </ion-text>\n        <ion-skeleton-text *ngIf=\"!isBuyingPowerLoaded\" animated\n          style=\"width: 100%;max-width: 100px;height: 20px;border-radius: 5px;\">\n        </ion-skeleton-text>\n      </div>\n      <div class=\"footer-icon-container\">\n        <span class=\"icon icon-reload primary-color\"></span>\n      </div>\n\n    </ion-col>\n\n    <ion-col size=\"6\" class=\"before-border-div flex-row-info\" *ngIf=\"order.side?.id == OrderSidesEnum.sell\"\n      (click)=\"refreshSymbolShares()\">\n      <div class=\"flex-col-info\">\n        <ion-text class='sell-info-label'>{{'order.OWNED_AMOUNT' | translate }}\n        </ion-text>\n        <ion-text *ngIf=\"order.symbol != null && isSymbolShareLoaded\" class='sell-info-value'>\n          {{ +order.symbol?.availableQuantity || '0' }}\n          {{ 'order.SHARES' | translate  }}\n        </ion-text>\n        <ion-text *ngIf=\"order.symbol == null\" class='sell-info-value'>\n          {{ '0' }}\n          {{ 'order.SHARES' | translate  }}\n        </ion-text>\n        <ion-skeleton-text *ngIf=\"!isSymbolShareLoaded && order?.symbol\" animated\n          style=\"width: 100%;max-width: 100px;height: 20px;border-radius: 5px;\"></ion-skeleton-text>\n      </div>\n      <div class=\"footer-icon-container\">\n        <span class=\"icon icon-reload primary-color\"></span>\n      </div>\n\n    </ion-col>\n\n  </ion-row>\n  <tadawul-expandable expandHeight=\"130px\" [expanded]=\"expand\">\n    <tadawul-commission [order]=\"order\" [type]=\"commissionType.SUBMIT_ORDER\" [form]=\"form\"\n      (onChange)=\"onCommissionLoaded($event)\"></tadawul-commission>\n  </tadawul-expandable>\n  <div style=\"z-index: 200;padding: 10px 16px;\">\n    <ion-button id='save-button' expand=\"block\" (click)=\"execute()\" [disabled]=\"(!form.valid && pageMode != OrderPageMode.edit) || (pageMode == OrderPageMode.edit && !form.dirty && form.valid) || (pageMode == OrderPageMode.edit && form.dirty && !form.valid)\">\n\n      <span *ngIf=\"pageMode == OrderPageMode.edit\">\n        <span *ngIf=\"order.side?.id == OrderSidesEnum.buy\">{{ 'order.edit_buy_order' | translate  }}</span>\n        <span *ngIf=\"order.side?.id == OrderSidesEnum.sell\">{{ 'order.edit_sell_order' | translate  }}</span>\n      </span>\n\n      <span *ngIf=\"pageMode != OrderPageMode.edit\">\n        <span *ngIf=\"order.side?.id == OrderSidesEnum.buy\">{{ 'order.BUY_ORDER2' | translate  }}</span>\n        <span *ngIf=\"order.side?.id == OrderSidesEnum.sell\">{{ 'order.SELL_ORDER2' | translate  }}</span>\n      </span>\n\n    </ion-button>\n  </div>\n</ion-footer>\n";

/***/ }),

/***/ 67085:
/*!************************************************************************!*\
  !*** ./src/app/pages/order/summary/order-summary.page.html?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>{{ 'order.SUMMARY_ORDER' | translate }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"ion-text-center\">\n    <div class=\"success-check\">\n      <span class=\"success-icon icon-tick\"></span>\n    </div>\n    <ion-text class=\"message-txt\">{{'order.ORDER_PLACED' | translate}}</ion-text>\n    <div class=\"info-txt\">{{ 'order.ORDER_NUMBER' | translate }} : {{order?.referenceNumber}}</div>\n  </div>\n\n  <ion-button expand=\"block\" class=\"confirm-button\" (click)=\"toOutstandingOrders()\" >{{'order.BACK_TO_OUTSTANDING_ORDERS' | translate}}</ion-button>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=default-src_app_pages_order_confirm_order-confirm_page_ts-src_app_pages_order_order_page_ts.js.map