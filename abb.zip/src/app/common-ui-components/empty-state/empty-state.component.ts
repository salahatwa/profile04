import { Component, OnInit, Input, Output, EventEmitter, HostBinding } from '@angular/core';

@Component({
  selector: 'app-empty-state',
  templateUrl: './empty-state.component.html',
  styleUrls: ['./empty-state.component.scss'],
  // host: {'class': 'parent'}
})
export class EmptyStateComponent implements OnInit {

  constructor() { }
  // @HostBinding('class') class = 'parent';
  @Input() message:any;
  @Input() secondMessage:String;
  @Input() image:String;
  @Input() button:boolean;
  @Input() buttonValue:String;
  @Input() msgColor :string;
  @Output() buttonClicked = new EventEmitter<any>();//+ Event emitter

  click() {
    this.buttonClicked.emit();
  }

  ngOnInit() {}

}
