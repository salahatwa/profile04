import { TranslateModule } from '@ngx-translate/core';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ForgetUsernamePasswordPageRoutingModule } from './forget-username-password-routing.module';

import { ForgetUsernamePasswordPage } from './forget-username-password.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ForgetUsernamePasswordPageRoutingModule,
    TranslateModule.forChild()
  ],
  declarations: [ForgetUsernamePasswordPage]
})
export class ForgetUsernamePasswordPageModule {}
