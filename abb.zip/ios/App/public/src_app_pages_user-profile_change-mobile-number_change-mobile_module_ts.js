"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_user-profile_change-mobile-number_change-mobile_module_ts"],{

/***/ 4753:
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/user-profile/change-mobile-number/change-mobile-routing.module.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChangeMobilePageRoutingModule": () => (/* binding */ ChangeMobilePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _change_mobile_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./change-mobile.page */ 71160);




const routes = [
    {
        path: '',
        component: _change_mobile_page__WEBPACK_IMPORTED_MODULE_0__.ChangeMobilePage
    }
];
let ChangeMobilePageRoutingModule = class ChangeMobilePageRoutingModule {
};
ChangeMobilePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ChangeMobilePageRoutingModule);



/***/ }),

/***/ 79671:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/user-profile/change-mobile-number/change-mobile.module.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChangeMobilePageModule": () => (/* binding */ ChangeMobilePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _change_mobile_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./change-mobile-routing.module */ 4753);
/* harmony import */ var _change_mobile_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./change-mobile.page */ 71160);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);









let ChangeMobilePageModule = class ChangeMobilePageModule {
};
ChangeMobilePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _change_mobile_routing_module__WEBPACK_IMPORTED_MODULE_0__.ChangeMobilePageRoutingModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateModule.forChild()
        ],
        declarations: [_change_mobile_page__WEBPACK_IMPORTED_MODULE_1__.ChangeMobilePage]
    })
], ChangeMobilePageModule);



/***/ }),

/***/ 71160:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/user-profile/change-mobile-number/change-mobile.page.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChangeMobilePage": () => (/* binding */ ChangeMobilePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _change_mobile_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./change-mobile.page.html?ngResource */ 95191);
/* harmony import */ var _change_mobile_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./change-mobile.page.scss?ngResource */ 43529);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _inma_models_change_mobile_change_mobile_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/models/change-mobile/change-mobile.model */ 11695);
/* harmony import */ var _change_mobile_translations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./change-mobile.translations */ 44150);
/* harmony import */ var _inma_helpers_translations__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @inma/helpers/translations */ 69353);










let ChangeMobilePage = class ChangeMobilePage {
    constructor(formBuilder, sharedData, navCtrl) {
        this.formBuilder = formBuilder;
        this.sharedData = sharedData;
        this.navCtrl = navCtrl;
        this.t = _change_mobile_translations__WEBPACK_IMPORTED_MODULE_4__.ChangeMobileTranslations;
        this.newMobileNumber = '';
        this.otp = '';
        this.numberEntered = false;
        this.submitted_1 = false;
        this.submitted_2 = false;
        this.buildForm();
    }
    buildForm() {
        this.form = this.formBuilder.group({
            newMobileNumber: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.pattern("[0-9]*"), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(9), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(12)])],
            otp: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required])]
        });
    }
    get f() { return this.form.controls; }
    ngOnInit() {
        _inma_models_change_mobile_change_mobile_model__WEBPACK_IMPORTED_MODULE_3__.ChangeMobile.getCurrentMobileNumber().subscribe(result => {
            console.log(result, "user mobile number");
        });
    }
    saveChanges(form) {
        this.submitted_1 = true;
        console.log(!this.f.newMobileNumber.errors);
        if (!this.f.newMobileNumber.errors && !this.f.newMobileNumber.disabled) {
            console.log(this.f.newMobileNumber.value);
            _inma_models_change_mobile_change_mobile_model__WEBPACK_IMPORTED_MODULE_3__.ChangeMobile.changeCustomerMobileNumber(this.f.newMobileNumber.value).subscribe(result => {
                console.log(result);
                this.numberEntered = true;
                this.f.newMobileNumber.disable();
            });
            return;
        }
        if (this.f.newMobileNumber.disabled) {
            this.submitted_2 = true;
            if (!this.f.otp.errors) {
                console.log(this.form);
                console.log('new mobile: ' + this.f.newMobileNumber.value + ' otp: ' + this.f.otp.value);
                _inma_models_change_mobile_change_mobile_model__WEBPACK_IMPORTED_MODULE_3__.ChangeMobile.confirmMobileNumberChange(this.f.otp.value).subscribe(result => {
                    console.log(result);
                    this.sharedData.setSharedData(true, 'mobile_changed');
                    this.navCtrl.navigateForward('main/user-profile');
                });
            }
        }
    }
    edit() {
        this.numberEntered = false;
        this.f.otp.reset();
        this.form.controls.newMobileNumber.enable();
    }
    resendOTP() {
        _inma_models_change_mobile_change_mobile_model__WEBPACK_IMPORTED_MODULE_3__.ChangeMobile.resendOTP().subscribe(result => {
            console.log(result);
        });
    }
};
ChangeMobilePage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder },
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_2__.SharedDataService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController }
];
(0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_inma_helpers_translations__WEBPACK_IMPORTED_MODULE_5__.Translations)(),
    (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__metadata)("design:type", Object)
], ChangeMobilePage.prototype, "t", void 0);
ChangeMobilePage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'tadawul-change-mobile',
        template: _change_mobile_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_change_mobile_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__metadata)("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder, src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_2__.SharedDataService, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController])
], ChangeMobilePage);



/***/ }),

/***/ 44150:
/*!***************************************************************************************!*\
  !*** ./src/app/pages/user-profile/change-mobile-number/change-mobile.translations.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChangeMobileTranslations": () => (/* binding */ ChangeMobileTranslations)
/* harmony export */ });
class Translations {
    constructor() {
        this.CHANGE_MOBILE_NUMBER = ['تغيير رقم الجوال', 'Change Mobile Number'];
        this.MOBILE_NUMBER = ['رقم الجوال', 'Mobile Number'];
        this.MOBILE_PATTERN = ['يجب أن يكون الرقم كالتالي 966XXXXXXXXX', 'The number must be like 966XXXXXXXXX'];
        this.MOBILE_REQUIRED = ['الرجاء ادخال رقم الجوال', 'Please enter the mobile number'];
        this.NUMBERS_ONLY = ['رقم الجوال يجب ان يحتوي على ارقام فقط', 'Mobile number must contain numbers only'];
        this.NUMBER_LENGTH = ['رقم الجوال يجب ان لا يكون اقل من ٩ ولا اكثر من ١٢ خانة', 'The mobile number must not be less than 9 or more than 12 digits'];
        this.OTP = ['رمز التفعيل', 'Activation code'];
        this.OTP_REQUIRED = ['يجب ادخال رمز التفعيل', 'The activation code must be entered'];
        this.RESEND_OTP = ['إعادة الإرسال', 'Resend Code'];
        this.EDIT = ['تعديل', 'Edit'];
        this.SAVE_CHANGES = ['حفظ التغييرات', 'Save Changes'];
    }
}
const ChangeMobileTranslations = new Translations();


/***/ }),

/***/ 11695:
/*!***************************************************************!*\
  !*** ./src/app/🌱models/change-mobile/change-mobile.model.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChangeMobile": () => (/* binding */ ChangeMobile),
/* harmony export */   "ChangeMobileModel": () => (/* binding */ ChangeMobileModel)
/* harmony export */ });
/* harmony import */ var _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/helpers/http */ 36802);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ 86942);


// import { cat } from "rxjs/observable/ErrorObservable";
class ChangeMobileModel {
    getCurrentMobileNumber() {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request("/customerSettings/customerSettings/getCurrentMobileNumber").pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.map)(result => {
            return result;
        }));
    }
    changeCustomerMobileNumber(newMobileNumber) {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request("/customerSettings/customerSettings/changeCustomerMobileNumber", { newMobileNumber: newMobileNumber }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.map)(result => {
            return result;
        }));
    }
    confirmMobileNumberChange(token) {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request("/customerSettings/customerSettings/confirmMobileNumberChange", { token: token }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.map)(result => {
            return result;
        }));
    }
    resendOTP() {
        return _inma_helpers_http__WEBPACK_IMPORTED_MODULE_0__.Http.request("/customerSettings/customerSettings/resendOTP").pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.map)(result => {
            return result;
        }));
    }
}
const ChangeMobile = new ChangeMobileModel;


/***/ }),

/***/ 43529:
/*!********************************************************************************************!*\
  !*** ./src/app/pages/user-profile/change-mobile-number/change-mobile.page.scss?ngResource ***!
  \********************************************************************************************/
/***/ ((module) => {

module.exports = "ion-item {\n  --border-color: transparent;\n  color: var(--ion-color-primary-txt);\n}\n\nion-toolbar {\n  --background: #005157;\n  --color: white;\n}\n\nion-label {\n  font-weight: bold;\n}\n\nion-input {\n  --padding-start: 8px!important;\n  border: solid 1px #99b9bc;\n}\n\nion-text.examble, ion-text.resend {\n  color: #f5455a;\n  font-size: 12px;\n}\n\nion-back-button {\n  color: white;\n}\n\n.validator-error {\n  color: #f5455a;\n  font-size: 14px;\n}\n\n.validator-error .error-msg {\n  display: none;\n}\n\n.validator-error .error-msg:first-child {\n  display: block;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoYW5nZS1tb2JpbGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksMkJBQUE7RUFFQSxtQ0FBQTtBQUFKOztBQUdBO0VBQ0kscUJBQUE7RUFDQSxjQUFBO0FBQUo7O0FBR0E7RUFDSSxpQkFBQTtBQUFKOztBQUdBO0VBQ0ksOEJBQUE7RUFDQSx5QkFBQTtBQUFKOztBQUlJO0VBQ0ksY0FBQTtFQUNBLGVBQUE7QUFEUjs7QUFLQTtFQUNJLFlBQUE7QUFGSjs7QUFLQTtFQUNJLGNBQUE7RUFDQSxlQUFBO0FBRko7O0FBSUE7RUFFSSxhQUFBO0FBRko7O0FBSUE7RUFDSSxjQUFBO0FBREoiLCJmaWxlIjoiY2hhbmdlLW1vYmlsZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taXRlbSB7XG4gICAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICAgIC8vIGNvbG9yOiAjMDA1NDU3O1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS10eHQpO1xufVxuXG5pb24tdG9vbGJhciB7XG4gICAgLS1iYWNrZ3JvdW5kOiAjMDA1MTU3O1xuICAgIC0tY29sb3I6IHdoaXRlO1xufVxuXG5pb24tbGFiZWwge1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuXG5pb24taW5wdXQge1xuICAgIC0tcGFkZGluZy1zdGFydDogOHB4IWltcG9ydGFudDtcbiAgICBib3JkZXI6IHNvbGlkIDFweCAjOTliOWJjO1xufVxuXG5pb24tdGV4dCB7XG4gICAgJi5leGFtYmxlLCAmLnJlc2VuZCB7XG4gICAgICAgIGNvbG9yOiAjZjU0NTVhO1xuICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgfVxufVxuXG5pb24tYmFjay1idXR0b24ge1xuICAgIGNvbG9yOiB3aGl0ZTtcbn1cblxuLnZhbGlkYXRvci1lcnJvciB7XG4gICAgY29sb3I6ICNmNTQ1NWE7XG4gICAgZm9udC1zaXplOiAxNHB4O1xufVxuLnZhbGlkYXRvci1lcnJvciAuZXJyb3ItbXNne1xuICAgIC8vIEhpZGRlbiBieSBkZWZhdWx0XG4gICAgZGlzcGxheTogbm9uZTtcbiAgfVxuLnZhbGlkYXRvci1lcnJvciAuZXJyb3ItbXNnOmZpcnN0LWNoaWxkIHtcbiAgICBkaXNwbGF5OiBibG9jaztcbn0iXX0= */";

/***/ }),

/***/ 95191:
/*!********************************************************************************************!*\
  !*** ./src/app/pages/user-profile/change-mobile-number/change-mobile.page.html?ngResource ***!
  \********************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button [text]=\"''\"></ion-back-button>\n    </ion-buttons>\n    <ion-title> {{'changeMobile.CHANGE_MOBILE_NUMBER' | translate}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <form [formGroup]=\"form\" (ngSubmit)=\"saveChanges(form)\">\n    <ion-list>\n      \n      <ion-item>\n        <ion-label position=\"stacked\">{{'changeMobile.MOBILE_NUMBER' | translate}}</ion-label>\n        <ion-input\n        name=\"newMobileNumber\"\n        formControlName=\"newMobileNumber\" [(ngModel)]=\"newMobileNumber\"\n        ></ion-input>\n        <ion-text class=\"examble\"> {{'changeMobile.MOBILE_PATTERN' | translate}}</ion-text>\n          <div *ngIf=\"f.newMobileNumber.errors && (submitted_1 || f.newMobileNumber.touched)\" class=\"validator-error\">\n            <div class=\"error-msg\" *ngIf=\"f.newMobileNumber.errors.required\"> {{'changeMobile.MOBILE_REQUIRED' | translate}}</div>\n            <div class=\"error-msg\" *ngIf=\"f.newMobileNumber.errors.pattern\"> {{'changeMobile.NUMBERS_ONLY' | translate}}</div>\n            <div class=\"error-msg\" *ngIf=\"f.newMobileNumber.errors.minlength || f.newMobileNumber.errors.maxlength\"> {{'changeMobile.NUMBER_LENGTH' | translate}}</div>\n          </div>\n      </ion-item>\n\n\n      <ion-item *ngIf=\"numberEntered\">\n        <ion-label position=\"stacked\"> {{'changeMobile.OTP' | translate}}</ion-label>\n        <ion-input\n        name=\"otp\"\n        formControlName=\"otp\" [(ngModel)]=\"otp\"\n        ></ion-input>\n        <div *ngIf=\"f.otp.errors && (submitted_2 || f.otp.touched)\" class=\"validator-error\">\n          <div class=\"error-msg\" *ngIf=\"f.otp.errors.required\"> {{'changeMobile.OTP_REQUIRED' | translate}}</div>\n        </div>\n        <ion-text (click)=\"resendOTP()\" class=\"resend\"> {{'changeMobile.RESEND_OTP' | translate}}</ion-text>\n      </ion-item>\n\n    </ion-list>\n  <ion-grid class=\"ion-padding\">\n    <ion-row *ngIf=\"numberEntered\">\n      <ion-col>\n        <app-button \n        expand=\"block\"\n        color=\"primary\"\n        fill=\"outline\"\n        strong=\"true\"\n        (clickAction)=\"edit()\"\n        >\n         {{'changeMobile.EDIT' | translate}}\n        </app-button>\n      </ion-col>\n      <!-- <ion-col>\n        <app-button \n        expand=\"block\"\n        color=\"primary\"\n        fill=\"outline\"\n        strong=\"true\"\n        >\n        استعادة\n        </app-button>\n      </ion-col> -->\n    </ion-row>\n\n    <app-button \n    expand=\"block\"\n    color=\"primary\"\n    fill=\"solid\"\n    strong=\"true\"\n    type=\"submit\"\n    >\n     {{'changeMobile.SAVE_CHANGES' | translate}}\n    </app-button>\n\n  </ion-grid>\n</form>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_user-profile_change-mobile-number_change-mobile_module_ts.js.map