"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_ui-samples_ui-samples_module_ts"],{

/***/ 57151:
/*!*********************************************************!*\
  !*** ./src/app/ui-samples/ui-samples-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UiSamplesPageRoutingModule": () => (/* binding */ UiSamplesPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ui_samples_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ui-samples.page */ 19608);




const routes = [
    {
        path: '',
        component: _ui_samples_page__WEBPACK_IMPORTED_MODULE_0__.UiSamplesPage
    }
];
let UiSamplesPageRoutingModule = class UiSamplesPageRoutingModule {
};
UiSamplesPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], UiSamplesPageRoutingModule);



/***/ }),

/***/ 18016:
/*!*************************************************!*\
  !*** ./src/app/ui-samples/ui-samples.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UiSamplesPageModule": () => (/* binding */ UiSamplesPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ui_samples_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ui-samples-routing.module */ 57151);
/* harmony import */ var _ui_samples_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ui-samples.page */ 19608);
/* harmony import */ var _common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../common-ui-components/tadawul-common-ui.module */ 50773);








let UiSamplesPageModule = class UiSamplesPageModule {
};
UiSamplesPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _ui_samples_routing_module__WEBPACK_IMPORTED_MODULE_0__.UiSamplesPageRoutingModule,
            _common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule
        ],
        declarations: [_ui_samples_page__WEBPACK_IMPORTED_MODULE_1__.UiSamplesPage]
    })
], UiSamplesPageModule);



/***/ }),

/***/ 19608:
/*!***********************************************!*\
  !*** ./src/app/ui-samples/ui-samples.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UiSamplesPage": () => (/* binding */ UiSamplesPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ui_samples_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ui-samples.page.html?ngResource */ 88082);
/* harmony import */ var _ui_samples_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ui-samples.page.scss?ngResource */ 40837);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let UiSamplesPage = class UiSamplesPage {
    constructor() {
        /********************TEST************************* */
        /*markrt Value **************************************/
        this.headerOne = 'Mohamed';
        this.headerTwo = 'ayman';
        this.headerThree = 'ali';
        this.headerFour = 'mekawy';
        this.valueOne = "we";
        this.valueTwo = "can";
        this.valueThree = "7676";
        this.valueFour = "2332";
        this.marketHeader = "marketHeaderText";
        this.marketGreen = "marketHeaderValuesGreen";
        this.marketRed = "marketHeaderValuesRed";
        this.marketGrid = "marketGrid";
        /***************changeable box ************* */
        this.boxContainer = "changeValueContainerRed";
        this.boxtextClass = "changableValueText";
        this.boxText = "93.6";
        /********************Segment******************* */
        this.text1 = "wallet wallet";
        this.text2 = "investment boxes";
        this.text3 = "boxes boxes";
        this.icon1 = "assets/icon/mutualfund.png";
        this.icon2 = "assets/icon/local-portfolio.png";
        this.icon3 = "assets/icon/mutualfund.png";
        /******************************Grid Header */
        this.headerListMenu = ["Text1", "Text2", "Text3", "Text4", "Text5"];
        /******************Portfolio********************** */
        this.arr = [1, 2, 3, 4, 5];
        /******* Meka *******************/
        this.slideOptsOne = {
            slidesPerView: 1.05,
            spaceBetween: 10
        };
        this.items = [
            { expanded: false },
            { expanded: false },
            { expanded: false }
        ];
    }
    ngOnInit() {
    }
    /********************MEKA************************* */
    /*********************collapseable controller */
    expandItem(item) {
        if (item.expanded) {
            item.expanded = false;
        }
        else {
            this.items.map(listItem => {
                if (item == listItem) {
                    listItem.expanded = !listItem.expanded;
                }
                else {
                    listItem.expanded = false;
                }
                return listItem;
            });
        }
    }
    toggleTheme() {
        document.body.classList.toggle('dark');
    }
};
UiSamplesPage.ctorParameters = () => [];
UiSamplesPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'tadawul-ui-samples',
        template: _ui_samples_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_ui_samples_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:paramtypes", [])
], UiSamplesPage);



/***/ }),

/***/ 40837:
/*!************************************************************!*\
  !*** ./src/app/ui-samples/ui-samples.page.scss?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ1aS1zYW1wbGVzLnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 88082:
/*!************************************************************!*\
  !*** ./src/app/ui-samples/ui-samples.page.html?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>ui-samples</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n<!-- /********************Portfolio ***********************/ -->\n<ion-grid>\n  <tadawul-slider-pager [slideOption]=\"slideOptsOne\">\n    <ion-slide  *ngFor=\"let x of arr\">\n      <tadawul-portfolio\n      leftTextOne=\"wallet number\"\n      leftTextTwo=\"54555\"\n      leftTextThree=\"investment wallet\"\n      rightText=\"Details\"\n      leftBoxText=\"Buy (sar)\"\n      leftBoxValue=\"96274063\"\n      rightBoxValue=\"52118463\"\n      rightBoxText=\"Wallet valu (sar)\"\n      ></tadawul-portfolio>\n    </ion-slide>\n  </tadawul-slider-pager>\n    <!-- </ion-slides> -->\n  </ion-grid>\n  \n  \n  \n    <!-- /********************changable value*****************************/ -->\n    <tadawul-changable-value-box \n    [containerClass]=\"boxContainer\"\n    [textClass]=\"boxtextClass\"\n    [boxValue]=\"boxText\"\n    >\n  </tadawul-changable-value-box>\n  \n    <!-- /*********************Market status***********************/ -->\n  <tadawul-market-value \n  [headerOne]=\"headerOne\" \n   [headerTwo]=\"headerTwo\"\n   [headerThree]=\"headerThree\"\n   [headerFour]=\"headerFour\"\n   [valueOne]=\"valueOne\"\n   [valueTwo]=\"valueTwo\"\n   [valueThree]=\"valueThree\"\n   [valueFour]=\"valueFour\"\n   [valOneClass]=\"marketGreen\"\n   [valTwoClass]=\"marketRed\"\n   [marketHeaderClass]=\"marketHeader\"\n   [marketGridClass]=\"marketGrid\"\n   >\n  </tadawul-market-value>\n    \n  \n    <!-- /**************************Tabs\\button group************************/ -->\n  \n  <tadawul-common-segment-group\n  [firstSegmentText]=\"text1\"\n  [secondSegmentText]=\"text2\"\n  [thirdSegmentText]=\"text3\"\n  [firstSegmentIcon]=\"icon1\"\n  [secondSegmentIcon]=\"icon2\"\n  [thirdSegmentIcon]=\"icon3\"\n  >\n  </tadawul-common-segment-group>\n  \n  \n  <!-- /***************************Stock quick view *****************************/ -->\n  \n  <tadawul-stock-quick-view\n  headerFirstText=\"Last Price\"\n  headerSecondText=\"Market Value\"\n  headerThirdText=\"Profit/loss Unrealized\"\n  headerFirstValue=\"3.24\"\n  headerSecondValue=\"533,453.87\"\n  headerThirdValue=\"293,847.92\"\n  middelText=\"Profit/loss Percentage\"\n  middelValue=\"-87.27%\"\n  firstBtnText=\"vip subscribe\"\n  secondBtnText=\"Refund\"\n  thirdBtnText=\"Yearly Report\"\n  >\n  </tadawul-stock-quick-view>\n  \n  <!-- *****************************collabseable list**********************/ -->\n   <tadawul-collapsible-list\n   cardTextOne=\"inmaa box\"\n   cardTextTwo=\"76.9\"\n   cardTextThree=\"9680\"\n   cardTextFour=\"87543\"\n   >\n  \n\n   <tadawul-stock-quick-view\n   headerFirstText=\"Last Price\"\n   headerSecondText=\"Market Value\"\n   headerThirdText=\"Profit/loss Unrealized\"\n   headerFirstValue=\"3.24\"\n   headerSecondValue=\"533,453.87\"\n   headerThirdValue=\"293,847.92\"\n   middelText=\"Profit/loss Percentage\"\n   middelValue=\"-87.27%\"\n   firstBtnText=\"vip subscribe\"\n   secondBtnText=\"Refund\"\n   thirdBtnText=\"Yearly Report\"\n   >\n   </tadawul-stock-quick-view>\n\n\n\n\n   </tadawul-collapsible-list>\n  \n  \n  <!-- /**********************grid header******************************> -->\n  <ion-grid>\n    <tadawul-grid-header\n    [headerList]=\"[{title:'title'},{title:'title'},{title:'title'},{title:'title'}]\"\n    ></tadawul-grid-header>\n    </ion-grid>\n\n    <ion-button (click)=\"toggleTheme()\" color=\"primary\">toggle theme</ion-button>\n    <ion-segment>\n      <ion-segment-button clas>\n        one\n      </ion-segment-button>\n      <ion-segment-button>\n        two\n      </ion-segment-button>\n      <ion-segment-button>\n        three\n      </ion-segment-button>\n    </ion-segment>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_ui-samples_ui-samples_module_ts.js.map