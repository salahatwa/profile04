import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'tadawul-loading',
  templateUrl: './loading.page.html',
  styleUrls: ['./loading.page.scss'],
  encapsulation: ViewEncapsulation.None
})
export class LoadingPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
