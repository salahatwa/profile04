import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'tadawul-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.scss'],
})
export class LoaderComponent implements OnInit {
@Input() addClass: string;
  constructor() { }

  ngOnInit() {}

}
