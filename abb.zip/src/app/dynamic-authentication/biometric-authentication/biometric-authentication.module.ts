import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BiometricAuthenticationPageRoutingModule } from './biometric-authentication-routing.module';

import { BiometricAuthenticationPage } from './biometric-authentication.page';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BiometricAuthenticationPageRoutingModule,
    TranslateModule.forChild()
  ],
  declarations: [BiometricAuthenticationPage]
})
export class BiometricAuthenticationPageModule {}
