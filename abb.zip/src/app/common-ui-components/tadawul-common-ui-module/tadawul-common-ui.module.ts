// import { NgModule } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { IonicModule } from '@ionic/angular';
// // import { MarketValueComponent } from '../market-value/market-value/market-value.component';
// // import { ExpandableComponent } from '../Expandable/expandable/expandable.component';
// // import { ChangableValueBoxComponent } from '../changable-value-box/changable-value-box/changable-value-box.component';
// // import { CommonSegmentGroupComponent } from '../common-segment-group/common-segment-group/common-segment-group.component';
// // import { SliderPagerComponent } from '../slider-pager/slider-pager/slider-pager.component';
// // import { PortfolioComponent } from '../portfolio/portfolio/portfolio.component';
// // import { StockQuickViewComponent } from '../stok-quick-view/stock-quick-view/stock-quick-view.component';
// // import { CollapsibleListComponent } from '../collapsible-list/collapsible-list/collapsible-list.component';
// import { ButtonComponent } from '../button/button.component';
// import { InputComponent } from '../input/input.component';



// @NgModule({
//   declarations: [
//     // MarketValueComponent,
//     // ExpandableComponent,
//     // ChangableValueBoxComponent,
//     // CommonSegmentGroupComponent,
//     // SliderPagerComponent,
//     // PortfolioComponent,
//     // StockQuickViewComponent,
//     // CollapsibleListComponent,
//     ButtonComponent,
//     InputComponent
//   ],
//   imports: [
//     CommonModule,
//     FormsModule,
//     ReactiveFormsModule,
//     IonicModule,
//   ],
//   exports: [
//     MarketValueComponent,
//     ExpandableComponent,
//     ChangableValueBoxComponent,
//     CommonSegmentGroupComponent,
//     SliderPagerComponent,
//     PortfolioComponent,
//     StockQuickViewComponent,
//     CollapsibleListComponent,
//     ButtonComponent,
//     InputComponent
//   ]
// })
// export class TadawulCommonUiModule { }
