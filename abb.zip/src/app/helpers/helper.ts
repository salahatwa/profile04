import { Injectable, Inject } from '@angular/core';
import { LangChangeEvent, TranslateService } from '@ngx-translate/core';

@Injectable()
export class AppHelper {
    mapper = {
      CHANGE_PASSWORD : ['تغيير كلمة المرور','Change Password'],
    CURRENT_PASSWORD : ['كلمة المرور الحالية' , 'Current Password'],
    FORGOT_PASSWORD : ['نسيت كلمة المرور', 'Forgot Password'],
    NEW_PASSWORD : ['كلمة المرور الجديدة' , 'New Password'],
    CONFIRM_NEW_PASSWORD : ['تأكيد كلمة المرور الجديدة' , 'Confirm New Password'],
    SAVE_CHANGES : ['حفظ التغييرات', 'Save Changes'],
    PASSWORD_RULES : [
        'كلمة المرور يجب ان لاتقل عن 8 خانات ولا تزيد عن 16\n\rكلمة المرور يجب ان تحتوي على الاقل على حرف واحد او رقم واحد\n\rكلمة المرور يجب ان لا تحتوي على فراغات\n\rكلمة المرور يجب ان لا تكون مطابقة لاسم المستخدم\n\rكلمة المرور حساسة لحالة الحروف الصغيرة والكبيرة\n\rكلمة المرور يجب ان لا تحتوي على رموز',
        'Password should be at least 8 characters and not more than 16 \n\r Password should have at least one charachter or one digit \n\r Password should not have spaces \n\r Password should not be the same as user name \n\r Password is case sensitive \n\r Password should not have symbols'
    ],
    CURRENT_PASSWORD_REQUIRED : ['الرجاء ادخال كلمة المرور الحالية', 'Please enter the current password'],
    NEW_PASSWORD_REQUIRED : ['الرجاء ادخال كلمة المرور الجديدة', 'Please enter the new password'],
    CONFIRM_PASSWORD_REQUIRED : ['الرجاء ادخال تأكيد كلمة المرور الجديدة', 'Please enter the confirm password'],
    PASSWORD_PATTERN : ['كلمة المرور يجب ان لا تحتوي على رموز', 'Password should not have symbols '],
    PASSWORD_MIN : ['كلمة المرور يجب أن لا تقل عن ٨ خانات', 'Password should be at least 8 characters'],
    PASSWORD_MAX : ['كلمة المرور يجب أن لا تكون اكثر من ١٦ خانة', 'Password should not be more than 16 characters'],
    UNMATCHED_PASSWORD : ['تأكيد كلمة المرور يجب ان يكون مطابق لكلمة المرور الجديدة', 'Confirm password must match the new password'],
    }

    constructor() {

    }

    mapLocalized() {

        let ar = '', en = '';
        Object.keys(this.mapper).forEach((val) => {
            ar += '"' + val + '":"' + this.mapper[val][0] + '",';
            en += '"' + val + '":"' + this.mapper[val][1] + '",';
        });
        console.log(ar)
        console.log(en)

    }
}

