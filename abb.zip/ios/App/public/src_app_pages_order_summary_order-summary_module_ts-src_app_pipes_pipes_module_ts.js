"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_order_summary_order-summary_module_ts-src_app_pipes_pipes_module_ts"],{

/***/ 46490:
/*!*********************************************************************!*\
  !*** ./src/app/pages/order/summary/order-summary-routing.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderSummaryPageRoutingModule": () => (/* binding */ OrderSummaryPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _order_summary_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./order-summary.page */ 87674);




const routes = [
    {
        path: '',
        component: _order_summary_page__WEBPACK_IMPORTED_MODULE_0__.OrderSummaryPage
    }
];
let OrderSummaryPageRoutingModule = class OrderSummaryPageRoutingModule {
};
OrderSummaryPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], OrderSummaryPageRoutingModule);



/***/ }),

/***/ 62798:
/*!*************************************************************!*\
  !*** ./src/app/pages/order/summary/order-summary.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderSummaryPageModule": () => (/* binding */ OrderSummaryPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _order_summary_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./order-summary-routing.module */ 46490);
/* harmony import */ var _order_summary_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./order-summary.page */ 87674);
/* harmony import */ var _commission_commission_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../commission/commission.module */ 89080);









let OrderSummaryPageModule = class OrderSummaryPageModule {
};
OrderSummaryPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _order_summary_routing_module__WEBPACK_IMPORTED_MODULE_0__.OrderSummaryPageRoutingModule,
            _commission_commission_module__WEBPACK_IMPORTED_MODULE_2__.CommissionComponentModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateModule.forChild()
        ],
        declarations: [_order_summary_page__WEBPACK_IMPORTED_MODULE_1__.OrderSummaryPage]
    })
], OrderSummaryPageModule);



/***/ }),

/***/ 20320:
/*!***********************************!*\
  !*** ./src/app/pipes/camelize.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CamelizePipe": () => (/* binding */ CamelizePipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_strings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/strings */ 36782);



let CamelizePipe = class CamelizePipe {
    transform(value, args) {
        return _inma_strings__WEBPACK_IMPORTED_MODULE_0__.Strings.camelize(value);
    }
};
CamelizePipe = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Pipe)({ name: 'camelize' })
], CamelizePipe);



/***/ }),

/***/ 98302:
/*!**********************************!*\
  !*** ./src/app/pipes/commafy.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommafyPipe": () => (/* binding */ CommafyPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let CommafyPipe = class CommafyPipe {
    transform(value, ...args) {
        if (value) {
            if (args.length > 0 && args[2] == 'debug')
                debugger;
            if (value == '_')
                return value;
            value = parseFloat(value.toString().replace(new RegExp(',', 'g'), ''));
            let str = value.toString().split('.');
            let precision = 0;
            // if (args && args.length && args[0].toLowerCase() == 'integer')
            //   precision = 0;
            // else
            if (args[1] || str[1]) // already contains fraction part, or demanded explicitly
                precision = args[1] || 2;
            value = Number(value);
            if (value.toFixed)
                value = value.toFixed(precision);
            str = value.toString().split('.');
            if (str[0].length > 3)
                str[0] = str[0].replace(/(\d)(?=(\d{3})+$)/g, '$1,');
            if (args && args.length) {
                if ('number' == args[0].toLowerCase())
                    if (str[1])
                        return str[0] + '.' + str[1];
                    else
                        return str[0];
                else if ('integer' == args[0].toLowerCase())
                    return str[0];
                else if ('fraction' == args[0].toLowerCase())
                    return str[1] || '0';
                else if ('percentage' == args[0].toLowerCase())
                    return parseInt((parseFloat(str.join('.')) * 100).toString()) + '%';
            }
            return str.join('.');
        }
        else
            return ''; //{int: '', fraction: ''};
    }
};
CommafyPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
        name: 'commafy',
    })
], CommafyPipe);



/***/ }),

/***/ 15803:
/*!************************************!*\
  !*** ./src/app/pipes/constants.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConstantsPipe": () => (/* binding */ ConstantsPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let ConstantsPipe = class ConstantsPipe {
    transform(value, ...args) {
        let keys = [];
        for (let key in value) {
            if (isNaN(Number(key)))
                keys.push(key);
        }
        return keys;
    }
};
ConstantsPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({ name: 'constants' })
], ConstantsPipe);



/***/ }),

/***/ 74935:
/*!****************************************!*\
  !*** ./src/app/pipes/enum-to-array.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EnumToArrayPipe": () => (/* binding */ EnumToArrayPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let EnumToArrayPipe = class EnumToArrayPipe {
    transform(value, ...args) {
        let result = [];
        var keys = Object.keys(value);
        var values = Object.values(value);
        for (var i = 0; i < keys.length; i++) {
            result.push({ key: keys[i], value: values[i] });
        }
        return result;
    }
};
EnumToArrayPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
        name: 'enumToArray'
    })
], EnumToArrayPipe);



/***/ }),

/***/ 555:
/*!*******************************!*\
  !*** ./src/app/pipes/keys.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "KeysPipe": () => (/* binding */ KeysPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let KeysPipe = class KeysPipe {
    transform(value, args) {
        let keys = [];
        for (let key in value) {
            keys.push(key);
        }
        return keys;
    }
};
KeysPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({ name: 'keys' })
], KeysPipe);



/***/ }),

/***/ 41041:
/*!***************************************!*\
  !*** ./src/app/pipes/pipes.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PipesModule": () => (/* binding */ PipesModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _safe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./safe */ 37930);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _commafy__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./commafy */ 98302);
/* harmony import */ var _keys__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./keys */ 555);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./constants */ 15803);
/* harmony import */ var _camelize__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./camelize */ 20320);
/* harmony import */ var _price__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./price */ 78981);
/* harmony import */ var _enum_to_array__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./enum-to-array */ 74935);









let PipesModule = class PipesModule {
};
PipesModule = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.NgModule)({
        declarations: [_commafy__WEBPACK_IMPORTED_MODULE_1__.CommafyPipe, _keys__WEBPACK_IMPORTED_MODULE_2__.KeysPipe, _constants__WEBPACK_IMPORTED_MODULE_3__.ConstantsPipe, _camelize__WEBPACK_IMPORTED_MODULE_4__.CamelizePipe, _price__WEBPACK_IMPORTED_MODULE_5__.SARPipe, _enum_to_array__WEBPACK_IMPORTED_MODULE_6__.EnumToArrayPipe, _safe__WEBPACK_IMPORTED_MODULE_0__.SafeHtml],
        imports: [],
        exports: [_commafy__WEBPACK_IMPORTED_MODULE_1__.CommafyPipe, _keys__WEBPACK_IMPORTED_MODULE_2__.KeysPipe, _constants__WEBPACK_IMPORTED_MODULE_3__.ConstantsPipe, _camelize__WEBPACK_IMPORTED_MODULE_4__.CamelizePipe, _price__WEBPACK_IMPORTED_MODULE_5__.SARPipe, _enum_to_array__WEBPACK_IMPORTED_MODULE_6__.EnumToArrayPipe, _safe__WEBPACK_IMPORTED_MODULE_0__.SafeHtml]
    })
], PipesModule);



/***/ }),

/***/ 78981:
/*!********************************!*\
  !*** ./src/app/pipes/price.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SARPipe": () => (/* binding */ SARPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/helpers/settings */ 96892);



let SARPipe = class SARPipe {
    constructor() {
        // @Translations()
        // t = AppTranslations;
        this.arabic = 'ر.س';
        this.english = 'SAR';
    }
    transform(value, ...args) {
        if (_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_0__.Settings.language == _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_0__.Languages.English) {
            return value + " " + this.english;
        }
        else if (_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_0__.Settings.language == _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_0__.Languages.Arabic) {
            return value + " " + this.arabic;
        }
    }
};
SARPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Pipe)({ name: 'SAR' })
], SARPipe);



/***/ }),

/***/ 37930:
/*!*******************************!*\
  !*** ./src/app/pipes/safe.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SafeHtml": () => (/* binding */ SafeHtml)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ 50318);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);



let SafeHtml = class SafeHtml {
    constructor(sanitizer) {
        this.sanitizer = sanitizer;
    }
    transform(html) {
        return this.sanitizer.bypassSecurityTrustHtml(html);
    }
};
SafeHtml.ctorParameters = () => [
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__.DomSanitizer }
];
SafeHtml = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Pipe)({ name: 'safe' }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__metadata)("design:paramtypes", [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__.DomSanitizer])
], SafeHtml);



/***/ })

}]);
//# sourceMappingURL=src_app_pages_order_summary_order-summary_module_ts-src_app_pipes_pipes_module_ts.js.map