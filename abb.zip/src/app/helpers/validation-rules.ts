export class ValidationRules {
    Expression = {
      NUMBERS_ONLY: '[0-9\u0660-\u0669]*',
    };
  }