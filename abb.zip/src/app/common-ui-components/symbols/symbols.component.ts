import { OnInit, Input, Output, EventEmitter, ChangeDetectionStrategy, ChangeDetectorRef, OnDestroy, ViewChild } from '@angular/core';
import { Translations } from '@inma/helpers/translations';
import { SymbolsTranslations } from './symbols.translations';
import { Symbols, SymbolState } from '@inma/models/symbol';

import { Component } from '@angular/core';
import { Symbol } from '@inma/models/symbol';
import { of } from 'rxjs';
import { debounced } from '@inma/helpers/debounced';
import fitty from 'fitty';
import sort from 'fast-sort';
import { IonContent } from '@ionic/angular';
import { SharedDataService } from 'src/app/providers/shared-data.service';

export enum SymbolColor {
  Loading = '#B4B0B0',
  Safe = '#21bf73',
  Danger = '#F93F03',
  Neutral = '#005457'
}



@Component({
  selector: 'tadawul-symbols',
  templateUrl: './symbols.component.html',
  styleUrls: ['./symbols.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SymbolsComponent implements OnInit, OnDestroy {
  Number = Number;
  Symbols = Symbols;
  filterQuery;
  @Input() symbolListClass : string;
  @Input() hidden = false;
  @Input() filterType :string;
  @Output() onSymbolChange = new EventEmitter();
  SymbolColor = SymbolColor;
  _allSymbols: Symbol[];
  defaultSymbols:Symbol[];
  updateInterval;
  down="down";
  up="up";
  zero = "zero"
  @ViewChild(IonContent, { static: false }) content: IonContent;
  constructor(private cdr: ChangeDetectorRef, public sharedData: SharedDataService,) { 
  }

  ngOnDestroy(): void {
    clearInterval(this.updateInterval);
  }

  ngOnInit() {
    this.updateInterval =setInterval(() => {
      this.cdr.detectChanges();
    }, 1000);

    Symbol.patchChange.subscribe(() => {
      if(this.changePercentageSortDirection!=2){this.sortByChangePercentage();}
    });

    this.sharedData.symbolSearchId.subscribe(symbolId=>{
      this.changePercentageSortDirection =2;
      this.sortByChangePercentage();
      this.scrollToSymbol(symbolId)
    });

    this.sharedData.symbolsFilterType.subscribe(filterType=>{
      if(filterType == 'TOP_TEN'){
        this.changePercentageSortDirection = 1;
      }else if(filterType == 'DOWN_TEN'){
        this.changePercentageSortDirection = 0;
      }else {
        this.changePercentageSortDirection = 2;
      }
      this.sortByChangePercentage();
    });
  }

  scrollToSymbol(symbolId){
    if(symbolId){
    let elmnt: HTMLElement = document.getElementById("symbolsData");
    let yOffset = document.getElementById(symbolId).offsetTop;
    this.content.scrollToPoint(0,yOffset - elmnt.offsetHeight + 265);
  }
  }

  @Input() set allSymbols(allSymbols: Symbol[]) {
    this.defaultSymbols = Object.assign([], allSymbols);
    this._allSymbols = allSymbols;
    this.symbols = allSymbols;
  }

  get allSymbols() {
    return this._allSymbols;
  }

  symbols: Symbol[];
  query;
  @debounced(250)
  filter(query) {
    this.query = query?.trim();
    Symbols.filter(query, of(this.allSymbols)).subscribe(symbols => {
      this.symbols = symbols;
      //this.sort();
    });
  }

  getColor(s: Symbol): SymbolColor {
    // TODO: Symbol color update
    if (!s) return SymbolColor.Loading;
    else return s.state === SymbolState.Unknown ? SymbolColor.Loading : (s.state === SymbolState.Down) ? SymbolColor.Danger : SymbolColor.Safe;
  }

  @Input() selectedSymbol = null;
  onSymbolSelect(s: Symbol) {
    this.onSymbolChange.emit(s);
  }


  // sort by name
  nameSortDirection = 2;
  nameSortIcon = "icon-sort";
  sortByName() {
     if (this.nameSortDirection == 1){
         this.symbols = [].concat(sort(this.symbols).desc(u => u.sortAbbreviation));
         this.nameSortIcon = "icon-sort-descending";
    }
    else if (this.nameSortDirection == 0){
        this.symbols = [].concat(sort(this.symbols).asc(u => u.sortAbbreviation));
        this.nameSortIcon = "icon-sort-ascending";
    }
     else if (this.nameSortDirection == 2){
       this.symbols = [].concat(this.defaultSymbols);
       this.nameSortIcon = "icon-sort";
     }

    this.cdr.detectChanges();
  }

  nameToggleSort() {
    this.changePercentageSortDirection = 2;
    this.changePercentageSortIcon ="icon-sort"
    if(this.nameSortDirection != 2){this.nameSortDirection += 1} else{this.nameSortDirection =0};
    this.sortByName();
  }

  //sort by change percentage
  changePercentageSortDirection = 2;
  changePercentageSortIcon ="icon-sort"
  sortByChangePercentage() {
    if (this.changePercentageSortDirection == 1){
      this.symbols = [].concat(sort(this.symbols).desc(u => Number(u.parameters.value.changePercentage)));
      this.changePercentageSortIcon = "icon-sort-descending";
    }
    else if (this.changePercentageSortDirection == 0){
      this.symbols = [].concat(sort(this.symbols).asc(u => Number(u.parameters.value.changePercentage)));
      this.changePercentageSortIcon = "icon-sort-ascending";
    }
     else if (this.changePercentageSortDirection == 2){
       this.symbols = [].concat(this.defaultSymbols);
       this.changePercentageSortIcon = "icon-sort";
     }
    this.cdr.detectChanges();
  }

  changePercentageToggleSort() {
    this.nameSortDirection = 2;
    this.nameSortIcon = "icon-sort";
    if(this.changePercentageSortDirection != 2){this.changePercentageSortDirection += 1} else{this.changePercentageSortDirection =0};
    this.sortByChangePercentage();
  }
}
