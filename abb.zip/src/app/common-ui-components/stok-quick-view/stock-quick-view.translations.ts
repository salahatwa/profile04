class Translations {
    default = ['المحفظة الافتراضية', 'Defalt Portfolio'];
    notDefault = ['تعيين كإفتراضي', 'Set as default'];
}


export const StockQuickViewTranslations = new Translations();
