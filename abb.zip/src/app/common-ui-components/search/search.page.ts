import { Component, Input, OnInit } from '@angular/core';
import { ModalController, NavParams, NavController } from '@ionic/angular';
import { Translations } from '@inma/helpers/translations';
import { SearchTranslations } from './search.translations';
import { Strings } from '@inma/helpers/strings';
import { ISearchable } from '@inma/helpers/searchable';
import { Symbols } from '@inma/models/symbol';
import { of } from 'rxjs';

@Component({
  selector: 'tadawul-search',
  templateUrl: './search.page.html',
  styleUrls: ['./search.page.scss'],
})
export class SearchPage implements OnInit {

  
  @Input() title: string;
  @Input() symbols: Symbol[];
  @Input() color;
  
  @Translations()
  t = SearchTranslations;

  ngOnInit() {
    Symbols.all.subscribe(symbols => {
      let s = this.symbols || symbols;
      this.allSearchables = s;
      this.searchables = this.allSearchables;
    });
  }


  allSearchables = [];
  queryText: string;
  searchables = [];

  constructor(public navCtrl: NavController, private modalCtrl: ModalController) {

  }

  filter() {
    console.log(this.queryText);
    
    Symbols.filter(this.queryText, of(this.allSearchables)).subscribe(symbols => {
      this.searchables = symbols;
    });
  }
  filter2() {
    console.log(this.queryText);
    let filteredSearchables = [];
    this.queryText = (<any>(this.queryText || '')).trimStart();
    if (this.queryText != '') {
      this.queryText = Strings.normalizeArabicNumbers(this.queryText.toLowerCase());

      const digitsRegex = /\d+/m;

      // Do extraction of the query text
      let queryNumbers = this.queryText.match(digitsRegex);
      let queryNumber = queryNumbers && queryNumbers.length > 0 ? queryNumbers[0].trim() : null;
      let queryWords = this.queryText.replace(digitsRegex, '').trim().toLowerCase();

      let secondFilteredSearchables = [];
      this.allSearchables.forEach((searchable: ISearchable) => {
        var matchValue = searchable?.toString()?.toLocaleLowerCase();
        if (!matchValue) return;
        let numberIndex = null, wordsIndex = null;
        if (queryNumber)
          numberIndex = matchValue.indexOf(queryNumber);
        if (queryWords)
          wordsIndex = matchValue.indexOf(queryWords);

        if (numberIndex != null && numberIndex != -1) {
          if (wordsIndex == null || (wordsIndex != null && wordsIndex != -1)) {
            if (numberIndex == 0)
              filteredSearchables.push(searchable);
            else
              secondFilteredSearchables.push(searchable);
          }
        } else if (numberIndex == null && wordsIndex && wordsIndex != -1) {
          filteredSearchables.push(searchable);
        }
      }
      )
      filteredSearchables.push(...secondFilteredSearchables);
    } else
      filteredSearchables = this.allSearchables;

    this.searchables = filteredSearchables
  }

  select(searchable) {
    this.closeModal(searchable);
  }

  dismiss() {
    this.modalCtrl.dismiss();
  }

  closeModal(selectedSearchable: ISearchable) {
    this.modalCtrl.dismiss(selectedSearchable);
  }


}

