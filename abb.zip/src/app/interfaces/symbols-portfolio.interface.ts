export interface Symbol {
    code: string;
}

export interface AvgCostPrice {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface TotalCost {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface TotalMrktValue {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface UnrealizedProfitLoss {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface SymbolPortfoliosInfo {
    portfolioNumber: string;
    symbol: Symbol;
    ownedQuantity: string;
    outstandSellQuantity?: any;
    outstandBuyQuantity?: any;
    pledgedQuantity: string;
    availQuantity?: any;
    avgCostPrice: AvgCostPrice;
    mrktPrice?: any;
    totalCost: TotalCost;
    totalMrktValue: TotalMrktValue;
    unrealizedProfitLoss: UnrealizedProfitLoss;
    realizedProfitLoss?: any;
    unrealizedProfitLossPercen: string;
    realizedProfitLossPercen?: any;
    portfolioPer: number;
    additionDisplayData?: any;
    productType?: any;
    productQuantity: number;
    securityType?: any;
    couponDays?: any;
    couponAmount?: any;
    secArName?: any;
    secEnName?: any;
}

export interface SymbolPortfolios {
    totalOwnedQuantity: string;
    totalProfitLoss: string;
    symbolPortfoliosInfo: SymbolPortfoliosInfo[];
}