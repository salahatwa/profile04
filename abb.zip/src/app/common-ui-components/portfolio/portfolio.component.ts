import { PortfolioInfo } from './../../interfaces/portofolio.interface';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';
import { debug } from 'logrocket';
import { HomeTranslations } from 'src/app/tadawul-home/home.translation';
import { PortfolioDetailsInfo } from 'src/app/interfaces/refactor/portfolio-info.interface';
import { PortfolioActionsPage } from './../../pages/portfolio-actions/portfolio-actions.page';


import { ChartHelper } from './../../../helpers/chart.helper';
import { Component, OnInit, Input, ViewChild, Output, EventEmitter, ChangeDetectorRef, AfterViewInit, OnChanges, SimpleChanges } from '@angular/core';
import { Languages, Settings } from '@inma/helpers/settings';
import { Portfolio } from '@inma/models/portfolio';
import { IonSlides, ModalController } from '@ionic/angular';
import fitty from 'fitty';
import * as ApexCharts from 'apexcharts';
import { PortfolioInfoCardComponent } from 'src/app/pages/portfolios/portfolio-info-card/portfolio-info-card.component';
import * as $ from 'jquery';
import { SharedDataService } from 'src/app/providers/shared-data.service';
import { Translations } from '@inma/helpers/translations';

@Component({
  selector: 'tadawul-portfolio',
  templateUrl: './portfolio.component.html',
  styleUrls: ['./portfolio.component.scss'],
})
export class PortfolioComponent implements OnInit, OnChanges {

  @ViewChild('slider', { static: false }) slidefromHtml: IonSlides;
  public profitloss: number;
  public direction: string

  @Output() detailClick = new EventEmitter();
  @Output() defaultBtnClick = new EventEmitter();
  @Output() notdefaultBtnClick = new EventEmitter();
  Number = Number;
  @Input() portfolioInfo: PortfolioDetailsInfo;
  @Input() portfolio: PortfolioInfo;
  footerLeftValueClass: string;
  constructor(
    private cdr: ChangeDetectorRef,
    private modalCtrl: ModalController,
    public sharedData: SharedDataService,
    private translate: TranslateService
  ) {
  }
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['portfolioInfo']) {
      this.footerLeftValueClass = this.portfolioInfo?._totalLoss < 0 ? 'item-value text-down' : 'item-value text-up'
      setTimeout(() => {
        if (this.portfolio?.number == this.portfolioInfo?._portfolioNumber) {
          this.loadChart();
          this.cdr.detectChanges();
        }
      }, 200);
    }
  }

  ngOnInit() {
    if (this.translate.currentLang == 'ar') {
      this.direction = "rightDirection"
    } else {
      this.direction = "leftDirection"
    }
    this.translate.onLangChange.subscribe((event: LangChangeEvent) => {
      if (event.lang == 'ar') {
        this.direction = "rightDirection"
      } else {
        this.direction = "leftDirection"
      }
    });
    setTimeout(() => {
      fitty('#portfolio-middle-right-text-container .portfolio-middle-text', {
        minSize: 8,
        maxSize: 10,
        multiLine: false
      });
      fitty('#portfolio-middle-left-text-container .portfolio-middle-text', {
        minSize: 8,
        maxSize: 10,
        multiLine: false
      });
      fitty('#portfolio-middle-right-value-container .portfolio-footer-value', {
        minSize: 8,
        maxSize: 13,
        multiLine: false
      });

      fitty('#buying-power span', {
        minSize: 8,
        maxSize: 13,
        multiLine: false
      });


      fitty('#portfolio-middle-left-value-container .portfolio-footer-value', {
        minSize: 8,
        maxSize: 13,
        multiLine: false
      });
    }, 1000);

  }


  uncommafy(value) {
    if (value) {
      return value.toString().replace(/,/g, '');
    }
    else {
      return;
    }
  }

  getActiveSlide() {
    this.slidefromHtml.getActiveIndex().then(id => {
      console.log('your index', id);
    }
    );
  }

  public detailClicked() {
    this.detailClick.emit();
  }

  public defaultBtnClicked() {
    this.defaultBtnClick.emit();
  }

  public notDefaultBtnClicked() {
    this.notdefaultBtnClick.emit();
  }


  loadChart() {
    let chartValues = [Number(this.portfolioInfo?._cashPercentage), Number(this.portfolioInfo?._unitPercentage)];
    let pieSeries = [];
    let piePattern = [];
    let patternType = [];
    let pieColors = [];
    if (chartValues.every((val) => val == 0)) {
      pieSeries = [1];
      pieColors = ['#337479'];
    } else {
      pieColors = ['#7aabde', '#fc0'];
      chartValues.forEach((val, idx) => {
        if (val < 0) {
          pieSeries.push(Math.abs(val));
          piePattern.push('slantedLines');
          patternType.push('pattern');
          pieColors[idx] = '#f5455a'
        } else {
          pieSeries.push(val);
          piePattern.push('');
          patternType.push('solid');
        }
      });
    }

    var options = {
      states: {
        active: {
          filter: {
            type: 'none' /* none, lighten, darken */,
            value: 0
          }
        }
      },
      series: pieSeries,
      colors: pieColors,
      chart: {
        height: 100,
        type: 'donut',
      },
      dataLabels: {
        enabled: false,
      },
      tooltip: {
        enabled: false
      },
      fill: {
        // type: "gradient",
        // gradient: {
        //   shadeIntensity: 1,
        //   opacityFrom: 0.7,
        //   opacityTo: 0.9,
        //   stops: [0, 90, 100]
        // }
        type: patternType,
        opacity: 1,
        pattern: {
          enabled: true,
          style: piePattern
        }
      },
      plotOptions: {
        pie: {
          expandOnClick: false,
          donut: {
            size: '70%',
            labels: {}
          }
        }
      },
      legend: {
        show: false
      }, stroke: {
        show: false,
        width: 0
      },
    };
    if (this.portfolioInfo) {

      $('#chart_' + this.portfolioInfo._portfolioNumber).empty();
      var chart = new ApexCharts(document.querySelector('#chart_' + this.portfolioInfo._portfolioNumber), options);
      chart.render();
    }
  }

  async openActions() {
    alert(1)
    const modal = await this.modalCtrl.create({
      component: PortfolioActionsPage,
      cssClass: 'auto-height-modal',
      componentProps: {
        portfolio: this.portfolioInfo
      },
      backdropBreakpoint: 0.9,
      swipeToClose: true,
    });

    modal.onDidDismiss().then((data) => {
    });

    return await modal.present();
  }


}
