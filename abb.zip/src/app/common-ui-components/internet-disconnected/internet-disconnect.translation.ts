import { AppTranslations } from 'src/app/app.translations';

class Translations extends AppTranslations {
    textOne = ['لايوجد اتصال بالإنترنت', 'No internet connection'];
    textTwo = ["الرجاء التأكد من توفر الاتصال بالإنترنت", "Please check your internet availability"];
    goToLogin = ['الذهاب إلى صفحة الدخول', 'Go to login page'];
  
}

export const InternetDisconnectTranslations = new Translations();