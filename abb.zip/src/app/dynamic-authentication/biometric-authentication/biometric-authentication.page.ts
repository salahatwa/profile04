import { Component, OnInit } from '@angular/core';
import { Biometric } from '@inma/helpers/biometric';
import { Authentication } from '@inma/models/authentication/authentication.model';
import { Authentication2 } from '@inma/models/users/authentication';
import { AuthenticationGroup } from '@inma/models/users/authentication-group';
import { ModalController, NavController, NavParams } from '@ionic/angular';
import { DynamicAuthenticationTranslations } from '../dynamic-authentication.translations';
import { Translations } from "@inma/helpers/translations";
import { map } from 'rxjs/operators';
import { debug } from 'logrocket';

@Component({
  selector: 'tadawul-biometric-authentication',
  templateUrl: './biometric-authentication.page.html',
  styleUrls: ['./biometric-authentication.page.scss'],
})
export class BiometricAuthenticationPage implements OnInit {

  @Translations()
  t = DynamicAuthenticationTranslations;
  opened: boolean;

  get biometricAction() {
    return Biometric.type + this.action;
  }
  static action: string;
  static authenticationGroup: AuthenticationGroup;

  static isStored() {
    return Biometric.isStored().pipe(map(result => {
      return !!result;
    }));
  }

  ngOnInit() {
    this.opened = true;
    if (!Biometric.type)
      this.closeBiometricAuthentication();

    Biometric.verify("Verify" + (this.action == "Authenticate" ? this.action : "Other")).subscribe(result => {
      if (result) {
        if (result == "NOT_STORED" || result == "NOT_VERIFIED" || result == "CANCELLED" || result?.startsWith('Error')) {
          this.closeBiometricAuthentication(false);
        } else {
          var storedUsername = result.split('#:#')[0];
          var storedKey = result.split('#:#')[1];
          this.authenticateBiometric(storedUsername, storedKey)
        }
      }
      else {
        if (this.opened) {
          Biometric.delete().subscribe();
          this.closeBiometricAuthentication(false);
        }
      }
    })
  }

  get action() {
    return BiometricAuthenticationPage.action;
  }
  get authenticationGroup() {
    return BiometricAuthenticationPage.authenticationGroup;
  }



  constructor(public navCtrl: NavController, public navParams: NavParams, private modalCtrl: ModalController) {
    // this.action = navParams.get('action')
    // this.authenticationGroup = navParams.get('group');
    // this.translate.get("authentication." + Biometric.type + this.action).subscribe(value => {
    // });
  }


  authenticateBiometric(storedUsername, storedKey) {
    console.log("Login key " + storedKey);
    Authentication.encrypt(storedKey).subscribe(encryptedKey => {
      this.authenticationGroup.methods[0].value = encryptedKey;
      console.log("Login Key encrypted" + encryptedKey);


      Authentication2.authenticateSourceAction(this.authenticationGroup.groupName, this.authenticationGroup.methods)
        .subscribe(response => {

          if (response) {
            Authentication2.dynamicAuthenticationSubject.next(response);
          }
          else {
            Authentication2.dynamicAuthenticationSubject.error(response);
          }
          Authentication2.dynamicAuthenticationSubject.complete();

          this.closeBiometricAuthentication(true);
        });
    });
  }

  closeBiometricAuthentication(isSuccess = null) {
    setTimeout(() => {
      this.opened = false;
      this.modalCtrl.dismiss(isSuccess, null, 'biometric-authentication-page');
    }, 500);
  }

}
