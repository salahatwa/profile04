import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NavController } from '@ionic/angular';
import { kycTranslations } from '../../../kyc/kyctranslation';
import { Translations } from '@inma/helpers/translations';
import { Kyc } from '@inma/models/kyc/';
import { resetCache } from '@inma/helpers/cached';

@Component({
  selector: 'tadawul-ideal-investment-portfolio',
  templateUrl: './ideal-investment-portfolio.component.html',
  styleUrls: ['./ideal-investment-portfolio.component.scss'],
})
export class IdealInvestmentPortfolioComponent implements OnInit {
  form: FormGroup;
  t = kycTranslations;
  public showLoader = false;
  formData = {};
  details = {
    investmentInfo: {
      sharesRiskPerc: {
        low: "",
        medium: "",
        high: "",
      },
      investmentFundsRiskPerc: {
        low: "",
        medium: "",
        high: "",
      },
      debtInstrumentsRiskPerc: {
        low: "",
        medium: "",
        high: "",
      },
      otherFinancialInfo: "",
      riskLevel: {
        code: ""
      }
    }
  };
  total;

  constructor(private formBuilder: FormBuilder, private navCtrl: NavController) { 
    this.buildForm();
  }

  ngOnInit() {
    Kyc.details.subscribe( details => {
      console.log(details);

      this.form.controls['otherFinancialInfo'].setValue(details.investmentInfo.otherFinancialInfo);
      this.details = details;

      if(this.isRiskLevelLow()) {
        this.form.controls['shares'].setValue(details.investmentInfo.sharesRiskPerc.low);
        this.form.controls['sukuk'].setValue(details.investmentInfo.debtInstrumentsRiskPerc.low);
        this.form.controls['investmentFunds'].setValue(details.investmentInfo.investmentFundsRiskPerc.low);
        details.investmentInfo.sharesRiskPerc.medium = 0;
        details.investmentInfo.sharesRiskPerc.high = 0;
        details.investmentInfo.debtInstrumentsRiskPerc.medium = 0;
        details.investmentInfo.debtInstrumentsRiskPerc.high = 0;
        details.investmentInfo.investmentFundsRiskPerc.medium = 0;
        details.investmentInfo.investmentFundsRiskPerc.high = 0;
        this.calcTotal();
      }
      else if(this.isRiskLevelMedium()) {
        this.form.controls['shares'].setValue(details.investmentInfo.sharesRiskPerc.medium);
        this.form.controls['sukuk'].setValue(details.investmentInfo.debtInstrumentsRiskPerc.medium);
        this.form.controls['investmentFunds'].setValue(details.investmentInfo.investmentFundsRiskPerc.medium);
        details.investmentInfo.sharesRiskPerc.low = 0;
        details.investmentInfo.sharesRiskPerc.high = 0;
        details.investmentInfo.debtInstrumentsRiskPerc.low = 0;
        details.investmentInfo.debtInstrumentsRiskPerc.high = 0;
        details.investmentInfo.investmentFundsRiskPerc.low = 0;
        details.investmentInfo.investmentFundsRiskPerc.high = 0;
        this.calcTotal();
      }
      else if(this.isRiskLevelHigh()) {
        this.form.controls['shares'].setValue(details.investmentInfo.sharesRiskPerc.high);
        this.form.controls['sukuk'].setValue(details.investmentInfo.debtInstrumentsRiskPerc.high);
        this.form.controls['investmentFunds'].setValue(details.investmentInfo.investmentFundsRiskPerc.high);
        details.investmentInfo.sharesRiskPerc.medium = 0;
        details.investmentInfo.sharesRiskPerc.low = 0;
        details.investmentInfo.debtInstrumentsRiskPerc.medium = 0;
        details.investmentInfo.debtInstrumentsRiskPerc.low = 0;
        details.investmentInfo.investmentFundsRiskPerc.medium = 0;
        details.investmentInfo.investmentFundsRiskPerc.low = 0;
        this.calcTotal();
      }

      this.details['contact'] = null;
      // this.calcTotal();
    });
  }

  isRiskLevelLow() {
    return this.details.investmentInfo.riskLevel.code == '03';
  }

  isRiskLevelMedium() {
    return this.details.investmentInfo.riskLevel.code == '02';
  }

  isRiskLevelHigh() {
    return this.details.investmentInfo.riskLevel.code == '01';
  }

  buildForm() {
    this.form = this.formBuilder.group({
      shares: [
        '', Validators.compose([
          Validators.required
        ])
      ],
      sukuk: [
        '', Validators.compose([
          Validators.required
        ])
      ],
      investmentFunds: [
        '', Validators.compose([
          Validators.required
        ])
      ],
      total: [
        '', Validators.compose([
          Validators.required
        ])
      ],
      otherFinancialInfo: []
    });
  }

  calcTotal() {
    let sukukVal = parseInt(this.form.controls['sukuk'].value) ? parseInt(this.form.controls['sukuk'].value) : 0;
    let sharesVal = parseInt(this.form.controls['shares'].value) ? parseInt(this.form.controls['shares'].value) : 0;
    let invFundsVal = parseInt(this.form.controls['investmentFunds'].value) ? parseInt(this.form.controls['investmentFunds'].value) : 0;

    this.form.controls['total'].setValue(String(sharesVal+ sukukVal + invFundsVal));
    this.total = String(sharesVal + sukukVal + invFundsVal);
    console.log(this.total);
  }

  saveSettings(form) {
    console.log(form.valid);
    if (form.invalid || this.total >100) {
      return;
    }
    //Kyc.updateDetails(this.details);
    this.showLoader = true;
    Kyc.updateDetails(this.details).subscribe(() => {
      resetCache(Kyc, 'details');
      this.showLoader = false;
      this.navCtrl.navigateRoot('/kyc/home', { animated: true });
    },
    err => {
      console.log('HTTP Error', err);
      this.showLoader = false;
    });
  }
}
