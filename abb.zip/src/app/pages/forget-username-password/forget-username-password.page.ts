import { Component, OnInit } from '@angular/core';
import { Translations } from '@inma/helpers/translations';
import { forgotTranslations } from '../forget-username-password/forgot.translations';

@Component({
  selector: 'tadawul-forget-username-password',
  templateUrl: './forget-username-password.page.html',
  styleUrls: ['./forget-username-password.page.scss'],
})
export class ForgetUsernamePasswordPage implements OnInit {

  
  constructor() { }

  ngOnInit() {
  }

}
