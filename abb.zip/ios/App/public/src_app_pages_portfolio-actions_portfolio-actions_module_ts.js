"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_portfolio-actions_portfolio-actions_module_ts"],{

/***/ 318:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/portfolio-actions/portfolio-actions-routing.module.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PortfolioActionsPageRoutingModule": () => (/* binding */ PortfolioActionsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _portfolio_actions_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./portfolio-actions.page */ 51049);




const routes = [
    {
        path: '',
        component: _portfolio_actions_page__WEBPACK_IMPORTED_MODULE_0__.PortfolioActionsPage
    }
];
let PortfolioActionsPageRoutingModule = class PortfolioActionsPageRoutingModule {
};
PortfolioActionsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PortfolioActionsPageRoutingModule);



/***/ }),

/***/ 76739:
/*!*********************************************************************!*\
  !*** ./src/app/pages/portfolio-actions/portfolio-actions.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PortfolioActionsPageModule": () => (/* binding */ PortfolioActionsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../common-ui-components/tadawul-common-ui.module */ 50773);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _portfolio_actions_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./portfolio-actions-routing.module */ 318);
/* harmony import */ var _portfolio_actions_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./portfolio-actions.page */ 51049);









let PortfolioActionsPageModule = class PortfolioActionsPageModule {
};
PortfolioActionsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _portfolio_actions_routing_module__WEBPACK_IMPORTED_MODULE_1__.PortfolioActionsPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule,
            _common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_0__.TadawulCommonUiModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateModule.forChild()
        ],
        declarations: [_portfolio_actions_page__WEBPACK_IMPORTED_MODULE_2__.PortfolioActionsPage]
    })
], PortfolioActionsPageModule);



/***/ })

}]);
//# sourceMappingURL=src_app_pages_portfolio-actions_portfolio-actions_module_ts.js.map