import { Injectable, Inject } from '@angular/core';
import { LangChangeEvent, TranslateService } from '@ngx-translate/core';

@Injectable()
export class LocalizedString {
  translate: TranslateService;
  arabicString: string;
  englishString: string;
  storage: Storage;
  constructor(@Inject(String) en: string, @Inject(String) ar: string, @Inject(TranslateService) trans: TranslateService) {
    this.arabicString = ar ? ar : '--';
    this.englishString = en ? en : '--';
    this.translate = trans;
    // this.translate.onLangChange.subscribe((event: LangChangeEvent) => {
    //   this.toString();
    // });
  }



  toString(): string {
    if (this.translate.currentLang == 'en') {
      return this.englishString;
    } else if (this.translate.currentLang == 'ar') {
      return this.arabicString;
    }

  }

}