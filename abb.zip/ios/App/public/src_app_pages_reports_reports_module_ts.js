"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_reports_reports_module_ts"],{

/***/ 23441:
/*!*********************************************************!*\
  !*** ./src/app/pages/reports/reports-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReportsPageRoutingModule": () => (/* binding */ ReportsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _reports_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reports.page */ 79131);




const routes = [
    {
        path: '',
        component: _reports_page__WEBPACK_IMPORTED_MODULE_0__.ReportsPage
    }
];
let ReportsPageRoutingModule = class ReportsPageRoutingModule {
};
ReportsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ReportsPageRoutingModule);



/***/ }),

/***/ 75843:
/*!*************************************************!*\
  !*** ./src/app/pages/reports/reports.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReportsPageModule": () => (/* binding */ ReportsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _reports_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reports-routing.module */ 23441);
/* harmony import */ var _reports_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./reports.page */ 79131);
/* harmony import */ var src_app_pipes_reverse__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/pipes/reverse */ 84674);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);










let ReportsPageModule = class ReportsPageModule {
};
ReportsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _reports_routing_module__WEBPACK_IMPORTED_MODULE_0__.ReportsPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.ReactiveFormsModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateModule.forChild(),
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_3__.TadawulCommonUiModule
        ],
        declarations: [_reports_page__WEBPACK_IMPORTED_MODULE_1__.ReportsPage, src_app_pipes_reverse__WEBPACK_IMPORTED_MODULE_2__.ReversePipe]
    })
], ReportsPageModule);



/***/ }),

/***/ 79131:
/*!***********************************************!*\
  !*** ./src/app/pages/reports/reports.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReportsPage": () => (/* binding */ ReportsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _reports_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reports.page.html?ngResource */ 78909);
/* harmony import */ var _reports_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./reports.page.scss?ngResource */ 85413);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_models_symbol__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/models/symbol */ 61202);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @capacitor/core */ 26549);
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/animations */ 17329);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _inma_models_reports_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/models/reports.model */ 30484);
/* harmony import */ var _inma_models_mutual_funds__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @inma/models/mutual-funds */ 14645);







const { Browser } = _capacitor_core__WEBPACK_IMPORTED_MODULE_3__.Plugins;




let ReportsPage = class ReportsPage {
    constructor(formBuilder, route) {
        this.formBuilder = formBuilder;
        this.route = route;
        this.Symbols = _inma_models_symbol__WEBPACK_IMPORTED_MODULE_2__.Symbols;
        this.Reports = _inma_models_reports_model__WEBPACK_IMPORTED_MODULE_4__.Reports;
        this.showLoader = true;
        this.reverse = false;
    }
    ngOnInit() {
        this.route.params.subscribe(params => {
            this.showLoader = true;
            _inma_models_mutual_funds__WEBPACK_IMPORTED_MODULE_5__.MutualFunds.findById(params === null || params === void 0 ? void 0 : params.id).subscribe(mf => {
                setTimeout(() => {
                    _inma_models_reports_model__WEBPACK_IMPORTED_MODULE_4__.Reports.getAll(mf).subscribe(rs => {
                        this.reports = rs;
                        this.showLoader = false;
                    });
                }, 1000);
            });
        });
    }
    anyReports(reports) {
        return (reports === null || reports === void 0 ? void 0 : reports.findIndex(r => r.halfYearReportExist || r.yearReportExist)) != -1;
    }
    openReport(reportURL) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            // On iOS, for example, open the URL in SFSafariViewController (the in-app browser)
            yield Browser.open({
                url: reportURL
            });
        });
    }
    filter() {
    }
    toggleDirection() {
        this.reverse = !this.reverse;
    }
};
ReportsPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute }
];
ReportsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-watchlist',
        template: _reports_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        animations: [
            // nice stagger effect when showing existing elements
            (0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.trigger)('list', [
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.transition)(':enter', [
                    // child animation selector + stagger
                    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.query)('@items', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.stagger)(25, (0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.animateChild)()), { optional: true })
                ]),
            ]),
            (0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.trigger)('items', [
                // cubic-bezier for a tiny bouncing feel
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.transition)(':enter', [
                    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.style)({ opacity: 0 }),
                    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.animate)('1s ease-in-out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.style)({ opacity: 1 }))
                ]),
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.transition)(':leave', [
                    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.style)({ opacity: 1, height: '*' }),
                    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.animate)('0.5s ease-in-out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_10__.style)({ opacity: 0, height: '0px', margin: '0px' }))
                ])
            ])
        ],
        styles: [_reports_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder, _angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute])
], ReportsPage);



/***/ }),

/***/ 84674:
/*!**********************************!*\
  !*** ./src/app/pipes/reverse.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReversePipe": () => (/* binding */ ReversePipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let ReversePipe = class ReversePipe {
    transform(value, ...args) {
        var _a;
        if (args === null || args === void 0 ? void 0 : args[0])
            return (_a = value === null || value === void 0 ? void 0 : value.slice()) === null || _a === void 0 ? void 0 : _a.reverse();
        else
            return value;
    }
};
ReversePipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({ name: 'reverse' })
], ReversePipe);



/***/ }),

/***/ 30484:
/*!*******************************************!*\
  !*** ./src/app/🌱models/reports.model.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Report": () => (/* binding */ Report),
/* harmony export */   "Reports": () => (/* binding */ Reports),
/* harmony export */   "ReportsModel": () => (/* binding */ ReportsModel)
/* harmony export */ });
/* harmony import */ var _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @inma/helpers/settings */ 96892);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! moment */ 56908);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 64139);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 19193);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 47418);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 80522);
/* harmony import */ var src_environments__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments */ 92020);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 28784);
/* harmony import */ var _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/helpers/injector */ 19753);
/* harmony import */ var _inma_helpers_strings__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/helpers/strings */ 36782);








class Report {
    constructor(year, mutualFund) {
        this.year = year;
        this.mutualFund = mutualFund;
        this.reportsBaseURLContext = "AlinmaMutualFunds";
        this.halfYearReportExist = false;
        this.yearReportExist = false;
    }
    // baseURL = "https://www.alinmatadawuluat.com";
    // https://www.alinmatadawuluat.com/AlinmaMutualFunds/111111-000/2018/En/12-2018.pdf
    get halfYearReport() {
        return (`${src_environments__WEBPACK_IMPORTED_MODULE_2__.Environment.hostURL}/AlinmaMutualFunds/${this.mutualFund.id}/${this.year}/${_inma_helpers_strings__WEBPACK_IMPORTED_MODULE_4__.Strings.toPascalCase(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_0__.Settings.languageAsString)}/6-${this.year}.pdf`);
    }
    get yearReport() {
        return (`${src_environments__WEBPACK_IMPORTED_MODULE_2__.Environment.hostURL}/AlinmaMutualFunds/${this.mutualFund.id}/${this.year}/${_inma_helpers_strings__WEBPACK_IMPORTED_MODULE_4__.Strings.toPascalCase(_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_0__.Settings.languageAsString)}/12-${this.year}.pdf`);
    }
    get httpClient() {
        return _inma_helpers_injector__WEBPACK_IMPORTED_MODULE_3__.Injector.get(_angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpClient);
    }
    checkExistence(url) {
        // const result = Math.random() > 0.5;
        // if (result) console.log(url, result);
        // return of(result);
        return this.httpClient
            .head(url, { headers: null, observe: "response" })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)((response) => {
            var _a, _b;
            console.log(url, response);
            if (((_b = (_a = response === null || response === void 0 ? void 0 : response.url) === null || _a === void 0 ? void 0 : _a.toLowerCase()) === null || _b === void 0 ? void 0 : _b.endsWith("error/404.html")) === true)
                return false;
            else {
                // console.log(url, response);
                return true;
            }
        }))
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.catchError)((error) => {
            console.log(url, error);
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.of)(false);
        }));
    }
}
class ReportsModel {
    getAll(mf) {
        const currentYear = moment__WEBPACK_IMPORTED_MODULE_1__().year();
        const startYear = currentYear - 5;
        var result = [];
        const checksOfExistence = Array();
        for (var y = currentYear; y >= startYear; y--) {
            const r = new Report(y, mf);
            result.push(r);
            checksOfExistence.push(r.checkExistence(r.yearReport).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(exist => r.yearReportExist = exist)));
            checksOfExistence.push(r.checkExistence(r.halfYearReport).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(exist => r.halfYearReportExist = exist)));
        }
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.combineLatest)(checksOfExistence).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.mergeMap)(() => (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.of)(result)));
    }
}
const Reports = new ReportsModel();


/***/ }),

/***/ 85413:
/*!************************************************************!*\
  !*** ./src/app/pages/reports/reports.page.scss?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = ":host {\n  font-size: 80%;\n  height: 100%;\n}\n:host ion-row#header {\n  background: #e6eff0;\n  color: #83afb4;\n  height: 28px;\n}\nbody.dark :host ion-row#header {\n  background-color: var(--ion-color-tertiary);\n}\n:host ion-row#header ion-col {\n  color: #65979a;\n  font-weight: normal;\n}\nbody.dark :host ion-row#header ion-col {\n  color: var(--ion-color-tertiary-contrast);\n}\n:host #symbols-grid {\n  padding: 0;\n}\n:host #sort {\n  --background: white;\n  --color: #005157;\n  font-size: 80%;\n  --border-color: #e6eff0;\n  --border-style: solid;\n  --border-width: 1px;\n  margin: 10px;\n}\nbody.dark :host #sort {\n  --background: #787878;\n  --color:white;\n}\n:host #sort ion-img {\n  -webkit-margin-end: 4px;\n          margin-inline-end: 4px;\n}\n:host ion-col {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  text-align: center;\n  flex-direction: column;\n  color: #005457;\n  font-weight: bold;\n}\nbody.dark :host ion-col {\n  color: white;\n}\n:host ion-col .sub {\n  font-size: 80%;\n  direction: ltr;\n  font-weight: normal;\n}\n:host ion-fab {\n  left: 16px;\n  bottom: 124px;\n}\n:host ion-searchbar {\n  --background: #e6eff0;\n  --color: #005157;\n  --icon-color: #005157;\n  padding: 0;\n  height: 32px;\n  border: 1px solid #e6eff0;\n  --background: transparent;\n}\n:host ion-button {\n  --border-radius: 0;\n}\n:host ion-button.reverse ion-img {\n  transform: scaleY(-1);\n}\n:host #add {\n  font-size: 100%;\n  --background: #e6eff0;\n  --color: #005157;\n  font-weight: normal;\n  width: 100%;\n}\n:host ion-toolbar {\n  --background: #005157;\n  --color: white;\n}\n:host #symbol-id {\n  font-weight: normal;\n  border: 1px solid #e6eff0;\n  padding: 0 2px;\n  width: 36px;\n}\n:host ion-back-button {\n  color: white;\n}\n:host ion-toolbar {\n  --color: white;\n  --background: #005157;\n  --border-width: 0;\n}\n:host ion-toolbar ion-searchbar {\n  --color: #65979a;\n  --icon-color: #65979a;\n  --background: #e6eff0;\n  --border-radius: 0;\n}\nbody.dark :host ion-toolbar ion-searchbar {\n  --color: white;\n  --icon-color: white;\n}\nbody.dark :host .sortImg {\n  content: url(\"/assets/icon/sort-icon-white.svg\");\n}\napp-empty-state {\n  top: 50%;\n  transform: translateY(-50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlcG9ydHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUUsY0FBQTtFQUNBLFlBQUE7QUFBRjtBQUNFO0VBQ0UsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtBQUNKO0FBQUk7RUFDRSwyQ0FBQTtBQUVOO0FBQUk7RUFFRSxjQUFBO0VBQ0EsbUJBQUE7QUFDTjtBQUFNO0VBQ0UseUNBQUE7QUFFUjtBQUdFO0VBQ0UsVUFBQTtBQURKO0FBSUU7RUFDRSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLHVCQUFBO0VBQ0EscUJBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7QUFGSjtBQUdJO0VBQ0UscUJBQUE7RUFDQSxhQUFBO0FBRE47QUFHSTtFQUNFLHVCQUFBO1VBQUEsc0JBQUE7QUFETjtBQUtFO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFFQSxrQkFBQTtFQUNBLHNCQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0FBSko7QUFLSTtFQUNFLFlBQUE7QUFITjtBQUtJO0VBQ0UsY0FBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtBQUhOO0FBT0U7RUFDRSxVQUFBO0VBQ0EsYUFBQTtBQUxKO0FBUUU7RUFDRSxxQkFBQTtFQUNBLGdCQUFBO0VBQ0EscUJBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLHlCQUFBO0VBQ0EseUJBQUE7QUFOSjtBQVNFO0VBQ0Usa0JBQUE7QUFQSjtBQVNNO0VBQ0UscUJBQUE7QUFQUjtBQVlFO0VBQ0UsZUFBQTtFQUNBLHFCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7QUFWSjtBQWFFO0VBQ0UscUJBQUE7RUFDQSxjQUFBO0FBWEo7QUFjRTtFQUNFLG1CQUFBO0VBQ0EseUJBQUE7RUFDQSxjQUFBO0VBQ0EsV0FBQTtBQVpKO0FBY0U7RUFDRSxZQUFBO0FBWko7QUFlRTtFQUNFLGNBQUE7RUFDQSxxQkFBQTtFQUNBLGlCQUFBO0FBYko7QUFjSTtFQUNJLGdCQUFBO0VBQ0EscUJBQUE7RUFDQSxxQkFBQTtFQUNBLGtCQUFBO0FBWlI7QUFhUTtFQUNFLGNBQUE7RUFDQSxtQkFBQTtBQVhWO0FBaUJBO0VBQ0UsZ0RBQUE7QUFkRjtBQWlCQTtFQUNFLFFBQUE7RUFDQSwyQkFBQTtBQWRGIiwiZmlsZSI6InJlcG9ydHMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xuXG4gIGZvbnQtc2l6ZTogODAlO1xuICBoZWlnaHQ6IDEwMCU7XG4gIGlvbi1yb3cjaGVhZGVyIHtcbiAgICBiYWNrZ3JvdW5kOiAjZTZlZmYwO1xuICAgIGNvbG9yOiAjODNhZmI0O1xuICAgIGhlaWdodDogMjhweDtcbiAgICBib2R5LmRhcmsgJiB7XG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItdGVydGlhcnkpO1xuICAgIH1cbiAgICBpb24tY29sIHtcbiAgICAgIC8vIGZvbnQtc2l6ZTogOHB4ICFpbXBvcnRhbnQ7XG4gICAgICBjb2xvcjogIzY1OTc5YTtcbiAgICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgICBib2R5LmRhcmsgJiB7XG4gICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItdGVydGlhcnktY29udHJhc3QpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gICNzeW1ib2xzLWdyaWQge1xuICAgIHBhZGRpbmc6IDA7XG4gIH1cblxuICAjc29ydCB7XG4gICAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgICAtLWNvbG9yOiAjMDA1MTU3O1xuICAgIGZvbnQtc2l6ZTogODAlO1xuICAgIC0tYm9yZGVyLWNvbG9yOiAjZTZlZmYwO1xuICAgIC0tYm9yZGVyLXN0eWxlOiBzb2xpZDtcbiAgICAtLWJvcmRlci13aWR0aDogMXB4O1xuICAgIG1hcmdpbjogMTBweDtcbiAgICBib2R5LmRhcmsgJiB7XG4gICAgICAtLWJhY2tncm91bmQ6ICM3ODc4Nzg7XG4gICAgICAtLWNvbG9yOndoaXRlO1xuICAgIH1cbiAgICBpb24taW1nIHtcbiAgICAgIG1hcmdpbi1pbmxpbmUtZW5kOiA0cHg7XG4gICAgfVxuICB9XG5cbiAgaW9uLWNvbCB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIC8vIGZvbnQtc2l6ZTogMTBweDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICBjb2xvcjogIzAwNTQ1NztcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBib2R5LmRhcmsgJiB7XG4gICAgICBjb2xvcjogd2hpdGU7XG4gICAgfVxuICAgIC5zdWIge1xuICAgICAgZm9udC1zaXplOiA4MCU7XG4gICAgICBkaXJlY3Rpb246IGx0cjtcbiAgICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgfVxuICB9XG5cbiAgaW9uLWZhYiB7XG4gICAgbGVmdDogMTZweDtcbiAgICBib3R0b206IDEyNHB4O1xuICB9XG5cbiAgaW9uLXNlYXJjaGJhciB7XG4gICAgLS1iYWNrZ3JvdW5kOiAjZTZlZmYwO1xuICAgIC0tY29sb3I6ICMwMDUxNTc7XG4gICAgLS1pY29uLWNvbG9yOiAjMDA1MTU3O1xuICAgIHBhZGRpbmc6IDA7XG4gICAgaGVpZ2h0OiAzMnB4O1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICNlNmVmZjA7XG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgfVxuXG4gIGlvbi1idXR0b24ge1xuICAgIC0tYm9yZGVyLXJhZGl1czogMDtcbiAgICAmLnJldmVyc2Uge1xuICAgICAgaW9uLWltZyB7XG4gICAgICAgIHRyYW5zZm9ybTogc2NhbGVZKC0xKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAjYWRkIHtcbiAgICBmb250LXNpemU6IDEwMCU7XG4gICAgLS1iYWNrZ3JvdW5kOiAjZTZlZmYwO1xuICAgIC0tY29sb3I6ICMwMDUxNTc7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICB3aWR0aDogMTAwJTtcbiAgfVxuICBcbiAgaW9uLXRvb2xiYXIge1xuICAgIC0tYmFja2dyb3VuZDogIzAwNTE1NztcbiAgICAtLWNvbG9yOiB3aGl0ZTtcbiAgfVxuXG4gICNzeW1ib2wtaWQge1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgYm9yZGVyOiAxcHggc29saWQgI2U2ZWZmMDtcbiAgICBwYWRkaW5nOiAwIDJweDtcbiAgICB3aWR0aDogMzZweDtcbiAgfVxuICBpb24tYmFjay1idXR0b24ge1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgfVxuXG4gIGlvbi10b29sYmFyIHtcbiAgICAtLWNvbG9yICAgICA6IHdoaXRlO1xuICAgIC0tYmFja2dyb3VuZDogIzAwNTE1NztcbiAgICAtLWJvcmRlci13aWR0aDogMDtcbiAgICBpb24tc2VhcmNoYmFyIHtcbiAgICAgICAgLS1jb2xvcjogIzY1OTc5YTtcbiAgICAgICAgLS1pY29uLWNvbG9yOiAjNjU5NzlhO1xuICAgICAgICAtLWJhY2tncm91bmQ6ICNlNmVmZjA7XG4gICAgICAgIC0tYm9yZGVyLXJhZGl1czogMDtcbiAgICAgICAgYm9keS5kYXJrICYge1xuICAgICAgICAgIC0tY29sb3I6IHdoaXRlO1xuICAgICAgICAgIC0taWNvbi1jb2xvcjogd2hpdGU7XG4gICAgICAgIH1cbiAgICB9XG59XG59XG5cbmJvZHkuZGFyayA6aG9zdCAuc29ydEltZ3tcbiAgY29udGVudDp1cmwoXCIvYXNzZXRzL2ljb24vc29ydC1pY29uLXdoaXRlLnN2Z1wiKTtcbn1cblxuYXBwLWVtcHR5LXN0YXRlIHtcbiAgdG9wOiA1MCU7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcbn0iXX0= */";

/***/ }),

/***/ 78909:
/*!************************************************************!*\
  !*** ./src/app/pages/reports/reports.page.html?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button [text]=\"''\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{ 'report.PAGE_TITLE' | translate}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-header>\n  <ion-toolbar>\n    <ion-grid>\n      <!-- <ion-row>\n        <ion-col>\n          <ion-title>{{ 'report.PAGE_TITLE }}</ion-title>\n        </ion-col>\n      </ion-row> -->\n      <ion-row>\n        <ion-searchbar [(ngModel)]=\"queryText\" (ngModelChange)=\"filter()\" [placeholder]=\" 'report.SEARCH_BY_YEAR' | translate \"  [disabled]=\"!anyReports(reports)\">\n        </ion-searchbar>\n      </ion-row>\n    </ion-grid>\n  </ion-toolbar>\n</ion-header>\n\n\n\n<ion-content padding>\n\n\n  <ion-button id='sort' [ngClass]=\"{'reverse': reverse}\" (click)=\"toggleDirection()\" [disabled]=\"!anyReports(reports)\">\n    <!-- <ion-icon slot=\"start\" name=\"add-circle-outline\"></ion-icon> -->\n    <!-- <ion-icon  src='assets/icon/filter-icon.png'></ion-icon> -->\n    <ion-img class=\"sortImg\" src=\"assets/icon/sort-icon.png\"></ion-img>\n    {{ 'report.SORTING' | translate }}\n  </ion-button>\n\n  <!-- symbols -->\n  <ion-grid id='symbols-grid'>\n    <!-- header -->\n    <ion-row id='header'>\n      <ion-col>\n        {{ 'report.REPORT_YEAR' | translate }}\n      </ion-col>\n      <ion-col>\n        {{ 'report.ANNUAL' | translate }}\n      </ion-col>\n      <ion-col>\n        {{ 'report.SEMI_ANNUAL' | translate }}\n      </ion-col>\n    </ion-row>\n    <!--// -->\n\n    <!-- symbols -->\n    <div id='list' @list>\n\n      <!-- ifEmpty -->\n      <div @items *ngFor=\"let r of reports | reverse:reverse\">\n        <div *ngIf=\"r.halfYearReportExist || r.yearReportExist\">\n        <ion-row *ngIf=\"!queryText || (r.year.toString().indexOf(queryText.trim()) != -1)\">\n\n          <ion-col>\n            {{ r.year }}\n          </ion-col>\n          <ion-col >\n            <ion-icon src=\"assets/icon/pdf.svg\" *ngIf=\"r.yearReportExist\" (click)=\"openReport(r.yearReport)\"></ion-icon>\n          </ion-col>\n\n          <ion-col>\n            <ion-icon src=\"assets/icon/pdf.svg\" *ngIf=\"r.halfYearReportExist\" (click)=\"openReport(r.halfYearReport)\"></ion-icon>\n          </ion-col>\n        </ion-row>\n      </div>\n      </div>\n    </div>\n    <!--// -->\n\n  </ion-grid>\n\n  <!--// -->\n  <tadawul-loader *ngIf=\"showLoader\"></tadawul-loader>\n  <app-empty-state\n  message=\"{{'report.EMPTY' | translate}}\"\n  image=\"assets/icon/empty-orders.png\"\n  *ngIf=\"!showLoader && !anyReports(reports)\"\n  >\n  </app-empty-state>\n\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_reports_reports_module_ts.js.map