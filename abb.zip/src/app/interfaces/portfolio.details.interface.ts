export interface Symbol {
    code: string;
}

export interface AvgCostPrice {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface MrktPrice {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface TotalCost {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface TotalMrktValue {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface UnrealizedProfitLoss {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface RealizedProfitLoss {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface TradeSecurty {
    portfolioNumber: string;
    symbol: Symbol;
    ownedQuantity: string;
    outstandSellQuantity: string;
    outstandBuyQuantity: string;
    pledgedQuantity: string;
    availQuantity: string;
    avgCostPrice: AvgCostPrice;
    mrktPrice: MrktPrice;
    totalCost: TotalCost;
    totalMrktValue: TotalMrktValue;
    unrealizedProfitLoss: UnrealizedProfitLoss;
    realizedProfitLoss: RealizedProfitLoss;
    unrealizedProfitLossPercen: string;
    realizedProfitLossPercen: string;
    symbolName: string;
    portfolioPer: number;
    additionDisplayData: string;
    productType?: any;
    productQuantity: number;
    securityType: string;
    couponDays?: any;
    couponAmount?: any;
    secArName?: any;
    secEnName?: any;
}

export interface MFPortfolioDetailsPortfolioDetails {
    totalCost: string;
    totalMrktValue: string;
    totalProfitLoss: string;
    actualBalance: string;
    tradeSecurties: TradeSecurty[];
}
