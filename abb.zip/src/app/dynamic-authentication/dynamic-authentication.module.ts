import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DynamicAuthenticationPageRoutingModule } from './dynamic-authentication-routing.module';

import { DynamicAuthenticationPage } from './dynamic-authentication.page';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DynamicAuthenticationPageRoutingModule,
    TranslateModule.forChild()
  ],
  declarations: [DynamicAuthenticationPage]
})
export class DynamicAuthenticationPageModule {}
