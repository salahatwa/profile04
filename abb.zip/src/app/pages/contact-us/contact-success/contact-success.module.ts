import { TranslateModule } from '@ngx-translate/core';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ContactSuccessPageRoutingModule } from './contact-success-routing.module';

import { ContactSuccessPage } from './contact-success.page';
import { TadawulCommonUiModule } from 'src/app/common-ui-components/tadawul-common-ui.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ContactSuccessPageRoutingModule,
    TadawulCommonUiModule,
    TranslateModule.forChild()
  ],
  declarations: [ContactSuccessPage]
})
export class ContactSuccessPageModule {}
