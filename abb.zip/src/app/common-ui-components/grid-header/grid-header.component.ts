import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'tadawul-grid-header',
  templateUrl: './grid-header.component.html',
  styleUrls: ['./grid-header.component.scss'],
})
export class GridHeaderComponent implements OnInit {


@Input() headerList: any;
@Input() color: any;
@Input() sort :boolean;
public sortType :string = "dec";
@Output() ascBtnClick = new EventEmitter();
@Output() decBtnClick = new EventEmitter();

  constructor() { }

  ngOnInit() {}

  public ascBtnClicked() {
    this.sortType = "asc"
    this.ascBtnClick.emit();
  }
  public decBtnClicked() {
    this.sortType = "dec"
    this.decBtnClick.emit();
  }

}
