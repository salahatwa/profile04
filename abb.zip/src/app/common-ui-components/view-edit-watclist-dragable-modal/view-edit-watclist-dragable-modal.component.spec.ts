import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { ViewEditWatclistDragableModalComponent } from './view-edit-watclist-dragable-modal.component';

describe('ViewEditWatclistDragableModalComponent', () => {
  let component: ViewEditWatclistDragableModalComponent;
  let fixture: ComponentFixture<ViewEditWatclistDragableModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewEditWatclistDragableModalComponent ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(ViewEditWatclistDragableModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
