import { SessionExpiredPage } from './pages/session-expired/session-expired.page';
import { EventsService } from './events.service';
import { LangChangeEvent, TranslateService } from '@ngx-translate/core';
import {
  Component,
  ViewChild,
  AfterViewInit,
  OnInit,
  OnDestroy,
  NgZone,
  Optional,
  Inject,
} from "@angular/core";

import {

  ModalController,
  NavController,
  Platform, IonRouterOutlet, ToastController,
} from "@ionic/angular";
// import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar as StatusBar2 } from "@ionic-native/status-bar/ngx";
import { Console } from "@inma/helpers/console";
import { MenuComponent, Menu } from "./pages/menu";
import { Http } from "@inma/helpers/http";
import { Environment } from "@inma/environment";
import { LoginPage } from "./pages/login/login.page";
import { User, Users } from "./🌱models/users";
import { Router, NavigationStart } from "@angular/router";

import { Authentication2 } from "./🌱models/users/authentication";
import { TokenAuthenticationPage } from "./token-authentication/token-authentication.page";
import { Biometric } from "@inma/helpers/biometric";
import { Settings, Languages, Theme } from "../helpers/settings";
import { KeychainTouchId } from "@ionic-native/keychain-touch-id/ngx";
import { AuthenticationGroup } from "./🌱models/users/authentication-group";
import { DynamicAuthenticationPage } from "./dynamic-authentication/dynamic-authentication.page";
import { Backends } from "src/environments/backends";
import { Keyboard, KeyboardInfo } from '@capacitor/keyboard';

import { Capacitor, Plugins } from "@capacitor/core";

import { SmsRetriever } from "@ionic-native/sms-retriever/ngx";
import { MobileAccessibility } from "@ionic-native/mobile-accessibility/ngx";
import { SplashScreen } from '@capacitor/splash-screen';

import { StatusBarStyle } from "@capacitor/status-bar";
import { Network } from "@ionic-native/network/ngx";
import * as $ from "jquery";
import { InternetDisconnectedComponent } from "./common-ui-components/internet-disconnected/internet-disconnected.component";

import { PushNotifications, PushNotificationsPlugin, } from "@capacitor/push-notifications";
import { resetCache, resetGlobalCaches } from "@inma/helpers/cached";
import { Streaming } from "@inma/helpers/streaming";
import { TabbarComponent } from "./pages/tabbar/tabbar.component";
import { Kyc } from "./🌱models/kyc";
import { NetworkStatus } from '@capacitor/network'
import { Toast } from "../../src/helpers/toast";
import { refreshAll } from "@inma/helpers/refreshable";
import { Symbols } from "./🌱models/symbol";
import { Market } from "./🌱models/market";
import { Injector } from "@inma/helpers/injector";

import { StatusBar } from '@capacitor/status-bar';
const { Storage } = Plugins;
import { Authentication } from './🌱models/authentication/authentication.model';
import { DOCUMENT } from '@angular/common';
import { Constants } from './helpers/constants';
import { AppHelper } from './helpers/helper';
//const { PushNotifications } = Plugins;

declare var window: any;
@Component({
  selector: "app-root",
  templateUrl: "app.component.html",
  styleUrls: ["app.component.scss"],
})
export class AppComponent implements OnInit, OnDestroy {
  @ViewChild('router') ionRouter: IonRouterOutlet;
  Users = Users;
  JSON = JSON;
  Environment = Environment;
  Backends = Backends;
  static navCtrl: NavController;
  static loggedoutDisconnected: boolean = false;
  MenuComponent = MenuComponent;
  networkStatus: NetworkStatus;
  // networkListener: PluginListenerHandle;
  static ExpiredUserID = false;
  static idExpiryDate = false;
  static platformType = '';
  routerDirection: string = 'rtl';
  currentLang: string;
  App = App;
  constructor(
    private platform: Platform,
    // private splashScreen: SplashScreen,
    private statusBar: StatusBar2,
    private router: Router,
    private translate: TranslateService,
    // private settingsService: SettingsService,
    private modalCtrl: ModalController,
    private navCtrl: NavController,
    // private routerOutlet: IonRouterOutlet
    private smsRetriever: SmsRetriever,
    private mobileAccessibility: MobileAccessibility,
    private zone: NgZone,
    private network: Network,
    private event: EventsService,
    private appHelper: AppHelper,
    public toastController: ToastController,
    @Inject(DOCUMENT) private document: Document,
    @Optional() private readonly routerOutlet?: IonRouterOutlet,
  ) {
   // this.appHelper.mapLocalized()
    Settings.getUserPreferences(Constants._SETTINGS._PREFERRED_LANG).subscribe((lang) => {
      if (lang) {
        localStorage.setItem(Constants._SETTINGS._PREFERRED_LANG, lang.toString());
        this.handleLanguagePreferences(lang.toString());
      }
    })
    AppComponent.navCtrl = navCtrl;
    AppComponent.refreshCurrentURL();
    if (Environment.isDevelopment && !AppComponent.isAnonymousRouteActive()) {
      Settings.getUserPreferences("user").subscribe((user) => {
        if (user && user != "undefined")
          Users.current = JSON.parse(user as string);
      });
    }
    // this.routerOutlet.swipeGesture = false;
    Console.printImage(
      window.location.origin + "/assets/console/AlinmaInvestmentConsole2.png",
      10
    );
    this.initializeApp();
    AppComponent.instance = this;

    this.router.events.subscribe(this.onRouteChange.bind(this));
    Authentication2.authenticationGroupsSubject.subscribe((groups) => {
      this.handleDynamicAuthenticationGroups(groups);
    });

    // this.event.subscribe('CHANGE_APP_ROUTER', (lang) => {
    //   if (lang) {
    //     this.routerDirection = lang == 'ar' ? 'rtl' : 'ltr';
    //   }
    // })
  }

  static refreshCurrentURL() {
    AppComponent.currentURL =
      AppComponent.currentURL || window?.location?.pathname;
  }

  private async handleDynamicAuthenticationGroups(groups) {
    if (groups.length == 1) {
      TokenAuthenticationPage.group = groups[0];

      const modal = await this.modalCtrl.create({
        id: 'TOKEN_MODAL',
        component: TokenAuthenticationPage,
        // presentingElement: this.routerOutlet == null ? await this.modalCtrl.getTop() : this.routerOutlet.nativeEl,
        cssClass: 'auto-height-modal',
        swipeToClose: true,
      });

      modal.onDidDismiss()
        .then((data) => {
          if (data.data != null) {
          }
        });

      return await modal.present();



      this.navCtrl.navigateForward("/token-authentication");
    } else {
      // if (Authentication2.touchIdAvailable) {
      //    let authenticationGroup: AuthenticationGroup = groups.find(group => group.groupName == "3")
      //    if (authenticationGroup) {
      //      let biometricAuthenticationModal = await this.modalCtrl.create({
      //       component: 'BiometricAuthenticationPage', componentProps: { group: authenticationGroup, action: this.authenticationService.sourceAction }});
      //      biometricAuthenticationModal.present();
      //    }
      //    else
      //     //  this.nav.push('DynamicAuthenticationPage', { groups: response.result.groups });
      //  }
      //  else

      DynamicAuthenticationPage.authenticationGroups = groups;
      // UNDO this.navCtrl.navigateForward("/dynamic-authentication");
      DynamicAuthenticationPage.open();
      // this.nav.push('/token-authentication', { groups: groups });
    }
  }

  initializeApp() {
    if (Capacitor.isNativePlatform()) {
      AppComponent.initPushwoosh();
    }
    this.translate.addLangs(['en', 'ar']);
    this.handleLanguagePreferences('en');
    this.handleLanguagePreferences('ar');
    this.changeNGXLanguage();
    // Settings.setLanguage();
    Settings.setTheme();
    this.routerDirection = this.translate.currentLang == 'ar' ? 'rtl' : 'ltr';
    this.currentLang = this.translate.currentLang;
    document.addEventListener("deviceready", () => { }, false);

    this.platform.ready().then(() => {
      Biometric.initialize();
      setTimeout(() => {
        SplashScreen.hide();
      }, 1000);

      // To avoid calling Capacitor.isPluginAvailable
      if (Capacitor.isPluginAvailable("StatusBar"))
        StatusBar.setOverlaysWebView({ overlay: true });
      this.statusBar.overlaysWebView(true);
      this.applyStatusbarStyle(true);
      this.statusBar.backgroundColorByHexString("#005157");
      this.mobileAccessibility.usePreferredTextZoom(false);

      if (
        this.platform.is("capacitor") &&
        (this.platform.is("ios") || this.platform.is("android"))
      ) {
        window.screen?.orientation?.lock("portrait");
        Keyboard.setAccessoryBarVisible({ isVisible: true });

        Keyboard.addListener("keyboardWillShow", (info: KeyboardInfo) => {
          console.log("keyboard will show with height", info.keyboardHeight);
          document.body.classList.add("keyboard-is-open");
          // this.event.publish('KEYBOARD_SHOW');
          // alert('keyboard is open app component')
        });

        // Can be wrapped in a class
        Keyboard.addListener("keyboardWillHide", () => {
          console.log("keyboard will hide");
          document.body.classList.remove("keyboard-is-open");
          // this.event.publish('KEYBOARD_HIDE');
          // alert('keyboard is hidden app component ')
        });
      }

      if (this.platform.is("android")) {
        this.smsRetriever
          .getAppHash()
          .then((res: any) => console.log(res))
          .catch((error: any) => console.error(error));
        App.platformType = 'android'
      }
      // SplashScreen.hide();
    });

    this.platform.resume.subscribe(async () => {
      if (Users.current) {

        resetCache(Authentication, "checkLoggedUser");
        Authentication.checkLoggedUser.subscribe((result => {
          if (result == true) {
            debugger
            if (App.isActive("/main/tabs/tradestation")) {
              const zone = Injector.get(NgZone);
              Market.connectToStream().subscribe((marketInfoMessage) => {
                zone.run(() => {
                  const streamedMarketInfo = JSON.parse(marketInfoMessage["data"]);
                  Market._info.next(streamedMarketInfo);
                })
              });

              Symbols.connectToStream();

            } else if (App.isActive("/tadawul-home") || App.isActive("/main/tabs")) {
              const zone = Injector.get(NgZone);
              Market.connectToStream().subscribe((marketInfoMessage) => {
                zone.run(() => {
                  const streamedMarketInfo = JSON.parse(marketInfoMessage["data"]);
                  Market._info.next(streamedMarketInfo);
                })

              });
            }
          } else if (result == false) {
            debugger;
            this.goToLogoutPage();
          }
        }));

        // resetCache(Kyc, "detailsIncomeSourcesList");
        // Kyc.detailsIncomeSourcesList.subscribe(
        //   (incomeSourcesList: any[]) => {
        //     if (App.isActive("/tradestation")) {
        //       const zone = Injector.get(NgZone);
        //       Market.connectToStream().subscribe((marketInfoMessage) => {
        //         zone.run(() => {
        //           const streamedMarketInfo = JSON.parse(marketInfoMessage["data"]);
        //           Market._info.next(streamedMarketInfo);
        //         })
        //       });

        //       Symbols.connectToStream();

        //     } else if (App.isActive("/tadawul-home")) {
        //       const zone = Injector.get(NgZone);
        //       Market.connectToStream().subscribe((marketInfoMessage) => {
        //         zone.run(() => {
        //           const streamedMarketInfo = JSON.parse(marketInfoMessage["data"]);
        //           Market._info.next(streamedMarketInfo);
        //         })

        //       });
        //     }

        //   }
        // );

      }
    });

    this.platform.pause.subscribe(async () => {
      Streaming.disconnect();
    });

    // this.changeLanguage(); //init with LTR direction

    //#region sessionExpiry
    Http.sessionExpirySubject.subscribe((response) => {
      Users.autoLogin();
    });
    //#endregion

    let tryingToConnect = false;

    let streamingFailureWindow = null;
    Streaming.connectionChangeSubject.subscribe((status) => {
      if (!status) {
        if (streamingFailureWindow) return;
        console.log('setTimeout');
        streamingFailureWindow = setTimeout(() => {
          AppComponent.goToLogoutPage();
        }, 5 * 60 * 1000);
      } else {
        console.log('clearTimeout');
        clearTimeout(streamingFailureWindow);
        streamingFailureWindow = null;
      }
    });

    if (Environment.labs?.enabled && Environment.labs?.streamingInstablity) {
      Streaming.connectionChangeSubject.subscribe((status) => {
        if (!status) {
          Toast.present("محاولة اعادة الاتصال ", { class: 'server-error-toast', timer: { period: 10, callback: null } });
          tryingToConnect = true;
        } else if (tryingToConnect) {
          Toast.present("اعادة الاتصال بنجاح", { class: 'server-success-toast', duration: 5, icon: 'cloud-done-outline' });
          resetGlobalCaches();
          refreshAll();
        }
      });
    }

    this.trackConnection();
  }

  handleLanguagePreferences(lang: string) {
    if (lang == 'ar') {
      this.translate.setDefaultLang('ar');
      this.translate.use('ar');
      this.document.documentElement.dir = 'rtl';
    } else if (lang == 'en') {
      this.translate.setDefaultLang('en');
      this.translate.use('en');
      this.document.documentElement.dir = 'ltr';
    }
  }

  trackConnection() {
    // watch network for a disconnection
    let disconnectSubscription = this.network.onDisconnect().subscribe(() => {
      //alert('network was disconnected :-(');
      if (!AppComponent.currentURL ||
        AppComponent.currentURL == "/" ||
        AppComponent.currentURL == "/login") {
        AppComponent.loggedoutDisconnected = true;
      } else {
        AppComponent.loggedoutDisconnected = true;
        this.presentInternetDisconnectionModal();
      }
    });

    // stop disconnect watch
    //disconnectSubscription.unsubscribe();

    // watch network for a connection
    let connectSubscription = this.network.onConnect().subscribe(() => {
      // alert('network connected!');
      AppComponent.loggedoutDisconnected = false;
    });
  }

  //open force update page

static openForceUpdatePage(){
  this.navCtrl.navigateRoot('force-update');
}


  // present internet connection error
  async presentInternetDisconnectionModal() {
    const modal = await this.modalCtrl.create({
      component: InternetDisconnectedComponent,
      cssClass: "disconnect-modal",
    });

    modal.onDidDismiss().then(() => { });

    return await modal.present();

  }

  //#region Menu
  @ViewChild(MenuComponent) menu: MenuComponent;
  private static instance: AppComponent;
  // static get menu() {
  //   return this.instance?.menu;
  // }
  //#endregion

  //#region Routing
  onRouteChange(event) {
    if (event instanceof NavigationStart) {
      AppComponent.currentURL = event.url;
      this.statusBar.styleDefault();
      if (
        !AppComponent.currentURL ||
        AppComponent.currentURL == "/" ||
        AppComponent.currentURL == "/login"
      )
        this.applyStatusbarStyle(true);
      else {
        if (
          !this.isThemeDark() &&
          AppComponent.currentURL == "main/tabs"
        )
          this.applyStatusbarStyle(false);
        else this.applyStatusbarStyle(true);
      }
      // alert(AppComponent.currentURL)
    }
    // NavigationStart
    // NavigationEnd
    // NavigationCancel
    // NavigationError
    // RoutesRecognized
  }
  applyStatusbarStyle(light: boolean) {
    // alert(light ? 'light' : 'dark');
    if (Capacitor.isPluginAvailable("StatusBar"))
      StatusBar.setStyle({
        style: light ? StatusBarStyle.Dark : StatusBarStyle.Light,
      });
  }
  static currentURL: string;
  static isActive(link: string = null) {
    const menuIsOpen = Menu.isOpen;
    const result =
      (link == this.currentURL ||
        (!!link && link != "/" && this.currentURL?.startsWith(link))) &&
      !menuIsOpen;
    return result;
  }

  static isAnonymousRouteActive() {
    return (
      App.isActive() ||
      App.isActive("/") ||
      App.isActive("/login") ||
      App.isActive("/token-authentication") ||
      App.isActive("/disconnection-page") ||
      App.isActive("/dynamic-authentication") ||
      App.isActive("/biometric-authentication") ||
      App.isActive("/forget-username-password") ||
      App.isActive("/session-expired") ||
      App.isActive("/id-expired")
    );
  }
  private static initialHref = window.location.origin;
  static restart(onRestart?: () => void, showSpash = true) {
    if (showSpash) SplashScreen.show({ fadeInDuration: 0, fadeOutDuration: 0 });
    if (onRestart) onRestart();
    window.location = AppComponent.initialHref;
  }
  //#endregion

  //Toggle Dark/light theme
  toggleTheme() {
    document.body.classList.toggle("dark");
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)");
  }

  isThemeDark() {
    return $(document.body).hasClass("dark");
  }

  //Toggle Rtl/ltr mode
  // changeLanguage() {
  //   if (document.documentElement.getAttribute("dir") == "rtl") {
  //     document.documentElement.setAttribute("dir", "ltr");
  //     Settings.language = Languages.English;
  //   } else {
  //     document.documentElement.setAttribute("dir", "rtl");
  //     Settings.language = Languages.Arabic;
  //   }
  // }

  changeNGXLanguage() {
    this.translate.onLangChange.subscribe((event: LangChangeEvent) => {
      this.event.publish(Constants._EVENT._LANGUAGE_CHANGED, event.lang);
      if (event.lang == 'ar') {
        this.translate.setDefaultLang('ar');
        this.translate.use('ar');
        this.document.documentElement.dir = 'rtl';
      } else {
        this.translate.setDefaultLang('en');
        this.translate.use('en');
        this.document.documentElement.dir = 'ltr';
      }
    });
  }

  async ngOnInit() {
    // this.//  = Network.addListener('networkStatusChange', (status) => {
    //   this.zone.run(() => {
    //     console.log("Network status changed", status);
    //     this.networkStatus = status;
    //     if (status.connected == false) {
    //       if (TabbarComponent.isTabbarVisible) {
    //         this.navCtrl.navigateRoot("/disconnection-page");
    //         // Streaming.disconnect();
    //       }
    //     } else {
    //       if (App.isActive('/disconnection-page')) {
    //         setTimeout(() => {
    //           Streaming.connect().subscribe(connected => {
    //             setTimeout(() => {
    //               resetGlobalCaches();
    //               this.navCtrl.navigateRoot('/tadawul-home/home');
    //             }, 100);
    //           })
    //         }, 100);
    //       }
    //     }
    //   });
    // });
    // this.networkStatus = await Network.getStatus();
  }

  ngOnDestroy() {
    // this.// .remove();
  }

  static initPushwoosh() {
    var pushNotification = (<any>window).plugins.pushNotification;
    //initialize Pushwoosh with projectid: "YOUR_FCM_SENDER_ID", appid : "PUSHWOOSH_APP_ID". This will trigger all pending push notifications on start.
    pushNotification.onDeviceReady({
      projectid: "545068156778",
      appid: "0188D-D8B48",//production :0188D-D8B48 // uat 21A2F-49E7A
      serviceName: ""
    });

    //register for push notifications
    var app = this;
    if (localStorage.getItem(Settings.enableNotficationKey) == "true" || localStorage.getItem(Settings.enableNotficationKey) == null) {
      pushNotification.registerDevice(
        function (status) {
          //  alert("registered with token: " + status.pushToken);
        },
        function (status) {
          //  alert("failed to register: " + status);
         // alert(JSON.stringify(['failed to register ', status]));
        }
      );
    } else if (localStorage.getItem(Settings.enableNotficationKey) == "false") {
      pushNotification.unregisterDevice(
        function (status) {
          // alert("unregisterDevice with token: ");
        },
        function (status) {
         //  alert("failed to unregister: ");
          //console.warn(JSON.stringify(['failed to unregister ', status]));
        }
      );
    }
  }



  //Error Handling Code


  logout(serverSide: boolean = true) {
    // this.menu.close('menu');
    Users.logout(serverSide).subscribe(() => {
      AppComponent.restart(() => {
        setTimeout(() => {
          this.navCtrl.navigateRoot('login', { animated: false });
        }, 100);
      });
    });
  }

  //! Horrible place to place code
  static logout(serverSide: boolean = true, restartMessage = null) {
    if (restartMessage) Storage.set({ key: "RESTART_MESSAGE", value: restartMessage });
    AppComponent.instance?.logout(serverSide);
  }

  static goToLogoutPage() {
    AppComponent.instance?.goToLogoutPage();
  }

  async goToLogoutPage() {
    AppComponent.refreshCurrentURL();
    const modal = await this.modalCtrl.create({
      component: SessionExpiredPage,
      cssClass: 'auto-height-modal session-expired ipad-full-width-modal',
      swipeToClose: false,
      backdropDismiss: false
    });
    return await modal.present();
  }

  //!TODO: refactor this
  static errorsHistory: IErrorsHistory = {};
  static async showError(message, callback: Function = null) {
    if (!message || message?.trim() == 'undefined') return;
    // message = message || '';
    if (AppComponent.errorsHistory[message]) {
      if (AppComponent.errorsHistory[message].opened) {
        return;
      } else {
        const now = new Date().getTime();
        const history = AppComponent.errorsHistory[message].date.getTime();
        if ((now - history) < ERROR_MIN_TIME_AMOUNT)
          return;
      }
    }
    AppComponent.errorsHistory[message] = { date: new Date(), opened: true };
    ////
    const toastController = AppComponent.instance?.toastController;
    const toast = await toastController.create({
      message: message,
      duration: 4000,
      cssClass: "info-alert"
      // buttons: [
      //   {
      //     text: 'Done',
      //     icon: 'star',
      //     role: 'cancel',
      //     handler: () => {
      //       console.log('Cancel clicked');
      //     }
      //   }
      // ]
    });
    toast.onDidDismiss().then(() => {
      if (AppComponent.errorsHistory[message])
        AppComponent.errorsHistory[message].opened = false;
    });

    toast.present().then(callback?.());
  }

}

const ERROR_MIN_TIME_AMOUNT = 1000 * 4;
export interface IErrorsHistory {
  [messageKey: string]: { date: Date, opened: boolean };
}


export const App = AppComponent;
