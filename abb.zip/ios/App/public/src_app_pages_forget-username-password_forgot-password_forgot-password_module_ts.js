"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_forget-username-password_forgot-password_forgot-password_module_ts"],{

/***/ 75688:
/*!**************************************************************************************************!*\
  !*** ./src/app/pages/forget-username-password/forgot-password/forgot-password-routing.module.ts ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgotPasswordPageRoutingModule": () => (/* binding */ ForgotPasswordPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _forgot_password_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forgot-password.page */ 76056);




const routes = [
    {
        path: '',
        component: _forgot_password_page__WEBPACK_IMPORTED_MODULE_0__.ForgotPasswordPage
    }
];
let ForgotPasswordPageRoutingModule = class ForgotPasswordPageRoutingModule {
};
ForgotPasswordPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ForgotPasswordPageRoutingModule);



/***/ }),

/***/ 48517:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/forget-username-password/forgot-password/forgot-password.module.ts ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgotPasswordPageModule": () => (/* binding */ ForgotPasswordPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _forgot_password_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forgot-password-routing.module */ 75688);
/* harmony import */ var _forgot_password_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./forgot-password.page */ 76056);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);









let ForgotPasswordPageModule = class ForgotPasswordPageModule {
};
ForgotPasswordPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _forgot_password_routing_module__WEBPACK_IMPORTED_MODULE_0__.ForgotPasswordPageRoutingModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateModule.forChild()
        ],
        declarations: [_forgot_password_page__WEBPACK_IMPORTED_MODULE_1__.ForgotPasswordPage]
    })
], ForgotPasswordPageModule);



/***/ }),

/***/ 76056:
/*!****************************************************************************************!*\
  !*** ./src/app/pages/forget-username-password/forgot-password/forgot-password.page.ts ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgotPasswordPage": () => (/* binding */ ForgotPasswordPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _forgot_password_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forgot-password.page.html?ngResource */ 43586);
/* harmony import */ var _forgot_password_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./forgot-password.page.scss?ngResource */ 61224);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _inma_models_forget_user_pass__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/models/forget-user-pass */ 90957);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);









let ForgotPasswordPage = class ForgotPasswordPage {
    constructor(formBuilder, translate, alertController, navCtrl) {
        this.formBuilder = formBuilder;
        this.translate = translate;
        this.alertController = alertController;
        this.navCtrl = navCtrl;
        this.formData = {
            alinmaID: '',
            idType: '',
            accountNumber: '',
            customerType: '',
            commercialRegisteration: ''
        };
        this.isIndividual = true;
        this.buildForm();
    }
    buildForm() {
        this.form = this.formBuilder.group({
            customerType: [
                '', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required
                ])
            ],
            alinmaID: [
                '', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.minLength(11),
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.maxLength(11)
                ])
            ],
            idType: [
                '', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.minLength(10),
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.maxLength(10)
                ])
            ],
            commercialRegisteration: [
                '', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required
                ])
            ],
            accountNumber: [
                '', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.minLength(12),
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.maxLength(12)
                ])
            ],
        });
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        _inma_models_forget_user_pass__WEBPACK_IMPORTED_MODULE_2__.forget.getCustomerTypes.subscribe(res => {
            console.log(res);
            this.customerTypes = res;
        });
    }
    customerTypeChanged(value) {
        // console.log(this.formData.customerType);
        // console.log(value);
        if (value.id == 'I') {
            this.isIndividual = true;
            this.form.controls['alinmaID'].setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required);
            this.form.controls['idType'].setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required);
            this.form.controls['commercialRegisteration'].setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.nullValidator);
        }
        else if (value.id == 'O') {
            this.isIndividual = false;
            this.form.controls['alinmaID'].setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.nullValidator);
            this.form.controls['idType'].setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.nullValidator);
            this.form.controls['commercialRegisteration'].setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required);
        }
        this.form.controls['alinmaID'].updateValueAndValidity();
        this.form.controls['idType'].updateValueAndValidity();
        this.form.controls['commercialRegisteration'].updateValueAndValidity();
    }
    retrieve(form) {
        console.log(form);
        if (form.invalid) {
            return;
        }
        let customerType = this.formData.customerType['id'];
        let idType = this.formData.idType;
        let alinmaID = this.formData.alinmaID;
        let commercialRegisteration = this.formData.commercialRegisteration;
        let accountNumber = this.formData.accountNumber;
        _inma_models_forget_user_pass__WEBPACK_IMPORTED_MODULE_2__.forget.forgetPassword(customerType, alinmaID, commercialRegisteration, idType, accountNumber).subscribe(res => {
            // console.log(res);
            // this.showMessage(res);
            this.navCtrl.navigateForward('forget-username-password/change-password');
        });
    }
    showMessage(res) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                // header: String(this.t.USERNAME),
                message: res['_message']['msgText'],
                buttons: [this.translate.instant('forgot.OK')]
            });
            yield alert.present();
        });
    }
};
ForgotPasswordPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormBuilder },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslateService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController }
];
ForgotPasswordPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'tadawul-forgot-password',
        template: _forgot_password_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_forgot_password_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__metadata)("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormBuilder, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslateService, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController])
], ForgotPasswordPage);



/***/ }),

/***/ 61224:
/*!*****************************************************************************************************!*\
  !*** ./src/app/pages/forget-username-password/forgot-password/forgot-password.page.scss?ngResource ***!
  \*****************************************************************************************************/
/***/ ((module) => {

module.exports = "ion-toolbar {\n  --background: #005157;\n  color: #fff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZvcmdvdC1wYXNzd29yZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxxQkFBQTtFQUNBLFdBQUE7QUFDSiIsImZpbGUiOiJmb3Jnb3QtcGFzc3dvcmQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXIge1xuICAgIC0tYmFja2dyb3VuZDogIzAwNTE1NztcbiAgICBjb2xvcjogI2ZmZjtcbiAgfSJdfQ== */";

/***/ }),

/***/ 43586:
/*!*****************************************************************************************************!*\
  !*** ./src/app/pages/forget-username-password/forgot-password/forgot-password.page.html?ngResource ***!
  \*****************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button [text]=\"''\"></ion-back-button>\n    </ion-buttons>\n    <ion-title slot=\"start\">{{'forgot.FORGOT_PASSWORD' | translate}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <form [formGroup]=\"form\" (ngSubmit)=\"retrieve(form)\">\n    <ion-text>\n        {{'forgot.FORGOT_PASSWORD_MOBILE_MESSAGE_NOTICE' | translate}}\n    </ion-text>\n\n    <ion-item>\n      <ion-label position=\"stacked\">{{ 'forgot.CUSTOMER_TYPE' | translate }}</ion-label>\n      <ion-select placeholder=\"{{ 'forgot.SELECT' | translate }}\" formControlName=\"customerType\" name=\"customerType\" okText=\"{{ 'forgot.OK' | translate }}\"\n        interface=\"action-sheet\" mode=\"ios\" [interfaceOptions]=\"{header: 'forgot.CUSTOMER_TYPE' | translate, cssClass: 'app-select'}\"\n        cancelText=\"{{ 'forgot.CANCEL' | translate }}\" [(ngModel)]=\"formData.customerType\" (ngModelChange)=\"customerTypeChanged($event)\">\n\n        <ion-select-option *ngFor=\"let customerType of customerTypes\" [value]=\"customerType\">\n          {{customerType.name}}\n        </ion-select-option>\n\n      </ion-select>\n\n      <div *ngIf=\"!form.controls.customerType.valid\n                  && form.controls.customerType.dirty\" class=\"validator-error\">\n        {{ 'forgot.PLEASE_CHOOSE' | translate }} {{ 'forgot.CUSTOMER_TYPE' | translate }}\n      </div>\n    </ion-item>\n\n    <app-input *ngIf=\"isIndividual\" [form]=\"form\" [label]=\"'forgot.ALINMA_ID' | translate\" [formControl]=\"form.controls.alinmaID\" name=\"alinmaID\" type=\"number\" [(model)]=\"formData.alinmaID\" layout=\"2\" ngDefaultControl></app-input>\n    \n    <app-input *ngIf=\"isIndividual\" [form]=\"form\" [label]=\"'forgot.ID_TYPE' | translate\" [formControl]=\"form.controls.idType\" name=\"idType\" type=\"number\" [(model)]=\"formData.idType\" layout=\"2\" ngDefaultControl></app-input>\n    \n    <app-input *ngIf=\"!isIndividual\" [form]=\"form\" [label]=\"'forgot.COMMERCIAL_REGISTERATION' | translate\" [formControl]=\"form.controls.commercialRegisteration\" name=\"commercialRegisteration\" type=\"number\" [(model)]=\"formData.commercialRegisteration\" layout=\"2\" ngDefaultControl></app-input>\n    \n    <app-input [form]=\"form\" [label]=\"'forgot.ACCOUNT_NUMBER' | translate\" [formControl]=\"form.controls.accountNumber\" name=\"accountNumber\" type=\"number\" [(model)]=\"formData.accountNumber\" layout=\"2\" ngDefaultControl></app-input>\n  \n  \n    <app-button \n      [disabled]=\"!form.valid\" \n      expand=\"block\" \n      size=\"\"\n      color=\"success\"\n      fill=\"solid\"\n      shape=\"\"\n      type=\"submit\"\n      >\n      {{'forgot.RETRIEVE' | translate}}\n    </app-button>\n  </form>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_forget-username-password_forgot-password_forgot-password_module_ts.js.map