export interface PortfolioType {
    code: string;
}

export interface ParentsBO {
}

export interface SamaAccount {
    accountNumber: string;
    accountType?: any;
    iban?: any;
    accountName?: any;
    shortDesc?: any;
    accountNickName?: any;
    accountStatus?: any;
    accountCurrency?: any;
    availableBalance?: any;
    ledgerBalance?: any;
    currentBalance?: any;
    subUsrEnabled?: any;
    acctFuncsAccess?: any;
    deliveryOption?: any;
    deliveryLocation?: any;
    stmtPreferredLang?: any;
    branchId?: any;
    atmCardExist?: any;
    signId?: any;
    countryCode?: any;
    bankCode?: any;
    mnemonicName?: any;
    updatesMap: any[];
    parentsBO: ParentsBO;
    parentLists: any[];
    parentMaps: any[];
    isFetched: boolean;
    exists?: any;
    updated: boolean;
    recordStatus?: any;
    previousRecordStatus?: any;
    validated: boolean;
    context?: any;
}

export interface AccountType {
    code: string;
}

export interface ParentsBO2 {
}

export interface Account {
    accountNumber: string;
    accountType: AccountType;
    iban?: any;
    accountName?: any;
    shortDesc: string;
    accountNickName?: any;
    accountStatus?: any;
    accountCurrency?: any;
    availableBalance?: any;
    ledgerBalance?: any;
    currentBalance?: any;
    subUsrEnabled?: any;
    acctFuncsAccess?: any;
    deliveryOption?: any;
    deliveryLocation?: any;
    stmtPreferredLang?: any;
    branchId?: any;
    atmCardExist?: any;
    signId?: any;
    countryCode?: any;
    bankCode?: any;
    mnemonicName?: any;
    updatesMap: string[];
    parentsBO: ParentsBO2;
    parentLists: any[];
    parentMaps: any[];
    isFetched: boolean;
    exists?: any;
    updated: boolean;
    recordStatus: string;
    previousRecordStatus?: any;
    validated: boolean;
    context?: any;
}

export interface PortfolioInfo {
    number: string;
    year?: any;
    quarter?: any;
    portfolioType: PortfolioType;
    name: string;
    samaAccount: SamaAccount;
    account: Account;
    positionAmt?: any;
    totalUnrealizedprofitLossAmt?: any;
    totalRealizedprofitLossAmt?: any;
    totalCost?: any;
    totalMarketValue?: any;
    tradeSecList?: any;
    safekeepingFeeAmount?: any;
    actualBalance?: any;
    defaultPortfolio: boolean;
    _cachedBuyingPower?: any;
    _facilities?: any;
    _portfolioValue?: any;
    _currency?: any;
    _moneyBalance?: any;
    _marketValue?: any;
    _blockedAmount?: any;
    _currentPortfolio?: boolean;
}

export interface PortfoliosInterface {
    status: string;
    msg?: any;
    result: PortfolioInfo[];
}



