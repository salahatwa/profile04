import { AppTranslations } from '../app.translations';

class Translations extends AppTranslations {

    "touchAuthenticate" = ["دخول بالبصمة", "Login With Fingerprint"];
    "faceAuthenticate" = ["دخول ببصمة الوجه", "Login With Face ID"];
    "touchOther" = ["تأكيد بالبصمة", "Verify With Fingerprint"];
    "faceOther" = ["تأكيد ببصمة الوجه", "Verify With Face ID"];

    "touchVerifyAuthenticate" = ["من فضلك سجل بصمتك لتسجيل الدخول للتطبيق", "Please provide your Fingerprint to Login to the App"];
    "touchVerifyOther" = ["من فضلك سجل بصمتك من أجل إتمام العملية", "Please provide your Fingerprint to complete the transaction"];
    "faceVerifyAuthenticate" = ["من فضلك قم بتأكيد بصمة وجهك لتسجيل الدخول للتطبيق", "Please verfiy your Face to Login to the App"];
    "faceVerifyOther" = ["من فضلك قم بتأكيد بصمة وجهك من أجل إتمام العملية", "Please verfiy your Face to complete the transaction"];

    "touchStoreConfirm" = ["هل تريد التسجيل بخدمة البصمة لتطبيق تداول الإنماء؟", "Do you want to register in Fingerprint service for Alinma Tadawul application?"];
    "faceStoreConfirm" = ["هل تريد التسجيل بخدمة بصمة الوجه لتطبيق تداول الإنماء؟", "Do you want to register in Face Verification service for Alinma Tadawul application?"];

    "termsFingerPrint" = [
        "<div class='alert-container'><p>نموذج شروط وأحكام خدمة التحقق بالبصمة</p><p>حيث إنني أرغب بالحصول على خدمة معيار التحقق الثاني باستخدام (البصمة) فقد وافقت على شروط وأحكام الخدمة الآتي بيانها:</p> <ol> <li>تعد هذه الخدمة سارية المفعول وتحت مسئوليتي اعتباراً من تاريخه مالم تتسلم الإنماء للاستثمار طلباً إلكترونياً مني بإلغاء الاشتراك بالخدمة، أو تتسلم إشعارا بوفاتي.</li> <li>لا تلزمني شركة الإنماء للاستثمار بحد أدنى من الرصيد، ولا توجد رسوم اشتراك للخدمة ويمكنني إلغاء الاشتراك في أي وقت، وتعد صلاحية الخدمة مفتوحة ما لم أتقدم للإنماء للاستثمار بطلب خطي يفيد بعدم رغبتي في تجديد الخدمة.</li> <li>سأتولى تنشيط الخدمة من القناة الإلكترونية المخصصة لذلك.</li> <li>يخضع هذا الطلب للشروط والأحكام الواردة في اتفاقية فتح الحساب الجاري.</li> <li>أقر بأن جميع بصمات الأصابع المحفوظة على الجهاز هي بصمات أصابع يدي.</li> </ol></div>",
        "<div class='alert-container'><p>Fingerprint Biometric Authentication Service Terms and Conditions Form</p> <p>Whereas I desire to avail the second-factor fingerprint authentication; now, therefore, I agree to the service terms and conditions below stated:</p> <ol> <li>This service is deemed valid effective immediately and under my sole responsibility unless otherwise is received by Alinma Investment from me through electronic means instructing the cancellation of my subscription to the service, or unless Alinma Investment receives a notice of my death.</li> <li>No minimum balance is required by Alinma Investment for the service. No service subscription fee is charged, and I am entitled to cancel my subscription to the service at any time I desire. The service availability is open-ended, unless I instruct Alinma Investment in writing of my wish to cancel the renewal of my subscription to the service.</li> <li>I will activate the service from the specified electronic channel.</li> <li>This request is subject to the terms and conditions of the Current Account Opening Agreement.</li> <li>I acknowledge that all the fingerprints saved on the device are of my own.</li> </ol></div>"
    ];

    "termsCancelFingerprint" = [
        "<div class='alert-container'><p>نموذج طلب إلغاء خدمة التحقق بالبصمة</p> <p>حيث إنني أرغب بإلغاء خدمة معيار التحقق الثاني باستخدام (البصمة) فقد وافقت على الشروط والأحكام الآتية:</p> <ol> <li>تعد جميع الأعمال والتصرفات التي تمت قبل تاريخ&nbsp;هذا الطلب صحيحة وملزمة لي.</li> <li>لا يحق للإنماء للاستثمار أن تخصم من حسابي أي رسوم خاصة بإلغاء الخدمة. .</li> <li>ستقوم شركة الإنماء للاستثمار بإيقاف الخدمة من التطبيق فور تلقيها هذا الطلب.</li> </ol></div>",
        "<div class='alert-container'><p>Fingerprint Authentication Service Cancellation Request Form</p> <p>Whereas I desire to cancel the second-factor fingerprint authentication; now, therefore, I agree to the below-set terms and conditions:</p> <ol> <li>All activities and transactions conducted before the date of this form shall be deemed correct and binding.</li> <li>Alinma Investment is not entitled to deduct any fees from my account as cancellation fees.</li> <li>Alinma Investment will deactivate this service immediately in the application upon the receipt of this request.</li> </ol></div>"
    ];

    "touchStoreSuccess" = ["تم التسجيل بخدمة البصمة بنجاح", "You have registered successfully in Fingerprint service"];
    "faceStoreSuccess" = ["تم التسجيل بخدمة بصمة الوجه بنجاح", "You have registered successfully in Face Verification service"];
    "touchStoreError" = ["لم يتم التسجيل بخدمة البصمة", "You haven't registered in Fingerprint service"];
    "faceStoreError" = ["لم يتم التسجيل بخدمة بصمة الوجه", "You haven't registered in Face Verification service"];
    "touchCancelSuccess" = ["تم إلغاء التسجيل بخدمة البصمة بنجاح", "You registration in Fingerprint service have been Cancelled"];
    "faceCancelSuccess" = ["تم إلغاء التسجيل بخدمة بصمة الوجه بنجاح", "You registration in Face Verification service have been Cancelled"];
    "touchCancelError" = ["لم يتم إلغاء التسجيل بخدمة البصمة", "Fingerprint service haven't been cancelled"];
    "faceCancelError" = ["لم يتم إلغاء التسجيل بخدمة بصمة الوجه", "Face Verification service haven't been cancelled"];

    SELECT_ACTIVATION = ["اختر طريقة التفعيل", "Select Activation Method"];
    ACTIVATION = ["التفعيل", "Activation"];
    NEXT = ["التالي", "Next"];
	SUBMIT = ["إرسال", "Submit"];
}

export const DynamicAuthenticationTranslations = new Translations();
