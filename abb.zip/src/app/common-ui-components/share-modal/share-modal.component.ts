import { Component, Input, OnInit } from '@angular/core';
import { ShareService } from 'src/app/providers/share.service';
import { Translations } from '@inma/helpers/translations';
import { ShareModalTranslations } from './share-modal.translations';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'tadawul-share-modal',
  templateUrl: './share-modal.component.html',
  styleUrls: ['./share-modal.component.scss'],
})
export class ShareModalComponent implements OnInit {
  @Input() content;

  @Translations()
  t = ShareModalTranslations;

  constructor(private shareService: ShareService, private modalCtrl: ModalController) { }

  ngOnInit() {
    setTimeout(() => {
      var nodeEl = document.getElementsByClassName('modal-share-screenshot')[0];
      this.shareService.shareScreenshot(nodeEl).then(res=> {
        console.log(res);
        this.dismiss();
      }).catch(err=>{
        console.log(err);
        this.dismiss();
      });
    },1000);
  }

  dismiss() {
    this.modalCtrl.dismiss();
  }

}
