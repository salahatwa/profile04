export interface ParentsBO {
}

export interface Account {
    accountNumber: string;
    accountType?: any;
    iban?: any;
    accountName?: any;
    shortDesc?: any;
    accountNickName?: any;
    accountStatus?: any;
    accountCurrency?: any;
    availableBalance?: any;
    ledgerBalance?: any;
    currentBalance?: any;
    subUsrEnabled?: any;
    acctFuncsAccess?: any;
    deliveryOption?: any;
    deliveryLocation?: any;
    stmtPreferredLang?: any;
    branchId?: any;
    atmCardExist?: any;
    signId?: any;
    countryCode?: any;
    bankCode?: any;
    mnemonicName?: any;
    updatesMap: any[];
    parentsBO: ParentsBO;
    parentLists: any[];
    parentMaps: any[];
    isFetched: boolean;
    exists?: any;
    updated: boolean;
    recordStatus?: any;
    previousRecordStatus?: any;
    validated: boolean;
    context?: any;
}

export interface BuyingPwrAmt {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface ClosingBalAmt {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface NetSecurityAmt {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface OverdraftAmt {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface BlockedAmt {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface UsageAmt {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface AvilLimitAmt {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface PortfolioPostionAmt {
    currencyCode?: any;
    currencyRate?: any;
    amount: string;
    formatedAmount?: any;
    localAmount?: any;
}

export interface BuyingPwr {
    account: Account;
    buyingPwrAmt: BuyingPwrAmt;
    closingBalAmt: ClosingBalAmt;
    netSecurityAmt: NetSecurityAmt;
    overdraftAmt: OverdraftAmt;
    blockedAmt: BlockedAmt;
    usageAmt: UsageAmt;
    avilLimitAmt: AvilLimitAmt;
    portfolioPostionAmt: PortfolioPostionAmt;
}

export interface PortfolioBuyingPowerInfo {
    buyingPwr: BuyingPwr;
    currency: string;
    documentType: string;
}