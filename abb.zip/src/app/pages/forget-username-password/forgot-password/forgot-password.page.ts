import { TranslateService } from '@ngx-translate/core';
import { Component, OnInit } from '@angular/core';
import { Translations } from '@inma/helpers/translations';
import { forgotTranslations } from '../../forget-username-password/forgot.translations';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { forget } from '@inma/models/forget-user-pass';
import { AlertController } from '@ionic/angular';
import { NavController } from "@ionic/angular";

@Component({
  selector: 'tadawul-forgot-password',
  templateUrl: './forgot-password.page.html',
  styleUrls: ['./forgot-password.page.scss'],
})
export class ForgotPasswordPage implements OnInit {

  form: FormGroup;
  formData = {
    alinmaID: '',
    idType: '',
    accountNumber: '',
    customerType: '',
    commercialRegisteration: ''
  };
  customerTypes;
  isIndividual:boolean = true;


  constructor(private formBuilder: FormBuilder,public translate: TranslateService ,public alertController: AlertController, public navCtrl: NavController) {
    this.buildForm();
  }

  buildForm() {
    this.form = this.formBuilder.group({
      customerType: [
        '',  Validators.compose([
          Validators.required
        ])
      ],
      alinmaID: [
        '', Validators.compose([
          Validators.required,
          Validators.minLength(11),
          Validators.maxLength(11)
        ])
      ],
      idType: [
        '', Validators.compose([
          Validators.required,
          Validators.minLength(10),
          Validators.maxLength(10)
        ])
      ],
      commercialRegisteration: [
        '',  Validators.compose([
          Validators.required
        ])
      ],
      accountNumber: [
        '', Validators.compose([
          Validators.required,
          Validators.minLength(12),
          Validators.maxLength(12)
        ])
      ],
    });
  }

  ngOnInit() {
  }

  ionViewWillEnter() {
    forget.getCustomerTypes.subscribe(res=> {
      console.log(res);
      this.customerTypes = res;
    });
  }

  customerTypeChanged(value) {
    // console.log(this.formData.customerType);
    // console.log(value);
    if(value.id == 'I'){
      this.isIndividual = true;
      this.form.controls['alinmaID'].setValidators(Validators.required);
      this.form.controls['idType'].setValidators(Validators.required);
      this.form.controls['commercialRegisteration'].setValidators(Validators.nullValidator);
    }else if( value.id == 'O'){
      this.isIndividual = false;
      this.form.controls['alinmaID'].setValidators(Validators.nullValidator);
      this.form.controls['idType'].setValidators(Validators.nullValidator);
      this.form.controls['commercialRegisteration'].setValidators(Validators.required);
    }

    this.form.controls['alinmaID'].updateValueAndValidity();
    this.form.controls['idType'].updateValueAndValidity();
    this.form.controls['commercialRegisteration'].updateValueAndValidity();
  }


  retrieve(form) {
    console.log(form);
    if (form.invalid) {
      return;
    }

    let customerType = this.formData.customerType['id'];
    let idType = this.formData.idType;
    let alinmaID = this.formData.alinmaID;
    let commercialRegisteration = this.formData.commercialRegisteration;
    let accountNumber = this.formData.accountNumber;
    forget.forgetPassword(customerType,alinmaID,commercialRegisteration,idType,accountNumber).subscribe(res=> {
      // console.log(res);
      // this.showMessage(res);
      this.navCtrl.navigateForward('forget-username-password/change-password');
    });

  }

  async showMessage(res) {
    const alert = await this.alertController.create({
      // header: String(this.t.USERNAME),
      message: res['_message']['msgText'],
      buttons: [this.translate.instant('forgot.OK')]
    });

    await alert.present();
  }

}
