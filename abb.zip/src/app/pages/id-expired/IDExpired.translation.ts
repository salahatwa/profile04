import { AppTranslations } from 'src/app/app.translations';

class Translations extends AppTranslations {
    warning = ['تنبيه', 'Alert'];
    textOne = ['هويتك منتهية', 'ID Expired'];
    textTwo = ["قد لا تتمكن من الاستفادة من بعض خدمات التطبيق ", "You may not be able to use some of app services"];
    textThree = [' يرجى تحديث الهوية الوطنية أو الإقامة', 'Please update your national ID or Iqama'];
    textFour = ['تحديث بياناتكم الشخصية منتهية', 'Your KYC has been expired'];
    textFive = ["قد لا تتمكن من الإستفادة من بعض خدمات الإنماء للاستثمار. ", "you may not be able to benefit from some of the Alinma Investment service."];
    textSex = ['لتحديث بياناتكم الشخصية الرجاء الدخول على تداول الإنماء', 'To Update your KYC please login Alinma Tadawul website'];
    textSeven = ['من هنا', 'Here'];
    continue = ['الاستمرار', 'Continue'];
}

export const IDExpiryTranslations = new Translations();