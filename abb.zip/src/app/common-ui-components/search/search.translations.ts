class Translations {
    CLOSE = ['إغلاق', 'Close'];
    PAGE_TITLE = ['بحث', 'Search'];
}


export const SearchTranslations = new Translations();
