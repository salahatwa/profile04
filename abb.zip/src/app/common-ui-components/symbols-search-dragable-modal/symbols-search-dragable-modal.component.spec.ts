import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { SymbolsSearchDragableModalComponent } from './symbols-search-dragable-modal.component';

describe('SymbolsSearchDragableModalComponent', () => {
  let component: SymbolsSearchDragableModalComponent;
  let fixture: ComponentFixture<SymbolsSearchDragableModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SymbolsSearchDragableModalComponent ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(SymbolsSearchDragableModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
