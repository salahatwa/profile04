"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_pages_standing-orders_standing-orders_module_ts"],{

/***/ 51987:
/*!******************************************************************************!*\
  !*** ./src/app/pages/standing-orders/delete-order/delete-order.component.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteOrderComponent": () => (/* binding */ DeleteOrderComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _delete_order_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./delete-order.component.html?ngResource */ 40683);
/* harmony import */ var _delete_order_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./delete-order.component.scss?ngResource */ 3066);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _inma_models_order__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/models/order */ 39344);







let DeleteOrderComponent = class DeleteOrderComponent {
    constructor(modalControl, translate) {
        this.modalControl = modalControl;
        this.translate = translate;
        this.order = true;
        this.outstandingOrdersHeader = () => [{ title: this.translate.instant('outstandingOrder.companyName'), size: '4.4' }, { title: this.translate.instant('outstandingOrder.price'), size: '1.4' }, { title: this.translate.instant('outstandingOrder.quantity'), size: '1.4' }, { title: this.translate.instant('outstandingOrder.excutedQuantity'), size: '2' }, { title: this.translate.instant('outstandingOrder.status'), size: '1.8' }];
    }
    ngOnInit() { }
    closeModal() {
        this.modalControl.dismiss();
    }
    deleteAllOrders() {
        // if (confirm(this.t.confirmDelete))
        // Dialogs.confirm(this.t.confirmDelete as any).subscribe(deleteOrders => {
        //   if (deleteOrders) {
        for (let i = 0; i < this.outstandingOrders.length; i++) {
            _inma_models_order__WEBPACK_IMPORTED_MODULE_2__.Orders["delete"](this.outstandingOrders[i]).subscribe();
            if (i == this.outstandingOrders.length - 1) {
                const data = "delete";
                this.modalControl.dismiss(data);
            }
        }
        // }
        // else {
        // }
        // });    
    }
    collapsSymbole(order, dataArr) {
        for (let i = 0; i < dataArr.length; i++) {
            if (dataArr[i].referenceNumber == order.referenceNumber) {
                if (dataArr[i].expanded == true) {
                    dataArr[i].expanded = false;
                    return;
                }
                else {
                    dataArr[i].expanded = true;
                }
            }
            else {
                dataArr[i].expanded = false;
            }
        }
    }
};
DeleteOrderComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslateService }
];
DeleteOrderComponent.propDecorators = {
    outstandingOrders: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input }]
};
DeleteOrderComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'tadawul-delete-order',
        template: _delete_order_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_delete_order_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController,
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslateService])
], DeleteOrderComponent);



/***/ }),

/***/ 76302:
/*!********************************************************************************!*\
  !*** ./src/app/pages/standing-orders/filter-orders/filter-orders.component.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FilterOrdersComponent": () => (/* binding */ FilterOrdersComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _filter_orders_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./filter-orders.component.html?ngResource */ 65654);
/* harmony import */ var _filter_orders_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./filter-orders.component.scss?ngResource */ 36687);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _inma_models_order__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @inma/models/order */ 39344);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! moment */ 56908);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/models/portfolio */ 65082);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);











let FilterOrdersComponent = class FilterOrdersComponent {
    constructor(sharedData, translate, pickerCtrl, modalCtrl, navCtrl) {
        this.sharedData = sharedData;
        this.translate = translate;
        this.pickerCtrl = pickerCtrl;
        this.modalCtrl = modalCtrl;
        this.navCtrl = navCtrl;
        //@Input() portfolioID: any;
        this.statuses = [];
        this.types = [];
        this.periods = [];
        this.selectedPeriod = 1;
        this.allStandardPortfolios = [];
        this.searchInfoObj = {};
        this.showLoader = false;
    }
    ngOnInit() {
        this.getAllStandardPortfolios();
        //console.log("this.portfolioID>>>>>>>>>>>>>>>>" + this.portfolioID, );
        _inma_models_order__WEBPACK_IMPORTED_MODULE_2__.Orders.statuses.subscribe(statuses => {
            // this.statuses = statuses;
            // this.selectedStatus = statuses[0];
            console.log("statuses>>>>>>>>>>>>>>>>>>" + statuses);
            this.statuses = statuses;
            this.statusID = statuses[0].id;
            this.selectedStatusIndex = 0;
            this.selectedStatusValue = this.statuses[0].name;
        });
        _inma_models_order__WEBPACK_IMPORTED_MODULE_2__.Orders.sides.subscribe(sides => {
            // this.sides = sides;
            // this.selectedSide = sides[0];
            this.types = sides;
            this.typeID = sides[0].id;
            this.selectedOrderSideIndex = 0;
            this.selectedOrderSideValue = this.types[0].name;
        });
        _inma_models_order__WEBPACK_IMPORTED_MODULE_2__.Orders.periods.subscribe(periods => {
            var _a, _b;
            // this.periods = periods;
            // this.selectedPeriod = periods?.[2];
            this.periods = periods;
            //  this.periods.shift();
            this.periodID = (_a = periods[0]) === null || _a === void 0 ? void 0 : _a.id;
            this.selectedOrderPeriodIndex = 0;
            this.selectedOrderPeriodValue = (_b = this.periods[0]) === null || _b === void 0 ? void 0 : _b.name;
        });
        this.startDate = moment__WEBPACK_IMPORTED_MODULE_3__().format("YYYY-MM-DD");
        this.endDate = moment__WEBPACK_IMPORTED_MODULE_3__().format("YYYY-MM-DD");
        this.today = moment__WEBPACK_IMPORTED_MODULE_3__().format("YYYY-MM-DD");
    }
    getAllStandardPortfolios() {
        _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_4__.Portfolios.allStandardPortfolios.subscribe(allStandardPortfolios => {
            //console.log('allStandardPortfolios>>>>>>>>>>' + allStandardPortfolios);
            this.allStandardPortfolios = allStandardPortfolios;
            this.selectedPortfolioID = allStandardPortfolios[0].id;
            this.selectedPortfolioIndex = this.selectedPortfolioID;
            this.selectedPortfolioValue = this.selectedPortfolioID;
        });
    }
    changePeriod(periodID) {
        this.selectedPeriod = periodID;
    }
    closeModal() {
        // this.modalControl.dismiss();
    }
    createsearchInfoObj() {
        this.searchInfoObj = {};
        this.searchInfoObj.portfolio = this.selectedPortfolioID;
        this.searchInfoObj.status = this.selectedStatusValue;
        this.searchInfoObj.type = this.selectedOrderSideValue;
        this.searchInfoObj.period = this.selectedPeriod == 1 ? this.selectedOrderPeriodValue : this.translate.instant('outstandingOrder.from') + ' ' + this.startDate;
        this.searchInfoObj.toDate = this.selectedPeriod != 1 ? this.translate.instant('outstandingOrder.to') + ' ' + this.endDate : null;
        // for (let i = 0; i < this.statuses.length; i++) {
        //   if (this.statusID == this.statuses[i].id) {
        //     this.searchInfoObj.status = this.statuses[i].name
        //   }
        // }
        // for (let i = 0; i < this.types.length; i++) {
        //   if (this.typeID == this.types[i].id) {
        //     this.searchInfoObj.type = this.types[i].name
        //   }
        // }
        // if (this.selectedPeriod == 1) {
        //   for (let i = 0; i < this.periods.length; i++) {
        //     if (this.periodID == this.periods[i].id) {
        //       this.searchInfoObj.period = this.periods[i].name
        //     }
        //   }
        // } else {
        //   this.searchInfoObj.period = this.translate.instant('outstandingOrder.from') + ' ' + this.startDate;
        //   this.searchInfoObj.toDate = this.translate.instant('outstandingOrder.to') + ' ' + this.endDate;
        // }
    }
    filterData(orders) {
        // console.log(orders);
        // debugger
        // if (orders.length == 0) {
        //   Dialogs.alert(this.translate.instant('outstandingOrder.emptyOrdersSearch') as any).subscribe(ok => {
        //   });
        //   //alert(this.t.emptyOrdersSearch);
        //   return false;
        // }
        // for (let i = 0; i < orders.length; i++) {
        //   orders[i].symbol.abbreviation.subscribe(abbreviation => {
        //     console.log('abbreviation>>>>>>>>' + abbreviation);
        //     orders[i].symbol.abbreviation = abbreviation;
        //   });
        //   orders[i].symbol.name.subscribe(name => {
        //     console.log('name>>>>>>>>' + name);
        //     orders[i].symbol.name = name;
        //   });
        //   if (orders[i].side.id === 'BUY') {
        //     orders[i].ststusColor = 'success';
        //   } else {
        //     orders[i].ststusColor = 'danger';
        //   }
        // }
        this.createsearchInfoObj();
        this.sharedData.setSharedData(orders, 'orders');
        this.sharedData.setSharedData(this.searchInfoObj, 'searchInfoObj');
        this.navCtrl.navigateForward('/main/standing-orders/search-results');
        // const data = orders;
        // this.modalControl.dismiss(data);
    }
    search() {
        // Orders.search(options ? : { this.selectedPeriod,
        //    orderStatusId?,
        //     orderSideId?, period?, startDate?, endDate?, referenceNumber?}).subscribe(orders => {
        //   // MyApp.openPage(this.navCtrl, 'OrdersSearchResultsPage', false, { orders: orders })
        // });
        this.showLoader = true;
        setTimeout(() => {
            this.showLoader = false;
        }, 3000);
        if (this.selectedPeriod == 1) {
            this.startDate = "";
            this.endDate = "";
        }
        else {
            this.periodID = "";
            if (this.startDate) {
                this.startDate = this.startDate.slice(0, 10);
            }
            if (this.endDate) {
                this.endDate = this.endDate.slice(0, 10);
            }
        }
        _inma_models_order__WEBPACK_IMPORTED_MODULE_2__.Orders.search({
            portfolioId: this.selectedPortfolioID,
            orderStatusId: this.statusID ? this.statusID : null,
            orderSideId: this.typeID ? this.typeID : null,
            period: this.periodID ? this.periodID : null,
            startDate: this.startDate ? this.startDate : null,
            endDate: this.endDate ? this.endDate : null,
            referenceNumber: this.orderNumber
        }).subscribe(orders => {
            orders.forEach((o) => {
                o.orderStatusColor = this.getOrderStatusColor(o.status.name);
            });
            // MyApp.openPage(this.navCtrl, 'OrdersSearchResultsPage', false, { orders: orders })
            console.log(orders);
            this.filterData(orders);
            this.showLoader = false;
        });
    }
    // test(){
    //   if(this.selectedPeriod == 1){
    //     this.startDate = "";
    //     this.endDate = "";
    //   }else{
    //     this.periodID = "";
    //     if (this.startDate){this.startDate = this.startDate.slice(0, 10); }
    //     if (this.endDate){this.endDate  = this.endDate.slice(0, 10); }
    //   }
    //   console.log("this.statusID>>>>>>>>>>" + this.statusID);
    //   console.log("this.typeID>>>>>>>>>>" + this.typeID);
    //   console.log("this.periodID>>>>>>>>>>" + this.periodID);
    // }
    getOrderStatusColor(orderStatusColor) {
        let orderStatusBoxColor;
        if (orderStatusColor === "Rejected" || orderStatusColor === "مرفوض") {
            orderStatusBoxColor = "order-status-rejected";
        }
        else if (orderStatusColor === "Filled" || orderStatusColor === "تم التنفيذ") {
            orderStatusBoxColor = "order-status-filled";
        }
        else if (orderStatusColor === "Queued" || orderStatusColor === "قائم") {
            orderStatusBoxColor = "order-status-queued";
        }
        else if (orderStatusColor === "Partially filled" || orderStatusColor === "منفذ جزئيا") {
            orderStatusBoxColor = "order-status-partially-filled";
        }
        else if (orderStatusColor === "Replaced" || orderStatusColor === "معدل") {
            orderStatusBoxColor = "order-status-replaced";
        }
        else {
            orderStatusBoxColor = "order-status-other";
        }
        return orderStatusBoxColor;
    }
    segmentChanged(event) {
        //this.activeSegment = event;
        console.log("statusID>>>>>>>>" + this.statusID);
        console.log("typeID>>>>>>>>" + this.typeID);
    }
    openPortfolioPicker() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            let options = this.allStandardPortfolios.map(p => ({ text: p.id, value: p.id }));
            let pickerAction;
            let opt = {
                buttons: [
                    {
                        text: this.translate.instant('product.CANCEL'),
                        role: 'cancel',
                        handler: value => {
                            pickerAction = 'cancel';
                        }
                    },
                    {
                        text: this.translate.instant('product.OK'),
                        role: 'done',
                        handler: value => {
                            pickerAction = 'done';
                        }
                    }
                ],
                columns: [
                    {
                        selectedIndex: this.selectedPortfolioIndex ? this.selectedPortfolioIndex : 0,
                        name: 'Portfolios',
                        options: options,
                    }
                ]
            };
            let picker = yield this.pickerCtrl.create(opt);
            picker.present();
            picker.onDidDismiss().then((data) => (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
                if (pickerAction == 'done') {
                    let col = yield picker.getColumn('Portfolios');
                    this.selectedPortfolioIndex = col.selectedIndex;
                    this.selectedPortfolioValue = col.options[col.selectedIndex].text;
                    this.selectedPortfolioID = this.allStandardPortfolios.find(p => p.id == this.selectedPortfolioValue);
                }
            }));
        });
    }
    openOrderStatusPicker() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            let options = this.statuses.map((status) => ({ text: status.name, value: status.id }));
            let pickerAction;
            let opt = {
                buttons: [
                    {
                        text: this.translate.instant('product.CANCEL'),
                        role: 'cancel',
                        handler: value => {
                            pickerAction = 'cancel';
                        }
                    },
                    {
                        text: this.translate.instant('product.OK'),
                        role: 'done',
                        handler: value => {
                            pickerAction = 'done';
                        }
                    }
                ],
                columns: [
                    {
                        selectedIndex: this.selectedStatusIndex ? this.selectedStatusIndex : 0,
                        name: 'OrderStatus',
                        options: options,
                    }
                ]
            };
            let picker = yield this.pickerCtrl.create(opt);
            picker.present();
            picker.onDidDismiss().then((data) => (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
                if (pickerAction == 'done') {
                    let col = yield picker.getColumn('OrderStatus');
                    this.selectedStatusIndex = col.selectedIndex;
                    this.selectedStatusValue = col.options[col.selectedIndex].text;
                    this.statusID = this.statuses.find((s) => s.name == this.selectedStatusValue).id;
                }
            }));
        });
    }
    openOrderSidePicker() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            let options = this.types.map((type) => ({ text: type.name, value: type.id }));
            let pickerAction;
            let opt = {
                buttons: [
                    {
                        text: this.translate.instant('product.CANCEL'),
                        role: 'cancel',
                        handler: value => {
                            pickerAction = 'cancel';
                        }
                    },
                    {
                        text: this.translate.instant('product.OK'),
                        role: 'done',
                        handler: value => {
                            pickerAction = 'done';
                        }
                    }
                ],
                columns: [
                    {
                        selectedIndex: this.selectedOrderSideIndex ? this.selectedOrderSideIndex : 0,
                        name: 'OrderStatus',
                        options: options,
                    }
                ]
            };
            let picker = yield this.pickerCtrl.create(opt);
            picker.present();
            picker.onDidDismiss().then((data) => (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
                if (pickerAction == 'done') {
                    let col = yield picker.getColumn('OrderStatus');
                    this.selectedOrderSideIndex = col.selectedIndex;
                    this.selectedOrderSideValue = col.options[col.selectedIndex].text;
                    this.typeID = this.types.find((s) => s.name == this.selectedOrderSideValue).id;
                }
            }));
        });
    }
    openOrderPeriodPicker() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            let options = this.periods.map((type) => ({ text: type.name, value: type.id }));
            let pickerAction;
            let opt = {
                buttons: [
                    {
                        text: this.translate.instant('product.CANCEL'),
                        role: 'cancel',
                        handler: value => {
                            pickerAction = 'cancel';
                        }
                    },
                    {
                        text: this.translate.instant('product.OK'),
                        role: 'done',
                        handler: value => {
                            pickerAction = 'done';
                        }
                    }
                ],
                columns: [
                    {
                        selectedIndex: this.selectedOrderPeriodIndex ? this.selectedOrderPeriodIndex : 0,
                        name: 'OrderPeriod',
                        options: options,
                    }
                ]
            };
            let picker = yield this.pickerCtrl.create(opt);
            picker.present();
            picker.onDidDismiss().then((data) => (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
                if (pickerAction == 'done') {
                    let col = yield picker.getColumn('OrderPeriod');
                    this.selectedOrderPeriodIndex = col.selectedIndex;
                    this.selectedOrderPeriodValue = col.options[col.selectedIndex].text;
                    this.periodID = this.periods.find((period) => period.name == this.selectedOrderPeriodValue).id;
                }
            }));
        });
    }
};
FilterOrdersComponent.ctorParameters = () => [
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_5__.SharedDataService },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__.TranslateService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.PickerController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController }
];
FilterOrdersComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'tadawul-filter-orders',
        template: _filter_orders_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_filter_orders_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:paramtypes", [src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_5__.SharedDataService,
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__.TranslateService,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.PickerController,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController])
], FilterOrdersComponent);



/***/ }),

/***/ 6707:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/standing-orders/filter-results/filter-results.component.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FilterResultsComponent": () => (/* binding */ FilterResultsComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _filter_results_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./filter-results.component.html?ngResource */ 52669);
/* harmony import */ var _filter_results_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./filter-results.component.scss?ngResource */ 32640);
/* harmony import */ var src_app_enum_skeleton_type_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/enum/skeleton-type.enum */ 88617);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _inma_helpers_dialogs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/helpers/dialogs */ 66695);
/* harmony import */ var _inma_models_order__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/models/order */ 39344);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var fitty__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! fitty */ 5986);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var _order_order_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../order/order.page */ 28798);












let FilterResultsComponent = class FilterResultsComponent {
    constructor(sharedData, navCtrl, translate) {
        this.sharedData = sharedData;
        this.navCtrl = navCtrl;
        this.translate = translate;
        this.outstandingOrders = [];
        this.SkeletonType = src_app_enum_skeleton_type_enum__WEBPACK_IMPORTED_MODULE_2__.SkeletonType;
        this.outstandingOrdersHeader = () => [{ title: this.translate.instant('outstandingOrder.companyName'), size: '4.4' }, { title: this.translate.instant('outstandingOrder.price'), size: '1.4' }, { title: this.translate.instant('outstandingOrder.quantity'), size: '1.4' }, { title: this.translate.instant('outstandingOrder.excutedQuantity'), size: '2' }, { title: this.translate.instant('outstandingOrder.status'), size: '1.8' }];
    }
    ngOnInit() {
        this.searchInfoObj = this.sharedData.getSharedData("searchInfoObj");
        this.outstandingOrders = this.sharedData.getSharedData("orders");
        setTimeout(() => {
            (0,fitty__WEBPACK_IMPORTED_MODULE_5__["default"])('#period-container .valueClass', {
                minSize: 10,
                maxSize: 13,
                multiLine: false
            });
            (0,fitty__WEBPACK_IMPORTED_MODULE_5__["default"])('#period-container .textClass', {
                minSize: 16,
                maxSize: 15,
                multiLine: false
            });
        }, 1000);
    }
    backToSearch() {
        this.navCtrl.navigateForward('standing-orders/filter-order', { animated: true });
    }
    collapsSymbole(order, dataArr) {
        for (let i = 0; i < dataArr.length; i++) {
            if (dataArr[i].referenceNumber == order.referenceNumber) {
                if (dataArr[i].expanded == true) {
                    dataArr[i].expanded = false;
                    return;
                }
                else {
                    dataArr[i].expanded = true;
                }
            }
            else {
                dataArr[i].expanded = false;
            }
        }
    }
    editDeleteOrder(order, operation) {
        if (operation == 'delete') {
            _inma_helpers_dialogs__WEBPACK_IMPORTED_MODULE_3__.Dialogs.confirm(this.translate.instant('outstandingOrder.confirmDelete')).subscribe(deleteOrder => {
                if (deleteOrder) {
                    _inma_models_order__WEBPACK_IMPORTED_MODULE_4__.Orders["delete"](order).subscribe(() => {
                        for (var i = 0; i < this.outstandingOrders.length; i++) {
                            if (this.outstandingOrders[i].referenceNumber === order.referenceNumber) {
                                this.outstandingOrders.splice(i, 1);
                                break;
                            }
                        }
                    });
                }
                else { }
            });
            // if (confirm(this.translate.instant('outstandingOrder.confirmDelete))
            //   Orders.delete(order).subscribe(() => {
            //     this.getOutstandingOrders(this.selectedPortfolioID);
            //   });
        }
        else {
            this.sharedData.setSharedData(order, 'sharedOrder');
            this.sharedData.setSharedData(operation, 'orderOperation');
            this.navCtrl.navigateForward('order', { animated: true });
            _order_order_page__WEBPACK_IMPORTED_MODULE_7__.OrderPage.initialize();
        }
    }
};
FilterResultsComponent.ctorParameters = () => [
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_6__.SharedDataService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateService }
];
FilterResultsComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        selector: 'tadawul-filter-results',
        template: _filter_results_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_filter_results_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__metadata)("design:paramtypes", [src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_6__.SharedDataService,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController,
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateService])
], FilterResultsComponent);



/***/ }),

/***/ 41133:
/*!************************************************************************************!*\
  !*** ./src/app/pages/standing-orders/order-of-orders/order-of-orders.component.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderOfOrdersComponent": () => (/* binding */ OrderOfOrdersComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _order_of_orders_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./order-of-orders.component.html?ngResource */ 1624);
/* harmony import */ var _order_of_orders_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./order-of-orders.component.scss?ngResource */ 56149);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 93819);





let OrderOfOrdersComponent = class OrderOfOrdersComponent {
    constructor(modalControl) {
        this.modalControl = modalControl;
    }
    ngOnInit() { }
    closeModal() {
        //this.modalControl.dismiss();
    }
    OrderData(orderType) {
        const data = orderType;
        this.modalControl.dismiss(data);
    }
};
OrderOfOrdersComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.ModalController }
];
OrderOfOrdersComponent.propDecorators = {
    orderBy: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }]
};
OrderOfOrdersComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'tadawul-order-of-orders',
        template: _order_of_orders_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_order_of_orders_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__metadata)("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__.ModalController])
], OrderOfOrdersComponent);



/***/ }),

/***/ 47509:
/*!*************************************************************************!*\
  !*** ./src/app/pages/standing-orders/standing-orders-routing.module.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StandingOrdersPageRoutingModule": () => (/* binding */ StandingOrdersPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _filter_orders_filter_orders_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./filter-orders/filter-orders.component */ 76302);
/* harmony import */ var _filter_results_filter_results_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./filter-results/filter-results.component */ 6707);
/* harmony import */ var _standing_orders_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./standing-orders.page */ 52799);






const routes = [
    {
        path: '',
        component: _standing_orders_page__WEBPACK_IMPORTED_MODULE_2__.StandingOrdersPage
    },
    {
        path: 'filter-order',
        component: _filter_orders_filter_orders_component__WEBPACK_IMPORTED_MODULE_0__.FilterOrdersComponent
    },
    {
        path: 'search-results',
        component: _filter_results_filter_results_component__WEBPACK_IMPORTED_MODULE_1__.FilterResultsComponent
    }
];
let StandingOrdersPageRoutingModule = class StandingOrdersPageRoutingModule {
};
StandingOrdersPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule],
    })
], StandingOrdersPageRoutingModule);



/***/ }),

/***/ 47425:
/*!*****************************************************************!*\
  !*** ./src/app/pages/standing-orders/standing-orders.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StandingOrdersPageModule": () => (/* binding */ StandingOrdersPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _standing_orders_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./standing-orders-routing.module */ 47509);
/* harmony import */ var _standing_orders_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./standing-orders.page */ 52799);
/* harmony import */ var src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/common-ui-components/tadawul-common-ui.module */ 50773);
/* harmony import */ var _filter_orders_filter_orders_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./filter-orders/filter-orders.component */ 76302);
/* harmony import */ var _order_of_orders_order_of_orders_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./order-of-orders/order-of-orders.component */ 41133);
/* harmony import */ var _delete_order_delete_order_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./delete-order/delete-order.component */ 51987);
/* harmony import */ var _filter_results_filter_results_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./filter-results/filter-results.component */ 6707);
/* harmony import */ var src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/pipes/pipes.module */ 41041);














let StandingOrdersPageModule = class StandingOrdersPageModule {
};
StandingOrdersPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_10__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonicModule,
            _standing_orders_routing_module__WEBPACK_IMPORTED_MODULE_0__.StandingOrdersPageRoutingModule,
            src_app_common_ui_components_tadawul_common_ui_module__WEBPACK_IMPORTED_MODULE_2__.TadawulCommonUiModule,
            src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_7__.PipesModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__.TranslateModule.forChild()
        ],
        declarations: [_standing_orders_page__WEBPACK_IMPORTED_MODULE_1__.StandingOrdersPage, _filter_orders_filter_orders_component__WEBPACK_IMPORTED_MODULE_3__.FilterOrdersComponent, _order_of_orders_order_of_orders_component__WEBPACK_IMPORTED_MODULE_4__.OrderOfOrdersComponent, _delete_order_delete_order_component__WEBPACK_IMPORTED_MODULE_5__.DeleteOrderComponent, _filter_results_filter_results_component__WEBPACK_IMPORTED_MODULE_6__.FilterResultsComponent]
    })
], StandingOrdersPageModule);



/***/ }),

/***/ 52799:
/*!***************************************************************!*\
  !*** ./src/app/pages/standing-orders/standing-orders.page.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StandingOrdersPage": () => (/* binding */ StandingOrdersPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _standing_orders_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./standing-orders.page.html?ngResource */ 50487);
/* harmony import */ var _standing_orders_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./standing-orders.page.scss?ngResource */ 92204);
/* harmony import */ var ngx_navigation_with_data__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ngx-navigation-with-data */ 5430);
/* harmony import */ var src_app_helpers_localized_string__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/helpers/localized-string */ 41734);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @inma/models/portfolio */ 65082);
/* harmony import */ var _inma_models_order__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @inma/models/order */ 39344);
/* harmony import */ var _order_of_orders_order_of_orders_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./order-of-orders/order-of-orders.component */ 41133);
/* harmony import */ var _filter_orders_filter_orders_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./filter-orders/filter-orders.component */ 76302);
/* harmony import */ var src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/providers/shared-data.service */ 9046);
/* harmony import */ var _order_order_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../order/order.page */ 28798);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _inma_helpers_dialogs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @inma/helpers/dialogs */ 66695);
/* harmony import */ var _delete_order_delete_order_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./delete-order/delete-order.component */ 51987);
/* harmony import */ var _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @inma/helpers/settings */ 96892);
/* harmony import */ var src_app_enum_skeleton_type_enum__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/enum/skeleton-type.enum */ 88617);
/* harmony import */ var _inma_models_symbol__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @inma/models/symbol */ 61202);




















let StandingOrdersPage = class StandingOrdersPage {
    constructor(modalController, sharedData, navCtrl, translate, route, pickerCtrl) {
        this.modalController = modalController;
        this.sharedData = sharedData;
        this.navCtrl = navCtrl;
        this.translate = translate;
        this.route = route;
        this.pickerCtrl = pickerCtrl;
        this.order = true;
        this.filter = true;
        this.outstandingOrders = [];
        this.tempOutstandingOrders = [];
        this.allStandardPortfolios = [];
        this.allPortfolios = [];
        this.searchTerm = '';
        this.showLoader = false;
        this.lang = "Ar";
        this.SkeletonType = src_app_enum_skeleton_type_enum__WEBPACK_IMPORTED_MODULE_12__.SkeletonType;
        this.orderType = 'period';
        this.orderStatusBoxColor = '';
        this.outstandingOrdersHeader = () => [{ title: this.translate.instant('outstandingOrder.companyName'), size: '4.4' }, { title: this.translate.instant('outstandingOrder.price'), size: '1.4' }, { title: this.translate.instant('outstandingOrder.quantity'), size: '1.4' }, { title: this.translate.instant('outstandingOrder.excutedQuantity'), size: '2' }, { title: this.translate.instant('outstandingOrder.status'), size: '1.8' }];
        this.MFoutstandingOrdersHeader = () => [{ title: this.translate.instant('outstandingOrder.mutualFund'), size: '3.7' }, { title: this.translate.instant('outstandingOrder.orderType'), size: '2.5' }, { title: this.translate.instant('outstandingOrder.unitNo'), size: '1.5' }, { title: this.translate.instant('outstandingOrder.price'), size: '1.5' }, { title: this.translate.instant('outstandingOrder.status'), size: '1.8' }];
        if (this.navCtrl.get('selectedPorNav')) {
            setTimeout(() => {
                this.selectedPortfolioID = this.navCtrl.get('selectedPorNav');
                this.accountType = "IP";
                this.getAllPortfolio();
                this.setFilteredItems();
            }, 500);
        }
        else {
            this.getAllPortfolio();
            this.setFilteredItems();
        }
        // this.route.params.subscribe(val => {
        //   setTimeout(() => {
        //     //this.getAllStandardPortfolios();
        //     if(val['selectedPorNav']){
        //       this.selectedPortfolioID = val['selectedPorNav'];
        //     }
        //     this.getAllPortfolio();
        //     this.setFilteredItems();
        //   }, 100);
        // });
    }
    ngOnInit() {
        // this.onEnterOutstandingOrder();
    }
    onEnterOutstandingOrder() {
        //this.getAllStandardPortfolios();
        this.getAllPortfolio();
        this.setFilteredItems();
        if (_inma_helpers_settings__WEBPACK_IMPORTED_MODULE_11__.Settings.language == _inma_helpers_settings__WEBPACK_IMPORTED_MODULE_11__.Languages.Arabic) {
            this.lang = "Ar";
        }
        else {
            this.lang = "En";
        }
    }
    doRefresh(event) {
        this.checkPortfolioType(this.selectedPortfolioID);
        setTimeout(() => {
            event.target.complete();
        }, 200);
    }
    presentOrderModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, function* () {
            if (this.showLoader) {
                return false;
            }
            const modal = yield this.modalController.create({
                component: _order_of_orders_order_of_orders_component__WEBPACK_IMPORTED_MODULE_5__.OrderOfOrdersComponent,
                cssClass: 'auto-height-modal',
                swipeToClose: true,
                componentProps: {
                    orderBy: this.orderType
                }
            });
            modal.onDidDismiss()
                .then((data) => {
                // console.log(data.data);
                this.orderType = data.data;
                if (data.data === 'period') {
                    this.orderByDate();
                }
                else if (data.data === 'type') {
                    this.orderByType();
                }
                else if (data.data === 'status') {
                    this.orderByStatus();
                }
            });
            return yield modal.present();
        });
    }
    presentFilterModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _filter_orders_filter_orders_component__WEBPACK_IMPORTED_MODULE_6__.FilterOrdersComponent,
                cssClass: '',
                swipeToClose: true,
                componentProps: {
                    portfolioID: this.selectedPortfolioID
                }
            });
            modal.onDidDismiss()
                .then((data) => {
                // console.log(data.data);
                if (data.data) {
                    this.tempOutstandingOrders = [];
                    this.tempOutstandingOrders = data.data;
                    debugger;
                    for (let i = 0; i < this.tempOutstandingOrders.length; i++) {
                        this.tempOutstandingOrders[i].symbol.abbreviation.subscribe(abbreviation => {
                            // console.log('abbreviation>>>>>>>>' + abbreviation);
                            this.tempOutstandingOrders[i].symbol.abbreviation = abbreviation;
                        });
                        this.tempOutstandingOrders[i].symbol.name.subscribe(name => {
                            //console.log('name>>>>>>>>' + name);
                            this.tempOutstandingOrders[i].symbol.name = name;
                        });
                        if (this.tempOutstandingOrders[i].side.id === 'BUY') {
                            this.tempOutstandingOrders[i].ststusColor = 'success';
                        }
                        else {
                            this.tempOutstandingOrders[i].ststusColor = 'danger';
                        }
                        this.tempOutstandingOrders[i]._name = new src_app_helpers_localized_string__WEBPACK_IMPORTED_MODULE_2__.LocalizedString(this.tempOutstandingOrders[i].mutualFundEnName, this.tempOutstandingOrders[i].mutualFundAnName, this.translate);
                        this.tempOutstandingOrders[i]._label = new src_app_helpers_localized_string__WEBPACK_IMPORTED_MODULE_2__.LocalizedString(this.tempOutstandingOrders[i].mutualFundOrderTypeEnLabel, this.tempOutstandingOrders[i].mutualFundOrderTypeArLabel, this.translate);
                    }
                    this.outstandingOrders = this.tempOutstandingOrders;
                }
            });
            return yield modal.present();
        });
    }
    presentDeleteOrderModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, function* () {
            if (this.showLoader) {
                return false;
            }
            if (this.outstandingOrders.length == 0) {
                // alert(this.t.emptyOrders);
                _inma_helpers_dialogs__WEBPACK_IMPORTED_MODULE_9__.Dialogs.alert(this.translate.instant('outstandingOrder.emptyOrders')).subscribe(deleteOrders => {
                });
                return false;
            }
            //console.log(this.outstandingOrders)
            const modal = yield this.modalController.create({
                component: _delete_order_delete_order_component__WEBPACK_IMPORTED_MODULE_10__.DeleteOrderComponent,
                cssClass: '',
                componentProps: {
                    outstandingOrders: this.outstandingOrders
                }
            });
            modal.onDidDismiss()
                .then((data) => {
                // console.log(data.data);
                if (data.data == "delete") {
                    this.getOutstandingOrders(this.selectedPortfolioID);
                }
            });
            return yield modal.present();
        });
    }
    // async presentWalletModal() {
    //   const modal = await this.modalController.create({
    //     component: CustomeSelectComponent,
    //     cssClass: 'custom-select',
    //     componentProps: {
    //       'data': this.allStandardPortfolios,
    //       'rowData': "id",
    //       'text': this.t.CANCEL,
    //     }
    //   });
    //   modal.onDidDismiss()
    //     .then((data) => {
    //       console.log(data.data);
    //       this.selectedPortfolioID = data.data.id
    //       this.getOutstandingOrders(data.data.id);
    //     });
    //   return await modal.present();
    // }
    orderByDate() {
        this.tempOutstandingOrders.sort(function (a, b) {
            const keyA = new Date(a.dateTime), keyB = new Date(b.dateTime);
            // Compare the 2 dates
            if (keyA < keyB)
                return 1;
            if (keyA > keyB)
                return -1;
            return 0;
        });
        //console.log(this.tempOutstandingOrders);
    }
    orderByStatus() {
        this.tempOutstandingOrders.sort(function compare(a, b) {
            if (a.status.name < b.status.name) {
                return -1;
            }
            if (a.status.name > b.status.name) {
                return 1;
            }
            return 0;
        });
        //console.log(this.outstandingOrders);
    }
    orderByType() {
        this.tempOutstandingOrders.sort(function compare(a, b) {
            if (a.side.name < b.side.name) {
                return -1;
            }
            if (a.side.name > b.side.name) {
                return 1;
            }
            return 0;
        });
        // console.log(this.outstandingOrders);
    }
    getAllStandardPortfolios() {
        this.showLoader = true;
        _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_3__.Portfolios.allStandardPortfolios.subscribe(allStandardPortfolios => {
            //console.log('allStandardPortfolios>>>>>>>>>>' + allStandardPortfolios);
            this.allStandardPortfolios = allStandardPortfolios;
            this.selectedPortfolioID = allStandardPortfolios[0].id;
            this.getOutstandingOrders(allStandardPortfolios[0].id);
        }, err => {
            console.log('HTTP Error', err);
            this.showLoader = false;
        });
    }
    getAllPortfolio() {
        this.showLoader = true;
        _inma_models_portfolio__WEBPACK_IMPORTED_MODULE_3__.Portfolios.all.subscribe(Portfolios => {
            var _a;
            this.allPortfolios = Portfolios;
            // this.selectedPortfolioID = this.sharedData.getSharedData('selectedPor',false);
            if (!this.selectedPortfolioID) {
                for (let i = 0; i < Portfolios.length; i++) {
                    if (((_a = Portfolios[i]) === null || _a === void 0 ? void 0 : _a.defaultPortfolio) == true) {
                        this.selectedPortfolioID = Portfolios[i].id;
                    }
                }
                if (!this.selectedPortfolioID) {
                    this.selectedPortfolioID = Portfolios[0].id;
                }
                this.accountType = this.allPortfolios[0].type;
            }
            if (this.accountType == "IP") {
                this.getOutstandingOrders(this.selectedPortfolioID);
            }
            else {
                this.getMFOutstandingOrders(this.selectedPortfolioID);
            }
        }, err => {
            console.log('HTTP Error', err);
            this.showLoader = false;
        });
    }
    checkPortfolioType(portfolioID) {
        this.tempOutstandingOrders = [];
        this.outstandingOrders = [];
        this.selectedPortfolioID = portfolioID;
        for (let i = 0; i < this.allPortfolios.length; i++) {
            if (portfolioID == this.allPortfolios[i].id) {
                this.accountType = this.allPortfolios[i].type;
            }
        }
        if (this.accountType == "IP") {
            this.getOutstandingOrders(portfolioID);
        }
        else {
            this.getMFOutstandingOrders(portfolioID);
        }
    }
    openPortfolioPicker() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, function* () {
            let options = this.allPortfolios.map(p => ({ text: p.id, value: p.id }));
            let pickerAction;
            if (this.selectedPortfolioID) {
                for (let i = 0; i <= this.allPortfolios.length - 1; i++) {
                    if (this.allPortfolios[i].id == this.selectedPortfolioID) {
                        this.selectedPortfolioIndex = i;
                    }
                }
            }
            let opt = {
                buttons: [
                    {
                        text: this.translate.instant('product.CANCEL'),
                        role: 'cancel',
                        handler: value => {
                            pickerAction = 'cancel';
                        }
                    },
                    {
                        text: this.translate.instant('product.OK'),
                        role: 'done',
                        handler: value => {
                            pickerAction = 'done';
                        }
                    }
                ],
                columns: [
                    {
                        selectedIndex: this.selectedPortfolioIndex ? this.selectedPortfolioIndex : 0,
                        name: 'Portfolios',
                        options: options,
                    }
                ]
            };
            let picker = yield this.pickerCtrl.create(opt);
            picker.present();
            picker.onDidDismiss().then((data) => (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, function* () {
                if (pickerAction == 'done') {
                    let col = yield picker.getColumn('Portfolios');
                    this.selectedPortfolioIndex = col.selectedIndex;
                    this.selectedPortfolioValue = col.options[col.selectedIndex].text;
                    console.log(this.selectedPortfolioValue);
                    if (this.selectedPortfolioID == this.selectedPortfolioValue) {
                        console.log('not changed');
                        return;
                    }
                    else {
                        console.log('changed');
                        this.selectedPortfolioID = this.allPortfolios.find(p => p.id == this.selectedPortfolioValue).id;
                        this.checkPortfolioType(this.selectedPortfolioValue);
                    }
                }
            }));
        });
    }
    getMFOutstandingOrders(selectedPortfolio) {
        this.showLoader = true;
        this.outstandingOrders = [];
        this.selectedPortfolioID = selectedPortfolio;
        _inma_models_order__WEBPACK_IMPORTED_MODULE_4__.Orders.mutualFundOutstandingOrders(selectedPortfolio).subscribe(MFoutstandingOrders => {
            // console.log('MFoutstandingOrders>>>>>>>>>>' + MFoutstandingOrders);
            this.showLoader = false;
            this.outstandingOrders = MFoutstandingOrders;
            for (let i = 0; i < this.outstandingOrders.length; i++) {
                this.outstandingOrders[i].expanded = false;
                this.outstandingOrders[i]._name = new src_app_helpers_localized_string__WEBPACK_IMPORTED_MODULE_2__.LocalizedString(this.outstandingOrders[i].mutualFundEnName, this.outstandingOrders[i].mutualFundArName, this.translate);
                this.outstandingOrders[i]._label = new src_app_helpers_localized_string__WEBPACK_IMPORTED_MODULE_2__.LocalizedString(this.outstandingOrders[i].mutualFundOrderTypeEnLabel, this.outstandingOrders[i].mutualFundOrderTypeArLabel, this.translate);
            }
            this.tempOutstandingOrders = MFoutstandingOrders;
        }, err => {
            console.log('HTTP Error', err);
            this.showLoader = false;
        });
    }
    getOutstandingOrders(selectedPortfolio) {
        this.showLoader = true;
        this.outstandingOrders = [];
        this.selectedPortfolioID = selectedPortfolio;
        _inma_models_order__WEBPACK_IMPORTED_MODULE_4__.Orders.getOutstandingOrders(selectedPortfolio).subscribe(outstandingOrders => {
            this.showLoader = false;
            _inma_models_symbol__WEBPACK_IMPORTED_MODULE_13__.Symbols.all.subscribe((allSymbols) => {
                // console.log('outstandingOrders>>>>>>>>>>' + outstandingOrders);
                this.outstandingOrders = outstandingOrders;
                for (let i = 0; i < outstandingOrders.length; i++) {
                    let symbol = allSymbols.find((s) => s.id == outstandingOrders[i].symbol.id);
                    this.outstandingOrders[i]._name = symbol.id + ' - ' + symbol.sortAbbreviation;
                    if (this.outstandingOrders[i].side.id === 'BUY') {
                        this.outstandingOrders[i].ststusColor = 'success';
                    }
                    else {
                        this.outstandingOrders[i].ststusColor = 'danger';
                    }
                    this.outstandingOrders[i].orderStatusColor = this.getOrderStatusColor(this.outstandingOrders[i].status.name);
                    this.outstandingOrders[i].expanded = false;
                }
                this.tempOutstandingOrders = this.outstandingOrders;
            }, err => {
                console.log('HTTP Error', err);
                this.showLoader = false;
            });
        });
    }
    // getOrderDetail(order){
    // console.log('order.side.name>>>>>>>>>>' + order.side.name);
    // }
    filterItems(searchTerm) {
        return this.outstandingOrders.filter(outstandingOrders => {
            return outstandingOrders.symbol._name.toString().toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
        });
    }
    setFilteredItems() {
        this.tempOutstandingOrders = this.filterItems(this.searchTerm);
    }
    editDeleteOrder(order, operation) {
        if (operation == 'delete') {
            _inma_helpers_dialogs__WEBPACK_IMPORTED_MODULE_9__.Dialogs.confirm(this.translate.instant('outstandingOrder.confirmDelete')).subscribe(deleteOrder => {
                if (deleteOrder) {
                    _inma_models_order__WEBPACK_IMPORTED_MODULE_4__.Orders["delete"](order).subscribe(() => {
                        this.getOutstandingOrders(this.selectedPortfolioID);
                    });
                }
                else { }
            });
            // if (confirm(this.t.confirmDelete))
            //   Orders.delete(order).subscribe(() => {
            //     this.getOutstandingOrders(this.selectedPortfolioID);
            //   });
        }
        else {
            this.serachOrderByID(order, operation);
        }
    }
    serachOrderByID(order, operation) {
        _inma_models_order__WEBPACK_IMPORTED_MODULE_4__.Orders.search({
            referenceNumber: order.referenceNumber,
            portfolioId: this.selectedPortfolioID
        }).subscribe(orders => {
            this.sharedData.setSharedData(orders[0], 'sharedOrder');
            console.log("🚀 ~ file: standing-orders.page.ts ~ line 379 ~ applyNavParams ~ StandingOrdersPage ~ serachOrderByID ~ orders[0]", orders[0].remainingQuantity);
            this.sharedData.setSharedData(operation, 'operation');
            this.openModal(orders[0], operation);
            // this.navCtrl.navigateForward('order', { animated: true });
            // OrderPage.initialize();
        });
    }
    openModal(order, operation) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _order_order_page__WEBPACK_IMPORTED_MODULE_8__.OrderPage,
                cssClass: 'buy-sell',
                componentProps: {
                    sharedOrder: order,
                    // sharedSymbol: order.symbol,
                    operation: operation
                },
                // cssClass:'dragable-modal',
                swipeToClose: true
            });
            return yield modal.present();
        });
    }
    deleteAll() {
        if (this.outstandingOrders.length == 0) {
            return false;
        }
        _inma_helpers_dialogs__WEBPACK_IMPORTED_MODULE_9__.Dialogs.confirm(this.translate.instant('outstandingOrder.confirmDelete')).subscribe(deleteOrders => {
            if (deleteOrders) {
                for (let i = 0; i < this.outstandingOrders.length; i++) {
                    _inma_models_order__WEBPACK_IMPORTED_MODULE_4__.Orders["delete"](this.outstandingOrders[i]).subscribe();
                }
                this.getOutstandingOrders(this.selectedPortfolioID);
            }
            else { }
        });
    }
    collapsSymbole(order, dataArr) {
        for (let i = 0; i < dataArr.length; i++) {
            if (dataArr[i].referenceNumber == order.referenceNumber) {
                if (dataArr[i].expanded == true) {
                    dataArr[i].expanded = false;
                    return;
                }
                else {
                    dataArr[i].expanded = true;
                }
            }
            else {
                dataArr[i].expanded = false;
            }
        }
    }
    collapsMFSymbole(order, dataArr) {
        for (let i = 0; i < dataArr.length; i++) {
            if (dataArr[i].orderId == order.orderId) {
                if (dataArr[i].expanded == true) {
                    dataArr[i].expanded = false;
                    return;
                }
                else {
                    dataArr[i].expanded = true;
                }
            }
            else {
                dataArr[i].expanded = false;
            }
        }
    }
    getOrderStatusColor(orderStatusColor) {
        if (orderStatusColor === "Rejected" || orderStatusColor === "مرفوض") {
            this.orderStatusBoxColor = "order-status-rejected";
        }
        else if (orderStatusColor === "Filled" || orderStatusColor === "تم التنفيذ") {
            this.orderStatusBoxColor = "order-status-filled";
        }
        else if (orderStatusColor === "Queued" || orderStatusColor === "قائم") {
            this.orderStatusBoxColor = "order-status-queued";
        }
        else if (orderStatusColor === "Partially filled" || orderStatusColor === "منفذ جزئيا") {
            this.orderStatusBoxColor = "order-status-partially-filled";
        }
        else if (orderStatusColor === "Replaced" || orderStatusColor === "معدل") {
            this.orderStatusBoxColor = "order-status-replaced";
        }
        else {
            this.orderStatusBoxColor = "order-status-other";
        }
        return this.orderStatusBoxColor;
    }
};
StandingOrdersPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.ModalController },
    { type: src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_7__.SharedDataService },
    { type: ngx_navigation_with_data__WEBPACK_IMPORTED_MODULE_16__.NgxNavigationWithDataComponent },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_17__.TranslateService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_18__.ActivatedRoute },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.PickerController }
];
StandingOrdersPage = (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_19__.Component)({
        selector: 'app-standing-orders',
        template: _standing_orders_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_standing_orders_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    }),
    (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_15__.ModalController,
        src_app_providers_shared_data_service__WEBPACK_IMPORTED_MODULE_7__.SharedDataService,
        ngx_navigation_with_data__WEBPACK_IMPORTED_MODULE_16__.NgxNavigationWithDataComponent,
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_17__.TranslateService,
        _angular_router__WEBPACK_IMPORTED_MODULE_18__.ActivatedRoute,
        _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.PickerController])
], StandingOrdersPage);



/***/ }),

/***/ 3066:
/*!*******************************************************************************************!*\
  !*** ./src/app/pages/standing-orders/delete-order/delete-order.component.scss?ngResource ***!
  \*******************************************************************************************/
/***/ ((module) => {

module.exports = ".walletClass {\n  width: 55px;\n  height: 23px;\n  font-size: 18px;\n  font-weight: bold;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: normal;\n  letter-spacing: normal;\n  text-align: right;\n  color: var(--ion-color-primary-txt);\n}\n\n.card-height {\n  height: 400px;\n  overflow-y: scroll;\n  padding: 0px 0;\n}\n\n.standing-order-header {\n  padding: 5px 0;\n}\n\n.standing-order-toolbar {\n  --background: #005157;\n  text-align: center;\n  color: white;\n}\n\n.deleteNote {\n  background-color: #fdf9f2;\n  border: 1px solid #f5a623;\n  color: #f5a623;\n  font-size: 12px;\n  height: 65px;\n  padding-top: 11px;\n}\n\nbody.dark :host .deleteNote {\n  background-color: transparent !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRlbGV0ZS1vcmRlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBRUEsZUFBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0Esc0JBQUE7RUFDQSxpQkFBQTtFQUNBLG1DQUFBO0FBQUo7O0FBR0E7RUFDSSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FBQUo7O0FBR0E7RUFDSSxjQUFBO0FBQUo7O0FBR0E7RUFDSSxxQkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtBQUFKOztBQUdBO0VBQ0kseUJBQUE7RUFDQSx5QkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0FBQUo7O0FBSUE7RUFDSSx3Q0FBQTtBQURKIiwiZmlsZSI6ImRlbGV0ZS1vcmRlci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi53YWxsZXRDbGFzc3tcbiAgICB3aWR0aDogNTVweDtcbiAgICBoZWlnaHQ6IDIzcHg7XG4gICAgLy9mb250LWZhbWlseTogQWxpbm1hVGhlU2FucztcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiBub3JtYWw7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktdHh0KTtcbn1cblxuLmNhcmQtaGVpZ2h0e1xuICAgIGhlaWdodDogNDAwcHg7XG4gICAgb3ZlcmZsb3cteTogc2Nyb2xsO1xuICAgIHBhZGRpbmc6IDBweCAwO1xufVxuXG4uc3RhbmRpbmctb3JkZXItaGVhZGVye1xuICAgIHBhZGRpbmc6IDVweCAwO1xufVxuXG4uc3RhbmRpbmctb3JkZXItdG9vbGJhcntcbiAgICAtLWJhY2tncm91bmQ6ICMwMDUxNTc7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiB3aGl0ZTtcbn1cblxuLmRlbGV0ZU5vdGV7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZkZjlmMjtcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZjVhNjIzO1xuICAgIGNvbG9yOiAjZjVhNjIzO1xuICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICBoZWlnaHQ6IDY1cHg7XG4gICAgcGFkZGluZy10b3A6IDExcHg7XG5cbn1cblxuYm9keS5kYXJrIDpob3N0IC5kZWxldGVOb3Rle1xuICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50IWltcG9ydGFudDtcbn0iXX0= */";

/***/ }),

/***/ 36687:
/*!*********************************************************************************************!*\
  !*** ./src/app/pages/standing-orders/filter-orders/filter-orders.component.scss?ngResource ***!
  \*********************************************************************************************/
/***/ ((module) => {

module.exports = "ion-header ion-toolbar {\n  --background: #005157;\n  color: #fff;\n  --border-width: 0;\n}\n\nion-content {\n  --padding-top: 20px;\n}\n\nion-content .form-label {\n  font-size: 12px;\n}\n\nion-content ion-select {\n  border: 1px solid #99b9bc;\n  border-radius: 5px;\n  padding: 5px 10px;\n}\n\nion-content ion-segment.form-segment {\n  max-width: 100%;\n}\n\n.select-picker-placeholder {\n  align-items: center;\n  height: 40px;\n  display: flex;\n  justify-content: space-between;\n  border: solid 1px #cddcdd;\n  border-radius: 5px;\n}\n\n.picker-select-icon {\n  transform: rotate(90deg);\n}\n\n.select-color {\n  color: #005157 !important;\n  margin: 0 10px;\n}\n\nion-datetime.rounded-date {\n  display: flex;\n  margin: auto;\n  --color: var(--ion-color-tertiary-contrast) !important;\n  color: var(--ion-color-tertiary-contrast) !important;\n  --caret-color: var(--ion-color-tertiary-contrast) !important;\n  --placeholder-color: var(--ion-color-tertiary-contrast) !important;\n}\n\n.date-time-modal {\n  --backdrop-opacity: 0.7 !important;\n  --border-radius: 10px !important;\n}\n\n.date-time-modal::part(backdrop) {\n  background-color: black;\n  opacity: 0.7;\n}\n\n.date-time-modal::part(content) {\n  width: 90% !important;\n  height: 55%;\n  max-width: 400px !important;\n  max-height: 350px !important;\n}\n\n.select-picker-placeholder {\n  align-items: center;\n  height: 40px;\n  display: flex;\n  justify-content: space-between;\n  border: solid 1px #cddcdd;\n  border-radius: 5px;\n}\n\n.picker-select-icon {\n  transform: rotate(90deg);\n}\n\n.select-color {\n  color: #005157 !important;\n  margin: 0 10px;\n}\n\n.icon-bg {\n  width: 30px;\n  height: 30px;\n  border-radius: 4px;\n  background-color: var(--ion-color-tertiary);\n  z-index: 100;\n  display: grid;\n  place-items: center;\n}\n\n.main-color {\n  color: var(--ion-color-primary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbHRlci1vcmRlcnMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0k7RUFDRSxxQkFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtBQUFOOztBQUlBO0VBQ0ksbUJBQUE7QUFESjs7QUFHSTtFQUNJLGVBQUE7QUFEUjs7QUFJSTtFQUNJLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQUZSOztBQUtJO0VBQ0ksZUFBQTtBQUhSOztBQWFBO0VBQ0ksbUJBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtBQVZKOztBQWFBO0VBQ0ksd0JBQUE7QUFWSjs7QUFjQTtFQUNJLHlCQUFBO0VBQ0EsY0FBQTtBQVhKOztBQWNBO0VBQ0ksYUFBQTtFQUNBLFlBQUE7RUFDQSxzREFBQTtFQUNBLG9EQUFBO0VBQ0EsNERBQUE7RUFDQSxrRUFBQTtBQVhKOztBQWNFO0VBQ0Usa0NBQUE7RUFDQSxnQ0FBQTtBQVhKOztBQVlJO0VBQ0UsdUJBQUE7RUFDQSxZQUFBO0FBVk47O0FBYUk7RUFDRSxxQkFBQTtFQUNBLFdBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0FBWE47O0FBZUU7RUFDRSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0FBWko7O0FBY0U7RUFDRSx3QkFBQTtBQVhKOztBQWVFO0VBQ0UseUJBQUE7RUFDQSxjQUFBO0FBWko7O0FBY0U7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsMkNBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FBWEo7O0FBYUU7RUFDRSwrQkFBQTtBQVZKIiwiZmlsZSI6ImZpbHRlci1vcmRlcnMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcbiAgICBpb24tdG9vbGJhciB7XG4gICAgICAtLWJhY2tncm91bmQ6ICMwMDUxNTc7XG4gICAgICBjb2xvcjogI2ZmZjtcbiAgICAgIC0tYm9yZGVyLXdpZHRoOiAwO1xuICAgIH1cbn1cblxuaW9uLWNvbnRlbnQge1xuICAgIC0tcGFkZGluZy10b3A6IDIwcHg7XG5cbiAgICAuZm9ybS1sYWJlbCB7XG4gICAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICB9XG4gICAgXG4gICAgaW9uLXNlbGVjdCB7XG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICM5OWI5YmM7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICAgICAgcGFkZGluZzogNXB4IDEwcHg7XG4gICAgfVxuXG4gICAgaW9uLXNlZ21lbnQuZm9ybS1zZWdtZW50IHtcbiAgICAgICAgbWF4LXdpZHRoOiAxMDAlO1xuICAgIH1cblxuICAgIC8vIFBpY2tlciBzdHlsZSBcblxuICAgXG59XG5cblxuXG4uc2VsZWN0LXBpY2tlci1wbGFjZWhvbGRlciB7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBoZWlnaHQ6IDQwcHg7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgYm9yZGVyOiBzb2xpZCAxcHggI2NkZGNkZDtcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XG59XG5cbi5waWNrZXItc2VsZWN0LWljb24ge1xuICAgIHRyYW5zZm9ybTogcm90YXRlKDkwZGVnKTtcblxufVxuXG4uc2VsZWN0LWNvbG9yIHtcbiAgICBjb2xvcjogICMwMDUxNTcgIWltcG9ydGFudDtcbiAgICBtYXJnaW46IDAgMTBweDtcbn1cblxuaW9uLWRhdGV0aW1lLnJvdW5kZWQtZGF0ZSB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBtYXJnaW46IGF1dG87XG4gICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5LWNvbnRyYXN0KSAhaW1wb3J0YW50O1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItdGVydGlhcnktY29udHJhc3QpICFpbXBvcnRhbnQ7XG4gICAgLS1jYXJldC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5LWNvbnRyYXN0KSAhaW1wb3J0YW50O1xuICAgIC0tcGxhY2Vob2xkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci10ZXJ0aWFyeS1jb250cmFzdCkgIWltcG9ydGFudDtcbiAgfVxuXG4gIC5kYXRlLXRpbWUtbW9kYWwge1xuICAgIC0tYmFja2Ryb3Atb3BhY2l0eTogMC43ICFpbXBvcnRhbnQ7XG4gICAgLS1ib3JkZXItcmFkaXVzOiAxMHB4ICFpbXBvcnRhbnQ7XG4gICAgJjo6cGFydChiYWNrZHJvcCkge1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7XG4gICAgICBvcGFjaXR5OiAwLjc7XG4gICAgfVxuICBcbiAgICAmOjpwYXJ0KGNvbnRlbnQpIHtcbiAgICAgIHdpZHRoOiA5MCUgIWltcG9ydGFudDtcbiAgICAgIGhlaWdodDogNTUlO1xuICAgICAgbWF4LXdpZHRoOiA0MDBweCAhaW1wb3J0YW50O1xuICAgICAgbWF4LWhlaWdodDogMzUwcHggIWltcG9ydGFudDtcbiAgICB9XG4gIH1cblxuICAuc2VsZWN0LXBpY2tlci1wbGFjZWhvbGRlciB7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBoZWlnaHQ6IDQwcHg7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgYm9yZGVyOiBzb2xpZCAxcHggI2NkZGNkZDtcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIH1cbiAgLnBpY2tlci1zZWxlY3QtaWNvbiB7XG4gICAgdHJhbnNmb3JtOiByb3RhdGUoOTBkZWcpO1xuICBcbiAgfVxuICBcbiAgLnNlbGVjdC1jb2xvciB7XG4gICAgY29sb3I6ICAjMDA1MTU3ICFpbXBvcnRhbnQ7XG4gICAgbWFyZ2luOiAwIDEwcHg7XG4gIH1cbiAgLmljb24tYmcge1xuICAgIHdpZHRoOiAzMHB4O1xuICAgIGhlaWdodDogMzBweDtcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5KTtcbiAgICB6LWluZGV4OiAxMDA7XG4gICAgZGlzcGxheTogZ3JpZDtcbiAgICBwbGFjZS1pdGVtczogY2VudGVyO1xuICB9XG4gIC5tYWluLWNvbG9ye1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIH1cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cbi8vIC5zdGFuZGluZy1vcmRlci10b29sYmFye1xuLy8gICAgIC0tYmFja2dyb3VuZDogIzAwNTE1Nztcbi8vIH1cblxuLy8gLnN0YW5kaW5nLXRpdGxle1xuLy8gICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbi8vICAgICBjb2xvcjogd2hpdGU7XG4vLyB9XG4vLyAuc3RhbmRpbmctb3JkZXItaGVpZ2h0LXBhZGRpbmd7XG4vLyAgICAgaGVpZ2h0OiA0MHB4O1xuLy8gICAgIHBhZGRpbmctdG9wOiAxMHB4O1xuLy8gfVxuXG4vLyAud2FsbGV0Q2xhc3N7XG4vLyAgICAgd2lkdGg6IDU1cHg7XG4vLyAgICAgaGVpZ2h0OiAyM3B4O1xuLy8gICAgIGZvbnQtZmFtaWx5OiBBbGlubWFUaGVTYW5zO1xuLy8gICAgIGZvbnQtc2l6ZTogMThweDtcbi8vICAgICBmb250LXdlaWdodDogYm9sZDtcbi8vICAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbi8vICAgICBmb250LXN0eWxlOiBub3JtYWw7XG4vLyAgICAgbGluZS1oZWlnaHQ6IG5vcm1hbDtcbi8vICAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuLy8gICAgIHRleHQtYWxpZ246IHN0YXJ0O1xuLy8gICAgIGNvbG9yOiAjMDA1NDU3O1xuLy8gfVxuXG4vLyBib2R5LmRhcmsgOmhvc3QgLndhbGxldENsYXNze1xuLy8gICAgIGNvbG9yOiB3aGl0ZTtcbi8vIH1cblxuLy8gLnN0YW5kaW5nLW9yZGVyLXctMTAwe1xuLy8gICAgIHdpZHRoOiAxMDAlO1xuLy8gfVxuXG4vLyAuY2FsZW5kYXItYmt7XG4vLyAgICAgYmFja2dyb3VuZDogIzAwNTE1Nztcbi8vICAgICB3aWR0aDogMzVweDtcbi8vICAgICBoZWlnaHQ6IDM1cHg7XG4vLyAgICAgY29sb3I6ICNmZmY7XG4vLyAgICAgZGlzcGxheTogZmxleDtcbi8vICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbi8vICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuLy8gICAgIG1hcmdpbi10b3A6IDVweDtcbi8vIH1cblxuLy8gYm9keS5kYXJrIDpob3N0IC5jYWxlbmRhci1ia3tcbi8vICAgICBiYWNrZ3JvdW5kOiAjNzg3ODc4O1xuLy8gfVxuXG4vLyAuZmlsdGVyLW9yZGVycy1yb3d7XG4vLyAgICAgbWFyZ2luLXRvcDogMjBweDtcbi8vIH1cblxuLy8gLmZpbHRlci1vcmRlcnMtY29sLWljb257XG4vLyAgICAgZGlzcGxheTogZmxleDtcbi8vICAgICBtYXJnaW4tdG9wOiAzM3B4O1xuLy8gfVxuXG4vLyAuaW52ZXN0bWVudC1idG57XG4vLyAgICAgaW9uLWJ1dHRvbiB7XG4vLyAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDA1MTU3O1xuLy8gICAgICAgY29sb3I6ICNlNmVmZjA7XG4vLyAgICAgICBib3JkZXItcmFkaXVzOiAwO1xuLy8gICAgIH1cbi8vIH1cblxuLy8gYm9keS5kYXJrIDpob3N0IC5pbnZlc3RtZW50LWJ0bntcbi8vICAgICBpb24tYnV0dG9uIHtcbi8vICAgICAgIGJhY2tncm91bmQtY29sb3I6ICM3ODc4Nzg7XG4vLyAgICAgICBjb2xvcjogd2hpdGU7XG4vLyAgICAgICBib3JkZXItcmFkaXVzOiAwO1xuLy8gICAgIH1cbi8vIH1cblxuLy8gLmluLWFjdGl2ZS1idG57XG4vLyAgICAgaW9uLWJ1dHRvbiB7XG4vLyAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTZlZmYwO1xuLy8gICAgICAgY29sb3I6ICMwMDUxNTc7XG4vLyAgICAgICBib3JkZXItcmFkaXVzOiAwO1xuLy8gICAgIH1cbi8vIH1cblxuLy8gYm9keS5kYXJrIDpob3N0IC5pbi1hY3RpdmUtYnRue1xuLy8gICAgIGlvbi1idXR0b24ge1xuLy8gICAgICAgYmFja2dyb3VuZC1jb2xvcjogIzRiNGI0Yjtcbi8vICAgICAgIGNvbG9yOiAjYTVhNWE1O1xuLy8gICAgICAgYm9yZGVyLXJhZGl1czogMDtcbi8vICAgICB9XG4vLyB9XG5cbi8vIC8vIGlvbi1zZWdtZW50LWJ1dHRvbiB7XG4vLyAvLyAgICAgbWluLXdpZHRoOiBhdXRvO1xuLy8gLy8gICAgIG1hcmdpbjogMCA0cHg7XG4vLyAvLyAgICAgLS1iYWNrZ3JvdW5kOiAjZTZlZmYwO1xuLy8gLy8gICAgIC0tYmFja2dyb3VuZC1jaGVja2VkOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4vLyAvLyAgICAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbi8vIC8vICAgICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4vLyAvLyAgICAgLS1jb2xvci1jaGVja2VkXHQ6IHdoaXRlO1xuLy8gLy8gICAgIC0tY29sb3ItZm9jdXNlZDogd2hpdGU7XG4vLyAvLyAgICAgLS1jb2xvci1ob3Zlcjogd2hpdGU7XG5cbi8vIC8vICAgICBib2R5LmRhcmsgOmhvc3QgJntcbi8vIC8vICAgICAgICAgLS1iYWNrZ3JvdW5kOiAjNGI0YjRiO1xuLy8gLy8gICAgICAgICAtLWJhY2tncm91bmQtY2hlY2tlZDogIzc4Nzg3ODtcbi8vIC8vICAgICAgICAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6ICM3ODc4Nzg7XG4vLyAvLyAgICAgICAgIC0tY29sb3I6ICNhNWE1YTU7XG4vLyAvLyAgICAgfVxuLy8gLy8gfVxuXG5cbi8vIC5zdGFuZGluZy1vcmRlci1zZWxlY3QtaXRlbXtcbi8vICAgICAvLyBjb2xvcjogIzAwNTQ1Nztcbi8vICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktdHh0KTtcbi8vICAgICBib3JkZXI6IDJweCBzb2xpZCAjOTliOWJjO1xuICAgIFxuLy8gfVxuXG4vLyBpb24taGVhZGVyIHtcbi8vICAgICBpb24tdG9vbGJhciB7XG4vLyAgICAgICAtLWJhY2tncm91bmQ6ICMwMDUxNTc7XG4vLyAgICAgICBjb2xvcjogI2ZmZjtcbi8vICAgICB9XG4vLyAgIH1cblxuICAiXX0= */";

/***/ }),

/***/ 32640:
/*!***********************************************************************************************!*\
  !*** ./src/app/pages/standing-orders/filter-results/filter-results.component.scss?ngResource ***!
  \***********************************************************************************************/
/***/ ((module) => {

module.exports = "/* Dynamically change text color based on a background color */\nion-header ion-toolbar {\n  --background: #005157;\n  color: #fff;\n  --border-width: 0;\n}\nion-content {\n  --background:#F4F8F8;\n}\nion-content ion-card.order-item {\n  box-shadow: none;\n  border: 1px solid #CDDCDD;\n  border-radius: 5px;\n  margin: 16px;\n}\nion-content ion-card.order-item ion-card-header {\n  --color: #005157;\n  padding: 0;\n  border-bottom: 1px solid #CDDCDD;\n  background: #e6eff0;\n  height: 40px;\n}\nion-content ion-card.order-item ion-card-header ion-card-title {\n  --color: #005157;\n  font-size: 13px;\n  line-height: 10px;\n  font-weight: bold;\n  text-align: start;\n  padding: 3px 10px;\n  padding-top: 8px;\n}\nion-content ion-card.order-item ion-card-header .order-type {\n  font-size: 9px;\n  padding: 0 10px;\n  font-weight: bold;\n}\nion-content ion-card.order-item ion-card-header .order-type.buy {\n  color: #2EBD85;\n}\nion-content ion-card.order-item ion-card-header .order-type.sell {\n  color: #F5455A;\n}\nion-content ion-card.order-item ion-card-header .icon-link {\n  display: inline-flex;\n  -webkit-border-start: 1px solid #CDDCDD;\n          border-inline-start: 1px solid #CDDCDD;\n}\nion-content ion-card.order-item ion-card-header .icon-link.delete {\n  color: #F5455A;\n}\nion-content ion-card.order-item ion-card-content {\n  padding: 10px;\n}\nion-content ion-card.order-item ion-card-content .item-value {\n  font-size: 12px;\n}\nion-content ion-card.order-item.order-buy {\n  border-color: #D3EAE6;\n}\nion-content ion-card.order-item.order-buy ion-card-header {\n  background: #E9F8F3;\n  border-bottom: 1px solid #D3EAE6;\n}\nion-content ion-card.order-item.order-buy ion-card-header .order-type {\n  color: #2EBD85;\n}\nion-content ion-card.order-item.order-buy ion-card-header .icon-link {\n  border-color: #D3EAE6;\n}\nion-content ion-card.order-item.order-sell {\n  border-color: #E8DEE1;\n}\nion-content ion-card.order-item.order-sell ion-card-header {\n  background: #FEECEE;\n  border-bottom: 1px solid #E8DEE1;\n}\nion-content ion-card.order-item.order-sell ion-card-header .order-type {\n  color: #F5455A;\n}\nion-content ion-card.order-item.order-sell ion-card-header .icon-link {\n  border-color: #E8DEE1;\n}\nion-content .order-status {\n  padding: 0px 10px;\n  border-radius: 3px;\n  font-size: 10px;\n  -webkit-margin-start: 5px;\n          margin-inline-start: 5px;\n}\nion-content .order-status-filled {\n  background-color: #2ebd85 !important;\n  color: #FFFFFF;\n}\nion-content .order-status-rejected {\n  background-color: #f5455a !important;\n  color: #1e1e1e;\n}\nion-content .order-status-other {\n  background-color: #a5a5a5 !important;\n  color: #1e1e1e;\n}\nion-content .order-status-queued {\n  background-color: #83afb4 !important;\n  color: #1e1e1e;\n}\nion-content .order-status-partially-filled {\n  background-color: #f7d117 !important;\n  color: #1e1e1e;\n}\nion-content .order-status-replaced {\n  background-color: #c0ce00 !important;\n  color: #FFFFFF;\n}\n.criteria-container {\n  background-color: #e6eff0;\n  margin-top: 10px;\n  margin-left: 10px;\n  margin-right: 10px;\n  height: auto;\n}\nbody.dark :host .criteria-container {\n  background-color: grey;\n}\n.textClass {\n  width: 55px;\n  height: 23px;\n  font-family: AlinmaTheSans;\n  font-size: 16px;\n  font-weight: bold;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: normal;\n  letter-spacing: normal;\n  text-align: right;\n  color: #005457;\n  -webkit-padding-start: 3px;\n          padding-inline-start: 3px;\n}\nbody.dark :host .textClass {\n  color: white;\n}\n.valueClass {\n  width: 55px;\n  height: 23px;\n  font-family: AlinmaTheSans;\n  font-size: 13px;\n  padding: 5px;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: normal;\n  letter-spacing: normal;\n  text-align: right;\n  color: #005457;\n}\nbody.dark :host .valueClass {\n  color: white;\n}\n.card-height {\n  height: 500px;\n  overflow-y: scroll;\n  padding: 0px 0;\n}\n.standing-order-header {\n  padding: 5px 0;\n}\n.standing-order-toolbar {\n  --background: #005157;\n  text-align: center;\n  color: white;\n}\nion-header ion-toolbar {\n  --background: #005157;\n  color: #fff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbHRlci1yZXN1bHRzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQVVBLDhEQUFBO0FBVUk7RUFDRSxxQkFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtBQWxCTjtBQXNCQTtFQUNJLG9CQUFBO0FBbkJKO0FBcUJJO0VBQ0ksZ0JBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtBQW5CUjtBQXFCUTtFQUNJLGdCQUFBO0VBQ0EsVUFBQTtFQUNBLGdDQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0FBbkJaO0FBcUJZO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQW5CaEI7QUFzQlk7RUFDSSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FBcEJoQjtBQXNCZ0I7RUFDSSxjQUFBO0FBcEJwQjtBQXNCZ0I7RUFDSSxjQUFBO0FBcEJwQjtBQXdCWTtFQUNJLG9CQUFBO0VBQ0EsdUNBQUE7VUFBQSxzQ0FBQTtBQXRCaEI7QUF3QmdCO0VBQ0ksY0FBQTtBQXRCcEI7QUEyQlE7RUFDSSxhQUFBO0FBekJaO0FBMkJZO0VBQ0ksZUFBQTtBQXpCaEI7QUErQlE7RUFDSSxxQkFBQTtBQTdCWjtBQStCWTtFQUNJLG1CQUFBO0VBQ0EsZ0NBQUE7QUE3QmhCO0FBK0JnQjtFQUNJLGNBQUE7QUE3QnBCO0FBZ0NnQjtFQUNJLHFCQUFBO0FBOUJwQjtBQW1DUTtFQUNJLHFCQUFBO0FBakNaO0FBbUNZO0VBQ0ksbUJBQUE7RUFDQSxnQ0FBQTtBQWpDaEI7QUFtQ2dCO0VBQ0ksY0FBQTtBQWpDcEI7QUFvQ2dCO0VBQ0kscUJBQUE7QUFsQ3BCO0FBd0NJO0VBQ0ksaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSx5QkFBQTtVQUFBLHdCQUFBO0FBdENSO0FBeUNZO0VBQ0ksb0NBQUE7RUFDQSxjQUFBO0FBdkNoQjtBQXFDWTtFQUNJLG9DQUFBO0VBQ0EsY0FBQTtBQW5DaEI7QUFpQ1k7RUFDSSxvQ0FBQTtFQUNBLGNBQUE7QUEvQmhCO0FBNkJZO0VBQ0ksb0NBQUE7RUFDQSxjQUFBO0FBM0JoQjtBQXlCWTtFQUNJLG9DQUFBO0VBQ0EsY0FBQTtBQXZCaEI7QUFxQlk7RUFDSSxvQ0FBQTtFQUNBLGNBQUE7QUFuQmhCO0FBcUNBO0VBQ0kseUJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FBbENKO0FBcUNBO0VBQ0ksc0JBQUE7QUFsQ0o7QUFxQ0E7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLDBCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0Esc0JBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSwwQkFBQTtVQUFBLHlCQUFBO0FBbENKO0FBcUNBO0VBQ0ksWUFBQTtBQWxDSjtBQXNDQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsMEJBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0FBbkNKO0FBc0NBO0VBQ0ksWUFBQTtBQW5DSjtBQXVDQTtFQUNJLGFBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7QUFwQ0o7QUF1Q0E7RUFDSSxjQUFBO0FBcENKO0FBdUNBO0VBQ0kscUJBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7QUFwQ0o7QUF3Q0k7RUFDRSxxQkFBQTtFQUNBLFdBQUE7QUFyQ04iLCJmaWxlIjoiZmlsdGVyLXJlc3VsdHMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIkc3RhdHVzLWNvbG9yczogKFxuICAgIGZpbGxlZDogIzJlYmQ4NSxcbiAgICByZWplY3RlZDogI2Y1NDU1YSxcbiAgICBvdGhlcjogI2E1YTVhNSxcbiAgICBxdWV1ZWQ6ICM4M2FmYjQsXG4gICAgcGFydGlhbGx5LWZpbGxlZDogI2Y3ZDExNyxcbiAgICByZXBsYWNlZDogI2MwY2UwMCxcbiAgICAvLyBmaWctcHVycGxlOiAjOGQ0MTg5XG4pO1xuXG4vKiBEeW5hbWljYWxseSBjaGFuZ2UgdGV4dCBjb2xvciBiYXNlZCBvbiBhIGJhY2tncm91bmQgY29sb3IgKi9cbkBmdW5jdGlvbiBzZXRUZXh0Q29sb3IoJGNvbG9yKSB7XG4gICAgQGlmIChsaWdodG5lc3MoJGNvbG9yKSA+IDUwKSB7XG4gICAgICBAcmV0dXJuICMxZTFlMWU7IC8vIExpZ2h0ZXIgYmFja2dvcnVuZCwgcmV0dXJuIGRhcmsgY29sb3JcbiAgICB9IEBlbHNlIHtcbiAgICAgIEByZXR1cm4gI0ZGRkZGRjsgLy8gRGFya2VyIGJhY2tncm91bmQsIHJldHVybiBsaWdodCBjb2xvclxuICAgIH1cbn1cblxuaW9uLWhlYWRlciB7XG4gICAgaW9uLXRvb2xiYXIge1xuICAgICAgLS1iYWNrZ3JvdW5kOiAjMDA1MTU3O1xuICAgICAgY29sb3I6ICNmZmY7XG4gICAgICAtLWJvcmRlci13aWR0aDogMDtcbiAgICB9XG59XG5cbmlvbi1jb250ZW50IHtcbiAgICAtLWJhY2tncm91bmQ6I0Y0RjhGODtcblxuICAgIGlvbi1jYXJkLm9yZGVyLWl0ZW0ge1xuICAgICAgICBib3gtc2hhZG93OiBub25lO1xuICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjQ0REQ0REO1xuICAgICAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgICAgIG1hcmdpbjogMTZweDtcblxuICAgICAgICBpb24tY2FyZC1oZWFkZXIge1xuICAgICAgICAgICAgLS1jb2xvcjogIzAwNTE1NztcbiAgICAgICAgICAgIHBhZGRpbmc6IDA7XG4gICAgICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI0NERENERDtcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICNlNmVmZjA7XG4gICAgICAgICAgICBoZWlnaHQ6IDQwcHg7XG5cbiAgICAgICAgICAgIGlvbi1jYXJkLXRpdGxlIHtcbiAgICAgICAgICAgICAgICAtLWNvbG9yOiAjMDA1MTU3O1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICAgICAgICAgICAgICBsaW5lLWhlaWdodDogMTBweDtcbiAgICAgICAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBzdGFydDtcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAzcHggMTBweDtcbiAgICAgICAgICAgICAgICBwYWRkaW5nLXRvcDogOHB4O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAub3JkZXItdHlwZSB7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiA5cHg7XG4gICAgICAgICAgICAgICAgcGFkZGluZzogMCAxMHB4O1xuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuXG4gICAgICAgICAgICAgICAgJi5idXkge1xuICAgICAgICAgICAgICAgICAgICBjb2xvcjogIzJFQkQ4NTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgJi5zZWxsIHtcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICNGNTQ1NUE7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgXG4gICAgICAgICAgICAuaWNvbi1saW5rIHtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcbiAgICAgICAgICAgICAgICBib3JkZXItaW5saW5lLXN0YXJ0OiAxcHggc29saWQgI0NERENERDtcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAmLmRlbGV0ZSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjRjU0NTVBO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGlvbi1jYXJkLWNvbnRlbnQge1xuICAgICAgICAgICAgcGFkZGluZzogMTBweDtcblxuICAgICAgICAgICAgLml0ZW0tdmFsdWUge1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG5cblxuICAgICAgICAmLm9yZGVyLWJ1eSB7XG4gICAgICAgICAgICBib3JkZXItY29sb3I6ICNEM0VBRTY7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIGlvbi1jYXJkLWhlYWRlciB7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI0U5RjhGMztcbiAgICAgICAgICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI0QzRUFFNjtcblxuICAgICAgICAgICAgICAgIC5vcmRlci10eXBlIHtcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICMyRUJEODVcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAuaWNvbi1saW5rIHtcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyLWNvbG9yOiAjRDNFQUU2O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgICYub3JkZXItc2VsbCB7XG4gICAgICAgICAgICBib3JkZXItY29sb3I6ICNFOERFRTE7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIGlvbi1jYXJkLWhlYWRlciB7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI0ZFRUNFRTtcbiAgICAgICAgICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI0U4REVFMTtcblxuICAgICAgICAgICAgICAgIC5vcmRlci10eXBlIHtcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICNGNTQ1NUE7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgLmljb24tbGluayB7XG4gICAgICAgICAgICAgICAgICAgIGJvcmRlci1jb2xvcjogI0U4REVFMTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAub3JkZXItc3RhdHVzIHtcbiAgICAgICAgcGFkZGluZzogMHB4IDEwcHg7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDNweDtcbiAgICAgICAgZm9udC1zaXplOiAxMHB4O1xuICAgICAgICBtYXJnaW4taW5saW5lLXN0YXJ0OiA1cHg7XG5cbiAgICAgICAgQGVhY2ggJGNvbG9yLWtleSwgJGNvbG9yLXZhbHVlIGluICRzdGF0dXMtY29sb3JzIHtcbiAgICAgICAgICAgICYtI3skY29sb3Ita2V5fSB7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogJGNvbG9yLXZhbHVlICFpbXBvcnRhbnQ7XG4gICAgICAgICAgICAgICAgY29sb3I6IHNldFRleHRDb2xvcigkY29sb3ItdmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG4uY3JpdGVyaWEtY29udGFpbmVye1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNlNmVmZjA7XG4gICAgbWFyZ2luLXRvcDogMTBweDtcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgaGVpZ2h0OiBhdXRvO1xufVxuXG5ib2R5LmRhcmsgOmhvc3QgLmNyaXRlcmlhLWNvbnRhaW5lcntcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBncmV5O1xufVxuXG4udGV4dENsYXNze1xuICAgIHdpZHRoOiA1NXB4O1xuICAgIGhlaWdodDogMjNweDtcbiAgICBmb250LWZhbWlseTogQWxpbm1hVGhlU2FucztcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiBub3JtYWw7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgICBjb2xvcjogIzAwNTQ1NztcbiAgICBwYWRkaW5nLWlubGluZS1zdGFydDogM3B4O1xufVxuXG5ib2R5LmRhcmsgOmhvc3QgLnRleHRDbGFzc3tcbiAgICBjb2xvcjogd2hpdGU7XG59XG5cblxuLnZhbHVlQ2xhc3N7XG4gICAgd2lkdGg6IDU1cHg7XG4gICAgaGVpZ2h0OiAyM3B4O1xuICAgIGZvbnQtZmFtaWx5OiBBbGlubWFUaGVTYW5zO1xuICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICBwYWRkaW5nOiA1cHg7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiBub3JtYWw7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgICBjb2xvcjogIzAwNTQ1NztcbiAgLy8gIHdoaXRlLXNwYWNlOiB1bnNldCAhaW1wb3J0YW50O1xufVxuYm9keS5kYXJrIDpob3N0IC52YWx1ZUNsYXNze1xuICAgIGNvbG9yOiB3aGl0ZTtcbn1cblxuXG4uY2FyZC1oZWlnaHR7XG4gICAgaGVpZ2h0OiA1MDBweDtcbiAgICBvdmVyZmxvdy15OiBzY3JvbGw7XG4gICAgcGFkZGluZzogMHB4IDA7XG59XG5cbi5zdGFuZGluZy1vcmRlci1oZWFkZXJ7XG4gICAgcGFkZGluZzogNXB4IDA7XG59XG5cbi5zdGFuZGluZy1vcmRlci10b29sYmFye1xuICAgIC0tYmFja2dyb3VuZDogIzAwNTE1NztcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6IHdoaXRlO1xufVxuXG5pb24taGVhZGVyIHtcbiAgICBpb24tdG9vbGJhciB7XG4gICAgICAtLWJhY2tncm91bmQ6ICMwMDUxNTc7XG4gICAgICBjb2xvcjogI2ZmZjtcbiAgICB9XG4gIH0iXX0= */";

/***/ }),

/***/ 56149:
/*!*************************************************************************************************!*\
  !*** ./src/app/pages/standing-orders/order-of-orders/order-of-orders.component.scss?ngResource ***!
  \*************************************************************************************************/
/***/ ((module) => {

module.exports = ".standing-order-height-padding {\n  height: 40px;\n  padding-top: 10px;\n}\n\n.walletClass {\n  width: 55px;\n  height: 23px;\n  font-size: 20px;\n  font-weight: bold;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: normal;\n  letter-spacing: normal;\n  text-align: right;\n  color: #005457;\n}\n\nbody.dark :host .walletClass {\n  color: white;\n}\n\n.standing-order-w-100 {\n  width: 100%;\n}\n\nbody.dark :host ion-item {\n  border-bottom: 1px solid lightgrey;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9yZGVyLW9mLW9yZGVycy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFRQTtFQUNJLFlBQUE7RUFDQSxpQkFBQTtBQVBKOztBQVVBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFFQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQVJKOztBQVNJO0VBQ0ksWUFBQTtBQVBSOztBQVdBO0VBQ0ksV0FBQTtBQVJKOztBQVlJO0VBQ0ksa0NBQUE7QUFUUiIsImZpbGUiOiJvcmRlci1vZi1vcmRlcnMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvLyAuc3RhbmRpbmctb3JkZXItdG9vbGJhcntcbi8vICAgICAtLWJhY2tncm91bmQ6ICMwMDUxNTc7XG4vLyB9XG5cbi8vIC5zdGFuZGluZy10aXRsZXtcbi8vICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4vLyAgICAgY29sb3I6IHdoaXRlO1xuLy8gfVxuLnN0YW5kaW5nLW9yZGVyLWhlaWdodC1wYWRkaW5ne1xuICAgIGhlaWdodDogNDBweDtcbiAgICBwYWRkaW5nLXRvcDogMTBweDtcbn1cblxuLndhbGxldENsYXNze1xuICAgIHdpZHRoOiA1NXB4O1xuICAgIGhlaWdodDogMjNweDtcbiAgICAvL2ZvbnQtZmFtaWx5OiBBbGlubWFUaGVTYW5zO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IG5vcm1hbDtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IHJpZ2h0O1xuICAgIGNvbG9yOiAjMDA1NDU3O1xuICAgIGJvZHkuZGFyayA6aG9zdCAmIHtcbiAgICAgICAgY29sb3I6IHdoaXRlO1xuICAgIH1cbn1cblxuLnN0YW5kaW5nLW9yZGVyLXctMTAwe1xuICAgIHdpZHRoOiAxMDAlO1xufVxuXG5pb24taXRlbSB7XG4gICAgYm9keS5kYXJrIDpob3N0ICZ7XG4gICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBsaWdodGdyZXk7XG4gICAgfVxufVxuXG5cbiJdfQ== */";

/***/ }),

/***/ 92204:
/*!****************************************************************************!*\
  !*** ./src/app/pages/standing-orders/standing-orders.page.scss?ngResource ***!
  \****************************************************************************/
/***/ ((module) => {

module.exports = "/* Dynamically change text color based on a background color */\n:host {\n  background: #F4F8F8;\n}\nion-header ion-toolbar {\n  --background: #005157;\n  color: #fff;\n  --border-width: 0;\n}\nion-header .sub-header-top {\n  padding: 5px 16px;\n}\nion-header .sub-header-top .item-label {\n  color: #CDDCDD;\n  line-height: 11px;\n}\nion-header .sub-header-top ion-select {\n  border: 0;\n  padding: 0;\n  font-weight: bold;\n  font-size: 18px;\n}\nion-header .sub-header-top ion-select .select-icon {\n  font-family: \"tadawul-icon-font\";\n  content: \"\\e91f\";\n}\nion-header .sub-header-top ion-select .select-icon-inner {\n  visibility: hidden;\n}\nion-header .sub-header-top .cancel-orders {\n  --background: #BB4A5B;\n  --background-activated: #F5455A;\n  --border-width: 1px;\n  --border-style: solid;\n  --border-color: #F5455A;\n  --border-radius: 4px;\n}\nion-header .sub-header-top .cancel-orders [class*=icon-] {\n  -webkit-margin-end: 5px;\n          margin-inline-end: 5px;\n}\nion-header .sub-header-bottom {\n  border-bottom: 1px solid #E6EFF0;\n  background: #FFFFFF;\n  color: #005157;\n}\nion-header .sub-header-bottom ion-searchbar {\n  --border-radius: 0;\n  padding: 0;\n  height: 40px;\n  --placeholder-color: #CDDCDD;\n  --placeholder-opacity: 1;\n}\nion-header .sub-header-bottom ion-searchbar .searchbar-input-container {\n  height: 100%;\n}\nion-header .sub-header-bottom .icon-link {\n  color: #005157;\n  -webkit-border-start: 1px solid #E6EFF0;\n          border-inline-start: 1px solid #E6EFF0;\n}\nion-header .sub-header .select-picker-placeholder {\n  align-items: center;\n  display: flex;\n  justify-content: space-between;\n}\nion-header .sub-header .picker-select-icon {\n  transform: rotate(90deg);\n}\nion-header .sub-header .select-color {\n  color: #FFFFFF !important;\n  font-weight: bold;\n  font-size: 18px;\n}\nion-content {\n  --background:#F4F8F8;\n}\nion-content ion-card.order-item {\n  box-shadow: none;\n  border: 1px solid #CDDCDD;\n  border-radius: 5px;\n  margin: 16px;\n}\nion-content ion-card.order-item ion-card-header {\n  --color: #005157;\n  padding: 0;\n  border-bottom: 1px solid #CDDCDD;\n  background: #e6eff0;\n  height: 40px;\n}\nion-content ion-card.order-item ion-card-header ion-card-title {\n  --color: #005157;\n  font-size: 13px;\n  line-height: 10px;\n  font-weight: bold;\n  text-align: start;\n  padding: 3px 10px;\n  padding-top: 8px;\n}\nion-content ion-card.order-item ion-card-header .order-type {\n  font-size: 9px;\n  padding: 0 10px;\n  font-weight: bold;\n}\nion-content ion-card.order-item ion-card-header .order-type.buy {\n  color: #2EBD85;\n}\nion-content ion-card.order-item ion-card-header .order-type.sell {\n  color: #F5455A;\n}\nion-content ion-card.order-item ion-card-header .icon-link {\n  display: inline-flex;\n  -webkit-border-start: 1px solid #CDDCDD;\n          border-inline-start: 1px solid #CDDCDD;\n}\nion-content ion-card.order-item ion-card-header .icon-link.delete {\n  color: #F5455A;\n}\nion-content ion-card.order-item ion-card-content {\n  padding: 10px;\n}\nion-content ion-card.order-item ion-card-content .item-value {\n  font-size: 12px;\n}\nion-content ion-card.order-item.order-buy {\n  border-color: #D3EAE6;\n}\nion-content ion-card.order-item.order-buy ion-card-header {\n  background: #E9F8F3;\n  border-bottom: 1px solid #D3EAE6;\n}\nion-content ion-card.order-item.order-buy ion-card-header .order-type {\n  color: #2EBD85;\n}\nion-content ion-card.order-item.order-buy ion-card-header .icon-link {\n  border-color: #D3EAE6;\n}\nion-content ion-card.order-item.order-sell {\n  border-color: #E8DEE1;\n}\nion-content ion-card.order-item.order-sell ion-card-header {\n  background: #FEECEE;\n  border-bottom: 1px solid #E8DEE1;\n}\nion-content ion-card.order-item.order-sell ion-card-header .order-type {\n  color: #F5455A;\n}\nion-content ion-card.order-item.order-sell ion-card-header .icon-link {\n  border-color: #E8DEE1;\n}\nion-content .order-status {\n  padding: 0px 10px;\n  border-radius: 3px;\n  font-size: 10px;\n  -webkit-margin-start: 5px;\n          margin-inline-start: 5px;\n}\nion-content .order-status-filled {\n  background-color: #2ebd85 !important;\n  color: #FFFFFF;\n}\nion-content .order-status-rejected {\n  background-color: #f5455a !important;\n  color: #1e1e1e;\n}\nion-content .order-status-other {\n  background-color: #a5a5a5 !important;\n  color: #1e1e1e;\n}\nion-content .order-status-queued {\n  background-color: #83afb4 !important;\n  color: #1e1e1e;\n}\nion-content .order-status-partially-filled {\n  background-color: #f7d117 !important;\n  color: #1e1e1e;\n}\nion-content .order-status-replaced {\n  background-color: #c0ce00 !important;\n  color: #FFFFFF;\n}\nion-refresher {\n  background: #F4F8F8;\n  --color:#005157;\n  --ion-text-color:#005157;\n}\n.walletClass {\n  width: 55px;\n  height: 23px;\n  font-family: AlinmaTheSans;\n  font-size: 20px;\n  font-weight: bold;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: normal;\n  letter-spacing: normal;\n  text-align: right;\n  color: var(--ion-color-primary-txt);\n}\n.standing-orders-search {\n  color: white;\n  height: 45px;\n  border: 2px solid #99b9bc;\n}\n.standing-orders-search ion-input {\n  color: #65979a;\n}\n.standing-order-toolbar {\n  --background: #005157;\n}\n.standing-order-select-item {\n  color: var(--ion-color-primary-txt);\n  border: 2px solid #99b9bc;\n}\n.standing-order-paddiing-top-20px {\n  padding-top: 20px;\n}\n.standing-order-height-padding {\n  height: 40px;\n  padding-top: 10px;\n}\n.standing-order-w-100 {\n  width: 100%;\n}\n.standing-orders-search {\n  position: relative;\n}\n.standing-orders-filter-display {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  padding: 9px 0;\n  text-transform: capitalize;\n  background-color: #005157;\n  color: white;\n  margin-top: 5px;\n  margin-bottom: 5px;\n}\n.standing-orders-filter-display .standing-orders-filter-display-icons {\n  margin-top: 3px;\n}\n.standing-orders-filter-display .standing-order-filter-display-title {\n  margin: 0 4px;\n}\n.standing-orders-delete-display {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  padding: 9px 0;\n  text-transform: capitalize;\n  background-color: #f5455a;\n  color: white;\n  margin-top: 5px;\n  margin-bottom: 5px;\n}\n.standing-orders-delete-display .standing-orders-filter-display-icons {\n  margin-top: 3px;\n}\n.standing-orders-delete-display .standing-order-filter-display-title {\n  margin: 0 4px;\n}\n.standing-orders-wallet-select ion-select {\n  padding: 11px;\n}\n.search-icon {\n  display: flex;\n  align-items: center;\n}\n.search-icon ion-icon {\n  color: #fff;\n}\nion-searchbar {\n  height: 40px !important;\n}\n.card-height {\n  height: 354px;\n  overflow-y: scroll;\n  padding: 0px 0;\n}\n.standing-order-header {\n  padding: 5px 0;\n}\n.standing-title {\n  text-align: center;\n  color: white;\n}\n.standing-order-grid-bk {\n  background-color: #005157;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN0YW5kaW5nLW9yZGVycy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBVUEsOERBQUE7QUFTQTtFQUNJLG1CQUFBO0FBakJKO0FBcUJJO0VBQ0UscUJBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7QUFsQk47QUE2QlE7RUFDSSxpQkFBQTtBQTNCWjtBQTZCWTtFQUNJLGNBQUE7RUFDQSxpQkFBQTtBQTNCaEI7QUE4Qlk7RUFDSSxTQUFBO0VBQ0EsVUFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtBQTVCaEI7QUE4QmdCO0VBQ0ksZ0NBQUE7RUFDQSxnQkFBQTtBQTVCcEI7QUErQmdCO0VBQ0ksa0JBQUE7QUE3QnBCO0FBa0NZO0VBQ0kscUJBQUE7RUFDQSwrQkFBQTtFQUNBLG1CQUFBO0VBQ0EscUJBQUE7RUFDQSx1QkFBQTtFQUNBLG9CQUFBO0FBaENoQjtBQWtDZ0I7RUFDSSx1QkFBQTtVQUFBLHNCQUFBO0FBaENwQjtBQXNDUTtFQUNJLGdDQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0FBcENaO0FBc0NZO0VBQ0ksa0JBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLDRCQUFBO0VBQ0Esd0JBQUE7QUFwQ2hCO0FBc0NnQjtFQUNJLFlBQUE7QUFwQ3BCO0FBOENZO0VBQ0ksY0FBQTtFQUNBLHVDQUFBO1VBQUEsc0NBQUE7QUE1Q2hCO0FBaURRO0VBQ0ksbUJBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7QUEvQ1o7QUFrRFE7RUFDSSx3QkFBQTtBQWhEWjtBQW1EUTtFQUNJLHlCQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0FBakRaO0FBc0RBO0VBQ0ksb0JBQUE7QUFuREo7QUFxREk7RUFDSSxnQkFBQTtFQUNBLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FBbkRSO0FBcURRO0VBQ0ksZ0JBQUE7RUFDQSxVQUFBO0VBQ0EsZ0NBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7QUFuRFo7QUFxRFk7RUFDSSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0FBbkRoQjtBQXNEWTtFQUNJLGNBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUFwRGhCO0FBc0RnQjtFQUNJLGNBQUE7QUFwRHBCO0FBc0RnQjtFQUNJLGNBQUE7QUFwRHBCO0FBd0RZO0VBQ0ksb0JBQUE7RUFDQSx1Q0FBQTtVQUFBLHNDQUFBO0FBdERoQjtBQXdEZ0I7RUFDSSxjQUFBO0FBdERwQjtBQTJEUTtFQUNJLGFBQUE7QUF6RFo7QUEyRFk7RUFDSSxlQUFBO0FBekRoQjtBQStEUTtFQUNJLHFCQUFBO0FBN0RaO0FBK0RZO0VBQ0ksbUJBQUE7RUFDQSxnQ0FBQTtBQTdEaEI7QUErRGdCO0VBQ0ksY0FBQTtBQTdEcEI7QUFnRWdCO0VBQ0kscUJBQUE7QUE5RHBCO0FBbUVRO0VBQ0kscUJBQUE7QUFqRVo7QUFtRVk7RUFDSSxtQkFBQTtFQUNBLGdDQUFBO0FBakVoQjtBQW1FZ0I7RUFDSSxjQUFBO0FBakVwQjtBQW9FZ0I7RUFDSSxxQkFBQTtBQWxFcEI7QUF3RUk7RUFDSSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLHlCQUFBO1VBQUEsd0JBQUE7QUF0RVI7QUF5RVk7RUFDSSxvQ0FBQTtFQUNBLGNBQUE7QUF2RWhCO0FBcUVZO0VBQ0ksb0NBQUE7RUFDQSxjQUFBO0FBbkVoQjtBQWlFWTtFQUNJLG9DQUFBO0VBQ0EsY0FBQTtBQS9EaEI7QUE2RFk7RUFDSSxvQ0FBQTtFQUNBLGNBQUE7QUEzRGhCO0FBeURZO0VBQ0ksb0NBQUE7RUFDQSxjQUFBO0FBdkRoQjtBQXFEWTtFQUNJLG9DQUFBO0VBQ0EsY0FBQTtBQW5EaEI7QUE0RUE7RUFDSSxtQkFBQTtFQUNBLGVBQUE7RUFDQSx3QkFBQTtBQXpFSjtBQThFQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsMEJBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLGlCQUFBO0VBRUEsbUNBQUE7QUE1RUo7QUErRUE7RUFDSSxZQUFBO0VBRUEsWUFBQTtFQUNBLHlCQUFBO0FBN0VKO0FBOEVJO0VBRUksY0FBQTtBQTdFUjtBQWlGQTtFQUNJLHFCQUFBO0FBOUVKO0FBaUZBO0VBRUksbUNBQUE7RUFDQSx5QkFBQTtBQS9FSjtBQW1GQTtFQUNJLGlCQUFBO0FBaEZKO0FBbUZBO0VBQ0ksWUFBQTtFQUNBLGlCQUFBO0FBaEZKO0FBbUZBO0VBQ0ksV0FBQTtBQWhGSjtBQW1GQTtFQUNJLGtCQUFBO0FBaEZKO0FBNEZBO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxjQUFBO0VBQ0EsMEJBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUF6Rko7QUEwRkk7RUFDSSxlQUFBO0FBeEZSO0FBMEZJO0VBQ0ksYUFBQTtBQXhGUjtBQTRGQTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsY0FBQTtFQUNBLDBCQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FBekZKO0FBMEZJO0VBQ0ksZUFBQTtBQXhGUjtBQTBGSTtFQUNJLGFBQUE7QUF4RlI7QUE2Rkk7RUFDSSxhQUFBO0FBMUZSO0FBOEZBO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0FBM0ZKO0FBNEZJO0VBQ0ksV0FBQTtBQTFGUjtBQTZGQTtFQUVJLHVCQUFBO0FBM0ZKO0FBOEZBO0VBQ0ksYUFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtBQTNGSjtBQThGQTtFQUNJLGNBQUE7QUEzRko7QUE4RkE7RUFDSSxrQkFBQTtFQUNBLFlBQUE7QUEzRko7QUE4RkE7RUFDSSx5QkFBQTtBQTNGSiIsImZpbGUiOiJzdGFuZGluZy1vcmRlcnMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiJHN0YXR1cy1jb2xvcnM6IChcbiAgICBmaWxsZWQ6ICMyZWJkODUsXG4gICAgcmVqZWN0ZWQ6ICNmNTQ1NWEsXG4gICAgb3RoZXI6ICNhNWE1YTUsXG4gICAgcXVldWVkOiAjODNhZmI0LFxuICAgIHBhcnRpYWxseS1maWxsZWQ6ICNmN2QxMTcsXG4gICAgcmVwbGFjZWQ6ICNjMGNlMDAsXG4gICAgLy8gZmlnLXB1cnBsZTogIzhkNDE4OVxuKTtcblxuLyogRHluYW1pY2FsbHkgY2hhbmdlIHRleHQgY29sb3IgYmFzZWQgb24gYSBiYWNrZ3JvdW5kIGNvbG9yICovXG5AZnVuY3Rpb24gc2V0VGV4dENvbG9yKCRjb2xvcikge1xuICAgIEBpZiAobGlnaHRuZXNzKCRjb2xvcikgPiA1MCkge1xuICAgICAgQHJldHVybiAjMWUxZTFlOyAvLyBMaWdodGVyIGJhY2tnb3J1bmQsIHJldHVybiBkYXJrIGNvbG9yXG4gICAgfSBAZWxzZSB7XG4gICAgICBAcmV0dXJuICNGRkZGRkY7IC8vIERhcmtlciBiYWNrZ3JvdW5kLCByZXR1cm4gbGlnaHQgY29sb3JcbiAgICB9XG59XG5cbjpob3N0IHtcbiAgICBiYWNrZ3JvdW5kOiAjRjRGOEY4O1xufVxuXG5pb24taGVhZGVyIHtcbiAgICBpb24tdG9vbGJhciB7XG4gICAgICAtLWJhY2tncm91bmQ6ICMwMDUxNTc7XG4gICAgICBjb2xvcjogI2ZmZjtcbiAgICAgIC0tYm9yZGVyLXdpZHRoOiAwO1xuICAgIH1cblxuICAgIC5zdWItaGVhZGVyIHtcbiAgICAgICAgLy8gYmFja2dyb3VuZDogIzBFNUE2MTtcbiAgICAgICAgLy8gY29sb3I6ICNGRkZGRkY7XG4gICAgICAgIC8vIGJvcmRlci10b3A6IDFweCBzb2xpZCAjMjI2NjZkO1xuICAgICAgICBcbiAgICAgICAgLy8gcG9zaXRpb246IHN0aWNreTtcbiAgICAgICAgLy8gdG9wOiAwO1xuXG4gICAgICAgICYtdG9wIHtcbiAgICAgICAgICAgIHBhZGRpbmc6IDVweCAxNnB4O1xuXG4gICAgICAgICAgICAuaXRlbS1sYWJlbCB7XG4gICAgICAgICAgICAgICAgY29sb3I6ICNDRERDREQ7XG4gICAgICAgICAgICAgICAgbGluZS1oZWlnaHQ6IDExcHg7XG4gICAgICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICAgICAgaW9uLXNlbGVjdCB7XG4gICAgICAgICAgICAgICAgYm9yZGVyOiAwO1xuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDA7XG4gICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxOHB4O1xuICAgICAgICBcbiAgICAgICAgICAgICAgICAuc2VsZWN0LWljb24ge1xuICAgICAgICAgICAgICAgICAgICBmb250LWZhbWlseTogJ3RhZGF3dWwtaWNvbi1mb250JztcbiAgICAgICAgICAgICAgICAgICAgY29udGVudDogJ1xcZTkxZic7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLnNlbGVjdC1pY29uLWlubmVyIHtcbiAgICAgICAgICAgICAgICAgICAgdmlzaWJpbGl0eTpoaWRkZW47XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgICAgIH1cbiAgICAgICAgXG4gICAgICAgICAgICAuY2FuY2VsLW9yZGVycyB7XG4gICAgICAgICAgICAgICAgLS1iYWNrZ3JvdW5kOiAjQkI0QTVCO1xuICAgICAgICAgICAgICAgIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6ICNGNTQ1NUE7XG4gICAgICAgICAgICAgICAgLS1ib3JkZXItd2lkdGg6IDFweDtcbiAgICAgICAgICAgICAgICAtLWJvcmRlci1zdHlsZTogc29saWQ7XG4gICAgICAgICAgICAgICAgLS1ib3JkZXItY29sb3I6ICNGNTQ1NUE7XG4gICAgICAgICAgICAgICAgLS1ib3JkZXItcmFkaXVzOiA0cHg7XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgW2NsYXNzKj1cImljb24tXCJdIHtcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWlubGluZS1lbmQ6IDVweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgXG5cbiAgICAgICAgJi1ib3R0b20ge1xuICAgICAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNFNkVGRjA7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAjRkZGRkZGO1xuICAgICAgICAgICAgY29sb3I6ICMwMDUxNTc7XG5cbiAgICAgICAgICAgIGlvbi1zZWFyY2hiYXIge1xuICAgICAgICAgICAgICAgIC0tYm9yZGVyLXJhZGl1czogMDtcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAwO1xuICAgICAgICAgICAgICAgIGhlaWdodDogNDBweDtcbiAgICAgICAgICAgICAgICAtLXBsYWNlaG9sZGVyLWNvbG9yOiAjQ0REQ0REO1xuICAgICAgICAgICAgICAgIC0tcGxhY2Vob2xkZXItb3BhY2l0eTogMTtcbiAgICAgICAgXG4gICAgICAgICAgICAgICAgLnNlYXJjaGJhci1pbnB1dC1jb250YWluZXIge1xuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDEwMCU7XG4gICAgICAgICAgICAgICAgfVxuXG5cbiAgICAgICAgICAgICAgICAvLyAuc2VhcmNoYmFyLXNlYXJjaC1pY29uLFxuICAgICAgICAgICAgICAgIC8vIC5zZWFyY2hiYXItY2xlYXItaWNvbiB7XG4gICAgICAgICAgICAgICAgLy8gICAgIGNvbG9yOiNDRERDREQgIWltcG9ydGFudDtcbiAgICAgICAgICAgICAgICAvLyB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC5pY29uLWxpbmsge1xuICAgICAgICAgICAgICAgIGNvbG9yOiAjMDA1MTU3O1xuICAgICAgICAgICAgICAgIGJvcmRlci1pbmxpbmUtc3RhcnQ6IDFweCBzb2xpZCAjRTZFRkYwO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gUGlja2VyIHN0eWxlIFxuICAgICAgICAuc2VsZWN0LXBpY2tlci1wbGFjZWhvbGRlciB7XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgLnBpY2tlci1zZWxlY3QtaWNvbiB7XG4gICAgICAgICAgICB0cmFuc2Zvcm06IHJvdGF0ZSg5MGRlZyk7XG4gICAgICAgIH1cbiAgICAgICAgXG4gICAgICAgIC5zZWxlY3QtY29sb3Ige1xuICAgICAgICAgICAgY29sb3I6ICAjRkZGRkZGICFpbXBvcnRhbnQ7XG4gICAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuaW9uLWNvbnRlbnQge1xuICAgIC0tYmFja2dyb3VuZDojRjRGOEY4O1xuXG4gICAgaW9uLWNhcmQub3JkZXItaXRlbSB7XG4gICAgICAgIGJveC1zaGFkb3c6IG5vbmU7XG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNDRERDREQ7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICAgICAgbWFyZ2luOiAxNnB4O1xuXG4gICAgICAgIGlvbi1jYXJkLWhlYWRlciB7XG4gICAgICAgICAgICAtLWNvbG9yOiAjMDA1MTU3O1xuICAgICAgICAgICAgcGFkZGluZzogMDtcbiAgICAgICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjQ0REQ0REO1xuICAgICAgICAgICAgYmFja2dyb3VuZDogI2U2ZWZmMDtcbiAgICAgICAgICAgIGhlaWdodDogNDBweDtcblxuICAgICAgICAgICAgaW9uLWNhcmQtdGl0bGUge1xuICAgICAgICAgICAgICAgIC0tY29sb3I6ICMwMDUxNTc7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgICAgICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxMHB4O1xuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICAgICAgICAgIHRleHQtYWxpZ246IHN0YXJ0O1xuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDNweCAxMHB4O1xuICAgICAgICAgICAgICAgIHBhZGRpbmctdG9wOiA4cHg7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC5vcmRlci10eXBlIHtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDlweDtcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAwIDEwcHg7XG4gICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG5cbiAgICAgICAgICAgICAgICAmLmJ1eSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjMkVCRDg1O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAmLnNlbGwge1xuICAgICAgICAgICAgICAgICAgICBjb2xvcjogI0Y1NDU1QTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIC5pY29uLWxpbmsge1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGlubGluZS1mbGV4O1xuICAgICAgICAgICAgICAgIGJvcmRlci1pbmxpbmUtc3RhcnQ6IDFweCBzb2xpZCAjQ0REQ0REO1xuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICYuZGVsZXRlIHtcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICNGNTQ1NUE7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgaW9uLWNhcmQtY29udGVudCB7XG4gICAgICAgICAgICBwYWRkaW5nOiAxMHB4O1xuXG4gICAgICAgICAgICAuaXRlbS12YWx1ZSB7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cblxuXG4gICAgICAgICYub3JkZXItYnV5IHtcbiAgICAgICAgICAgIGJvcmRlci1jb2xvcjogI0QzRUFFNjtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgaW9uLWNhcmQtaGVhZGVyIHtcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjRTlGOEYzO1xuICAgICAgICAgICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjRDNFQUU2O1xuXG4gICAgICAgICAgICAgICAgLm9yZGVyLXR5cGUge1xuICAgICAgICAgICAgICAgICAgICBjb2xvcjogIzJFQkQ4NVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIC5pY29uLWxpbmsge1xuICAgICAgICAgICAgICAgICAgICBib3JkZXItY29sb3I6ICNEM0VBRTY7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgJi5vcmRlci1zZWxsIHtcbiAgICAgICAgICAgIGJvcmRlci1jb2xvcjogI0U4REVFMTtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgaW9uLWNhcmQtaGVhZGVyIHtcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjRkVFQ0VFO1xuICAgICAgICAgICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjRThERUUxO1xuXG4gICAgICAgICAgICAgICAgLm9yZGVyLXR5cGUge1xuICAgICAgICAgICAgICAgICAgICBjb2xvcjogI0Y1NDU1QTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAuaWNvbi1saW5rIHtcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyLWNvbG9yOiAjRThERUUxO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5vcmRlci1zdGF0dXMge1xuICAgICAgICBwYWRkaW5nOiAwcHggMTBweDtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogM3B4O1xuICAgICAgICBmb250LXNpemU6IDEwcHg7XG4gICAgICAgIG1hcmdpbi1pbmxpbmUtc3RhcnQ6IDVweDtcblxuICAgICAgICBAZWFjaCAkY29sb3Ita2V5LCAkY29sb3ItdmFsdWUgaW4gJHN0YXR1cy1jb2xvcnMge1xuICAgICAgICAgICAgJi0jeyRjb2xvci1rZXl9IHtcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3ItdmFsdWUgIWltcG9ydGFudDtcbiAgICAgICAgICAgICAgICBjb2xvcjogc2V0VGV4dENvbG9yKCRjb2xvci12YWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyAmLWdyZWVuIHtcbiAgICAgICAgLy8gICAgIGJhY2tncm91bmQtY29sb3I6ICMyZWJkODU7XG4gICAgICAgIC8vIH1cbiAgICAgICAgLy8gJi1yZWQge1xuICAgICAgICAvLyAgICAgYmFja2dyb3VuZC1jb2xvcjogI2Y1NDU1YTtcbiAgICAgICAgLy8gfVxuICAgICAgICAvLyAmLWdyZXkge1xuICAgICAgICAvLyAgICAgYmFja2dyb3VuZC1jb2xvcjogI2E1YTVhNTtcbiAgICAgICAgLy8gfVxuICAgICAgICAvLyAmLXNreS1ibHVlIHtcbiAgICAgICAgLy8gICAgIGJhY2tncm91bmQtY29sb3I6ICM4M2FmYjQ7XG4gICAgICAgIC8vIH1cbiAgICAgICAgLy8gJi1vcmFuZ2Uge1xuICAgICAgICAvLyAgICAgYmFja2dyb3VuZC1jb2xvcjogI2Y3ZDExODtcbiAgICAgICAgLy8gfVxuICAgICAgICAvLyAmLXB1cnBsZSB7XG4gICAgICAgIC8vICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjOGQ0MTg5O1xuICAgICAgICAvLyB9XG4gICAgfVxufVxuXG5pb24tcmVmcmVzaGVyIHtcbiAgICBiYWNrZ3JvdW5kOiAjRjRGOEY4O1xuICAgIC0tY29sb3I6IzAwNTE1NztcbiAgICAtLWlvbi10ZXh0LWNvbG9yOiMwMDUxNTc7XG59XG5cblxuXG4ud2FsbGV0Q2xhc3N7XG4gICAgd2lkdGg6IDU1cHg7XG4gICAgaGVpZ2h0OiAyM3B4O1xuICAgIGZvbnQtZmFtaWx5OiBBbGlubWFUaGVTYW5zO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IG5vcm1hbDtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IHJpZ2h0O1xuICAgIC8vIGNvbG9yOiAjMDA1NDU3O1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS10eHQpO1xufVxuXG4uc3RhbmRpbmctb3JkZXJzLXNlYXJjaHtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAvLyBwYWRkaW5nOiAwO1xuICAgIGhlaWdodDogNDVweDtcbiAgICBib3JkZXI6IDJweCBzb2xpZCAjOTliOWJjO1xuICAgIGlvbi1pbnB1dHtcbiAgICAgICAvLyBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgICAgICAgY29sb3I6ICM2NTk3OWE7XG4gICAgfVxufVxuXG4uc3RhbmRpbmctb3JkZXItdG9vbGJhcntcbiAgICAtLWJhY2tncm91bmQ6ICMwMDUxNTc7XG59XG5cbi5zdGFuZGluZy1vcmRlci1zZWxlY3QtaXRlbXtcbiAgICAvLyBjb2xvcjogIzAwNTQ1NztcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktdHh0KTtcbiAgICBib3JkZXI6IDJweCBzb2xpZCAjOTliOWJjO1xuICAgIFxufVxuXG4uc3RhbmRpbmctb3JkZXItcGFkZGlpbmctdG9wLTIwcHh7XG4gICAgcGFkZGluZy10b3A6IDIwcHg7XG59XG5cbi5zdGFuZGluZy1vcmRlci1oZWlnaHQtcGFkZGluZ3tcbiAgICBoZWlnaHQ6IDQwcHg7XG4gICAgcGFkZGluZy10b3A6IDEwcHg7XG59XG5cbi5zdGFuZGluZy1vcmRlci13LTEwMHtcbiAgICB3aWR0aDogMTAwJTtcbn1cblxuLnN0YW5kaW5nLW9yZGVycy1zZWFyY2h7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuXG4gICAgLy8gLnN0YW5kaW5nLW9yZGVycy1zZWFyY2gtaWNvbntcbiAgICAvLyAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIC8vICAgICB0b3A6IDE1cHg7XG4gICAgLy8gICAgIGNvbG9yOiAjMDAwO1xuICAgIC8vICAgICByaWdodDogMTJweDtcbiAgICAvLyAgICAgei1pbmRleDogMjtcbiAgICAvLyB9XG4gICAgXG59XG5cbi5zdGFuZGluZy1vcmRlcnMtZmlsdGVyLWRpc3BsYXl7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIHBhZGRpbmc6IDlweCAwO1xuICAgIHRleHQtdHJhbnNmb3JtOiBjYXBpdGFsaXplO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICMwMDUxNTc7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIG1hcmdpbi10b3A6IDVweDtcbiAgICBtYXJnaW4tYm90dG9tOiA1cHg7XG4gICAgLnN0YW5kaW5nLW9yZGVycy1maWx0ZXItZGlzcGxheS1pY29uc3tcbiAgICAgICAgbWFyZ2luLXRvcDogM3B4O1xuICAgIH1cbiAgICAuc3RhbmRpbmctb3JkZXItZmlsdGVyLWRpc3BsYXktdGl0bGV7XG4gICAgICAgIG1hcmdpbjogMCA0cHg7XG4gICAgfVxufVxuXG4uc3RhbmRpbmctb3JkZXJzLWRlbGV0ZS1kaXNwbGF5e1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICBwYWRkaW5nOiA5cHggMDtcbiAgICB0ZXh0LXRyYW5zZm9ybTogY2FwaXRhbGl6ZTtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjU0NTVhO1xuICAgIGNvbG9yOndoaXRlO1xuICAgIG1hcmdpbi10b3A6IDVweDtcbiAgICBtYXJnaW4tYm90dG9tOiA1cHg7XG4gICAgLnN0YW5kaW5nLW9yZGVycy1maWx0ZXItZGlzcGxheS1pY29uc3tcbiAgICAgICAgbWFyZ2luLXRvcDogM3B4O1xuICAgIH1cbiAgICAuc3RhbmRpbmctb3JkZXItZmlsdGVyLWRpc3BsYXktdGl0bGV7XG4gICAgICAgIG1hcmdpbjogMCA0cHg7XG4gICAgfVxufVxuXG4uc3RhbmRpbmctb3JkZXJzLXdhbGxldC1zZWxlY3R7XG4gICAgaW9uLXNlbGVjdHtcbiAgICAgICAgcGFkZGluZzogMTFweDtcbiAgICB9XG59XG5cbi5zZWFyY2gtaWNvbntcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgaW9uLWljb257XG4gICAgICAgIGNvbG9yOiAjZmZmO1xuICAgIH1cbn1cbmlvbi1zZWFyY2hiYXIge1xuICAgIC8vYmFja2dyb3VuZC1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgICBoZWlnaHQ6IDQwcHggIWltcG9ydGFudDtcbn0gXG5cbi5jYXJkLWhlaWdodHtcbiAgICBoZWlnaHQ6IDM1NHB4O1xuICAgIG92ZXJmbG93LXk6IHNjcm9sbDtcbiAgICBwYWRkaW5nOiAwcHggMDtcbn1cblxuLnN0YW5kaW5nLW9yZGVyLWhlYWRlcntcbiAgICBwYWRkaW5nOiA1cHggMDtcbn1cblxuLnN0YW5kaW5nLXRpdGxle1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogd2hpdGU7XG59XG5cbi5zdGFuZGluZy1vcmRlci1ncmlkLWJre1xuICAgIGJhY2tncm91bmQtY29sb3I6ICMwMDUxNTc7XG59Il19 */";

/***/ }),

/***/ 40683:
/*!*******************************************************************************************!*\
  !*** ./src/app/pages/standing-orders/delete-order/delete-order.component.html?ngResource ***!
  \*******************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar class=\"standing-order-toolbar\" >\n    <ion-title>\n          {{'outstandingOrder.cancelOrders' | translate}}\n  </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-grid style=\"padding: 0px;\">\n    <ion-row>\n      <ion-col>\n        <span class=\"walletClass\">{{'outstandingOrder.cancelOrderText' | translate}}</span>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-grid class=\"standing-order-header\">\n       \n            <div>\n            <tadawul-grid-header\n            [headerList]=outstandingOrdersHeader() [ngClass]=\"{'symbols-list-header': true}\"\n            ></tadawul-grid-header>\n          </div>\n         \n        \n          <div class=\"card-height\">\n            <div *ngFor=\"let order of outstandingOrders\">\n            <tadawul-collapsible-list\n            [ngClass] = \"{'symbols-list': true}\"\n            [cardTextOne]= order.symbol?.abbreviation\n            [cardTextOneSecondLine]= order.side.name\n            [cardTextOneThirdLine]= order.symbol?.id\n            [cardTextOneFourthLine]= order.type?.name\n            [statusColor]= order.ststusColor\n            [cardTextTwo]=\"order.price | commafy:'number':2\"\n            [cardTextThree]=\"order.executedQuantity\"\n            [cardTextFour]=\"order.remainingQuantity\"\n            [cardTextFive]=order.status.name\n            formName = \"outstanding\"\n            colOneSize=\"3.2\"\n            colTwoSize=\"1.4\"\n            colThreeSize=\"1.4\"\n            colFourSize=\"2\"\n            colFiveSize=\"1.8\"\n            colSixSize=\"1.2\"\n            [arrow]=\"false\"\n            [expand]=\"order.expanded\"\n            (collabseClick)=\"collapsSymbole(order,outstandingOrders)\"\n            >\n           \n         \n            <tadawul-stock-quick-view\n            headerFirstText=\"{{'outstandingOrder.filterByType' | translate}}\"\n            headerSecondText=\"{{'outstandingOrder.orderNumber' | translate}}\"\n            headerThirdText=\"{{'outstandingOrder.remainingQuantity' | translate}}\"\n            [headerFirstValue]=order.side.name\n            [headerSecondValue]= order.referenceNumber\n            [headerThirdValue]= \"order.remainingQuantity | commafy:'number':2\"\n            middelFirstText=\"{{'outstandingOrder.orderDate' | translate}}\"\n            middelSecondText=\"{{'outstandingOrder.endDate' | translate}}\"\n            middleThirdText=\"{{'outstandingOrder.expiry' | translate}}\"\n            [middelFirstValue]=order.date \n            [middelSecondValue]= order.endDate\n            [middelThirdValue]= order.tif?.name\n           \n            [statusFlag] = order.status?.name\n            >\n            </tadawul-stock-quick-view>\n        \n            </tadawul-collapsible-list>\n          </div>\n          </div>\n      </ion-grid>\n    </ion-row>\n    <ion-row class=\"deleteNote\">\n      {{'outstandingOrder.deleteNote' | translate}}\n    </ion-row>\n  </ion-grid>\n</ion-content>\n<ion-footer>\n\n    <ion-grid class=\"ion-padding\">\n      <app-button \n        (clickAction)=\"deleteAllOrders()\"\n        expand=\"block\" \n        size=\"\"\n        color=\"danger\"\n        fill=\"solid\"\n        strong=\"false\"\n        target=\"_blank\"\n        >\n        {{'outstandingOrder.cancelOrdersButton' | translate}}\n      </app-button>\n    \n        <app-button \n        (clickAction)=\"closeModal()\"\n        expand=\"block\" \n        size=\"\"\n        color=\"txt\"\n        fill=\"outline\"\n        strong=\"false\"\n        target=\"_blank\"\n        >\n        {{'outstandingOrder.back' | translate}}\n      </app-button>\n    </ion-grid>\n</ion-footer>";

/***/ }),

/***/ 65654:
/*!*********************************************************************************************!*\
  !*** ./src/app/pages/standing-orders/filter-orders/filter-orders.component.html?ngResource ***!
  \*********************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header translucent>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <!-- <ion-menu-button autoHide=\"true\"></ion-menu-button> -->\n      <ion-back-button text=\"\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>\n      {{'morePage.SEARCH_ORDERS' | translate}}\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n\n  <ion-grid>\n\n    <!-- المحفظة -->\n    <ion-row class=\"ion-align-items-center\">\n      <ion-col size=\"4\">\n        <ion-text class=\"label-form\">{{'outstandingOrder.wallet' | translate}}</ion-text>\n      </ion-col>\n      <ion-col size=\"8\">\n        <div class=\"select-picker-placeholder\" (click)=\"openPortfolioPicker()\">\n          <ion-text class=\"select-color\">{{selectedPortfolioValue}}</ion-text>\n          <span class=\"icon icon-chevron-right picker-select-icon select-color\"></span>\n        </div>\n        <!-- <ion-select interface=\"action-sheet\" mode=\"ios\" [interfaceOptions]=\"{header: 'outstandingOrder.wallets' | translate, cssClass: 'app-select'}\" [value]=\"allStandardPortfolios[0]?.id\" [(ngModel)]=\"selectedPortfolioID\" cancelText=\"{{'outstandingOrder.CANCEL' | translate}}\">\n          <ion-select-option *ngFor=\"let item of allStandardPortfolios\" [value]=\"item.id\" selected>{{item.id}}</ion-select-option>\n        </ion-select> -->\n      </ion-col>\n    </ion-row>\n\n    <!-- حالة الأمر -->\n    <ion-row class=\"ion-align-items-center\">\n      <ion-col size=\"4\">\n        <ion-text class=\"label-form\">{{'outstandingOrder.filterByStatus' | translate}}</ion-text>\n      </ion-col>\n      <ion-col size=\"8\">\n        <div class=\"select-picker-placeholder\" (click)=\"openOrderStatusPicker()\">\n          <ion-text class=\"select-color\">{{selectedStatusValue}}</ion-text>\n          <span class=\"icon icon-chevron-right picker-select-icon select-color\"></span>\n        </div>\n        <!-- <ion-select interface=\"action-sheet\" mode=\"ios\"\n          [interfaceOptions]=\"{header: 'outstandingOrder.filterByStatus' | translate, cssClass: 'app-select'}\"\n          [value]=\"statuses[0]?.id\" [(ngModel)]=\"statusID\" cancelText=\"{{'outstandingOrder.CANCEL' | translate}}\">\n          <ion-select-option *ngFor=\"let status of statuses\" [value]=\"status.id\" selected>{{status.name}}\n          </ion-select-option>\n        </ion-select> -->\n      </ion-col>\n    </ion-row>\n\n    <!-- نوع الأمر -->\n    <ion-row class=\"ion-align-items-center\">\n      <ion-col size=\"4\">\n        <ion-text class=\"label-form\">{{'outstandingOrder.filterByType' | translate}}</ion-text>\n      </ion-col>\n      <ion-col size=\"8\">\n        <div class=\"select-picker-placeholder\" (click)=\"openOrderSidePicker()\">\n          <ion-text class=\"select-color\">{{selectedOrderSideValue}}</ion-text>\n          <span class=\"icon icon-chevron-right picker-select-icon select-color\"></span>\n        </div>\n        <!-- <ion-select interface=\"action-sheet\" mode=\"ios\"\n          [interfaceOptions]=\"{header: 'outstandingOrder.filterByType' | translate, cssClass: 'app-select'}\"\n          [value]=\"types[0]?.id\" [(ngModel)]=\"typeID\" cancelText=\"{{'outstandingOrder.CANCEL' | translate}}\">\n          <ion-select-option *ngFor=\"let type of types\" [value]=\"type.id\" selected>{{type.name}}</ion-select-option>\n        </ion-select> -->\n      </ion-col>\n    </ion-row>\n\n    <!-- الفترة -->\n    <ion-row class=\"ion-align-items-center\">\n      <ion-col size=\"4\">\n        <ion-text class=\"label-form\">{{'outstandingOrder.filterByPeriod' | translate}}</ion-text>\n      </ion-col>\n      <ion-col size=\"8\">\n        <ion-segment class='form-segment' value=\"outstandingOrder.specificPeriod\">\n          <ion-segment-button (click)=\"changePeriod(1)\" value=\"outstandingOrder.specificPeriod\">\n            <ion-label>{{'outstandingOrder.specificPeriod' | translate}}</ion-label>\n          </ion-segment-button>\n          <ion-segment-button (click)=\"changePeriod(2)\" value=\"outstandingOrder.fromDate\">\n            <ion-label>{{'outstandingOrder.fromDate' | translate}}</ion-label>\n          </ion-segment-button>\n        </ion-segment>\n      </ion-col>\n    </ion-row>\n\n    <!-- نوع الأمر -->\n    <ion-row class=\"ion-align-items-center\" [hidden]=\"selectedPeriod == 2\">\n      <ion-col size=\"4\">\n        <ion-text class=\"label-form\">{{'outstandingOrder.specificPeriod' | translate}}</ion-text>\n      </ion-col>\n      <ion-col size=\"8\">\n        <div class=\"select-picker-placeholder\" (click)=\"openOrderPeriodPicker()\">\n          <ion-text class=\"select-color\">{{selectedOrderPeriodValue}}</ion-text>\n          <span class=\"icon icon-chevron-right picker-select-icon select-color\"></span>\n        </div>\n        <!-- <ion-select interface=\"action-sheet\" mode=\"ios\"\n          [interfaceOptions]=\"{header: 'outstandingOrder.specificPeriod' | translate, cssClass: 'app-select'}\"\n          [value]=\"periods[0]?.id\" [(ngModel)]=\"periodID\" cancelText=\"{{'outstandingOrder.CANCEL' | translate}}\">\n          <ion-select-option *ngFor=\"let period of periods\" [value]=\"period.id\" selected>{{period.name}}\n          </ion-select-option>\n        </ion-select> -->\n      </ion-col>\n    </ion-row>\n\n    <!-- التاريخ من -->\n    <ion-row class=\"ion-align-items-center\" [hidden]=\"selectedPeriod == 1\">\n      <ion-col size=\"4\">\n        <ion-text class=\"label-form\">{{'outstandingOrder.fromDate' | translate}}</ion-text>\n      </ion-col>\n      <ion-col size=\"8\">\n        <!-- <ion-datetime placeholder=\"00/00/0000\" displayFormat=\"YYYY-MM-DD\" [(ngModel)]='startDate' max='2030'\n          doneText=\"{{ 'outstandingOrder.DONE' | translate }}\" cancelText=\"{{ 'outstandingOrder.CANCEL' | translate }}\">\n        </ion-datetime> -->\n\n\n        <div  id=\"open-start-date-modal\" class=\"select-picker-placeholder\">\n          <ion-text class=\"select-color\">{{startDate}}</ion-text>\n          <div class=\"icon-bg\" style=\"margin-inline-end: 5px;\"><span class=\"icon icon-calendar main-color\"></span></div>\n        </div>\n       \n        <ion-input [(ngModel)]=\"startDate\" [hidden]=\"true\"></ion-input>\n        <ion-modal trigger=\"open-start-date-modal\" class=\"date-time-modal\">\n          <ng-template>\n            <ion-content>\n              <ion-datetime #datepicker class=\"rounded-date\" [ngModelOptions]=\"{standalone:true}\"\n                displayFormat=\"YYYY-MM-DD\"  presentation=\"date\" [max]=\"today\"\n                showDefaultButtons=\"true\" [(ngModel)]=\"startDate\" doneText=\"{{ 'app.OK' | translate  }}\" cancelText=\"{{ 'app.CANCEL' | translate  }}\">\n              </ion-datetime>\n            </ion-content>\n          </ng-template>\n        </ion-modal>\n\n      </ion-col>\n    </ion-row>\n\n    <!-- التاريخ إلى -->\n    <ion-row class=\"ion-align-items-center\" [hidden]=\"selectedPeriod == 1\">\n      <ion-col size=\"4\">\n        <ion-text class=\"label-form\">{{'outstandingOrder.toDate' | translate}}</ion-text>\n      </ion-col>\n      <ion-col size=\"8\">\n        <!-- <ion-datetime placeholder=\"00/00/0000\" displayFormat=\"YYYY-MM-DD\" [(ngModel)]='endDate' min='{{startDate}}'\n          max='2030' doneText=\"{{ 'outstandingOrder.DONE' | translate }}\"\n          cancelText=\"{{ 'outstandingOrder.CANCEL' | translate }}\"></ion-datetime> -->\n\n\n        <div  id=\"open-end-date-modal\" class=\"select-picker-placeholder\">\n          <ion-text class=\"select-color\">{{endDate}}</ion-text>\n          <div class=\"icon-bg\" style=\"margin-inline-end: 5px;\"><span class=\"icon icon-calendar main-color\"></span></div>\n        </div>\n       \n        <ion-input [(ngModel)]=\"endDate\" [hidden]=\"true\"></ion-input>\n        <ion-modal trigger=\"open-end-date-modal\" class=\"date-time-modal\">\n          <ng-template>\n            <ion-content>\n              <ion-datetime #datepicker class=\"rounded-date\" [ngModelOptions]=\"{standalone:true}\"\n              displayFormat=\"YYYY-MM-DD\"  presentation=\"date\" max=\"2030\" min='{{startDate}}'\n                showDefaultButtons=\"true\" [(ngModel)]=\"endDate\" doneText=\"{{ 'app.OK' | translate  }}\" cancelText=\"{{ 'app.CANCEL' | translate  }}\">\n              </ion-datetime>\n            </ion-content>\n          </ng-template>\n        </ion-modal>\n\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\n  <!-- <ion-grid>\n\n    <ion-row style=\"padding-top: 10px;\">\n      <ion-col>\n        <span class=\"walletClass\">{{'outstandingOrder.wallet' | translate}}</span>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-select interface=\"action-sheet\" mode=\"ios\"\n          [interfaceOptions]=\"{header: 'outstandingOrder.wallets' | translate, cssClass: 'app-select'}\"\n          [value]=\"allStandardPortfolios[0]?.id\" [(ngModel)]=\"selectedPortfolioID\" class=\"standing-order-select-item\"\n          cancelText=\"{{'outstandingOrder.CANCEL' | translate}}\">\n          <ion-select-option *ngFor=\"let item of allStandardPortfolios\" [value]=\"item.id\" selected>{{item.id}}\n          </ion-select-option>\n        </ion-select>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col>\n        <span class=\"walletClass\">{{'outstandingOrder.filterByStatus' | translate}}</span>\n      </ion-col>\n    </ion-row>\n    <ion-row ion-segment mode=\"md\">\n      <ion-segment scrollable=\"true\" [(ngModel)]=\"statusID\">\n        <ion-segment-button *ngFor=\"let status of statuses\" [value]=\"status.id\">\n          <ion-label>{{ status.name}}</ion-label>\n        </ion-segment-button>\n      </ion-segment>\n    </ion-row>\n    <hr style=\"background-color: #dedede;\">\n    <ion-row>\n      <ion-col>\n        <span class=\"walletClass\">{{'outstandingOrder.filterByType' | translate}}</span>\n      </ion-col>\n\n    </ion-row>\n    <ion-row ion-segment mode=\"md\">\n      <ion-segment scrollable=\"true\" [(ngModel)]=\"typeID\">\n        <ion-segment-button *ngFor=\"let type of types\" [value]=\"type.id\">\n          <ion-label>{{ type.name}}</ion-label>\n        </ion-segment-button>\n      </ion-segment>\n    </ion-row>\n    <hr style=\"background-color: #dedede;\">\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-label class=\"walletClass\">{{'outstandingOrder.filterByPeriod' | translate}}</ion-label>\n      </ion-col>\n      <ion-row>\n        <ion-col size=\"6\" [ngClass]=\"selectedPeriod == 1 ?  'investment-btn' : 'in-active-btn'\">\n          <ion-button expand=\"full\" color=\"txt\" (click)=\"changePeriod(1)\">\n            {{'outstandingOrder.specificPeriod' | translate}}\n          </ion-button>\n        </ion-col>\n        <ion-col class=\"home-btn-padding\" [ngClass]=\"selectedPeriod == 2 ?  'investment-btn' : 'in-active-btn'\"\n          size=\"6\">\n          <ion-button expand=\"full\" color=\"txt\" (click)=\"changePeriod(2)\">\n            {{'outstandingOrder.fromDate' | translate}}\n          </ion-button>\n        </ion-col>\n      </ion-row>\n    </ion-row>\n    <hr style=\"background-color: #dedede;\">\n\n    <ion-row ion-segment mode=\"md\" [hidden]=\"selectedPeriod == 2\">\n      <ion-col size=\"12\" class=\"walletClass\">{{'outstandingOrder.specificPeriod' | translate}}</ion-col>\n      <ion-col size=\"12\" style=\"margin-top: 10px;\">\n        <ion-segment scrollable=\"true\" [(ngModel)]=\"periodID\">\n          <ion-segment-button *ngFor=\"let period of periods\" [value]=\"period.id\">\n            <ion-label>{{period.name}}</ion-label>\n          </ion-segment-button>\n        </ion-segment>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"filter-orders-row filter-orders\" [hidden]=\"selectedPeriod == 1\">\n      <ion-col size=\"10\">\n        <ion-label class=\"walletClass\" position=\"floating\">{{'outstandingOrder.fromDate' | translate}}</ion-label>\n        <ion-item class=\"filter-orders-item\">\n\n          <ion-datetime placeholder=\"00/00/0000\" displayFormat=\"YYYY-MM-DD\" [(ngModel)]='startDate' max='2030'\n            doneText=\"{{ 'outstandingOrder.DONE' | translate }}\"\n            cancelText=\"{{ 'outstandingOrder.CANCEL' | translate }}\"></ion-datetime>\n        </ion-item>\n      </ion-col>\n      <ion-col class=\"filter-orders-col-icon\" size=\"2\">\n        <div class=\"calendar-bk\">\n          <ion-icon name=\"calendar-outline\"></ion-icon>\n        </div>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"filter-orders-row filter-orders\" [hidden]=\"selectedPeriod == 1\">\n      <ion-col size=\"10\">\n        <ion-label class=\"walletClass\" position=\"floating\">{{'outstandingOrder.toDate' | translate}}</ion-label>\n        <ion-item class=\"filter-orders-item\">\n          <ion-datetime placeholder=\"00/00/0000\" displayFormat=\"YYYY-MM-DD\" [(ngModel)]='endDate' min='{{startDate}}'\n            max='2030' doneText=\"{{ 'outstandingOrder.DONE' | translate }}\"\n            cancelText=\"{{ 'outstandingOrder.CANCEL' | translate }}\"></ion-datetime>\n        </ion-item>\n      </ion-col>\n      <ion-col class=\"filter-orders-col-icon\" size=\"2\">\n        <div class=\"calendar-bk\">\n          <ion-icon name=\"calendar-outline\"></ion-icon>\n        </div>\n      </ion-col>\n    </ion-row>\n  </ion-grid> -->\n  <ion-grid class=\"ion-padding\">\n    <app-button (clickAction)=\"search()\" expand=\"block\" size=\"\" color=\"primary\" fill=\"solid\" strong=\"false\"\n      target=\"_blank\">\n      {{'outstandingOrder.search' | translate}}\n    </app-button>\n  </ion-grid>\n  \n</ion-content>\n<ion-footer>\n  <tadawul-loader *ngIf=\"showLoader\"></tadawul-loader>\n</ion-footer>";

/***/ }),

/***/ 52669:
/*!***********************************************************************************************!*\
  !*** ./src/app/pages/standing-orders/filter-results/filter-results.component.html?ngResource ***!
  \***********************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <!-- <ion-menu-button autoHide=\"true\"></ion-menu-button> -->\n      <ion-back-button text=\"\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>\n          {{'outstandingOrder.searchResults' | translate}}\n  </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n\n  <ion-row class=\"criteria-container\">\n    <ion-col size=\"6\" style=\"border-bottom: 1px solid #cddfe1;\">\n      <span class=\"textClass\">{{'outstandingOrder.wallet' | translate}}:</span>\n      <span class=\"valueClass\">{{searchInfoObj.portfolio}}</span>\n    </ion-col>\n    <ion-col size=\"6\" style=\"border-bottom: 1px solid #cddfe1;padding-top: 0px;\">\n      <ion-row id=\"period-container\">\n      <ion-col size=\"4\" class=\"textClass\">{{'outstandingOrder.searchperiod' | translate}}:</ion-col>\n      <ion-col style=\"padding: 0px;\" size=\"7\">\n        <span class=\"valueClass\">{{searchInfoObj.period}}</span>\n        <span class=\"valueClass\">{{searchInfoObj?.toDate}}</span>\n      </ion-col>\n    </ion-row>\n    </ion-col>\n    <ion-col size=\"6\">\n      <span class=\"textClass\">{{'outstandingOrder.searchstatus' | translate}}:</span>\n      <span class=\"valueClass\">{{searchInfoObj.status}}</span>\n    </ion-col>\n    <ion-col size=\"6\">\n      <span class=\"textClass\">{{'outstandingOrder.searchorder' | translate}}:</span>\n      <span class=\"valueClass\">{{searchInfoObj.type}}</span>\n    </ion-col>\n  </ion-row>\n\n  <ng-container *ngIf=\"showLoader\">\n    <tadawul-skeleton-loader [type]=\"SkeletonType.ORDER_CARD\" *ngFor=\"let item of [].constructor(3)\">\n    </tadawul-skeleton-loader>\n  </ng-container>\n\n  <div class=\"order-list\">\n    <div *ngFor=\"let order of outstandingOrders\" [hidden]=\"outstandingOrders?.length == 0\">\n      <ion-card class=\"order-item\" [ngClass]=\"order.side.id  === 'BUY' ? 'order-buy' : 'order-sell'\">\n        <ion-card-header>\n          <ion-grid class=\"ion-no-padding\">\n            <ion-row>\n              <ion-col> <!--this.outstandingOrders[i].orderStatusColor = this.getOrderStatusColor(this.outstandingOrders[i].status.name);-->\n                <ion-card-title>{{order?._symbolShortName}} <span class=\"order-status\" [ngClass]=\"order.orderStatusColor\">{{order.status.name}}</span></ion-card-title>\n                <div class=\"order-type\">{{order.side.name}} - {{order.type?.name}} {{order?.tif?.name}} {{order.endDate}}</div>\n              </ion-col>\n              <!-- <ion-col size=\"auto\">\n                <div class=\"icon-link\" (click)=\"editDeleteOrder(order,'edit')\">\n                  <span class=\"icon icon-edit\"></span>\n                </div>\n                <div class=\"icon-link delete\" (click)=\"editDeleteOrder(order,'delete')\">\n                  <span class=\"icon icon-delete\"></span>\n                </div>\n              </ion-col> -->\n            </ion-row>\n          </ion-grid>\n        </ion-card-header>\n      \n        <ion-card-content>\n\n          <ion-grid class=\"ion-no-padding\">\n            <ion-row>\n              <ion-col size=\"3\">\n                <div class=\"item-label\">{{'outstandingOrder.orderDate' | translate}}</div>\n                <div class=\"item-value\">\n                  {{order.date}}\n                </div>\n              </ion-col>\n\n              <ion-col size=\"3\">\n                <div class=\"item-label\">{{'outstandingOrder.quantity' | translate}}</div>\n                <div class=\"item-value\">\n                  {{order.quantity}}\n                </div>\n              </ion-col>\n\n              <ion-col size=\"3\">\n                <div class=\"item-label\">{{'outstandingOrder.excutedQuantity' | translate}}</div>\n                <div class=\"item-value\">\n                  {{order.executedQuantity}}\n                </div>\n              </ion-col>\n\n              <ion-col size=\"3\">\n                <div class=\"item-label\">{{'outstandingOrder.price' | translate}}</div>\n                <div class=\"item-value\">\n                  {{order.price | commafy:'number':2}}\n                </div>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </ion-card-content>\n      </ion-card>\n    </div>\n    <div *ngIf=\"!showLoader\" [hidden]=\"outstandingOrders?.length != 0\">\n      <app-empty-state\n      message=\"{{'outstandingOrder.emptyOrders' | translate}}\"\n      image=\"assets/icon/empty-orders.png\"\n      >\n      </app-empty-state>\n    </div>\n  </div>\n\n\n\n\n\n\n\n\n\n\n\n\n  <!-- <ion-grid style=\"padding: 0px;\">\n    <ion-row class=\"criteria-container\">\n      <ion-col size=\"6\" style=\"border-bottom: 1px solid #cddfe1;\">\n        <span class=\"textClass\">{{'outstandingOrder.wallet' | translate}}:</span>\n        <span class=\"valueClass\">{{searchInfoObj.portfolio}}</span>\n      </ion-col>\n      <ion-col size=\"6\" style=\"border-bottom: 1px solid #cddfe1;padding-top: 0px;\">\n        <ion-row id=\"period-container\">\n        <ion-col size=\"4\" class=\"textClass\">{{'outstandingOrder.searchperiod' | translate}}:</ion-col>\n        <ion-col style=\"padding: 0px;\" size=\"7\">\n          <span class=\"valueClass\">{{searchInfoObj.period}}</span>\n          <span class=\"valueClass\">{{searchInfoObj?.toDate}}</span>\n        </ion-col>\n      </ion-row>\n      </ion-col>\n      <ion-col size=\"6\">\n        <span class=\"textClass\">{{'outstandingOrder.searchstatus' | translate}}:</span>\n        <span class=\"valueClass\">{{searchInfoObj.status}}</span>\n      </ion-col>\n      <ion-col size=\"6\">\n        <span class=\"textClass\">{{'outstandingOrder.searchorder' | translate}}:</span>\n        <span class=\"valueClass\">{{searchInfoObj.type}}</span>\n      </ion-col>\n    </ion-row>\n    <ion-row style=\"margin-top: 10px;\">\n      <ion-grid class=\"standing-order-header\">\n            <div>\n            <tadawul-grid-header\n            [headerList]=outstandingOrdersHeader() [ngClass]=\"{'symbols-list-header': true}\"\n            ></tadawul-grid-header>\n          </div>\n        \n          <div class=\"card-height\">\n            <div *ngFor=\"let order of outstandingOrders\">\n            <tadawul-collapsible-list\n            [ngClass] = \"{'symbols-list': true}\"\n            [cardTextOne]= order.symbol?.abbreviation\n            [cardTextOneSecondLine]= order.side.name\n            [cardTextOneThirdLine]= order.symbol?.id\n            [cardTextOneFourthLine]= order.type?.name\n            [statusColor]= order.ststusColor\n            [cardTextTwo]=\"order.price | commafy:'number':3\"\n            [cardTextThree]=\"order.executedQuantity\"\n            [cardTextFour]=\"order.remainingQuantity\"\n            [cardTextFive]=order.status.name\n            formName = \"outstanding\"\n            colOneSize=\"3.2\"\n            colTwoSize=\"1.4\"\n            colThreeSize=\"1.4\"\n            colFourSize=\"2\"\n            colFiveSize=\"1.8\"\n            colSixSize=\"1.2\"\n            [arrow]=\"false\"\n            [expand]=\"order.expanded\"\n            (collabseClick)=\"collapsSymbole(order,outstandingOrders)\"\n            >\n           \n         \n            <tadawul-stock-quick-view\n            headerFirstText=\"{{'outstandingOrder.filterByType' | translate}}\"\n            headerSecondText=\"{{'outstandingOrder.orderNumber' | translate}}\"\n            headerThirdText=\"{{'outstandingOrder.remainingQuantity' | translate}}\"\n            [headerFirstValue]=order.side.name\n            [headerSecondValue]= order.referenceNumber\n            [headerThirdValue]= \"order.remainingQuantity | commafy:'number':3\"\n            middelFirstText=\"{{'outstandingOrder.orderDate' | translate}}\"\n            middelSecondText=\"{{'outstandingOrder.endDate' | translate}}\"\n            middleThirdText=\"{{'outstandingOrder.expiry' | translate}}\"\n            [middelFirstValue]=order.date \n            [middelSecondValue]= order.endDate\n            [middelThirdValue]= order.tif?.name\n            firstBtnText=\"{{'outstandingOrder.editOrder' | translate}}\"\n            secondBtnText=\"{{'outstandingOrder.cancelOrder' | translate}}\"\n            firstBtnIcon=\"assets/icon/edit.png\"\n            secondBtnIcon=\"assets/icon/delete.png\"\n            (firstBtnClick)=\"editDeleteOrder(order,'edit')\"\n            (secondBtnClick)=\"editDeleteOrder(order,'delete')\"\n            firstBtnColor=\"stockButtonSecondary\"\n            secondBtnColor=\"stockButtonRed\"\n            [statusFlag] = order.status?.name\n            >\n            </tadawul-stock-quick-view>\n        \n            </tadawul-collapsible-list>\n          </div>\n         </div>\n      </ion-grid>\n    </ion-row>\n  </ion-grid> -->\n</ion-content>\n<!-- <ion-footer>\n\n    <ion-grid class=\"ion-padding\">\n      <app-button \n        (clickAction)=\"backToSearch()\"\n        expand=\"block\" \n        size=\"\"\n        color=\"primary\"\n        fill=\"solid\"\n        strong=\"false\"\n        target=\"_blank\"\n        >\n        {{'outstandingOrder.backToSearch' | translate}}\n      </app-button>\n    </ion-grid>\n</ion-footer> -->";

/***/ }),

/***/ 1624:
/*!*************************************************************************************************!*\
  !*** ./src/app/pages/standing-orders/order-of-orders/order-of-orders.component.html?ngResource ***!
  \*************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar class=\"standing-order-toolbar\" >\n    <ion-title>\n    <ion-grid>\n      <ion-row>\n        <ion-col  class=\"standing-title\">\n          {{'outstandingOrder.sortOrders' | translate}}\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <!-- <ion-grid>\n    <ion-row>\n      <ion-col>\n        <span class=\"walletClass\">{{'outstandingOrder.sortBy' | translate}}</span>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-radio-group class=\"standing-order-w-100\" allow-empty-selection value=\"\" [(ngModel)]='orderBy'>\n       \n        <ion-item (click)=\"OrderData('status')\">\n          <ion-label>{{'outstandingOrder.orderByStatus' | translate}}</ion-label>\n          <ion-radio slot=\"end\" color=\"primary\" value=\"status\"></ion-radio>\n        </ion-item>\n\n        <ion-item (click)=\"OrderData('type')\">\n          <ion-label>{{'outstandingOrder.orderByType' | translate}}</ion-label>\n          <ion-radio slot=\"end\" color=\"primary\" value=\"type\"></ion-radio>\n        </ion-item>\n\n        <ion-item (click)=\"OrderData('period')\">\n          <ion-label>{{'outstandingOrder.orderByPeriod' | translate}}</ion-label>\n          <ion-radio slot=\"end\" color=\"primary\" value=\"period\"></ion-radio>\n        </ion-item>\n      </ion-radio-group>\n    </ion-row>\n  </ion-grid> -->\n\n  <ion-list>\n    <ion-item>\n      <div>\n        <ion-label>\n          <div style=\"color:#005157;font-weight:bold;font-size:14px;padding-top: 5px;\">{{'outstandingOrder.orderByStatus' | translate}}</div>\n        </ion-label>\n      </div>\n      <ion-checkbox [checked]=\"orderBy == 'status'\" (ionChange)=\"OrderData('status');\" slot=\"end\" mode=\"ios\" color=\"primary\"></ion-checkbox>\n    </ion-item>\n    <ion-item>\n      <div>\n        <ion-label>\n          <div style=\"color:#005157;font-weight:bold;font-size:14px;padding-top: 5px;\">{{'outstandingOrder.orderByType' | translate}}</div>\n        </ion-label>\n      </div>\n      <ion-checkbox [checked]=\"orderBy == 'type'\" (ionChange)=\"OrderData('type');\" slot=\"end\" mode=\"ios\" color=\"primary\"></ion-checkbox>\n    </ion-item>\n    <ion-item>\n      <div>\n        <ion-label>\n          <div style=\"color:#005157;font-weight:bold;font-size:14px;padding-top: 5px;\">{{'outstandingOrder.orderByPeriod' | translate}}</div>\n        </ion-label>\n      </div>\n      <ion-checkbox [checked]=\"orderBy == 'period'\" (ionChange)=\"OrderData('period');\" slot=\"end\" mode=\"ios\" color=\"primary\"></ion-checkbox>\n    </ion-item>\n  </ion-list>\n\n\n\n  <!-- <ion-list>\n    <ion-item>\n      <div>\n        <ion-label>\n          <div style=\"color:#005157;font-weight:bold;font-size:14px;padding-top: 5px;\">{{'outstandingOrder.orderByStatus' | translate}}</div>\n        </ion-label>\n      </div>\n      <ion-checkbox checked [ngClass]=\"orderBy != 'status' ?'checkbox-icon' : ''\" (ionChange)=\"closeModal(orderBy);\" slot=\"end\" mode=\"ios\" color=\"primary\"></ion-checkbox>\n    </ion-item>\n  </ion-list> -->\n</ion-content>\n\n\n<!-- \n<ion-footer>\n\n    <ion-grid class=\"ion-padding\">\n      <app-button \n        (clickAction)=\"OrderData()\"\n        expand=\"block\" \n        size=\"\"\n        color=\"primary\"\n        fill=\"solid\"\n        strong=\"false\"\n        target=\"_blank\"\n        >\n        {{'outstandingOrder.sortOrders' | translate}}\n      </app-button>\n    \n        <app-button \n        (clickAction)=\"closeModal()\"\n        expand=\"block\" \n        size=\"\"\n        color=\"txt\"\n        fill=\"outline\"\n        strong=\"false\"\n        target=\"_blank\"\n        >\n        {{'outstandingOrder.back' | translate}}\n      </app-button>\n    </ion-grid>\n</ion-footer> -->";

/***/ }),

/***/ 50487:
/*!****************************************************************************!*\
  !*** ./src/app/pages/standing-orders/standing-orders.page.html?ngResource ***!
  \****************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button [text]=\"''\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{'outstandingOrder.standingOrders' | translate}}</ion-title>\n  </ion-toolbar>\n\n  <div class=\"sub-header\">\n    <ion-grid class=\"ion-no-padding sub-header-top\">\n      <ion-row class=\"ion-justify-content-between ion-align-items-center\">\n        <ion-col size=\"auto\">\n          <div class=\"item-label\">{{'outstandingOrder.wallet' | translate}}</div>\n          <!-- <ion-select [disabled]=\"showLoader\" interface=\"action-sheet\" mode=\"ios\" [interfaceOptions]=\"{header: 'outstandingOrder.wallets' | translate, cssClass: 'app-select'}\" [value]=\"selectedPortfolioID\" class=\"select-wallet\" (ionChange)=\"checkPortfolioType($event.target.value)\" cancelText=\"{{'outstandingOrder.CANCEL' | translate}}\">\n            <ion-select-option *ngFor=\"let item of allPortfolios\" [value]=\"item.id\" selected>{{item.id}}</ion-select-option>\n          </ion-select> -->\n\n \n\n          <div class=\"select-picker-placeholder\" (click)=\"openPortfolioPicker()\">\n            <ion-text class=\"select-color\">{{selectedPortfolioID}}</ion-text>\n            <span class=\"icon icon-chevron-right picker-select-icon select-color\"></span>\n          </div>\n\n\n\n        </ion-col>\n        <ion-col size=\"auto\" class=\"ion-text-end\">\n          <ion-button size=\"small\" (click)=\"deleteAll()\" *ngIf=\"accountType == 'IP'\" class=\"cancel-orders\">\n            <span class=\"icon-delete\"></span>\n            {{'outstandingOrder.deleteAll' | translate}}\n          </ion-button>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n\n    <ion-grid class=\"ion-no-padding sub-header-bottom\">\n      <ion-row>\n        <ion-col>\n          <ion-searchbar [disabled]=\"showLoader\" [(ngModel)]=\"searchTerm\" (ionChange)=\"setFilteredItems()\" placeholder=\"{{'outstandingOrder.searchText' | translate}}\"></ion-searchbar>\n        </ion-col>\n        <ion-col size=\"auto\">\n          <div class=\"icon-link\" (click)=\"presentOrderModal()\">\n            <span class=\"icon icon-sorting\"></span>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </div>\n</ion-header>\n\n<ion-content>\n\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\">\n    <ion-refresher-content pullingIcon=\"chevron-down-circle-outline\" refreshingSpinner=\"crescent\">\n    </ion-refresher-content>\n  </ion-refresher>\n\n<ng-container *ngIf=\"showLoader\">\n  <tadawul-skeleton-loader [type]=\"SkeletonType.ORDER_CARD\" *ngFor=\"let item of [].constructor(3)\">\n  </tadawul-skeleton-loader>\n</ng-container>\n\n  \n<div *ngIf=\"!showLoader\">\n  <div class=\"order-list\" *ngIf=\"accountType == 'IP'\" >\n    \n    <div *ngFor=\"let order of tempOutstandingOrders\" [hidden]=\"tempOutstandingOrders?.length == 0\">\n      <ion-card class=\"order-item\" [ngClass]=\"order.side.id  == 'BUY' ? 'order-buy' : 'order-sell'\">\n        <ion-card-header>\n          <ion-grid class=\"ion-no-padding\">\n            <ion-row>\n              <ion-col>\n                <ion-card-title>{{order._name}} <span class=\"order-status\" [ngClass]=\"order.orderStatusColor\">{{order.status.name}}</span></ion-card-title>\n                <div class=\"order-type\">{{order.side.name}} - {{order.type?.name}} {{order?.tif?.name}} {{order.endDate}}</div>\n              </ion-col>\n              <ion-col size=\"auto\">\n                <div class=\"icon-link\" (click)=\"editDeleteOrder(order,'edit')\">\n                  <span class=\"icon icon-edit\"></span>\n                </div>\n                <div class=\"icon-link delete\" (click)=\"editDeleteOrder(order,'delete')\">\n                  <span class=\"icon icon-delete\"></span>\n                </div>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </ion-card-header>\n      \n        <ion-card-content>\n\n          <ion-grid class=\"ion-no-padding\">\n            <ion-row>\n              <ion-col size=\"3\">\n                <div class=\"item-label\">{{'outstandingOrder.orderDate' | translate}}</div>\n                <div class=\"item-value\">\n                  {{order.date}}\n                </div>\n              </ion-col>\n\n              <ion-col size=\"3\">\n                <div class=\"item-label\">{{'outstandingOrder.quantity' | translate}}</div>\n                <div class=\"item-value\">\n                  {{order.quantity}}\n                </div>\n              </ion-col>\n\n              <ion-col size=\"3\">\n                <div class=\"item-label\">{{'outstandingOrder.excutedQuantity' | translate}}</div>\n                <div class=\"item-value\">\n                  {{order.executedQuantity}}\n                </div>\n              </ion-col>\n\n              <ion-col size=\"3\">\n                <div class=\"item-label\">{{'outstandingOrder.price' | translate}}</div>\n                <div class=\"item-value\">\n                  {{order.price | commafy:'number':2}}\n                </div>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </ion-card-content>\n      </ion-card>\n    </div>\n  \n    <div *ngIf=\"!showLoader\" [hidden]=\"tempOutstandingOrders?.length != 0\">\n      <app-empty-state\n      message=\"{{'outstandingOrder.emptyOrders' | translate}}\"\n      image=\"assets/icon/no-shares.svg\"\n      >\n      </app-empty-state>\n    </div>\n  </div>\n</div>\n\n\n<div *ngIf=\"!showLoader\">\n  <div  *ngIf=\"accountType == 'MP'\" class=\"order-list\">\n    <div *ngFor=\"let order of tempOutstandingOrders\" [hidden]=\"tempOutstandingOrders?.length == 0\">\n      <ion-card class=\"order-item\" [ngClass]=\"order.mutualFundOrderType  == 'SUBSCRIPTION' ? 'order-buy' : 'order-sell'\">\n        <ion-card-header>\n          <ion-grid class=\"ion-no-padding\">\n            <ion-row>\n              <ion-col>\n                <!-- <ion-card-title>{{order.orderId}} - {{order['mutualFund'+ lang + 'Name' ]}} - {{order['mutualFundOrderType' + lang + 'Label']}}</ion-card-title> -->\n                <ion-card-title>{{order._name.toString()}}</ion-card-title>\n                <div class=\"order-type\">{{order._label.toString()}}</div>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </ion-card-header>\n      \n        <ion-card-content>\n\n          <ion-grid class=\"ion-no-padding\">\n            <ion-row>\n              \n              <ion-col size=\"3\">\n                <div class=\"item-label\">{{'outstandingOrder.orderDate' | translate}}</div>\n                <div class=\"item-value\">\n                  {{order.orderStartDate.gregorianDate}}\n                </div>\n              </ion-col>\n              \n              <ion-col size=\"3\">\n                <div class=\"item-label\">{{'outstandingOrder.valuationDate' | translate}}</div>\n                <div class=\"item-value\">\n                  {{order.valuationDate.gregorianDate}}\n                </div>\n              </ion-col>\n\n              <ion-col size=\"3\">\n                <div class=\"item-label\">{{'outstandingOrder.quantity' | translate}}</div>\n                <div class=\"item-value\">\n                  {{order.orderQuantity || '-'}}\n                </div>\n              </ion-col>\n\n              <ion-col size=\"3\">\n                <div class=\"item-label\">{{'outstandingOrder.price' | translate}}</div>\n                <div class=\"item-value\">\n                  {{order.unitPrice.amount | number:'1.6-6'}}\n                </div>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </ion-card-content>\n      </ion-card>\n    </div>\n    <div *ngIf=\"!showLoader\" [hidden]=\"tempOutstandingOrders?.length != 0\">\n      <app-empty-state\n      message=\"{{'outstandingOrder.emptyOrders' | translate}}\"\n      image=\"assets/icon/no-shares.svg\"\n      >\n      </app-empty-state>\n    </div>\n  </div>\n</div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=default-src_app_pages_standing-orders_standing-orders_module_ts.js.map