import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { IdealInvestmentPortfolioComponent } from './ideal-investment-portfolio.component';

describe('IdealInvestmentPortfolioComponent', () => {
  let component: IdealInvestmentPortfolioComponent;
  let fixture: ComponentFixture<IdealInvestmentPortfolioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IdealInvestmentPortfolioComponent ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(IdealInvestmentPortfolioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
