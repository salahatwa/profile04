export enum OpenAccountLovType {
    TITLE,
    EDUCATION_LEVEL,
    MARITAL_STATUS,
    ANNUAL_INCOME,
    NET_WORTH,
    WORK_STATUS,
    JOB_TITLE,
    PREFERRED_LANG,
    ADDRESS_COUNTRY,
    WORK_COUNTRY,
    ADDRESS_CITY,
    WORK_CITY,
    FATCA_COUNTRY
}

export enum OpenAccountSlides {
    PERSONAL_INFO,
    WORK_INFO,
    CONTACT_INFO,
    ADDRESS_INFO,
    WORK_PLACE_INFO,
    MORE_PERSONAL_INFO,
    TIF_INFO,
    TRANSFER_MONEY_INFO,
    FINAL_STEP
}

export enum InputType {
    TEXT_FIELD,
    DROP_DOWN_LIST,
    RADIO_GROUP,
    TEXT_AREA,
    SEGMENT_TIN,
    ADD_COUNTRY,
    USER_NAME,
    PASSWORD,
    CONFIRM_PASSWORD
}


export interface OpenAccountInput {
    label: string;
    brief?: string;
    formControlName: string;
    inputType: number;
    lovType?: number;
    conditionalRadioValue?: string;
    conditionalInput?: SubInput;
    isConditional?: boolean;
    isGrid?: boolean;
    ngModelValue?: any;
    textType?: string;
}

export interface SubInput {
    label?: string;
    placeHolder?: string;
    formControlName?: string;
    inputType: number;
    lovType?: number;

}

export enum RadioButtonValues {
    YES = 'YES',
    NO = 'NO'
}